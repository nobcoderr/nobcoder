#!/usr/bin/env python3
"""Build a normalized, content-addressed development-only replay dataset."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
HOME = ROOT.parent
V011_DATASET = Path(
    "/home/nobcoder/pilot-runs/per-invocation-overshoot-characterization/"
    "ochar-v1-20261004/invocations.jsonl"
)
V012_ROOT = Path(
    "/home/nobcoder/pilot-runs/v0.1.2-acceptance/"
    "v012-rc1-acceptance-20261004"
)
V012_PRODUCT = HOME / "codex-security-harness-v0.1.2"
OUTPUT_ROOT = ROOT / "scheduler-sim" / "generated"
FIELDS = (
    "total_input_tokens",
    "noncached_input_tokens",
    "output_tokens",
    "reasoning_tokens",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def iso_seconds(start: str | None, end: str | None) -> float | None:
    if not start or not end:
        return None
    left = dt.datetime.fromisoformat(start.replace("Z", "+00:00"))
    right = dt.datetime.fromisoformat(end.replace("Z", "+00:00"))
    return round(max(0.0, (right - left).total_seconds()), 6)


def normalized_tokens(value: dict[str, Any]) -> dict[str, int]:
    return {field: int(value.get(field, 0) or 0) for field in FIELDS}


def estimator() -> Any:
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(V012_PRODUCT / "src"))
    from bbp_harness.reservations import BoundedReservationEstimator

    return BoundedReservationEstimator()


def ledger_lookup(run_dir: Path) -> tuple[dict[str, Any], dict[str, int]]:
    path = run_dir / "control" / "budget_ledger.json"
    ledger = load_json(path)
    order = {
        str(item.get("invocation_id")): index
        for index, item in enumerate(ledger.get("invocations", []), start=1)
    }
    records = {
        str(item.get("invocation_id")): item for item in ledger.get("invocations", [])
    }
    return records, order


def last_machine_progress_gap(
    run_dir: Path,
    invocation_id: str,
    started_at: str | None,
    ended_at: str | None,
) -> float | None:
    """Time from the last machine-observable worker event to worker end."""
    if not started_at or not ended_at:
        return None
    lifecycle = run_dir / "telemetry" / "lifecycle.jsonl"
    if not lifecycle.is_file():
        return None
    progress_times: list[str] = []
    for line in lifecycle.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if invocation_id not in str(event.get("command_id", "")):
            continue
        if event.get("event_type") not in {
            "TOOL_COMMAND_COMPLETED",
            "BUILD_COMPLETED",
            "TEST_COMPLETED",
            "STRUCTURED_WORKER_OUTPUT",
            "ARTIFACT_DIGEST_CHANGED",
        }:
            continue
        if event.get("timestamp"):
            progress_times.append(str(event["timestamp"]))
    anchor = max(progress_times) if progress_times else started_at
    return iso_seconds(anchor, ended_at)


def v011_rows(base_estimator: Any) -> list[dict[str, Any]]:
    raw = [
        json.loads(line)
        for line in V011_DATASET.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    rows: list[dict[str, Any]] = []
    ledgers: dict[str, tuple[dict[str, Any], dict[str, int]]] = {}
    for source in raw:
        if source.get("system") != "harness-v0.1.1":
            continue
        run_dir = Path(source["run_dir"]).resolve()
        key = str(run_dir)
        if key not in ledgers:
            ledgers[key] = ledger_lookup(run_dir)
        records, order = ledgers[key]
        invocation_id = str(source["invocation_id"])
        ledger_row = records.get(invocation_id, {})
        context = source.get("context", {})
        estimate = base_estimator.estimate(
            role=str(source["worker_role"]),
            prompt_bytes=int(context.get("prompt_bytes", 0) or 0),
            retrieved_document_count=int(context.get("retrieved_document_count", 0) or 0),
            upstream_evidence_bytes=int(context.get("upstream_evidence_bytes", 0) or 0),
        )
        rows.append(
            {
                "schema_version": 1,
                "source_version": "0.1.1",
                "source_phase": str(source["source_phase"]),
                "episode_id": f"{source['source_phase']}:{run_dir.parent.parent.name}:{run_dir.name}",
                "run_dir": str(run_dir),
                "invocation_id": invocation_id,
                "sequence_index": int(order.get(invocation_id, 0)),
                "role": str(source["worker_role"]),
                "context": {
                    "prompt_bytes": int(context.get("prompt_bytes", 0) or 0),
                    "retrieved_document_count": int(
                        context.get("retrieved_document_count", 0) or 0
                    ),
                    "upstream_evidence_bytes": int(
                        context.get("upstream_evidence_bytes", 0) or 0
                    ),
                },
                "original_reservation": normalized_tokens(source.get("reservation", {})),
                "v012_base_reservation": normalized_tokens(estimate.request),
                "actual": normalized_tokens(source.get("actual", {})),
                "started_at": ledger_row.get("started_at"),
                "ended_at": ledger_row.get("ended_at"),
                "duration_seconds": iso_seconds(
                    ledger_row.get("started_at"), ledger_row.get("ended_at")
                ),
                "last_machine_progress_gap_seconds": last_machine_progress_gap(
                    run_dir,
                    invocation_id,
                    ledger_row.get("started_at"),
                    ledger_row.get("ended_at"),
                ),
                "exit_reason": str(source.get("exit_reason", "")),
            }
        )
    return rows


def v012_rows() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    grade_by_run: dict[str, dict[str, Any]] = {}
    for path in V012_ROOT.glob("grades/*.json"):
        grade = load_json(path)
        grade_by_run[str(Path(grade["run_dir"]).resolve())] = grade
    rows: list[dict[str, Any]] = []
    episodes: list[dict[str, Any]] = []
    for ledger_path in sorted(
        V012_ROOT.glob("runs/trial-*/*harness-v0.1.2/control/budget_ledger.json")
    ):
        run_dir = ledger_path.parents[1].resolve()
        episode_id = f"{run_dir.parent.name}:{run_dir.name}"
        ledger = load_json(ledger_path)
        reservations = {
            str(item.get("invocation_id")): item
            for item in ledger.get("reservations", [])
        }
        grade = grade_by_run.get(str(run_dir), {})
        output = load_json(run_dir / "output.json")
        role_counts: Counter[str] = Counter()
        for index, source in enumerate(ledger.get("invocations", []), start=1):
            invocation_id = str(source.get("invocation_id"))
            reservation = reservations.get(invocation_id, {})
            context = reservation.get("estimator", {}).get("observed_context", {})
            role = str(source.get("role", source.get("worker", "unknown")))
            role_counts[role] += 1
            rows.append(
                {
                    "schema_version": 1,
                    "source_version": "0.1.2-rc1",
                    "source_phase": "RC1_ACCEPTANCE",
                    "episode_id": episode_id,
                    "run_dir": str(run_dir),
                    "invocation_id": invocation_id,
                    "sequence_index": index,
                    "role": role,
                    "context": {
                        "prompt_bytes": int(context.get("prompt_bytes", 0) or 0),
                        "retrieved_document_count": int(
                            context.get("retrieved_document_count", 0) or 0
                        ),
                        "upstream_evidence_bytes": int(
                            context.get("upstream_evidence_bytes", 0) or 0
                        ),
                    },
                    "original_reservation": normalized_tokens(
                        source.get("reservation", {})
                    ),
                    "v012_base_reservation": normalized_tokens(
                        source.get("reservation", {})
                    ),
                    "actual": normalized_tokens(source.get("usage", {})),
                    "started_at": source.get("started_at"),
                    "ended_at": source.get("ended_at"),
                    "duration_seconds": iso_seconds(
                        source.get("started_at"), source.get("ended_at")
                    ),
                    "last_machine_progress_gap_seconds": last_machine_progress_gap(
                        run_dir,
                        invocation_id,
                        source.get("started_at"),
                        source.get("ended_at"),
                    ),
                    "exit_reason": str(source.get("exit_reason", "")),
                }
            )
        candidates = output.get("candidates", []) if isinstance(output, dict) else []
        experiments = output.get("experiments", []) if isinstance(output, dict) else []
        campaigns = output.get("campaigns", []) if isinstance(output, dict) else []
        episodes.append(
            {
                "schema_version": 1,
                "source_version": "0.1.2-rc1",
                "episode_id": episode_id,
                "run_dir": str(run_dir),
                "protocol_status": grade.get("protocol_status"),
                "complete_research_episode": bool(
                    grade.get("complete_research_episode", False)
                ),
                "candidate_count": len(candidates),
                "experiment_count": len(experiments),
                "role_counts": dict(sorted(role_counts.items())),
                "terminal_verdict": (
                    campaigns[-1].get("terminal_verdict") if campaigns else None
                ),
                "last_progress_gap_seconds": grade.get("milestones", {}).get(
                    "last_progress_before_termination_seconds"
                ),
            }
        )
    return rows, episodes


def main() -> int:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    base_estimator = estimator()
    old_rows = v011_rows(base_estimator)
    new_rows, episodes = v012_rows()
    rows = sorted(
        old_rows + new_rows,
        key=lambda item: (
            item["source_version"],
            item["source_phase"],
            item["episode_id"],
            item["sequence_index"],
            item["invocation_id"],
        ),
    )
    invocation_path = OUTPUT_ROOT / "historical_invocations.jsonl"
    episode_path = OUTPUT_ROOT / "historical_episodes.json"
    invocation_path.write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in rows),
        encoding="utf-8",
    )
    episode_path.write_text(
        json.dumps(episodes, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    source_path = V012_PRODUCT / "src" / "bbp_harness" / "reservations.py"
    manifest = {
        "schema_version": 1,
        "classification": "DEVELOPMENT_ONLY_NO_MODEL_INVOCATION",
        "inputs": {
            "v0.1.1_invocations": {
                "path": str(V011_DATASET),
                "sha256": sha256_file(V011_DATASET),
            },
            "v0.1.2_schedule": {
                "path": str(V012_ROOT / "schedule.json"),
                "sha256": sha256_file(V012_ROOT / "schedule.json"),
            },
            "v0.1.2_execution_complete": {
                "path": str(V012_ROOT / "EXECUTION_COMPLETE.json"),
                "sha256": sha256_file(V012_ROOT / "EXECUTION_COMPLETE.json"),
            },
            "v0.1.2_estimator_source": {
                "path": str(source_path),
                "sha256": sha256_file(source_path),
            },
        },
        "outputs": {
            "historical_invocations": {
                "path": str(invocation_path),
                "sha256": sha256_file(invocation_path),
                "rows": len(rows),
            },
            "historical_episodes": {
                "path": str(episode_path),
                "sha256": sha256_file(episode_path),
                "rows": len(episodes),
            },
        },
        "counts": {
            "v0.1.1_invocations": len(old_rows),
            "v0.1.2_invocations": len(new_rows),
            "combined_invocations": len(rows),
            "roles": dict(sorted(Counter(row["role"] for row in rows).items())),
        },
        "fresh_holdout_used": False,
        "security_correctness_scored": False,
        "model_invocations": 0,
    }
    manifest_path = OUTPUT_ROOT / "DATASET_MANIFEST.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0 if len(rows) == 279 and len(episodes) == 15 else 1


if __name__ == "__main__":
    raise SystemExit(main())
