# V0.1.3 offline scheduler simulator

This directory is development-only engineering qualification. It does not call
Codex, use a fresh holdout, or score security correctness.

The simulator combines the immutable V0.1.1 overshoot-characterization corpus
with the immutable V0.1.2 RC1 acceptance ledgers. It is intentionally separate
from the product tree. A candidate policy can be rejected here, but a replay
pass is not release acceptance.

Commands:

```sh
python scheduler-sim/build_dataset.py
python scheduler-sim/simulate.py \
  --policy scheduler-sim/policies/v0.1.3-candidate-a.json
python -m unittest tests.test_scheduler_sim
```

Generated artifacts are written below `scheduler-sim/generated/`. The manifest
contains input and output SHA-256 digests. The source artifacts remain
untouched.

