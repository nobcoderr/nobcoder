#!/usr/bin/env python3
"""Replay exploratory V0.1.3 execution-control policies without model calls."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
GENERATED = ROOT / "scheduler-sim" / "generated"
FIELDS = (
    "total_input_tokens",
    "noncached_input_tokens",
    "output_tokens",
    "reasoning_tokens",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ratio(left: float, right: float) -> float | None:
    return round(left / right, 6) if right else None


def nearest_rank(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    return round(values[max(0, math.ceil(quantile * len(values)) - 1)], 6)


def condition_matches(rule: dict[str, Any], row: dict[str, Any]) -> bool:
    if rule.get("role") != row["role"]:
        return False
    prompt = int(row.get("context", {}).get("prompt_bytes", 0) or 0)
    when = rule.get("when", {})
    if "prompt_bytes_lt" in when and not prompt < int(when["prompt_bytes_lt"]):
        return False
    if "prompt_bytes_gte" in when and not prompt >= int(when["prompt_bytes_gte"]):
        return False
    return True


def request_for(policy: dict[str, Any], row: dict[str, Any]) -> dict[str, int]:
    request = dict(row["v012_base_reservation"])
    for rule in policy.get("reservation_overrides", []):
        if condition_matches(rule, row):
            request.update({key: int(value) for key, value in rule.get("set", {}).items()})
    return {field: int(request[field]) for field in FIELDS}


def metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    requested = {field: sum(row["simulated_request"][field] for row in rows) for field in FIELDS}
    actual = {field: sum(row["actual"][field] for row in rows) for field in FIELDS}
    utilizations = [
        row["actual"]["total_input_tokens"]
        / row["simulated_request"]["total_input_tokens"]
        for row in rows
        if row["simulated_request"]["total_input_tokens"] > 0
    ]
    overshoots = [
        {
            "source_version": row["source_version"],
            "source_phase": row["source_phase"],
            "episode_id": row["episode_id"],
            "invocation_id": row["invocation_id"],
            "role": row["role"],
            "dimension": field,
            "requested": row["simulated_request"][field],
            "actual": row["actual"][field],
        }
        for row in rows
        for field in FIELDS
        if row["actual"][field] > row["simulated_request"][field]
    ]
    return {
        "invocations": len(rows),
        "requested": requested,
        "actual": actual,
        "total_requested_to_actual_ratio": ratio(
            requested["total_input_tokens"], actual["total_input_tokens"]
        ),
        "total_unused_reservation_fraction": ratio(
            requested["total_input_tokens"] - actual["total_input_tokens"],
            requested["total_input_tokens"],
        ),
        "total_utilization": {
            "p50": round(statistics.median(utilizations), 6) if utilizations else None,
            "p95": nearest_rank(utilizations, 0.95),
            "maximum": round(max(utilizations), 6) if utilizations else None,
        },
        "overshooting_invocations": len(
            {value["episode_id"] + ":" + value["invocation_id"] for value in overshoots}
        ),
        "overshoot_events": overshoots,
    }


def evaluate_metrics(
    value: dict[str, Any], gates: dict[str, Any], *, enforce_role: bool
) -> list[str]:
    failures: list[str] = []
    if value["overshooting_invocations"] > int(
        gates["maximum_predicted_overshooting_invocations"]
    ):
        failures.append("predicted_overshoot")
    if (value["total_requested_to_actual_ratio"] or float("inf")) > float(
        gates[
            "maximum_role_requested_to_actual_ratio_when_n_gte_10"
            if enforce_role
            else "maximum_total_requested_to_actual_ratio"
        ]
    ):
        failures.append("requested_to_actual_ratio")
    if (value["total_unused_reservation_fraction"] or float("inf")) > float(
        gates[
            "maximum_role_unused_fraction_when_n_gte_10"
            if enforce_role
            else "maximum_total_unused_reservation_fraction"
        ]
    ):
        failures.append("unused_reservation_fraction")
    if enforce_role and (value["total_utilization"]["p50"] or 0) < float(
        gates["minimum_role_p50_utilization_when_n_gte_10"]
    ):
        failures.append("p50_utilization")
    return failures


def workflow_replay(
    episodes: list[dict[str, Any]],
    invocation_rows: list[dict[str, Any]],
    policy: dict[str, Any],
) -> dict[str, Any]:
    config = policy["workflow_governance"]
    available = int(config["max_invocations"]) - int(config["fixed_research_slots"])
    bundle = int(config["candidate_bundle_slots"])
    bundle_capacity = max(0, available // bundle)
    cold_judge = policy["cold_start"]["evidence_judge"]["reservation"]
    requests_by_role: dict[str, dict[str, int]] = {}
    for role in ("reproducer", "skeptic", "prior_art"):
        role_rows = [row for row in invocation_rows if row["role"] == role]
        requests_by_role[role] = {
            field: max((row["simulated_request"][field] for row in role_rows), default=0)
            for field in FIELDS
        }
    requests_by_role["evidence_judge"] = {
        field: int(cold_judge[field]) for field in FIELDS
    }
    bundle_request = {
        field: sum(requests_by_role[role][field] for role in config["bundle_roles"])
        for field in FIELDS
    }
    run_limits = {field: int(config["run_limits"][field]) for field in FIELDS}
    rows = []
    for episode in episodes:
        candidates = int(episode["candidate_count"])
        invocation_admitted = min(candidates, bundle_capacity)
        episode_rows = [
            row for row in invocation_rows if row["episode_id"] == episode["episode_id"]
        ]
        research_rows = [
            row for row in episode_rows if row["role"] in {"mapper", "researcher"}
        ]
        research_used = {
            field: sum(row["actual"][field] for row in research_rows) for field in FIELDS
        }
        resource_bundle_capacity = min(
            max(0, (run_limits[field] - research_used[field]) // bundle_request[field])
            if bundle_request[field]
            else bundle_capacity
            for field in FIELDS
        )
        full_bundle_admitted = min(
            invocation_admitted, max(0, int(resource_bundle_capacity))
        )
        deferred = max(0, candidates - full_bundle_admitted)
        capacity_reserved = full_bundle_admitted * bundle
        rows.append(
            {
                "episode_id": episode["episode_id"],
                "candidates_observed": candidates,
                "candidates_with_invocation_capacity": invocation_admitted,
                "candidates_with_full_bundle_capacity": full_bundle_admitted,
                "hypotheses_deferred_capacity": deferred,
                "research_slots": int(config["fixed_research_slots"]),
                "research_actual_usage": research_used,
                "resource_bundle_capacity": int(resource_bundle_capacity),
                "verification_slots_reserved": capacity_reserved,
                "simulated_invocations_if_all_admitted_reach_judge": (
                    int(config["fixed_research_slots"]) + capacity_reserved
                ),
                "verification_starvation_if_invocation_only_admission": (
                    invocation_admitted - full_bundle_admitted
                ),
            }
        )
    invocation_admitted = sum(row["candidates_with_invocation_capacity"] for row in rows)
    resource_admitted = sum(row["candidates_with_full_bundle_capacity"] for row in rows)
    return {
        "bundle_capacity_per_episode": bundle_capacity,
        "bundle_reservation_by_role": requests_by_role,
        "bundle_reservation_total": bundle_request,
        "episodes": rows,
        "candidates_observed": sum(row["candidates_observed"] for row in rows),
        "candidates_with_invocation_capacity": invocation_admitted,
        "candidates_with_full_bundle_capacity": resource_admitted,
        "hypotheses_deferred_capacity": sum(
            row["hypotheses_deferred_capacity"] for row in rows
        ),
        "verification_starvation_if_invocation_only_admission": sum(
            row["verification_starvation_if_invocation_only_admission"] for row in rows
        ),
        "invocation_terminal_path_capacity_fraction": 1.0,
        "resource_terminal_path_capacity_fraction": ratio(
            resource_admitted, invocation_admitted
        ),
        "limitation": (
            "Structural invocation-capacity replay only; worker results and Evidence Judge "
            "token use are not synthesized."
        ),
    }


def convergence_replay(
    rows: list[dict[str, Any]], policy: dict[str, Any]
) -> dict[str, Any]:
    config = policy["convergence"]
    role = str(config["role"])
    threshold = float(config["candidate_no_progress_seconds"])
    selected = [
        row
        for row in rows
        if row["role"] == role
        and row.get("last_machine_progress_gap_seconds") is not None
    ]
    healthy = [row for row in selected if row["exit_reason"] == "NORMAL_COMPLETION"]
    timed_out = [row for row in selected if "TIMEOUT" in row["exit_reason"]]
    false_terminations = [
        row for row in healthy if float(row["last_machine_progress_gap_seconds"]) >= threshold
    ]
    detected_timeouts = [
        row for row in timed_out if float(row["last_machine_progress_gap_seconds"]) >= threshold
    ]
    healthy_gaps = [float(row["last_machine_progress_gap_seconds"]) for row in healthy]
    return {
        "role": role,
        "threshold_seconds": threshold,
        "samples": len(selected),
        "healthy_samples": len(healthy),
        "timeout_samples": len(timed_out),
        "healthy_gap_seconds": {
            "p50": round(statistics.median(healthy_gaps), 6) if healthy_gaps else None,
            "p95": nearest_rank(healthy_gaps, 0.95),
            "maximum": round(max(healthy_gaps), 6) if healthy_gaps else None,
        },
        "timeout_gap_seconds": [
            round(float(row["last_machine_progress_gap_seconds"]), 6)
            for row in timed_out
        ],
        "false_termination_count": len(false_terminations),
        "detected_timeout_count": len(detected_timeouts),
        "status": (
            "PASS"
            if len(healthy) >= 20
            and not false_terminations
            and timed_out
            and len(detected_timeouts) == len(timed_out)
            else "FAIL"
        ),
    }


def simulate(policy_path: Path) -> dict[str, Any]:
    policy = json.loads(policy_path.read_text(encoding="utf-8"))
    invocation_path = GENERATED / "historical_invocations.jsonl"
    episode_path = GENERATED / "historical_episodes.json"
    manifest_path = GENERATED / "DATASET_MANIFEST.json"
    rows = [
        json.loads(line)
        for line in invocation_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    episodes = json.loads(episode_path.read_text(encoding="utf-8"))
    for row in rows:
        row["simulated_request"] = request_for(policy, row)
    overall = metrics(rows)
    by_role = {
        role: metrics([row for row in rows if row["role"] == role])
        for role in sorted({row["role"] for row in rows})
    }
    by_phase = {
        phase: metrics([row for row in rows if row["source_phase"] == phase])
        for phase in sorted({row["source_phase"] for row in rows})
    }
    gates = policy["offline_gates"]
    failures = evaluate_metrics(overall, gates, enforce_role=False)
    role_failures: dict[str, list[str]] = {}
    for role, value in by_role.items():
        if value["invocations"] < 10:
            continue
        current = evaluate_metrics(value, gates, enforce_role=True)
        if current:
            role_failures[role] = current
    workflow = workflow_replay(episodes, rows, policy)
    if (workflow["invocation_terminal_path_capacity_fraction"] or 0) < float(
        gates["required_terminal_path_capacity_fraction"]
    ):
        failures.append("terminal_path_capacity")
    data_gaps = []
    if by_role.get("evidence_judge", {}).get("invocations", 0) == 0:
        data_gaps.append(
            {
                "code": "NO_EVIDENCE_JUDGE_TOKEN_SAMPLE",
                "effect": "cold-start reservation cannot be validated for tail safety or efficiency offline",
            }
        )
    if (workflow["resource_terminal_path_capacity_fraction"] or 0) < float(
        gates["required_terminal_path_capacity_fraction"]
    ):
        data_gaps.append(
            {
                "code": "RESOURCE_CLOSURE_NOT_PROVEN",
                "effect": (
                    "invocation slots can be preserved, but the frozen run envelope cannot "
                    "guarantee the cold-start full verification bundle for every otherwise-admitted candidate"
                ),
            }
        )
    convergence = convergence_replay(rows, policy)
    if convergence["status"] != "PASS":
        data_gaps.append(
            {
                "code": "MAPPER_STALL_THRESHOLD_NOT_VALIDATED",
                "effect": "candidate threshold may terminate healthy long-tail finalization",
            }
        )
    replay_status = "PASS" if not failures and not role_failures else "FAIL"
    contract_status = "BLOCKED_DATA_GAPS" if replay_status == "PASS" and data_gaps else replay_status
    return {
        "schema_version": 1,
        "simulation_id": "v0.1.3-offline-scheduler-replay-v1",
        "classification": "DEVELOPMENT_ONLY_NO_MODEL_INVOCATION",
        "policy": {
            "path": str(policy_path.resolve()),
            "sha256": sha256_file(policy_path),
            "policy_id": policy["policy_id"],
            "status": policy["status"],
        },
        "dataset": {
            "manifest_path": str(manifest_path),
            "manifest_sha256": sha256_file(manifest_path),
            "invocations_path": str(invocation_path),
            "invocations_sha256": sha256_file(invocation_path),
            "episodes_path": str(episode_path),
            "episodes_sha256": sha256_file(episode_path),
        },
        "overall": overall,
        "by_role": by_role,
        "by_phase": by_phase,
        "workflow_capacity": workflow,
        "convergence": convergence,
        "gate_failures": failures,
        "role_gate_failures": role_failures,
        "offline_replay_status": replay_status,
        "contract_freeze_status": contract_status,
        "blocking_data_gaps": data_gaps,
        "model_invocations": 0,
        "fresh_holdout_used": False,
        "security_correctness_scored": False,
        "implementation_authorized": False,
        "claim": "INSUFFICIENT_DATA",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--policy", type=Path, required=True)
    parser.add_argument(
        "--output", type=Path, default=GENERATED / "v0.1.3-candidate-a-result.json"
    )
    args = parser.parse_args()
    result = simulate(args.policy.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["offline_replay_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
