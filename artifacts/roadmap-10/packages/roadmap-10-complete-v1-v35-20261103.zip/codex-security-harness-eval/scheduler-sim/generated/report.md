# V0.1.3 contract-first offline replay

The role-aware tail candidate passes the historical replay, but the complete
V0.1.3 contract is not ready to freeze. No product code, prompt, skill, corpus,
model configuration, fresh holdout, or security decision logic was changed.

## Tail replay

| Metric | Result |
|---|---:|
| Historical invocations | 279 |
| Predicted overshooting invocations | 0 |
| Total requested / actual | 2.425108× |
| Unused total-input reservation | 58.7647% |
| Per-role efficiency gates | PASS |

The replayed policy keeps role-specific sizing. It does not restore a uniform
large reservation. The Evidence Judge is excluded from the measured-role pass
because the historical corpus contains zero Judge invocations.

## Workflow capacity

The frozen 16-invocation envelope can structurally retain four initial research
slots and three four-role candidate bundles. That makes invocation capacity
available for every role in each admitted bundle.

Resource capacity does not support the same conclusion. With conservative
historical maxima plus the cold-start Judge allowance, one full bundle requests
1,050,000 total-input, 170,000 noncached-input, 36,000 output, and 21,700
reasoning tokens. Across the 15 RC1 development episodes, 33 candidate paths
had invocation slots but only 8 had full resource-bundle capacity after the
observed mapper/researcher usage. The resource closure fraction is 8/33
(0.242424).

Therefore `invocation slots reserved` must not be reported as `verification
capacity guaranteed`.

## Mapper convergence

The already-existing 120-second no-progress threshold cleanly separates the
available mapper sample:

| Mapper sample | Count/result |
|---|---:|
| Healthy completions | 29 |
| Healthy P95 no-progress gap | 98.643307 s |
| Healthy maximum gap | 106.230569 s |
| Timeout samples | 1 |
| Timeout no-progress gap | 170.645225 s |
| Healthy false terminations at 120 s | 0 |
| Timeouts detected at 120 s | 1 |

Only machine-observable events reset the clock. Free-form reasoning text or
token activity does not count as meaningful progress.

## Decision

`CONTRACT_FREEZE_BLOCKED_DATA_GAPS`

The next permitted step is a separately precommitted, development-only Evidence
Judge capacity characterization with unchanged intelligence. After that, rerun
the full-bundle resource replay. V0.1.3 implementation, packaging, a fresh
holdout, and Pilot V3 remain blocked.

