from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from analyze_irac_v2_official_r4 import analyze_rows  # noqa: E402


def row(sample: str, signature: str, total: int, *, identity: str | None = None, component: str | None = None) -> dict:
    identity = identity or signature
    component = component or signature
    return {
        "sample_id": sample,
        "raw_request_sha256": identity + "-raw",
        "canonical_request_sha256": identity + "-canonical",
        "content_component_signature_sha256": signature,
        "model_configuration_sha256": identity + "-model",
        "instructions_sha256": component + "-instructions",
        "input_messages_sha256": component + "-messages",
        "selected_output_schema_sha256": "fixed-schema",
        "tools_sha256": "fixed-tools",
        "apps_tool_context_sha256": "fixed-apps",
        "runtime_generated_fields_sha256": "fixed-runtime",
        "other_content_bearing_fields_sha256": "fixed-other",
        "reported_total_input": total,
    }


def test_semantic_context_drift_outcome() -> None:
    rows = [row("A1", "A", 100), row("A2", "A", 100), row("B1", "B", 200), row("B2", "B", 200)]
    result = analyze_rows(rows)
    assert result["outcome"] == "PRE_INVOCATION_CONTEXT_DRIFT_ESTABLISHED"
    assert result["context_drift_evidence"] is True
    assert result["accounting_variation_evidence"] is False


def test_accounting_variation_outcome() -> None:
    rows = [row("A1", "A", 100, identity="same"), row("A2", "A", 200, identity="same")]
    result = analyze_rows(rows)
    assert result["outcome"] == "MEASUREMENT_ACCOUNTING_VARIATION_ESTABLISHED"
    assert result["context_drift_evidence"] is False
    assert result["accounting_variation_evidence"] is True


def test_mixed_outcome() -> None:
    rows = [
        row("A1", "A", 100), row("A2", "A", 100),
        row("B1", "B", 200), row("B2", "B", 200),
        row("C1", "C", 300, identity="same-c"), row("C2", "C", 301, identity="same-c"),
    ]
    result = analyze_rows(rows)
    assert result["outcome"] == "MIXED"
    assert result["context_drift_evidence"] is True
    assert result["accounting_variation_evidence"] is True


def test_unresolved_without_predicates() -> None:
    result = analyze_rows([row("A1", "A", 100)])
    assert result["outcome"] == "UNRESOLVED"


def test_visibility_failure_forces_unresolved() -> None:
    rows = [row("A1", "A", 100, identity="same"), row("A2", "A", 200, identity="same")]
    result = analyze_rows(rows, visibility_complete=False)
    assert result["accounting_variation_evidence"] is True
    assert result["outcome"] == "UNRESOLVED"
