from __future__ import annotations

import json
import os
import stat
import sys
import tempfile
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_finalization_r1 import complete_cleanup, finalize_observation, initialize_journal  # noqa: E402
from irac_v2_readiness_lifecycle import directory_content_digest, write_json_atomic  # noqa: E402
from raw_lock_gate_v2 import apply_gate, verify_gate  # noqa: E402


def _writable(path: Path) -> None:
    if not path.exists():
        return
    for member in [path, *sorted(path.rglob("*"))]:
        if member.exists() and not member.is_symlink():
            member.chmod(stat.S_IMODE(member.stat().st_mode) | stat.S_IWUSR | (stat.S_IXUSR if member.is_dir() else 0))


def _build_execution(
    root: Path,
    *,
    expected: int = 54,
    invalid_position: int | None = None,
    provider_error: str | None = None,
    attempts: int = 1,
    replacement: bool = False,
) -> Path:
    schedule = root / "schedule.json"
    entries = [{"position": position, "sample_id": f"SAMPLE-{position:03d}"} for position in range(1, expected + 1)]
    write_json_atomic(schedule, {"schema_version": 1, "entries": entries})
    for directory in ("active", "observations", "finalization", "position-status"):
        (root / directory).mkdir(parents=True, exist_ok=True)
    ledger = root / "ATTEMPT_LEDGER.jsonl"
    ledger_rows = []
    for entry in entries:
        position = entry["position"]
        sample_id = entry["sample_id"]
        for attempt in range(1, attempts + 1 if position == invalid_position else 2):
            ledger_rows.append({"position": position, "sample_id": sample_id, "attempt_number": attempt, "replacement": replacement and position == invalid_position})
        staging = root / "active" / sample_id
        canonical = root / "observations" / sample_id
        journal = root / "finalization" / sample_id / "FINALIZATION_JOURNAL.json"
        capsule = root / "capsules" / sample_id
        immutable = capsule / "immutable" / "snapshot"
        immutable.mkdir(parents=True)
        write_json_atomic(immutable / "fixture.json", {"sample_id": sample_id})
        (capsule / "runtime").mkdir()
        (capsule / "worker_runs").mkdir()
        immutable_digest = directory_content_digest(immutable)
        staging.mkdir(parents=True)
        terminal = "INVALID_CAPTURE" if position == invalid_position else "VALID_COMPLETED"
        provider = provider_error if position == invalid_position and provider_error else "ACCEPTED"
        observation = {"schema_version": 1, "schedule_position": position, "sample_id": sample_id, "terminal_status": terminal}
        write_json_atomic(staging / "observation.json", observation)
        initialize_journal(journal, invocation_id=sample_id, schedule_position=position, staging=staging, canonical=canonical, capsule=capsule)
        finalize_observation(
            staging=staging,
            canonical=canonical,
            journal_path=journal,
            invocation_lock_fields={
                "invocation_id": sample_id,
                "schedule_position": position,
                "fixture_digest": "0" * 64,
                "runtime_digest": "1" * 64,
                "product_digest": "2" * 64,
                "capture_digest": "3" * 64,
                "classifier_digest": "4" * 64,
                "raw_request_digest": "5" * 64,
                "canonical_request_digest": "6" * 64,
                "terminal_status": terminal,
            },
            validator=lambda path: json.loads((path / "observation.json").read_text()),
        )
        complete_cleanup(
            canonical=canonical,
            journal_path=journal,
            capsule=capsule,
            immutable_snapshot=immutable,
            expected_immutable_digest=immutable_digest,
            cleanup_journal_path=journal.parent / "CLEANUP_JOURNAL.json",
        )
        write_json_atomic(root / "position-status" / f"POSITION-{position:03d}.json", {
            "position": position,
            "sample_id": sample_id,
            "scientific_provider_outcome": provider,
            "scientific_terminal_status": terminal,
            "position_valid": terminal == "VALID_COMPLETED" and provider == "ACCEPTED",
        })
    ledger.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in ledger_rows), encoding="utf-8")
    write_json_atomic(root / "EXECUTION_MANIFEST.json", {"complete": True, "analysis_authorized": True})
    return schedule


@pytest.fixture
def execution_root():
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        yield root
        _writable(root)


def _assert_incomplete(result: dict) -> None:
    assert result["lock"]["analysis_authorized"] is False
    assert result["lock"]["never_analyze"] is True
    assert Path(result["lock_path"]).name == "MEASUREMENT_INCOMPLETE_LOCK.json"
    assert not Path(result["lock_path"]).with_name("RAW_EXECUTION_LOCK.json").exists()


def test_54_of_54_emits_only_analyzable_raw_lock(execution_root: Path):
    schedule = _build_execution(execution_root)
    result = apply_gate(execution_root, schedule)
    assert result["lock"]["analysis_authorized"] is True
    assert Path(result["lock_path"]).name == "RAW_EXECUTION_LOCK.json"
    assert not execution_root.joinpath("MEASUREMENT_INCOMPLETE_LOCK.json").exists()
    assert verify_gate(execution_root, schedule)["status"] == "PASS"


@pytest.mark.parametrize("provider", ["MODEL_CAPACITY", "TRANSIENT_SERVER_ERROR"])
def test_provider_rejection_emits_only_incomplete_lock(execution_root: Path, provider: str):
    schedule = _build_execution(execution_root, invalid_position=17, provider_error=provider)
    _assert_incomplete(apply_gate(execution_root, schedule))


def test_53_of_54_valid_emits_incomplete(execution_root: Path):
    schedule = _build_execution(execution_root, invalid_position=54)
    _assert_incomplete(apply_gate(execution_root, schedule))


def test_retry_detected(execution_root: Path):
    schedule = _build_execution(execution_root, invalid_position=11, attempts=2)
    result = apply_gate(execution_root, schedule)
    _assert_incomplete(result)
    assert "RETRY_DETECTED" in result["lock"]["failure_codes"]


def test_replacement_detected(execution_root: Path):
    schedule = _build_execution(execution_root, invalid_position=11, replacement=True)
    result = apply_gate(execution_root, schedule)
    _assert_incomplete(result)
    assert "REPLACEMENT_DETECTED" in result["lock"]["failure_codes"]


def test_missing_observation(execution_root: Path):
    schedule = _build_execution(execution_root)
    missing = execution_root / "observations" / "SAMPLE-009"
    _writable(missing)
    for member in sorted(missing.rglob("*"), reverse=True):
        if member.is_file():
            member.unlink()
        elif member.is_dir():
            member.rmdir()
    missing.rmdir()
    _assert_incomplete(apply_gate(execution_root, schedule))


def test_duplicate_or_extra_observation(execution_root: Path):
    schedule = _build_execution(execution_root)
    extra = execution_root / "observations" / "SAMPLE-EXTRA"
    extra.mkdir()
    write_json_atomic(extra / "observation.json", {"sample_id": "SAMPLE-001", "schedule_position": 1, "terminal_status": "VALID_COMPLETED"})
    _assert_incomplete(apply_gate(execution_root, schedule))


def test_missing_finalization(execution_root: Path):
    schedule = _build_execution(execution_root)
    journal = execution_root / "finalization" / "SAMPLE-013" / "FINALIZATION_JOURNAL.json"
    journal.unlink()
    _assert_incomplete(apply_gate(execution_root, schedule))


def test_schedule_mismatch(execution_root: Path):
    schedule = _build_execution(execution_root)
    status = execution_root / "position-status" / "POSITION-021.json"
    value = json.loads(status.read_text())
    value["sample_id"] = "WRONG"
    write_json_atomic(status, value)
    _assert_incomplete(apply_gate(execution_root, schedule))


def test_artifact_mutation_fails_closed(execution_root: Path):
    schedule = _build_execution(execution_root)
    observation = execution_root / "observations" / "SAMPLE-031" / "observation.json"
    observation.chmod(0o644)
    observation.write_text(observation.read_text() + " ", encoding="utf-8")
    result = apply_gate(execution_root, schedule)
    _assert_incomplete(result)
    assert any(code.startswith("FINALIZATION_VERIFICATION") for code in result["lock"]["failure_codes"])


def test_runner_complete_claim_is_not_trusted(execution_root: Path):
    schedule = _build_execution(execution_root, invalid_position=7, provider_error="MODEL_CAPACITY")
    result = apply_gate(execution_root, schedule)
    _assert_incomplete(result)
    assert result["report"]["runner_claim_observed_but_not_trusted"]["complete"] is True


def test_both_lock_files_fail_verification(execution_root: Path):
    schedule = _build_execution(execution_root)
    apply_gate(execution_root, schedule)
    write_json_atomic(execution_root / "MEASUREMENT_INCOMPLETE_LOCK.json", {"analysis_authorized": False})
    assert verify_gate(execution_root, schedule)["status"] == "FAIL"
