from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_official_projection import project_request  # noqa: E402


class OfficialProjectionTests(unittest.TestCase):
    def payload(self):
        return {
            "type": "response.create",
            "model": "gpt-test",
            "reasoning": {"effort": "xhigh"},
            "instructions": "system instructions ## Apps (Connectors)",
            "input": [{"type": "message", "role": "user", "content": [{"type": "input_text", "text": "fixture"}]}],
            "text": {"format": {"type": "json_schema", "schema": {"type": "object"}}},
            "tools": [],
            "prompt_cache_key": "cache-a",
            "include": ["usage"],
        }

    def test_projection_is_deterministic_and_complete(self) -> None:
        raw = json.dumps(self.payload(), separators=(",", ":")).encode()
        first = project_request(raw)
        second = project_request(raw)
        self.assertEqual(first, second)
        self.assertEqual(len(raw), first["raw_request_byte_length"])
        self.assertEqual(
            {
                "model_configuration", "instructions", "input_messages", "output_schema", "tools",
                "apps_tool_context", "runtime_generated_fields", "other_content_bearing_fields",
            },
            set(first["component_sha256"]),
        )

    def test_each_component_change_changes_signature(self) -> None:
        baseline = self.payload()
        changes = [
            ("model", "gpt-other"),
            ("instructions", "other"),
            ("input", []),
            ("tools", [{"type": "function", "name": "x"}]),
            ("prompt_cache_key", "cache-b"),
            ("include", ["other"]),
        ]
        baseline_signature = project_request(json.dumps(baseline).encode())["content_component_signature_sha256"]
        for key, value in changes:
            candidate = dict(baseline)
            candidate[key] = value
            with self.subTest(key=key):
                self.assertNotEqual(baseline_signature, project_request(json.dumps(candidate).encode())["content_component_signature_sha256"])

    def test_non_response_create_fails(self) -> None:
        with self.assertRaises(ValueError):
            project_request(b'{"type":"session.update"}')


if __name__ == "__main__":
    unittest.main()
