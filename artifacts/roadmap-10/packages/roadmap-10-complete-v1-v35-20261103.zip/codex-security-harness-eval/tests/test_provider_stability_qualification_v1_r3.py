from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import run_provider_stability_qualification_v1_r3 as r3  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _rows(count: int, *, failed: int | None = None) -> list[dict]:
    rows = []
    for position in range(1, count + 1):
        success = position != failed
        rows.append({
            "position": position,
            "sample_id": f"IRAC2PSQR3A-{position:03d}",
            "session_id": f"session-{position:03d}" if success else None,
            "operational_classification": "ACCEPTED" if success else "PROXY_STARTUP_FAILURE",
            "provider_outcome": "ACCEPTED" if success else None,
            "capture_valid": success,
            "fixture_bound_request_count": 1 if success else 0,
            "classifier_ambiguity_count": 0,
            "payload_mutation_count": 0,
            "finalization_pass": success,
            "proxy_readiness_pass": success,
            "selftest_isolation_pass": success,
            "position_terminalized": True,
        })
    return rows


def test_r3_preserves_provider_thresholds_and_changes_only_operational_runtime():
    r2 = load(ROOT / "protocol" / "PROVIDER_STABILITY_QUALIFICATION_V1_R2.json")
    value = load(ROOT / "protocol" / "PROVIDER_STABILITY_QUALIFICATION_V1_R3.json")
    assert value["representative_probe"] == r2["representative_probe"]
    assert value["stage_a"]["scheduled_probes"] == r2["stage_a"]["scheduled_probes"] == 60
    assert value["stage_a"]["precommitted_gates"]["maximum_classified_provider_rejections"] == 1
    assert value["stage_a"]["precommitted_gates"]["minimum_uninterrupted_accepted_streak"] == 54
    assert value["stage_b"]["scheduled_probes"] == 12
    assert value["ancestry"]["scientific_components_changed"] is False
    assert value["ancestry"]["provider_thresholds_changed"] is False


def test_r3_schedules_are_fixed_unique_and_schema_compatible():
    directory = ROOT / "calibration" / "provider-stability-qualification-v1-r3"
    for name, stage, count in (("SCHEDULE_STAGE_A.json", "A", 60), ("SCHEDULE_STAGE_B.json", "B", 12)):
        schedule = load(directory / name)
        assert [row["position"] for row in schedule["entries"]] == list(range(1, count + 1))
        assert len({row["sample_id"] for row in schedule["entries"]}) == count
        assert all(row["stage"] == stage and row["sample_id"].startswith(f"IRAC2PSQR3{stage}-") for row in schedule["entries"])
        assert schedule["retry_count"] == 0
        assert schedule["replacement_count"] == 0


def test_stage_a_score_passes_only_with_all_runtime_gates():
    value = r3.score_stage_r3(_rows(60), stage="A", source_ok=True)
    assert value["status"] == "PASS_LOCKED"
    assert value["longest_uninterrupted_accepted_streak"] == 60
    assert all(value["gates"].values())


def test_one_operational_failure_fails_stage_a():
    value = r3.score_stage_r3(_rows(60, failed=20), stage="A", source_ok=True)
    assert value["status"] == "FAIL_LOCKED"
    assert value["gates"]["proxy_readiness_all"] is False
    assert value["gates"]["selftest_isolation_all"] is False
    assert value["gates"]["runtime_operational_failures_zero"] is False


def test_capture_runtime_v3_lock_is_pass_locked():
    lock = load(Path("/home/nobcoder/pilot-runs/capture-runtime-reliability-v3-20261006/CAPTURE_RUNTIME_RELIABILITY_LOCK.json"))
    assert lock["status"] == "PASS_LOCKED"
    assert lock["provider_stability_r3_authorized"] is True
    assert lock["variance_identity_creation_authorized"] is False

