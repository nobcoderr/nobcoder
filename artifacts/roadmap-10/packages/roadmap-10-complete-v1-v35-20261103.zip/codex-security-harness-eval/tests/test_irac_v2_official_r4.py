from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import irac_v2_availability_capture_core_v1 as availability_core  # noqa: E402
from irac_v2_invocation_capture_validator_v1 import validate_capture  # noqa: E402
from irac_v2_message_classifier import canonical_digest  # noqa: E402
from run_irac_v2_official_r4 import execute_preflight  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_r4_preserves_scientific_decision_tree_and_resource_envelope() -> None:
    r4 = load(ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL_R4.json")
    r3 = load(ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL_R3.json")
    assert canonical_digest(r4["decision_tree"]) == canonical_digest(r3["decision_tree"])
    assert r4["measurement_envelope"] == r3["measurement_envelope"]


def test_r4_declares_connection_count_telemetry_and_request_count_gate() -> None:
    protocol = load(ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL_R4.json")
    assert protocol["observer"]["websocket_connection_cardinality_is_scientific_validity_criterion"] is False
    assert protocol["observer"]["fixture_bound_request_cardinality_is_scientific_validity_criterion"] is True
    assert protocol["validity_gate"]["fixture_bound_response_create_per_run"] == 1


def test_r4_schedule_is_fresh_balanced_and_no_retry() -> None:
    schedule = load(ROOT / "calibration" / "initial-request-accounting-characterization-v2-official-r4" / "SCHEDULE.json")
    assert [row["position"] for row in schedule["entries"]] == list(range(1, 13))
    assert len({row["sample_id"] for row in schedule["entries"]}) == 12
    assert all(row["sample_id"].startswith("IRAC2R4-") for row in schedule["entries"])
    assert Counter(row["condition"] for row in schedule["entries"]) == Counter({
        "EMPTY_START": 4,
        "MODEL_CACHE_ONLY": 4,
        "MODEL_PLUS_APPS_CACHE": 4,
    })
    assert schedule["retry_count"] == schedule["replacement_count"] == 0


def test_r4_preflight_temporarily_uses_invocation_validator(monkeypatch, tmp_path: Path) -> None:
    original = availability_core.validate_capture
    observed = {}

    def fake(root, entry):
        observed["validator"] = availability_core.validate_capture
        return {"probe_id": entry["probe_id"]}

    monkeypatch.setattr(availability_core, "execute_probe", fake)
    result = execute_preflight(tmp_path, {"probe_id": "IRAC2ACR1-001", "position": 1})
    assert result["probe_id"] == "IRAC2ACR1-001"
    assert observed["validator"] is validate_capture
    assert availability_core.validate_capture is original
