from __future__ import annotations

import ast
import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_closure_bundle_policy_postmortem_v2.py"
SPEC = importlib.util.spec_from_file_location("closure_bundle_policy_postmortem_v2", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_v1_is_immutable_and_aborted_without_result() -> None:
    predecessor = MODULE.verify_predecessor()
    assert predecessor["status"] == "ABORTED_IMPLEMENTATION_DEFECT"
    assert predecessor["result_json_created"] is False
    assert predecessor["model_invocations"] == 0
    assert MODULE.V1.sha256_file(MODULE.V1_RUNNER) == "11af8f3f047cb7b4526522ea798eea19d6b78219de1e97ed2ed12b9b086ccdbf"


def test_v2_inherits_scientific_contract_byte_for_byte() -> None:
    v2 = MODULE.load_v2_protocol()
    inherited = v2["inherits_scientific_contract"]
    assert MODULE.V1.sha256_file(MODULE.V1.resolve(inherited["path"])) == inherited["sha256"]
    protocol = MODULE.inherited_protocol()
    assert protocol["eligible_path_contract"]["required_path_count"] == 33
    assert protocol["closure_bundle"]["noncached_input_tokens"] == 258000


def test_only_contract_listed_producer_terminal_enums_are_allowed() -> None:
    allowed = set(MODULE.load_v2_protocol()["producer_terminal_rule"]["allowed_terminal_events"])
    assert allowed == {"RESERVATION_SETTLED", "RESERVATION_OVERSHOOT_INVALID"}
    assert allowed == MODULE.V1.TERMINAL_ACTUAL_EVENTS


def test_change_boundary_keeps_product_and_capacity_policy_frozen() -> None:
    boundary = MODULE.load_v2_protocol()["change_boundary"]
    assert "Capacity V2 policy" in boundary["forbidden"]
    assert "scheduler source" in boundary["forbidden"]
    assert "V0.1.3" in boundary["forbidden"]
    assert "model invocation" in boundary["forbidden"]


def test_v2_preflight_is_offline_and_resolves_33_paths() -> None:
    value = MODULE.preflight(False)
    assert value["status"] == "PRE_EXECUTION_LOCKED"
    assert value["eligible_path_count"] == 33
    assert value["model_invocations"] == 0


def test_runner_contains_no_model_or_network_execution() -> None:
    source = MODULE_PATH.read_text(encoding="utf-8")
    tree = ast.parse(source)
    imported = {
        alias.name
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
        for alias in node.names
    }
    assert "subprocess" not in imported
    assert "requests" not in imported
    assert "websocket" not in imported

