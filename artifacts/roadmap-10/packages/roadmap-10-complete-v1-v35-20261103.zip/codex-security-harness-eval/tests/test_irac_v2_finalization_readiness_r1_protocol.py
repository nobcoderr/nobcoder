from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = ROOT / "protocol" / "IRAC_V2_OFFICIAL_FINALIZATION_READINESS_R1.json"
OFFICIAL = ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL.json"


def digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def test_protocol_freezes_exact_state_machine_and_matrix() -> None:
    value = json.loads(PROTOCOL.read_text())
    assert value["status"] == "FROZEN_PRE_SYNTHETIC_ACCEPTANCE"
    assert value["state_machine"] == [
        "STAGING", "EXECUTION_COMPLETE", "VALIDATED", "HASHED", "RENAMED_TO_CANONICAL",
        "LOCK_WRITTEN", "FSYNCED", "FROZEN_READ_ONLY", "IMMUTABILITY_VERIFIED",
        "EPHEMERAL_CLEANED", "FINALIZED",
    ]
    assert len(value["synthetic_matrix"]["cases"]) == 14
    assert value["synthetic_matrix"]["required_pass"] == "14/14"
    assert value["atomicity"]["copy_delete_fallback"] is False
    assert value["real_codex_smoke"]["retry_or_replacement"] is False


def test_decision_tree_is_hash_identical_to_failed_official_v2() -> None:
    value = json.loads(PROTOCOL.read_text())
    official = json.loads(OFFICIAL.read_text())
    assert digest(official["decision_tree"]) == value["decision_tree_sha256"]


def test_forbidden_component_hashes_match_files() -> None:
    value = json.loads(PROTOCOL.read_text())
    paths = {
        "capture_addon": ROOT / "scripts" / "irac_v2_websocket_capture.py",
        "capture_runtime": ROOT / "scripts" / "irac_v2_runtime.py",
        "classifier": ROOT / "scripts" / "irac_v2_message_classifier.py",
        "component_projection": ROOT / "scripts" / "irac_v2_official_projection.py",
        "usage_extraction": ROOT / "scripts" / "budget.py",
        "execution_environment": ROOT / "scripts" / "execution_environment.py",
        "cache_runtime": ROOT / "scripts" / "irac_runtime.py",
        "scientific_fixture": ROOT / "calibration" / "evidence-judge-variance-decomposition-v1" / "workloads" / "EJVD-REPEAT-D.json",
        "evidence_judge_schema": Path("/home/nobcoder/codex-security-harness-v0.1.2/schemas/evidence-judge-output.schema.json"),
        "evidence_judge_prompt": Path("/home/nobcoder/codex-security-harness-v0.1.2/prompts/evidence-judge.md"),
        "prompt_builder": Path("/home/nobcoder/codex-security-harness-v0.1.2/src/bbp_harness/workers.py"),
    }
    for name, path in paths.items():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == value["frozen_component_sha256"][name]
