from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from acceptance_grade_v3 import grade  # noqa: E402
from run_development_e2e_v015 import (  # noqa: E402
    _candidate_root_from_init,
    finalize_interrupted_harness,
)


def _write(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(value, str):
        path.write_text(value, encoding="utf-8")
    else:
        path.write_text(json.dumps(value), encoding="utf-8")


def _complete_plain_fixture(root: Path) -> None:
    _write(root / "output.json", {
        "status": "COMPLETE",
        "hypotheses": [{"disposition": "KILL"}],
        "candidates": [],
        "experiments": [],
    })
    _write(root / "manifest.json", {"status": "VALID_COMPLETED", "exit_code": 0})
    _write(root / "resource_compliance.json", {
        "valid_resource_compliance": True,
        "violations": [],
        "termination": {},
    })
    _write(root / "semantic_status.json", {"invalid_infrastructure": False})
    _write(root / "token_usage.json", {})
    _write(root / "timing.json", {"timed_out": False, "exit_code": 0})
    events = [
        {"event_type": "TOOL_COMMAND_COMPLETED", "command": "read /work/target", "exit_code": 0, "monotonic_seconds": 1},
        {"event_type": "BUILD_COMPLETED", "exit_code": 0, "monotonic_seconds": 2},
        {"event_type": "TEST_COMPLETED", "exit_code": 0, "monotonic_seconds": 3},
        {"event_type": "HYPOTHESIS_CREATED", "monotonic_seconds": 4},
    ]
    _write(root / "telemetry" / "lifecycle.jsonl", "\n".join(json.dumps(row) for row in events) + "\n")


class V015AcceptanceRuntimeTests(unittest.TestCase):
    def test_candidate_root_resolution_stops_at_product_root(self) -> None:
        path = Path("/capsule/product/codex-security-harness/src/bbp_harness/__init__.py")
        self.assertEqual(
            _candidate_root_from_init(path),
            Path("/capsule/product/codex-security-harness"),
        )

    def test_wall_time_has_precedence_over_coincident_overshoot(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _complete_plain_fixture(root)
            _write(root / "timing.json", {"timed_out": True, "exit_code": 124})
            _write(root / "resource_compliance.json", {
                "valid_resource_compliance": False,
                "violations": [{"type": "TOKEN_OVERSHOOT"}],
                "termination": {"reason": "BUDGET_OVERSHOOT_INVALID"},
            })
            result = grade(root, "plain-minimal")
        self.assertEqual(result["terminal_cause_v3"]["primary_cause"], "WALL_TIME_OVERRUN")
        self.assertEqual(result["protocol_status"], "VALID_TIMEOUT")
        self.assertFalse(result["true_resource_overshoot"])

    def test_model_prose_cannot_create_infrastructure_failure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _complete_plain_fixture(root)
            _write(root / "semantic_status.json", {
                "invalid_infrastructure": True,
                "fatal_errors": ["model said: provider unavailable"],
            })
            result = grade(root, "plain-minimal")
        self.assertFalse(result["structured_infrastructure_failure"])
        self.assertEqual(result["checks"]["semantic_infrastructure"], "PASS")
        self.assertEqual(result["terminal_cause_v3"]["primary_cause"], "NORMAL_SEMANTIC_TERMINAL")

    @mock.patch("run_development_e2e_v015._campaign_id", return_value="campaign-1")
    @mock.patch("run_development_e2e_v015.subprocess.run")
    def test_hard_stop_finalizer_attests_zero_live_state(
        self,
        run: mock.Mock,
        _campaign: mock.Mock,
    ) -> None:
        run.return_value = mock.Mock(
            returncode=0,
            stdout=json.dumps({
                "terminal_verdict": "TIMEOUT",
                "remaining_nonterminal_candidates": 0,
                "remaining_nonterminal_closure_candidates": 0,
                "remaining_live_reservations": 0,
                "active_closure_owner": None,
            }),
            stderr="",
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "control").mkdir()
            attestation = finalize_interrupted_harness(
                run_dir=root,
                database=root / "state.db",
                candidate=root / "product",
                ledger_path=root / "control" / "budget.json",
            )
        self.assertEqual(attestation["status"], "PASS")
        self.assertEqual(attestation["result"]["remaining_live_reservations"], 0)


if __name__ == "__main__":
    unittest.main()
