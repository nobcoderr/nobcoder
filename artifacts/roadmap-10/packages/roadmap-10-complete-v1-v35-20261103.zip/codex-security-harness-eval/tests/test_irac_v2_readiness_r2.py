from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

import jsonschema


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from execution_environment import sha256_file  # noqa: E402
from verify_irac_v2_readiness_r2 import count_exact_strings, verify  # noqa: E402


class IracV2ReadinessR2Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.protocol = json.loads((ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_READINESS_R2.json").read_text())
        self.prompt = (ROOT / self.protocol["smoke_fixture"]["prompt_path"]).read_text()
        self.schema_path = ROOT / self.protocol["smoke_fixture"]["schema_path"]
        self.schema = json.loads(self.schema_path.read_text())

    def test_capture_implementation_is_unchanged(self) -> None:
        frozen = self.protocol["frozen_capture_implementation"]
        self.assertEqual(frozen["capture_addon_sha256"], sha256_file(ROOT / "scripts" / "irac_v2_websocket_capture.py"))
        self.assertEqual(frozen["capture_runtime_sha256"], sha256_file(ROOT / "scripts" / "irac_v2_runtime.py"))
        self.assertEqual("PASS_UNCHANGED", frozen["transport_capture"])

    def test_schema_is_valid_and_sentinels_are_unambiguous(self) -> None:
        jsonschema.Draft202012Validator.check_schema(self.schema)
        fixture = self.protocol["smoke_fixture"]
        self.assertEqual(1, self.prompt.count(fixture["input_marker"]))
        self.assertEqual(0, count_exact_strings(self.schema, fixture["input_marker"]))
        self.assertNotIn(fixture["output_sentinel"], self.prompt)
        self.assertEqual(1, count_exact_strings(self.schema, fixture["output_sentinel"]))

    def test_readiness_remains_fail_closed_before_smoke(self) -> None:
        self.assertTrue(self.protocol["prohibitions"]["official_characterization_execution"])
        self.assertEqual(
            "STILL_REQUIRES_NEW_FROZEN_PROTOCOL_SCHEDULE_AND_EXECUTION_LOCK",
            self.protocol["pass_consequence"]["official_characterization_execution"],
        )

    def test_static_readiness_verifier_passes(self) -> None:
        self.assertEqual("PASS", verify()["status"])


if __name__ == "__main__":
    unittest.main()
