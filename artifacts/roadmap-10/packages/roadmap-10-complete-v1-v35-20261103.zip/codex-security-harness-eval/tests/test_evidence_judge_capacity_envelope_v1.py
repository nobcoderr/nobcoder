from __future__ import annotations

import importlib.util
import json
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


builder = load_module(
    "capacity_dataset_builder",
    ROOT / "scripts" / "build_evidence_judge_capacity_development_v1.py",
)
deriver = load_module(
    "capacity_envelope_deriver",
    ROOT / "scripts" / "derive_evidence_judge_capacity_envelope_v1.py",
)


def test_tier_boundaries_fail_closed() -> None:
    assert builder.tier_for(5_000) == "SMALL"
    assert builder.tier_for(5_001) == "MEDIUM"
    assert builder.tier_for(10_001) == "LARGE"
    try:
        builder.tier_for(15_001)
    except ValueError:
        pass
    else:
        raise AssertionError("out-of-domain context did not fail closed")


def test_dataset_is_complete_deduplicated_and_excludes_never_analyze() -> None:
    with tempfile.TemporaryDirectory() as directory:
        manifest = builder.build(Path(directory))
        assert manifest["rows"] == 144
        assert manifest["counts_by_source"] == {
            "evidence-judge-characterization-v1": 12,
            "evidence-judge-characterization-v2": 12,
            "evidence-judge-variance-decomposition-v1": 54,
            "evidence-judge-variance-decomposition-v3": 54,
            "request-identity-characterization-v1-r2": 12,
        }
        assert manifest["deduplication"]["duplicate_source_invocations"] == 0
        assert manifest["eligibility"]["never_analyze_roots_opened"] is False


def test_derivation_uses_frozen_factor_and_worst_case_noncached() -> None:
    values = list(builder.characterization_rows()) + list(builder.variance_rows()) + list(builder.request_identity_rows())
    policy = deriver.derive(values)
    for tier in ("SMALL", "MEDIUM", "LARGE"):
        reservation = policy["tiers"][tier]["reservation"]
        assert reservation["noncached_input_tokens"] == reservation["total_input_tokens"]
        maximum = policy["tiers"][tier]["development_actual_maximum"]
        assert reservation["total_input_tokens"] >= maximum["total_input_tokens"] * 1.25
        assert reservation["output_tokens"] >= maximum["output_tokens"] * 1.25
        assert reservation["reasoning_tokens"] >= maximum["reasoning_tokens"] * 1.25


def test_offline_replay_gates_are_mechanical() -> None:
    values = list(builder.characterization_rows()) + list(builder.variance_rows()) + list(builder.request_identity_rows())
    policy = deriver.derive(values)
    result = deriver.replay(values, policy)
    assert result["status"] == "PASS"
    assert result["overshoot_events"] == []
    assert result["noncached_safety_violations"] == 0
    assert result["aggregate_requested_to_actual_ratio"] <= 3.0
    assert result["aggregate_unused_reservation_fraction"] <= 0.6667
