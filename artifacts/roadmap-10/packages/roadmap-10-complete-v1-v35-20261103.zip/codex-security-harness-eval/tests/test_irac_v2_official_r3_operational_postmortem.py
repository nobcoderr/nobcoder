from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postmortem_irac_v2_official_r3_operational as postmortem  # noqa: E402


class OfficialR3OperationalPostmortemTests(unittest.TestCase):
    def test_lock_verifies(self) -> None:
        self.assertEqual("PASS", postmortem.verify()["status"])

    def test_scientific_data_remained_closed(self) -> None:
        result = json.loads((postmortem.OUTPUT / "POSTMORTEM.json").read_text())
        self.assertFalse(result["analysis_authorized"])
        self.assertFalse(result["scientific_fields_inspected"])
        self.assertFalse(result["historical_artifacts_reclassified"])
        self.assertEqual("DENIED", result["official_r3_analysis"])

    def test_two_idle_connection_cardinality_failures(self) -> None:
        result = json.loads((postmortem.OUTPUT / "POSTMORTEM.json").read_text())
        self.assertEqual(2, len(result["invalid_positions"]))
        for row in result["invalid_positions"]:
            self.assertEqual(2, row["websocket_established"])
            self.assertEqual(1, row["client_logical_messages"])
            self.assertEqual(1, row["selected_request_count"])
            self.assertEqual("PASS", row["capture_integrity"])
            self.assertEqual("ACCEPTED", row["provider_outcome"])


if __name__ == "__main__":
    unittest.main()
