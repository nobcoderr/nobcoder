from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from verify_irac_v2_official_protocol import verify  # noqa: E402


class OfficialProtocolTests(unittest.TestCase):
    def setUp(self) -> None:
        self.protocol = json.loads((ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL.json").read_text())
        self.schedule = json.loads((ROOT / "calibration" / "initial-request-accounting-characterization-v2-official" / "SCHEDULE.json").read_text())

    def test_official_protocol_verifies_without_model(self) -> None:
        result = verify()
        self.assertEqual("PASS", result["status"], result["errors"])
        self.assertEqual(0, result["model_invocations"])

    def test_schedule_is_exactly_12_without_retry_or_replacement(self) -> None:
        self.assertEqual(list(range(1, 13)), [row["position"] for row in self.schedule["entries"]])
        self.assertEqual(12, len({row["sample_id"] for row in self.schedule["entries"]}))
        self.assertEqual(0, self.schedule["retry_count"])
        self.assertEqual(0, self.schedule["replacement_count"])
        self.assertEqual(1, self.schedule["concurrency"])

    def test_decision_tree_has_exact_authoritative_outcomes(self) -> None:
        tree = self.protocol["decision_tree"]
        outcomes = {
            "PRE_INVOCATION_CONTEXT_DRIFT_ESTABLISHED",
            "MEASUREMENT_ACCOUNTING_VARIATION_ESTABLISHED",
            "MIXED",
            "UNRESOLVED",
        }
        self.assertTrue(outcomes.issubset(tree))
        self.assertTrue(tree["no_post_hoc_rule_change"])

    def test_product_scheduler_and_variance_v2_remain_blocked(self) -> None:
        prohibitions = self.protocol["prohibitions"]
        self.assertTrue(prohibitions["product_or_scheduler_change"])
        self.assertTrue(prohibitions["variance_v2_before_irac_conclusion"])
        self.assertTrue(prohibitions["full_bundle_replay"])


if __name__ == "__main__":
    unittest.main()
