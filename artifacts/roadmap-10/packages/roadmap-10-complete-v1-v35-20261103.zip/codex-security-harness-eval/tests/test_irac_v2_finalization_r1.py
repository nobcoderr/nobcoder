from __future__ import annotations

import json
import stat
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_finalization_r1 import (  # noqa: E402
    FinalizationError,
    FinalizationInterrupted,
    complete_cleanup,
    finalize_observation,
    initialize_journal,
    recovery_status,
    verify_finalized,
)
from irac_v2_readiness_lifecycle import directory_content_digest  # noqa: E402


class FinalizationR1Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.active = self.root / "active" / "T-001"
        self.canonical = self.root / "observations" / "T-001"
        self.meta = self.root / "finalization" / "T-001"
        self.capsule = self.root / "capsules" / "T-001"
        self.immutable = self.capsule / "immutable" / "snapshot"
        self.runtime = self.capsule / "runtime"
        self.workers = self.capsule / "worker_runs"
        for path in (self.active, self.immutable, self.runtime, self.workers):
            path.mkdir(parents=True)
        (self.active / "observation.json").write_text('{"status":"PASS"}\n')
        (self.immutable / "source.txt").write_text("immutable\n")
        (self.runtime / "temp.txt").write_text("temporary\n")
        (self.workers / "run.txt").write_text("temporary\n")
        self.immutable_digest = directory_content_digest(self.immutable)
        self.journal = self.meta / "FINALIZATION_JOURNAL.json"
        initialize_journal(
            self.journal,
            invocation_id="T-001",
            schedule_position=1,
            staging=self.active,
            canonical=self.canonical,
            capsule=self.capsule,
        )

    def tearDown(self) -> None:
        for path in sorted(self.root.rglob("*")):
            if path.exists() and not path.is_symlink():
                path.chmod(stat.S_IMODE(path.stat().st_mode) | stat.S_IWUSR | (stat.S_IXUSR if path.is_dir() else 0))
        self.temp.cleanup()

    def validator(self, path: Path) -> None:
        self.assertEqual("PASS", json.loads((path / "observation.json").read_text())["status"])

    def fields(self) -> dict[str, object]:
        return {
            "invocation_id": "T-001",
            "schedule_position": 1,
            "fixture_digest": "a" * 64,
            "runtime_digest": "b" * 64,
            "product_digest": "c" * 64,
            "capture_digest": "d" * 64,
            "classifier_digest": "e" * 64,
            "raw_request_digest": "f" * 64,
            "canonical_request_digest": "0" * 64,
            "terminal_status": "VALID_COMPLETED",
        }

    def finalize(self, **kwargs):
        return finalize_observation(
            staging=self.active,
            canonical=self.canonical,
            journal_path=self.journal,
            invocation_lock_fields=self.fields(),
            validator=self.validator,
            **kwargs,
        )

    def cleanup(self, **kwargs):
        return complete_cleanup(
            canonical=self.canonical,
            journal_path=self.journal,
            capsule=self.capsule,
            immutable_snapshot=self.immutable,
            expected_immutable_digest=self.immutable_digest,
            cleanup_journal_path=self.meta / "CLEANUP_JOURNAL.json",
            **kwargs,
        )

    def test_happy_path_renames_then_freezes_then_cleans(self) -> None:
        self.assertEqual("IMMUTABILITY_VERIFIED", self.finalize()["state"])
        self.assertFalse(self.active.exists())
        self.assertTrue(self.canonical.exists())
        self.assertEqual("PASS", self.cleanup()["status"])
        self.assertTrue(self.immutable.exists())
        self.assertFalse(self.runtime.exists())
        self.assertFalse(self.workers.exists())
        self.assertEqual("PASS", verify_finalized(canonical=self.canonical, journal_path=self.journal)["status"])

    def test_freeze_before_rename_is_refused(self) -> None:
        self.active.chmod(0o555)
        with self.assertRaisesRegex(FinalizationError, "FREEZE_BEFORE_RENAME_REFUSED"):
            self.finalize()

    def test_existing_destination_fails_closed(self) -> None:
        self.canonical.mkdir(parents=True)
        with self.assertRaisesRegex(FinalizationError, "FINALIZATION_DESTINATION_EXISTS"):
            self.finalize()

    def test_cross_device_fails_closed(self) -> None:
        with self.assertRaisesRegex(FinalizationError, "FINALIZATION_CROSS_DEVICE"):
            self.finalize(device_id_override=(1, 2))
        self.assertTrue(self.active.exists())

    def test_artifact_mutation_after_hash_fails_closed(self) -> None:
        with self.assertRaisesRegex(FinalizationError, "ARTIFACT_DIGEST_MUTATION"):
            self.finalize(inject_mutation_after_hash=True)

    def test_interruption_before_rename_is_unfinalized_staging(self) -> None:
        with self.assertRaises(FinalizationInterrupted):
            self.finalize(inject_interrupt_after="EXECUTION_COMPLETE")
        self.assertEqual("UNFINALIZED_STAGING", recovery_status(self.journal, self.active, self.canonical))

    def test_interruption_after_rename_is_recoverable_without_model(self) -> None:
        with self.assertRaises(FinalizationInterrupted):
            self.finalize(inject_interrupt_after="RENAMED_TO_CANONICAL")
        self.assertEqual("FINALIZATION_INTERRUPTED", recovery_status(self.journal, self.active, self.canonical))
        self.assertEqual("IMMUTABILITY_VERIFIED", self.finalize()["state"])
        self.assertEqual("PASS", self.cleanup()["status"])

    def test_interruption_after_freeze_is_recoverable_without_model(self) -> None:
        with self.assertRaises(FinalizationInterrupted):
            self.finalize(inject_interrupt_after="FROZEN_READ_ONLY")
        self.assertEqual("FINALIZATION_INTERRUPTED", recovery_status(self.journal, self.active, self.canonical))
        self.assertEqual("IMMUTABILITY_VERIFIED", self.finalize()["state"])
        self.assertEqual("PASS", self.cleanup()["status"])

    def test_cleanup_before_freeze_is_refused(self) -> None:
        with self.assertRaisesRegex(FinalizationError, "cleanup before immutability"):
            self.cleanup()


if __name__ == "__main__":
    unittest.main()
