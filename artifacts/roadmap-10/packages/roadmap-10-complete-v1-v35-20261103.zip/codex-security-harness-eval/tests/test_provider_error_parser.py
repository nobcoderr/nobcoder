from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from provider_error_parser import parse_provider_outcome  # noqa: E402


def error(code: str, error_type: str, message: str) -> dict:
    return {"type": "error", "error": {"code": code, "type": error_type, "message": message}}


class ProviderErrorParserTests(unittest.TestCase):
    def test_normal_response_is_accepted(self) -> None:
        result = parse_provider_outcome([{"type": "response.created"}, {"type": "response.completed"}])
        self.assertEqual(("PASS", "ACCEPTED"), (result["status"], result["provider_outcome"]))

    def test_model_at_capacity(self) -> None:
        result = parse_provider_outcome([error("server_is_overloaded", "service_unavailable_error", "Our servers are currently overloaded.")])
        self.assertEqual("MODEL_CAPACITY", result["provider_error_class"])

    def test_rate_limit(self) -> None:
        result = parse_provider_outcome([error("rate_limit_exceeded", "rate_limit_error", "Rate limit reached")])
        self.assertEqual("RATE_LIMIT", result["provider_error_class"])

    def test_service_unavailable(self) -> None:
        result = parse_provider_outcome([error("service_unavailable", "service_unavailable_error", "Service unavailable")])
        self.assertEqual("UNAVAILABLE", result["provider_error_class"])

    def test_authentication_failure(self) -> None:
        result = parse_provider_outcome([error("unauthorized", "authentication_error", "Unauthorized")])
        self.assertEqual("AUTHENTICATION", result["provider_error_class"])

    def test_invalid_request(self) -> None:
        result = parse_provider_outcome([error("invalid_request", "invalid_request_error", "Invalid request")])
        self.assertEqual("INVALID_REQUEST", result["provider_error_class"])

    def test_malformed_known_error_fails_closed(self) -> None:
        result = parse_provider_outcome([{"type": "error", "error": {"code": "server_is_overloaded"}}])
        self.assertEqual(("FAIL_CLOSED", "PROTOCOL_UNRECOGNIZED"), (result["status"], result["provider_outcome"]))

    def test_unknown_error_is_structured(self) -> None:
        result = parse_provider_outcome([error("new_code", "new_type", "New provider failure")])
        self.assertEqual("UNKNOWN_PROVIDER_ERROR", result["provider_error_class"])

    def test_conflicting_error_classes_fail_closed(self) -> None:
        result = parse_provider_outcome([
            error("server_is_overloaded", "service_unavailable_error", "overloaded"),
            error("rate_limit_exceeded", "rate_limit_error", "rate limit"),
        ])
        self.assertEqual(("FAIL_CLOSED", "PROTOCOL_UNRECOGNIZED"), (result["status"], result["provider_outcome"]))

    def test_normal_response_plus_conflicting_error_fails_closed(self) -> None:
        result = parse_provider_outcome([
            {"type": "response.created"},
            {"type": "response.completed"},
            error("server_error", "server_error", "generic failure"),
        ])
        self.assertEqual(("FAIL_CLOSED", "PROTOCOL_UNRECOGNIZED"), (result["status"], result["provider_outcome"]))

    def test_setup_success_then_capacity_is_rejected_not_conflict(self) -> None:
        result = parse_provider_outcome([
            {"type": "response.created"},
            {"type": "response.completed"},
            {"type": "response.created"},
            error("server_is_overloaded", "service_unavailable_error", "overloaded"),
            {"type": "response.failed"},
        ])
        self.assertEqual(("PASS", "REJECTED", "MODEL_CAPACITY"), (result["status"], result["provider_outcome"], result["provider_error_class"]))


if __name__ == "__main__":
    unittest.main()
