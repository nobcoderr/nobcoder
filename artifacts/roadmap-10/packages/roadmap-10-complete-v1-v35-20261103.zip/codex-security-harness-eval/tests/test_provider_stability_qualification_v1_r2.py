from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
V1 = ROOT / "protocol" / "PROVIDER_STABILITY_QUALIFICATION_V1.json"
R2 = ROOT / "protocol" / "PROVIDER_STABILITY_QUALIFICATION_V1_R2.json"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_r2_changes_only_lock_contract_and_identity():
    v1, r2 = load(V1), load(R2)
    assert r2["representative_probe"] == v1["representative_probe"]
    assert r2["stage_a"] == v1["stage_a"]
    assert r2["stage_b"] == v1["stage_b"]
    assert r2["decision"]["stage_a_fail"] == v1["decision"]["stage_a_fail"]
    assert r2["decision"]["stage_a_pass_stage_b_fail"] == v1["decision"]["stage_a_pass_stage_b_fail"]
    assert r2["decision"]["both_pass"] == v1["decision"]["both_pass"]
    assert r2["ancestry"]["thresholds_changed"] is False
    assert r2["ancestry"]["scientific_components_changed"] is False


def test_v1_is_immutable_pre_execution_failure():
    disposition = load(ROOT / "protocol" / "PROVIDER_STABILITY_QUALIFICATION_V1.disposition.json")
    assert disposition["status"] == "PRE_EXECUTION_LOCK_CONTRACT_FAIL_IMMUTABLE_NEVER_EXECUTE"
    assert disposition["model_invocations"] == 0
    assert disposition["fresh_variance_identity_creation_authorized"] is False


def test_r2_schedules_are_fresh_and_exact_when_built():
    directory = ROOT / "calibration" / "provider-stability-qualification-v1-r2"
    if not directory.exists():
        return
    for name, stage, count in (("SCHEDULE_STAGE_A.json", "A", 60), ("SCHEDULE_STAGE_B.json", "B", 12)):
        schedule = load(directory / name)
        assert [row["position"] for row in schedule["entries"]] == list(range(1, count + 1))
        assert all(row["stage"] == stage for row in schedule["entries"])
        assert all("R2" in row["sample_id"] for row in schedule["entries"])
        assert len({row["sample_id"] for row in schedule["entries"]}) == count
