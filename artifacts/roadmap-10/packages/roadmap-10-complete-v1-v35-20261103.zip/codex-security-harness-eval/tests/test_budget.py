from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from scripts.budget import BudgetDenied, BudgetLedger, BudgetWait


def spec(total: int = 100, invocations: int = 10) -> dict:
    return {
        "budget_version": "test-v1",
        "accounting": {"primary_metric": "total_input_tokens"},
        "limits": {
            "per_run": {
                "max_total_input_tokens": total,
                "max_noncached_input_tokens": total,
                "max_output_tokens": total,
                "max_reasoning_tokens": total,
                "max_wall_time_seconds": 100,
                "max_invocations": invocations,
            },
            "per_invocation": {
                "max_total_input_tokens": total,
                "max_noncached_input_tokens": total,
                "max_output_tokens": total,
                "max_wall_time_seconds": 50,
            },
        },
        "reservation_profiles": {
            "default": {
                "total_input_tokens": total,
                "noncached_input_tokens": total,
                "output_tokens": total,
                "reasoning_tokens": total,
            }
        },
        "policy": {
            "on_budget_exhaustion": "HARD_STOP",
            "on_token_overshoot": "HARD_STOP_AND_INVALIDATE",
            "reservation_lease_seconds": 10,
            "resume_preserves_usage": True,
        },
    }


def request(total: int) -> dict[str, int]:
    return {
        "total_input_tokens": total,
        "noncached_input_tokens": 0,
        "output_tokens": 0,
        "reasoning_tokens": 0,
    }


def usage(total: int) -> dict[str, int]:
    return {
        "total_input_tokens": total,
        "cached_input_tokens": total,
        "noncached_input_tokens": 0,
        "output_tokens": 0,
        "reasoning_tokens": 0,
    }


def v012_spec(total: int = 1200, invocations: int = 10) -> dict:
    value = spec(total, invocations)
    value["budget_version"] = "v0.1.2-test"
    value["policy"]["on_transient_capacity_pressure"] = "WAIT"
    value["limits"]["per_invocation"]["max_reasoning_tokens"] = total
    return value


class BudgetTests(unittest.TestCase):
    def make(self, root: Path, *, system: str = "plain", total: int = 100) -> BudgetLedger:
        return BudgetLedger.initialize(
            root / f"{system}.json", spec(total), run_id="run", system=system, now=1000
        )

    def test_sequential_reservation_denies_insufficient_budget(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = self.make(Path(temporary))
            ledger.reserve(role="a", requested=request(40), invocation_id="a", now=1001)
            ledger.start("a", now=1002)
            ledger.settle("a", actual_usage=usage(40), exit_code=0, exit_reason="PASS", now=1003)
            with self.assertRaises(BudgetDenied):
                ledger.reserve(role="b", requested=request(70), invocation_id="b", now=1004)
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["termination"]["reason"], "BUDGET_EXHAUSTED")

    def test_concurrent_reservations_are_atomic(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = self.make(Path(temporary))
            barrier = threading.Barrier(2)

            def attempt(name: str) -> str:
                barrier.wait()
                try:
                    ledger.reserve(role=name, requested=request(60), invocation_id=name, now=1001)
                    return "ADMITTED"
                except BudgetDenied:
                    return "DENIED"

            with ThreadPoolExecutor(max_workers=2) as pool:
                results = list(pool.map(attempt, ("a", "b")))
            self.assertEqual(sorted(results), ["ADMITTED", "DENIED"])

    def test_expired_unstarted_reservation_is_released(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = self.make(Path(temporary))
            ledger.reserve(role="a", requested=request(50), invocation_id="a", now=1001)
            self.assertEqual(ledger.reap(now=1012), ["a"])
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["usage"]["invocations"], 0)
            self.assertEqual(state["reservations"][0]["status"], "RELEASED")

    def test_overshoot_hard_stops_and_invalidates(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = self.make(Path(temporary))
            ledger.reserve(role="a", requested=request(30), invocation_id="a", now=1001)
            ledger.start("a", now=1002)
            ledger.settle("a", actual_usage=usage(40), exit_code=0, exit_reason="PASS", now=1003)
            result = ledger.verify()
            self.assertFalse(result["valid_resource_compliance"])
            self.assertEqual(result["termination"]["reason"], "BUDGET_OVERSHOOT_INVALID")
            with self.assertRaises(BudgetDenied):
                ledger.reserve(role="b", requested=request(1), invocation_id="b", now=1004)

    def test_resume_preserves_used_budget(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            ledger = self.make(root)
            ledger.reserve(role="a", requested=request(70), invocation_id="a", now=1001)
            ledger.start("a", now=1002)
            ledger.settle("a", actual_usage=usage(70), exit_code=0, exit_reason="PASS", now=1003)
            resumed = BudgetLedger(ledger.path)
            resumed.reserve(role="b", requested=request(30), invocation_id="b", now=1004)
            with self.assertRaises(BudgetDenied):
                resumed.reserve(role="c", requested=request(1), invocation_id="c", now=1005)

    def test_activation_clock_starts_at_execution_and_resume_does_not_reset(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = self.make(Path(temporary))
            ledger.activate(now=5000)
            ledger.reserve(role="a", requested=request(10), invocation_id="a", now=5001)
            resumed = BudgetLedger(ledger.path)
            resumed.activate(now=9000)
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["run_started_epoch"], 5000)
            self.assertEqual(
                [event["type"] for event in state["events"]].count("RUN_ACTIVATED"),
                1,
            )

    def test_same_enforcer_for_plain_and_harness(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            outcomes = []
            for system in ("plain-minimal", "harness-v0.1.0"):
                ledger = self.make(root, system=system)
                ledger.reserve(role="worker", requested=request(40), invocation_id="a", now=1001)
                ledger.start("a", now=1002)
                ledger.settle("a", actual_usage=usage(40), exit_code=0, exit_reason="PASS", now=1003)
                ledger.reap(force=True, now=1004)
                ledger.finalize(wall_clock_seconds=4, reason="NORMAL_COMPLETION", now=1005)
                outcomes.append(ledger.verify())
            self.assertTrue(all(item["status"] == "PASS" for item in outcomes))
            self.assertTrue(all(item["valid_resource_compliance"] for item in outcomes))
            self.assertEqual(outcomes[0]["usage"], outcomes[1]["usage"])

    def test_run_01_regression_fixture_cannot_continue(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = self.make(Path(temporary), total=120000)
            ledger.reserve(role="worker", requested=request(120000), invocation_id="run-01", now=1001)
            ledger.start("run-01", now=1002)
            ledger.settle(
                "run-01",
                actual_usage={
                    "total_input_tokens": 1903264,
                    "cached_input_tokens": 1528320,
                    "noncached_input_tokens": 374944,
                    "output_tokens": 57287,
                    "reasoning_tokens": 33306,
                },
                exit_code=0,
                exit_reason="PASS",
                now=1003,
            )
            result = ledger.verify()
            self.assertFalse(result["valid_resource_compliance"])
            with self.assertRaises(BudgetDenied):
                ledger.reserve(role="next", requested=request(1), invocation_id="next", now=1004)

    def test_wrapper_enforces_same_ledger_for_plain_and_harness(self) -> None:
        project = Path(__file__).resolve().parents[1]
        calibration_spec = json.loads(
            (project / "protocol" / "CALIBRATION_BUDGET_V0.json").read_text()
        )
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            fake = root / "fake-codex"
            fake.write_text(
                "#!/bin/sh\n"
                "printf '%s\\n' '{\"type\":\"turn.completed\",\"usage\":{\"input_tokens\":40,\"cached_input_tokens\":10,\"output_tokens\":3,\"reasoning_output_tokens\":2}}'\n",
                encoding="utf-8",
            )
            fake.chmod(0o755)
            for system, nested in (("plain-minimal", False), ("harness-v0.1.0", True)):
                run = root / system
                run.mkdir()
                (run / "worker_runs").mkdir()
                shutil.copy2(project / "scripts" / "codex_xhigh_wrapper.sh", run / "codex-wrapper")
                shutil.copy2(project / "scripts" / "budget.py", run / "budget.py")
                shutil.copy2(project / "scripts" / "budget_cli.py", run / "budget_cli.py")
                (run / "codex-wrapper").chmod(0o755)
                ledger = BudgetLedger.initialize(
                    run / "budget_ledger.json",
                    calibration_spec,
                    run_id=system,
                    system=system,
                )
                env = os.environ.copy()
                env.update({
                    "PILOT_RUN_DIR": str(run),
                    "BUDGET_LEDGER": str(ledger.path),
                    "CODEX_REAL_BINARY": str(fake),
                })
                if nested:
                    (run / "home" / "state").mkdir(parents=True)
                    env["BBP_AI_HOME"] = str(run / "home")
                completed = subprocess.run(
                    [str(run / "codex-wrapper"), "exec"],
                    capture_output=True,
                    text=True,
                    env=env,
                    check=False,
                    timeout=30,
                )
                self.assertEqual(completed.returncode, 0, completed.stderr)
                self.assertIn('"input_tokens":40', completed.stdout)
                ledger.reap(force=True)
                ledger.finalize(wall_clock_seconds=1, reason="NORMAL_COMPLETION")
                verified = ledger.verify()
                self.assertTrue(verified["valid_resource_compliance"])
                self.assertEqual(verified["usage"]["total_input_tokens"], 40)

    def test_v012_wrapper_consumes_one_preauthorized_reservation(self) -> None:
        project = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            run = Path(temporary)
            (run / "worker_runs").mkdir()
            for name in ("budget.py", "budget_cli.py"):
                shutil.copy2(project / "scripts" / name, run / name)
            wrapper = run / "codex-wrapper"
            shutil.copy2(project / "scripts" / "codex_v2_wrapper.sh", wrapper)
            wrapper.chmod(0o755)
            fake = run / "fake-codex"
            fake.write_text(
                "#!/bin/sh\n"
                "printf '%s\\n' '{\"type\":\"turn.completed\",\"usage\":{\"input_tokens\":40,\"cached_input_tokens\":10,\"output_tokens\":3,\"reasoning_output_tokens\":2}}'\n",
                encoding="utf-8",
            )
            fake.chmod(0o755)
            ledger = BudgetLedger.initialize(
                run / "budget_ledger.json",
                v012_spec(1000),
                run_id="preauthorized",
                system="harness-v0.1.2",
            )
            ledger.reserve(
                role="mapper",
                requested={
                    "total_input_tokens": 100,
                    "noncached_input_tokens": 50,
                    "output_tokens": 10,
                    "reasoning_tokens": 10,
                },
                invocation_id="INV-preauthorized",
                estimator={"version": "fixture"},
            )
            env = os.environ.copy()
            env.update(
                {
                    "PILOT_RUN_DIR": str(run),
                    "BUDGET_LEDGER": str(ledger.path),
                    "CODEX_REAL_BINARY": str(fake),
                    "BBP_PREAUTHORIZED_INVOCATION_ID": "INV-preauthorized",
                    "BBP_PREAUTHORIZED_ROLE": "mapper",
                }
            )
            completed = subprocess.run(
                [str(wrapper), "--output-schema", "/fixture/mapper-output.schema.json"],
                capture_output=True,
                text=True,
                env=env,
                check=False,
                timeout=30,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            state = json.loads(ledger.path.read_text())
            self.assertEqual(len(state["reservations"]), 1)
            self.assertEqual(len(state["invocations"]), 1)
            self.assertEqual(state["reservations"][0]["status"], "SETTLED")
            self.assertEqual(state["usage"]["total_input_tokens"], 40)

    def test_v012_temporary_pressure_waits_then_admits_after_settlement(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            ledger = BudgetLedger.initialize(
                root / "v012.json", v012_spec(), run_id="run", system="harness-v0.1.2", now=1000
            )
            ledger.reserve(role="used", requested=request(500), invocation_id="used", now=1001)
            ledger.start("used", now=1002)
            ledger.settle("used", actual_usage=usage(500), exit_code=0, exit_reason="PASS", now=1003)
            ledger.reserve(role="active", requested=request(500), invocation_id="active", now=1004)
            ledger.start("active", now=1005)

            with self.assertRaises(BudgetWait):
                ledger.reserve(role="next", requested=request(300), invocation_id="next", now=1006)
            waiting = ledger.inspect("next")
            self.assertEqual(waiting["status"], "WAITING")
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["status"], "ACTIVE")
            self.assertIsNone(state["termination"]["reason"])

            ledger.settle("active", actual_usage=usage(100), exit_code=0, exit_reason="PASS", now=1007)
            admitted = ledger.reserve(
                role="next", requested=request(300), invocation_id="next", now=1008
            )
            self.assertEqual(admitted["status"], "RESERVED")
            self.assertEqual(admitted["wait_count"], 1)
            events = [
                item["type"]
                for item in json.loads(ledger.path.read_text())["events"]
                if item.get("details", {}).get("invocation_id") == "next"
            ]
            self.assertIn("RESERVATION_WAITING", events)
            self.assertGreater(events.index("RESERVATION_ADMITTED"), events.index("RESERVATION_WAITING"))

    def test_v012_impossible_after_active_release_denies_final(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            ledger = BudgetLedger.initialize(
                root / "v012.json", v012_spec(), run_id="run", system="harness-v0.1.2", now=1000
            )
            ledger.reserve(role="used", requested=request(1000), invocation_id="used", now=1001)
            ledger.start("used", now=1002)
            ledger.settle("used", actual_usage=usage(1000), exit_code=0, exit_reason="PASS", now=1003)
            with self.assertRaises(BudgetDenied):
                ledger.reserve(role="next", requested=request(300), invocation_id="next", now=1004)
            denied = ledger.inspect("next")
            self.assertEqual(denied["status"], "DENIED_FINAL")
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["termination"]["reason"], "BUDGET_EXHAUSTED")
            self.assertIn("RESERVATION_DENIED_FINAL", [item["type"] for item in state["events"]])

    def test_v012_concurrent_pressure_admits_one_and_waits_one(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            ledger = BudgetLedger.initialize(
                root / "v012.json", v012_spec(1000), run_id="run", system="harness-v0.1.2", now=1000
            )
            barrier = threading.Barrier(2)

            def attempt(name: str) -> str:
                barrier.wait()
                try:
                    ledger.reserve(role=name, requested=request(600), invocation_id=name, now=1001)
                    return "ADMITTED"
                except BudgetWait:
                    return "WAIT"

            with ThreadPoolExecutor(max_workers=2) as pool:
                outcomes = list(pool.map(attempt, ("a", "b")))
            self.assertEqual(sorted(outcomes), ["ADMITTED", "WAIT"])
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["status"], "ACTIVE")
            self.assertEqual(
                sorted(item["status"] for item in state["reservations"]),
                ["RESERVED", "WAITING"],
            )

    def test_v012_duplicate_settlement_is_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            ledger = BudgetLedger.initialize(
                root / "v012.json", v012_spec(), run_id="run", system="harness-v0.1.2", now=1000
            )
            ledger.reserve(role="worker", requested=request(400), invocation_id="worker", now=1001)
            ledger.start("worker", now=1002)
            first = ledger.settle(
                "worker", actual_usage=usage(100), exit_code=0, exit_reason="PASS", now=1003
            )
            second = ledger.settle(
                "worker", actual_usage=usage(100), exit_code=0, exit_reason="PASS", now=1004
            )
            self.assertEqual(first, second)
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["usage"]["total_input_tokens"], 100)
            self.assertEqual(state["usage"]["invocations"], 1)

    def test_v012_overshoot_has_explicit_terminal_reservation_state(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = BudgetLedger.initialize(
                Path(temporary) / "v012.json",
                v012_spec(),
                run_id="run",
                system="harness-v0.1.2",
                now=1000,
            )
            ledger.reserve(role="worker", requested=request(300), invocation_id="worker", now=1001)
            ledger.start("worker", now=1002)
            ledger.settle(
                "worker",
                actual_usage=usage(301),
                exit_code=0,
                exit_reason="PASS",
                now=1003,
            )
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["reservations"][0]["status"], "OVERSHOOT_INVALID")
            self.assertEqual(state["termination"]["reason"], "BUDGET_OVERSHOOT_INVALID")
            self.assertIn(
                "RESERVATION_OVERSHOOT_INVALID",
                [item["type"] for item in state["events"]],
            )
            verified = ledger.verify()
            self.assertEqual(verified["status"], "PASS")
            self.assertFalse(verified["valid_resource_compliance"])


if __name__ == "__main__":
    unittest.main()
