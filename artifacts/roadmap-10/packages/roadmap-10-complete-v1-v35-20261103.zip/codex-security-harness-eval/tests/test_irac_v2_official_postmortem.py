from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postmortem_irac_v2_official_execution as postmortem  # noqa: E402


class OfficialIracPostmortemTests(unittest.TestCase):
    def test_disposition_is_never_analyze(self) -> None:
        result = json.loads((postmortem.OUTPUT / "POSTMORTEM.json").read_text())
        self.assertEqual("MEASUREMENT_INCOMPLETE_IMMUTABLE_NEVER_ANALYZE", result["authoritative_status"])
        self.assertFalse(result["analysis_authorized"])
        self.assertEqual("NOT_RUN", result["scientific_disposition"]["decision_tree_outcome"])
        self.assertFalse(result["scientific_disposition"]["request_or_usage_outcomes_inspected"])

    def test_invocation_count_erratum_does_not_rescore(self) -> None:
        result = json.loads((postmortem.OUTPUT / "POSTMORTEM.json").read_text())
        self.assertEqual(0, result["metadata_erratum"]["historical_raw_lock_model_invocations_recorded"])
        self.assertEqual(1, result["metadata_erratum"]["actual_model_invocations"])
        self.assertEqual("NONE_EXECUTION_ALREADY_MEASUREMENT_INCOMPLETE", result["metadata_erratum"]["decision_impact"])

    def test_locked_postmortem_verifies(self) -> None:
        self.assertEqual("PASS", postmortem.verify()["status"])


if __name__ == "__main__":
    unittest.main()
