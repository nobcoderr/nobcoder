from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import run_initial_request_accounting_characterization_v1 as runner  # noqa: E402


class InitialRequestAccountingRunnerV1Tests(unittest.TestCase):
    def test_classification_is_fail_closed_for_capture_and_interaction(self) -> None:
        usage = {"total_input_tokens": 10, "noncached_input_tokens": 10, "output_tokens": 1, "reasoning_tokens": 1}
        limits = {"max_total_input_tokens": 100, "max_noncached_input_tokens": 100, "max_output_tokens": 100, "max_reasoning_tokens": 100, "max_wall_time_seconds": 10}
        valid = runner.classify(exit_code=0, timed_out=False, usage=usage, limits=limits, wall=1, schema_valid=True, session_id="s", capture_valid=True, turn_count=1, tool_call_count=0)
        self.assertEqual("VALID_COMPLETED", valid[0])
        self.assertEqual("INVALID_CAPTURE", runner.classify(exit_code=0, timed_out=False, usage=usage, limits=limits, wall=1, schema_valid=True, session_id="s", capture_valid=False, turn_count=1, tool_call_count=0)[0])
        self.assertEqual("INVALID_CAPTURE", runner.classify(exit_code=0, timed_out=False, usage=usage, limits=limits, wall=1, schema_valid=True, session_id="s", capture_valid=True, turn_count=2, tool_call_count=0)[0])
        self.assertEqual("INVALID_CAPTURE", runner.classify(exit_code=0, timed_out=False, usage=usage, limits=limits, wall=1, schema_valid=True, session_id="s", capture_valid=True, turn_count=1, tool_call_count=1)[0])

    def test_overshoot_and_timeout_do_not_become_success(self) -> None:
        limits = {"max_total_input_tokens": 100, "max_noncached_input_tokens": 100, "max_output_tokens": 100, "max_reasoning_tokens": 100, "max_wall_time_seconds": 10}
        overshoot = {"total_input_tokens": 101, "noncached_input_tokens": 10, "output_tokens": 1, "reasoning_tokens": 1}
        self.assertEqual("INVALID_OVERSHOOT", runner.classify(exit_code=0, timed_out=False, usage=overshoot, limits=limits, wall=1, schema_valid=True, session_id="s", capture_valid=True, turn_count=1, tool_call_count=0)[0])
        within = {"total_input_tokens": 10, "noncached_input_tokens": 10, "output_tokens": 1, "reasoning_tokens": 1}
        self.assertEqual("VALID_TIMEOUT", runner.classify(exit_code=124, timed_out=True, usage=within, limits=limits, wall=10, schema_valid=False, session_id="s", capture_valid=True, turn_count=0, tool_call_count=0)[0])

    def test_event_structure_detects_tools_and_turns(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            path = Path(directory) / "events.jsonl"
            rows = [
                {"type": "turn.started"},
                {"type": "item.completed", "item": {"type": "agent_message"}},
                {"type": "item.completed", "item": {"type": "command_execution"}},
                {"type": "turn.completed"},
            ]
            path.write_text("".join(json.dumps(row) + "\n" for row in rows))
            self.assertEqual((1, 1), runner.event_structure(path))

    def test_started_position_can_never_be_retried(self) -> None:
        schedule = {"entries": [{"sample_id": "IRAC-001"}, {"sample_id": "IRAC-002"}]}
        with self.assertRaisesRegex(RuntimeError, "cannot retry"):
            runner.completed_prefix_length(schedule, {"samples": {"IRAC-001": "STARTED", "IRAC-002": "PENDING"}})

    def test_progress_must_be_contiguous_prefix(self) -> None:
        schedule = {"entries": [{"sample_id": "IRAC-001"}, {"sample_id": "IRAC-002"}]}
        with self.assertRaisesRegex(RuntimeError, "not a completed prefix"):
            runner.completed_prefix_length(schedule, {"samples": {"IRAC-001": "PENDING", "IRAC-002": "COMPLETE"}})

    def test_runner_hash_surface_includes_capture_and_protocol_tests(self) -> None:
        hashes = runner.runner_file_hashes()
        for key in ("capture_addon", "runtime_helper", "protocol_verifier", "capture_preflight_script", "runner_test", "protocol_test"):
            self.assertIn(key, hashes)
            self.assertEqual(64, len(hashes[key]))

    def test_design_lock_and_static_verifier_pass_without_model(self) -> None:
        verified = runner.verify_design_lock()
        self.assertEqual("LOCKED_DESIGN_PRE_INVOCATION", verified["lock"]["status"])
        self.assertEqual(0, verified["lock"]["model_invocations_at_lock"])
        self.assertEqual("PASS", verified["verification"]["status"])


if __name__ == "__main__":
    unittest.main()
