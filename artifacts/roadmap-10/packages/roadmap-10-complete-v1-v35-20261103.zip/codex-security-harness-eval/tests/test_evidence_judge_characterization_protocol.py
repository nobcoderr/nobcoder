from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "scripts"))

from verify_evidence_judge_characterization_protocol import verify


class EvidenceJudgeCharacterizationProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result = verify()

    def test_protocol_preflight_passes(self) -> None:
        self.assertEqual(self.result["status"], "PASS", self.result["errors"])

    def test_workload_matrix_is_complete(self) -> None:
        check = self.result["checks"]["workloads"]
        self.assertEqual(check["count"], 12)
        self.assertEqual(check["tier_counts"], {"LARGE": 4, "MEDIUM": 4, "SMALL": 4})

    def test_capture_limits_are_data_derived(self) -> None:
        self.assertEqual(self.result["checks"]["capture_limit_derivation"]["status"], "PASS")

    def test_characterization_does_not_authorize_product_or_holdout(self) -> None:
        self.assertFalse(self.result["implementation_authorized"])
        self.assertFalse(self.result["fresh_holdout_used"])


if __name__ == "__main__":
    unittest.main()

