from __future__ import annotations
import json, sys
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"scripts"))
from ej_capacity_runner_dispatch_v1 import DispatchError  # noqa:E402
from ej_capacity_runner_dispatch_v2 import verify_launch_manifest  # noqa:E402
from execution_environment import sha256_file  # noqa:E402
from run_ej_capacity_dispatch_v2 import runtime_model_started  # noqa:E402
RUNNER=ROOT/"scripts/run_ej_capacity_dispatch_v2.py"

def write(path,value): path.write_text(json.dumps(value,sort_keys=True)+"\n",encoding="utf-8")
def setup(tmp_path, capable=True):
    fixture=tmp_path/"fixture.json"; write(fixture,{"x":1}); schedule=tmp_path/"schedule.json"; write(schedule,{"experiment_namespace":"NSV2","entries":[]}); policy=tmp_path/"policy.json"; write(policy,{"v":2}); dp=tmp_path/"dispatch.json"; write(dp,{"protocol_id":"DP2"}); ep=tmp_path/"execution.json"; write(ep,{"protocol_id":"EP2",**({"measurement_envelope":{}} if capable else {})}); manifest=tmp_path/"manifest.json"; write(manifest,{"workloads":[]}); schema=tmp_path/"schema.json"; write(schema,{"type":"object"})
    value={"experiment_id":"X","namespace":"NSV2","repository_root":str(tmp_path),"runner":{"path":str(RUNNER),"sha256":sha256_file(RUNNER)},"schedule":{"path":str(schedule),"sha256":sha256_file(schedule)},"policy":{"path":str(policy),"sha256":sha256_file(policy)},"dispatch_protocol":{"path":str(dp),"sha256":sha256_file(dp)},"dispatch_protocol_id":"DP2","execution_protocol":{"path":str(ep),"sha256":sha256_file(ep)},"execution_protocol_id":"EP2","workload_manifest":{"path":str(manifest),"sha256":sha256_file(manifest)},"observation_schema":{"path":str(schema),"sha256":sha256_file(schema)}}; path=tmp_path/"launch.json"; write(path,value); return path,value
def test_separate_protocol_roles_pass(tmp_path): assert verify_launch_manifest(*setup(tmp_path)[:1],RUNNER)["execution_protocol_id"]=="EP2"
def test_readiness_protocol_cannot_be_execution_protocol(tmp_path):
    path,_=setup(tmp_path,False)
    with pytest.raises(DispatchError,match="capability"): verify_launch_manifest(path,RUNNER)
def test_execution_protocol_hash_drift_fails(tmp_path):
    path,value=setup(tmp_path); value["execution_protocol"]["sha256"]="0"*64; write(path,value)
    with pytest.raises(DispatchError): verify_launch_manifest(path,RUNNER)
def test_model_started_requires_runtime_lifecycle(tmp_path):
    assert runtime_model_started(tmp_path,1) is False
    path=tmp_path/"lifecycle/POSITION-001.jsonl"; path.parent.mkdir(); path.write_text(json.dumps({"event":"MODEL_STARTING"})+"\n"); assert runtime_model_started(tmp_path,1) is False
    path.write_text(path.read_text()+json.dumps({"event":"MODEL_STARTED"})+"\n"); assert runtime_model_started(tmp_path,1) is True
