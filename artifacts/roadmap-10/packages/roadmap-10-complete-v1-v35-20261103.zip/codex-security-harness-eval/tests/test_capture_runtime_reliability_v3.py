from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import capture_runtime_reliability_v1 as base  # noqa: E402
import capture_runtime_reliability_v3 as v3  # noqa: E402
from irac_v2_runtime import logical_messages  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_v3_change_boundary_is_only_selftest_capture_isolation():
    value = load(ROOT / "protocol" / "CAPTURE_RUNTIME_RELIABILITY_V3.json")
    ancestry = value["ancestry"]
    assert ancestry["v2_status"] == "FAIL_LOCKED_IMMUTABLE_NO_RETRY"
    assert ancestry["change"] == "SELFTEST_CAPTURE_ISOLATION_BEFORE_MODEL_ADMISSION"
    assert ancestry["websocket_capture_changed"] is False
    assert ancestry["classifier_changed"] is False
    assert ancestry["finalizer_changed"] is False
    assert ancestry["scientific_components_changed"] is False
    assert value["decision"]["variance_identity_creation"] == "FORBIDDEN"


def test_v3_schedule_is_fixed_schema_compatible_and_unique():
    value = load(ROOT / "calibration" / "capture-runtime-reliability-v3" / "SCHEDULE.json")
    assert [row["position"] for row in value["entries"]] == list(range(1, 13))
    assert len({row["sample_id"] for row in value["entries"]}) == 12
    assert all(re.fullmatch(r"^IRAC2[A-Z0-9-]+$", row["sample_id"]) for row in value["entries"])
    assert value["retry_count"] == 0
    assert value["replacement_count"] == 0


def test_same_proxy_selftest_is_archived_before_model_admission(tmp_path: Path):
    context = v3.CaptureRuntimeContextV3(root=tmp_path, position=1, sample_id="IRAC2CRRV3-001")
    context.initialize()
    capture = tmp_path / "capture"
    handle = context.start_proxy(capture, context.sample_id)
    try:
        handle.assert_model_allowed()
        archive = tmp_path / "readiness-selftest"
        attestation = load(archive / "SELFTEST_ISOLATION_ATTESTATION.json")
        assert attestation["status"] == "SELFTEST_CAPTURE_ISOLATED"
        assert attestation["logical_messages_archived"] >= 1
        assert attestation["model_capture_logical_messages_after_isolation"] == 0
        assert logical_messages(capture) == []
        assert any(row.get("event") == "SELFTEST_CAPTURE_ISOLATED" for row in base.read_lifecycle(context.journal_path))
    finally:
        handle.stop()


def test_isolation_refuses_empty_or_stale_archive(tmp_path: Path):
    capture = tmp_path / "capture"
    capture.mkdir()
    try:
        v3.isolate_selftest_capture(capture, tmp_path / "archive")
    except base.CaptureNotReady as error:
        assert "EMPTY" in str(error)
    else:
        raise AssertionError("empty selftest capture was not refused")


def test_v2_postmortem_is_operational_only():
    value = load(ROOT / "postmortems" / "capture-runtime-reliability-v2-20261006" / "REPORT.json")
    assert value["positions_with_same_classifier_fatal"] == 12
    assert value["fatal_error"] == "UNKNOWN_CLIENT_ENVELOPE:capture.runtime.selftest"
    assert value["scientific_fields_inspected"] is False

