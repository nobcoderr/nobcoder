from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import freeze_irac_v2_readiness_r2_aborted_smoke as freezer  # noqa: E402


class IracV2ReadinessR2AbortedSmokeTests(unittest.TestCase):
    def test_pre_cleanup_result_is_not_authoritative_pass(self) -> None:
        result = json.loads((freezer.SMOKE / "RESULT.json").read_text())
        lock = json.loads(freezer.LOCK.read_text())
        self.assertEqual("PASS", result["status"])
        self.assertEqual("ABORTED_POST_EXECUTION_CLEANUP_FAILURE", lock["authoritative_smoke_status"])
        self.assertFalse(lock["official_execution_authorized"])
        self.assertFalse((freezer.SMOKE / "LOCK.json").exists())

    def test_aborted_root_verifies(self) -> None:
        self.assertEqual("PASS", freezer.verify()["status"])


if __name__ == "__main__":
    unittest.main()
