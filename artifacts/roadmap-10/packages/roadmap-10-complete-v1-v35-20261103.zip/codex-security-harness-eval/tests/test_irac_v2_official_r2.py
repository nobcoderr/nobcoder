from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL_R2.json"
OLD = ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL.json"
SCHEDULE = ROOT / "calibration" / "initial-request-accounting-characterization-v2-official-r2" / "SCHEDULE.json"


def digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def test_scientific_decision_tree_is_unchanged() -> None:
    current = json.loads(PROTOCOL.read_text())
    old = json.loads(OLD.read_text())
    assert digest(current["decision_tree"]) == digest(old["decision_tree"])
    assert digest(current["decision_tree"]) == "2f3861aac87e7cadf7fc3923225c120a41ccfad0a8a8495e733dc918b1b2b8bd"


def test_new_schedule_is_balanced_complete_and_no_retry() -> None:
    schedule = json.loads(SCHEDULE.read_text())
    entries = schedule["entries"]
    assert [row["position"] for row in entries] == list(range(1, 13))
    assert len({row["sample_id"] for row in entries}) == 12
    assert Counter(row["condition"] for row in entries) == {
        "EMPTY_START": 4,
        "MODEL_CACHE_ONLY": 4,
        "MODEL_PLUS_APPS_CACHE": 4,
    }
    assert schedule["retry_count"] == schedule["replacement_count"] == 0
    assert schedule["interim_analysis"] is False


def test_protocol_requires_all_valid_and_finalized() -> None:
    value = json.loads(PROTOCOL.read_text())
    assert value["validity_gate"]["required_valid_completed"] == "12/12"
    assert value["validity_gate"]["required_finalized"] == "12/12"
    assert value["validity_gate"]["failure_outcome"] == "MEASUREMENT_INCOMPLETE_IMMUTABLE_NEVER_ANALYZE"
    assert value["execution_discipline"]["interim_request_hash_or_usage_inspection"] == "FORBIDDEN"

