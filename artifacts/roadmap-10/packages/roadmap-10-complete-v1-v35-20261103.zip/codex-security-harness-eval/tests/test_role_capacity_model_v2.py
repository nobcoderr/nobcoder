from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "derive_role_capacity_model_v2.py"
SPEC = importlib.util.spec_from_file_location("role_capacity_v2", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class RoleCapacityModelV2Tests(unittest.TestCase):
    def test_researcher_buckets_are_frozen_and_total(self) -> None:
        values = {
            0: "lt30000",
            29999: "lt30000",
            30000: "30000_30999",
            30999: "30000_30999",
            31000: "31000_33999",
            33999: "31000_33999",
            34000: "34000_35999",
            35999: "34000_35999",
            36000: "36000_37999",
            37999: "36000_37999",
            38000: "gte38000",
        }
        for prompt_bytes, expected in values.items():
            self.assertEqual(MODULE.researcher_bucket(prompt_bytes), expected)

    def test_derivation_uses_five_percent_floor_and_rounding(self) -> None:
        protocol = MODULE.load_json(MODULE.PROTOCOL)
        base = {
            "source_experiment": "TEST",
            "source_run": "TEST",
            "invocation_id": "I",
            "prompt_bytes": 10000,
            "context_bucket": "all",
            "old_reservation": {},
            "old_overshoot_dimensions": [],
            "source_terminal_state": "SETTLED",
            "validity": "ELIGIBLE_DEVELOPMENT_OBSERVATION",
        }
        rows = []
        for role in ("mapper", "reproducer"):
            rows.append({**base, "role": role, "invocation_id": role, "actual_total_input_tokens": 100000, "actual_noncached_input_tokens": 20000, "actual_output_tokens": 1000, "actual_reasoning_tokens": 1000})
        for index, bucket in enumerate(protocol["researcher_context_buckets"]):
            rows.append({**base, "role": "researcher", "invocation_id": f"R{index}", "prompt_bytes": bucket["prompt_bytes_gte"], "context_bucket": bucket["id"], "actual_total_input_tokens": 100000, "actual_noncached_input_tokens": 20000, "actual_output_tokens": 1000, "actual_reasoning_tokens": 1000})
        policy = MODULE.derive_policy(protocol, rows)
        mapper = next(item for item in policy["groups"] if item["role"] == "mapper")
        self.assertEqual(mapper["request"]["total_input_tokens"], 105000)
        self.assertEqual(mapper["request"]["noncached_input_tokens"], 25000)
        self.assertEqual(mapper["request"]["output_tokens"], 1500)

    def test_real_dataset_has_all_roles_and_no_conflicting_duplicates(self) -> None:
        protocol = MODULE.load_json(MODULE.PROTOCOL)
        rows = MODULE.build_dataset(protocol)
        self.assertGreaterEqual(len(rows), 100)
        self.assertEqual({row["role"] for row in rows}, set(MODULE.AFFECTED_ROLES))
        keys = {(row["source_experiment"], row["source_run"], row["invocation_id"]) for row in rows}
        self.assertEqual(len(keys), len(rows))


if __name__ == "__main__":
    unittest.main()
