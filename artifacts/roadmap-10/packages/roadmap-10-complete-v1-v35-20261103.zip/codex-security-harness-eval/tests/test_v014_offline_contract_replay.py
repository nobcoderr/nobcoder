from __future__ import annotations

import unittest

from scripts.run_v014_offline_contract_replay import (
    build_result,
    replay_terminal_code,
    run_terminal_code,
    simulate_queue,
)


class V014OfflineContractReplayTests(unittest.TestCase):
    def test_run_terminal_mapping_is_fail_closed(self) -> None:
        self.assertEqual(run_terminal_code("TIMEOUT"), "BLOCKED_TIMEOUT")
        self.assertEqual(run_terminal_code("BUDGET_EXHAUSTED"), "BLOCKED_BUDGET")
        self.assertEqual(run_terminal_code("INFRA_FAILURE"), "BLOCKED_INFRA")
        self.assertEqual(run_terminal_code("unknown"), "BLOCKED_RUN_TERMINAL")

    def test_nonpass_worker_and_queue_defects_become_terminal(self) -> None:
        self.assertEqual(
            replay_terminal_code({"first_cause": "TERMINAL_STATE_DEFECT", "run_terminal": "BLOCKED"}),
            "BLOCKED_WORKER_RESULT",
        )
        self.assertEqual(
            replay_terminal_code({"first_cause": "QUEUE_DEADLOCK", "run_terminal": "TIMEOUT"}),
            "BLOCKED_TIMEOUT",
        )

    def test_fifo_queue_releases_each_owner(self) -> None:
        candidates = ["A", "B", "C"]
        result = simulate_queue(candidates, {item: "BLOCKED_WORKER_RESULT" for item in candidates})
        admitted = [row["candidate_id"] for row in result["transitions"] if row["event"] == "ADMITTED_WITH_ESCROW"]
        self.assertEqual(admitted, candidates)
        self.assertEqual(set(result["terminal"]), set(candidates))
        self.assertIsNone(result["active_after"])
        self.assertEqual(result["queued_after"], [])

    def test_frozen_rc1_replay_meets_every_gate(self) -> None:
        result = build_result()
        self.assertEqual(result["status"], "PASS_LOCKABLE")
        self.assertEqual(result["historical_candidates_preserved"], 33)
        self.assertEqual(result["structural_feasible_paths"], 33)
        self.assertTrue(all(value == "PASS" for value in result["checks"].values()))


if __name__ == "__main__":
    unittest.main()
