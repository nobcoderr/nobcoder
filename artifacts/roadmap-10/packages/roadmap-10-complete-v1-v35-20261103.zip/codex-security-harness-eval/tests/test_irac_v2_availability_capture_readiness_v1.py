from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_availability_capture_core_v1 import classify_operational  # noqa: E402
from run_irac_v2_availability_capture_readiness_v1 import score  # noqa: E402


class AvailabilityCaptureReadinessTests(unittest.TestCase):
    def test_protocol_precommits_strict_thresholds(self) -> None:
        protocol = json.loads((ROOT / "protocol" / "IRAC_V2_AVAILABILITY_CAPTURE_READINESS_V1.json").read_text())
        self.assertEqual(24, protocol["schedule"]["positions"])
        self.assertEqual(1.0, protocol["precommitted_thresholds"]["minimum_accepted_proportion"])
        self.assertEqual(0.0, protocol["precommitted_thresholds"]["maximum_capacity_rejection_proportion"])
        self.assertEqual(30, protocol["freshness_contract"]["maximum_seconds_between_available_preflight_completion_and_official_invocation_start"])

    def test_provider_rejection_precedes_capture_label(self) -> None:
        classification = classify_operational(
            provider={"status": "PASS", "provider_outcome": "REJECTED", "provider_error_class": "MODEL_CAPACITY"},
            exit_code=1, timed_out=False, websocket_established=True, capture_integrity="PASS",
            selected_count=1, payload_mutations=0, schema_valid=False, session_id=None, turns=0, tools=0,
        )
        self.assertEqual("PROVIDER_CAPACITY_REJECTION", classification)

    def test_capture_and_classifier_failures_are_distinct(self) -> None:
        accepted = {"status": "PASS", "provider_outcome": "ACCEPTED", "provider_error_class": None}
        base = dict(provider=accepted, exit_code=0, timed_out=False, websocket_established=True, payload_mutations=0, schema_valid=True, session_id="s", turns=1, tools=0)
        self.assertEqual("CAPTURE_FAILURE", classify_operational(**base, capture_integrity="FAIL", selected_count=1))
        self.assertEqual("CLASSIFIER_FAILURE", classify_operational(**base, capture_integrity="PASS", selected_count=2))

    def test_score_passes_only_24_perfect_probes(self) -> None:
        rows = [{"classification": "ACCEPTED", "accepted": True, "capture_reliable": True, "session_id": f"s{i}", "finalization_pass": True} for i in range(24)]
        result = score(rows, 100.0, {"status": "PASS", "frozen_drift": []})
        self.assertEqual("PASS_LOCKED", result["status"])
        rows[7] = {**rows[7], "classification": "PROVIDER_CAPACITY_REJECTION", "accepted": False, "capture_reliable": False}
        result = score(rows, 100.0, {"status": "PASS", "frozen_drift": []})
        self.assertEqual("FAIL_LOCKED", result["status"])
        self.assertFalse(result["official_r3_identity_creation_authorized"])

    def test_schedule_exactly_once(self) -> None:
        schedule = json.loads((ROOT / "calibration" / "irac-v2-availability-capture-readiness-v1" / "SCHEDULE.json").read_text())
        self.assertEqual(list(range(1, 25)), [entry["position"] for entry in schedule["entries"]])
        self.assertEqual(24, len({entry["probe_id"] for entry in schedule["entries"]}))


if __name__ == "__main__":
    unittest.main()
