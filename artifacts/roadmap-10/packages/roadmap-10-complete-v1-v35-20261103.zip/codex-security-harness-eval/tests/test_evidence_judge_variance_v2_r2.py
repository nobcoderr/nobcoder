import json
from pathlib import Path

import jsonschema


ROOT = Path(__file__).resolve().parents[1]
V2_PROTOCOL = ROOT / "protocol" / "EVIDENCE_JUDGE_VARIANCE_DECOMPOSITION_V2.json"
R2_PROTOCOL = ROOT / "protocol" / "EVIDENCE_JUDGE_VARIANCE_DECOMPOSITION_V2_R2.json"
V2_SCHEDULE = ROOT / "calibration" / "evidence-judge-variance-decomposition-v2" / "SCHEDULE.json"
R2_SCHEDULE = ROOT / "calibration" / "evidence-judge-variance-decomposition-v2" / "SCHEDULE_R2.json"
CORE_SCHEMA = ROOT / "schemas" / "evidence-judge-variance-core-observation-v2-r2.schema.json"
V2_RAW_LOCK = Path("/home/nobcoder/pilot-runs/evidence-judge-variance-decomposition-v2-20261005/RAW_EXECUTION_LOCK.json")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_r2_statistical_and_scientific_contract_is_unchanged():
    v2, r2 = load(V2_PROTOCOL), load(R2_PROTOCOL)
    for key in (
        "classification", "objective", "prohibitions", "runtime", "observer", "design",
        "measurement_envelope", "measurement_fields", "analysis_precommit",
        "eligibility_and_stopping", "execution_discipline", "post_measurement",
    ):
        assert r2[key] == v2[key]


def test_r2_schedule_has_same_order_and_fresh_identity():
    v2, r2 = load(V2_SCHEDULE)["entries"], load(R2_SCHEDULE)["entries"]
    assert len(v2) == len(r2) == 54
    for left, right in zip(v2, r2):
        assert {key: left[key] for key in ("position", "fixture_id", "family", "repetition")} == {
            key: right[key] for key in ("position", "fixture_id", "family", "repetition")
        }
        assert right["sample_id"] == f"IRAC2EJVDV2-{right['position'] + 100:03d}"
        assert right["sample_id"] != left["sample_id"]


def test_core_schema_accepts_full_variance_position_and_repetition():
    schema = load(CORE_SCHEMA)
    assert schema["properties"]["schedule_position"]["maximum"] == 54
    assert schema["properties"]["repetition"]["maximum"] == 12
    jsonschema.Draft202012Validator.check_schema(schema)


def test_v2_historical_identity_is_never_analyze():
    lock = load(V2_RAW_LOCK)
    assert lock["execution_status"] == "MEASUREMENT_INCOMPLETE_IMMUTABLE_NEVER_ANALYZE"
    assert lock["analysis_authorized"] is False
