from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_v2_change_boundary_is_sample_namespace_only():
    value = load(ROOT / "protocol" / "CAPTURE_RUNTIME_RELIABILITY_V2.json")
    assert value["ancestry"]["v1_status"] == "FAIL_LOCKED_IMMUTABLE_NO_RETRY"
    assert value["ancestry"]["change"] == "SCHEDULE_SAMPLE_ID_NAMESPACE_ONLY"
    assert value["ancestry"]["capture_runtime_implementation_changed"] is False
    assert value["ancestry"]["scientific_components_changed"] is False
    assert value["ancestry"]["thresholds_changed"] is False
    assert value["decision"]["variance_identity_creation"] == "FORBIDDEN"


def test_v2_schedule_satisfies_inherited_schema_namespace():
    value = load(ROOT / "calibration" / "capture-runtime-reliability-v2" / "SCHEDULE.json")
    pattern = re.compile(r"^IRAC2[A-Z0-9-]+$")
    assert [row["position"] for row in value["entries"]] == list(range(1, 13))
    assert all(pattern.fullmatch(row["sample_id"]) for row in value["entries"])
    assert len({row["sample_id"] for row in value["entries"]}) == 12
    assert value["retry_count"] == 0
    assert value["replacement_count"] == 0


def test_v1_postmortem_is_operational_only():
    value = load(ROOT / "postmortems" / "capture-runtime-reliability-v1-20261006" / "REPORT.json")
    assert value["positions_with_same_schema_failure"] == 12
    assert value["failure_class"] == "OPERATIONAL_SCHEMA_NAMESPACE_INCOMPATIBILITY"
    assert value["scientific_fields_inspected"] is False
    assert value["provider_stability_established"] is False

