from __future__ import annotations

import json
import socket
import stat
import sys
import threading
import time
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import capture_runtime_reliability_v1 as reliability  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _context(root: Path, position: int = 1) -> reliability.CaptureRuntimeContext:
    value = reliability.CaptureRuntimeContext(root=root, position=position, sample_id=f"CRRV1-{position:03d}")
    value.initialize()
    return value


def _event(context: reliability.CaptureRuntimeContext, event: str) -> None:
    reliability.append_lifecycle(
        context.journal_path,
        event,
        position=context.position,
        sample_id=context.sample_id,
    )


def test_contract_precommits_all_seventeen_synthetic_cases():
    protocol = load(ROOT / "protocol" / "CAPTURE_RUNTIME_RELIABILITY_V1.json")
    assert len(protocol["synthetic_acceptance_matrix"]) == 17
    assert protocol["live_qualification"]["positions"] == 12
    assert protocol["live_qualification"]["retry_count"] == 0
    assert protocol["live_qualification"]["replacement_count"] == 0
    assert protocol["decision"]["variance_identity_creation"] == "FORBIDDEN"


def test_forbidden_components_are_unchanged():
    assert reliability.verify_forbidden_components()["status"] == "PASS"


def test_normal_startup_fragmented_and_multiple_connection_capture(tmp_path: Path):
    context = _context(tmp_path)
    capture = tmp_path / "capture"
    handle = reliability.start_reliable_proxy(
        capture,
        context.sample_id,
        journal_path=context.journal_path,
        readiness_attestation=context.readiness_path,
        position=context.position,
        timeout=20,
        close_grace_seconds=3,
    )
    try:
        handle.assert_model_allowed()
        first = load(context.readiness_path)
        second = reliability.run_local_ws_selftest(handle.port, capture, "SECOND-CONNECTION", timeout=10)
        assert first["status"] == "READY_ATTESTED"
        assert second["status"] == "PASS"
        assert second["fragmented_message"] is True
        established, _ = reliability._connection_counts(capture)
        assert established >= 2
    finally:
        handle.stop()


def test_delayed_startup_wait_helper_passes():
    state = {"ready": False}
    timer = threading.Timer(0.15, lambda: state.update(ready=True))
    timer.start()
    try:
        reliability._wait_for(lambda: state["ready"], 2, "DELAYED_STARTUP_FAILED")
    finally:
        timer.cancel()


def test_bind_failure_fails_closed(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    context = _context(tmp_path)

    def fail(_: int) -> None:
        raise reliability.CaptureNotReady("CAPTURE_ENDPOINT_BIND_FAILURE")

    monkeypatch.setattr(reliability, "assert_endpoint_unoccupied", fail)
    with pytest.raises(reliability.CaptureNotReady, match="BIND_FAILURE"):
        reliability.start_reliable_proxy(
            tmp_path / "capture",
            context.sample_id,
            journal_path=context.journal_path,
            readiness_attestation=context.readiness_path,
            position=context.position,
            requested_port=31337,
        )


def test_occupied_endpoint_fails_closed(tmp_path: Path):
    context = _context(tmp_path)
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(("127.0.0.1", 0))
    listener.listen()
    try:
        with pytest.raises(reliability.CaptureNotReady, match="OCCUPIED"):
            reliability.start_reliable_proxy(
                tmp_path / "capture",
                context.sample_id,
                journal_path=context.journal_path,
                readiness_attestation=context.readiness_path,
                position=context.position,
                requested_port=int(listener.getsockname()[1]),
            )
    finally:
        listener.close()


def test_proxy_exit_before_ready_fails_closed(tmp_path: Path):
    context = _context(tmp_path)
    with pytest.raises(reliability.CaptureNotReady, match="PROXY_EXITED_BEFORE_READY"):
        reliability.start_reliable_proxy(
            tmp_path / "capture",
            context.sample_id,
            journal_path=context.journal_path,
            readiness_attestation=context.readiness_path,
            position=context.position,
            timeout=2,
            command_override=["sh", "-c", "exit 7"],
        )


def test_proxy_exit_after_ready_before_model_fails_closed(tmp_path: Path):
    context = _context(tmp_path)
    handle = reliability.start_reliable_proxy(
        tmp_path / "capture",
        context.sample_id,
        journal_path=context.journal_path,
        readiness_attestation=context.readiness_path,
        position=context.position,
        timeout=20,
        close_grace_seconds=1,
    )
    handle.process.terminate()
    handle.process.wait(timeout=5)
    try:
        with pytest.raises(reliability.CaptureNotReady, match="EXITED_AFTER_READY"):
            handle.assert_model_allowed()
    finally:
        handle.stop()


def test_local_websocket_selftest_failure_is_fail_closed(tmp_path: Path):
    capture = tmp_path / "capture"
    capture.mkdir()
    result = reliability.validate_selftest_capture(capture, "0" * 64)
    assert result["status"] == "FAIL"


def test_stale_capture_artifact_is_refused(tmp_path: Path):
    context = _context(tmp_path)
    (tmp_path / "capture").mkdir()
    with pytest.raises(reliability.CaptureNotReady, match="STALE_CAPTURE_ARTIFACTS"):
        reliability.start_reliable_proxy(
            tmp_path / "capture",
            context.sample_id,
            journal_path=context.journal_path,
            readiness_attestation=context.readiness_path,
            position=context.position,
        )


@pytest.mark.parametrize(
    ("events", "expected", "invocations"),
    [
        ([], "PRE_MODEL_OPERATIONAL_FAILURE", 0),
        (["MODEL_STARTING", "MODEL_STARTED"], "INVALID_OPERATIONAL", 1),
        (["MODEL_STARTING", "MODEL_STARTED", "MODEL_TERMINAL"], "INVALID_OPERATIONAL", 1),
        (
            ["MODEL_STARTING", "MODEL_STARTED", "MODEL_TERMINAL", "CAPTURE_VALIDATED", "OBSERVATION_FINALIZED"],
            "DERIVE_FROM_FINALIZED_OBSERVATION",
            1,
        ),
    ],
)
def test_runner_crash_is_externally_finalized(
    tmp_path: Path, events: list[str], expected: str, invocations: int
):
    context = _context(tmp_path)
    for event in events:
        _event(context, event)
    result = reliability.externally_finalize_incomplete(
        tmp_path,
        journal_path=context.journal_path,
        position=context.position,
        sample_id=context.sample_id,
        failure_class="SYNTHETIC_CRASH",
        failure_detail="precommitted fixture",
    )
    assert result["position_status"]["status"] == expected
    assert result["position_status"]["model_invocation_count"] == invocations
    assert result["position_status"]["analysis_authorized"] is False
    assert reliability.read_lifecycle(context.journal_path)[-1]["event"] == "POSITION_TERMINAL"


def test_external_finalizer_is_idempotent_but_conflicts_are_refused(tmp_path: Path):
    context = _context(tmp_path)
    first = reliability.externally_finalize_incomplete(
        tmp_path,
        journal_path=context.journal_path,
        position=1,
        sample_id=context.sample_id,
        failure_class="PROXY_STARTUP_FAILURE",
        failure_detail="synthetic",
    )
    second = reliability.externally_finalize_incomplete(
        tmp_path,
        journal_path=context.journal_path,
        position=1,
        sample_id=context.sample_id,
        failure_class="PROXY_STARTUP_FAILURE",
        failure_detail="synthetic",
    )
    assert first["finalization"]["idempotent"] is False
    assert second["finalization"]["idempotent"] is True
    with pytest.raises(reliability.CaptureRuntimeError, match="DOUBLE_FINALIZATION_CONFLICT"):
        reliability.externally_finalize_incomplete(
            tmp_path,
            journal_path=context.journal_path,
            position=1,
            sample_id=context.sample_id,
            failure_class="DIFFERENT_FAILURE",
            failure_detail="synthetic",
        )


def test_final_status_is_immutable_and_post_terminal_journal_is_refused(tmp_path: Path):
    context = _context(tmp_path)
    result = reliability.externally_finalize_incomplete(
        tmp_path,
        journal_path=context.journal_path,
        position=1,
        sample_id=context.sample_id,
        failure_class="SYNTHETIC_CRASH",
        failure_detail="artifact mutation fixture",
    )
    status_path = Path(result["path"])
    assert stat.S_IMODE(status_path.stat().st_mode) & 0o222 == 0
    with pytest.raises(reliability.LifecycleJournalError, match="after POSITION_TERMINAL"):
        _event(context, "CAPTURE_VALIDATED")

