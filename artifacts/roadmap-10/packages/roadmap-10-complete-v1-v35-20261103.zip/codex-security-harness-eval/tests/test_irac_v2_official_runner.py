from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_irac_v2_official import classify  # noqa: E402


class OfficialRunnerTests(unittest.TestCase):
    def limits(self):
        return {
            "max_total_input_tokens": 100,
            "max_noncached_input_tokens": 100,
            "max_output_tokens": 100,
            "max_reasoning_tokens": 100,
            "max_wall_time_seconds": 10,
        }

    def usage(self):
        return {"total_input_tokens": 10, "noncached_input_tokens": 10, "output_tokens": 5, "reasoning_tokens": 3}

    def test_valid_completed_requires_every_gate(self) -> None:
        status, compliant, reason = classify(
            exit_code=0, timed_out=False, usage=self.usage(), limits=self.limits(), wall=1,
            schema_valid=True, session_id="s", capture_valid=True, turns=1, tools=0, cache_valid=True,
        )
        self.assertEqual(("VALID_COMPLETED", True, "NORMAL_COMPLETION"), (status, compliant, reason))

    def test_capture_failure_fails_closed(self) -> None:
        status, _, _ = classify(
            exit_code=0, timed_out=False, usage=self.usage(), limits=self.limits(), wall=1,
            schema_valid=True, session_id="s", capture_valid=False, turns=1, tools=0, cache_valid=True,
        )
        self.assertEqual("INVALID_CAPTURE", status)

    def test_overshoot_precedes_completion(self) -> None:
        usage = self.usage()
        usage["reasoning_tokens"] = 101
        status, compliant, _ = classify(
            exit_code=0, timed_out=False, usage=usage, limits=self.limits(), wall=1,
            schema_valid=True, session_id="s", capture_valid=True, turns=1, tools=0, cache_valid=True,
        )
        self.assertEqual("INVALID_OVERSHOOT", status)
        self.assertFalse(compliant)


if __name__ == "__main__":
    unittest.main()
