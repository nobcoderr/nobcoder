from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from acceptance_terminal_cause_v3 import (  # noqa: E402
    classify_terminal_cause,
    queue_return_is_deadlock,
    structured_infrastructure_evidence,
    summarize_nonterminal_candidates,
)


class AcceptanceTerminalCauseV3Tests(unittest.TestCase):
    def test_earliest_causal_event_wins(self) -> None:
        result = classify_terminal_cause([
            {"cause": "TRUE_RESOURCE_OVERSHOOT", "at": "2026-10-07T00:00:01+00:00", "structured": True},
            {"cause": "WALL_TIME_OVERRUN", "at": "2026-10-07T00:00:02+00:00", "structured": True},
        ])
        self.assertEqual(result["primary_cause"], "TRUE_RESOURCE_OVERSHOOT")
        self.assertTrue(result["exactly_one_primary"])

    def test_wall_time_is_not_token_overshoot(self) -> None:
        result = classify_terminal_cause([
            {"cause": "WALL_TIME_OVERRUN", "at": "2026-10-07T00:00:01+00:00", "structured": True}
        ])
        self.assertEqual(result["primary_cause"], "WALL_TIME_OVERRUN")

    def test_model_authored_free_text_is_not_infrastructure(self) -> None:
        semantic = {
            "invalid_infrastructure": True,
            "fatal_statuses": [],
            "fatal_errors": [{"code": "CAPABILITY_UNAVAILABLE", "source": "worker-output.json"}],
        }
        self.assertEqual(structured_infrastructure_evidence(semantic), [])

    def test_structured_provider_error_is_infrastructure(self) -> None:
        semantic = {"structured_provider_errors": [{"class": "MODEL_CAPACITY", "source": "ws-server-event"}]}
        self.assertEqual(structured_infrastructure_evidence(semantic)[0]["status"], "MODEL_CAPACITY")

    def test_late_concurrent_return_after_terminal_is_not_deadlock(self) -> None:
        result = queue_return_is_deadlock(
            worker_returned_at="2026-10-07T00:00:02+00:00",
            candidate_terminal_at="2026-10-07T00:00:01+00:00",
            candidate_terminal_transition_exists=True,
            candidate_nonterminal_after_return=False,
            recovery_transition_possible=False,
            queue_ownership_stuck=False,
        )
        self.assertFalse(result["queue_deadlock"])

    def test_nonterminal_stuck_queue_is_deadlock(self) -> None:
        result = queue_return_is_deadlock(
            worker_returned_at="2026-10-07T00:00:02+00:00",
            candidate_terminal_at=None,
            candidate_terminal_transition_exists=False,
            candidate_nonterminal_after_return=True,
            recovery_transition_possible=False,
            queue_ownership_stuck=True,
        )
        self.assertTrue(result["queue_deadlock"])

    def test_cross_layer_candidate_is_counted_once_semantically(self) -> None:
        result = summarize_nonterminal_candidates(["C-1", "C-2"], ["C-1", "C-2"])
        self.assertEqual(result["cross_layer_observations"], 4)
        self.assertEqual(result["distinct_semantic_candidates"], 2)


if __name__ == "__main__":
    unittest.main()
