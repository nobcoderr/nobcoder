from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_narrow_terminalization_contract_repair_v1.py"
SPEC = importlib.util.spec_from_file_location("terminalization_contract_repair", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_quantiles_use_frozen_linear_interpolation() -> None:
    assert MODULE.quantile([1, 2, 3, 4], 0.50) == 2.5
    assert MODULE.quantile([1, 2, 3, 4], 0.95) == 3.85
    assert MODULE.quantile([], 0.95) is None


def test_reserve_uses_precommitted_formula_without_manual_override() -> None:
    protocol = MODULE.load_protocol()
    rows = [
        {"mechanical_duration_upper_bound_seconds": value}
        for value in (1.0, 1.5, 2.0, 3.2)
    ]
    result = MODULE.derive_reserve(rows, protocol)
    assert result["base_upper_bound_seconds"] == 3.2
    assert result["derived_terminalization_reserve_seconds"] == 15
    assert result["manual_override_applied"] is False


def test_frozen_v015_contract_requires_new_version() -> None:
    protocol = MODULE.load_protocol()
    diff = MODULE.contract_diff(protocol)
    assert diff["retained_behavior"]["quiescence_terminal_sweep"] is True
    assert diff["retained_behavior"]["external_hard_stop_finalizer"] is True
    assert "derived_terminalization_reserve" in diff["new_normative_behavior"]
    assert "remaining_wall_deadline_trigger" in diff["new_normative_behavior"]
    assert diff["version_rule_result"] == "V0.1.6_CONTRACT_FIRST"


def test_fixture_contract_has_all_precommitted_cases() -> None:
    protocol = MODULE.load_protocol()
    result = MODULE.fixture_spec(protocol, 15)
    assert len(result["fixtures"]) == 10
    assert {row["fixture_id"] for row in result["fixtures"]} == {
        "A_NO_CANDIDATES",
        "B_ALL_KILL",
        "C_ONE_REPORT_READY",
        "D_ACTIVE_AT_DEADLINE",
        "E_QUEUED_AT_DEADLINE",
        "F_COMPLETED_CLOSURE_RESULT",
        "G_RESERVE_REACHED",
        "H_FINISH_BEFORE_HARD_STOP",
        "I_TERMINALIZATION_STALL",
        "J_CRASH_RESUME",
    }
    assert all(
        row["expected_invariants"]["finalized_implies_zero_nonterminal_candidates"]
        for row in result["fixtures"]
    )


def test_protocol_and_all_frozen_inputs_are_intact() -> None:
    protocol = MODULE.load_protocol()
    assert MODULE.verify_inputs(protocol) == []


def test_replay_gate_semantics_require_plain_runs_to_remain_unchanged() -> None:
    expected = MODULE.load_json(MODULE.PROTOCOL)["required_replay_gate_semantics"]
    assert expected["plain_runs_changed"] is False
    assert all(type(value) is bool for value in expected.values())
    assert MODULE.replay_gate_status(dict(expected), expected) is True
    wrong = dict(expected, plain_runs_changed=True)
    assert MODULE.replay_gate_status(wrong, expected) is False
