from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from pathlib import Path

import jsonschema


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_module(name: str, relative: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


VERIFY = load_module("verify_ej_v2", "scripts/verify_evidence_judge_characterization_protocol_v2.py")
DERIVER = load_module("derive_ej_v2", "scripts/derive_evidence_judge_capacity_model_v2.py")
RUNNER = load_module("run_ej_v2", "scripts/run_evidence_judge_characterization_v2.py")


class EvidenceJudgeCharacterizationV2ProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result = VERIFY.verify()
        cls.protocol = json.loads(VERIFY.PROTOCOL.read_text())

    def test_preflight_passes_without_invocation_or_product_change(self) -> None:
        self.assertEqual(self.result["status"], "PASS", self.result["errors"])
        self.assertEqual(self.result["model_invocations"], 0)
        self.assertEqual(self.result["product_changes"], 0)
        self.assertEqual(self.result["v1_mutations"], 0)

    def test_only_noncached_characterization_ceiling_changes(self) -> None:
        check = self.result["checks"]["uncensored_measurement_envelope"]
        self.assertEqual(check["status"], "PASS")
        old = check["v1"]
        new = check["v2"]
        changed = {key for key in old if old[key] != new[key]}
        self.assertEqual(changed, {"max_noncached_input_tokens"})
        self.assertEqual(new["max_noncached_input_tokens"], new["max_total_input_tokens"])

    def test_workloads_are_byte_identical_and_predictors_are_pre_invocation(self) -> None:
        self.assertEqual(self.result["checks"]["workloads_and_predictors"]["status"], "PASS")
        manifest = json.loads(RUNNER.WORKLOAD_MANIFEST.read_text())
        self.assertEqual(manifest["input_construction"], "BYTE_IDENTICAL_TO_V1")
        self.assertFalse(manifest["predictor_tokenization"]["provider_token_equivalence"])
        self.assertEqual(len(manifest["workloads"]), 12)

    def test_estimator_and_closure_rules_are_precommitted(self) -> None:
        self.assertEqual(
            set(self.protocol["estimator_derivation"]["candidate_models"]),
            {"TIER_TOLERANCE_V1", "CONTEXT_AFFINE_UPPER_V1"},
        )
        gate = self.protocol["full_bundle_replay_gate_precommit"]
        self.assertEqual(gate["maximum_verification_starvation"], 0)
        self.assertEqual(gate["required_terminal_path_capacity_fraction"], 1.0)
        self.assertFalse(self.protocol["post_characterization"]["v0.1.3_implementation_authorized"])

    def test_v2_sample_schema_accepts_frozen_measurement_shape(self) -> None:
        manifest = json.loads(RUNNER.WORKLOAD_MANIFEST.read_text())
        row = manifest["workloads"][0]
        token_values = {
            "total_input_tokens": 10,
            "noncached_input_tokens": 10,
            "output_tokens": 2,
            "reasoning_tokens": 1,
        }
        sample = {
            "schema_version": 1,
            "sample_id": "EJ2-CAP-01",
            "workload_id": row["workload_id"],
            "tier": row["tier"],
            "variant": row["variant"],
            "status": "VALID_COMPLETED",
            "context": row["measurements"],
            "capture_reservation": token_values,
            "actual": dict(token_values, cached_input_tokens=0),
            "wall_time_seconds": 1.0,
            "termination": {"exit_code": 0, "reason": "NORMAL_COMPLETION"},
            "artifacts": {str(index): "a" * 64 for index in range(5)},
        }
        schema = json.loads(RUNNER.SAMPLE_SCHEMA.read_text())
        jsonschema.Draft202012Validator(schema).validate(sample)


class EvidenceJudgeCharacterizationV2DeriverTests(unittest.TestCase):
    @staticmethod
    def sample(tier: str, variant: int, scale: int) -> dict:
        jitter = variant - 2
        return {
            "sample_id": f"{tier}-{variant}",
            "tier": tier,
            "variant": variant,
            "context": {"prompt_lexical_tokens": 1000 * scale + variant},
            "actual": {
                "total_input_tokens": 10000 * scale + jitter,
                "noncached_input_tokens": 8000 * scale + jitter,
                "output_tokens": 400 * scale + jitter,
                "reasoning_tokens": 200 * scale + jitter,
            },
            "wall_time_seconds": 10 * scale + jitter / 10,
        }

    def setUp(self) -> None:
        self.protocol = json.loads(DERIVER.PROTOCOL.read_text())
        self.samples = [
            self.sample(tier, variant, scale)
            for tier, scale in (("SMALL", 1), ("MEDIUM", 2), ("LARGE", 3))
            for variant in range(1, 5)
        ]

    def test_both_frozen_model_families_cross_validate(self) -> None:
        for family in DERIVER.MODEL_FAMILIES:
            result = DERIVER.cross_validate(family, self.samples, self.protocol)
            self.assertEqual(len(result["folds"]), 4)
            self.assertEqual(len(result["out_of_fold_predictions"]), 12)
            self.assertEqual(result["overshoot_count"], 0)

    def test_selection_is_deterministic(self) -> None:
        results = [DERIVER.cross_validate(family, self.samples, self.protocol) for family in DERIVER.MODEL_FAMILIES]
        eligible = [row for row in results if row["eligible"]]
        first = min(eligible, key=DERIVER.selection_score)["family"]
        second = min(reversed(eligible), key=DERIVER.selection_score)["family"]
        self.assertEqual(first, second)

    def test_held_out_tail_is_rejected(self) -> None:
        samples = list(self.samples)
        samples[-1] = self.sample("LARGE", 4, 30)
        result = DERIVER.cross_validate("TIER_TOLERANCE_V1", samples, self.protocol)
        self.assertGreater(result["overshoot_count"], 0)
        self.assertFalse(result["eligible"])


if __name__ == "__main__":
    unittest.main()
