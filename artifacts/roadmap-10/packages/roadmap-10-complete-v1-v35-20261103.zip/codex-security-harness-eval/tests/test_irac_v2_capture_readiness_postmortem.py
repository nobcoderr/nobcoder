from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postmortem_irac_v2_capture_readiness as postmortem  # noqa: E402


class IracV2CaptureReadinessPostmortemTests(unittest.TestCase):
    def test_failure_is_smoke_contract_not_capture_transport(self) -> None:
        result = postmortem.build_result()
        self.assertEqual("REAL_CODEX_SMOKE_CONTRACT_INVALID_NOT_CAPTURE_TRANSPORT_FAILURE", result["root_cause"])
        self.assertTrue(result["capture_conclusion"]["websocket_observation_layer_functional"])
        self.assertTrue(result["failure_components"]["INVALID_OUTPUT_SCHEMA"]["established"])
        self.assertTrue(result["failure_components"]["SENTINEL_CARDINALITY_PRECOMMIT_MISMATCH"]["established"])

    def test_fail_closed_authorizations(self) -> None:
        result = postmortem.build_result()
        self.assertEqual("IMMUTABLE_FAIL_NO_RETRY", result["disposition"]["irac_v2_readiness_attempt"])
        self.assertEqual("DENIED", result["disposition"]["official_irac_v2_execution"])
        self.assertTrue(all(value is False for value in result["authorizations"].values()))
        self.assertEqual(0, result["model_invocations_added_by_postmortem"])
        self.assertEqual("INSUFFICIENT_DATA", result["claim"])


if __name__ == "__main__":
    unittest.main()
