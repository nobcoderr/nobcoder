from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import run_v016_acceptance as acceptance  # noqa: E402
from score_v016_acceptance import closure_observability  # noqa: E402


class V016AcceptanceTests(unittest.TestCase):
    def test_schedule_is_balanced_interleaved_deterministic_and_fresh(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        first = acceptance.schedule(protocol, "e" * 64)
        second = acceptance.schedule(protocol, "e" * 64)
        self.assertEqual(first, second)
        self.assertEqual([row["position"] for row in first], list(range(1, 31)))
        self.assertEqual(sum(row["system"] == "plain-minimal" for row in first), 15)
        self.assertEqual(sum(row["system"] == "harness-v0.1.6" for row in first), 15)
        for index in range(0, 30, 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_frozen_thresholds_and_terminalization_gates(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        gate = protocol["development_e2e"]
        self.assertEqual(gate["minimum_accepted_terminals_per_system"], 12)
        self.assertEqual(gate["maximum_wall_time_overruns_per_system"], 0)
        self.assertEqual(gate["maximum_true_token_overshoots_per_system"], 0)
        terminal = protocol["terminalization_acceptance"]
        self.assertEqual(terminal["maximum_terminalization_budget_exceeded"], 0)
        self.assertEqual(terminal["maximum_nonterminal_candidates_at_run_end"], 0)
        self.assertEqual(terminal["maximum_queue_left_open_at_run_end"], 0)
        self.assertEqual(terminal["terminalization_reserve_seconds"], 15)
        self.assertEqual(terminal["outer_hard_stop_seconds"], 900)
        self.assertEqual(protocol["post_acceptance_rescue"], "FORBIDDEN_FOR_THIS_IDENTITY")

    def test_missing_database_fails_closed_for_new_terminalization_metrics(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            result = closure_observability(Path(temporary))
        self.assertEqual(result["queue_deadlocks"], 1)
        self.assertEqual(result["terminalization_budget_exceeded"], 1)
        self.assertEqual(result["queue_left_open_at_run_end"], 1)
        self.assertEqual(result["terminalization_finalized_missing"], 1)


if __name__ == "__main__":
    unittest.main()
