from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_v015_rc1_walltime_postmortem.py"
SPEC = importlib.util.spec_from_file_location("v015_walltime_postmortem", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_linear_interpolation_quantile() -> None:
    assert MODULE.quantile([100, 200, 300, 400], 0.50) == 250.0
    assert MODULE.quantile([100, 200, 300, 400], 0.75) == 325.0
    assert MODULE.quantile([], 0.90) is None


def test_meaningful_progress_deduplicates_semantic_identity() -> None:
    rows = MODULE.mark_progress(
        [
            {"event_type": "HYPOTHESIS_CREATED", "hypothesis_id": "H-1", "monotonic_seconds": 10, "sequence": 1},
            {"event_type": "HYPOTHESIS_CREATED", "hypothesis_id": "H-1", "monotonic_seconds": 20, "sequence": 2},
            {"event_type": "TEST_COMPLETED", "command_id": "C-1", "exit_code": 0, "monotonic_seconds": 30, "sequence": 3},
            {"event_type": "RUN_TERMINATED", "monotonic_seconds": 40, "sequence": 4},
        ],
        40,
    )
    assert [row["meaningful_progress"] for row in rows] == [True, False, True, False]


def test_terminalization_majority_selects_frozen_branch_d() -> None:
    wall_rows = []
    for position in range(1, 14):
        wall_rows.append(
            {
                "system": "harness-v0.1.5",
                "primary_class": "TERMINALIZATION_OVERRUN",
                "active_worker_roles": "",
                "active_worker_count": 0,
            }
        )
    wall_rows.append(
        {
            "system": "harness-v0.1.5",
            "primary_class": "QUEUE_WAIT",
            "active_worker_roles": "",
            "active_worker_count": 0,
        }
    )
    for _ in range(5):
        wall_rows.append(
            {
                "system": "plain-minimal",
                "primary_class": "PRODUCTIVE_AT_HARD_STOP",
                "active_worker_roles": "",
                "active_worker_count": 0,
            }
        )
    distributions = {
        "plain-minimal": {"count": 9, "p90_seconds": 190.0, "maximum_seconds": 200.0},
        "harness-v0.1.5": {"count": 0, "p90_seconds": None, "maximum_seconds": None},
    }
    decision = MODULE.choose_decision(wall_rows, distributions)
    assert decision["branch"] == "D"
    assert decision["label"] == "FINALIZATION_OR_TERMINALIZATION_LATENCY"
    assert decision["next"] == "NARROW_TERMINALIZATION_CONTRACT_REPAIR"


def test_protocol_lock_and_authoritative_sources_are_intact() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    assert MODULE.verify_frozen_sources(protocol) == []

