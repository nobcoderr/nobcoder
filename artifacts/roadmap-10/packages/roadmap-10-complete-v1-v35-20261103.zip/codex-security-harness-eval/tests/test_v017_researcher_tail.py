from __future__ import annotations

import json
import unittest

from scripts.derive_v017_researcher_tail import POLICY, TARGET, derive


class V017ResearcherTailTests(unittest.TestCase):
    def test_locked_formula_rederives_only_the_authorized_bucket(self) -> None:
        result = derive()
        self.assertEqual(result["target"], {"role": "researcher", "context_bucket": "36000_37999"})
        self.assertEqual(result["prior_request"]["reasoning_tokens"], 7500)
        self.assertEqual(result["derived_request"]["reasoning_tokens"], 8500)
        self.assertEqual(result["derived_request"]["output_tokens"], 11000)
        self.assertFalse(result["manual_override"])

    def test_no_other_group_or_dimension_changes(self) -> None:
        policy = json.loads(POLICY.read_text(encoding="utf-8"))
        result = derive()
        changed: list[tuple[str, str, str]] = []
        for group in policy["groups"]:
            key = (group["role"], group["context_bucket"])
            proposed = result["derived_request"] if key == TARGET else group["request"]
            for field, previous in group["request"].items():
                if int(proposed[field]) != int(previous):
                    changed.append((*key, field))
        self.assertEqual(changed, [("researcher", "36000_37999", "reasoning_tokens")])


if __name__ == "__main__":
    unittest.main()
