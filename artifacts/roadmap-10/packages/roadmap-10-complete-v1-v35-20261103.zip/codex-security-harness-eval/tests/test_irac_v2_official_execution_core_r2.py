from __future__ import annotations

import json
import sys
from pathlib import Path

import jsonschema


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_finalization_r1 import STATES  # noqa: E402
from irac_v2_official_execution_core_r2 import OBSERVATION_SCHEMA, WORKLOAD  # noqa: E402


def test_finalization_state_machine_is_exact() -> None:
    protocol = json.loads((ROOT / "protocol" / "IRAC_V2_OFFICIAL_FINALIZATION_READINESS_R1.json").read_text())
    assert list(STATES) == protocol["state_machine"]


def test_r2_observation_schema_accepts_only_external_finalization_contract() -> None:
    schema = json.loads(OBSERVATION_SCHEMA.read_text())
    required = set(schema["required"])
    assert "external_finalization_required" in required
    assert "cleanup_pass" not in required
    assert "evidence_lock_pass" not in required
    assert schema["properties"]["external_finalization_required"]["const"] is True
    jsonschema.Draft202012Validator.check_schema(schema)


def test_scientific_workload_is_unchanged() -> None:
    import hashlib

    assert hashlib.sha256(WORKLOAD.read_bytes()).hexdigest() == "90b18c2773808ef5adaa1134ff9bffa96e08434eed9ff96012a33327f0f5f41d"

