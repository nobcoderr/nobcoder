from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import ej_capacity_envelope_v2_validation as v2  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_protocol_and_policy_are_frozen_for_30_fresh_runs():
    protocol = load(v2.PROTOCOL)
    policy = load(v2.POLICY)
    assert protocol["positions"] == 30
    assert protocol["tiers"] == {"SMALL": 10, "MEDIUM": 10, "LARGE": 10}
    assert protocol["retry_count"] == protocol["replacement_count"] == 0
    assert policy["pooled_tail_bound"]["output_tokens"]["rounded_bounded_allowance"] == 3000
    assert policy["pooled_tail_bound"]["reasoning_tokens"]["rounded_bounded_allowance"] == 2500


def test_acceptance_fails_closed_on_one_invalid_position(tmp_path):
    statuses = [{"sample_id": f"EJCENV2VAL-{index:03d}", "position_valid": index != 30, "scientific_provider_outcome": "ACCEPTED"} for index in range(1, 31)]
    result = v2.acceptance(tmp_path, statuses)
    assert result["status"] == "FAIL_LOCKED"
    assert result["full_bundle_replay_authorized"] is False


def test_fixture_manifest_is_fresh_and_balanced_when_present():
    if not v2.MANIFEST.exists():
        return
    manifest, schedule = load(v2.MANIFEST), load(v2.SCHEDULE)
    assert manifest["counts"] == {"total": 30, "per_tier": {"SMALL": 10, "MEDIUM": 10, "LARGE": 10}}
    assert len(schedule["entries"]) == 30
    assert len({row["sample_id"] for row in schedule["entries"]}) == 30
    assert all(row["experiment_namespace"] == "EJCENV2VAL" for row in schedule["entries"])
