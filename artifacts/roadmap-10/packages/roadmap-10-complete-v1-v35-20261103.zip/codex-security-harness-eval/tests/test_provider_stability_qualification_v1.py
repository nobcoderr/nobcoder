from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import run_provider_stability_qualification_v1 as runner  # noqa: E402


def row(position: int, *, stage: str = "A", classification: str = "ACCEPTED") -> dict:
    return {
        "stage": stage,
        "position": position,
        "sample_id": f"IRAC2PSQ{stage}-{position:03d}",
        "session_id": f"session-{stage}-{position:03d}",
        "operational_classification": classification,
        "provider_outcome": "ACCEPTED" if classification == "ACCEPTED" else "REJECTED",
        "provider_error_class": None if classification == "ACCEPTED" else classification,
        "capture_valid": classification == "ACCEPTED",
        "fixture_bound_request_count": 1 if classification == "ACCEPTED" else 0,
        "classifier_ambiguity_count": 0,
        "payload_mutation_count": 0,
        "finalization_pass": True,
        "cleanup_pass": True,
        "scientific_fields_admitted": False,
    }


def test_protocol_precommits_60_plus_12_and_zero_retry():
    protocol = json.loads((ROOT / "protocol" / "PROVIDER_STABILITY_QUALIFICATION_V1.json").read_text())
    assert protocol["stage_a"]["scheduled_probes"] == 60
    assert protocol["stage_a"]["precommitted_gates"]["minimum_uninterrupted_accepted_streak"] == 54
    assert protocol["stage_b"]["scheduled_probes"] == 12
    assert protocol["stage_b"]["precommitted_gates"]["accepted"] == "12/12"
    assert protocol["stage_a"]["retry_count"] == protocol["stage_b"]["retry_count"] == 0


def test_stage_a_pass_requires_a_54_clean_streak():
    rows = [row(position) for position in range(1, 61)]
    result = runner.score_stage(rows, stage="A", source_ok=True)
    assert result["status"] == "PASS_LOCKED"
    assert result["longest_uninterrupted_accepted_streak"] == 60

    rows[29] = row(30, classification="PROVIDER_CAPACITY_REJECTION")
    result = runner.score_stage(rows, stage="A", source_ok=True)
    assert result["status"] == "FAIL_LOCKED"
    assert result["longest_uninterrupted_accepted_streak"] == 30


def test_stage_a_allows_at_most_one_edge_rejection_only_if_streak_survives():
    rows = [row(position) for position in range(1, 61)]
    rows[59] = row(60, classification="PROVIDER_TRANSIENT_REJECTION")
    result = runner.score_stage(rows, stage="A", source_ok=True)
    assert result["status"] == "PASS_LOCKED"
    assert result["provider_rejections"] == 1
    assert result["longest_uninterrupted_accepted_streak"] == 59

    rows[58] = row(59, classification="PROVIDER_CAPACITY_REJECTION")
    assert runner.score_stage(rows, stage="A", source_ok=True)["status"] == "FAIL_LOCKED"


@pytest.mark.parametrize("classification", [
    "PROVIDER_UNKNOWN_REJECTION", "PROVIDER_PROTOCOL_UNRECOGNIZED", "TRANSPORT_TIMEOUT",
    "CAPTURE_FAILURE", "CLASSIFIER_FAILURE", "FINALIZATION_FAILURE",
    "OPERATIONAL_COMPLETION_FAILURE", "SESSION_IDENTITY_FAILURE",
])
def test_stage_a_fails_closed_on_nonqualified_operational_outcome(classification: str):
    rows = [row(position) for position in range(1, 61)]
    rows[-1] = row(60, classification=classification)
    assert runner.score_stage(rows, stage="A", source_ok=True)["status"] == "FAIL_LOCKED"


def test_stage_b_requires_12_of_12():
    rows = [row(position, stage="B") for position in range(1, 13)]
    assert runner.score_stage(rows, stage="B", source_ok=True)["status"] == "PASS_LOCKED"
    rows[-1] = row(12, stage="B", classification="PROVIDER_CAPACITY_REJECTION")
    assert runner.score_stage(rows, stage="B", source_ok=True)["status"] == "FAIL_LOCKED"


def test_duplicate_session_fails_freshness_gate():
    rows = [row(position) for position in range(1, 61)]
    rows[-1]["session_id"] = rows[-2]["session_id"]
    result = runner.score_stage(rows, stage="A", source_ok=True)
    assert result["status"] == "FAIL_LOCKED"
    assert result["gates"]["fresh_session_uniqueness"] is False


def test_no_scientific_fields_are_aggregated():
    result = runner.score_stage([row(position) for position in range(1, 61)], stage="A", source_ok=True)
    serialized = json.dumps(result, sort_keys=True)
    for forbidden in ("output_tokens", "reasoning_tokens", "total_input_tokens", "scientific_request_digest"):
        assert forbidden not in serialized
    assert result["scientific_fields_analyzed"] is False


def test_schedule_generation_shape():
    for path, count, stage in (
        (ROOT / "calibration" / "provider-stability-qualification-v1" / "SCHEDULE_STAGE_A.json", 60, "A"),
        (ROOT / "calibration" / "provider-stability-qualification-v1" / "SCHEDULE_STAGE_B.json", 12, "B"),
    ):
        if not path.exists():
            pytest.skip("schedule is generated and locked by build step")
        schedule = json.loads(path.read_text())
        assert [entry["position"] for entry in schedule["entries"]] == list(range(1, count + 1))
        assert len({entry["sample_id"] for entry in schedule["entries"]}) == count
        assert {entry["stage"] for entry in schedule["entries"]} == {stage}
