from __future__ import annotations

import copy
import json
import sqlite3
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE_SRC = Path("/home/nobcoder/codex-security-harness-v0.1.7/src")
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(CANDIDATE_SRC))

from bbp_harness.db import SCHEMA_SQL  # noqa: E402
from v017_acceptance_telemetry_v2 import (  # noqa: E402
    CONTRACT,
    TelemetrySchemaError,
    collect_database_telemetry,
    load_json,
    validate_schema,
)


NOW = "2026-10-08T00:00:00+00:00"


def database(tmp_path: Path, name: str = "research.db") -> Path:
    path = tmp_path / name
    connection = sqlite3.connect(path)
    try:
        connection.executescript(SCHEMA_SQL)
    finally:
        connection.close()
    return path


def insert_campaign(connection: sqlite3.Connection, campaign_id: str, target_id: int) -> None:
    connection.execute(
        "INSERT INTO targets(id,root_path,created_at,updated_at) VALUES(?,?,?,?)",
        (target_id, f"/fixture/{target_id}", NOW, NOW),
    )
    connection.execute(
        "INSERT INTO campaigns(id,target_id,objective,status,scope_status,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?)",
        (campaign_id, target_id, "offline readiness", "COMPLETE", "PROVEN", NOW, NOW),
    )


def insert_candidate(connection: sqlite3.Connection, candidate_id: str, campaign_id: str) -> None:
    connection.execute(
        "INSERT INTO candidates(id,campaign_id,title,state,created_at,updated_at) VALUES(?,?,?,?,?,?)",
        (candidate_id, campaign_id, candidate_id, "DISCOVERED", NOW, NOW),
    )


def insert_transition(connection: sqlite3.Connection, candidate_id: str, suffix: str) -> None:
    connection.execute(
        "INSERT INTO candidate_transitions(candidate_id,from_state,to_state,reason,created_at) "
        "VALUES(?,?,?,?,?)",
        (candidate_id, "DISCOVERED", "WAIT_CLOSURE_SLOT", suffix, NOW),
    )


def test_s01_one_campaign_no_child_records_passes(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        insert_campaign(connection, "C1", 1)
    result = collect_database_telemetry(path)
    assert result["schema"]["status"] == "PASS"
    assert result["candidates"] == {"count": 0, "transitions": 0}


def test_s02_multiple_candidates_have_exact_join_cardinality(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        insert_campaign(connection, "C1", 1)
        insert_candidate(connection, "A", "C1")
        insert_candidate(connection, "B", "C1")
        insert_transition(connection, "A", "a1")
        insert_transition(connection, "A", "a2")
        insert_transition(connection, "B", "b1")
    result = collect_database_telemetry(path)
    assert result["candidates"] == {"count": 2, "transitions": 3}


def test_s03_campaign_join_excludes_other_campaign_transitions(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        connection.row_factory = sqlite3.Row
        insert_campaign(connection, "C1", 1)
        insert_campaign(connection, "C2", 2)
        insert_candidate(connection, "A", "C1")
        insert_candidate(connection, "B", "C2")
        insert_transition(connection, "A", "a1")
        insert_transition(connection, "A", "a2")
        insert_transition(connection, "B", "b1")
        count = int(connection.execute(
            "SELECT count(*) FROM candidate_transitions AS ct "
            "JOIN candidates AS c ON c.id=ct.candidate_id WHERE c.campaign_id=?",
            ("C1",),
        ).fetchone()[0])
    assert count == 2


def test_s04_nullable_actual_json_is_supported(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        insert_campaign(connection, "C1", 1)
        connection.execute(
            "INSERT INTO worker_jobs(id,campaign_id,role,status,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            ("J1", "C1", "researcher", "READY", NOW, NOW),
        )
        connection.execute(
            "INSERT INTO scheduler_reservations("
            "invocation_id,campaign_id,job_id,worker_role,state,request_json,estimator_json,actual_json,created_at,updated_at"
            ") VALUES(?,?,?,?,?,?,?,?,?,?)",
            ("I1", "C1", "J1", "researcher", "ADMITTED", "{}", "{}", None, NOW, NOW),
        )
    result = collect_database_telemetry(path)
    assert result["reservations"][0]["actual"] == {}


def test_s05_zero_campaigns_fail_closed(tmp_path: Path) -> None:
    with pytest.raises(TelemetrySchemaError, match="cardinality must be 1, observed 0"):
        collect_database_telemetry(database(tmp_path))


def test_s06_multiple_campaigns_fail_closed(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        insert_campaign(connection, "C1", 1)
        insert_campaign(connection, "C2", 2)
    with pytest.raises(TelemetrySchemaError, match="cardinality must be 1, observed 2"):
        collect_database_telemetry(path)


def test_s07_missing_transition_table_fails_closed(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        connection.execute("DROP TABLE candidate_transitions")
        connection.row_factory = sqlite3.Row
        with pytest.raises(TelemetrySchemaError, match="missing table: candidate_transitions"):
            validate_schema(connection)


def test_s08_missing_transition_foreign_key_fails_closed(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        connection.execute("DROP TABLE candidate_transitions")
        connection.execute(
            "CREATE TABLE candidate_transitions("
            "id INTEGER PRIMARY KEY AUTOINCREMENT,candidate_id TEXT NOT NULL,"
            "from_state TEXT NOT NULL,to_state TEXT NOT NULL,reason TEXT NOT NULL,"
            "evidence_json TEXT NOT NULL DEFAULT '[]',actor TEXT NOT NULL DEFAULT 'state-machine',"
            "created_at TEXT NOT NULL)"
        )
        connection.row_factory = sqlite3.Row
        with pytest.raises(TelemetrySchemaError, match="missing foreign key"):
            validate_schema(connection)


def test_exact_rc1_query_defect_is_reproduced_and_corrected(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        insert_campaign(connection, "C1", 1)
        insert_candidate(connection, "A", "C1")
        insert_transition(connection, "A", "a1")
        with pytest.raises(sqlite3.OperationalError, match="no such column: campaign_id"):
            connection.execute(
                "SELECT count(*) FROM candidate_transitions WHERE campaign_id=?", ("C1",)
            ).fetchone()
    assert collect_database_telemetry(path)["candidates"]["transitions"] == 1


def test_malformed_required_json_fails_closed(tmp_path: Path) -> None:
    path = database(tmp_path)
    with sqlite3.connect(path) as connection:
        insert_campaign(connection, "C1", 1)
        connection.execute(
            "INSERT INTO events(campaign_id,entity_type,entity_id,event_type,payload_json,created_at) "
            "VALUES(?,?,?,?,?,?)",
            ("C1", "campaign", "C1", "NO_RUNNABLE_WORK_CONVERGED", "{", NOW),
        )
    with pytest.raises(TelemetrySchemaError, match="malformed telemetry JSON"):
        collect_database_telemetry(path)


def test_nullability_drift_fails_closed(tmp_path: Path) -> None:
    path = database(tmp_path)
    contract = copy.deepcopy(load_json(CONTRACT))
    contract["required_tables"]["scheduler_reservations"]["nullable"] = ["request_json"]
    with sqlite3.connect(path) as connection:
        connection.row_factory = sqlite3.Row
        with pytest.raises(TelemetrySchemaError, match="required nullable column became NOT NULL"):
            validate_schema(connection, contract)
