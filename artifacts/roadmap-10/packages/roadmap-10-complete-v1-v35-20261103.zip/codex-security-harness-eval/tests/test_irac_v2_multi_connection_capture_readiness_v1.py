from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from run_irac_v2_multi_connection_capture_readiness_v1 import forbidden_component_status, score  # noqa: E402


def row(position: int, *, connections: int = 1) -> dict:
    return {
        "classification": "ACCEPTED",
        "accepted": True,
        "capture_reliable": True,
        "invocation_capture_validator_status": "PASS",
        "fixture_bound_request_count": 1,
        "classifier_ambiguity_count": 0,
        "payload_mutation_count": 0,
        "finalization_pass": True,
        "session_id": f"session-{position}",
        "connection_count": connections,
    }


def test_protocol_precommits_invocation_scope_and_strict_live_gate() -> None:
    protocol = json.loads((ROOT / "protocol" / "IRAC_V2_MULTI_CONNECTION_CAPTURE_READINESS_V1.json").read_text())
    assert protocol["authoritative_rules"]["validation_scope"] == "INVOCATION"
    assert protocol["authoritative_rules"]["connection_cardinality_is_validity_gate"] is False
    assert protocol["authoritative_rules"]["fixture_bound_request_cardinality_is_validity_gate"] is True
    assert protocol["live_qualification"]["positions"] == 12
    assert protocol["live_qualification"]["acceptance"]["provider_accepted"] == "12/12"
    assert protocol["live_qualification"]["retry_count"] == 0


def test_forbidden_components_match_preimplementation_manifest() -> None:
    result = forbidden_component_status()
    assert result["status"] == "PASS"
    assert result["drift"] == []


def test_score_passes_with_multi_connection_samples() -> None:
    rows = [row(position, connections=2 if position in {7, 12} else 1) for position in range(1, 13)]
    source = {"status": "PASS", "forbidden": {"drift": []}}
    result = score(rows, 100.0, source)
    assert result["status"] == "PASS_LOCKED"
    assert result["multi_connection_samples"] == 2
    assert result["gates"]["multi_connection_samples_if_present_pass"] is True


def test_score_fails_closed_on_request_ambiguity() -> None:
    rows = [row(position) for position in range(1, 13)]
    rows[4]["fixture_bound_request_count"] = 2
    rows[4]["invocation_capture_validator_status"] = "FAIL"
    source = {"status": "PASS", "forbidden": {"drift": []}}
    result = score(rows, 100.0, source)
    assert result["status"] == "FAIL_LOCKED"
    assert result["official_r4_identity_creation_authorized"] is False


def test_score_does_not_require_a_live_multi_connection_sample() -> None:
    rows = [row(position) for position in range(1, 13)]
    source = {"status": "PASS", "forbidden": {"drift": []}}
    result = score(rows, 100.0, source)
    assert result["status"] == "PASS_LOCKED"
    assert result["multi_connection_samples"] == 0
