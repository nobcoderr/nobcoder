from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_analyzer():
    path = ROOT / "scripts" / "analyze_evidence_judge_variance_decomposition_v1.py"
    spec = importlib.util.spec_from_file_location("analyze_ej_variance_v1", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


ANALYZER = load_analyzer()
PERMUTATIONS = 100000
BOOTSTRAPS = 20000
PERMUTATION_SEED = "ejvd-v1-semantic-permutation"
BOOTSTRAP_SEED = "ejvd-v1-semantic-bootstrap"


def paired_groups(groups):
    return {
        "output_tokens": {name: list(values) for name, values in groups.items()},
        "reasoning_tokens": {name: [value * 2 + 3 for value in values] for name, values in groups.items()},
    }


def analyze(groups):
    return ANALYZER.analyze_balanced_family(
        paired_groups(groups),
        permutations=PERMUTATIONS,
        permutation_seed=PERMUTATION_SEED,
        resamples=BOOTSTRAPS,
        bootstrap_seed=BOOTSTRAP_SEED,
        dominant_label="SEMANTIC_DOMINANT",
    )


class EvidenceJudgeVarianceAnalyzerV1Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        low_noise = [-7, -5, -3, -1, 1, 3, 5, 7]
        cls.semantic = analyze({
            "A": [100 + value for value in low_noise],
            "B": [500 + value for value in low_noise],
            "C": [900 + value for value in low_noise],
        })
        stochastic_values = [100, 200, 300, 400, 500, 600, 700, 800]
        cls.stochastic = analyze({
            "A": stochastic_values,
            "B": list(reversed(stochastic_values)),
            "C": stochastic_values[2:] + stochastic_values[:2],
        })
        cls.mixed = analyze({
            "A": [100 + value for value in low_noise],
            "B": [105 + value for value in low_noise],
            "C": [110 + value for value in low_noise],
        })

    def test_synthetic_a_is_semantic_dominant(self) -> None:
        self.assertEqual(self.semantic["output_tokens"]["classification"], "SEMANTIC_DOMINANT")
        self.assertEqual(self.semantic["reasoning_tokens"]["classification"], "SEMANTIC_DOMINANT")

    def test_synthetic_b_is_stochastic_dominant(self) -> None:
        self.assertEqual(self.stochastic["output_tokens"]["classification"], "STOCHASTIC_DOMINANT")
        self.assertEqual(self.stochastic["reasoning_tokens"]["classification"], "STOCHASTIC_DOMINANT")

    def test_synthetic_c_is_mixed_or_unresolved(self) -> None:
        self.assertEqual(self.mixed["output_tokens"]["classification"], "MIXED_OR_UNRESOLVED")
        self.assertEqual(self.mixed["reasoning_tokens"]["classification"], "MIXED_OR_UNRESOLVED")

    def test_exact_permutation_and_bootstrap_counts_are_recorded(self) -> None:
        for result in (self.semantic, self.stochastic, self.mixed):
            for outcome in ANALYZER.OUTCOMES:
                self.assertEqual(result[outcome]["permutation"]["permutations"], 100000)
                self.assertEqual(result[outcome]["bootstrap"]["resamples"], 20000)

    def test_deterministic_seed_reproduces_identical_result(self) -> None:
        low_noise = [-7, -5, -3, -1, 1, 3, 5, 7]
        repeated = ANALYZER.analyze_balanced_family(
            paired_groups({
                "A": [100 + value for value in low_noise],
                "B": [500 + value for value in low_noise],
                "C": [900 + value for value in low_noise],
            }),
            permutations=PERMUTATIONS,
            permutation_seed=PERMUTATION_SEED,
            resamples=BOOTSTRAPS,
            bootstrap_seed=BOOTSTRAP_SEED,
            dominant_label="SEMANTIC_DOMINANT",
        )
        self.assertEqual(repeated, self.semantic)

    def test_holm_regression(self) -> None:
        adjusted = ANALYZER.holm_adjust({"output_tokens": 0.01, "reasoning_tokens": 0.04})
        self.assertAlmostEqual(adjusted["output_tokens"], 0.02)
        self.assertAlmostEqual(adjusted["reasoning_tokens"], 0.04)
        tied = ANALYZER.holm_adjust({"output_tokens": 0.03, "reasoning_tokens": 0.03})
        self.assertAlmostEqual(tied["output_tokens"], 0.06)
        self.assertAlmostEqual(tied["reasoning_tokens"], 0.06)

    def test_decision_boundary_edges(self) -> None:
        classify = ANALYZER.classify_dimension
        self.assertEqual(
            classify(ratio=2.0, lower=1.000001, upper=3.0, p_unadjusted=0.02, p_holm=0.05, dominant_label="SEMANTIC_DOMINANT"),
            "SEMANTIC_DOMINANT",
        )
        self.assertEqual(
            classify(ratio=2.0, lower=1.0, upper=3.0, p_unadjusted=0.02, p_holm=0.05, dominant_label="SEMANTIC_DOMINANT"),
            "MIXED_OR_UNRESOLVED",
        )
        self.assertEqual(
            classify(ratio=0.5, lower=0.0, upper=0.999999, p_unadjusted=0.10, p_holm=0.20, dominant_label="SEMANTIC_DOMINANT"),
            "STOCHASTIC_DOMINANT",
        )
        self.assertEqual(
            classify(ratio=0.5, lower=0.0, upper=1.0, p_unadjusted=0.10, p_holm=0.20, dominant_label="SEMANTIC_DOMINANT"),
            "MIXED_OR_UNRESOLVED",
        )

    def test_synthetic_d_missing_or_invalid_observation_fails_closed(self) -> None:
        schedule = [
            {"position": index, "sample_id": f"EJVD-{index:03d}", "fixture_id": "EJVD-SEM-A", "family": "SEMANTIC_FIXED_SIZE", "repetition": index}
            for index in range(1, 55)
        ]
        rows = [
            {
                "schedule_position": item["position"],
                "sample_id": item["sample_id"],
                "fixture_id": item["fixture_id"],
                "family": item["family"],
                "repetition": item["repetition"],
                "terminal_status": "VALID_COMPLETED",
                "valid_for_primary_analysis": True,
                "schema_valid": True,
                "resource_compliant": True,
            }
            for item in schedule
        ]
        with self.assertRaisesRegex(ANALYZER.AnalysisContractError, "54/54"):
            ANALYZER.validate_complete_observations(schedule, rows[:-1])
        rows[26]["terminal_status"] = "INVALID_INFRASTRUCTURE"
        rows[26]["valid_for_primary_analysis"] = False
        with self.assertRaisesRegex(ANALYZER.AnalysisContractError, "ineligible"):
            ANALYZER.validate_complete_observations(schedule, rows)

    def test_overall_decision_rule_is_exact(self) -> None:
        self.assertEqual(ANALYZER.overall_interpretation(self.semantic, True), "SEMANTIC_DOMINANT_FOR_CONTROLLED_FIXTURES")
        self.assertEqual(ANALYZER.overall_interpretation(self.stochastic, True), "STOCHASTIC_DOMINANT_FOR_CONTROLLED_FIXTURES")
        dimension_specific = {
            "output_tokens": {"classification": "SEMANTIC_DOMINANT"},
            "reasoning_tokens": {"classification": "STOCHASTIC_DOMINANT"},
        }
        self.assertEqual(ANALYZER.overall_interpretation(dimension_specific, True), "DIMENSION_SPECIFIC")
        self.assertEqual(ANALYZER.overall_interpretation(self.semantic, False), "INSUFFICIENT_SEPARATION")


if __name__ == "__main__":
    unittest.main()
