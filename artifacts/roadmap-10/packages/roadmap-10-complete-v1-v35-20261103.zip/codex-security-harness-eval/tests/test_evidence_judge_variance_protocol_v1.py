from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_module(name: str, relative: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


VERIFY = load_module("verify_ej_variance_v1", "scripts/verify_evidence_judge_variance_protocol_v1.py")
PROTOCOL = json.loads((ROOT / "protocol" / "EVIDENCE_JUDGE_VARIANCE_DECOMPOSITION_V1.json").read_text())
MANIFEST = json.loads((ROOT / "calibration" / "evidence-judge-variance-decomposition-v1" / "WORKLOAD_MANIFEST.json").read_text())
SCHEDULE = json.loads((ROOT / "calibration" / "evidence-judge-variance-decomposition-v1" / "SCHEDULE.json").read_text())


class EvidenceJudgeVarianceProtocolV1Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result = VERIFY.verify()

    def test_preflight_passes_without_invocation_or_product_change(self) -> None:
        self.assertEqual(self.result["status"], "PASS", self.result["errors"])
        self.assertEqual(self.result["model_invocations"], 0)
        self.assertEqual(self.result["estimators_fitted"], 0)
        self.assertEqual(self.result["product_changes"], 0)
        self.assertFalse(self.result["execution_authorized"])

    def test_factorial_families_and_repetitions_are_frozen(self) -> None:
        counts = Counter(row["family"] for row in SCHEDULE["entries"])
        self.assertEqual(counts["SEMANTIC_FIXED_SIZE"], 24)
        self.assertEqual(counts["SIZE_FIXED_SEMANTICS"], 18)
        self.assertEqual(counts["EXACT_REPEAT"], 12)
        self.assertEqual(len(SCHEDULE["entries"]), 54)

    def test_semantic_family_is_size_matched(self) -> None:
        rows = {row["fixture_id"]: row for row in MANIFEST["workloads"]}
        semantic = [rows[key]["measurements"] for key in ("EJVD-SEM-A", "EJVD-SEM-B", "EJVD-SEM-C")]
        lexical = [row["prompt_lexical_tokens"] for row in semantic]
        byte_counts = [row["prompt_bytes"] for row in semantic]
        self.assertLessEqual(max(lexical) / min(lexical), 1.01)
        self.assertLessEqual(max(byte_counts) / min(byte_counts), 1.01)

    def test_size_family_has_one_semantic_projection(self) -> None:
        rows = [row for row in MANIFEST["workloads"] if row["family"] == "SIZE_FIXED_SEMANTICS"]
        self.assertEqual(len({row["semantic_projection_sha256"] for row in rows}), 1)
        by_id = {row["fixture_id"]: row for row in rows}
        small = by_id["EJVD-SIZE-S"]["measurements"]["prompt_lexical_tokens"]
        medium = by_id["EJVD-SIZE-M"]["measurements"]["prompt_lexical_tokens"]
        large = by_id["EJVD-SIZE-L"]["measurements"]["prompt_lexical_tokens"]
        self.assertGreaterEqual(medium / small, 2.0)
        self.assertGreaterEqual(large / medium, 1.5)

    def test_schedule_is_interleaved_and_has_no_reruns(self) -> None:
        entries = SCHEDULE["entries"]
        self.assertTrue(all(left["fixture_id"] != right["fixture_id"] for left, right in zip(entries, entries[1:])))
        self.assertEqual(PROTOCOL["schedule"]["reruns"], 0)
        self.assertTrue(PROTOCOL["eligibility_and_stopping"]["no_early_success_stop"])

    def test_analysis_is_measurement_only_and_precommitted(self) -> None:
        analysis = PROTOCOL["analysis_precommit"]
        self.assertEqual(PROTOCOL["design"]["co_primary_outcomes"], ["output_tokens", "reasoning_tokens"])
        self.assertEqual(analysis["family_1_variance_components"]["permutation_test"]["permutations"], 100000)
        self.assertEqual(analysis["family_1_variance_components"]["bootstrap"]["resamples"], 20000)
        self.assertTrue(analysis["no_estimator_outputs"])
        self.assertTrue(analysis["no_reservation_outputs"])
        self.assertFalse(PROTOCOL["post_measurement"]["full_bundle_replay_authorized"])
        self.assertFalse(PROTOCOL["post_measurement"]["v0.1.3_implementation_authorized"])


if __name__ == "__main__":
    unittest.main()
