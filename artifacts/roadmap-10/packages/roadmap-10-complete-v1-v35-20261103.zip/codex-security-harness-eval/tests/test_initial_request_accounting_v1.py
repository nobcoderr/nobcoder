from __future__ import annotations

import hashlib
import http.client as http_client
import json
import sys
import tempfile
import threading
import unittest
from collections import Counter
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from mitmproxy import http
from mitmproxy.test import tflow


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import irac_request_capture as capture  # noqa: E402
import irac_runtime as runtime  # noqa: E402


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class InitialRequestAccountingProtocolV1Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.protocol = json.loads((ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V1.json").read_text())
        self.schedule = json.loads((ROOT / "calibration" / "initial-request-accounting-characterization-v1" / "SCHEDULE.json").read_text())

    def test_schedule_is_balanced_interleaved_and_never_retries(self) -> None:
        entries = self.schedule["entries"]
        self.assertEqual(list(range(1, 13)), [row["position"] for row in entries])
        self.assertEqual(12, len({row["sample_id"] for row in entries}))
        self.assertEqual(Counter({"EMPTY_START": 4, "MODEL_CACHE_ONLY": 4, "MODEL_PLUS_APPS_CACHE": 4}), Counter(row["condition"] for row in entries))
        self.assertTrue(all(a["condition"] != b["condition"] for a, b in zip(entries, entries[1:])))
        self.assertEqual(0, self.schedule["retry_count"])
        self.assertEqual(0, self.schedule["replacement_count"])

    def test_protocol_forbids_product_and_historical_mutation(self) -> None:
        forbidden = self.protocol["prohibitions"]
        for key in (
            "variance_v1_mutation", "variance_v1_rescore", "threshold_relaxation",
            "retry_or_replacement", "optional_stopping", "estimator_derivation",
            "scheduler_or_product_change", "full_bundle_replay", "fresh_holdout", "pilot_v3",
        ):
            self.assertIs(forbidden[key], True)
        self.assertEqual("INSUFFICIENT_DATA", self.protocol["claim"])

    def test_cache_seed_manifest_binds_exact_files(self) -> None:
        base = ROOT / "calibration" / "initial-request-accounting-characterization-v1"
        manifest = json.loads((base / "CACHE_SEED_MANIFEST.json").read_text())
        for relative, expected in manifest["files"].items():
            self.assertEqual(expected, sha256(base / "cache-seed" / relative))

    def test_validity_requires_all_twelve_without_retry(self) -> None:
        gate = self.protocol["validity_gate"]
        self.assertEqual("12/12", gate["required_valid_completed"])
        self.assertEqual("NO_RETRY_NO_REPLACEMENT_MEASUREMENT_INCOMPLETE", gate["invalid_sample_policy"])
        self.assertIs(gate["exactly_one_captured_inference_request_per_sample"], True)

    def test_decision_labels_are_precommitted_and_do_not_authorize_product(self) -> None:
        rule = self.protocol["decision_rule"]
        for label in ("PRE_INVOCATION_CONTEXT_DRIFT", "MEASUREMENT_ACCOUNTING", "MIXED", "UNRESOLVED", "MEASUREMENT_INCOMPLETE"):
            self.assertIn(label, rule)
        self.assertIs(rule["no_post_hoc_rule_change"], True)
        authorization = self.protocol["analysis_authorization"]
        self.assertIs(authorization["available_only_after_raw_execution_lock"], True)
        self.assertTrue(all(value is False for key, value in authorization.items() if key != "available_only_after_raw_execution_lock"))


class InitialRequestCaptureTests(unittest.TestCase):
    def payload(self, instructions: str = "fixed instructions") -> dict:
        return {
            "model": "gpt-5.6-sol",
            "instructions": instructions,
            "input": [
                {"role": "developer", "content": "## Apps (Connectors)\nfixed"},
                {"role": "user", "content": "synthetic prompt"},
            ],
            "tools": [{"type": "function", "name": "safe_tool", "parameters": {"type": "object"}}],
            "reasoning": {"effort": "xhigh"},
            "stream": True,
            "metadata": {"random_session": "ignored-in-token-projection"},
        }

    def flow(self, payload: dict) -> http.HTTPFlow:
        request = http.Request.make(
            "POST",
            "https://chatgpt.com/backend-api/codex/responses",
            json.dumps(payload).encode(),
            headers={"content-type": "application/json", "authorization": "Bearer MUST_NOT_PERSIST", "cookie": "MUST_NOT_PERSIST"},
        )
        return tflow.tflow(req=request, resp=http.Response.make(200, b"ok"))

    def test_capture_persists_body_and_only_header_hashes(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            addon = capture.RequestCaptureAddon(Path(directory), "IRAC-TEST")
            flow = self.flow(self.payload())
            addon.request(flow)
            addon.response(flow)
            metadata_path = Path(directory) / "inference-001.metadata.json"
            metadata = json.loads(metadata_path.read_text())
            self.assertEqual(1, metadata["capture_index"])
            self.assertEqual(200, metadata["response_status_code"])
            self.assertFalse(metadata["raw_header_values_persisted"])
            for path in Path(directory).iterdir():
                if path.suffix in {".json", ".jsonl"} and path.name != "inference-001.decoded.json":
                    text = path.read_text(errors="replace")
                    self.assertNotIn("MUST_NOT_PERSIST", text)

    def test_token_projection_excludes_only_precommitted_transport_fields(self) -> None:
        first = self.payload()
        second = self.payload()
        second["metadata"] = {"random_session": "different"}
        a = capture.component_projection(first)["component_sha256"]
        b = capture.component_projection(second)["component_sha256"]
        self.assertEqual(a["token_bearing_projection"], b["token_bearing_projection"])
        second["instructions"] = "changed token-bearing instruction"
        c = capture.component_projection(second)["component_sha256"]
        self.assertNotEqual(a["token_bearing_projection"], c["token_bearing_projection"])

    def test_apps_and_tools_have_separate_digests(self) -> None:
        components = capture.component_projection(self.payload())["component_sha256"]
        self.assertNotEqual(components["apps_instruction_context"], components["tool_definitions"])
        self.assertEqual(64, len(components["initial_input"]))

    def test_cache_conditions_are_exact_and_normalized(self) -> None:
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            root = Path(directory)
            manifests = {}
            for condition in ("EMPTY_START", "MODEL_CACHE_ONLY", "MODEL_PLUS_APPS_CACHE"):
                home = root / condition
                manifests[condition] = runtime.seed_cache(home, condition, fetched_at="2026-10-05T00:00:00Z")
                self.assertTrue(runtime.cache_condition_matches(manifests[condition], condition))
            self.assertFalse(manifests["EMPTY_START"]["entries"]["models_cache.json"]["present"])
            self.assertTrue(manifests["MODEL_CACHE_ONLY"]["entries"]["models_cache.json"]["present"])
            self.assertTrue(manifests["MODEL_PLUS_APPS_CACHE"]["entries"]["cache/codex_apps_tools/3dc8de247b82e9503071a033b9b598ea9599d5fa.json"]["present"])

    def test_real_proxy_capture_is_non_mutating_without_model(self) -> None:
        received: list[bytes] = []

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self) -> None:  # noqa: N802
                body = self.rfile.read(int(self.headers.get("content-length", "0")))
                received.append(body)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"ok")

            def log_message(self, *_args: object) -> None:
                return

        server = HTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with tempfile.TemporaryDirectory(dir=ROOT) as directory:
                proxy = runtime.start_proxy(Path(directory) / "capture", "IRAC-TEST")
                try:
                    body = json.dumps(self.payload()).encode()
                    connection = http_client.HTTPConnection("127.0.0.1", proxy.port, timeout=10)
                    connection.request(
                        "POST",
                        f"http://127.0.0.1:{server.server_port}/backend-api/codex/responses",
                        body=body,
                        headers={"content-type": "application/json", "authorization": "Bearer MUST_NOT_PERSIST"},
                    )
                    response = connection.getresponse()
                    response.read()
                    connection.close()
                    self.assertEqual(200, response.status)
                finally:
                    proxy.stop()
                result = runtime.validate_single_capture(Path(directory) / "capture")
                self.assertEqual("PASS", result["status"])
                self.assertEqual([body], received)
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
