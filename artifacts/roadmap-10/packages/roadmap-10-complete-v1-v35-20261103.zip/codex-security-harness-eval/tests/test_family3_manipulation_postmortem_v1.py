from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_module():
    path = ROOT / "scripts" / "postmortem_family3_manipulation_v1.py"
    spec = importlib.util.spec_from_file_location("family3_postmortem", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


POSTMORTEM = load_module()


class Family3ManipulationPostmortemV1Tests(unittest.TestCase):
    def test_sample_paths_normalize_without_changing_other_content(self) -> None:
        value = {"path": "/capsules/EJVD-046/runtime", "other": "EJVD-REPEAT-D"}
        normalized = POSTMORTEM.normalize_sample_paths(value)
        self.assertEqual(normalized["path"], "/capsules/EJVD-XXX/runtime")
        self.assertEqual(normalized["other"], "EJVD-REPEAT-D")

    def test_unobserved_request_context_fails_closed_as_unresolved(self) -> None:
        verdict = POSTMORTEM.classify_variation_source(
            total_input_varies=True,
            single_turn_only=True,
            tool_calls=0,
            static_context_identical=True,
            request_payload_captured=False,
            explicit_initial_context_drift=False,
            accounting_error_proven=False,
        )
        self.assertEqual(verdict, "UNRESOLVED")

    def test_explicit_pre_invocation_drift_is_classified_only_when_proven(self) -> None:
        verdict = POSTMORTEM.classify_variation_source(
            total_input_varies=True,
            single_turn_only=True,
            tool_calls=0,
            static_context_identical=True,
            request_payload_captured=True,
            explicit_initial_context_drift=True,
            accounting_error_proven=False,
        )
        self.assertEqual(verdict, "PRE_INVOCATION_CONTEXT_DRIFT")

    def test_trajectory_requires_multiple_turns_or_tool_calls(self) -> None:
        verdict = POSTMORTEM.classify_variation_source(
            total_input_varies=True,
            single_turn_only=False,
            tool_calls=2,
            static_context_identical=True,
            request_payload_captured=True,
            explicit_initial_context_drift=False,
            accounting_error_proven=False,
        )
        self.assertEqual(verdict, "TRAJECTORY_DIVERGENCE")

    def test_accounting_and_mixed_labels_require_direct_evidence(self) -> None:
        accounting = POSTMORTEM.classify_variation_source(
            total_input_varies=True,
            single_turn_only=True,
            tool_calls=0,
            static_context_identical=True,
            request_payload_captured=True,
            explicit_initial_context_drift=False,
            accounting_error_proven=True,
        )
        mixed = POSTMORTEM.classify_variation_source(
            total_input_varies=True,
            single_turn_only=True,
            tool_calls=0,
            static_context_identical=True,
            request_payload_captured=True,
            explicit_initial_context_drift=True,
            accounting_error_proven=True,
        )
        self.assertEqual(accounting, "MEASUREMENT_ACCOUNTING")
        self.assertEqual(mixed, "MIXED")


if __name__ == "__main__":
    unittest.main()
