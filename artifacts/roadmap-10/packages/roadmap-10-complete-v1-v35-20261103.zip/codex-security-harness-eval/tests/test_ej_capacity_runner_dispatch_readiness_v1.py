from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from ej_capacity_runner_dispatch_v1 import DispatchError, append_event, finalize_pre_model_failure, resolve_sample, verify_journal, verify_launch_manifest  # noqa: E402
from execution_environment import sha256_file  # noqa: E402
from raw_lock_gate_v2 import apply_gate, verify_gate  # noqa: E402

RUNNER = ROOT / "scripts" / "run_ej_capacity_dispatch_v1.py"


def write(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + "\n", encoding="utf-8")


def setup_case(tmp_path: Path, namespace="EJCENV2VALR3"):
    fixture = tmp_path / "fixture.json"; write(fixture, {"fixture": "dispatch"})
    schedule = tmp_path / "schedule.json"
    write(schedule, {"experiment_namespace": namespace, "positions": 1, "entries": [{"position": 1, "experiment_namespace": namespace, "sample_id": f"{namespace}-001", "fixture_id": "FIX-1"}]})
    manifest = tmp_path / "manifest.json"; write(manifest, {"workloads": [{"fixture_id": "FIX-1", "path": "fixture.json", "sha256": sha256_file(fixture)}]})
    policy = tmp_path / "policy.json"; write(policy, {"policy": "v2"})
    protocol = tmp_path / "protocol.json"; write(protocol, {"protocol_id": "EJ_CAPACITY_ENVELOPE_V2"})
    schema = tmp_path / "schema.json"; write(schema, {"type": "object"})
    launch = {"schema_version": 1, "experiment_id": "EJ_CAPACITY_V2_VALIDATION_R3", "protocol_id": "EJ_CAPACITY_ENVELOPE_V2", "namespace": namespace, "repository_root": str(tmp_path), "runner": {"path": str(RUNNER), "sha256": sha256_file(RUNNER)}, "schedule": {"path": str(schedule), "sha256": sha256_file(schedule)}, "policy": {"path": str(policy), "sha256": sha256_file(policy)}, "protocol": {"path": str(protocol), "sha256": sha256_file(protocol)}, "workload_manifest": {"path": str(manifest), "sha256": sha256_file(manifest)}, "observation_schema": {"path": str(schema), "sha256": sha256_file(schema)}}
    launch_path = tmp_path / "launch.json"; write(launch_path, launch)
    return launch_path, launch


def test_correct_dispatch_passes(tmp_path):
    path, _ = setup_case(tmp_path)
    launch = verify_launch_manifest(path, RUNNER)
    assert resolve_sample(launch, 1, "EJCENV2VALR3-001")["fixture_id"] == "FIX-1"


@pytest.mark.parametrize("field", ["runner", "schedule", "policy", "protocol"])
def test_hash_drift_fails_pre_model(tmp_path, field):
    path, launch = setup_case(tmp_path)
    launch[field]["sha256"] = "0" * 64
    write(path, launch)
    with pytest.raises(DispatchError): verify_launch_manifest(path, RUNNER)


def test_wrong_runner_v1_with_v2_schedule_fails_exact_regression(tmp_path):
    path, launch = setup_case(tmp_path, "EJCENV2VAL")
    v1 = ROOT / "scripts" / "run_evidence_judge_capacity_envelope_v1.py"
    launch["runner"] = {"path": str(v1), "sha256": sha256_file(v1)}
    write(path, launch)
    with pytest.raises(DispatchError, match="runner"):
        verify_launch_manifest(path, RUNNER)


def test_wrong_namespace_fails(tmp_path):
    path, launch = setup_case(tmp_path)
    launch["namespace"] = "WRONG"
    write(path, launch)
    with pytest.raises(DispatchError, match="schedule_namespace"):
        verify_launch_manifest(path, RUNNER)


@pytest.mark.parametrize("sample", ["EJCENV2VALR3-002", "MISSING-001"])
def test_missing_or_position_mismatched_sample_fails(tmp_path, sample):
    path, _ = setup_case(tmp_path)
    launch = verify_launch_manifest(path, RUNNER)
    with pytest.raises(DispatchError): resolve_sample(launch, 1, sample)


def test_duplicate_sample_fails(tmp_path):
    path, launch = setup_case(tmp_path)
    schedule = Path(launch["schedule"]["path"]); value = json.loads(schedule.read_text()); value["entries"].append(dict(value["entries"][0])); write(schedule, value)
    launch["schedule"]["sha256"] = sha256_file(schedule); write(path, launch)
    verified = verify_launch_manifest(path, RUNNER)
    with pytest.raises(DispatchError, match="sample_cardinality"): resolve_sample(verified, 1, "EJCENV2VALR3-001")


def test_wrong_fixture_digest_fails(tmp_path):
    path, _ = setup_case(tmp_path); launch = verify_launch_manifest(path, RUNNER)
    (tmp_path / "fixture.json").write_text("mutated", encoding="utf-8")
    with pytest.raises(DispatchError, match="fixture_digest"): resolve_sample(launch, 1, "EJCENV2VALR3-001")


def test_pre_model_crashes_finalize_without_lifecycle_error(tmp_path):
    root = tmp_path / "root"; (root / "position-status").mkdir(parents=True)
    journal = root / "dispatch-lifecycle" / "POSITION-001.jsonl"
    value = finalize_pre_model_failure(root, 1, "EJCENV2VALR3-001", journal, "CHILD_CRASH")
    assert value["model_invocation_count"] == 0
    assert value["status"] == "PRE_MODEL_OPERATIONAL_FAILURE"
    verify_journal(journal)


def test_child_crash_after_handshake_pre_model_finalizes(tmp_path):
    root = tmp_path / "root"; (root / "position-status").mkdir(parents=True)
    journal = root / "dispatch-lifecycle" / "POSITION-001.jsonl"
    append_event(journal, "POSITION_PLANNED"); append_event(journal, "CHILD_IDENTITY_VERIFIED")
    assert finalize_pre_model_failure(root, 1, "EJCENV2VALR3-001", journal, "CHILD_CRASH")["model_invocation_count"] == 0


def test_journal_mutation_fails_closed(tmp_path):
    journal = tmp_path / "journal.jsonl"; append_event(journal, "POSITION_PLANNED")
    journal.write_text(journal.read_text().replace("POSITION_PLANNED", "MUTATED"), encoding="utf-8")
    with pytest.raises(DispatchError, match="MUTATION"): verify_journal(journal)


def test_incomplete_raw_lock_is_valid_and_never_analyze(tmp_path):
    root = tmp_path / "root"; root.mkdir(); (root / "position-status").mkdir()
    schedule = root / "schedule.json"; write(schedule, {"positions": 1, "entries": [{"position": 1, "sample_id": "EJCENV2VALR3-001"}]})
    journal = root / "dispatch-lifecycle" / "POSITION-001.jsonl"
    finalize_pre_model_failure(root, 1, "EJCENV2VALR3-001", journal, "MISMATCH")
    result = apply_gate(root, schedule)
    assert result["lock"]["status"] == "MEASUREMENT_INCOMPLETE_IMMUTABLE_NEVER_ANALYZE"
    assert verify_gate(root, schedule)["status"] == "PASS"


def test_protocol_precommits_zero_model_synthetic_matrix():
    value = json.loads((ROOT / "protocol" / "EJ_CAPACITY_RUNNER_DISPATCH_READINESS_V1.json").read_text())
    assert value["synthetic_matrix"]["model_invocations"] == 0
    assert value["synthetic_matrix"]["required_cases"] == 17


def test_policy_forbidden_hash_remains_exact():
    policy = ROOT / "calibration" / "evidence-judge-capacity-envelope-v2" / "EJ_CAPACITY_ENVELOPE_V2_POLICY.json"
    assert sha256_file(policy) == "16060ad484cedff8d7b204192689c0a4add1c4b008271c9b81b15548a0061efc"


def test_correct_dispatch_second_control(tmp_path):
    path, _ = setup_case(tmp_path, "EJCENV2VAL")
    launch = verify_launch_manifest(path, RUNNER)
    assert resolve_sample(launch, 1, "EJCENV2VAL-001")["position"] == 1
