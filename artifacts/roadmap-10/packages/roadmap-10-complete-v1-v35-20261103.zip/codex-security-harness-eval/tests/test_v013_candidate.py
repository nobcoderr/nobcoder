from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from verify_v013_candidate import verify  # noqa: E402


class V013CandidateTests(unittest.TestCase):
    def test_v013_candidate_stays_inside_frozen_boundary(self) -> None:
        result = verify()
        self.assertEqual(result["status"], "PASS", result["errors"])
        self.assertEqual(result["checks"]["change_boundary"]["status"], "PASS")
        self.assertEqual(result["checks"]["inherited_v012_intelligence_seal"]["status"], "PASS")
        self.assertEqual(result["checks"]["capacity_v2"], "PASS")
        self.assertEqual(result["checks"]["runtime_contract_values"], "PASS")


if __name__ == "__main__":
    unittest.main()
