from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SIM_PATH = ROOT / "scheduler-sim" / "simulate.py"
POLICY_PATH = ROOT / "scheduler-sim" / "policies" / "v0.1.3-candidate-a.json"
GENERATED = ROOT / "scheduler-sim" / "generated"


def load_simulator():
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("scheduler_sim", SIM_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class SchedulerSimulatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        if not (GENERATED / "historical_invocations.jsonl").is_file():
            raise RuntimeError("run scheduler-sim/build_dataset.py before tests")
        cls.simulator = load_simulator()
        cls.result = cls.simulator.simulate(POLICY_PATH)

    def test_dataset_is_expected_size(self) -> None:
        manifest = json.loads((GENERATED / "DATASET_MANIFEST.json").read_text())
        self.assertEqual(manifest["counts"]["combined_invocations"], 279)
        self.assertEqual(manifest["counts"]["v0.1.1_invocations"], 142)
        self.assertEqual(manifest["counts"]["v0.1.2_invocations"], 137)

    def test_candidate_eliminates_observed_overshoots(self) -> None:
        self.assertEqual(self.result["overall"]["overshooting_invocations"], 0)

    def test_efficiency_gates_pass(self) -> None:
        self.assertEqual(self.result["offline_replay_status"], "PASS")
        self.assertEqual(self.result["gate_failures"], [])
        self.assertEqual(self.result["role_gate_failures"], {})

    def test_verification_capacity_is_preserved(self) -> None:
        workflow = self.result["workflow_capacity"]
        self.assertEqual(workflow["invocation_terminal_path_capacity_fraction"], 1.0)
        self.assertLess(workflow["resource_terminal_path_capacity_fraction"], 1.0)
        self.assertGreater(
            workflow["verification_starvation_if_invocation_only_admission"], 0
        )
        self.assertEqual(workflow["bundle_capacity_per_episode"], 3)

    def test_mapper_convergence_threshold_replays_cleanly(self) -> None:
        convergence = self.result["convergence"]
        self.assertEqual(convergence["status"], "PASS")
        self.assertEqual(convergence["false_termination_count"], 0)
        self.assertEqual(convergence["detected_timeout_count"], 1)

    def test_contract_freeze_fails_closed_on_data_gaps(self) -> None:
        self.assertEqual(self.result["contract_freeze_status"], "BLOCKED_DATA_GAPS")
        codes = {item["code"] for item in self.result["blocking_data_gaps"]}
        self.assertEqual(
            codes,
            {"NO_EVIDENCE_JUDGE_TOKEN_SAMPLE", "RESOURCE_CLOSURE_NOT_PROVEN"},
        )


if __name__ == "__main__":
    unittest.main()
