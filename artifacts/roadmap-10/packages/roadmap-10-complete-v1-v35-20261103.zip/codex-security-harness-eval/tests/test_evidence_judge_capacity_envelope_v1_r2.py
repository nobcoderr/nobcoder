from __future__ import annotations

import json
from pathlib import Path

from execution_environment import sha256_file
from experiment_namespace_v1 import validate_schedule_bindings


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "calibration" / "evidence-judge-capacity-envelope-v1-validation-r2"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_r2_has_24_fresh_in_domain_workloads() -> None:
    manifest = load(BASE / "WORKLOAD_MANIFEST.json")
    previous = load(ROOT / "calibration" / "evidence-judge-capacity-envelope-v1-validation" / "WORKLOAD_MANIFEST.json")
    prior_digests = {row["sha256"] for row in previous["workloads"]}
    assert len(manifest["workloads"]) == 24
    assert manifest["counts"]["per_tier"] == {"SMALL": 8, "MEDIUM": 8, "LARGE": 8}
    assert not ({row["sha256"] for row in manifest["workloads"]} & prior_digests)
    for row in manifest["workloads"]:
        assert sha256_file(ROOT / row["path"]) == row["sha256"]
        tokens = row["measurements"]["prompt_lexical_tokens"]
        if row["tier"] == "SMALL":
            assert 0 <= tokens <= 5_000
        elif row["tier"] == "MEDIUM":
            assert 5_001 <= tokens <= 10_000
        else:
            assert 10_001 <= tokens <= 15_000


def test_r2_schedule_namespace_binding_and_exact_once() -> None:
    schedule = load(BASE / "SCHEDULE.json")
    assert schedule["experiment_namespace"] == "EJCENV1R2"
    assert [row["position"] for row in schedule["entries"]] == list(range(1, 25))
    assert len({row["fixture_id"] for row in schedule["entries"]}) == 24
    validate_schedule_bindings(schedule["entries"])
    assert schedule["retry_count"] == schedule["replacement_count"] == 0


def test_r2_capacity_policy_is_exactly_frozen_v1_policy() -> None:
    policy = ROOT / "calibration" / "evidence-judge-capacity-envelope-v1" / "EJ_CAPACITY_ENVELOPE_V1_POLICY.json"
    assert sha256_file(policy) == "df8fa209fef6097e21352e8fee20faff5a9b8f4bc95064f0dd931dd6ccdc8741"


def test_r2_protocol_keeps_v1_thresholds() -> None:
    value = load(ROOT / "protocol" / "EVIDENCE_JUDGE_CAPACITY_ENVELOPE_V1_VALIDATION_R2.json")
    assert value["acceptance"]["valid_completed"] == "24/24"
    assert value["acceptance"]["maximum_aggregate_requested_to_actual_ratio"] == 3.0
    assert value["acceptance"]["maximum_aggregate_unused_reservation_fraction"] == 0.6667
    assert set(value["acceptance"]["overshoot_events_by_dimension"].values()) == {0}

