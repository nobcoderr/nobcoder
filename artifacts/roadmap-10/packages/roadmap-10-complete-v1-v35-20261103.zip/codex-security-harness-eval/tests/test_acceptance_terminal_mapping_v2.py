from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from acceptance_terminal_mapping_v2 import map_plain_terminal  # noqa: E402
from verify_acceptance_terminal_mapping_v2 import verify  # noqa: E402


class AcceptanceTerminalMappingV2Tests(unittest.TestCase):
    def mapped(self, status: str, states: list[str], *, exit_code: int = 0, infra: bool = False) -> str:
        return map_plain_terminal(
            {"status": status, "candidates": [{"state": state} for state in states]},
            {"invalid_infrastructure": infra},
            {"exit_code": exit_code},
        )["terminal"]

    def test_frozen_synthetic_matrix(self) -> None:
        self.assertEqual(self.mapped("COMPLETE", ["KILL"]), "NO_VALID_FINDING")
        self.assertEqual(self.mapped("COMPLETE", ["REPORT_READY"]), "REPORT_READY")
        self.assertEqual(self.mapped("COMPLETE", ["STRONG"]), "BLOCKED")
        self.assertEqual(self.mapped("INCOMPLETE", [], exit_code=124), "TIMEOUT")
        self.assertEqual(self.mapped("BUDGET_EXHAUSTED", []), "BUDGET_EXHAUSTED")
        self.assertEqual(self.mapped("COMPLETE", [], infra=True), "INFRA_FAILURE")
        self.assertEqual(self.mapped("COMPLETE", ["KILL", "BLOCKED_DEPENDENCY"]), "BLOCKED")
        self.assertEqual(self.mapped("ABORTED", []), "ABORTED")
        self.assertEqual(self.mapped("COMPLETE", []), "NO_VALID_FINDING")

    def test_generic_complete_is_never_accepted_by_itself(self) -> None:
        result = map_plain_terminal(
            {"status": "COMPLETE", "candidates": [{"state": "UNKNOWN"}]}, {}, {"exit_code": 0}
        )
        self.assertEqual(result["terminal"], "BLOCKED")
        self.assertFalse(result["accepted_completion"])
        self.assertFalse(result["generic_complete_accepted"])

    def test_historical_regression_is_12_of_15_without_rescore(self) -> None:
        result = verify()
        self.assertEqual(result["status"], "PASS_LOCKABLE")
        self.assertEqual(result["historical_regression"]["accepted_completion"], 12)
        self.assertEqual(result["historical_regression"]["mapping_repairs"], 9)
        self.assertFalse(result["historical_regression"]["official_rc1_score_changed"])


if __name__ == "__main__":
    unittest.main()
