from __future__ import annotations

import copy

import pytest

from scripts.scientific_request_equivalence_v1 import request_identities, semantic_message_projection


def payload() -> dict:
    return {
        "type": "response.create",
        "model": "gpt-test",
        "parallel_tool_calls": False,
        "reasoning": {"effort": "xhigh"},
        "tool_choice": "auto",
        "input": [
            {"type": "additional_tools", "role": "developer", "id": "at-a", "tools": [{"name": "x"}]},
            {
                "type": "message",
                "role": "user",
                "id": "msg-a",
                "content": [{"type": "input_text", "text": "same"}],
                "internal_chat_message_metadata_passthrough": {"create_time": 1.0, "turn_id": "turn-a"},
            },
        ],
        "client_metadata": {"session_id": "session-a"},
        "prompt_cache_key": "cache-a",
        "store": False,
        "stream": True,
        "text": {"format": {"type": "json_schema", "schema": {"type": "object"}}, "verbosity": "low"},
    }


def test_runtime_and_item_identity_do_not_change_scientific_identity() -> None:
    left = payload()
    right = copy.deepcopy(left)
    right["input"][0]["id"] = "at-b"
    right["input"][1]["id"] = "msg-b"
    right["input"][1]["internal_chat_message_metadata_passthrough"] = {"create_time": 2.0, "turn_id": "turn-b"}
    right["client_metadata"] = {"session_id": "session-b"}
    right["prompt_cache_key"] = "cache-b"
    left_id = request_identities(left)
    right_id = request_identities(right)
    assert left_id["full_message_digest"] != right_id["full_message_digest"]
    assert left_id["runtime_full_digest"] != right_id["runtime_full_digest"]
    assert left_id["semantic_message_digest"] == right_id["semantic_message_digest"]
    assert left_id["scientific_request_digest"] == right_id["scientific_request_digest"]


def test_content_change_changes_semantic_and_scientific_identity() -> None:
    left = payload()
    right = copy.deepcopy(left)
    right["input"][1]["content"][0]["text"] = "different"
    assert request_identities(left)["semantic_message_digest"] != request_identities(right)["semantic_message_digest"]
    assert request_identities(left)["scientific_request_digest"] != request_identities(right)["scientific_request_digest"]


def test_order_change_changes_semantic_identity() -> None:
    left = payload()
    right = copy.deepcopy(left)
    right["input"] = list(reversed(right["input"]))
    assert request_identities(left)["semantic_message_digest"] != request_identities(right)["semantic_message_digest"]


def test_unknown_input_item_fails_closed() -> None:
    value = payload()["input"]
    value.append({"type": "unknown", "role": "user", "content": []})
    with pytest.raises(ValueError, match="unsupported input item type"):
        semantic_message_projection(value)

