from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_message_classifier import FixtureIdentity, canonical_digest, classify_messages, sha256_bytes  # noqa: E402


MODEL = "gpt-test"
PROMPT = "fixture-bound-prompt"
SCHEMA = {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"], "additionalProperties": False}
IDENTITY = FixtureIdentity(MODEL, sha256_bytes(PROMPT.encode()), canonical_digest(SCHEMA))


def response_create(*, prompt: str | None = PROMPT, schema: object = SCHEMA, model: str = MODEL) -> dict:
    inputs = [{"type": "message", "role": "developer", "content": [{"type": "input_text", "text": "setup"}]}]
    if prompt is not None:
        inputs.append({"type": "message", "role": "user", "content": [{"type": "input_text", "text": prompt}]})
    payload = {"type": "response.create", "model": model, "input": inputs, "text": {"format": {"type": "json_schema", "schema": schema}}}
    return payload


class ClassifierFixture:
    def __init__(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.rows: list[dict] = []

    def close(self) -> None:
        self.temporary.cleanup()

    def add(self, payload: object, *, message_type: str = "text") -> None:
        sequence = len(self.rows) + 1
        raw = json.dumps(payload, separators=(",", ":")).encode()
        name = f"message-{sequence}.bin"
        (self.root / name).write_bytes(raw)
        self.rows.append({
            "direction": "client_to_server",
            "message_sequence": sequence,
            "message_type": message_type,
            "raw_artifact": name,
            "raw_message_sha256": sha256_bytes(raw),
        })


class IracV2MessageClassifierTests(unittest.TestCase):
    def setUp(self) -> None:
        self.fixture = ClassifierFixture()

    def tearDown(self) -> None:
        self.fixture.close()

    def classify(self) -> dict:
        return classify_messages(self.fixture.rows, self.fixture.root, IDENTITY)

    def test_setup_plus_inference_selects_inference(self) -> None:
        self.fixture.add(response_create(prompt=None, schema={"type": "object"}))
        self.fixture.add(response_create())
        result = self.classify()
        self.assertEqual("PASS", result["status"])
        self.assertEqual(2, result["selected"]["message_sequence"])

    def test_inference_plus_control_selects_inference(self) -> None:
        self.fixture.add(response_create())
        self.fixture.add({"type": "response.cancel", "response_id": "r1"})
        result = self.classify()
        self.assertEqual("PASS", result["status"])
        self.assertEqual(1, result["selected_count"])

    def test_multiple_request_like_selects_exact_fixture(self) -> None:
        self.fixture.add(response_create(prompt="different"))
        self.fixture.add(response_create())
        self.fixture.add(response_create(model="different"))
        result = self.classify()
        self.assertEqual("PASS", result["status"])
        self.assertEqual(2, result["selected"]["message_sequence"])

    def test_zero_matching_fails_closed(self) -> None:
        self.fixture.add(response_create(prompt="different"))
        result = self.classify()
        self.assertEqual("FAIL_CLOSED", result["status"])
        self.assertEqual("ZERO_FIXTURE_BOUND_INFERENCE_REQUESTS", result["reason"])

    def test_multiple_matching_fails_closed(self) -> None:
        self.fixture.add(response_create())
        self.fixture.add(response_create())
        result = self.classify()
        self.assertEqual("FAIL_CLOSED", result["status"])
        self.assertEqual("MULTIPLE_FIXTURE_BOUND_INFERENCE_REQUESTS", result["reason"])

    def test_unknown_message_type_fails_closed(self) -> None:
        self.fixture.add(response_create())
        self.fixture.add({"type": "future.unknown", "value": 1})
        result = self.classify()
        self.assertEqual("FAIL_CLOSED", result["status"])
        self.assertIn("UNKNOWN_CLIENT_ENVELOPE:2:future.unknown", result["fatal_errors"])


if __name__ == "__main__":
    unittest.main()
