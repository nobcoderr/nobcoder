from __future__ import annotations

import ast
import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_full_bundle_replay_v2.py"
SPEC = importlib.util.spec_from_file_location("full_bundle_replay_v2", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_only_boolean_name_repair_is_active() -> None:
    assert MODULE.V1.replay.__globals__["false"] is False
    assert MODULE.V1.sha256_file(MODULE.V1_RUNNER) == "0c9ff0dd739c4beda9008f8252a6fee0a1bc0671e9eae5e7b9c8b6eda8ee7bb9"


def test_v2_runner_has_no_unresolved_lowercase_boolean_name() -> None:
    tree = ast.parse(MODULE_PATH.read_text(encoding="utf-8"))
    names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
    assert "false" not in names
    assert "true" not in names


def test_v1_scientific_protocol_is_inherited_byte_for_byte() -> None:
    config = MODULE.load_v2_protocol()["inherits_scientific_contract"]
    assert MODULE.V1.sha256_file(MODULE.V1.resolve(config["path"])) == config["sha256"]
    assert MODULE.inherited_protocol()["acceptance_gates"]["eligible_paths"] == 33


def test_aborted_v1_has_no_result() -> None:
    predecessor = MODULE.verify_predecessor()
    assert predecessor["status"] == "ABORTED_IMPLEMENTATION_DEFECT"
    assert predecessor["result_json_created"] is False
    assert predecessor["model_invocations"] == 0


def test_v2_preflight_is_clean_and_nonexecuting() -> None:
    value = MODULE.preflight(False)
    assert value["status"] == "PRE_EXECUTION_LOCKED"
    assert value["identity"] == "full-bundle-replay-v2"
    assert value["eligible_path_count"] == 33
    assert value["model_invocations"] == 0
