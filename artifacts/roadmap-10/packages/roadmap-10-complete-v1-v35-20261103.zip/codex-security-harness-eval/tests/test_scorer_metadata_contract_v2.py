from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from scorer_metadata_contract_v2 import (  # noqa: E402
    MetadataContractError,
    resolve_acceptance_protocol_sha256,
)


VALID = "31f7f26d4540e4d77265d592e20323c24efbcc5e12e26f30afd47b8869a172fa"


class ScorerMetadataContractV2Tests(unittest.TestCase):
    def test_valid_nested_provenance_passes(self) -> None:
        self.assertEqual(
            resolve_acceptance_protocol_sha256(
                {"provenance": {"acceptance_protocol_sha256": VALID}}
            ),
            VALID,
        )

    def test_missing_provenance_fails_closed(self) -> None:
        with self.assertRaises(MetadataContractError):
            resolve_acceptance_protocol_sha256({})

    def test_conflicting_top_level_and_nested_fails_closed(self) -> None:
        with self.assertRaises(MetadataContractError):
            resolve_acceptance_protocol_sha256({
                "acceptance_protocol_sha256": "0" * 64,
                "provenance": {"acceptance_protocol_sha256": VALID},
            })

    def test_matching_legacy_copy_is_not_ambiguous(self) -> None:
        self.assertEqual(
            resolve_acceptance_protocol_sha256({
                "acceptance_protocol_sha256": VALID,
                "provenance": {"acceptance_protocol_sha256": VALID},
            }),
            VALID,
        )


if __name__ == "__main__":
    unittest.main()
