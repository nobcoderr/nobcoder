from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

from scripts.analyze_request_identity_characterization_v1 import analyze_rows


ROOT = Path(__file__).resolve().parents[1]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def row(index: int, *, semantic: str = "semantic-a", scientific: str = "science-a", runtime: str | None = None, total: int = 100, cached: int = 80) -> dict:
    return {
        "semantic_message_digest": semantic,
        "scientific_request_digest": scientific,
        "runtime_full_digest": runtime or f"runtime-{index}",
        "runtime_field_digests": {"client_metadata": f"client-{index}"},
        "reported_total_input": total,
        "reported_cached_input": cached,
        "reported_noncached_input": total - cached,
    }


def contract(**overrides) -> dict:
    value = {"model_visible_runtime_fields": [], "unknown_runtime_fields": []}
    value.update(overrides)
    return value


def test_schedule_is_balanced_unique_and_no_retry() -> None:
    schedule = load(ROOT / "calibration" / "request-identity-characterization-v1" / "SCHEDULE.json")
    assert [item["position"] for item in schedule["entries"]] == list(range(1, 13))
    assert len({item["sample_id"] for item in schedule["entries"]}) == 12
    assert Counter(item["condition"] for item in schedule["entries"]) == Counter({"EMPTY_START": 4, "MODEL_CACHE_ONLY": 4, "MODEL_PLUS_APPS_CACHE": 4})
    assert schedule["retry_count"] == schedule["replacement_count"] == 0


def test_semantic_stability_and_cache_split_are_combined() -> None:
    rows = [row(i, cached=0 if i < 3 else 80) for i in range(12)]
    result = analyze_rows(rows, contract())
    assert result["primary_outcome"] == "SEMANTIC_REQUEST_STABLE_RUNTIME_METADATA_VOLATILE"
    assert result["authoritative_conclusions"] == [
        "SEMANTIC_REQUEST_STABLE_RUNTIME_METADATA_VOLATILE",
        "CACHE_ACCOUNTING_SPLIT_VARIATION_ESTABLISHED",
    ]


def test_semantic_message_drift_wins() -> None:
    rows = [row(i, semantic="a" if i < 6 else "b") for i in range(12)]
    result = analyze_rows(rows, contract())
    assert result["primary_outcome"] == "PRE_INFERENCE_MESSAGE_DRIFT_ESTABLISHED"


def test_model_visible_runtime_drift_is_separate() -> None:
    rows = [row(i) for i in range(12)]
    result = analyze_rows(rows, contract(model_visible_runtime_fields=["client_metadata"]))
    assert result["primary_outcome"] == "RUNTIME_CONTEXT_DRIFT_ESTABLISHED"


def test_unknown_runtime_field_fails_closed() -> None:
    rows = [row(i) for i in range(12)]
    result = analyze_rows(rows, contract(unknown_runtime_fields=["mystery"]))
    assert result["primary_outcome"] == "UNRESOLVED"


def test_accounting_sum_violation_blocks_cache_split() -> None:
    rows = [row(i, cached=0 if i < 3 else 80) for i in range(12)]
    rows[0]["reported_noncached_input"] = 99
    result = analyze_rows(rows, contract())
    assert "CACHE_ACCOUNTING_SPLIT_VARIATION_ESTABLISHED" not in result["authoritative_conclusions"]

