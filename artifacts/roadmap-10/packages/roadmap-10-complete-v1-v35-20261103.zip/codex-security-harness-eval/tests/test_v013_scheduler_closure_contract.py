from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "lock_v013_scheduler_closure_contract.py"
SPEC = importlib.util.spec_from_file_location("lock_v013_scheduler_closure_contract", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def contract():
    return MODULE.load_json(MODULE.CONTRACT)


def test_governance_authority_is_locked_policy_c() -> None:
    value = contract()
    result = MODULE.load_json(MODULE.resolve(value["authorized_by"]["closure_budget_governance_result"]["path"]))
    assert result["status"] == "PASS_LOCKED"
    assert result["selected_policy"] == "policy_c"
    assert result["v0.1.3_contract_freeze_authorized"] is True


def test_run_envelope_and_capacity_v2_are_unchanged() -> None:
    value = contract()
    assert value["run_envelope"]["noncached_input_tokens"] == 360000
    assert value["run_envelope"]["invocation_slots"] == 16
    assert value["input_and_cache_policy"]["capacity_policy_tuning_during_v0.1.3"] == "FORBIDDEN"


def test_candidate_admission_requires_full_escrow() -> None:
    value = contract()
    machine = value["candidate_state_machine"]
    assert machine["maximum_active_closure_candidates"] == 1
    assert "FULL_CLOSURE_ESCROW_RESERVED" in machine["admission_invariant"]
    assert machine["admitted_candidate_verification_starvation_permitted"] is False


def test_invocation_and_wall_are_first_class_reserves() -> None:
    value = contract()
    assert value["invocation_and_wall_governance"]["invocation_floor"] == 4
    assert value["invocation_and_wall_governance"]["wall_floor_seconds"] == 335
    assert "invocation_slots" in value["global_closure_floor"]["dimensions"]
    assert "wall_time_seconds" in value["global_closure_floor"]["dimensions"]


def test_intelligence_layer_is_frozen() -> None:
    forbidden = set(contract()["frozen_intelligence"]["required_unchanged"])
    assert "prompts" in forbidden
    assert "skills" in forbidden
    assert "Evidence Judge decision logic" in forbidden
    assert "security methodology and threat model" in forbidden


def test_release_remains_blocked_until_new_acceptance() -> None:
    value = contract()
    assert value["target_product"]["release_state"] == "BLOCKED_UNTIL_NEW_ACCEPTANCE_PASS"
    assert value["release_rule"]["fresh_holdout_before_release"] == "FORBIDDEN"
    assert value["release_rule"]["pilot_v3_before_release"] == "BLOCKED"


def test_contract_validator_passes_without_writing() -> None:
    value = MODULE.validate()
    assert value["status"] == "READY_TO_LOCK"
    assert value["v0.1.3_implementation_authorized"] is True
    assert value["model_invocations"] == 0

