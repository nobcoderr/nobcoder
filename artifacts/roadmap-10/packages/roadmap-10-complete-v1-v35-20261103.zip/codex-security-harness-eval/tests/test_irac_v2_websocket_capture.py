from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import irac_v2_websocket_capture as addon  # noqa: E402
import preflight_irac_v2_websocket_capture as preflight  # noqa: E402
import run_irac_v2_codex_capture_smoke as smoke  # noqa: E402


class IracV2WebSocketCaptureTests(unittest.TestCase):
    def test_component_projection_finds_nested_request(self) -> None:
        message = {
            "type": "request",
            "payload": {
                "model": "gpt-test",
                "input": [{"role": "user", "content": "sentinel"}],
                "tools": [{"type": "function", "name": "tool"}],
                "prompt_cache_key": "excluded",
            },
        }
        result = addon.request_component_projection(message)
        self.assertTrue(result["request_payload_found"])
        self.assertIn("message_or_input_payload", result["component_sha256"])
        self.assertIn("token_bearing_request_payload", result["component_sha256"])

    def test_non_request_message_is_explicit(self) -> None:
        result = addon.request_component_projection({"type": "ack"})
        self.assertFalse(result["request_payload_found"])
        self.assertEqual({}, result["component_sha256"])

    def test_protocol_denies_official_execution(self) -> None:
        protocol = json.loads((ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2.json").read_text())
        self.assertEqual("FROZEN_CAPTURE_READINESS_OFFICIAL_EXECUTION_DENIED", protocol["status"])
        self.assertFalse(protocol["authorizations"]["official_irac_v2_execution"])
        self.assertTrue(protocol["prohibitions"]["official_irac_v2_invocation_before_readiness_lock"])
        self.assertEqual("NOT_CREATED", protocol["official_plan_after_readiness"]["official_schedule"])

    def test_acceptance_fails_closed_on_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            capture = Path(temporary)
            raw = b"one"
            (capture / "connection-001-message-0001.bin").write_bytes(raw)
            (capture / "connection-001-message-0001.components.json").write_text("{}\n")
            row = {
                "event": "WEBSOCKET_LOGICAL_MESSAGE",
                "direction": "client_to_server",
                "message_sequence": 1,
                "message_type": "text",
                "raw_message_sha256": addon.sha256_bytes(raw),
                "content_before_hook_sha256": addon.sha256_bytes(raw),
                "content_after_hook_sha256": "0" * 64,
                "content_mutated_by_addon": True,
                "dropped": False,
                "injected": False,
                "raw_artifact": "connection-001-message-0001.bin",
                "component_artifact": "connection-001-message-0001.components.json",
            }
            (capture / "websocket-events.jsonl").write_text(json.dumps(row) + "\n")
            result = preflight.validate_acceptance(
                capture_dir=capture,
                sent=[{"sha256": addon.sha256_bytes(raw)}],
                received=[],
                server_received=[],
                pong_received=False,
            )
            self.assertEqual("FAIL", result["status"])
            self.assertFalse(result["checks"]["payload_mutation_zero"])

    def test_smoke_validation_requires_exact_sentinel_request(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            capture = Path(temporary)
            payload = {
                "request": {
                    "model": "gpt-test",
                    "input": "IRAC-V2-WS-CAPTURE-SENTINEL-20261005",
                }
            }
            raw = json.dumps(payload).encode()
            sha = addon.sha256_bytes(raw)
            (capture / "request.bin").write_bytes(raw)
            components = addon.request_component_projection(payload)
            (capture / "request.components.json").write_text(json.dumps(components))
            events = [
                {"event": "WEBSOCKET_ESTABLISHED"},
                {
                    "event": "WEBSOCKET_LOGICAL_MESSAGE",
                    "direction": "client_to_server",
                    "message_sequence": 1,
                    "message_type": "text",
                    "raw_message_sha256": sha,
                    "canonical_message_sha256": addon.canonical_digest(payload),
                    "content_before_hook_sha256": sha,
                    "content_after_hook_sha256": sha,
                    "content_mutated_by_addon": False,
                    "dropped": False,
                    "injected": False,
                    "raw_artifact": "request.bin",
                    "component_artifact": "request.components.json",
                    "sentinel_occurrences": 1,
                },
                {"event": "WEBSOCKET_CLOSED"},
            ]
            (capture / "websocket-events.jsonl").write_text("\n".join(json.dumps(row) for row in events) + "\n")
            (capture / "http-events.jsonl").write_text(json.dumps({
                "event": "HTTP_UPGRADE_REQUEST",
                "websocket_upgrade": True,
                "path": "/backend-api/codex/responses",
            }) + "\n")
            result = smoke.validate_smoke(capture, "IRAC-V2-WS-CAPTURE-SENTINEL-20261005")
            self.assertEqual("PASS", result["status"])
            self.assertTrue(result["checks"]["request_payload_reconstructed"])


if __name__ == "__main__":
    unittest.main()
