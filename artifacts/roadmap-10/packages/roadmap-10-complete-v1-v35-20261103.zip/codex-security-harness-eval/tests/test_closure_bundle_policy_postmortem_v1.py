from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_closure_bundle_policy_postmortem_v1.py"
SPEC = importlib.util.spec_from_file_location("closure_bundle_policy_postmortem_v1", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def event(sequence: int, event_type: str, invocation: str, job: str, reservation=None, actual=None):
    return {
        "sequence": sequence,
        "event_type": event_type,
        "invocation_id": invocation,
        "job_id": job,
        "payload": {"reservation": reservation, "actual": actual},
    }


def tokens(total: int, noncached: int, output: int, reasoning: int):
    return {
        "total_input_tokens": total,
        "noncached_input_tokens": noncached,
        "output_tokens": output,
        "reasoning_tokens": reasoning,
    }


def test_protocol_freezes_exact_bundle_and_envelope() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    assert protocol["closure_bundle"] == {
        "total_input_tokens": 743000,
        "noncached_input_tokens": 258000,
        "output_tokens": 25000,
        "reasoning_tokens": 15700,
        "invocation_slots": 4,
        "wall_time_seconds": 335,
    }
    assert protocol["run_envelope"]["noncached_input_tokens"] == 360000
    assert protocol["decision"]["v0.1.3_implementation"] == "DENIED"


def test_dependency_lineage_is_not_role_based() -> None:
    jobs = {
        "mapper": {"depends_on": [], "role": "mapper"},
        "semantic-parent": {"depends_on": ["mapper"], "role": "skeptic"},
        "producer": {"depends_on": ["semantic-parent"], "role": "researcher"},
        "other-researcher": {"depends_on": ["mapper"], "role": "researcher"},
    }
    assert MODULE.transitive_ancestors("producer", jobs) == ["mapper", "semantic-parent", "producer"]
    assert "other-researcher" not in MODULE.transitive_ancestors("producer", jobs)


def test_replay_uses_settled_actual_plus_active_reservation() -> None:
    events = [
        event(1, "RESERVATION_ADMITTED", "i-map", "mapper", tokens(100, 50, 10, 5)),
        event(2, "INVOCATION_STARTED", "i-map", "mapper"),
        event(3, "RESERVATION_SETTLED", "i-map", "mapper", actual=tokens(80, 40, 8, 4)),
        event(4, "RESERVATION_ADMITTED", "i-prod", "producer", tokens(200, 100, 20, 10)),
        event(5, "RESERVATION_ADMITTED", "i-opt", "optional", tokens(300, 150, 30, 15)),
        event(6, "INVOCATION_STARTED", "i-prod", "producer"),
        event(7, "INVOCATION_STARTED", "i-opt", "optional"),
        event(8, "RESERVATION_SETTLED", "i-prod", "producer", actual=tokens(160, 90, 16, 8)),
    ]
    snapshot = MODULE.replay_to_sequence(events, 8)
    assert snapshot["settled_actual"] == tokens(240, 130, 24, 12)
    assert snapshot["active_reserved"] == tokens(300, 150, 30, 15)
    assert snapshot["historical_committed_footprint"] == tokens(540, 280, 54, 27)
    assert set(snapshot["started"]) == {"i-map", "i-prod", "i-opt"}


def test_overshoot_terminal_consumes_actual_and_releases_reservation() -> None:
    events = [
        event(1, "RESERVATION_ADMITTED", "i1", "job", tokens(100, 50, 10, 5)),
        event(2, "INVOCATION_STARTED", "i1", "job"),
        event(3, "RESERVATION_OVERSHOOT_INVALID", "i1", "job", actual=tokens(110, 55, 11, 6)),
    ]
    snapshot = MODULE.replay_to_sequence(events, 3)
    assert snapshot["settled_actual"] == tokens(110, 55, 11, 6)
    assert snapshot["active_reserved"] == tokens(0, 0, 0, 0)


def test_critical_path_uses_dependency_edges() -> None:
    jobs = {
        "a": {"depends_on": []},
        "b": {"depends_on": []},
        "c": {"depends_on": ["a", "b"]},
    }
    durations = {"a": 10.0, "b": 30.0, "c": 5.0}
    assert MODULE.critical_path_seconds("c", jobs, durations) == 35.0


def test_four_classification_branches_are_frozen() -> None:
    assert MODULE.classify_path(True, True, True) == "BASELINE_FULL_CLOSURE_FEASIBLE"
    assert MODULE.classify_path(False, True, True) == "POLICY_FIXABLE_POST_ADMISSION"
    assert MODULE.classify_path(False, False, True) == "POLICY_FIXABLE_PRE_ADMISSION_FANOUT"
    assert MODULE.classify_path(False, False, False) == "RUN_ENVELOPE_STRUCTURALLY_INSUFFICIENT"


def test_slack_and_blocker_order_are_deterministic() -> None:
    envelope = {field: 100.0 for field in MODULE.CAPACITY_FIELDS}
    footprint = {field: 20.0 for field in MODULE.CAPACITY_FIELDS}
    bundle = {field: 70.0 for field in MODULE.CAPACITY_FIELDS}
    bundle["noncached_input_tokens"] = 90.0
    bundle["output_tokens"] = 95.0
    slack = MODULE.slack_vector(envelope, footprint, bundle)
    order = list(MODULE.load_json(MODULE.PROTOCOL)["slack_contract"]["canonical_dimension_order"])
    assert MODULE.blockers(slack, order) == ["noncached_input_tokens", "output_tokens"]


def test_frozen_inputs_and_database_manifest_verify() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    assert len(MODULE.verify_protocol_inputs(protocol)) == len(protocol["frozen_inputs"])
    assert len(MODULE.verify_source_databases(protocol)) == 11


def test_preflight_is_offline_and_resolves_33_paths() -> None:
    value = MODULE.preflight(False)
    assert value["status"] == "PRE_EXECUTION_LOCKED"
    assert value["eligible_path_count"] == 33
    assert value["model_invocations"] == 0


def test_full_bundle_v2_remains_locked_fail() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    result = MODULE.load_json(MODULE.resolve(protocol["frozen_inputs"]["full_bundle_v2_result"]["path"]))
    disposition = MODULE.load_json(
        MODULE.resolve(protocol["frozen_inputs"]["full_bundle_v2_disposition"]["path"])
    )
    assert result["status"] == "FAIL"
    assert result["full_closure_feasible_paths"] == 9
    assert result["independent_single_bundle_feasible_paths"] == 27
    assert disposition["status"] == "FAIL_LOCKED"


def test_runner_has_no_model_or_network_dependency() -> None:
    source = MODULE_PATH.read_text(encoding="utf-8")
    assert "subprocess" not in source
    assert "requests" not in source
    assert "websocket" not in source.lower()

