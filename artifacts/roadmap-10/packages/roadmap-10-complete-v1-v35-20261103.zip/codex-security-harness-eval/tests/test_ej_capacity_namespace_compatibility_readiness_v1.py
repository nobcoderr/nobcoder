from __future__ import annotations

import json
from pathlib import Path

import pytest

from experiment_namespace_v1 import (
    NamespaceValidationError,
    generic_core_schema,
    validate_binding,
    validate_schedule_bindings,
)
from ej_capacity_namespace_core_v1 import execute_with_namespace
import irac_v2_official_execution_core_r2 as irac_core
from run_ej_capacity_namespace_readiness_v1_acceptance import run


ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize(
    ("namespace", "sample_id", "position"),
    [
        ("IRAC2", "IRAC2-001", 1),
        ("EJCENV1", "EJCENV1-001", 1),
        ("ABC123", "ABC123-999", 999),
    ],
)
def test_generic_namespace_accepts_legacy_new_and_arbitrary(namespace: str, sample_id: str, position: int) -> None:
    assert validate_binding({
        "experiment_namespace": namespace,
        "sample_id": sample_id,
        "position": position,
    })["sample_id"] == sample_id


@pytest.mark.parametrize(
    "value",
    [
        {"sample_id": "EJCENV1-001", "position": 1},
        {"experiment_namespace": "EJ/C", "sample_id": "EJ/C-001", "position": 1},
        {"experiment_namespace": "EJCENV1", "sample_id": "IRAC2-001", "position": 1},
        {"experiment_namespace": "EJCENV1", "sample_id": "EJCENV1-003", "position": 4},
        {"experiment_namespace": "ACTIVE", "sample_id": "ACTIVE-001", "position": 1},
    ],
)
def test_namespace_contract_fails_closed(value: dict) -> None:
    with pytest.raises(NamespaceValidationError):
        validate_binding(value)


def test_duplicate_sample_id_fails_closed() -> None:
    row = {"experiment_namespace": "EJCENV1", "sample_id": "EJCENV1-001", "position": 1}
    with pytest.raises(NamespaceValidationError, match="DUPLICATE_SAMPLE_ID"):
        validate_schedule_bindings([row, row])


def test_generic_core_is_derived_without_mutating_legacy_schema() -> None:
    legacy_path = ROOT / "schemas" / "evidence-judge-variance-core-observation-v2-r2.schema.json"
    before = legacy_path.read_bytes()
    generic = generic_core_schema()
    assert generic["properties"]["sample_id"]["pattern"] != "^IRAC2[A-Z0-9-]+$"
    assert {"experiment_namespace", "position"}.issubset(generic["required"])
    assert legacy_path.read_bytes() == before


def test_synthetic_post_model_pipeline_matrix(tmp_path: Path) -> None:
    result = run(tmp_path / "synthetic")
    assert result["status"] == "PASS"
    assert result["model_invocations"] == 0
    assert set(result["cases"]) == {
        "legacy_irac",
        "ej_capacity",
        "arbitrary_valid",
        "invalid_namespace",
        "namespace_mismatch",
        "position_mismatch",
        "duplicate_sample",
    }
    for name in ("legacy_irac", "ej_capacity", "arbitrary_valid"):
        assert result["cases"][name]["telemetry_created"] is True
        assert result["cases"][name]["finalization"] == "PASS"
        assert result["cases"][name]["lock_created"] is True


def test_contract_file_is_a_json_schema() -> None:
    contract = json.loads((ROOT / "protocol" / "EXPERIMENT_NAMESPACE_SCHEMA_V1.json").read_text())
    assert contract["x-contract"]["prefix_allowlist"] is False
    assert contract["x-contract"]["case_sensitive"] is True


def test_execution_adapter_injects_namespace_before_core_validation(tmp_path: Path) -> None:
    from run_ej_capacity_namespace_readiness_v1_acceptance import base_observation
    staging = tmp_path / "active" / "EJCENV1-001"
    staging.mkdir(parents=True)
    (staging / "observation.json").write_text(
        json.dumps(base_observation("EJCENV1-001", 1)), encoding="utf-8"
    )

    def fake_executor(_root: Path, _entry: dict) -> dict:
        irac_core._validator(staging)
        return {"status": "PASS"}

    result = execute_with_namespace(
        tmp_path,
        {
            "experiment_namespace": "EJCENV1",
            "sample_id": "EJCENV1-001",
            "position": 1,
        },
        fake_executor,
    )
    observation = json.loads((staging / "observation.json").read_text())
    assert result["status"] == "PASS"
    assert observation["experiment_namespace"] == "EJCENV1"
    assert observation["position"] == 1
    assert (staging / "artifacts" / "namespace-validation.json").is_file()
