from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import shutil
import stat
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_runner():
    path = ROOT / "scripts" / "run_evidence_judge_variance_decomposition_v1.py"
    spec = importlib.util.spec_from_file_location("run_ej_variance_v1", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


RUNNER = load_runner()


def make_writable(root: Path) -> None:
    if not root.exists():
        return
    for path in [root, *root.rglob("*")]:
        if path.is_symlink():
            continue
        try:
            mode = stat.S_IMODE(path.stat().st_mode)
            path.chmod(mode | 0o700)
        except FileNotFoundError:
            pass


class FakeExecutor:
    def __init__(self, invalid_position: int | None = None) -> None:
        self.invalid_position = invalid_position
        self.calls: list[dict] = []
        self.active = 0
        self.max_active = 0

    def __call__(self, root, entry, protocol, manifest, runner_lock):
        self.active += 1
        self.max_active = max(self.max_active, self.active)
        self.calls.append(dict(entry))
        try:
            observation_dir = root / "observations" / entry["sample_id"]
            observation_dir.mkdir(parents=True)
            payload = observation_dir / "raw-sentinel.json"
            payload.write_text(json.dumps({"entry": entry}, sort_keys=True) + "\n", encoding="utf-8")
            row = next(item for item in manifest["workloads"] if item["fixture_id"] == entry["fixture_id"])
            invalid = entry["position"] == self.invalid_position
            observation = {
                "schema_version": 1,
                "schedule_position": entry["position"],
                "sample_id": entry["sample_id"],
                "fixture_id": entry["fixture_id"],
                "family": entry["family"],
                "repetition": entry["repetition"],
                "session_id": f"fake-session-{entry['position']:03d}",
                "fresh_session": True,
                "concurrency": 1,
                "fixture_digest": row["sha256"],
                "input_context_digest": hashlib.sha256(entry["sample_id"].encode()).hexdigest(),
                "total_input_tokens": 10000 + entry["position"],
                "cached_input_tokens": 100,
                "noncached_input_tokens": 9900 + entry["position"],
                "output_tokens": 500,
                "reasoning_tokens": 250,
                "wall_seconds": 1.0,
                "exit_code": 1 if invalid else 0,
                "schema_valid": not invalid,
                "resource_compliant": True,
                "terminal_status": "INVALID_INFRASTRUCTURE" if invalid else "VALID_COMPLETED",
                "valid_for_primary_analysis": not invalid,
                "runtime_digest": runner_lock["runtime_package_manifest_sha256"],
                "product_digest": runner_lock["product_clean_tree_sha256"],
                "artifact_digest": "0" * 64,
                "started_at": "2026-10-05T00:00:00+00:00",
                "ended_at": "2026-10-05T00:00:01+00:00",
            }
            return RUNNER.freeze_invocation_artifact(observation_dir, observation, [payload])
        finally:
            self.active -= 1


class EvidenceJudgeVarianceRunnerV1Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.workspace = Path(tempfile.mkdtemp(prefix="ejvd-runner-tests-"))
        cls.base = cls.workspace / "base"
        RUNNER.plan(cls.base)
        cls.sealed_schedule = json.loads(RUNNER.SCHEDULE.read_text())["entries"]

    @classmethod
    def tearDownClass(cls) -> None:
        make_writable(cls.workspace)
        shutil.rmtree(cls.workspace, ignore_errors=True)

    def setUp(self) -> None:
        self.root = self.workspace / self.id().rsplit(".", 1)[-1]
        shutil.copytree(self.base, self.root)

    def tearDown(self) -> None:
        make_writable(self.root)
        shutil.rmtree(self.root, ignore_errors=True)

    def test_runner_lock_and_runtime_preflight_pass_without_model(self) -> None:
        verified = RUNNER.verify_runner_lock()
        self.assertEqual(verified["design"]["preflight"]["status"], "PASS")
        self.assertEqual(verified["lock"]["model_invocations_at_lock"], 0)

    def test_plan_preserves_all_54_positions_exactly_once(self) -> None:
        copied = json.loads((self.root / "schedule.json").read_text())["entries"]
        self.assertEqual(copied, self.sealed_schedule)
        self.assertEqual(len(copied), 54)
        self.assertEqual(len({row["sample_id"] for row in copied}), 54)
        progress = json.loads((self.root / "progress.json").read_text())
        self.assertTrue(all(value == "PENDING" for value in progress["samples"].values()))

    def test_fake_execution_preserves_order_uniqueness_fresh_sessions_and_concurrency(self) -> None:
        fake = FakeExecutor()
        result = RUNNER.execute(self.root, sample_executor=fake)
        self.assertEqual(result["status"], "EXECUTION_COMPLETE_VALID")
        self.assertEqual([row["sample_id"] for row in fake.calls], [row["sample_id"] for row in self.sealed_schedule])
        self.assertEqual(len(fake.calls), 54)
        self.assertEqual(fake.max_active, 1)
        self.assertTrue(result["fresh_session_uniqueness_valid"])
        lock = RUNNER.verify_raw_execution_lock(self.root)
        self.assertTrue(lock["analysis_authorized"])

    def test_invalid_position_invalidates_entire_experiment_without_retry_or_replacement(self) -> None:
        fake = FakeExecutor(invalid_position=17)
        result = RUNNER.execute(self.root, sample_executor=fake)
        self.assertEqual(result["status"], "EXECUTION_COMPLETE_INVALID_SAMPLE_FAILURE")
        self.assertEqual(len(fake.calls), 54)
        self.assertEqual(sum(row["position"] == 17 for row in fake.calls), 1)
        self.assertFalse(result["analysis_authorized"])
        self.assertTrue(result["no_retries"])
        self.assertTrue(result["no_replacements"])

    def test_resume_continues_at_exact_next_position_and_never_repeats_completed(self) -> None:
        first = FakeExecutor()
        paused = RUNNER.execute(self.root, sample_executor=first, safe_boundary_stop_after=10)
        self.assertEqual(paused["status"], "PAUSED_AT_SAFE_BOUNDARY")
        self.assertEqual(paused["next_position"], 11)
        second = FakeExecutor()
        result = RUNNER.execute(self.root, sample_executor=second)
        self.assertEqual(result["status"], "EXECUTION_COMPLETE_VALID")
        self.assertEqual([row["position"] for row in first.calls], list(range(1, 11)))
        self.assertEqual([row["position"] for row in second.calls], list(range(11, 55)))

    def test_started_position_is_never_retried(self) -> None:
        progress_path = self.root / "progress.json"
        progress = json.loads(progress_path.read_text())
        progress["status"] = "RUNNING"
        progress["samples"]["EJVD-001"] = "STARTED"
        progress_path.write_text(json.dumps(progress, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        fake = FakeExecutor()
        with self.assertRaisesRegex(RuntimeError, "started invocation cannot be retried"):
            RUNNER.execute(self.root, sample_executor=fake)
        self.assertEqual(fake.calls, [])

    def test_schedule_digest_drift_refuses_execution_before_invocation(self) -> None:
        schedule_path = self.root / "schedule.json"
        schedule_path.chmod(0o644)
        schedule = json.loads(schedule_path.read_text())
        schedule["entries"][0]["fixture_id"] = "DRIFT"
        schedule_path.write_text(json.dumps(schedule, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        fake = FakeExecutor()
        with self.assertRaisesRegex(RuntimeError, "execution seal drift"):
            RUNNER.execute(self.root, sample_executor=fake)
        self.assertEqual(fake.calls, [])

    def test_frozen_raw_artifact_detects_mutation(self) -> None:
        RUNNER.execute(self.root, sample_executor=FakeExecutor())
        raw = self.root / "observations" / "EJVD-001" / "raw-sentinel.json"
        raw.chmod(0o644)
        raw.write_text("mutated\n", encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "raw execution artifact drift"):
            RUNNER.verify_raw_execution_lock(self.root)


if __name__ == "__main__":
    unittest.main()
