from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE_SRC = Path("/home/nobcoder/codex-security-harness-v0.1.7/src")
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(CANDIDATE_SRC))

from bbp_harness.db import SCHEMA_SQL  # noqa: E402
import run_v017_acceptance_rc2 as acceptance  # noqa: E402
from v017_acceptance_common import (  # noqa: E402
    build_acceptance_scope,
    fixture_evidence,
    load_json,
    sha256_file,
    verify_candidate,
)
from v017_acceptance_common_r2 import harness_telemetry  # noqa: E402


NOW = "2026-10-08T00:00:00+00:00"
RC1_PROTOCOL = ROOT / "protocol/V0.1.7_DEVELOPMENT_ACCEPTANCE_RC1.json"
RC2_PROTOCOL = ROOT / "protocol/V0.1.7_DEVELOPMENT_ACCEPTANCE_RC2.json"
RC2_DRAFT = ROOT / "protocol/V0.1.7_DEVELOPMENT_ACCEPTANCE_RC2_DRAFT.json"
RC2_EXECUTION_ROOT = Path(
    "/home/nobcoder/pilot-runs/v0.1.7-acceptance/"
    "v0.1.7-rc2-development-acceptance-20261008"
)


def test_candidate_and_scorer_core_are_byte_identical() -> None:
    candidate = verify_candidate()
    protocol = load_json(RC2_PROTOCOL)
    assert candidate["status"] == "PASS", candidate["errors"]
    assert candidate["candidate_clean_tree_sha256"] == protocol["sealed_identity"]["source_tree_sha256"]
    assert sha256_file(ROOT / "scripts/score_v017_acceptance.py") == protocol["sealed_identity"]["scorer_core_sha256"]


def test_rc2_is_new_identity_with_zero_rc1_import() -> None:
    protocol = load_json(RC2_PROTOCOL)
    assert protocol["protocol_id"] == "v0.1.7-development-acceptance-rc2"
    assert protocol["identity"]["start_position"] == 1
    assert protocol["identity"]["rc1_imported_observations"] == 0
    assert protocol["identity"]["rc1_numerator_contribution"] == 0
    assert protocol["identity"]["rc1_denominator_contribution"] == 0
    assert protocol["execution"]["rc1_run_artifact_reuse"] == "FORBIDDEN"


def test_draft_identity_is_frozen_for_review() -> None:
    assert sha256_file(RC2_DRAFT) == "54a7e42e55de32f634780c478c5c3a1cd2f47d03a2590e37e93ab6b07ba938a4"
    assert load_json(RC2_DRAFT)["status"] == "DRAFT_FOR_REVIEW_LIVE_EXECUTION_NOT_AUTHORIZED"


def test_rc2_schedule_is_complete_deterministic_pair_interleaved_and_fresh() -> None:
    protocol = load_json(RC2_PROTOCOL)
    first = acceptance.make_schedule(protocol, protocol["sealed_identity"]["source_tree_sha256"])
    second = acceptance.make_schedule(protocol, protocol["sealed_identity"]["source_tree_sha256"])
    assert first == second
    assert [row["position"] for row in first] == list(range(1, 31))
    identities = [(row["trial"], row["case_id"], row["system"]) for row in first]
    assert len(set(identities)) == 30
    assert sum(row["system"] == "plain-minimal" for row in first) == 15
    assert sum(row["system"] == "harness-v0.1.7" for row in first) == 15
    assert all("source_acceptance_identity" not in row for row in first)
    assert all("source_observation" not in row for row in first)
    for index in range(0, 30, 2):
        assert first[index]["case_id"] == first[index + 1]["case_id"]
        assert first[index]["system"] != first[index + 1]["system"]


def test_acceptance_thresholds_and_intelligence_contracts_are_unchanged() -> None:
    rc1 = load_json(RC1_PROTOCOL)
    rc2 = load_json(RC2_PROTOCOL)
    assert rc2["repair_acceptance"] == rc1["repair_acceptance"]
    assert rc2["terminalization_acceptance"] == rc1["terminalization_acceptance"]
    assert rc2["harness_lifecycle"] == rc1["harness_lifecycle"]
    assert rc2["resource_acceptance"] == rc1["resource_acceptance"]
    for key in (
        "episodes",
        "systems",
        "trials_per_episode",
        "observations_per_system",
        "minimum_accepted_terminals_per_system",
        "minimum_trials_accepted_per_episode_per_system",
        "accepted_terminals",
        "maximum_invalid_infrastructure_per_system",
        "maximum_invalid_protocol_per_system",
        "maximum_true_token_overshoots_per_system",
        "maximum_wall_time_overruns_per_system",
    ):
        assert rc2["development_e2e"][key] == rc1["development_e2e"][key]


def test_rc2_seal_sources_bind_telemetry_v2_and_review_authorization() -> None:
    sources = acceptance.sealed_sources()
    assert sources["telemetry_schema_v2_sha256"].name == "v017_acceptance_telemetry_v2.py"
    assert sources["acceptance_common_r2_sha256"].name == "v017_acceptance_common_r2.py"
    assert sources["protocol_review_lock_sha256"] == acceptance.PROTOCOL_REVIEW_LOCK
    assert sources["execution_authorization_sha256"] == acceptance.EXECUTION_AUTHORIZATION
    assert "acceptance_common_sha256" not in sources


def test_execution_root_does_not_exist_before_protocol_review() -> None:
    if acceptance.PROTOCOL_REVIEW_LOCK.is_file():
        review = load_json(acceptance.PROTOCOL_REVIEW_LOCK)
        assert review["review_facts"]["execution_root_absent_before_review"] is True
    else:
        assert not RC2_EXECUTION_ROOT.exists()


def test_schema_bound_telemetry_handoff(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    database = run_dir / "harness-home/state/research.db"
    database.parent.mkdir(parents=True)
    with sqlite3.connect(database) as connection:
        connection.executescript(SCHEMA_SQL)
        connection.execute(
            "INSERT INTO targets(id,root_path,created_at,updated_at) VALUES(?,?,?,?)",
            (1, "/fixture", NOW, NOW),
        )
        connection.execute(
            "INSERT INTO campaigns(id,target_id,objective,status,scope_status,terminal_verdict,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?,?)",
            ("C1", 1, "offline rc2", "COMPLETE", "PROVEN", "NO_VALID_FINDING", NOW, NOW),
        )
        connection.execute(
            "INSERT INTO candidates(id,campaign_id,title,state,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            ("A", "C1", "candidate", "KILL", NOW, NOW),
        )
        connection.execute(
            "INSERT INTO candidate_transitions(candidate_id,from_state,to_state,reason,created_at) "
            "VALUES(?,?,?,?,?)",
            ("A", "DISCOVERED", "KILL", "negative", NOW),
        )
    evidence = fixture_evidence("V2-CASE-003")
    budget = load_json(acceptance.core.BUDGET)
    base = acceptance.core.resource.calibration_scope("V2-CASE-003", budget)
    scope = build_acceptance_scope("V2-CASE-003", budget, base)
    scope_path = run_dir / "runtime/workspace/.bbpresearch/scope.yaml"
    scope_path.parent.mkdir(parents=True)
    scope_path.write_text(json.dumps(scope), encoding="utf-8")
    evidence_path = run_dir / "runtime/workspace/.bbpresearch/fixture-security-evidence.json"
    evidence_path.write_bytes(evidence["path"].read_bytes())
    ledger_path = run_dir / "control/budget_ledger.json"
    ledger_path.parent.mkdir(parents=True)
    ledger_path.write_text(json.dumps({
        "valid_resource_compliance": True,
        "reservations": [],
        "usage": {},
        "limits": {"per_run": {}},
    }), encoding="utf-8")
    telemetry = harness_telemetry(run_dir, position=1, case_id="V2-CASE-003", trial=1)
    assert telemetry["status"] == "PASS"
    assert telemetry["telemetry_contract_id"] == "V0.1.7_ACCEPTANCE_TELEMETRY_SCHEMA_CONTRACT_V2"
    assert telemetry["schema"]["status"] == "PASS"
    assert telemetry["candidates"] == {"count": 1, "transitions": 1}
