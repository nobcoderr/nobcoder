from __future__ import annotations

import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import jsonschema

from scripts.v017_fixture_contract import (
    ALLOWED_ACCEPTED_TERMINALS,
    ROOT,
    bind_episode_evidence,
    load_and_validate,
    validate_evidence,
)


MANIFEST = ROOT / "fixtures" / "v0.1.7-measurement-contract-regression" / "manifest.json"
PROTOCOL = ROOT / "protocol" / "V0.1.6_ACCEPTANCE_PROTOCOL.json"
SCHEMA = ROOT / "protocol" / "V0.1.7_ACCEPTANCE_FIXTURE_SECURITY_CONTRACT.schema.json"


class V017FixtureContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.evidence_root = self.root / "evidence"
        self.evidence_root.mkdir()
        self.valid = {
            "fixture_id": "FIXTURE-001",
            "prior_art_snapshot": {
                "status": "COMPLETE",
                "conclusion": "CLEAR_FOR_SYNTHETIC_FIXTURE",
                "network_required": False,
                "sources": ["sealed-source"],
            },
            "release_provenance": {
                "mapping": "FIXTURE_RELEASE_REACHABLE",
                "artifact": "fixture-release",
                "consumer": "protected consumer",
                "evidence": ["target/application_context.md"],
            },
        }

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def _write(self, document: dict) -> tuple[Path, str]:
        path = self.evidence_root / "evidence.json"
        path.write_text(json.dumps(document, sort_keys=True), encoding="utf-8")
        return path, hashlib.sha256(path.read_bytes()).hexdigest()

    def test_thirteen_rc1_measurement_contract_regressions_pass(self) -> None:
        document = json.loads(MANIFEST.read_text(encoding="utf-8"))
        schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
        jsonschema.validate(document, schema)
        result = load_and_validate(MANIFEST)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["entries"], 13)
        self.assertEqual(result["valid_entries"], 13)

    def test_missing_evidence_fails_closed(self) -> None:
        errors = validate_evidence(
            self.evidence_root / "missing.json",
            "0" * 64,
            "FIXTURE-001",
            evidence_root=self.evidence_root,
        )
        self.assertIn("missing evidence", errors)

    def test_digest_mutation_fails_closed(self) -> None:
        path, digest = self._write(self.valid)
        path.write_text(json.dumps({**self.valid, "mutated": True}), encoding="utf-8")
        errors = validate_evidence(
            path, digest, "FIXTURE-001", evidence_root=self.evidence_root
        )
        self.assertIn("evidence digest mismatch", errors)

    def test_missing_prior_art_conclusion_fails_closed(self) -> None:
        document = copy.deepcopy(self.valid)
        document["prior_art_snapshot"].pop("conclusion")
        path, digest = self._write(document)
        errors = validate_evidence(
            path, digest, "FIXTURE-001", evidence_root=self.evidence_root
        )
        self.assertIn("prior-art conclusion missing", errors)

    def test_missing_release_mapping_fails_closed(self) -> None:
        document = copy.deepcopy(self.valid)
        document["release_provenance"].pop("mapping")
        path, digest = self._write(document)
        errors = validate_evidence(
            path, digest, "FIXTURE-001", evidence_root=self.evidence_root
        )
        self.assertIn("release mapping is not sufficient", errors)

    def test_network_only_prior_art_fails_closed(self) -> None:
        document = copy.deepcopy(self.valid)
        document["prior_art_snapshot"]["network_required"] = True
        path, digest = self._write(document)
        errors = validate_evidence(
            path, digest, "FIXTURE-001", evidence_root=self.evidence_root
        )
        self.assertIn("prior-art evidence is not offline", errors)

    def test_scorer_semantics_are_unchanged(self) -> None:
        protocol = json.loads(PROTOCOL.read_text(encoding="utf-8"))
        accepted = set(protocol["development_e2e"]["accepted_terminals"])
        self.assertEqual(accepted, ALLOWED_ACCEPTED_TERMINALS)
        self.assertEqual(accepted, {"REPORT_READY", "NO_VALID_FINDING"})

    def test_verified_evidence_is_bound_into_worker_visible_scope(self) -> None:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        workspace = self.root / "workspace"
        workspace.mkdir()
        original_scope = {"allowed_actions": {"network": False, "public_web_research": False}}
        scope = bind_episode_evidence(
            manifest,
            position=1,
            episode="V2-CASE-003",
            trial=1,
            workspace=workspace,
            scope=original_scope,
        )
        declaration = scope["fixture_security_evidence"]
        materialized = workspace / declaration["path"]
        self.assertTrue(materialized.is_file())
        self.assertEqual(hashlib.sha256(materialized.read_bytes()).hexdigest(), declaration["sha256"])
        self.assertFalse(declaration["network_required"])
        self.assertFalse(scope["allowed_actions"]["network"])
        self.assertNotIn("fixture_security_evidence", original_scope)

    def test_unknown_episode_binding_fails_closed(self) -> None:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        workspace = self.root / "workspace"
        workspace.mkdir()
        with self.assertRaisesRegex(ValueError, "exactly once"):
            bind_episode_evidence(
                manifest,
                position=99,
                episode="UNKNOWN",
                trial=1,
                workspace=workspace,
                scope={},
            )


if __name__ == "__main__":
    unittest.main()
