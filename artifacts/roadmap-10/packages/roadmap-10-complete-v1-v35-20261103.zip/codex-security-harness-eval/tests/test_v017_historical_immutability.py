from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path


HOME = Path("/home/nobcoder")
RC1 = HOME / "pilot-runs/v0.1.6-acceptance/v0.1.6-rc1-development-acceptance-r2-20261008"
POSTMORTEM = HOME / "pilot-runs/v0.1.6-postmortem/v0.1.6-rc1-immutable-postmortem-20261008"
CONTRACTS = HOME / "codex-security-harness-eval/protocol"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest(root: Path, lock_name: str) -> None:
    lock = json.loads((root / lock_name).read_text(encoding="utf-8"))
    for relative, expected in lock["artifacts"].items():
        assert sha256(root / relative) == expected, relative


class V017HistoricalImmutabilityTests(unittest.TestCase):
    def test_v016_rc1_lock_and_artifacts_are_unchanged(self) -> None:
        self.assertEqual(
            sha256(RC1 / "ACCEPTANCE_LOCK.json"),
            "205f4043f4e04b1257125cdd8de5648ca570ed3bcb198a9b525ceb8c8f334a77",
        )
        verify_manifest(RC1, "ACCEPTANCE_LOCK.json")
        lock = json.loads((RC1 / "ACCEPTANCE_LOCK.json").read_text(encoding="utf-8"))
        self.assertEqual(lock["status"], "ACCEPTANCE_FAIL_LOCKED_NOT_RELEASED")
        self.assertTrue(lock["no_rescore"])
        self.assertTrue(lock["no_retry"])
        self.assertTrue(lock["no_replacement"])

    def test_v016_postmortem_lock_and_artifacts_are_unchanged(self) -> None:
        self.assertEqual(
            sha256(POSTMORTEM / "POSTMORTEM_LOCK.json"),
            "2f41406dee735084e39e8752394a5a8a85940b3e20174df9ffc80b63975cbced",
        )
        verify_manifest(POSTMORTEM, "POSTMORTEM_LOCK.json")
        lock = json.loads((POSTMORTEM / "POSTMORTEM_LOCK.json").read_text(encoding="utf-8"))
        self.assertEqual(lock["status"], "PASS_LOCKED")

    def test_preimplementation_contract_lock_is_intact(self) -> None:
        lock = json.loads(
            (CONTRACTS / "V0.1.7_CONTRACT_LOCK.json").read_text(encoding="utf-8")
        )
        for relative, expected in lock["artifacts"].items():
            self.assertEqual(sha256(CONTRACTS / relative), expected, relative)
        self.assertEqual(lock["status"], "PASS_LOCKED_BEFORE_IMPLEMENTATION")


if __name__ == "__main__":
    unittest.main()
