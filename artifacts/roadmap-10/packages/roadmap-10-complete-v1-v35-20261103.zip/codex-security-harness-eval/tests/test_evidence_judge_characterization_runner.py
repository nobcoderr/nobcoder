from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_module(name: str, relative: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


RUNNER = load_module("run_evidence_judge_characterization", "scripts/run_evidence_judge_characterization.py")
DERIVER = load_module("derive_evidence_judge_capacity_model", "scripts/derive_evidence_judge_capacity_model.py")


class EvidenceJudgeCharacterizationRunnerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.limits = {
            "max_total_input_tokens": 100,
            "max_noncached_input_tokens": 50,
            "max_output_tokens": 20,
            "max_reasoning_tokens": 10,
        }
        self.usage = {
            "total_input_tokens": 90,
            "cached_input_tokens": 50,
            "noncached_input_tokens": 40,
            "output_tokens": 15,
            "reasoning_tokens": 8,
        }

    def test_classification_completed(self) -> None:
        self.assertEqual(
            RUNNER.classify_sample(exit_code=0, timed_out=False, usage=self.usage, limits=self.limits, output_valid=True),
            ("VALID_COMPLETED", "NORMAL_COMPLETION"),
        )

    def test_overshoot_precedes_timeout(self) -> None:
        usage = dict(self.usage, reasoning_tokens=11)
        status, reason = RUNNER.classify_sample(exit_code=124, timed_out=True, usage=usage, limits=self.limits, output_valid=False)
        self.assertEqual(status, "INVALID_OVERSHOOT")
        self.assertIn("reasoning_tokens", reason)

    def test_timeout_remains_observed_timeout(self) -> None:
        self.assertEqual(
            RUNNER.classify_sample(exit_code=124, timed_out=True, usage=self.usage, limits=self.limits, output_valid=False),
            ("VALID_TIMEOUT", "TIMEOUT"),
        )

    def test_schema_or_runtime_failure_fails_closed(self) -> None:
        self.assertEqual(
            RUNNER.classify_sample(exit_code=0, timed_out=False, usage=self.usage, limits=self.limits, output_valid=False)[0],
            "INVALID_INFRASTRUCTURE",
        )

    def test_prompt_rebuild_matches_sealed_manifest(self) -> None:
        manifest = json.loads(RUNNER.WORKLOAD_MANIFEST.read_text())
        row = manifest["workloads"][0]
        workload = json.loads((ROOT / row["path"]).read_text())
        prompt = RUNNER.build_prompt(workload)
        self.assertEqual(len(prompt.encode()), row["measurements"]["prompt_bytes"])


class EvidenceJudgeEstimatorTests(unittest.TestCase):
    @staticmethod
    def sample(tier: str, variant: int, scale: int) -> dict:
        return {
            "sample_id": f"{tier}-{variant}",
            "tier": tier,
            "variant": variant,
            "actual": {
                "total_input_tokens": 100 * scale,
                "noncached_input_tokens": 20 * scale,
                "output_tokens": 10 * scale,
                "reasoning_tokens": 5 * scale,
            },
            "wall_time_seconds": 3 * scale,
        }

    def test_estimator_is_quantized_and_monotonic(self) -> None:
        protocol = json.loads(DERIVER.PROTOCOL.read_text())
        samples = []
        for tier, scale in (("SMALL", 1), ("MEDIUM", 2), ("LARGE", 3)):
            samples.extend(self.sample(tier, variant, scale) for variant in range(1, 5))
        reservations = DERIVER.derive_reservations(samples, protocol)
        for dimension in DERIVER.DIMENSIONS:
            self.assertLessEqual(reservations["SMALL"][dimension], reservations["MEDIUM"][dimension])
            self.assertLessEqual(reservations["MEDIUM"][dimension], reservations["LARGE"][dimension])
        self.assertEqual(DERIVER.prediction_failures(samples, reservations), [])

    def test_held_tail_is_detected(self) -> None:
        protocol = json.loads(DERIVER.PROTOCOL.read_text())
        training = [self.sample(tier, variant, 1) for tier in DERIVER.TIERS for variant in range(1, 4)]
        held = [self.sample(tier, 4, 20) for tier in DERIVER.TIERS]
        reservations = DERIVER.derive_reservations(training, protocol)
        self.assertTrue(DERIVER.prediction_failures(held, reservations))


if __name__ == "__main__":
    unittest.main()
