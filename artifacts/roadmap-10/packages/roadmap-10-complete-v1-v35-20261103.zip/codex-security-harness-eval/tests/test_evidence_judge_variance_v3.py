from __future__ import annotations

import copy
import json
from collections import Counter
from pathlib import Path

import jsonschema

from analyze_evidence_judge_variance_decomposition_v3 import manipulation_checks
from execution_environment import sha256_file


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = ROOT / "protocol" / "EVIDENCE_JUDGE_VARIANCE_DECOMPOSITION_V3.json"
SCHEDULE = ROOT / "calibration" / "evidence-judge-variance-decomposition-v3" / "SCHEDULE.json"
MANIFEST = ROOT / "calibration" / "evidence-judge-variance-decomposition-v3" / "WORKLOAD_MANIFEST.json"
OBSERVATION_SCHEMA = ROOT / "schemas" / "evidence-judge-variance-observation-v3.schema.json"
BASE_SCHEMA = ROOT / "schemas" / "evidence-judge-variance-observation-v3-base.schema.json"
RESULT_SCHEMA = ROOT / "schemas" / "evidence-judge-variance-analysis-result-v3.schema.json"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def synthetic_data():
    schedule = load(SCHEDULE)["entries"]
    manifest = load(MANIFEST)
    workloads = {row["fixture_id"]: row for row in manifest["workloads"]}
    size_inputs = {"EJVD-SIZE-S": 100, "EJVD-SIZE-M": 200, "EJVD-SIZE-L": 300}
    rows = []
    for entry in schedule:
        fixture = entry["fixture_id"]
        row = {
            **entry,
            "schedule_position": entry["position"],
            "fixture_digest": workloads[fixture]["sha256"],
            "scientific_request_digest": f"scientific-{fixture}",
            "semantic_message_digest": f"semantic-{fixture}",
            "model_config_digest": "model-config",
            "evidence_judge_config_digest": "evidence-judge-config",
            "runtime_digest": "runtime",
            "product_digest": "product",
            "capture_digest": "capture",
            "classifier_digest": "classifier",
            "equivalence_contract_digest": "equivalence",
            "resource_accounting_contract_digest": "accounting",
            "capture_runtime_readiness_digest": "capture-readiness",
            "provider_stability_readiness_digest": "provider-readiness",
            "raw_lock_gate_digest": "raw-lock-gate",
            "runtime_full_digest": f"volatile-{entry['position']}",
            "cache_accounting_sum_invariant": True,
            "total_input_tokens": size_inputs.get(fixture, 200),
        }
        rows.append(row)
    return {"workloads": workloads, "observations": rows}


def test_protocol_and_schedule_are_exactly_precommitted():
    protocol = load(PROTOCOL)
    entries = load(SCHEDULE)["entries"]
    assert protocol["design"]["total_scheduled_invocations"] == 54
    assert protocol["analysis_precommit"]["permutations"] == 100000
    assert protocol["analysis_precommit"]["bootstrap_resamples"] == 20000
    assert protocol["runtime"]["concurrency"] == 1
    assert protocol["runtime"]["retry_count"] == 0
    assert protocol["runtime"]["replacement_count"] == 0
    assert [row["position"] for row in entries] == list(range(1, 55))
    assert len({row["sample_id"] for row in entries}) == 54
    counts = Counter(row["family"] for row in entries)
    assert counts == {"SEMANTIC_FIXED_SIZE": 24, "SIZE_FIXED_SEMANTICS": 18, "EXACT_REPEAT": 12}
    fixture_counts = Counter(row["fixture_id"] for row in entries)
    assert {fixture_counts[key] for key in ("EJVD-SEM-A", "EJVD-SEM-B", "EJVD-SEM-C")} == {8}
    assert {fixture_counts[key] for key in ("EJVD-SIZE-S", "EJVD-SIZE-M", "EJVD-SIZE-L")} == {6}
    assert fixture_counts["EJVD-REPEAT-D"] == 12


def test_manifest_is_bound_to_schedule_and_frozen_fixture_bytes():
    manifest = load(MANIFEST)
    assert manifest["schedule_sha256"] == sha256_file(SCHEDULE)
    for workload in manifest["workloads"]:
        assert sha256_file(ROOT / workload["path"]) == workload["sha256"]


def test_all_v3_schemas_are_valid_json_schema():
    for path in (OBSERVATION_SCHEMA, BASE_SCHEMA, RESULT_SCHEMA):
        jsonschema.Draft202012Validator.check_schema(load(path))


def test_scientific_equivalence_passes_while_runtime_identity_is_volatile():
    result = manipulation_checks(synthetic_data())
    assert result["all_pass"] is True
    repeat = result["checks"]["family_3_exact_repeat_scientific_identity"]
    assert repeat["pass"] is True
    assert "runtime_full_digest" not in repeat["unique_counts"]


def test_scientific_request_drift_fails_closed():
    data = synthetic_data()
    repeated = [row for row in data["observations"] if row["fixture_id"] == "EJVD-REPEAT-D"]
    repeated[3]["scientific_request_digest"] = "drift"
    result = manipulation_checks(data)
    assert result["all_pass"] is False
    assert result["checks"]["family_3_exact_repeat_scientific_identity"]["pass"] is False


def test_cache_partition_is_telemetry_not_request_identity():
    data = synthetic_data()
    for index, row in enumerate(data["observations"]):
        row["cached_input_tokens"] = 100 if index % 2 else 0
        row["noncached_input_tokens"] = 100 if index % 2 else 200
    result = manipulation_checks(data)
    assert result["checks"]["family_3_exact_repeat_scientific_identity"]["pass"] is True


def test_model_or_evidence_judge_configuration_drift_fails_closed():
    for field in ("model_config_digest", "evidence_judge_config_digest"):
        data = synthetic_data()
        repeated = [row for row in data["observations"] if row["fixture_id"] == "EJVD-REPEAT-D"]
        repeated[-1][field] = "drift"
        assert manipulation_checks(data)["all_pass"] is False


def test_protocol_explicitly_excludes_transport_and_cache_identity():
    excluded = set(load(PROTOCOL)["request_equivalence"]["explicitly_not_equivalence_gates"])
    assert {"raw_request_digest", "runtime_full_digest", "cached_input_tokens", "noncached_input_tokens", "cache_state"} <= excluded


def test_mutating_a_copy_does_not_change_frozen_sources():
    data = synthetic_data()
    clone = copy.deepcopy(data)
    clone["observations"][0]["runtime_full_digest"] = "changed-runtime-metadata"
    assert manipulation_checks(clone)["all_pass"] is True
    assert manipulation_checks(data)["all_pass"] is True
