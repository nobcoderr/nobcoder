from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_v012_candidate", ROOT / "scripts" / "verify_v012_candidate.py"
)
VERIFY = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(VERIFY)


class V012CandidateSealTests(unittest.TestCase):
    def test_candidate_changes_stay_inside_frozen_boundary(self) -> None:
        result = VERIFY.verify(ROOT.parent / "codex-security-harness-v0.1.2")
        self.assertEqual(result["status"], "PASS", result["errors"])
        self.assertEqual(result["checks"]["frozen_intelligence"]["status"], "PASS")
        self.assertFalse(result["release_authorized"])
        self.assertFalse(result["fresh_holdout_authorized"])


if __name__ == "__main__":
    unittest.main()
