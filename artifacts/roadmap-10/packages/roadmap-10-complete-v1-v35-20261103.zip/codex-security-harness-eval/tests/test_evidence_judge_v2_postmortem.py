from __future__ import annotations

import importlib.util
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True


def load_module():
    path = ROOT / "scripts" / "postmortem_evidence_judge_v2.py"
    spec = importlib.util.spec_from_file_location("postmortem_ej_v2", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


POSTMORTEM = load_module()


class EvidenceJudgeV2PostmortemTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.v1 = POSTMORTEM.samples(POSTMORTEM.V1_ROOT)
        cls.v2 = POSTMORTEM.samples(POSTMORTEM.V2_ROOT)
        cls.model = json.loads(POSTMORTEM.V2_MODEL.read_text())
        cls.manifest = json.loads(POSTMORTEM.V2_MANIFEST.read_text())
        policy = json.loads(POSTMORTEM.CANDIDATE_A.read_text())
        cls.rows = POSTMORTEM.decomposition(
            cls.v2,
            cls.model,
            cls.manifest,
            policy["workflow_governance"]["run_limits"],
        )

    def test_source_and_pair_guards_pass(self) -> None:
        self.assertEqual(len(POSTMORTEM.source_guard()), 8)
        POSTMORTEM.verify_sample_contract(self.v1, self.v2)

    def test_only_small_02_overshoots_context_affine_prediction(self) -> None:
        overshoots = [row for row in self.rows if row["error_class"] == "OVERSHOOT"]
        self.assertEqual([row["workload_id"] for row in overshoots], ["EJ-SMALL-02"])
        row = overshoots[0]
        self.assertEqual(row["output_error_tokens"], 232)
        self.assertEqual(row["reasoning_error_tokens"], 116)
        self.assertAlmostEqual(row["output_relative_error"], 0.232)
        self.assertAlmostEqual(row["reasoning_relative_error"], 116 / 750)
        self.assertAlmostEqual(row["output_positive_error_share_of_run_budget"], 232 / 70000)
        self.assertAlmostEqual(row["reasoning_positive_error_share_of_run_budget"], 116 / 40000)

    def test_constant_predictor_is_reported_as_non_correlatable(self) -> None:
        result = POSTMORTEM.correlations(self.rows)
        self.assertEqual(result["experiment_count"]["unique_values"], 1)
        self.assertIsNone(result["experiment_count"]["output_residual"]["pearson_r"])
        self.assertIsNone(result["experiment_count"]["reasoning_residual"]["spearman_rho"])

    def test_tied_ranks_use_average_rank(self) -> None:
        self.assertEqual(POSTMORTEM.ranks([10, 20, 20, 30]), [1.0, 2.5, 2.5, 4.0])


if __name__ == "__main__":
    unittest.main()
