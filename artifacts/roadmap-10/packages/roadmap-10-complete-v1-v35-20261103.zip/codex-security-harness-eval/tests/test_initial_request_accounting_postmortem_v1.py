from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postmortem_initial_request_accounting_v1 as postmortem  # noqa: E402


class InitialRequestAccountingPostmortemV1Tests(unittest.TestCase):
    def test_direct_transport_evidence_establishes_capture_mismatch(self) -> None:
        result = postmortem.build_result()
        self.assertEqual("CAPTURE_TRANSPORT_MISMATCH_WEBSOCKET", result["root_cause"])
        self.assertTrue(result["evidence"]["websocket_upgrade_observed_12_of_12"])
        self.assertTrue(result["evidence"]["http_inference_capture_artifacts_absent_12_of_12"])

    def test_postmortem_does_not_analyze_or_authorize_follow_on(self) -> None:
        result = postmortem.build_result()
        self.assertFalse(result["execution"]["analysis_authorized"])
        self.assertEqual("MEASUREMENT_INCOMPLETE_IMMUTABLE_NEVER_ANALYZE", result["disposition"]["irac_v1"])
        self.assertEqual("UNRESOLVED", result["disposition"]["pre_invocation_context_drift_vs_measurement_accounting"])
        self.assertTrue(all(value is False for value in result["authorizations"].values()))
        self.assertEqual(0, result["model_invocations_added_by_postmortem"])


if __name__ == "__main__":
    unittest.main()
