from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postmortem_irac_v2_official_r2_operational as postmortem  # noqa: E402


class R2OperationalPostmortemTests(unittest.TestCase):
    def test_locked_postmortem_verifies(self) -> None:
        self.assertEqual("PASS", postmortem.verify()["status"])

    def test_no_scientific_analysis_or_mutation(self) -> None:
        result = json.loads((postmortem.OUTPUT / "POSTMORTEM.json").read_text())
        self.assertFalse(result["analysis_authorized"])
        self.assertFalse(result["scientific_fields_inspected"])
        self.assertFalse(result["historical_artifacts_reclassified"])
        self.assertEqual(0, result["model_invocations_added"])

    def test_expected_operational_classifications(self) -> None:
        result = json.loads((postmortem.OUTPUT / "POSTMORTEM.json").read_text())
        self.assertEqual(3, result["classification_counts"]["PROVIDER_CAPACITY_REJECTION"])
        self.assertEqual(1, result["classification_counts"]["PROVIDER_TRANSIENT_REJECTION"])
        self.assertNotIn("CAPTURE_FAILURE", result["classification_counts"])


if __name__ == "__main__":
    unittest.main()
