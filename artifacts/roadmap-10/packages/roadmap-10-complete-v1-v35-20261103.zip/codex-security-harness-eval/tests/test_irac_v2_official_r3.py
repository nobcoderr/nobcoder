from __future__ import annotations

import json
import sys
import unittest
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_message_classifier import canonical_digest  # noqa: E402
import run_irac_v2_official_r3 as runner  # noqa: E402


class OfficialR3Tests(unittest.TestCase):
    def test_scientific_decision_tree_is_unchanged(self) -> None:
        r3 = json.loads(runner.PROTOCOL.read_text())
        r2 = json.loads((ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_OFFICIAL_R2.json").read_text())
        self.assertEqual(canonical_digest(r2["decision_tree"]), canonical_digest(r3["decision_tree"]))
        self.assertEqual(r2["measurement_envelope"], r3["measurement_envelope"])

    def test_schedule_is_fresh_balanced_and_exactly_once(self) -> None:
        schedule = json.loads(runner.SCHEDULE.read_text())
        entries = schedule["entries"]
        self.assertEqual(list(range(1, 13)), [entry["position"] for entry in entries])
        self.assertEqual(12, len({entry["sample_id"] for entry in entries}))
        self.assertEqual(Counter({"EMPTY_START": 4, "MODEL_CACHE_ONLY": 4, "MODEL_PLUS_APPS_CACHE": 4}), Counter(entry["condition"] for entry in entries))
        self.assertTrue(all(entry["sample_id"].startswith("IRAC2R3-") for entry in entries))

    def test_fresh_preflight_contract(self) -> None:
        protocol = json.loads(runner.PROTOCOL.read_text())
        preflight = protocol["per_position_availability_attestation"]
        self.assertTrue(preflight["required"])
        self.assertEqual(30, preflight["maximum_seconds_before_scientific_dispatch"])
        self.assertEqual("SCIENTIFIC_INVOCATION_DENIED_POSITION_INVALID", preflight["stale_or_rejected_action"])
        self.assertFalse(preflight["preflight_guarantees_scientific_acceptance"])


if __name__ == "__main__":
    unittest.main()
