from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import run_v015_acceptance as acceptance  # noqa: E402
from run_v015_preacceptance_checks import locked_evidence  # noqa: E402
from score_v015_acceptance import closure_observability  # noqa: E402


class V015AcceptanceTests(unittest.TestCase):
    def test_schedule_is_balanced_interleaved_and_deterministic(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        first = acceptance.schedule(protocol, "d" * 64)
        second = acceptance.schedule(protocol, "d" * 64)
        self.assertEqual(first, second)
        self.assertEqual([row["position"] for row in first], list(range(1, 31)))
        self.assertEqual(sum(row["system"] == "plain-minimal" for row in first), 15)
        self.assertEqual(sum(row["system"] == "harness-v0.1.5" for row in first), 15)
        for index in range(0, 30, 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_frozen_gates_and_no_rescue_are_unchanged(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        gate = protocol["development_e2e"]
        self.assertEqual(gate["minimum_accepted_terminals_per_system"], 12)
        self.assertEqual(gate["maximum_true_token_overshoots_per_system"], 0)
        self.assertEqual(gate["maximum_wall_time_overruns_per_system"], 0)
        self.assertEqual(protocol["resource_acceptance"]["maximum_requested_to_actual_ratio"], 3.0)
        self.assertEqual(protocol["resource_acceptance"]["maximum_unused_reservation_fraction"], 0.6667)
        self.assertEqual(protocol["post_acceptance_rescue"], "FORBIDDEN_FOR_THIS_IDENTITY")

    def test_preacceptance_locked_evidence_is_current(self) -> None:
        rows = locked_evidence()
        self.assertTrue(rows)
        self.assertTrue(all(row["status"] == "PASS" for row in rows), rows)

    def test_missing_database_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            result = closure_observability(Path(temporary))
        self.assertEqual(result["queue_deadlocks"], 1)
        self.assertEqual(result["terminal_state_defects"], 1)
        self.assertEqual(result["hard_stop_handoff_failures"], 1)


if __name__ == "__main__":
    unittest.main()
