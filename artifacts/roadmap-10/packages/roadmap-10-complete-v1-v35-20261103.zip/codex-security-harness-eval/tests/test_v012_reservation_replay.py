from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "replay_v012_reservations", ROOT / "scripts" / "replay_v012_reservations.py"
)
REPLAY = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(REPLAY)


class V012ReservationReplayTests(unittest.TestCase):
    def test_frozen_static_estimator_passes_each_held_phase(self) -> None:
        result = REPLAY.replay()
        self.assertEqual(result["status"], "PASS", result)
        self.assertEqual(result["dataset"]["rows"], 157)
        self.assertEqual(result["dataset"]["excluded_plain_rows"], 15)
        self.assertEqual(len(result["folds"]), 3)
        self.assertTrue(all(item["status"] == "PASS" for item in result["folds"]))
        self.assertTrue(
            all(
                item["overall"]["predicted_overshoot_count"] == 0
                for item in result["folds"]
            )
        )


if __name__ == "__main__":
    unittest.main()
