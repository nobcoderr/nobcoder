from __future__ import annotations

import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


runner = load_module(
    "capacity_validation_runner",
    ROOT / "scripts" / "run_evidence_judge_capacity_envelope_v1.py",
)


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_manifest_has_24_fresh_in_domain_workloads() -> None:
    manifest = load(ROOT / "calibration" / "evidence-judge-capacity-envelope-v1-validation" / "WORKLOAD_MANIFEST.json")
    assert len(manifest["workloads"]) == 24
    assert manifest["counts"]["per_tier"] == {"SMALL": 8, "MEDIUM": 8, "LARGE": 8}
    ids = {row["fixture_id"] for row in manifest["workloads"]}
    digests = {row["sha256"] for row in manifest["workloads"]}
    assert len(ids) == 24
    assert len(digests) == 24
    for row in manifest["workloads"]:
        tokens = row["measurements"]["prompt_lexical_tokens"]
        if row["tier"] == "SMALL":
            assert 0 <= tokens <= 5_000
        elif row["tier"] == "MEDIUM":
            assert 5_001 <= tokens <= 10_000
        else:
            assert 10_001 <= tokens <= 15_000


def test_schedule_is_exact_once_and_interleaved() -> None:
    schedule = load(ROOT / "calibration" / "evidence-judge-capacity-envelope-v1-validation" / "SCHEDULE.json")
    assert [row["position"] for row in schedule["entries"]] == list(range(1, 25))
    assert len({row["sample_id"] for row in schedule["entries"]}) == 24
    assert len({row["fixture_id"] for row in schedule["entries"]}) == 24
    assert schedule["retry_count"] == 0
    assert schedule["replacement_count"] == 0


def test_acceptance_pass_and_fail_are_mechanical(tmp_path: Path) -> None:
    policy = load(ROOT / "calibration" / "evidence-judge-capacity-envelope-v1" / "EJ_CAPACITY_ENVELOPE_V1_POLICY.json")
    statuses = []
    telemetry = tmp_path / "variance-observations"
    telemetry.mkdir()
    for position, tier in enumerate((["SMALL", "MEDIUM", "LARGE"] * 8), 1):
        sample_id = f"EJCENV1-{position:03d}"
        reservation = policy["tiers"][tier]["reservation"]
        row = {
            "reservation": reservation,
            "total_input_tokens": reservation["total_input_tokens"] // 2,
            "noncached_input_tokens": reservation["noncached_input_tokens"] // 2,
            "output_tokens": reservation["output_tokens"] // 2,
            "reasoning_tokens": reservation["reasoning_tokens"] // 2,
            "overshoot_dimensions": [],
        }
        (telemetry / f"{sample_id}.json").write_text(json.dumps(row), encoding="utf-8")
        statuses.append({"sample_id": sample_id, "position_valid": True, "scientific_provider_outcome": "ACCEPTED"})
    result = runner.calculate_acceptance(tmp_path, statuses)
    assert result["status"] == "PASS"
    statuses[0]["position_valid"] = False
    result = runner.calculate_acceptance(tmp_path, statuses)
    assert result["status"] == "FAIL_LOCKED"
    assert "VALID_COMPLETED_NOT_24_OF_24" in result["gate_failures"]


def test_policy_uses_worst_case_cache_accounting() -> None:
    policy = load(ROOT / "calibration" / "evidence-judge-capacity-envelope-v1" / "EJ_CAPACITY_ENVELOPE_V1_POLICY.json")
    for tier in ("SMALL", "MEDIUM", "LARGE"):
        reservation = policy["tiers"][tier]["reservation"]
        assert reservation["noncached_input_tokens"] == reservation["total_input_tokens"]
