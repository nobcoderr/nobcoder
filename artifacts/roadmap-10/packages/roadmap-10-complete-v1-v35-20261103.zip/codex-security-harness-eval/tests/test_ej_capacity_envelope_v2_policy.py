from __future__ import annotations

import json
import math
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import derive_ej_capacity_envelope_v2 as v2  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sample(tier: str, total: int, output: int, reasoning: int, index: int):
    return {
        "source_experiment": "synthetic-contract-test",
        "source_invocation_id": f"T-{index:03d}",
        "tier": tier,
        "total_input": total,
        "noncached_input": total,
        "output": output,
        "reasoning": reasoning,
    }


def test_tolerance_rank_is_distribution_free_and_deterministic():
    rank = v2.tolerance_rank(156, 0.975, 0.95)
    assert rank == 156
    achieved = v2.binomial_cdf(rank - 1, 156, 0.975)
    assert achieved >= 0.95
    assert math.isclose(achieved, 1.0 - 0.975**156, rel_tol=1e-10)


def test_protocol_freezes_cause_agnostic_tail_rule_and_v1_input_inheritance():
    protocol = load(v2.PROTOCOL)
    rule = protocol["derivation_rule"]
    assert rule["point_estimation"] == "FORBIDDEN"
    assert rule["cache_prediction"] == "FORBIDDEN"
    assert rule["safety_factor"] == 1.25
    assert rule["rounding"] == {"output_tokens": 250, "reasoning_tokens": 250}
    assert rule["tail_pooling"].startswith("pool all eligible development tiers")
    assert protocol["offline_replay_gate"]["overshoot_events_by_dimension"] == {
        "total_input_tokens": 0,
        "noncached_input_tokens": 0,
        "output_tokens": 0,
        "reasoning_tokens": 0,
    }


def test_derivation_uses_pooled_tail_and_preserves_v1_input_policy(monkeypatch):
    values = []
    tiers = ("SMALL", "MEDIUM", "LARGE")
    for index in range(156):
        values.append(sample(tiers[index % 3], 1000, 100 + index, 200 + index, index))
    monkeypatch.setattr(v2, "PRECOMMIT_LOCK", v2.PROTOCOL)
    policy = v2.derive(values)
    old = load(v2.V1_POLICY)
    assert policy["pooled_tail_bound"]["output_tokens"]["order_statistic_rank"] == 156
    assert policy["tiers"]["SMALL"]["reservation"]["output_tokens"] == 1750
    assert policy["tiers"]["MEDIUM"]["reservation"]["reasoning_tokens"] == 1500
    for tier in tiers:
        assert policy["tiers"][tier]["reservation"]["total_input_tokens"] == old["tiers"][tier]["reservation"]["total_input_tokens"]
        assert policy["tiers"][tier]["reservation"]["noncached_input_tokens"] == old["tiers"][tier]["reservation"]["total_input_tokens"]


def test_replay_fails_on_any_dimension_overshoot():
    values = [sample("SMALL", 29001, 1, 1, 1)]
    policy = {
        "tiers": {
            "SMALL": {"reservation": {"total_input_tokens": 29000, "noncached_input_tokens": 29000, "output_tokens": 1750, "reasoning_tokens": 1250}}
        }
    }
    result = v2.replay(values, policy)
    assert result["status"] == "DESIGN_FAIL"
    assert result["overshoot_counts_by_dimension"]["total_input_tokens"] == 1


def test_live_validation_size_and_no_r2_reuse_are_precommitted():
    protocol = load(v2.PROTOCOL)
    live = protocol["fresh_live_validation"]
    assert live["workloads"] == 30
    assert live["tiers"] == {"SMALL": 10, "MEDIUM": 10, "LARGE": 10}
    assert live["r2_workload_reuse"] == "FORBIDDEN"
    assert live["retry_count"] == 0
    assert live["replacement_count"] == 0
