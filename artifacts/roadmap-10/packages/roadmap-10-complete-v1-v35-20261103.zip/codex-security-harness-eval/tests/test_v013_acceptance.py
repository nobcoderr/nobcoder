from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import run_v013_acceptance as acceptance  # noqa: E402
from score_v013_acceptance import closure_observability  # noqa: E402


class V013AcceptanceTests(unittest.TestCase):
    def test_schedule_is_balanced_interleaved_and_exactly_once(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        first = acceptance.schedule(protocol, "a" * 64)
        second = acceptance.schedule(protocol, "a" * 64)
        self.assertEqual(first, second)
        self.assertEqual(len(first), 30)
        self.assertEqual([row["position"] for row in first], list(range(1, 31)))
        self.assertEqual(sum(row["system"] == "plain-minimal" for row in first), 15)
        self.assertEqual(sum(row["system"] == "harness-v0.1.3" for row in first), 15)
        for index in range(0, 30, 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_protocol_keeps_frozen_thresholds_and_no_rescue(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        self.assertEqual(protocol["development_e2e"]["minimum_complete_research_episodes_per_system"], 12)
        self.assertEqual(protocol["resource_acceptance"]["maximum_requested_to_actual_ratio"], 3.0)
        self.assertEqual(protocol["resource_acceptance"]["maximum_unused_reservation_fraction"], 0.6667)
        self.assertEqual(protocol["post_acceptance_rescue"], "FORBIDDEN_FOR_THIS_IDENTITY")

    def test_missing_database_fails_closure_observability(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            result = closure_observability(Path(temporary))
        self.assertEqual(result["verification_starvation"], 1)
        self.assertEqual(result["negative_capacity_events"], 1)


if __name__ == "__main__":
    unittest.main()
