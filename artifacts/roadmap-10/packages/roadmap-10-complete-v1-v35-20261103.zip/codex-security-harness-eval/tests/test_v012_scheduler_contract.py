from __future__ import annotations

import json
import random
import sys
import tempfile
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import jsonschema


ROOT = Path(__file__).resolve().parents[1]
PRODUCT = ROOT.parent / "codex-security-harness-v0.1.2"
sys.path.insert(0, str(PRODUCT / "src"))

from bbp_harness.config import HarnessPaths  # noqa: E402
from bbp_harness.db import Database  # noqa: E402
from bbp_harness.reservations import BoundedReservationEstimator, ReservationDecision  # noqa: E402
from bbp_harness.scheduler import Scheduler  # noqa: E402
from bbp_harness.util import utcnow  # noqa: E402
from scripts.budget import BudgetLedger, BudgetWait  # noqa: E402
from tests.test_budget import usage, v012_spec  # noqa: E402


def multidimensional_request(total: int) -> dict[str, int]:
    return {
        "total_input_tokens": total,
        "noncached_input_tokens": total // 5,
        "output_tokens": total // 10,
        "reasoning_tokens": total // 20,
    }


def multidimensional_usage(total: int) -> dict[str, int]:
    return {
        "total_input_tokens": total,
        "cached_input_tokens": total - total // 5,
        "noncached_input_tokens": total // 5,
        "output_tokens": total // 10,
        "reasoning_tokens": total // 20,
    }


class DeterministicConcurrencyTests(unittest.TestCase):
    def test_one_hundred_seeded_atomic_wait_schedules(self) -> None:
        for seed in range(20261201, 20261301):
            with self.subTest(seed=seed), tempfile.TemporaryDirectory() as temporary:
                rng = random.Random(seed)
                spec = v012_spec(1000, invocations=4)
                ledger = BudgetLedger.initialize(
                    Path(temporary) / "ledger.json",
                    spec,
                    run_id=f"schedule-{seed}",
                    system="harness-v0.1.2",
                    now=1000,
                )
                requests = {
                    "older": multidimensional_request(rng.randint(550, 700)),
                    "younger": multidimensional_request(rng.randint(550, 700)),
                }
                barrier = threading.Barrier(2)

                def attempt(name: str) -> str:
                    barrier.wait()
                    try:
                        ledger.reserve(
                            role="researcher",
                            requested=requests[name],
                            invocation_id=name,
                            now=1001,
                        )
                        return "ADMITTED"
                    except BudgetWait:
                        return "WAIT"

                with ThreadPoolExecutor(max_workers=2) as pool:
                    outcomes = dict(zip(
                        ("older", "younger"),
                        pool.map(attempt, ("older", "younger")),
                        strict=True,
                    ))
                self.assertEqual(sorted(outcomes.values()), ["ADMITTED", "WAIT"])
                admitted = next(name for name, result in outcomes.items() if result == "ADMITTED")
                waiting = next(name for name, result in outcomes.items() if result == "WAIT")
                ledger.start(admitted, now=1002)
                first_actual = rng.randint(100, 250)
                ledger.settle(
                    admitted,
                    actual_usage=multidimensional_usage(first_actual),
                    exit_code=0,
                    exit_reason="PASS",
                    now=1003,
                )
                next_record = ledger.reserve(
                    role="researcher",
                    requested=requests[waiting],
                    invocation_id=waiting,
                    now=1004,
                )
                self.assertEqual(next_record["status"], "RESERVED")
                ledger.start(waiting, now=1005)
                second_actual = min(rng.randint(100, 250), 1000 - first_actual)
                ledger.settle(
                    waiting,
                    actual_usage=multidimensional_usage(second_actual),
                    exit_code=0,
                    exit_reason="PASS",
                    now=1006,
                )
                ledger.finalize(wall_clock_seconds=6, reason="NORMAL_COMPLETION", now=1007)
                state = json.loads(ledger.path.read_text())
                self.assertEqual(
                    [item["status"] for item in state["reservations"]].count("SETTLED"),
                    2,
                )
                self.assertEqual(len({item["invocation_id"] for item in state["reservations"]}), 2)
                self.assertTrue(ledger.verify()["valid_resource_compliance"])

    def test_resume_preserves_usage_and_reconciles_expired_live_reservations(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = BudgetLedger.initialize(
                Path(temporary) / "ledger.json",
                v012_spec(1000),
                run_id="resume",
                system="harness-v0.1.2",
                now=1000,
            )
            ledger.reserve(
                role="mapper",
                requested=multidimensional_request(400),
                invocation_id="done",
                now=1001,
            )
            ledger.start("done", now=1002)
            ledger.settle(
                "done",
                actual_usage=multidimensional_usage(250),
                exit_code=0,
                exit_reason="PASS",
                now=1003,
            )
            ledger.reserve(
                role="researcher",
                requested=multidimensional_request(400),
                invocation_id="crashed-before-start",
                now=1004,
            )
            resumed = BudgetLedger(ledger.path)
            self.assertEqual(resumed.reap(now=1015), ["crashed-before-start"])
            state = json.loads(ledger.path.read_text())
            self.assertEqual(state["usage"]["total_input_tokens"], 250)
            self.assertEqual(state["reservations"][1]["status"], "RELEASED")

    def test_started_crash_settles_known_usage_and_reclaims_unused_capacity(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            ledger = BudgetLedger.initialize(
                Path(temporary) / "ledger.json",
                v012_spec(1000),
                run_id="started-crash",
                system="harness-v0.1.2",
                now=1000,
            )
            ledger.reserve(
                role="researcher",
                requested=multidimensional_request(700),
                invocation_id="crashed",
                now=1001,
            )
            ledger.start("crashed", now=1002)
            ledger.settle(
                "crashed",
                actual_usage=multidimensional_usage(200),
                exit_code=125,
                exit_reason="WORKER_CRASHED_AFTER_START",
                now=1003,
            )
            admitted = ledger.reserve(
                role="researcher",
                requested=multidimensional_request(700),
                invocation_id="next",
                now=1004,
            )
            self.assertEqual(admitted["status"], "RESERVED")


class ProductReservationEventSchemaTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        paths = HarnessPaths.discover(Path(self.temporary.name) / "state")
        paths.ensure()
        self.database = Database(paths.database)
        self.database.migrate()
        now = utcnow()
        target = Path(self.temporary.name) / "target"
        target.mkdir()
        with self.database.connect() as connection:
            connection.execute(
                "INSERT INTO targets(root_path, created_at, updated_at) VALUES(?,?,?)",
                (str(target), now, now),
            )
            target_id = connection.execute("SELECT id FROM targets").fetchone()[0]
            connection.execute(
                "INSERT INTO campaigns(id,target_id,objective,status,scope_status,max_workers,max_waves,created_at,updated_at) "
                "VALUES('CAM-schema',?,'test','ACTIVE','PROVEN',3,4,?,?)",
                (target_id, now, now),
            )
        self.scheduler = Scheduler(self.database)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_all_emitted_lifecycle_events_validate_against_frozen_schema(self) -> None:
        job_id = self.scheduler.create_job("CAM-schema", "researcher")
        job = dict(self.database.one("SELECT * FROM worker_jobs WHERE id=?", (job_id,)))
        estimate = BoundedReservationEstimator().estimate(
            role="researcher",
            prompt_bytes=35000,
            retrieved_document_count=8,
            upstream_evidence_bytes=9000,
        )
        invocation_id = "INV-schema"
        self.scheduler.request_reservation(job, invocation_id, estimate)
        capacity = {
            "fields": {
                field: {
                    "actual_used_before": 0,
                    "active_reserved": 0,
                    "requested_reservation": value,
                    "available_capacity": 1500000,
                    "limit": 1500000,
                }
                for field, value in estimate.request.items()
            },
            "active_reservation_count": 0,
        }
        self.scheduler.apply_reservation_decision(
            invocation_id,
            ReservationDecision(
                "ADMIT",
                invocation_id,
                {"status": "RESERVED", "capacity_snapshot": capacity},
                {},
            ),
        )
        self.scheduler.claim_admitted(job_id, invocation_id)
        self.scheduler.start_reservation(invocation_id)
        self.scheduler.finish_reservation(
            invocation_id,
            {
                "status": "SETTLED",
                "usage": {
                    "total_input_tokens": 100000,
                    "cached_input_tokens": 80000,
                    "noncached_input_tokens": 20000,
                    "output_tokens": 4000,
                    "reasoning_tokens": 2000,
                },
                "violations": [],
            },
            fallback_reason="NORMAL_COMPLETION",
        )
        schema = json.loads(
            (ROOT / "protocol" / "V0.1.2_RESERVATION_EVENT.schema.json").read_text()
        )
        rows = self.database.all(
            "SELECT payload_json FROM scheduler_reservation_events ORDER BY sequence"
        )
        self.assertEqual(len(rows), 4)
        for row in rows:
            jsonschema.Draft202012Validator(schema).validate(json.loads(row["payload_json"]))


if __name__ == "__main__":
    unittest.main()
