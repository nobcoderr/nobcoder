from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import run_v017_acceptance as acceptance  # noqa: E402
from v017_acceptance_common import build_acceptance_scope, fixture_evidence, verify_candidate  # noqa: E402


class V017AcceptanceTests(unittest.TestCase):
    def test_candidate_and_offline_provenance_are_sealed(self) -> None:
        result = verify_candidate()
        self.assertEqual(result["status"], "PASS", result["errors"])
        self.assertEqual(
            result["candidate_clean_tree_sha256"],
            "805b0bc9564d1d22079e584ed15ca1b478cc56140615d450c4b7444c01a5b98a",
        )

    def test_schedule_is_balanced_pair_interleaved_and_deterministic(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        first = acceptance.make_schedule(protocol, "8" * 64)
        second = acceptance.make_schedule(protocol, "8" * 64)
        self.assertEqual(first, second)
        self.assertEqual([row["position"] for row in first], list(range(1, 31)))
        self.assertEqual(sum(row["system"] == "plain-minimal" for row in first), 15)
        self.assertEqual(sum(row["system"] == "harness-v0.1.7" for row in first), 15)
        for index in range(0, 30, 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_fixture_evidence_resolves_for_every_development_episode(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        for case_id in protocol["development_e2e"]["episodes"]:
            evidence = fixture_evidence(case_id)
            self.assertEqual(evidence["document"]["fixture_id"], case_id)

    def test_acceptance_scope_has_standing_authorization_without_bypass(self) -> None:
        budget = json.loads(acceptance.BUDGET.read_text(encoding="utf-8"))
        base = acceptance.resource.calibration_scope("V2-CASE-003", budget)
        scope = build_acceptance_scope("V2-CASE-003", budget, base)
        self.assertTrue(scope["authorization"]["confirmed"])
        self.assertEqual(scope["authorization"]["source"], "user_supplied_official_bug_bounty_scope")
        self.assertEqual(scope["authorization"]["confirmation_mode"], "standing_authorization")
        self.assertTrue(scope["asset"]["in_scope"])
        self.assertFalse(scope["allowed_actions"]["destructive"])
        self.assertFalse(scope["allowed_actions"]["network"])
        self.assertIn("destructive", scope["prohibited_actions"])
        self.assertEqual(scope["fixture_security_evidence"]["network_required"], False)

    def test_frozen_acceptance_thresholds(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        gate = protocol["development_e2e"]
        self.assertEqual(gate["accepted_terminals"], ["REPORT_READY", "NO_VALID_FINDING"])
        self.assertEqual(gate["minimum_accepted_terminals_per_system"], 12)
        self.assertEqual(gate["maximum_true_token_overshoots_per_system"], 0)
        self.assertEqual(protocol["execution"]["retry"], 0)
        self.assertEqual(protocol["execution"]["replacement"], 0)
        repair = protocol["repair_acceptance"]
        self.assertEqual(repair["researcher_reasoning_reservation"], 8500)
        self.assertEqual(repair["maximum_measurement_contract_regressions"], 0)
        self.assertEqual(protocol["post_acceptance_rescue"], "FORBIDDEN_FOR_THIS_IDENTITY")


if __name__ == "__main__":
    unittest.main()
