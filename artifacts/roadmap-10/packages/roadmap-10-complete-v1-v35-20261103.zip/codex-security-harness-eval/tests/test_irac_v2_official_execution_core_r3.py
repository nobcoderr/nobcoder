from __future__ import annotations

import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from execution_environment import prepare_environment  # noqa: E402
from irac_v2_official_execution_core_r3 import AUTH_DESTINATION, corrected_stable_capsule_command  # noqa: E402


def test_auth_mount_is_after_stable_home_parent_bind() -> None:
    with tempfile.TemporaryDirectory(dir=ROOT / "calibration") as temporary:
        layout = prepare_environment(Path(temporary) / "capsule", ROOT / "calibration" / "fixtures" / "SYNTH-001")
        auth = Path("/home/nobcoder/.codex/auth.json")
        command = corrected_stable_capsule_command(layout, ["/bin/true"], [(auth, AUTH_DESTINATION)])
        parent_bind = next(index for index in range(len(command) - 2) if command[index:index + 3] == ["--bind", str(layout.home), "/irac-home"])
        auth_bind = next(index for index in range(len(command) - 2) if command[index:index + 3] == ["--ro-bind", str(auth.resolve()), str(AUTH_DESTINATION)])
        assert parent_bind < auth_bind < command.index("--chdir")
