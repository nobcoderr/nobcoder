from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import postmortem_irac_v2_readiness_r2 as postmortem  # noqa: E402


class IracV2ReadinessR2PostmortemTests(unittest.TestCase):
    def test_cleanup_failure_overrides_pre_cleanup_pass(self) -> None:
        result = postmortem.build_result()
        self.assertTrue(result["pre_cleanup_evidence_non_authoritative"]["all_readiness_checks_true"])
        self.assertEqual("ABORTED_POST_EXECUTION_CLEANUP_FAILURE", result["authoritative_status"])
        self.assertEqual("FAIL_ABORTED_INFRASTRUCTURE", result["scientific_disposition"]["r2_readiness"])

    def test_classifier_separates_two_real_request_messages(self) -> None:
        evidence = postmortem.build_result()["message_classification_evidence"]
        self.assertEqual(2, evidence["request_like_messages_observed"])
        self.assertEqual(1, evidence["fixture_bound_inference_selected"])
        self.assertEqual([], evidence["fatal_errors"])
        self.assertFalse(evidence["ordering_used_for_selection"])
        self.assertTrue(all(evidence["selected_request_predicates"].values()))
        self.assertFalse(all(evidence["nonmatching_request_predicates"].values()))

    def test_no_follow_on_authorized(self) -> None:
        result = postmortem.build_result()
        self.assertTrue(all(value is False for value in result["authorizations"].values()))
        self.assertEqual("INSUFFICIENT_DATA", result["claim"])


if __name__ == "__main__":
    unittest.main()
