from __future__ import annotations

import importlib.util
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from budget import BudgetLedger


def load_module(name: str, relative: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


ENVIRONMENT = load_module("execution_environment", "scripts/execution_environment.py")
TELEMETRY = load_module("run_telemetry", "scripts/run_telemetry.py")
BASELINE = load_module("verify_baseline_store_v2", "scripts/verify_baseline_store.py")
RUNNER = load_module("run_pilot_v2_test", "scripts/run_pilot_v2.py")
SEMANTIC = load_module("semantic_status_test", "scripts/semantic_status.py")
E2E = load_module("e2e_attestation_test", "scripts/e2e_attestation.py")
CHECKPOINT = load_module("plain_checkpoint_test", "scripts/plain_checkpoint.py")
WORKFLOW = load_module("workflow_contract_test", "scripts/workflow_contract.py")
RESOURCE_CALIBRATION = load_module(
    "resource_envelope_calibration_test",
    "scripts/run_resource_envelope_calibration.py",
)
RESERVATION_METRICS = load_module(
    "reservation_capacity_metrics_test",
    "scripts/reservation_capacity_metrics.py",
)
CAPACITY_CALIBRATION = load_module(
    "token_reservation_capacity_calibration_test",
    "scripts/run_token_reservation_capacity_calibration.py",
)
OUTPUT_CALIBRATION = load_module(
    "output_capacity_calibration_test",
    "scripts/run_output_capacity_calibration.py",
)
OVERSHOOT_CHARACTERIZATION = load_module(
    "overshoot_characterization_test",
    "scripts/characterize_invocation_overshoot.py",
)


class PilotV2PlumbingTests(unittest.TestCase):
    def test_overshoot_characterization_result_is_locked_and_stops_capacity_escalation(self) -> None:
        result_path = (
            ROOT
            / "protocol"
            / "PER_INVOCATION_OVERSHOOT_CHARACTERIZATION_V1_RESULT.json"
        )
        lock = json.loads(
            (
                ROOT
                / "protocol"
                / "PER_INVOCATION_OVERSHOOT_CHARACTERIZATION_V1_RESULT.lock.json"
            ).read_text()
        )
        result = json.loads(result_path.read_text())
        self.assertEqual(hashlib.sha256(result_path.read_bytes()).hexdigest(), lock["sha256"])
        self.assertEqual(result["overshoot_shape"]["classification"], "SMALL_RANDOM_TAIL")
        self.assertEqual(
            result["reservation_model"]["classification"],
            "SYSTEMATIC_OVERRESERVATION",
        )
        self.assertEqual(result["decision"]["classification"], "SYSTEMATIC_RESERVATION_MISMATCH")
        self.assertEqual(result["decision"]["advance_capacity_escalation"], "DENY")
        self.assertEqual(result["decision"]["advance_noncached_run_cap_calibration"], "DENY")
        self.assertEqual(result["decision"]["budget_v2"], "NOT_CREATED")

    def test_v0_1_1_final_disposition_is_locked_not_released(self) -> None:
        disposition_path = ROOT / "protocol" / "V0.1.1_FINAL_DISPOSITION.json"
        lock = json.loads(
            (ROOT / "protocol" / "V0.1.1_FINAL_DISPOSITION.lock.json").read_text()
        )
        disposition = json.loads(disposition_path.read_text())
        self.assertEqual(
            hashlib.sha256(disposition_path.read_bytes()).hexdigest(), lock["sha256"]
        )
        self.assertEqual(disposition["status"], "FROZEN_NOT_RELEASED")
        self.assertEqual(disposition["classification"], "SCHEDULER_CAPACITY_INEFFICIENT")
        self.assertFalse(disposition["benchmarkable"])
        self.assertEqual(disposition["supersession"]["next_version"], "0.1.2")
        self.assertEqual(disposition["supersession"]["state"], "PLANNED_NOT_IMPLEMENTED")

    def test_overshoot_characterization_protocol_is_locked_and_offline(self) -> None:
        protocol = OVERSHOOT_CHARACTERIZATION.validate_protocol()
        self.assertEqual(protocol["status"], "FROZEN_BEFORE_ANALYSIS")
        self.assertFalse(protocol["model_invocations_permitted"])
        self.assertFalse(protocol["new_security_runs_permitted"])
        self.assertFalse(protocol["limits_or_reservations_may_change"])
        self.assertEqual(len(protocol["source_artifacts"]), 3)

    def test_overshoot_characterization_uses_nearest_rank_quantiles(self) -> None:
        values = list(range(1, 21))
        result = OVERSHOOT_CHARACTERIZATION.distribution(values)
        self.assertEqual(result["p50"], 10)
        self.assertEqual(result["p75"], 15)
        self.assertEqual(result["p90"], 18)
        self.assertEqual(result["p95"], 19)
        self.assertEqual(result["maximum"], 20)

    def test_overshoot_characterization_detects_systematic_overreservation(self) -> None:
        protocol = OVERSHOOT_CHARACTERIZATION.validate_protocol()
        rows = []
        for index in range(10):
            rows.append({
                "source_phase": "TEST",
                "case_id": f"CASE-{index}",
                "system": "harness-v0.1.1",
                "worker_role": "prior_art",
                "invocation_id": f"INV-{index}",
                "reservation": {
                    "total_input_tokens": 300_000,
                    "noncached_input_tokens": 50_000,
                    "output_tokens": 10_000,
                    "reasoning_tokens": 6_000,
                },
                "actual": {
                    "total_input_tokens": 21_000,
                    "cached_input_tokens": 10_000,
                    "noncached_input_tokens": 11_000,
                    "output_tokens": 500,
                    "reasoning_tokens": 250,
                },
                "utilization": {
                    "total_input_tokens": 0.07,
                    "noncached_input_tokens": 0.22,
                    "output_tokens": 0.05,
                    "reasoning_tokens": 0.041667,
                },
                "overshoot": [],
                "context": {
                    "context_available": True,
                    "prompt_characters": 100,
                    "prompt_bytes": 100,
                    "retrieved_document_count": 1,
                    "upstream_evidence_count": 1,
                    "upstream_evidence_bytes": 10,
                    "inherited_context_bytes": 20,
                },
                "termination": "COMPLETED",
            })
        result = OVERSHOOT_CHARACTERIZATION.characterize(protocol, rows)
        self.assertEqual(result["decision"], "SYSTEMATIC_RESERVATION_MISMATCH")
        self.assertTrue(result["systematic_overreservation_evidence"])
        self.assertEqual(result["capacity_escalation"], "DENY")

    def test_output_o1_result_is_locked_and_forbids_o2(self) -> None:
        result_path = ROOT / "protocol" / "OUTPUT_CAPACITY_CALIBRATION_O1_RESULT.json"
        lock = json.loads(
            (
                ROOT
                / "protocol"
                / "OUTPUT_CAPACITY_CALIBRATION_O1_RESULT.lock.json"
            ).read_text()
        )
        result = json.loads(result_path.read_text())
        self.assertEqual(hashlib.sha256(result_path.read_bytes()).hexdigest(), lock["sha256"])
        self.assertEqual(result["decision"]["classification"], "STOP_TOKEN_OVERSHOOT")
        self.assertEqual(result["decision"]["advance_to_o2"], "DENY")
        self.assertEqual(result["decision"]["budget_v2"], "NOT_CREATED")
        self.assertEqual(result["paired_output_materiality"]["c1_output_denials"], 3)
        self.assertEqual(result["paired_output_materiality"]["o1_output_denials"], 0)
        self.assertEqual(result["systems"]["harness_v0_1_1"]["completed"], 0)

    def test_output_capacity_protocol_is_locked_before_execution(self) -> None:
        protocol = OUTPUT_CALIBRATION.validate_protocol()
        self.assertEqual(protocol["status"], "FROZEN_BEFORE_EXECUTION")
        self.assertEqual(
            protocol["variable_under_test"]["field"],
            "limits.per_run.max_output_tokens",
        )
        self.assertEqual(
            [item["max_output_tokens"] for item in protocol["search_design"]["rungs"]],
            [70_000, 80_000, 90_000],
        )
        self.assertFalse(protocol["fresh_holdout_used"])

    def test_output_o1_changes_only_output_capacity_relative_to_c1(self) -> None:
        protocol = OUTPUT_CALIBRATION.validate_protocol()
        baseline = OUTPUT_CALIBRATION.c1_budget_baseline()
        derived = OUTPUT_CALIBRATION.derive_budget(protocol, "O1")
        self.assertEqual(
            derived["limits"]["per_run"]["max_total_input_tokens"], 1_500_000
        )
        self.assertEqual(derived["limits"]["per_run"]["max_output_tokens"], 70_000)
        self.assertEqual(derived["limits"]["per_invocation"], baseline["limits"]["per_invocation"])
        self.assertEqual(derived["reservation_profiles"], baseline["reservation_profiles"])
        for key, value in baseline["limits"]["per_run"].items():
            if key != "max_output_tokens":
                self.assertEqual(derived["limits"]["per_run"][key], value)

    def test_output_schedule_is_deterministic_case_paired_and_interleaved(self) -> None:
        protocol = OUTPUT_CALIBRATION.validate_protocol()
        first = OUTPUT_CALIBRATION.schedule(protocol, "O1", 1)
        second = OUTPUT_CALIBRATION.schedule(protocol, "O1", 1)
        self.assertEqual(first, second)
        self.assertEqual(len(first), 10)
        for index in range(0, len(first), 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_output_denial_classification_separates_output_only_and_mixed(self) -> None:
        metrics = [{
            "system": "harness-v0.1.1",
            "run_dir": "/tmp/run-a",
            "reservation_denials": [
                {"worker_role": "researcher", "failures": [{"field": "output_tokens"}]},
                {
                    "worker_role": "skeptic",
                    "failures": [
                        {"field": "output_tokens"},
                        {"field": "total_input_tokens"},
                    ],
                },
                {"worker_role": "prior_art", "failures": [{"field": "noncached_input_tokens"}]},
            ],
        }]
        grades = [{"run_dir": "/tmp/run-a", "case_id": "CASE-X"}]
        result = OUTPUT_CALIBRATION.denial_classification(
            metrics, grades, "harness-v0.1.1"
        )
        self.assertEqual(result["output_only_denial_count"], 1)
        self.assertEqual(result["mixed_output_denial_count"], 1)
        self.assertEqual(result["non_output_denial_count"], 1)
        self.assertEqual(result["output_denial_cases"], ["CASE-X"])

    def test_reservation_aggregate_includes_output_resource_fields(self) -> None:
        run_dir = (
            Path("/home/nobcoder/pilot-runs/token-reservation-capacity-calibration")
            / "trc-v1-20261004"
            / "C1"
            / "trial-1"
            / "runs"
            / "DEV-CASE-005-harness-v0.1.1"
        )
        metric = RESERVATION_METRICS.analyze_run(run_dir)
        result = RESERVATION_METRICS.aggregate_system([metric], [], "harness-v0.1.1")
        output = result["resource_fields"]["output_tokens"]
        self.assertGreater(output["requested_reservation"], 0)
        self.assertGreater(output["actual_usage"], 0)
        self.assertIn("prior_art", result["reservation_utilization_by_worker_role"])
        self.assertIn(
            "output_tokens",
            result["reservation_utilization_by_worker_role"]["prior_art"]["resource_fields"],
        )

    def test_capacity_c1_result_is_locked_and_forbids_c2(self) -> None:
        result_path = (
            ROOT / "protocol" / "TOKEN_RESERVATION_CAPACITY_CALIBRATION_C1_RESULT.json"
        )
        lock = json.loads(
            (
                ROOT
                / "protocol"
                / "TOKEN_RESERVATION_CAPACITY_CALIBRATION_C1_RESULT.lock.json"
            ).read_text()
        )
        result = json.loads(result_path.read_text())
        self.assertEqual(hashlib.sha256(result_path.read_bytes()).hexdigest(), lock["sha256"])
        self.assertEqual(result["decision"]["classification"], "STOP_DIFFERENT_RESOURCE_CONSTRAINT")
        self.assertEqual(result["decision"]["advance_to_c2"], "DENY")
        self.assertEqual(result["decision"]["budget_v2"], "NOT_CREATED")
        self.assertEqual(result["systems"]["plain_minimal"]["resource_compliant"], 5)
        self.assertEqual(result["systems"]["harness_v0_1_1"]["resource_compliant"], 5)

    def test_token_reservation_capacity_protocol_is_locked_before_execution(self) -> None:
        protocol = CAPACITY_CALIBRATION.validate_protocol()
        self.assertEqual(protocol["status"], "FROZEN_BEFORE_EXECUTION")
        self.assertEqual(
            protocol["variable_under_test"]["field"],
            "limits.per_run.max_total_input_tokens",
        )
        self.assertEqual(
            protocol["reasonable_envelope_precommitment"]["maximum_total_input_tokens"],
            2_100_000,
        )
        self.assertFalse(protocol["fresh_holdout_used"])

    def test_capacity_c1_changes_only_total_input_run_capacity(self) -> None:
        protocol = CAPACITY_CALIBRATION.validate_protocol()
        base = json.loads(CAPACITY_CALIBRATION.BUDGET_V1.read_text())
        derived = CAPACITY_CALIBRATION.derive_budget(protocol, "C1")
        self.assertEqual(derived["limits"]["per_run"]["max_total_input_tokens"], 1_500_000)
        self.assertEqual(derived["limits"]["per_invocation"], base["limits"]["per_invocation"])
        self.assertEqual(derived["reservation_profiles"], base["reservation_profiles"])
        for key, value in base["limits"]["per_run"].items():
            if key != "max_total_input_tokens":
                self.assertEqual(derived["limits"]["per_run"][key], value)

    def test_capacity_schedule_is_deterministic_case_paired_and_interleaved(self) -> None:
        protocol = CAPACITY_CALIBRATION.validate_protocol()
        first = CAPACITY_CALIBRATION.schedule(protocol, "C1", 1)
        second = CAPACITY_CALIBRATION.schedule(protocol, "C1", 1)
        self.assertEqual(first, second)
        self.assertEqual(len(first), 10)
        for index in range(0, len(first), 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_budget_reservation_events_include_capacity_snapshot_without_policy_change(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            spec = json.loads((ROOT / "protocol" / "PILOT_BUDGET_V1.json").read_text())
            ledger = BudgetLedger.initialize(
                root / "ledger.json", spec, run_id="telemetry-test", system="harness-v0.1.1"
            )
            ledger.activate(now=1000)
            request = ledger.profile_request("researcher")
            reservation = ledger.reserve(
                role="researcher", requested=request, invocation_id="INV-1", now=1001
            )
            snapshot = reservation["admission_capacity_snapshot"]
            total = snapshot["fields"]["total_input_tokens"]
            self.assertEqual(total["actual_used_before"], 0)
            self.assertEqual(total["active_reserved"], 0)
            self.assertEqual(total["requested_reservation"], 300_000)
            self.assertEqual(total["available_capacity"], 1_200_000)
            state = json.loads((root / "ledger.json").read_text())
            admitted = next(item for item in state["events"] if item["type"] == "RESERVATION_ADMITTED")
            self.assertIsNone(admitted["details"]["denial_reason"])
            self.assertFalse(
                admitted["details"]["capacity_snapshot"]["active_reservations"]
            )

    def test_reservation_metrics_report_utilization_wait_peak_and_denial(self) -> None:
        run_dir = (
            Path("/home/nobcoder/pilot-runs/resource-envelope-calibration")
            / "rec-v1-20261004"
            / "R0"
            / "trial-1"
            / "runs"
            / "DEV-CAL-RESEARCH-001-harness-v0.1.1"
        )
        result = RESERVATION_METRICS.analyze_run(run_dir)
        self.assertEqual(result["reservation_denial_count"], 1)
        self.assertEqual(result["peak_simultaneous_reserved_total_input_tokens"], 900_000)
        self.assertGreater(result["aggregate_requested_to_actual_ratio"], 1)
        self.assertIn("researcher", result["reservation_utilization_by_worker_role"])
        self.assertTrue(result["resource_compliant"])

    def test_reservation_aggregate_counts_resource_compliance_key(self) -> None:
        metrics = [{
            "system": "plain-minimal",
            "run_dir": "/tmp/example-run",
            "resource_compliant": True,
            "requested_total_input_tokens": 300_000,
            "actual_settled_total_input_tokens": 100_000,
            "actual_run_total_input_tokens": 100_000,
            "unused_total_input_tokens": 200_000,
            "aggregate_reservation_utilization": 1 / 3,
            "aggregate_requested_to_actual_ratio": 3,
            "aggregate_unused_reservation_fraction": 2 / 3,
            "peak_simultaneous_reserved_total_input_tokens": 300_000,
            "peak_simultaneous_reservation_count": 1,
            "reservation_denial_count": 0,
            "invocations": [],
        }]
        grades = [{
            "system": "plain-minimal",
            "run_dir": "/tmp/example-run",
            "complete_research_episode": True,
        }]
        result = RESERVATION_METRICS.aggregate_system(metrics, grades, "plain-minimal")
        self.assertEqual(result["resource_compliant"], 1)

    def test_resource_calibration_r0_result_is_locked_and_fail_closed(self) -> None:
        result_path = ROOT / "protocol" / "RESOURCE_ENVELOPE_CALIBRATION_V1_RESULT.json"
        lock = json.loads(
            (ROOT / "protocol" / "RESOURCE_ENVELOPE_CALIBRATION_V1_RESULT.lock.json").read_text()
        )
        result = json.loads(result_path.read_text())
        self.assertEqual(hashlib.sha256(result_path.read_bytes()).hexdigest(), lock["sha256"])
        self.assertEqual(result["status"], "R0_COMPLETE_STOPPED")
        self.assertEqual(result["decision"]["advance_to_r1"], "DENY")
        self.assertEqual(result["decision"]["budget_v2"], "NOT_CREATED")
        self.assertFalse(result["security_correctness_scored"])

    def test_resource_calibration_protocol_is_locked_before_execution(self) -> None:
        protocol = RESOURCE_CALIBRATION.validate_protocol()
        self.assertEqual(protocol["status"], "FROZEN_BEFORE_EXECUTION")
        self.assertEqual(protocol["search_acceptance"]["minimum_completion_rate_per_system"], 0.8)
        self.assertFalse(protocol["fresh_holdout_used"])

    def test_resource_calibration_r0_changes_no_budget_except_wall_metadata(self) -> None:
        protocol = RESOURCE_CALIBRATION.validate_protocol()
        base = json.loads(RESOURCE_CALIBRATION.BUDGET_V1.read_text())
        derived = RESOURCE_CALIBRATION.derive_budget(protocol, "R0")
        self.assertEqual(derived["limits"], base["limits"])
        self.assertEqual(derived["reservation_profiles"], base["reservation_profiles"])
        self.assertEqual(derived["limits"]["per_run"]["max_invocations"], 16)

    def test_resource_calibration_schedule_is_deterministic_and_interleaved(self) -> None:
        protocol = RESOURCE_CALIBRATION.validate_protocol()
        first = RESOURCE_CALIBRATION.schedule(protocol, "R0", 1)
        second = RESOURCE_CALIBRATION.schedule(protocol, "R0", 1)
        self.assertEqual(first, second)
        self.assertEqual(len(first), 10)
        for index in range(0, len(first), 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_research_episode_fixture_and_private_oracle_preflight(self) -> None:
        protocol = RESOURCE_CALIBRATION.validate_protocol()
        entry = next(item for item in protocol["episodes"] if item["id"] == "CAL-RESEARCH-001")
        root, case = RESOURCE_CALIBRATION.resolve_episode(entry)
        self.assertEqual(case["target_sha256"], entry["target_sha256"])
        self.assertTrue((root / "CAL-RESEARCH-001" / "target" / "artifacts" / "service.py").is_file())
        self.assertFalse((root / "CAL-RESEARCH-001" / "private").exists())

    def test_disposable_workspace_matches_snapshot_and_redirects_runtime_paths(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            (source / "target.txt").write_text("frozen\n", encoding="utf-8")
            layout = ENVIRONMENT.prepare_environment(root / "run", source)
            manifest = json.loads(layout.environment_manifest.read_text())
            self.assertEqual(
                manifest["immutable_snapshot_manifest"]["content_root_digest"],
                manifest["initial_workspace_manifest"]["content_root_digest"],
            )
            (layout.workspace / "target.txt").write_text("changed\n", encoding="utf-8")
            self.assertEqual((layout.immutable_snapshot / "target.txt").read_text(), "frozen\n")
            variables = ENVIRONMENT.environment_variables(layout)
            self.assertEqual(variables["TMPDIR"], "/tmp")
            self.assertEqual(variables["BENCHMARK_WORK"], "/work")
            self.assertTrue(variables["HOME"].startswith(str(layout.runtime_root)))

    def test_environment_policy_is_identical_for_both_system_labels(self) -> None:
        policy = ENVIRONMENT.environment_policy()
        self.assertEqual(policy["systems"], ["plain-minimal", "harness-v0.1.0"])
        self.assertEqual(policy["writable_mounts"], ["/work", "/tmp", "/build", "/artifacts"])

    def test_capsule_exposes_current_run_but_not_host_home_or_curator(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            (source / "assigned.txt").write_text("visible\n", encoding="utf-8")
            host_sentinel = root / "host-secret.txt"
            host_sentinel.write_text("must-not-be-mounted\n", encoding="utf-8")
            layout = ENVIRONMENT.prepare_environment(root / "run", source)
            command = ENVIRONMENT.bwrap_command(
                layout,
                [
                    "/bin/sh",
                    "-c",
                    f"test -f /work/assigned.txt && test ! -e {host_sentinel}",
                ],
            )
            completed = subprocess.run(command, capture_output=True, text=True, timeout=10, check=False)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertNotIn("--ro-bind /home /home", " ".join(command))

    def test_codex_runtime_is_discovered_from_package_and_fully_mounted(self) -> None:
        runtime = ENVIRONMENT.discover_codex_runtime(RUNNER.CODEX_BINARY)
        self.assertEqual(runtime["status"], "PASS")
        destinations = {item["destination"] for item in runtime["mounts"]}
        self.assertIn("/codex-bin", destinations)
        self.assertIn("/codex-code-mode-host", destinations)
        self.assertIn("/codex-path", destinations)
        self.assertIn("/codex-resources", destinations)
        self.assertEqual(runtime["completeness_oracle"], "real_codex_tool_invocation_required")
        for executable in runtime["executables"].values():
            self.assertTrue(executable["exists"])
            self.assertTrue(executable["executable"])
            self.assertEqual(executable["linkage"]["status"], "PASS")

    def test_capsule_command_contains_discovered_codex_runtime_mounts(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            source = root / "source"
            source.mkdir()
            (source / "assigned.txt").write_text("visible\n", encoding="utf-8")
            layout = ENVIRONMENT.prepare_environment(root / "run", source)
            command = ENVIRONMENT.bwrap_command(
                layout,
                ["/codex-bin", "--version"],
                readonly_paths=ENVIRONMENT.codex_runtime_mounts(RUNNER.CODEX_BINARY),
            )
            rendered = " ".join(str(item) for item in command)
            self.assertIn("/codex-code-mode-host", rendered)
            self.assertIn("/codex-resources", rendered)
            self.assertIn("/codex-path", rendered)

    def test_v2_plain_runner_uses_shared_writable_workspace(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            run = Path(temporary)
            (run / "runtime" / "workspace").mkdir(parents=True)
            (run / "runtime" / "workspace" / "worker_context.md").write_text("context\n")
            (run / "worker_runs").mkdir()
            command, _, _, _, _ = RUNNER.commands(run, "plain-minimal")
            self.assertIn("workspace-write", command)
            self.assertIn("/work", command)
            self.assertNotIn("read-only", command)

    def test_v2_wrapper_expands_writable_role_only_inside_outer_capsule(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            (root / "worker_runs").mkdir()
            (root / "control").mkdir()
            shutil.copy2(ROOT / "scripts" / "codex_v2_wrapper.sh", root / "wrapper")
            shutil.copy2(ROOT / "scripts" / "budget.py", root / "budget.py")
            shutil.copy2(ROOT / "scripts" / "budget_cli.py", root / "budget_cli.py")
            (root / "wrapper").chmod(0o755)
            (root / "budget_cli.py").chmod(0o755)
            fake = root / "fake-codex"
            fake.write_text(
                "#!/bin/sh\n"
                "printf '%s\\n' \"$@\" > \"$ARG_CAPTURE\"\n"
                "printf '%s\\n' '{\"type\":\"turn.completed\",\"usage\":{\"input_tokens\":40,\"cached_input_tokens\":10,\"output_tokens\":3,\"reasoning_output_tokens\":2}}'\n",
                encoding="utf-8",
            )
            fake.chmod(0o755)
            spec = json.loads((ROOT / "protocol" / "CALIBRATION_BUDGET_V0.json").read_text())
            ledger = BudgetLedger.initialize(
                root / "control" / "budget_ledger.json",
                spec,
                run_id="wrapper-translation",
                system="plain-minimal",
            )
            capture = root / "args.txt"
            environment = os.environ.copy()
            environment.update(
                PILOT_RUN_DIR=str(root),
                BUDGET_LEDGER=str(ledger.path),
                CODEX_REAL_BINARY=str(fake),
                BENCHMARK_OUTER_CAPSULE="1",
                ARG_CAPTURE=str(capture),
            )
            completed = subprocess.run(
                [str(root / "wrapper"), "exec", "-s", "workspace-write"],
                capture_output=True,
                text=True,
                env=environment,
                timeout=30,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            arguments = capture.read_text(encoding="utf-8").splitlines()
            self.assertIn("danger-full-access", arguments)
            self.assertNotIn("workspace-write", arguments)

    def test_v2_wrapper_does_not_strand_reservation_on_invocation_timeout(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            (root / "worker_runs").mkdir()
            (root / "control").mkdir()
            shutil.copy2(ROOT / "scripts" / "codex_v2_wrapper.sh", root / "wrapper")
            shutil.copy2(ROOT / "scripts" / "budget.py", root / "budget.py")
            shutil.copy2(ROOT / "scripts" / "budget_cli.py", root / "budget_cli.py")
            (root / "wrapper").chmod(0o755)
            fake = root / "fake-codex"
            fake.write_text("#!/bin/sh\nsleep 30\n", encoding="utf-8")
            fake.chmod(0o755)
            spec = json.loads((ROOT / "protocol" / "CALIBRATION_BUDGET_V0.json").read_text())
            spec["limits"]["per_invocation"]["max_wall_time_seconds"] = 2
            spec["limits"]["per_run"]["max_wall_time_seconds"] = 10
            ledger = BudgetLedger.initialize(
                root / "control" / "budget_ledger.json",
                spec,
                run_id="wrapper-termination",
                system="harness-v0.1.0",
            )
            environment = os.environ.copy()
            environment.update(
                PILOT_RUN_DIR=str(root),
                BUDGET_LEDGER=str(ledger.path),
                CODEX_REAL_BINARY=str(fake),
                CODEX_SETTLEMENT_GRACE_SECONDS="1",
            )
            completed = subprocess.run(
                [str(root / "wrapper"), "exec"],
                capture_output=True,
                text=True,
                env=environment,
                timeout=10,
                check=False,
            )
            self.assertEqual(completed.returncode, 124, completed.stderr)
            state = json.loads(ledger.path.read_text(encoding="utf-8"))
            self.assertEqual(len(state["reservations"]), 1)
            self.assertEqual(state["reservations"][0]["status"], "SETTLED")
            self.assertEqual(state["usage"]["invocations"], 1)
            self.assertEqual(state["invocations"][0]["exit_reason"], "INVOCATION_WALL_TIMEOUT")

    def test_lifecycle_observer_emits_candidate_worker_and_experiment_events(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            database = root / "research.db"
            connection = sqlite3.connect(database)
            connection.execute("CREATE TABLE hypotheses(id TEXT)")
            connection.execute("CREATE TABLE candidates(id TEXT, state TEXT)")
            connection.execute("CREATE TABLE worker_jobs(id TEXT, role TEXT, status TEXT)")
            connection.execute("CREATE TABLE worker_runs(id TEXT, role TEXT, status TEXT)")
            connection.execute("CREATE TABLE experiments(id TEXT, status TEXT)")
            connection.execute(
                "CREATE TABLE candidate_transitions(id TEXT, candidate_id TEXT, from_state TEXT, to_state TEXT, reason TEXT)"
            )
            connection.execute("INSERT INTO candidates VALUES('C-1','CANDIDATE')")
            connection.execute("INSERT INTO hypotheses VALUES('H-1')")
            connection.execute("INSERT INTO worker_jobs VALUES('J-1','reproducer','QUEUED')")
            connection.execute("INSERT INTO worker_runs VALUES('W-1','reproducer','RUNNING')")
            connection.execute("INSERT INTO experiments VALUES('E-1','RUNNING')")
            connection.execute("INSERT INTO candidate_transitions VALUES('T-1','C-1','HYPOTHESIS','CANDIDATE','evidence')")
            connection.commit()
            connection.close()
            (root / "budget_ledger.json").write_text(
                json.dumps({"usage": {"total_input_tokens": 10}, "reservations": []}), encoding="utf-8"
            )
            captures = root / "worker_runs" / "budget-captures"
            captures.mkdir(parents=True)
            (captures / "mapper.jsonl").write_text(
                "\n".join(
                    json.dumps({
                        "type": "item.completed",
                        "item": {
                            "id": identity,
                            "type": "command_execution",
                            "command": command,
                            "exit_code": 0,
                        },
                    })
                    for identity, command in (
                        ("build", "./environment/build.sh"),
                        ("test", "./environment/test.sh"),
                    )
                ) + "\n",
                encoding="utf-8",
            )
            observer = TELEMETRY.RunTelemetry(
                root,
                system="harness-v0.1.0",
                command=["controller"],
                database=database,
            )
            heartbeat = observer.sample()
            observer.finish(termination_reason="TIMEOUT")
            types = [json.loads(line)["event_type"] for line in observer.events_path.read_text().splitlines()]
            for expected in (
                "CANDIDATE_CREATED",
                "HYPOTHESIS_CREATED",
                "CANDIDATE_QUEUED",
                "REPRODUCER_SCHEDULED",
                "REPRODUCER_STARTED",
                "EXPERIMENT_CREATED",
                "EXPERIMENT_STARTED",
                "CANDIDATE_TRANSITION",
                "TOOL_COMMAND_COMPLETED",
                "BUILD_COMPLETED",
                "TEST_COMPLETED",
                "RUN_TERMINATED",
            ):
                self.assertIn(expected, types)
            for field in (
                "last_progress_at",
                "current_phase",
                "current_worker",
                "current_command",
                "subprocess_runtime",
                "tokens_since_progress",
                "experiments_started",
                "experiments_completed",
                "candidate_queue_depth",
            ):
                self.assertIn(field, heartbeat)

    def test_supervisor_records_timeout_and_terminates_process_group(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            (root / "worker_runs").mkdir()
            stdout = root / "worker_runs" / "stdout"
            stderr = root / "worker_runs" / "stderr"
            result = TELEMETRY.supervise_process(
                run_dir=root,
                system="plain-minimal",
                command=["/bin/sh", "-c", "sleep 30"],
                environment=os.environ.copy(),
                input_text="",
                stdout_path=stdout,
                stderr_path=stderr,
                wall_limit_seconds=0.2,
                poll_seconds=0.05,
            )
            self.assertTrue(result["timed_out"])
            self.assertEqual(result["termination_reason"], "TIMEOUT")
            heartbeat = json.loads((root / "telemetry" / "heartbeat.json").read_text())
            self.assertEqual(heartbeat["current_phase"], "TERMINATED")
            checkpoint = json.loads((root / "telemetry" / "plain_checkpoint.json").read_text())
            self.assertEqual(checkpoint["run_disposition"], "TIMEOUT")
            self.assertFalse(checkpoint["checkpoint_is_terminal"])
            self.assertFalse(checkpoint["checkpoint_can_upgrade_timeout"])

    def test_structured_blocked_status_overrides_zero_exit_code(self) -> None:
        result = {"exit_code": 0, "timed_out": False}
        compliance = {
            "valid_resource_compliance": True,
            "termination": {"reason": "NORMAL_COMPLETION"},
        }
        semantic = {
            "invalid_infrastructure": True,
            "fatal_statuses": [{"status": "BLOCKED", "source": "worker"}],
        }
        self.assertEqual(
            SEMANTIC.classify_run(result, compliance, semantic),
            "INVALID_INFRASTRUCTURE",
        )

    def test_missing_code_mode_host_error_is_fatal_even_with_complete_json(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            worker_runs = root / "worker_runs"
            worker_runs.mkdir()
            output = worker_runs / "last.json"
            output.write_text(json.dumps({"status": "COMPLETE"}), encoding="utf-8")
            (worker_runs / "stderr.txt").write_text(
                "failed to spawn code-mode host /codex-code-mode-host: No such file or directory\n",
                encoding="utf-8",
            )
            semantic = SEMANTIC.inspect_execution_semantics(
                root,
                system="plain-minimal",
                plain_output_path=output,
            )
            self.assertTrue(semantic["invalid_infrastructure"])
            self.assertEqual(semantic["status"], "INVALID_INFRASTRUCTURE")
            self.assertTrue(semantic["fatal_errors"])

    def test_exit_124_is_valid_timeout_even_when_outer_supervisor_did_not_time_out(self) -> None:
        result = {"timed_out": False, "exit_code": 124}
        compliance = {
            "valid_resource_compliance": True,
            "termination": {"reason": "WORKER_FAILURE"},
        }
        semantic = {"invalid_infrastructure": False, "structured_terminals": []}
        self.assertEqual(SEMANTIC.classify_run(result, compliance, semantic), "VALID_TIMEOUT")

    def test_typed_harness_timeout_precedes_zero_controller_exit(self) -> None:
        result = {"timed_out": False, "exit_code": 0}
        compliance = {
            "valid_resource_compliance": True,
            "termination": {"reason": "NORMAL_COMPLETION"},
        }
        semantic = {
            "invalid_infrastructure": False,
            "structured_terminals": [{"source": "campaign", "status": "TIMEOUT"}],
        }
        self.assertEqual(SEMANTIC.classify_run(result, compliance, semantic), "VALID_TIMEOUT")

    def test_plain_development_e2e_requires_real_lifecycle_evidence(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            workers = root / "worker_runs"
            workers.mkdir()
            commands = [
                "rg --files /work/target",
                "/work/environment/build.sh",
                "python3 /work/target/service.py",
                "/work/environment/test.sh",
            ]
            (workers / "plain-events.jsonl").write_text(
                "\n".join(
                    json.dumps({
                        "type": "item.completed",
                        "item": {"type": "command_execution", "command": command, "exit_code": 0},
                    })
                    for command in commands
                )
                + "\n",
                encoding="utf-8",
            )
            (root / "output.json").write_text(
                json.dumps({
                    "status": "COMPLETE",
                    "hypotheses": [{"id": "H-1"}],
                    "experiments": [{"id": "E-1"}],
                    "candidates": [{
                        "state": "REPORT_READY",
                        "reproduced": True,
                        "strongest_falsifier": "negative control",
                        "evidence": ["proof"],
                    }],
                }),
                encoding="utf-8",
            )
            result = E2E.attest_plain(root)
            self.assertEqual(result["status"], "PASS")
            self.assertTrue(all(value == "PASS" for value in result["checks"].values()))

    def test_harness_e2e_reads_budget_capture_events(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            captures = root / "worker_runs" / "budget-captures"
            captures.mkdir(parents=True)
            (captures / "mapper.jsonl").write_text(
                json.dumps({
                    "type": "item.completed",
                    "item": {
                        "type": "command_execution",
                        "command": "rg --files /work/target && /work/environment/build.sh",
                        "exit_code": 0,
                    },
                }) + "\n",
                encoding="utf-8",
            )
            (root / "output.json").write_text(json.dumps({
                "campaigns": [{"status": "BLOCKED"}],
                "worker_runs": [{"role": "mapper"}],
                "candidates": [],
                "experiments": [],
            }), encoding="utf-8")
            result = E2E.attest_harness(root)
            self.assertEqual(result["checks"]["used_tools"], "PASS")
            self.assertEqual(result["checks"]["read_source"], "PASS")
            self.assertEqual(result["checks"]["build_target"], "PASS")

    def test_plain_checkpoint_preserves_progress_without_upgrading_timeout(self) -> None:
        with tempfile.TemporaryDirectory(dir="/home/nobcoder") as temporary:
            root = Path(temporary)
            captures = root / "worker_runs" / "budget-captures"
            captures.mkdir(parents=True)
            events = [
                {
                    "type": "item.completed",
                    "item": {
                        "id": "message-1",
                        "type": "agent_message",
                        "text": json.dumps({
                            "status": "IN_PROGRESS",
                            "hypotheses": [{"id": "H-1", "disposition": "UNDER_TEST"}],
                            "experiments": [],
                            "candidates": [],
                        }),
                    },
                },
                {
                    "type": "item.started",
                    "item": {"id": "command-1", "type": "command_execution", "command": "test.sh"},
                },
            ]
            event_path = captures / "plain.jsonl"
            event_path.write_text("".join(json.dumps(item) + "\n" for item in events), encoding="utf-8")
            ended_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
            control = root / "control"
            control.mkdir()
            (control / "budget_ledger.json").write_text(json.dumps({
                "invocations": [{"exit_reason": "INVOCATION_WALL_TIMEOUT", "ended_at": ended_at}],
                "termination": {"reason": "WORKER_FAILURE", "at": ended_at},
            }), encoding="utf-8")

            checkpoint = CHECKPOINT.build_checkpoint(root, phase="TERMINATED")

            self.assertEqual(checkpoint["run_disposition"], "TIMEOUT")
            self.assertFalse(checkpoint["terminal_result_available"])
            self.assertFalse(checkpoint["checkpoint_is_terminal"])
            self.assertFalse(checkpoint["checkpoint_can_upgrade_timeout"])
            self.assertEqual(checkpoint["provisional_result"]["hypotheses"][0]["id"], "H-1")
            self.assertTrue(checkpoint["diagnostics"]["subprocess_open_at_checkpoint"])
            self.assertTrue(checkpoint["progress"]["progress_near_termination"])

    def test_frozen_v0_1_0_workflow_contract_has_product_defects(self) -> None:
        product = ROOT / "baselines" / "recovery" / "v0.1.0" / "product-tree" / "codex-security-harness"
        contract = WORKFLOW.inspect_product_contract(product)
        self.assertFalse(contract["experiment_producer_present"])
        self.assertFalse(contract["explicit_no_valid_finding_present"])
        self.assertTrue(contract["evidence_judge_scheduler_present"])
        self.assertTrue(contract["candidate_transition_writer_present"])

    def test_deterministic_contract_report_blocks_v0_1_0_benchmarking(self) -> None:
        report = json.loads((ROOT / "calibration" / "workflow-contract" / "latest.json").read_text())
        self.assertEqual(report["baseline_archive_sha256"], "16e5974c60e2159fa36e43e132ee7aad4b2cacafe3063c3a17d1a05bc82bea8c")
        self.assertEqual(report["status"], "E2E_INCOMPLETE")
        self.assertEqual(report["benchmarkability"], "NOT_BENCHMARKABLE")
        self.assertEqual(report["fixture_matrix"], {
            "POSITIVE": "FAIL",
            "NEGATIVE": "FAIL",
            "EMPTY": "FAIL",
            "BLOCKED": "PASS",
            "TIMEOUT": "FAIL",
        })

    def test_baseline_verifier_rejects_wrong_or_missing_archive(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = Path(temporary)
            lock = json.loads((ROOT / "baselines" / "v0.1.0" / "BASELINE_LOCK.json").read_text())
            lock["backup_store"] = str(store / "backup")
            (store / "BASELINE_LOCK.json").write_text(json.dumps(lock), encoding="utf-8")
            (store / "SHA256SUMS").write_text(
                f"{lock['archive']['sha256']}  {lock['archive']['name']}\n", encoding="utf-8"
            )
            result = BASELINE.verify_store(store)
            self.assertEqual(result["status"], "FAIL")
            self.assertFalse(result["materialization_allowed"])

    def test_old_cases_are_permanently_excluded_from_clean_holdout(self) -> None:
        registry = json.loads((ROOT / "protocol" / "DEVELOPMENT_ONLY_CASES.json").read_text())
        self.assertEqual(registry["classification"], "DEVELOPMENT_ONLY")
        self.assertEqual(registry["clean_holdout_eligibility"], "NEVER_CLEAN_HOLDOUT")
        self.assertEqual(registry["cases"], [f"CASE-{number:03d}" for number in range(1, 9)])

    def test_v2_cases_are_permanently_excluded_from_clean_holdout(self) -> None:
        registry = json.loads((ROOT / "protocol" / "DEVELOPMENT_ONLY_CASES_V2.json").read_text())
        self.assertEqual(registry["classification"], "DEVELOPMENT_ONLY")
        self.assertEqual(registry["clean_holdout_eligibility"], "NEVER_CLEAN_HOLDOUT")
        self.assertEqual(registry["cases"], [f"V2-CASE-{number:03d}" for number in range(1, 9)])


if __name__ == "__main__":
    unittest.main()
