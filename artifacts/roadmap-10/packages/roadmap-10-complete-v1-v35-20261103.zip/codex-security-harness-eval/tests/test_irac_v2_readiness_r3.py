from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from execution_environment import sha256_file  # noqa: E402
from run_irac_v2_readiness_r3_cleanup_acceptance import DEFAULT_ROOT, verify as verify_cleanup  # noqa: E402
from verify_irac_v2_readiness_r3 import verify as verify_static  # noqa: E402


class IracV2ReadinessR3Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.protocol = json.loads((ROOT / "protocol" / "INITIAL_REQUEST_ACCOUNTING_CHARACTERIZATION_V2_READINESS_R3.json").read_text())

    def test_forbidden_r2_components_are_hash_identical(self) -> None:
        frozen = self.protocol["frozen_r2_components"]
        expected = {
            "capture_addon_sha256": ROOT / "scripts" / "irac_v2_websocket_capture.py",
            "capture_runtime_sha256": ROOT / "scripts" / "irac_v2_runtime.py",
            "prompt_sha256": ROOT / "calibration" / "initial-request-accounting-characterization-v2-readiness-r2" / "smoke-prompt.txt",
            "schema_sha256": ROOT / "schemas" / "irac-v2-readiness-r2-smoke-output.schema.json",
            "classifier_sha256": ROOT / "scripts" / "irac_v2_message_classifier.py",
        }
        for key, path in expected.items():
            self.assertEqual(frozen[key], sha256_file(path), key)

    def test_lifecycle_contract_has_exact_cleanup_allowlist(self) -> None:
        lifecycle = self.protocol["lifecycle_contract"]
        self.assertEqual(["capsule/runtime", "capsule/worker_runs"], lifecycle["ephemeral_cleanup_allowlist"])
        self.assertEqual("FORBIDDEN", lifecycle["capsule_root_recursive_delete"])
        self.assertEqual("VERIFY_AND_PRESERVE", lifecycle["immutable_snapshot_normal_cleanup"])

    def test_r2_remains_aborted_no_retry(self) -> None:
        path = ROOT / "calibration" / "initial-request-accounting-characterization-v2-readiness-r2" / "real-codex-smoke-20261005" / "ABORTED_EXECUTION_LOCK.json"
        lock = json.loads(path.read_text())
        self.assertEqual("ABORTED_POST_EXECUTION_CLEANUP_FAILURE", lock["authoritative_smoke_status"])
        self.assertFalse(lock["retry_or_replacement"])

    def test_cleanup_acceptance_passes_8_of_8(self) -> None:
        result = verify_cleanup(DEFAULT_ROOT)
        self.assertEqual("PASS", result["status"])
        self.assertEqual(8, result["result"]["cases_passed"])
        self.assertEqual(0, result["result"]["model_invocations"])

    def test_static_verifier_passes(self) -> None:
        self.assertEqual("PASS", verify_static()["status"])


if __name__ == "__main__":
    unittest.main()
