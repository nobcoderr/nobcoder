import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import jsonschema

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from evidence_judge_variance_v2_core import workload_row  # noqa: E402


PROTOCOL = ROOT / "protocol" / "EVIDENCE_JUDGE_VARIANCE_DECOMPOSITION_V2.json"
SCHEDULE = ROOT / "calibration" / "evidence-judge-variance-decomposition-v2" / "SCHEDULE.json"
SCHEMA = ROOT / "schemas" / "evidence-judge-variance-observation-v2.schema.json"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def valid_observation():
    digest = "a" * 64
    return {
        "schema_version": 2,
        "schedule_position": 1,
        "sample_id": "IRAC2EJVDV2-001",
        "fixture_id": "EJVD-SEM-A",
        "family": "SEMANTIC_FIXED_SIZE",
        "repetition": 1,
        "session_id": "session-1",
        "fresh_session": True,
        "concurrency": 1,
        "fixture_digest": digest,
        "input_context_digest": digest,
        "raw_request_digest": digest,
        "full_message_digest": digest,
        "semantic_message_digest": digest,
        "runtime_full_digest": digest,
        "runtime_field_digests": {"prompt_cache_key": digest},
        "scientific_request_digest": digest,
        "logical_request_canonical_bytes": 100,
        "total_input_tokens": 100,
        "cached_input_tokens": 60,
        "noncached_input_tokens": 40,
        "output_tokens": 10,
        "reasoning_tokens": 5,
        "cache_accounting_sum_invariant": True,
        "wall_seconds": 1.0,
        "exit_code": 0,
        "schema_valid": True,
        "resource_compliant": True,
        "provider_outcome": "ACCEPTED",
        "fixture_bound_request_count": 1,
        "classifier_ambiguity_count": 0,
        "payload_mutation_count": 0,
        "turn_count": 1,
        "tool_call_count": 0,
        "terminal_status": "VALID_COMPLETED",
        "valid_for_primary_analysis": True,
        "runtime_digest": digest,
        "product_digest": digest,
        "capture_digest": digest,
        "classifier_digest": digest,
        "equivalence_contract_digest": digest,
        "resource_accounting_contract_digest": digest,
        "started_at": "2026-10-05T00:00:00+00:00",
        "ended_at": "2026-10-05T00:00:01+00:00",
    }


def test_schedule_is_complete_balanced_and_interleaved():
    entries = load(SCHEDULE)["entries"]
    assert len(entries) == 54
    assert [row["position"] for row in entries] == list(range(1, 55))
    assert len({row["sample_id"] for row in entries}) == 54
    assert all(row["sample_id"] == f"IRAC2EJVDV2-{row['position']:03d}" for row in entries)
    assert all(left["fixture_id"] != right["fixture_id"] for left, right in zip(entries, entries[1:]))
    assert Counter(row["family"] for row in entries) == Counter({
        "SEMANTIC_FIXED_SIZE": 24,
        "SIZE_FIXED_SEMANTICS": 18,
        "EXACT_REPEAT": 12,
    })
    repetitions = defaultdict(set)
    for row in entries:
        repetitions[row["fixture_id"]].add(row["repetition"])
    assert repetitions["EJVD-REPEAT-D"] == set(range(1, 13))


def test_protocol_uses_request_identity_not_provider_input_equality():
    protocol = load(PROTOCOL)
    family = protocol["design"]["family_3_exact_repeat"]
    checks = protocol["analysis_precommit"]["manipulation_checks"]
    assert family["scientific_request_digest_unique_required"] == 1
    assert family["provider_total_input_is_request_equivalence_gate"] is False
    assert checks["scientific_request_identity_within_fixture"].startswith("exactly one")
    assert checks["provider_total_input_equality_required"] is False
    assert "maximum_total_input_relative_range_for_runtime_consistency" not in family


def test_observation_schema_accepts_only_valid_scientific_sample():
    schema = load(SCHEMA)
    value = valid_observation()
    jsonschema.Draft202012Validator(schema).validate(value)
    invalid = dict(value)
    invalid["provider_outcome"] = "REJECTED"
    try:
        jsonschema.Draft202012Validator(schema).validate(invalid)
    except jsonschema.ValidationError:
        pass
    else:
        raise AssertionError("provider rejection must fail the V2 scientific observation schema")


def test_workload_mapping_is_unique_and_immutable():
    row = workload_row("EJVD-REPEAT-D")
    assert row["repetitions"] == 12
    assert (ROOT / row["path"]).is_file()
