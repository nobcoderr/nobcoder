from __future__ import annotations

import importlib.util
import hashlib
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("score_benchmark", ROOT / "scripts" / "score_benchmark.py")
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(MODULE)

SCREEN_SPEC = importlib.util.spec_from_file_location(
    "screen_contamination", ROOT / "scripts" / "screen_contamination.py"
)
SCREEN = importlib.util.module_from_spec(SCREEN_SPEC)
assert SCREEN_SPEC and SCREEN_SPEC.loader
SCREEN_SPEC.loader.exec_module(SCREEN)

COMPLIANT_RESOURCE = {
    "verification_source": "independent_budget_ledger_recomputation",
    "status": "PASS",
    "valid_resource_compliance": True,
    "budget_spec_sha256": "a" * 64,
    "errors": [],
    "violations": [],
}


class EvalLabTests(unittest.TestCase):
    def test_scores_valid_roots_and_false_strong(self) -> None:
        cases = {"suite": "s", "cases": [{"id": "real"}, {"id": "trap"}]}
        truth = {
            "suite": "s",
            "cases": [
                {"id": "real", "expected_class": "REAL_VULN", "eligible_roots": [{"root_id": "r1"}]},
                {"id": "trap", "expected_class": "TRAP", "eligible_roots": []},
            ],
        }
        base = {
            "status": "COMPLETE",
            "contaminated": False,
            "resource_compliance": COMPLIANT_RESOURCE,
            "trial": 1,
            "elapsed_seconds": 10,
            "tokens": {},
            "hypotheses_total": 1,
            "hypotheses_duplicate": 0,
            "reproducer": {"attempts": 1, "successes": 1},
            "skeptic_decisions": [],
        }
        observations = {
            "benchmark_id": "b",
            "baseline_id": "locked",
            "records": [
                {
                    **base,
                    "system": "harness",
                    "case_id": "real",
                    "candidates": [{"id": "c1", "semantic_key": "k1", "state": "STRONG", "matched_root_id": "r1", "reproduced": True}],
                },
                {
                    **base,
                    "system": "harness",
                    "case_id": "trap",
                    "candidates": [{"id": "c2", "semantic_key": "k2", "state": "STRONG", "matched_root_id": None, "reproduced": False}],
                },
            ],
        }
        result = MODULE.score(cases, truth, observations)["systems"]["harness"]
        self.assertEqual(result["unique_valid_roots_found"], 1)
        self.assertEqual(result["root_recall_at_available_k"], 1.0)
        self.assertEqual(result["incorrect_strong"], 1)
        self.assertEqual(result["negative_class_incorrect_strong"]["TRAP"], 1)
        self.assertEqual(result["strong_precision"], 0.5)
        self.assertEqual(result["false_strong"], 1)
        self.assertEqual(result["false_report_ready"], 0)
        self.assertEqual(result["codex_invocations"], 2)
        self.assertIsNone(result["pass_at_3"])
        self.assertIsNone(result["pass_power_3"])

    def test_scores_full_telemetry_without_double_counting_reasoning(self) -> None:
        cases = {"suite": "s", "cases": [{"id": "real"}]}
        truth = {
            "suite": "s",
            "cases": [{"id": "real", "expected_class": "REAL_VULN", "eligible_roots": [{"root_id": "r1"}]}],
        }
        observations = {
            "records": [{
                "system": "harness",
                "case_id": "real",
                "trial": 1,
                "status": "COMPLETE",
                "contaminated": False,
                "resource_compliance": COMPLIANT_RESOURCE,
                "wall_clock_seconds": 20,
                "worker_count": 5,
                "codex_invocations": 7,
                "cost_usd": 1.25,
                "tokens": {
                    "total_input_tokens": 100,
                    "cached_input_tokens": 60,
                    "noncached_input_tokens": 40,
                    "output_tokens": 20,
                    "reasoning_tokens": 5,
                },
                "candidates_generated": 1,
                "experiments_executed": 4,
                "duplicate_experiments": 1,
                "burned_path_revisits": 2,
                "candidates": [{
                    "semantic_key": "k",
                    "state": "REPORT_READY",
                    "matched_root_id": "r1",
                    "reproduced": True,
                }],
            }],
        }
        result = MODULE.score(cases, truth, observations)["systems"]["harness"]
        self.assertEqual(result["tokens"]["total_io_tokens"], 120)
        self.assertEqual(result["tokens"]["reasoning_tokens"], 5)
        self.assertEqual(result["tokens"]["token_consistency_errors"], 0)
        self.assertEqual(result["total_io_tokens_per_valid_unique_root"], 120.0)
        self.assertEqual(result["noncached_input_tokens_per_valid_unique_root"], 40.0)
        self.assertEqual(result["cost_usd_per_valid_unique_root"], 1.25)
        self.assertEqual(result["duplicate_experiments_per_case_trial"], 1.0)
        self.assertEqual(result["burned_path_revisits_per_case_trial"], 2.0)

    def test_rejects_ground_truth_in_public_manifest(self) -> None:
        cases = {"suite": "s", "cases": [{"id": "x", "expected_class": "TRAP"}]}
        truth = {"suite": "s", "cases": [{"id": "x", "expected_class": "TRAP", "eligible_roots": []}]}
        with self.assertRaises(ValueError):
            MODULE.score(cases, truth, {"records": []})

    def test_resource_noncompliant_record_is_excluded(self) -> None:
        cases = {"suite": "s", "cases": [{"id": "real"}]}
        truth = {
            "suite": "s",
            "cases": [
                {"id": "real", "expected_class": "REAL_VULN", "eligible_roots": [{"root_id": "r1"}]}
            ],
        }
        observations = {
            "records": [{
                "system": "harness",
                "case_id": "real",
                "trial": 1,
                "status": "COMPLETE",
                "contaminated": False,
                "resource_compliance": {
                    **COMPLIANT_RESOURCE,
                    "status": "FAIL",
                    "valid_resource_compliance": False,
                    "violations": ["total input overshoot"],
                },
                "candidates": [{
                    "semantic_key": "k",
                    "state": "REPORT_READY",
                    "matched_root_id": "r1",
                    "reproduced": True,
                }],
            }],
        }
        result = MODULE.score(cases, truth, observations)
        self.assertNotIn("harness", result["systems"])
        self.assertEqual(result["excluded_records"][0]["reason"], "resource_noncompliant")

    def test_resource_self_assertion_without_independent_verification_is_excluded(self) -> None:
        cases = {"suite": "s", "cases": [{"id": "real"}]}
        truth = {
            "suite": "s",
            "cases": [
                {"id": "real", "expected_class": "REAL_VULN", "eligible_roots": [{"root_id": "r1"}]}
            ],
        }
        observations = {
            "records": [{
                "system": "harness",
                "case_id": "real",
                "trial": 1,
                "status": "COMPLETE",
                "contaminated": False,
                "valid_resource_compliance": True,
                "candidates": [],
            }],
        }
        result = MODULE.score(cases, truth, observations)
        self.assertNotIn("harness", result["systems"])
        self.assertEqual(result["excluded_records"][0]["reason"], "resource_unverified")

    def test_baseline_store_fails_closed_when_archive_is_unavailable(self) -> None:
        spec = importlib.util.spec_from_file_location(
            "verify_baseline_store", ROOT / "scripts" / "verify_baseline_store.py"
        )
        verifier = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(verifier)
        result = verifier.verify_store(ROOT / "baselines" / "v0.1.0")
        self.assertEqual(result["sha256sums"], "PASS")
        self.assertEqual(result["recovery_tree"]["status"], "PASS")
        if result["primary_archive"]["status"] != "PASS" or result["backup_archive"]["status"] != "PASS":
            self.assertEqual(result["status"], "FAIL")
            self.assertFalse(result["materialization_allowed"])

    def test_frozen_budget_lock_matches_spec(self) -> None:
        spec_path = ROOT / "protocol" / "PILOT_BUDGET_V1.json"
        lock = json.loads((ROOT / "protocol" / "PILOT_BUDGET_V1.lock.json").read_text())
        self.assertEqual(hashlib.sha256(spec_path.read_bytes()).hexdigest(), lock["file_sha256"])
        spec = json.loads(spec_path.read_text())
        canonical = json.dumps(spec, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        self.assertEqual(hashlib.sha256(canonical.encode()).hexdigest(), lock["canonical_json_sha256"])

    def test_contamination_screen_classifies_direct_and_pair_hits(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            temp = Path(temp_dir)
            database = temp / "research.db"
            connection = sqlite3.connect(database)
            connection.execute(
                "CREATE TABLE knowledge_documents ("
                "id INTEGER PRIMARY KEY, source_type TEXT, source_uri TEXT, title TEXT, "
                "tags TEXT, content TEXT, sha256 TEXT)"
            )
            connection.executemany(
                "INSERT INTO knowledge_documents VALUES (?, ?, ?, ?, ?, ?, ?)",
                [
                    (1, "report", "a", "Exact historical title", "", "body", "a" * 64),
                    (2, "report", "b", "Unrelated", "", "orchid-repo boundary bypass", "b" * 64),
                    (3, "method", "c", "Generic", "", "generic authorization method", "c" * 64),
                ],
            )
            connection.commit()
            connection.close()
            manifest = temp / "fingerprints.json"
            manifest.write_text(json.dumps({
                "suite": "pilot",
                "cases": [
                    {"id": "CASE-001", "fingerprints": {"exact_title": ["Exact historical title"]}},
                    {"id": "CASE-002", "fingerprints": {
                        "repository_terms": ["orchid-repo"],
                        "vulnerability_terms": ["boundary bypass"],
                    }},
                    {"id": "CASE-003", "fingerprints": {"symbols": ["never_seen_symbol"]}},
                ],
            }), encoding="utf-8")
            result = SCREEN.screen(database, manifest)
            classes = {item["id"]: item["classification"] for item in result["cases"]}
            self.assertEqual(classes["CASE-001"], "CONTAMINATED")
            self.assertEqual(classes["CASE-002"], "CONTAMINATED")
            self.assertEqual(classes["CASE-003"], "CLEAN")


if __name__ == "__main__":
    unittest.main()
