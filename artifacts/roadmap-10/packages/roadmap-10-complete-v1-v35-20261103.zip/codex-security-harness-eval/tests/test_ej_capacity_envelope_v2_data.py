from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_r2_postmortem_is_invocation_free_and_complete() -> None:
    value = load(ROOT / "calibration" / "evidence-judge-capacity-envelope-v1-r2-postmortem" / "POSTMORTEM.json")
    assert value["rows"] == 24
    assert value["method"]["model_invocations"] == 0
    assert value["capacity_v1_policy_changed"] is False
    assert len(value["overshoot_rows"]) == 2
    assert {row["position"] for row in value["overshoot_rows"]} == {18, 19}


def test_capacity_v2_dataset_has_exact_permitted_sources() -> None:
    base = ROOT / "calibration" / "evidence-judge-capacity-envelope-v2"
    manifest = load(base / "DEVELOPMENT_DATASET_MANIFEST.json")
    rows = [json.loads(line) for line in (base / "EJ_CAPACITY_DEVELOPMENT_V2.jsonl").read_text().splitlines()]
    assert len(rows) == manifest["rows"]
    assert set(manifest["counts_by_source"]) == {
        "evidence-judge-characterization-v1",
        "evidence-judge-characterization-v2",
        "evidence-judge-variance-decomposition-v1",
        "evidence-judge-variance-decomposition-v3",
        "evidence-judge-capacity-envelope-v1-validation-r2",
    }
    assert "request-identity-characterization-v1-r2" not in manifest["counts_by_source"]
    assert all(row["validity"]["eligible"] for row in rows)
    assert len({row["deduplication_key"] for row in rows}) == len(rows)


def test_r2_tail_rows_are_development_not_fresh_validation() -> None:
    base = ROOT / "calibration" / "evidence-judge-capacity-envelope-v2"
    rows = [json.loads(line) for line in (base / "EJ_CAPACITY_DEVELOPMENT_V2.jsonl").read_text().splitlines()]
    r2 = [row for row in rows if row["source_experiment"] == "evidence-judge-capacity-envelope-v1-validation-r2"]
    assert len(r2) == 24
    assert sum(row["validity"]["capacity_reservation_compliant"] is False for row in r2) == 2
    assert all(row["classification"] == "DEVELOPMENT_ONLY_CAPACITY_DESIGN_DATA" for row in r2)

