from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import run_capture_runtime_reliability_v1 as runner  # noqa: E402
from irac_v2_readiness_lifecycle import write_json_atomic  # noqa: E402


def _build_score_fixture(root: Path, *, failed: int | None = None) -> None:
    root.mkdir()
    (root / "schedule.json").write_bytes(runner.SCHEDULE.read_bytes())
    (root / "position-status").mkdir()
    (root / "operational-observations").mkdir()
    for position in range(1, 13):
        success = position != failed
        write_json_atomic(root / "position-status" / f"POSITION-{position:03d}.json", {
            "position": position,
            "sample_id": f"CRRV1-{position:03d}",
            "status": "ACCEPTED" if success else "INVALID_OPERATIONAL",
            "model_invocation_count": 1,
            "proxy_readiness": "PASS" if success else "FAIL",
            "capture_valid": success,
            "classifier_valid": success,
            "finalization_pass": success,
            "provider_outcome": "ACCEPTED",
            "analysis_authorized": False,
            "retry_count": 0,
            "replacement_count": 0,
            **({} if success else {"failure_class": "UNKNOWN_CAPTURE_FAILURE"}),
        })
        write_json_atomic(root / "operational-observations" / f"POSITION-{position:03d}.json", {
            "position": position,
            "sample_id": f"CRRV1-{position:03d}",
            "operational_classification": "ACCEPTED" if success else "CAPTURE_FAILURE",
            "provider_outcome": "ACCEPTED",
            "capture_valid": success,
            "fixture_bound_request_count": 1 if success else 0,
            "classifier_ambiguity_count": 0,
            "finalization_pass": success,
        })


def test_score_requires_all_twelve_gates(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "pass"
    _build_score_fixture(root)
    monkeypatch.setattr(runner, "verify_source_lock", lambda: {"status": "PASS", "errors": []})
    value = runner.score(root)
    assert value["status"] == "PASS_LOCKED"
    assert all(value["gates"].values())
    assert value["variance_identity_creation_authorized"] is False


def test_score_fails_closed_on_one_capture_failure(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    root = tmp_path / "fail"
    _build_score_fixture(root, failed=7)
    monkeypatch.setattr(runner, "verify_source_lock", lambda: {"status": "PASS", "errors": []})
    value = runner.score(root)
    assert value["status"] == "FAIL_LOCKED"
    assert value["gates"]["capture_valid_12_of_12"] is False
    assert value["gates"]["unknown_capture_failure_zero"] is False


def test_failure_classifier_distinguishes_pre_model_and_post_model():
    assert runner.classify_child_failure("proxy listener timeout", ["PROXY_STARTING"]) == "PROXY_STARTUP_FAILURE"
    assert runner.classify_child_failure("unexpected", ["MODEL_STARTED"]) == "RUNNER_CRASH_DURING_MODEL"
    assert runner.classify_child_failure("unexpected", ["MODEL_STARTED", "MODEL_TERMINAL"]) == "UNKNOWN_CAPTURE_FAILURE"


def test_schedule_is_fixed_unique_and_non_scientific():
    value = json.loads(runner.SCHEDULE.read_text(encoding="utf-8"))
    assert value["positions"] == 12
    assert value["concurrency"] == 1
    assert value["retry_count"] == 0
    assert value["replacement_count"] == 0
    assert value["classification"] == "NON_SCIENTIFIC_OPERATIONAL_QUALIFICATION"
    assert [row["position"] for row in value["entries"]] == list(range(1, 13))
    assert len({row["sample_id"] for row in value["entries"]}) == 12

