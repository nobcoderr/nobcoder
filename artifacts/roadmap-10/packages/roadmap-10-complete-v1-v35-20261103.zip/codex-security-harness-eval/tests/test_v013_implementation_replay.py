from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from run_v013_implementation_replay import build_result  # noqa: E402


class V013ImplementationReplayTests(unittest.TestCase):
    def test_all_historical_candidates_remain_preserved_and_closable(self) -> None:
        result = build_result()
        self.assertEqual(result["status"], "PASS", result["checks"])
        self.assertEqual(result["observed"]["candidate_paths"], 33)
        self.assertEqual(result["observed"]["candidate_paths_preserved"], 33)
        self.assertEqual(result["observed"]["full_closure_feasible"], 33)
        self.assertEqual(result["observed"]["verification_starvation"], 0)


if __name__ == "__main__":
    unittest.main()
