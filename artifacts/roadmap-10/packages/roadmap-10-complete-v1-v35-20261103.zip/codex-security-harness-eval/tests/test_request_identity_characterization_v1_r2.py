from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import jsonschema


ROOT = Path(__file__).resolve().parents[1]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_r2_changes_only_declared_identity_contract_surface() -> None:
    r1 = load(ROOT / "protocol" / "REQUEST_IDENTITY_CHARACTERIZATION_V1.json")
    r2 = load(ROOT / "protocol" / "REQUEST_IDENTITY_CHARACTERIZATION_V1_R2.json")
    assert r2["decision_tree"] == r1["decision_tree"]
    assert r2["measurement_envelope"] == r1["measurement_envelope"]
    assert r2["frozen_workload"] == r1["frozen_workload"]
    assert r2["runtime"] == r1["runtime"]
    assert r2["observer"] == r1["observer"]


def test_r2_schedule_is_balanced_unique_and_schema_compatible() -> None:
    schedule = load(ROOT / "calibration" / "request-identity-characterization-v1-r2" / "SCHEDULE.json")
    observation_schema = load(ROOT / "schemas" / "initial-request-accounting-v2-official-r2-observation.schema.json")
    sample_schema = observation_schema["properties"]["sample_id"]
    assert [item["position"] for item in schedule["entries"]] == list(range(1, 13))
    assert len({item["sample_id"] for item in schedule["entries"]}) == 12
    assert Counter(item["condition"] for item in schedule["entries"]) == Counter({"EMPTY_START": 4, "MODEL_CACHE_ONLY": 4, "MODEL_PLUS_APPS_CACHE": 4})
    for item in schedule["entries"]:
        jsonschema.Draft202012Validator({"$schema": "https://json-schema.org/draft/2020-12/schema", **sample_schema}).validate(item["sample_id"])
    assert schedule["retry_count"] == schedule["replacement_count"] == 0


def test_r1_is_never_analyze_and_has_no_analysis_artifact() -> None:
    lock = load(Path("/home/nobcoder/pilot-runs/request-identity-characterization-v1-20261005/RAW_EXECUTION_LOCK.json"))
    assert lock["execution_status"] == "MEASUREMENT_INCOMPLETE_IMMUTABLE_NEVER_ANALYZE"
    assert lock["analysis_authorized"] is False
    assert not (ROOT / "analysis" / "request-identity-characterization-v1-20261005").exists()

