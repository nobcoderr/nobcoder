from __future__ import annotations

import importlib.util
import json
import unittest
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "run_v012_acceptance", ROOT / "scripts" / "run_v012_acceptance.py"
)
RUNNER = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(RUNNER)


class V012AcceptanceRunnerTests(unittest.TestCase):
    def test_schedule_is_deterministic_balanced_and_pair_interleaved(self) -> None:
        protocol = json.loads(
            (ROOT / "protocol" / "V0.1.2_ACCEPTANCE_PROTOCOL.json").read_text()
        )
        first = RUNNER.schedule(protocol, "a" * 64)
        second = RUNNER.schedule(protocol, "a" * 64)
        self.assertEqual(first, second)
        self.assertEqual(len(first), 30)
        counts = Counter((item["system"], item["case_id"]) for item in first)
        self.assertTrue(all(value == 3 for value in counts.values()))
        for index in range(0, len(first), 2):
            pair = first[index : index + 2]
            self.assertEqual(pair[0]["case_id"], pair[1]["case_id"])
            self.assertEqual(pair[0]["trial"], pair[1]["trial"])
            self.assertEqual(
                {item["system"] for item in pair},
                {"plain-minimal", "harness-v0.1.2"},
            )


if __name__ == "__main__":
    unittest.main()
