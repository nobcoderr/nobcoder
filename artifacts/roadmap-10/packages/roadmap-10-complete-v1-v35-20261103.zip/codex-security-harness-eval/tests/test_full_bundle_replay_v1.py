from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_full_bundle_replay_v1.py"
SPEC = importlib.util.spec_from_file_location("full_bundle_replay_v1", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_eligible_paths_are_bounded_by_invocation_capacity() -> None:
    episodes = [
        {"episode_id": "A", "candidate_count": 0},
        {"episode_id": "B", "candidate_count": 2},
        {"episode_id": "C", "candidate_count": 9},
    ]
    paths = MODULE.eligible_paths(episodes, 3)
    assert [row["path_id"] for row in paths] == [
        "B:candidate-01",
        "B:candidate-02",
        "C:candidate-01",
        "C:candidate-02",
        "C:candidate-03",
    ]


def test_capacity_feasibility_counts_used_active_and_requested() -> None:
    fields = MODULE.CAPACITY_FIELDS
    used = {field: 0.0 for field in fields}
    active = {field: 0.0 for field in fields}
    requested = {field: 1.0 for field in fields}
    limits = {field: 2.0 for field in fields}
    assert all(MODULE.capacity_feasibility(used, active, requested, limits).values())
    active["total_input_tokens"] = 2.0
    result = MODULE.capacity_feasibility(used, active, requested, limits)
    assert result["total_input_tokens"] is False
    assert result["reasoning_tokens"] is True


def test_add_capacity_never_mutates_inputs() -> None:
    left = {field: 1.0 for field in MODULE.CAPACITY_FIELDS}
    right = {field: 2.0 for field in MODULE.CAPACITY_FIELDS}
    result = MODULE.add_capacity(left, right)
    assert all(value == 3.0 for value in result.values())
    assert all(value == 1.0 for value in left.values())


def test_preflight_verifies_frozen_inputs_and_path_count() -> None:
    result = MODULE.preflight(False)
    assert result["status"] == "PRE_EXECUTION_LOCKED"
    assert result["eligible_path_count"] == 33
    assert result["model_invocations"] == 0


def test_bundle_uses_capacity_v2_large_tier_and_fixed_terminalization() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    policy = MODULE.load_json(MODULE.POLICY)
    invocations, _ = MODULE.load_rows(protocol)
    role_policy = MODULE.load_json(MODULE.frozen_input_paths(protocol)["candidate_a_role_policy"][0])
    ej_policy = MODULE.load_json(MODULE.frozen_input_paths(protocol)["evidence_judge_capacity_v2_policy"][0])
    roles, bundle, overshoots = MODULE.derive_bundle(protocol, policy, role_policy, ej_policy, invocations)
    assert roles["evidence_judge"]["total_input_tokens"] == 148000
    assert roles["evidence_judge"]["output_tokens"] == 3000
    assert roles["evidence_judge"]["reasoning_tokens"] == 2500
    assert roles["terminalization"]["invocation_slots"] == 0
    assert bundle["invocation_slots"] == 4
    assert bundle["wall_time_seconds"] == 335
    assert overshoots == []


def test_policy_and_protocol_forbid_product_and_model_execution() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    policy = MODULE.load_json(MODULE.POLICY)
    assert protocol["model_invocations"] == 0
    assert protocol["security_effectiveness_scoring"] == "FORBIDDEN"
    assert protocol["decision"]["v0.1.3_implementation_before_pass"] == "FORBIDDEN"
    assert policy["admission"]["actual_usage_synthesis"] is False
