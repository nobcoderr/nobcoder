from __future__ import annotations

import hashlib
import importlib.util
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_v012_preimplementation", ROOT / "scripts" / "verify_v012_preimplementation.py"
)
VERIFY = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
SPEC.loader.exec_module(VERIFY)


class V012PreimplementationTests(unittest.TestCase):
    def test_preimplementation_lock_and_intelligence_seal_pass(self) -> None:
        result = VERIFY.verify(ROOT)
        self.assertEqual(result["status"], "PASS", result["errors"])
        self.assertFalse(result["implementation_authorized"])
        self.assertFalse(result["release_authorized"])
        self.assertFalse(result["fresh_holdout_authorized"])

    def test_aggregate_lock_covers_every_authoritative_file(self) -> None:
        lock = json.loads(
            (ROOT / "protocol" / "V0.1.2_PREIMPLEMENTATION_LOCK.json").read_text()
        )
        observed = {
            relative: hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
            for relative in lock["files"]
        }
        self.assertEqual(observed, lock["files"])
        self.assertEqual(VERIFY.aggregate_digest(observed), lock["aggregate_sha256"])

    def test_contract_distinguishes_wait_from_final_denial(self) -> None:
        contract = json.loads(
            (ROOT / "protocol" / "V0.1.2_RESERVATION_SCHEDULER_CONTRACT.json").read_text()
        )
        admission = contract["admission"]
        self.assertIn("active reservations", admission["wait_rule"])
        self.assertIn("used + requested > run_limit", admission["deny_final_rule"])
        self.assertFalse(admission["transient_pressure_is_terminal"])
        self.assertEqual(contract["termination"]["temporary_capacity_pressure"], "NONTERMINAL_WAIT")

    def test_acceptance_thresholds_are_precommitted_and_stricter_than_v011(self) -> None:
        acceptance = json.loads(
            (ROOT / "protocol" / "V0.1.2_ACCEPTANCE_PROTOCOL.json").read_text()
        )
        offline = acceptance["acceptance_gates"]["offline_reservation_regression"]
        live = acceptance["acceptance_gates"]["live_efficiency"]
        e2e = acceptance["acceptance_gates"]["development_e2e"]
        self.assertEqual(offline["maximum_harness_total_requested_to_actual_ratio"], 3.0)
        self.assertLess(offline["maximum_harness_total_unused_reservation_fraction"], 0.762046)
        self.assertEqual(offline["prior_art_canary"]["minimum_total_p50_utilization"], 0.25)
        self.assertEqual(live["maximum_ghost_reservations"], 0)
        self.assertEqual(e2e["minimum_complete_research_episodes_per_system"], 12)
        self.assertEqual(e2e["maximum_token_overshoots_per_system"], 0)

    def test_change_boundary_forbids_intelligence_and_holdout_changes(self) -> None:
        boundary = json.loads(
            (ROOT / "protocol" / "V0.1.2_CHANGE_BOUNDARY.json").read_text()
        )
        frozen = set(boundary["frozen_behavior"])
        forbidden = set(boundary["forbidden"])
        self.assertIn("prompts and skills", frozen)
        self.assertIn("candidate admission and transition thresholds", frozen)
        self.assertIn("create Budget V2", forbidden)
        self.assertIn("curate or execute a fresh holdout", forbidden)
        self.assertIn("create Pilot V3 schedule", forbidden)

    def test_event_schema_is_closed_and_covers_lifecycle_terminals(self) -> None:
        schema = json.loads(
            (ROOT / "protocol" / "V0.1.2_RESERVATION_EVENT.schema.json").read_text()
        )
        contract = json.loads(
            (ROOT / "protocol" / "V0.1.2_RESERVATION_SCHEDULER_CONTRACT.json").read_text()
        )
        self.assertFalse(schema["additionalProperties"])
        schema_states = set(schema["properties"]["lifecycle_state"]["enum"])
        self.assertEqual(schema_states, set(contract["lifecycle"]["states"]))
        self.assertTrue(set(contract["lifecycle"]["terminal_states"]).issubset(schema_states))


if __name__ == "__main__":
    unittest.main()
