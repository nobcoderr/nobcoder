from __future__ import annotations

import json
import stat
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_readiness_lifecycle import (  # noqa: E402
    CleanupInterrupted,
    LifecycleError,
    cleanup_ephemeral,
    directory_content_digest,
    freeze_evidence,
    verify_evidence_lock,
)


class R3LifecycleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.capsule = self.root / "capsule"
        self.immutable = self.capsule / "immutable" / "snapshot"
        self.runtime = self.capsule / "runtime"
        self.workers = self.capsule / "worker_runs"
        self.evidence = self.root / "evidence"
        for path in (self.immutable, self.runtime, self.workers, self.evidence):
            path.mkdir(parents=True)
        (self.immutable / "source.txt").write_text("immutable\n")
        (self.runtime / "temp.txt").write_text("runtime\n")
        (self.workers / "worker.txt").write_text("worker\n")
        (self.evidence / "proof.txt").write_text("proof\n")
        self.immutable_digest = directory_content_digest(self.immutable)
        self.lock_path = self.root / "EVIDENCE_LOCK.json"
        freeze_evidence(self.root, [self.evidence], self.lock_path)
        self.journal = self.root / "CLEANUP_JOURNAL.json"

    def tearDown(self) -> None:
        for path in self.root.rglob("*"):
            if path.exists() and not path.is_symlink():
                path.chmod(stat.S_IMODE(path.stat().st_mode) | stat.S_IWUSR | (stat.S_IXUSR if path.is_dir() else 0))
        self.temporary.cleanup()

    def cleanup(self, **kwargs):
        return cleanup_ephemeral(
            self.capsule,
            immutable_snapshot=self.immutable,
            expected_immutable_digest=self.immutable_digest,
            evidence_base=self.root,
            evidence_lock_path=self.lock_path,
            journal_path=self.journal,
            **kwargs,
        )

    def test_cleanup_preserves_immutable_and_evidence(self) -> None:
        self.assertEqual("PASS", self.cleanup()["status"])
        self.assertTrue(self.immutable.exists())
        self.assertFalse(self.runtime.exists())
        self.assertFalse(self.workers.exists())
        self.assertEqual("PASS", verify_evidence_lock(self.root, self.lock_path)["status"])

    def test_cleanup_is_idempotent(self) -> None:
        self.assertFalse(self.cleanup()["idempotent"])
        self.assertTrue(self.cleanup()["idempotent"])

    def test_interrupted_cleanup_resumes_without_repeating(self) -> None:
        with self.assertRaises(CleanupInterrupted):
            self.cleanup(inject_interrupt_after=1)
        journal = json.loads(self.journal.read_text())
        self.assertEqual("INTERRUPTED", journal["status"])
        self.assertEqual(1, len(journal["completed_targets"]))
        self.assertEqual("PASS", self.cleanup()["status"])

    def test_digest_drift_fails_before_deletion(self) -> None:
        self.immutable.chmod(0o755)
        (self.immutable / "source.txt").chmod(0o644)
        (self.immutable / "source.txt").write_text("drift\n")
        with self.assertRaises(LifecycleError):
            self.cleanup()
        self.assertTrue(self.runtime.exists())
        self.assertTrue(self.workers.exists())
        self.assertEqual("FAILED", json.loads(self.journal.read_text())["status"])

    def test_cleanup_failure_is_terminal(self) -> None:
        with self.assertRaises(LifecycleError):
            self.cleanup(inject_failure=True)
        with self.assertRaises(LifecycleError):
            self.cleanup()

    def test_symlinked_cleanup_target_fails_closed(self) -> None:
        external = self.root / "external"
        external.mkdir()
        (external / "keep.txt").write_text("keep\n")
        for member in self.runtime.iterdir():
            member.unlink()
        self.runtime.rmdir()
        self.runtime.symlink_to(external, target_is_directory=True)
        with self.assertRaises(LifecycleError):
            self.cleanup()
        self.assertTrue((external / "keep.txt").exists())


if __name__ == "__main__":
    unittest.main()
