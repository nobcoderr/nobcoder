from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from irac_v2_invocation_capture_validator_v1 import validate_invocation_capture
from irac_v2_message_classifier import canonical_digest


MODEL = "gpt-5.6-sol"
PROMPT = "Return the operational sentinel only."
SCHEMA = {
    "type": "object",
    "properties": {"sentinel": {"const": "IRAC_MULTI_CONNECTION_READY", "type": "string"}},
    "required": ["sentinel"],
    "additionalProperties": False,
}


def request(*, bound: bool = True, suffix: str = "") -> dict:
    prompt = PROMPT if bound else PROMPT + " not-bound"
    schema = SCHEMA if bound else {"type": "object", "properties": {}}
    return {
        "type": "response.create",
        "model": MODEL,
        "input": [{"type": "message", "role": "user", "content": [{"type": "input_text", "text": prompt}]}],
        "text": {"format": {"type": "json_schema", "schema": schema}},
        "metadata": {"suffix": suffix},
    }


def write_capture(
    root: Path,
    connections: list[list[dict]],
    *,
    mutated: set[tuple[int, int]] | None = None,
    fragmented: set[tuple[int, int]] | None = None,
    close_connections: bool = True,
) -> Path:
    capture = root / "capture"
    capture.mkdir()
    events: list[dict] = []
    sequence = 0
    mutated = mutated or set()
    fragmented = fragmented or set()
    for connection_number, payloads in enumerate(connections, start=1):
        connection_id = hashlib.sha256(f"connection-{connection_number}".encode()).hexdigest()
        events.append({
            "event": "WEBSOCKET_ESTABLISHED",
            "connection_id_sha256": connection_id,
            "connection_number": connection_number,
            "path": "/backend-api/codex/responses",
        })
        for local_index, payload in enumerate(payloads, start=1):
            sequence += 1
            raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
            raw_name = f"messages/message-{sequence:04d}.json"
            component_name = f"messages/message-{sequence:04d}.components.json"
            (capture / raw_name).parent.mkdir(exist_ok=True)
            (capture / raw_name).write_bytes(raw)
            (capture / component_name).write_text(json.dumps({
                "request_payload_found": isinstance(payload, dict) and payload.get("type") == "response.create",
                "component_sha256": {"payload": canonical_digest(payload)},
            }), encoding="utf-8")
            digest = hashlib.sha256(raw).hexdigest()
            is_mutated = (connection_number, local_index) in mutated
            events.append({
                "event": "WEBSOCKET_LOGICAL_MESSAGE",
                "connection_id_sha256": connection_id,
                "connection_number": connection_number,
                "direction": "client_to_server",
                "message_sequence": sequence,
                "directional_sequence": local_index,
                "message_type": "text",
                "fragment_count": 3 if (connection_number, local_index) in fragmented else 1,
                "raw_artifact": raw_name,
                "component_artifact": component_name,
                "raw_message_sha256": digest,
                "content_before_hook_sha256": digest,
                "content_after_hook_sha256": "0" * 64 if is_mutated else digest,
                "content_mutated_by_addon": is_mutated,
                "dropped": False,
                "injected": False,
            })
        if close_connections:
            events.append({
                "event": "WEBSOCKET_CLOSED",
                "connection_id_sha256": connection_id,
                "connection_number": connection_number,
                "close_code": 1000,
            })
    (capture / "websocket-events.jsonl").write_text(
        "".join(json.dumps(row, sort_keys=True) + "\n" for row in events), encoding="utf-8"
    )
    (capture / "http-events.jsonl").write_text("", encoding="utf-8")
    return capture


@pytest.mark.parametrize(
    ("connections", "kwargs", "expected", "reason"),
    [
        ([[request()]], {}, "PASS", "EXACTLY_ONE_FIXTURE_BOUND_REQUEST"),
        ([[request()], [{"type": "session.update"}]], {}, "PASS", "EXACTLY_ONE_FIXTURE_BOUND_REQUEST"),
        ([[{"type": "session.update"}], [request()]], {}, "PASS", "EXACTLY_ONE_FIXTURE_BOUND_REQUEST"),
        ([[{"type": "session.update"}], [request(bound=False)], [request()]], {}, "PASS", "EXACTLY_ONE_FIXTURE_BOUND_REQUEST"),
        ([[request()], [request()]], {}, "FAIL", "INVALID_CAPTURE_AMBIGUOUS_BOUND_REQUEST"),
        ([[request(suffix="A")], [request(suffix="B")]], {}, "FAIL", "INVALID_CAPTURE_AMBIGUOUS_BOUND_REQUEST"),
        ([[request(bound=False)]], {}, "FAIL", "INVALID_CAPTURE_NO_BOUND_REQUEST"),
        ([[{"type": "session.update"}], [request()]], {}, "PASS", "EXACTLY_ONE_FIXTURE_BOUND_REQUEST"),
        ([[{"type": "session.update"}], [request()]], {"provider_outcome": "REJECTED"}, "FAIL", "INVALID_CAPTURE_PROVIDER_CONFLICT"),
        ([[request(bound=False)], [request()]], {}, "PASS", "EXACTLY_ONE_FIXTURE_BOUND_REQUEST"),
        ([[request()]], {"fragmented": {(1, 1)}}, "PASS", "EXACTLY_ONE_FIXTURE_BOUND_REQUEST"),
        ([[request()]], {"mutated": {(1, 1)}}, "FAIL", "INVALID_CAPTURE_INTEGRITY"),
        ([[{"type": "future.unknown"}], [request()]], {}, "FAIL", "INVALID_CAPTURE_CLASSIFIER_FATAL"),
    ],
)
def test_synthetic_matrix(tmp_path: Path, connections, kwargs, expected, reason):
    build_kwargs = {key: kwargs[key] for key in ("fragmented", "mutated") if key in kwargs}
    capture = write_capture(tmp_path, connections, **build_kwargs)
    result = validate_invocation_capture(
        capture, PROMPT, SCHEMA, MODEL,
        provider_outcome=kwargs.get("provider_outcome"),
    )
    assert result["status"] == expected
    assert result["reason"] == reason
    assert result["topology"]["connection_count"] == len(connections)
    assert [row["state"] for row in result["state_events"]][:-1] == [
        "CAPTURE_STARTED",
        "CONNECTIONS_DISCOVERED",
        "LOGICAL_MESSAGES_RECONSTRUCTED",
        "CAPTURE_CLOSED",
        "MESSAGES_AGGREGATED",
        "CLASSIFIER_COMPLETE",
        "CARDINALITY_CHECKED",
    ]


def test_open_capture_lifecycle_fails_closed(tmp_path: Path):
    capture = write_capture(tmp_path, [[request()]], close_connections=False)
    result = validate_invocation_capture(capture, PROMPT, SCHEMA, MODEL)
    assert result["status"] == "FAIL"
    assert result["reason"] == "INVALID_CAPTURE_LIFECYCLE_OPEN"


def test_selection_is_fixture_bound_not_connection_order(tmp_path: Path):
    capture = write_capture(tmp_path, [[request(bound=False)], [request()], [{"type": "session.update"}]])
    result = validate_invocation_capture(capture, PROMPT, SCHEMA, MODEL)
    assert result["status"] == "PASS"
    assert result["selected_request"]["selected_connection_id"] == result["topology"]["connection_ids"][1]
    assert result["classification"]["ordering_used_for_selection"] is False
