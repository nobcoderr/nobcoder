from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "scripts"
    / "run_v013_rc1_immutable_postmortem.py"
)
SPEC = importlib.util.spec_from_file_location("v013_rc1_postmortem", SCRIPT)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class V013RC1ImmutablePostmortemTests(unittest.TestCase):
    def test_all_kill_plain_completion_is_terminal_mapping_defect(self) -> None:
        output = {
            "status": "COMPLETE",
            "candidates": [{"state": "KILL"}, {"state": "KILL"}],
        }
        self.assertEqual(
            MODULE.plain_terminal_diagnosis(output, "COMPLETE"),
            "ALL_CANDIDATES_KILLED_BUT_TERMINAL_MAPPED_COMPLETE",
        )

    def test_nonterminal_plain_candidate_is_not_rewritten(self) -> None:
        output = {"status": "COMPLETE", "candidates": [{"state": "STRONG"}]}
        self.assertEqual(
            MODULE.plain_terminal_diagnosis(output, "COMPLETE"),
            "NONTERMINAL_CANDIDATE_PRESENT",
        )

    def test_six_dimension_slack_detects_structural_shortage(self) -> None:
        envelope = {
            "total_input_tokens": 100,
            "noncached_input_tokens": 50,
            "output_tokens": 30,
            "reasoning_tokens": 20,
            "invocation_slots": 8,
            "wall_time_seconds": 100,
        }
        prefix = {
            "total_input_tokens": 20,
            "noncached_input_tokens": 10,
            "output_tokens": 5,
            "reasoning_tokens": 4,
            "invocation_slots": 2,
        }
        bundle = {
            "total_input_tokens": 70,
            "noncached_input_tokens": 45,
            "output_tokens": 10,
            "reasoning_tokens": 5,
            "invocation_slots": 4,
            "wall_time_seconds": 30,
        }
        slack = MODULE.slack_vector(envelope, prefix, bundle, 25)
        self.assertEqual(slack["noncached_input_tokens"], -5)
        self.assertFalse(MODULE.feasible(slack))

    def test_efficiency_population_excludes_never_invoked_denial(self) -> None:
        self.assertFalse(
            MODULE.reservation_counts_for_efficiency(
                {"state": "DENIED_FINAL", "actual_json": None}
            )
        )
        self.assertTrue(
            MODULE.reservation_counts_for_efficiency(
                {
                    "state": "OVERSHOOT_INVALID",
                    "actual_json": '{"total_input_tokens":101}',
                }
            )
        )

    def test_mixed_decision_prioritizes_eval_then_resource_then_implementation(self) -> None:
        plain = {"eval_terminal_mapping_defects": 9}
        harness = {
            "overshoot_events": [
                {"classification": "OTHER_ROLE_RESERVATION_TAIL"}
            ],
            "terminalization_evidence": [{}] * 13,
        }
        replay = {"structural_feasibility": {"structural_shortage": 0}}
        result = MODULE.decision(plain, harness, replay)
        self.assertEqual(result["decision"], "F_MIXED")
        self.assertEqual(
            result["immediate_next"],
            "NEW_ACCEPTANCE_PROTOCOL_IDENTITY_AND_GRADER_TERMINAL_MAPPING_REPAIR",
        )
        self.assertFalse(result["version_conclusion"]["v0.1.3_rc2_sufficient"])
        self.assertTrue(
            result["version_conclusion"]["v0.1.4_contract_first_required_after_eval_repair"]
        )


if __name__ == "__main__":
    unittest.main()
