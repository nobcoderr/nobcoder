from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import run_v014_acceptance as acceptance  # noqa: E402
from acceptance_grade_v2 import grade  # noqa: E402
from score_v014_acceptance import closure_observability  # noqa: E402


class V014AcceptanceTests(unittest.TestCase):
    def test_schedule_is_balanced_interleaved_and_exactly_once(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        first = acceptance.schedule(protocol, "b" * 64)
        second = acceptance.schedule(protocol, "b" * 64)
        self.assertEqual(first, second)
        self.assertEqual(len(first), 30)
        self.assertEqual([row["position"] for row in first], list(range(1, 31)))
        self.assertEqual(sum(row["system"] == "plain-minimal" for row in first), 15)
        self.assertEqual(sum(row["system"] == "harness-v0.1.4" for row in first), 15)
        for index in range(0, 30, 2):
            self.assertEqual(first[index]["case_id"], first[index + 1]["case_id"])
            self.assertNotEqual(first[index]["system"], first[index + 1]["system"])

    def test_protocol_keeps_frozen_thresholds_and_no_rescue(self) -> None:
        protocol = json.loads(acceptance.PROTOCOL.read_text(encoding="utf-8"))
        gate = protocol["development_e2e"]
        self.assertEqual(gate["minimum_accepted_terminals_per_system"], 12)
        self.assertEqual(protocol["resource_acceptance"]["maximum_requested_to_actual_ratio"], 3.0)
        self.assertEqual(protocol["resource_acceptance"]["maximum_unused_reservation_fraction"], 0.6667)
        self.assertEqual(protocol["post_acceptance_rescue"], "FORBIDDEN_FOR_THIS_IDENTITY")

    def test_plain_all_kill_maps_to_accepted_no_valid_finding(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "telemetry").mkdir()
            (root / "output.json").write_text(json.dumps({
                "status": "COMPLETE",
                "hypotheses": [{"disposition": "KILL"}],
                "candidates": [{"state": "KILL"}],
                "experiments": [{"completed_at": "x"}],
            }))
            (root / "semantic_status.json").write_text(json.dumps({"invalid_infrastructure": False}))
            (root / "manifest.json").write_text(json.dumps({"exit_code": 0, "status": "VALID_COMPLETED"}))
            (root / "resource_compliance.json").write_text(json.dumps({"valid_resource_compliance": True}))
            (root / "token_usage.json").write_text("{}")
            (root / "timing.json").write_text("{}")
            events = [
                {"event_type": "TOOL_COMMAND_COMPLETED", "command": "read /work/target", "exit_code": 0, "monotonic_seconds": 1},
                {"event_type": "BUILD_COMPLETED", "exit_code": 0, "monotonic_seconds": 2},
                {"event_type": "TEST_COMPLETED", "exit_code": 0, "monotonic_seconds": 3},
                {"event_type": "HYPOTHESIS_CREATED", "monotonic_seconds": 4},
            ]
            (root / "telemetry" / "lifecycle.jsonl").write_text("\n".join(json.dumps(row) for row in events) + "\n")
            result = grade(root, "plain-minimal")
        self.assertEqual(result["terminal"], "NO_VALID_FINDING")
        self.assertTrue(result["accepted_completion"])
        self.assertTrue(result["complete_research_episode"])

    def test_missing_database_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            result = closure_observability(Path(temporary))
        self.assertEqual(result["queue_deadlocks"], 1)
        self.assertEqual(result["terminal_state_defects"], 1)
        self.assertEqual(result["evidence_judge_eligible_but_starved"], 1)


if __name__ == "__main__":
    unittest.main()
