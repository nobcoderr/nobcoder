from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_closure_budget_governance_v1.py"
SPEC = importlib.util.spec_from_file_location("closure_budget_governance_v1", MODULE_PATH)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_protocol_preserves_envelope_bundle_and_capacity_v2() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    assert protocol["resource_contract"]["capacity_v2_unchanged"] is True
    assert protocol["resource_contract"]["run_budget_unchanged"] is True
    assert protocol["resource_contract"]["closure_bundle"] == {
        "total_input_tokens": 743000,
        "noncached_input_tokens": 258000,
        "output_tokens": 25000,
        "reasoning_tokens": 15700,
        "invocation_slots": 4,
        "wall_time_seconds": 335,
    }


def test_fit_is_joint_across_six_dimensions() -> None:
    fields = MODULE.CAPACITY_FIELDS
    envelope = {field: 100.0 for field in fields}
    footprint = {field: 20.0 for field in fields}
    bundle = {field: 80.0 for field in fields}
    assert MODULE.fits(footprint, bundle, envelope)
    footprint["wall_time_seconds"] = 21.0
    assert not MODULE.fits(footprint, bundle, envelope)


def test_policy_c_queue_has_exactly_one_active_candidate() -> None:
    paths = [
        {"episode_id": "e1", "path_id": "e1:candidate-01", "candidate_ordinal": 1},
        {"episode_id": "e1", "path_id": "e1:candidate-02", "candidate_ordinal": 2},
        {"episode_id": "e2", "path_id": "e2:candidate-01", "candidate_ordinal": 1},
    ]
    result = MODULE.queue_coverage(paths, True)
    assert result["covered_paths"] == 3
    assert result["maximum_active_closure_candidates"] == 1
    assert all(row["active_count"] == 1 for row in result["transitions"])


def test_policies_a_and_b_do_not_claim_queue_coverage() -> None:
    paths = [{"episode_id": "e1", "path_id": "p1", "candidate_ordinal": 1}]
    result = MODULE.queue_coverage(paths, False)
    assert result["covered_paths"] == 0
    assert result["maximum_active_closure_candidates"] == 0
    assert result["transitions"][0]["queue_status"] == "NOT_IMPLEMENTED"


def test_efficiency_uses_conservative_component_max_without_synthesis() -> None:
    result = MODULE.efficiency_evidence(
        {
            "efficiency": {
                "historical_non_evidence_judge": {
                    "requested_to_actual_ratio": 2.425108,
                    "unused_reservation_fraction": 0.587647,
                },
                "evidence_judge_live_r3": {
                    "requested_to_actual_ratio": 1.4999,
                    "unused_reservation_fraction": 0.3333,
                },
            }
        }
    )
    assert result["requested_to_actual_ratio"] == 2.425108
    assert result["unused_reservation_fraction"] == 0.587647
    assert result["missing_full_bundle_actuals_synthesized"] is False


def test_postmortem_authorizes_governance_but_not_product() -> None:
    protocol = MODULE.load_json(MODULE.PROTOCOL)
    MODULE.verify_inputs(protocol)
    postmortem = MODULE.load_json(
        MODULE.resolve(protocol["frozen_inputs"]["closure_postmortem_v2_result"]["path"])
    )
    assert postmortem["structural_envelope_shortage"] == 0
    assert postmortem["closure_governance_authorized"] is True
    assert postmortem["v0.1.3_implementation_authorized"] is False


def test_preflight_is_offline_and_has_three_policies() -> None:
    value = MODULE.preflight(False)
    assert value["status"] == "PRE_EXECUTION_LOCKED"
    assert value["eligible_path_count"] == 33
    assert value["model_invocations"] == 0
    assert value["policy_ids"] == [
        "ADMISSION_ONLY_ESCROW",
        "GLOBAL_CLOSURE_FLOOR",
        "GLOBAL_FLOOR_PLUS_FANOUT_GOVERNANCE",
    ]


def test_runner_has_no_model_or_network_execution() -> None:
    source = MODULE_PATH.read_text(encoding="utf-8")
    assert "subprocess" not in source
    assert "requests" not in source
    assert "websocket" not in source.lower()

