# Narrow Terminalization Contract Repair V1

Status: **PASS_LOCKED**  
Model invocations: **0**  
Historical V0.1.5 RC1 disposition: **unchanged / no rescore**

## Timing diagnosis

The 13 locked `TERMINALIZATION_OVERRUN` runs separate cleanly into two
quantities:

- trigger delay, last substantive worker terminal to terminalization request:
  P50 **537.0s**, P95 **695.8s**, max
  **721.0s**;
- mechanical terminalization and persistence upper bound: P50
  **2.438968s**, P95 **3.133349s**, max
  **3.182262s**.

The long tail is therefore delayed triggering, not expensive persistence. The
precommitted formula derives a **15s**
terminalization reserve and a deadline trigger at elapsed second
**885**. No 60/90-second manual value
was selected.

## Offline replay

- Harness trajectories: 15/15
- Historical candidates preserved: 41/41
- Quiescence triggers: 13
- Deadline backstop triggers: 1
- Natural non-overrun run preserved: 1
- Nonterminal candidates at finalization: 0
- Queue entries at finalization: 0
- Predicted terminalization overruns: 0
- Plain trajectories changed: 0

## Version decision

**V0.1.6_CONTRACT_FIRST**. The frozen V0.1.5 contract contains quiescence and
post-hard-stop sweep requirements, but it does not define the derived
pre-hard-stop reserve, remaining-wall trigger, monotonic terminalization states,
stop-optional-work transition, duration telemetry, or
`TERMINALIZATION_BUDGET_EXCEEDED` taxonomy. These are new normative product
behavior, so RC2 is insufficient.

Next authorized product step: **IMPLEMENT_V0.1.6_FROM_CLEAN_V0.1.5_RC1_SOURCE_WITH_TERMINALIZATION_ONLY_CHANGE_BOUNDARY**. Live acceptance remains
unauthorized until that successor implementation passes the frozen fixture and
offline-replay gates.
