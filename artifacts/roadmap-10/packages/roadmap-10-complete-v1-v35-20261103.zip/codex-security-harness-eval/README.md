# Codex Security Harness V0.1 Evaluation Lab

This directory proves or falsifies whether the frozen V0.1.0 harness improves
on a single Codex session. It deliberately lives outside the product tree.

The authoritative baseline is the archive whose SHA-256 begins `16e597...`.
Shared Downloads is transport only. The local source-of-truth store is
`baselines/v0.1.0/`; verify it and its separate backup before every evaluation:

```bash
python3 scripts/verify_baseline_store.py
```

The exact archive is currently missing, so verification intentionally fails
closed. Eight matching extracted product trees were preserved under
`baselines/recovery/v0.1.0/`, but that recovery tree is not allowed to replace
the locked ZIP byte stream.

Read `protocol/BENCHMARK_PROTOCOL.md` before curating or running cases. Public
case manifests contain no result labels. The curator truth file must be added
only after all worker runs finish, ideally from a separate machine or removable
location. The scorer never launches agents:

```bash
python3 scripts/score_benchmark.py \
  --cases suite/public/cases.example.json \
  --truth /path/not-visible-to-workers/truth.json \
  --observations /path/to/frozen-observations.json
```

Screen sealed fingerprints before admitting cases to the clean holdout. The
input and report paths must stay curator-only:

```bash
python3 scripts/screen_contamination.py \
  --database /home/nobcoder/.bbp-ai/state/research.db \
  --fingerprints /unmounted-curator/pilot/fingerprints.json \
  --out /unmounted-curator/pilot/contamination-report.json
```

Only aggregate classification counts are printed to the terminal. Full matched
titles, locations, and fingerprint values go exclusively to the sealed report.

The calibrated eight-case worker bundle is under `pilot/`. Validate the public
side without loading curator truth:

```bash
python3 scripts/validate_pilot.py --pilot-root pilot
```

For the sealed preflight, the curator runs the same command with `--truth` and
`--contamination-report` paths from storage that will be unmounted before any
worker starts. Never copy those files into this evaluation directory.

`suite/public/cases.example.json` is a format example, not benchmark evidence.
No V0.2 change is allowed until a blinded main suite satisfies the promotion
gate.

## Pilot V2 plumbing

Pilot V1 is invalid for claims and `CASE-001` through `CASE-008` are permanently
development-only. Run the synthetic environment preflight and readiness gate:

```bash
python3 scripts/run_infrastructure_preflight.py --id <unique-id>
python3 scripts/check_pilot_v2_gate.py
```

The first command must pass all eight fixtures for both system labels. The
second command remains `BLOCKED` until the exact baseline plus backup and a
fresh curator-attested holdout exist. `scripts/run_pilot_v2.py prepare` refuses
to create a schedule before the pre-schedule gate passes, and `run-next`
refuses execution until that schedule is sealed and the final gate passes.
