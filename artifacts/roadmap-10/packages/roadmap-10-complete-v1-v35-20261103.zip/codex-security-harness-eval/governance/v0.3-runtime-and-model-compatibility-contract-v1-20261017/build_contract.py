#!/usr/bin/env python3
"""Build the static V0.3 runtime/model compatibility contract.

Only frozen local records are read.  No runtime, model, suite, worker,
credential, target, network, exploit, or parallel operation is performed.
"""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance"
AUTH = GOV / "v0.3-runtime-and-model-compatibility-contract-v1-publication-authorization-governance-v1-20261017"
V5 = GOV / "v0.3-runtime-substrate-validation-v5-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261017"
SUBSTRATE = GOV / "v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016"
REPO = BASE / "codex-security-harness"
CODEX_LOCK = REPO / "toolchain/codex.lock.json"
CODEX_ADAPTER = REPO / "src/bbp_harness/adapters/codex_cli/runtime.py"
ROUTER = BASE / "skill/config/AUTO_ROUTING_MAP.json"

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1"
MILESTONE = "ESTABLISH_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1"

ANCHORS = {
    "auth_lock": "6f0527943c04ad3d6dd5cfe757747e1fe8af77c4f9a7f593bf1adac8fb1640eb",
    "auth_manifest": "4efa0e2b23c809fd4908dac672c84e796afcb2fd3f5262d5e1b1d7badac6131b",
    "auth_root": "4187bdefd929f7762f6b0d39d331ff6e4b4ef1e488f0b7ddf59dc20a67651a47",
    "publication_auth": "c432e1bfa8f6ac49534a790b399a614566f870972e8c0df14f0ecb7273fb208d",
    "v5_lock": "8383ec457c0838fba668693ae9c837edf1a8c50222c524176dc60b9afda9191e",
    "v5_pass": "6fcc774d25ecb8fc57e04eda8d33c509622e65a6540e9c5e61d819727c94ba17",
    "substrate_lock": "77cc5e94b5b578f8a4bf828cb77de24df69b4d231804f7727a073144960034a7",
    "codex_lock": "22e19a11e64d32275301fa484a0fe996c7e007aad7999c387b81b60490b481da",
    "codex_adapter": "ae9f577b96bb1e8420e35acbed033fa19f484eff2225591a8d8f121156b30c30",
    "router": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
}

LIFECYCLE = [
    "DISCOVERED",
    "IDENTITY_PINNED",
    "COMPATIBILITY_CONTRACTED",
    "COMPATIBILITY_EXECUTION_AUTHORIZED",
    "COMPATIBILITY_TESTED",
    "PASS_LOCKED",
    "WORKER_EXECUTION_ELIGIBLE",
]

REQUIRED_SECTIONS = [
    "RuntimeIdentity", "RuntimeAdapterIdentity", "VersionPin",
    "BinaryDigestOrModelIdentity", "ConfigurationIdentity",
    "RuntimeCapabilities", "StructuredInputContract",
    "StructuredOutputContract", "ToolingContract", "SandboxExpectation",
    "FailureSemantics", "EvidenceContract", "CompatibilitySuiteDefinition",
    "AuthorityState", "UpgradeOrSuccessorSemantics",
]

FALSE_AUTHORITY_FIELDS = [
    "contract_execution_authorized", "compatibility_execution_authorized",
    "compatibility_suite_execution_authorized", "runtime_invocation_authorized",
    "codex_cli_invocation_authorized", "daybreak_invocation_authorized",
    "future_runtime_invocation_authorized", "worker_execution_authorized",
    "subagent_execution_authorized", "credential_use_authorized",
    "target_access_authorized", "external_network_authorized",
    "exploit_replay_authorized", "parallelism_authorized",
    "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized",
]

OPERATION_KEYS = [
    "compatibility_suite_executions", "runtime_invocations",
    "codex_cli_invocations", "daybreak_invocations", "future_runtime_invocations",
    "worker_processes", "subagent_processes", "credential_operations",
    "target_operations", "external_network_operations", "exploit_replays",
    "parallel_operations", "capability_edges", "candidate_promotions",
    "submission_operations",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda item: str(item["path"]))).encode()
    return hashlib.sha256(raw).hexdigest()


def verify_governance(root: Path, expected_root: str) -> bool:
    manifest_path = root / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest = load(manifest_path)
    lock = load(root / "GOVERNANCE_LOCK.json")
    members = manifest.get("members", [])
    if not root.is_dir() or root.is_symlink() or not ro(root) or not members:
        return False
    for row in members:
        path = root / str(row.get("path", ""))
        if not path.is_file() or path.is_symlink() or not ro(path):
            return False
        if path.stat().st_size != row.get("bytes") or sha(path) != row.get("sha256"):
            return False
    manifest_sha = sha(manifest_path)
    artifact_rows = members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}]
    return (
        rows_root(members) == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256")
        and manifest_sha == lock.get("governance_manifest_sha256")
        and rows_root(artifact_rows) == expected_root == lock.get("canonical_artifact_root_sha256")
    )


def zeros() -> dict[str, int]:
    return {key: 0 for key in OPERATION_KEYS}


def write_once(name: str, value: object) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def strict_schema(schema_id: str, title: str, required: list[str], properties: dict[str, Any]) -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": f"urn:nobcoder:{schema_id}:v1", "title": title,
        "type": "object", "additionalProperties": False,
        "required": required, "properties": properties,
    }


def main() -> None:
    expected_root = GOV / "v0.3-runtime-and-model-compatibility-contract-v1-20261017"
    if ROOT != expected_root or ROOT.is_symlink():
        raise SystemExit("wrong or symlinked contract path")
    if any(ROOT.glob("*.json")):
        raise SystemExit("contract JSON collision")
    expected_hashes = {
        AUTH / "GOVERNANCE_LOCK.json": ANCHORS["auth_lock"],
        AUTH / "GOVERNANCE_ARTIFACT_MANIFEST.json": ANCHORS["auth_manifest"],
        AUTH / "CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json": ANCHORS["publication_auth"],
        V5 / "GOVERNANCE_LOCK.json": ANCHORS["v5_lock"],
        V5 / "RUNTIME_SUBSTRATE_V5_PASS_LOCKED.json": ANCHORS["v5_pass"],
        SUBSTRATE / "GOVERNANCE_LOCK.json": ANCHORS["substrate_lock"],
        CODEX_LOCK: ANCHORS["codex_lock"], CODEX_ADAPTER: ANCHORS["codex_adapter"],
        ROUTER: ANCHORS["router"],
    }
    for path, digest in expected_hashes.items():
        if sha(path) != digest:
            raise SystemExit(f"anchor mismatch: {path}")
    if not verify_governance(AUTH, ANCHORS["auth_root"]):
        raise SystemExit("authorization governance integrity failure")
    auth = load(AUTH / "CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json")
    if auth.get("status") != "PASS_LOCKED_GOVERNANCE_ONLY" or auth.get("decision") != "AUTHORIZE_FUTURE_CONTRACT_PUBLICATION_ONLY":
        raise SystemExit("publication authorization unavailable")
    if auth.get("future_contract_identity") != IDENTITY or Path(str(auth.get("future_contract_path"))) != ROOT:
        raise SystemExit("contract identity/path authorization mismatch")
    if auth.get("contract_publication_authorized") is not True or any(auth.get(key) is not False for key in FALSE_AUTHORITY_FIELDS):
        raise SystemExit("authorization ceiling mismatch")

    codex = load(CODEX_LOCK)
    v5_pass = load(V5 / "RUNTIME_SUBSTRATE_V5_PASS_LOCKED.json")
    router = load(ROUTER)
    if codex.get("version") != "0.162.1" or codex.get("compatibility_state") != "CANDIDATE_ONLY_NOT_VALIDATED" or codex.get("runtime_invocation_authorized") is not False:
        raise SystemExit("Codex candidate state mismatch")
    if v5_pass.get("status") != "PASS_LOCKED":
        raise SystemExit("runtime substrate not PASS_LOCKED")

    main_contract = {
        "record_type": "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT",
        "schema_version": "1.0", "identity": IDENTITY, "milestone": MILESTONE,
        "status": "STATIC_CONTRACT_CANDIDATE",
        "purpose": "VERSION_PINNED_PROVIDER_NEUTRAL_RUNTIME_COMPATIBILITY_LIFECYCLE",
        "default_policy": "DENY", "required_sections": REQUIRED_SECTIONS,
        "canonical_lifecycle": LIFECYCLE,
        "pre_discovery_state": "NOT_DISCOVERED",
        "contract_pass_effect": "CONTRACT_ONLY_NO_COMPATIBILITY_EXECUTION_OR_RUNTIME_AUTHORITY",
        "unknown_identity_capability_configuration_or_evidence": "FAIL_CLOSED",
    }
    lifecycle = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_LIFECYCLE_CONTRACT",
        "schema_version": "1.0", "contract_identity": IDENTITY,
        "pre_lifecycle_states": ["NOT_DISCOVERED"],
        "ordered_acceptance_states": LIFECYCLE,
        "transition_requirements": {
            "NOT_DISCOVERED_TO_DISCOVERED": ["EXPLICIT_LOCAL_DISCOVERY_EVIDENCE", "NO_AVAILABILITY_INFERENCE"],
            "DISCOVERED_TO_IDENTITY_PINNED": ["EXACT_SOURCE_OR_PROVIDER_IDENTITY", "VERSION_OR_MODEL_IDENTITY", "CONFIGURATION_IDENTITY", "INTEGRITY_EVIDENCE"],
            "IDENTITY_PINNED_TO_COMPATIBILITY_CONTRACTED": ["ADAPTER_AND_STRUCTURED_IO_BOUND", "SUITE_DEFINITION_BOUND", "AUTHORITY_STATE_BOUND"],
            "COMPATIBILITY_CONTRACTED_TO_COMPATIBILITY_EXECUTION_AUTHORIZED": ["SEPARATE_PASS_LOCKED_GOVERNANCE_AUTHORIZATION"],
            "COMPATIBILITY_EXECUTION_AUTHORIZED_TO_COMPATIBILITY_TESTED": ["AUTHORIZED_SUITE_EXECUTED_ONCE_OR_AS_EXPLICITLY_BOUND", "COMPLETE_EVIDENCE"],
            "COMPATIBILITY_TESTED_TO_PASS_LOCKED": ["PRIMARY_AND_INDEPENDENT_ACCEPTANCE", "FROZEN_EVIDENCE", "NO_MANDATORY_FAILURE"],
            "PASS_LOCKED_TO_WORKER_EXECUTION_ELIGIBLE": ["SEPARATE_ELIGIBILITY_DECISION", "NO_WORKER_AUTHORITY_IMPLIED"],
        },
        "skip_or_reverse_transition": "PROHIBITED",
        "terminal_failure": "FRESH_SUCCESSOR_IDENTITY_REQUIRED_UNLESS_EXPLICIT_CONTRACT_SAYS_UNCONSUMED",
    }
    provider_state = {
        "record_type": "V0_3_RUNTIME_PROVIDER_STATE_MODEL",
        "schema_version": "1.0", "contract_identity": IDENTITY,
        "allowed_discovery_states": ["NOT_DISCOVERED", "DISCOVERED", "IDENTITY_PINNED"],
        "availability_claim_requires_evidence": True,
        "adapter_name_does_not_prove_provider_availability": True,
        "model_name_endpoint_capabilities_and_access_must_be_independently_bound": True,
        "unknown_provider_fields": "FAIL_CLOSED",
    }
    runtime_identity = {
        "record_type": "V0_3_RUNTIME_IDENTITY_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "required_fields": ["runtime_id", "provider", "discovery_state", "identity_state", "version", "binary_digest", "model_identity", "configuration_identity", "source_provenance", "availability_claim", "authoritative", "invocation_authorized", "invocation_count"],
        "identity_match_is_not_compatibility": True,
        "compatibility_is_not_execution_authority": True,
        "missing_or_mismatched_identity": "FAIL_CLOSED",
    }
    adapter_identity = {
        "record_type": "V0_3_RUNTIME_ADAPTER_IDENTITY_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY, "abstract_interface": "SecurityWorkerRuntime",
        "adapter_types": ["CodexCliRuntime", "DaybreakRuntime", "FutureRuntimeAdapter"],
        "adapter_type_is_not_availability_claim": True,
        "required_bindings": ["adapter_id", "implementation_identity", "source_digest", "runtime_identity", "structured_io_version", "sandbox_expectation", "tooling_contract", "failure_semantics", "evidence_contract"],
        "generic_command_or_code_endpoint": "PROHIBITED",
        "provider_specific_argv_in_core": "PROHIBITED",
    }
    version_pin = {
        "record_type": "V0_3_VERSION_BINARY_MODEL_PIN_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "binary_runtime_requirements": ["EXACT_VERSION", "EXACT_BINARY_SHA256", "EXACT_INSTALLATION_METHOD", "EXACT_TARGET_PLATFORM", "EXACT_PACKAGE_METADATA", "EXACT_CONFIGURATION_SHA256"],
        "model_runtime_requirements": ["EXACT_PROVIDER", "EXACT_MODEL_IDENTITY", "EXACT_ENDPOINT_CLASS", "EXACT_PROJECT_OR_ACCESS_PROGRAM_WHERE_APPLICABLE", "EXACT_CONFIGURATION_IDENTITY", "DATED_AVAILABILITY_EVIDENCE"],
        "moving_alias_or_latest": "PROHIBITED",
        "identity_drift": "FAIL_CLOSED_REQUIRES_SUCCESSOR",
        "binary_digest_or_model_identity_alone_is_sufficient": False,
    }
    configuration = {
        "record_type": "V0_3_CONFIGURATION_IDENTITY_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "required": ["configuration_path_or_provider_configuration_id", "sha256_or_provider_revision", "required_settings", "observed_setting_status", "environment_allowlist_digest", "working_directory_binding", "sandbox_policy_binding", "approval_policy_binding", "network_policy_binding", "tool_policy_binding"],
        "secret_values_in_contract_or_evidence": "PROHIBITED",
        "missing_required_setting": "NOT_COMPATIBLE_FAIL_CLOSED",
        "configuration_drift": "INVALIDATE_IDENTITY_AND_REQUIRE_SUCCESSOR_OR_REVALIDATION",
    }
    capabilities = {
        "record_type": "V0_3_RUNTIME_CAPABILITIES_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "capability_states": ["UNCLAIMED", "UPSTREAM_CLAIM", "IDENTITY_SUPPORTED", "COMPATIBILITY_TESTED", "PASS_LOCKED"],
        "capabilities": ["source_analysis", "structured_output", "tool_request_generation", "tool_execution", "long_context", "interruption", "timeout", "sandbox_integration", "authorized_red_team_mode"],
        "default_state": "UNCLAIMED", "upstream_claim_is_compatibility_evidence": False,
        "capability_requires_case_specific_evidence": True,
        "unknown_capability": "FAIL_CLOSED_NOT_AVAILABLE",
    }
    structured_io = {
        "record_type": "V0_3_STRUCTURED_INPUT_OUTPUT_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY, "io_version": "V1",
        "input_required_fields": ["request_id", "authorization_id", "runtime_identity", "adapter_identity", "task_class", "immutable_inputs", "scope", "allowed_tools", "resource_limits", "output_schema_digest", "abort_conditions"],
        "output_required_fields": ["request_id", "runtime_identity", "adapter_identity", "status", "structured_result", "tool_requests", "evidence_refs", "resource_usage", "termination_reason", "errors"],
        "free_form_prose_authoritative": False,
        "unknown_input_or_output_field": "REJECT",
        "schema_or_request_identity_mismatch": "FAIL_CLOSED",
        "model_output_can_grant_authority": False,
    }
    tooling = {
        "record_type": "V0_3_RUNTIME_TOOLING_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "default": "NO_TOOLS", "typed_requests_only": True,
        "generic_shell_python_code_raw_args_or_package_install": "PROHIBITED",
        "tool_identity_version_parameters_target_and_authorization_required": True,
        "parent_and_child_authority_recheck": "REQUIRED_IMMEDIATELY_BEFORE_CALL",
        "credential_or_network_tooling": "REQUIRES_SEPARATE_EXACT_AUTHORIZATION",
        "tool_output_state": "HYPOTHESIS_OR_EVIDENCE_NEVER_SELF_PROMOTION",
    }
    sandbox = {
        "record_type": "V0_3_RUNTIME_SANDBOX_EXPECTATION_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "substrate_identity": "RUNTIME_SUBSTRATE_V5_PASS_LOCKED",
        "substrate_lock_sha256": ANCHORS["v5_pass"],
        "requirements": ["EXACT_FILESYSTEM_TOPOLOGY", "EXACT_WRITABLE_SCOPE", "DENY_BY_DEFAULT_NETWORK", "EXACT_ENVIRONMENT", "EXACT_CWD", "EXACT_PROCESS_LINEAGE", "NO_HOST_SECRET_INHERITANCE", "OUT_OF_WORKER_MONITORING", "TRACE_COMPLETENESS", "FAIL_CLOSED_NO_UNSANDBOXED_FALLBACK"],
        "runtime_or_adapter_cannot_weaken_substrate": True,
        "topology_or_identity_drift": "STOP_BEFORE_OR_DURING_EXECUTION",
    }
    failure = {
        "record_type": "V0_3_RUNTIME_COMPATIBILITY_FAILURE_SEMANTICS", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "terminal_conditions": ["IDENTITY_MISMATCH", "CONFIGURATION_MISMATCH", "UNKNOWN_CAPABILITY", "SCHEMA_DIVERGENCE", "UNEXPECTED_TOOL_REQUEST", "SANDBOX_DRIFT", "NETWORK_OR_CREDENTIAL_REQUEST", "TRACE_OR_EVIDENCE_GAP", "TIMEOUT_WITHOUT_COMPLETE_EVIDENCE", "INTERRUPTION_AMBIGUITY", "VALIDATOR_DISAGREEMENT"],
        "mandatory_failure_result": "FAIL_CLOSED",
        "missing_evidence_result": "BLOCKED_NO_PASS",
        "automatic_retry": "PROHIBITED",
        "patch_relock_or_reclassify_consumed_identity": "PROHIBITED",
        "fresh_successor_required_after_consumed_terminal_failure": True,
    }
    evidence = {
        "record_type": "V0_3_RUNTIME_COMPATIBILITY_EVIDENCE_CONTRACT", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "required_bindings": ["authorization_id", "runtime_identity", "adapter_identity", "version_or_model_identity", "binary_or_provider_identity", "configuration_identity", "suite_definition_digest", "exact_input_digest", "exact_argv_or_request_digest", "environment_digest", "sandbox_identity", "start_state", "end_state", "exit_or_terminal_status", "stdout_stderr_or_structured_equivalent", "tool_request_ledger", "filesystem_network_process_effects", "timestamps", "validator_identity", "evidence_manifest"],
        "append_only": True, "digest_bound": True, "provenance_bound": True,
        "authorization_bound": True, "producer_bound": True,
        "redaction_must_preserve_verifiability": True,
        "secret_material_in_evidence": "PROHIBITED",
        "incomplete_evidence": "NO_PASS",
    }
    suite_cases = [
        ("C001_RUNTIME_IDENTITY", "exact runtime/version/model identity and integrity"),
        ("C002_CONFIGURATION", "configuration parses and exact required settings match"),
        ("C003_INSTRUCTION_CONTEXT", "workspace instruction discovery is deterministic and bounded"),
        ("C004_WORKING_DIRECTORY", "working directory is exact and canonical"),
        ("C005_ENVIRONMENT", "environment is normalized and allowlisted"),
        ("C006_SANDBOX", "runtime cannot weaken the pinned substrate"),
        ("C007_APPROVAL_POLICY", "approval behavior matches exact contract"),
        ("C008_NETWORK_DENIAL", "external network remains denied unless separately authorized"),
        ("C009_FILESYSTEM_BOUNDARY", "writes remain inside exact allowed scope"),
        ("C010_EXECUTION_SEMANTICS", "request-to-process or provider-call semantics are exact"),
        ("C011_STRUCTURED_OUTPUT", "output validates against locked schema"),
        ("C012_EXIT_STATUS", "exit and terminal status semantics are deterministic"),
        ("C013_TIMEOUT", "timeout terminates complete lineage and preserves evidence"),
        ("C014_INTERRUPTION", "interruption is distinguishable and fail-closed"),
        ("C015_TOOL_OR_MCP_POLICY", "tool/MCP exposure is deny-by-default and exact"),
        ("C016_SUBAGENT_DENIAL", "subagent creation is denied when not separately authorized"),
        ("C017_EVIDENCE_CAPTURE", "complete append-only evidence is emitted"),
        ("C018_EXACT_REQUEST_OR_ARGV", "exact request or argv serialization is digest-bound"),
    ]
    suite = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_SUITE_DEFINITION", "schema_version": "1.0",
        "contract_identity": IDENTITY, "suite_identity": "V0_3_RUNTIME_MODEL_COMPATIBILITY_SUITE_V1_DEFINITION_ONLY",
        "status": "DEFINED_NOT_AUTHORIZED_NOT_EXECUTED",
        "cases": [{"case_id": case_id, "question": question, "expected": "PASS", "evidence_required": True, "missing_or_disagreement": "FAIL_CLOSED_OR_BLOCKED_NO_PASS"} for case_id, question in suite_cases],
        "case_count": len(suite_cases), "all_mandatory": True,
        "execution_requires_separate_governance": True,
        "runtime_specific_profile_required": True,
        "no_shared_attempt_between_distinct_runtime_identities": True,
    }
    authority = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_AUTHORITY_STATE", "schema_version": "1.0",
        "contract_identity": IDENTITY, "contract_publication_authorized": True,
        **{key: False for key in FALSE_AUTHORITY_FIELDS},
        "operation_counters": zeros(),
        "structural_counts": {"contract_publication_event_count": 1, "suite_definition_case_count": 18},
        "authority_default": "DENY", "unknown_authority_field": "FAIL_CLOSED",
        "contract_pass_is_not_compatibility_pass": True,
        "compatibility_pass_is_not_worker_execution_authority": True,
    }
    upgrade = {
        "record_type": "V0_3_RUNTIME_MODEL_UPGRADE_AND_SUCCESSOR_SEMANTICS", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "current_authoritative_runtime": "NONE",
        "new_version_or_model_state": "CANDIDATE_ONLY",
        "automatic_update": "PROHIBITED",
        "candidate_may_replace_pass_locked_runtime_without_tests": False,
        "required_successor_steps": ["DISCOVER", "PIN_IDENTITY", "BIND_CONFIGURATION_AND_ADAPTER", "SEPARATE_COMPATIBILITY_EXECUTION_AUTHORIZATION", "RUN_LOCKED_SUITE", "INDEPENDENT_ACCEPTANCE", "FREEZE", "PROMOTION_GOVERNANCE"],
        "failed_or_consumed_identity": "TERMINAL_REFERENCE_ONLY_NO_PATCH_RELOCK_OR_RETRY_UNLESS_EXPLICITLY_AUTHORIZED",
        "rollback": "RETURN_TO_SEPARATELY_PASS_LOCKED_RUNTIME_ONLY",
    }
    codex_binding = {
        "record_type": "V0_3_CODEX_CLI_0_162_1_CANDIDATE_BINDING", "schema_version": "1.0",
        "contract_identity": IDENTITY, "runtime_id": codex["identity"],
        "runtime": "codex-cli", "version": "0.162.1", "target": codex["target"],
        "candidate_record_sha256": ANCHORS["codex_lock"],
        "declared_binary_sha256": codex["binary"]["sha256"],
        "declared_configuration_sha256": codex["configuration"]["sha256"],
        "adapter_source_sha256": ANCHORS["codex_adapter"],
        "discovery_state": "IDENTITY_PINNED_CANDIDATE_RECORD_ONLY",
        "status": "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED",
        "compatibility_state": "CANDIDATE_ONLY_NOT_VALIDATED",
        "configuration_compliance": "ABSENT_NOT_COMPLIANT",
        "binary_reverification_this_milestone": "NOT_PERFORMED_NO_BINARY_ACCESS_REQUIRED",
        "invocation_count": 0, "invocation_authorized": False,
        "compatibility_suite_executed": False, "authoritative_runtime": False,
    }
    daybreak = {
        "record_type": "V0_3_DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "daybreak": {"discovery_state": "NOT_DISCOVERED", "availability": "NOT_ASSUMED", "access": "NOT_ASSUMED", "provider": "UNBOUND", "model_identity": "UNBOUND", "endpoint": "UNBOUND", "capabilities": "UNVERIFIED", "compatibility": "NOT_ESTABLISHED", "invocation_count": 0, "invocation_authorized": False},
        "future_runtime": {"discovery_state": "NOT_DISCOVERED", "availability": "NOT_ASSUMED", "provider": "UNBOUND", "identity": "UNBOUND", "capabilities": "UNVERIFIED", "compatibility": "NOT_ESTABLISHED", "invocation_count": 0, "invocation_authorized": False},
        "adapter_contract_presence_is_availability_evidence": False,
    }
    predecessor = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_PREDECESSOR_AUTHORIZATION_BINDING", "schema_version": "1.0",
        "contract_identity": IDENTITY,
        "publication_authorization": {"path": str(AUTH), "governance_lock_sha256": ANCHORS["auth_lock"], "governance_manifest_sha256": ANCHORS["auth_manifest"], "canonical_artifact_root_sha256": ANCHORS["auth_root"], "publication_authorization_lock_sha256": ANCHORS["publication_auth"], "status": "PASS_LOCKED_GOVERNANCE_ONLY"},
        "runtime_substrate_v5": {"path": str(V5), "governance_lock_sha256": ANCHORS["v5_lock"], "pass_lock_sha256": ANCHORS["v5_pass"], "status": "PASS_LOCKED"},
        "substrate_contract": {"path": str(SUBSTRATE), "governance_lock_sha256": ANCHORS["substrate_lock"], "status": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY"},
        "predecessor_mutation": "PROHIBITED",
    }
    routes = sorted(str(name) for name in router.get("skill_routes", {}))
    always = set(str(name) for name in router.get("always_active_skills", []))
    active = {"agentic-security-research-harness", "external-ai-security-tool-governor"}
    routing = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_ROUTING_AND_SCOPE_DECISION", "schema_version": "1.0",
        "contract_identity": IDENTITY, "router_sha256": ANCHORS["router"],
        "active_skills": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness", "external-ai-security-tool-governor"],
        "route_ledger": [{"route": route, "state": "ACTIVE_POLICY_LAYER_NO_OPERATIONAL_AUTHORITY" if route in always else "ACTIVE_CONTRACT_DESIGN_ONLY" if route in active else "NOT_APPLICABLE_OR_DEFERRED_NO_RUNTIME_NO_TARGET"} for route in routes],
        "scope": "STATIC_CONTRACT_PUBLICATION_ONLY", "subagents": "NOT_USED",
        "network": "NOT_USED", "runtime_or_model_invocations": 0,
    }

    string = {"type": "string", "minLength": 1}
    nullable_string = {"type": ["string", "null"]}
    boolean = {"type": "boolean"}
    integer = {"type": "integer", "minimum": 0}
    runtime_identity_schema = strict_schema("runtime-identity", "Runtime Identity", ["runtime_id", "provider", "discovery_state", "identity_state", "version", "binary_digest", "model_identity", "configuration_identity", "source_provenance", "availability_claim", "authoritative", "invocation_authorized", "invocation_count"], {
        "runtime_id": string, "provider": string, "discovery_state": {"enum": ["NOT_DISCOVERED", "DISCOVERED", "IDENTITY_PINNED"]}, "identity_state": string,
        "version": nullable_string, "binary_digest": nullable_string, "model_identity": nullable_string, "configuration_identity": nullable_string,
        "source_provenance": string, "availability_claim": {"enum": ["NOT_ASSUMED", "EVIDENCE_BOUND"]}, "authoritative": boolean,
        "invocation_authorized": boolean, "invocation_count": integer,
    })
    adapter_schema = strict_schema("runtime-adapter-identity", "Runtime Adapter Identity", ["adapter_id", "interface", "implementation_identity", "source_digest", "runtime_identity", "structured_io_version", "sandbox_expectation", "tooling_contract", "failure_semantics", "evidence_contract", "generic_command_endpoint"], {
        "adapter_id": string, "interface": {"const": "SecurityWorkerRuntime"}, "implementation_identity": string, "source_digest": string,
        "runtime_identity": string, "structured_io_version": {"const": "V1"}, "sandbox_expectation": string, "tooling_contract": string,
        "failure_semantics": string, "evidence_contract": string, "generic_command_endpoint": {"const": False},
    })
    input_schema = strict_schema("runtime-structured-input", "Runtime Structured Input", structured_io["input_required_fields"], {key: string if key not in {"immutable_inputs", "scope", "allowed_tools", "resource_limits", "abort_conditions"} else {"type": ["object", "array"]} for key in structured_io["input_required_fields"]})
    output_schema = strict_schema("runtime-structured-output", "Runtime Structured Output", structured_io["output_required_fields"], {key: string if key in {"request_id", "runtime_identity", "adapter_identity", "status", "termination_reason"} else {"type": ["object", "array", "null"]} for key in structured_io["output_required_fields"]})
    case_schema = strict_schema("compatibility-case", "Compatibility Case", ["case_id", "question", "expected", "evidence_required", "missing_or_disagreement"], {"case_id": string, "question": string, "expected": {"const": "PASS"}, "evidence_required": {"const": True}, "missing_or_disagreement": {"enum": ["FAIL_CLOSED_OR_BLOCKED_NO_PASS"]}})
    authority_properties = {"contract_identity": string, "contract_publication_authorized": {"const": True}, **{key: {"const": False} for key in FALSE_AUTHORITY_FIELDS}, "operation_counters": {"type": "object", "additionalProperties": False, "required": OPERATION_KEYS, "properties": {key: {"const": 0} for key in OPERATION_KEYS}}, "structural_counts": {"type": "object"}, "authority_default": {"const": "DENY"}, "unknown_authority_field": {"const": "FAIL_CLOSED"}, "contract_pass_is_not_compatibility_pass": {"const": True}, "compatibility_pass_is_not_worker_execution_authority": {"const": True}}
    authority_schema = strict_schema("runtime-authority-state", "Runtime Authority State", list(authority_properties), authority_properties)

    negative_tests = [
        ("N001_MISSING_RUNTIME_ID", "runtime identity missing"),
        ("N002_MOVING_VERSION", "latest or moving version alias"),
        ("N003_MISSING_BINARY_OR_MODEL_IDENTITY", "neither binary digest nor model identity bound"),
        ("N004_MISSING_CONFIGURATION_IDENTITY", "configuration identity absent"),
        ("N005_CONFIGURATION_DRIFT", "configuration differs after pin"),
        ("N006_DAYBREAK_AVAILABILITY_ASSUMED", "provider availability inferred from adapter name"),
        ("N007_DAYBREAK_MODEL_INVENTED", "unverified model identity populated"),
        ("N008_CAPABILITY_FROM_MARKETING", "upstream claim promoted to tested capability"),
        ("N009_LIFECYCLE_SKIP", "COMPATIBILITY_CONTRACTED directly to COMPATIBILITY_TESTED"),
        ("N010_LIFECYCLE_REORDER", "canonical lifecycle reordered"),
        ("N011_CONTRACT_PASS_IMPLIES_SUITE_AUTH", "contract PASS grants suite execution"),
        ("N012_COMPAT_PASS_IMPLIES_WORKER_AUTH", "compatibility PASS grants worker execution"),
        ("N013_FREE_FORM_INPUT", "unstructured request becomes authoritative"),
        ("N014_FREE_FORM_OUTPUT", "model prose becomes authoritative state"),
        ("N015_UNKNOWN_INPUT_FIELD", "unknown structured input field"),
        ("N016_UNKNOWN_OUTPUT_FIELD", "unknown structured output field"),
        ("N017_GENERIC_SHELL", "generic shell endpoint enabled"),
        ("N018_ARBITRARY_CODE", "arbitrary code endpoint enabled"),
        ("N019_RAW_ADDITIONAL_ARGS", "raw untyped runtime args accepted"),
        ("N020_PACKAGE_INSTALL", "runtime self-installs dependency"),
        ("N021_AUTOMATIC_UPDATE", "candidate automatically tracks latest"),
        ("N022_SANDBOX_WEAKENING", "adapter weakens PASS_LOCKED substrate"),
        ("N023_UNSANDBOXED_FALLBACK", "runtime fallback bypasses sandbox"),
        ("N024_SECRET_IN_CONTEXT", "secret enters prompt or evidence"),
        ("N025_CREDENTIAL_USE", "credential use implied by compatibility"),
        ("N026_TARGET_ACCESS", "target access implied by compatibility"),
        ("N027_EXTERNAL_NETWORK", "external network implied by compatibility"),
        ("N028_EXPLOIT_REPLAY", "exploit replay implied by compatibility"),
        ("N029_SUBAGENT", "subagent execution implied by compatibility"),
        ("N030_PARALLELISM", "parallelism implied by compatibility"),
        ("N031_CAPABILITY_EDGE", "capability graph mutation implied"),
        ("N032_CANDIDATE_PROMOTION", "runtime output self-promotes candidate"),
        ("N033_SUBMISSION", "runtime submits external report"),
        ("N034_RETRY_AFTER_TERMINAL", "automatic retry after consumed terminal failure"),
        ("N035_EVIDENCE_INCOMPLETE_PASS", "missing evidence accepted"),
        ("N036_VALIDATOR_DISAGREEMENT_PASS", "validator disagreement accepted"),
        ("N037_SCHEMA_DIGEST_MISMATCH", "request schema digest differs"),
        ("N038_RUNTIME_IDENTITY_MISMATCH", "result identity differs from request"),
        ("N039_TOOL_REQUEST_OUTSIDE_ALLOWLIST", "unknown tool requested"),
        ("N040_EXTERNAL_REFERENCE_AUTHORITY", "README or external prompt grants authority"),
    ]
    negative_matrix = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_NEGATIVE_CONTRACT_FIXTURE_MATRIX", "schema_version": "1.0",
        "contract_identity": IDENTITY, "status": "DEFINED_INERT_NOT_EXECUTED_AS_RUNTIME",
        "fixtures": [{"fixture_id": fixture_id, "condition": condition, "expected": "REJECT_OR_FAIL_CLOSED"} for fixture_id, condition in negative_tests],
        "fixture_count": len(negative_tests),
    }

    artifacts = {
        "RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT.json": main_contract,
        "COMPATIBILITY_LIFECYCLE_CONTRACT.json": lifecycle,
        "PROVIDER_STATE_MODEL.json": provider_state,
        "RUNTIME_IDENTITY_CONTRACT.json": runtime_identity,
        "RUNTIME_ADAPTER_IDENTITY_CONTRACT.json": adapter_identity,
        "VERSION_BINARY_MODEL_PIN_CONTRACT.json": version_pin,
        "CONFIGURATION_IDENTITY_CONTRACT.json": configuration,
        "RUNTIME_CAPABILITIES_CONTRACT.json": capabilities,
        "STRUCTURED_IO_CONTRACT.json": structured_io,
        "TOOLING_CONTRACT.json": tooling,
        "SANDBOX_EXPECTATION_CONTRACT.json": sandbox,
        "FAILURE_SEMANTICS.json": failure,
        "EVIDENCE_CONTRACT.json": evidence,
        "COMPATIBILITY_SUITE_DEFINITION.json": suite,
        "AUTHORITY_STATE.json": authority,
        "UPGRADE_AND_SUCCESSOR_SEMANTICS.json": upgrade,
        "CODEX_CLI_0_162_1_CANDIDATE_BINDING.json": codex_binding,
        "DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json": daybreak,
        "PREDECESSOR_AUTHORIZATION_BINDING.json": predecessor,
        "ROUTING_AND_SCOPE_DECISION.json": routing,
        "RUNTIME_IDENTITY.schema.json": runtime_identity_schema,
        "RUNTIME_ADAPTER_IDENTITY.schema.json": adapter_schema,
        "STRUCTURED_INPUT.schema.json": input_schema,
        "STRUCTURED_OUTPUT.schema.json": output_schema,
        "COMPATIBILITY_CASE.schema.json": case_schema,
        "AUTHORITY_STATE.schema.json": authority_schema,
        "NEGATIVE_CONTRACT_FIXTURE_MATRIX.json": negative_matrix,
    }
    for name, value in artifacts.items():
        write_once(name, value)
    print(json.dumps({"status": "BUILT_STATIC_ONLY", "contract_members": len(artifacts), "suite_cases_defined": len(suite_cases), "negative_fixtures_defined": len(negative_tests), "operation_counters": zeros()}, sort_keys=True))


if __name__ == "__main__":
    main()
