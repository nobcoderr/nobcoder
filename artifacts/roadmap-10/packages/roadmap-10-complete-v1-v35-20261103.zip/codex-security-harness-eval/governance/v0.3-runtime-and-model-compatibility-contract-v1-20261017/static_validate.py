#!/usr/bin/env python3
"""Primary static and inert negative-fixture validation."""

from __future__ import annotations

import ast
import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1"
LIFECYCLE = ["DISCOVERED", "IDENTITY_PINNED", "COMPATIBILITY_CONTRACTED", "COMPATIBILITY_EXECUTION_AUTHORIZED", "COMPATIBILITY_TESTED", "PASS_LOCKED", "WORKER_EXECUTION_ELIGIBLE"]
FALSE_FIELDS = [
    "contract_execution_authorized", "compatibility_execution_authorized",
    "compatibility_suite_execution_authorized", "runtime_invocation_authorized",
    "codex_cli_invocation_authorized", "daybreak_invocation_authorized",
    "future_runtime_invocation_authorized", "worker_execution_authorized",
    "subagent_execution_authorized", "credential_use_authorized",
    "target_access_authorized", "external_network_authorized",
    "exploit_replay_authorized", "parallelism_authorized",
    "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized",
]
OPERATION_KEYS = [
    "compatibility_suite_executions", "runtime_invocations", "codex_cli_invocations",
    "daybreak_invocations", "future_runtime_invocations", "worker_processes",
    "subagent_processes", "credential_operations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
]
MEMBERS = [
    "RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT.json", "COMPATIBILITY_LIFECYCLE_CONTRACT.json",
    "PROVIDER_STATE_MODEL.json", "RUNTIME_IDENTITY_CONTRACT.json",
    "RUNTIME_ADAPTER_IDENTITY_CONTRACT.json", "VERSION_BINARY_MODEL_PIN_CONTRACT.json",
    "CONFIGURATION_IDENTITY_CONTRACT.json", "RUNTIME_CAPABILITIES_CONTRACT.json",
    "STRUCTURED_IO_CONTRACT.json", "TOOLING_CONTRACT.json",
    "SANDBOX_EXPECTATION_CONTRACT.json", "FAILURE_SEMANTICS.json", "EVIDENCE_CONTRACT.json",
    "COMPATIBILITY_SUITE_DEFINITION.json", "AUTHORITY_STATE.json",
    "UPGRADE_AND_SUCCESSOR_SEMANTICS.json", "CODEX_CLI_0_162_1_CANDIDATE_BINDING.json",
    "DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json", "PREDECESSOR_AUTHORIZATION_BINDING.json",
    "ROUTING_AND_SCOPE_DECISION.json", "RUNTIME_IDENTITY.schema.json",
    "RUNTIME_ADAPTER_IDENTITY.schema.json", "STRUCTURED_INPUT.schema.json",
    "STRUCTURED_OUTPUT.schema.json", "COMPATIBILITY_CASE.schema.json",
    "AUTHORITY_STATE.schema.json", "NEGATIVE_CONTRACT_FIXTURE_MATRIX.json",
]


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def zeros(value: Any) -> bool:
    return isinstance(value, dict) and set(value) == set(OPERATION_KEYS) and all(value[key] == 0 for key in OPERATION_KEYS)


def valid_bundle(b: dict[str, dict[str, Any]]) -> bool:
    main = b["RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT.json"]
    life = b["COMPATIBILITY_LIFECYCLE_CONTRACT.json"]
    provider = b["PROVIDER_STATE_MODEL.json"]
    rid = b["RUNTIME_IDENTITY_CONTRACT.json"]
    adapter = b["RUNTIME_ADAPTER_IDENTITY_CONTRACT.json"]
    pin = b["VERSION_BINARY_MODEL_PIN_CONTRACT.json"]
    config = b["CONFIGURATION_IDENTITY_CONTRACT.json"]
    caps = b["RUNTIME_CAPABILITIES_CONTRACT.json"]
    io = b["STRUCTURED_IO_CONTRACT.json"]
    tools = b["TOOLING_CONTRACT.json"]
    sandbox = b["SANDBOX_EXPECTATION_CONTRACT.json"]
    failure = b["FAILURE_SEMANTICS.json"]
    evidence = b["EVIDENCE_CONTRACT.json"]
    suite = b["COMPATIBILITY_SUITE_DEFINITION.json"]
    authority = b["AUTHORITY_STATE.json"]
    upgrade = b["UPGRADE_AND_SUCCESSOR_SEMANTICS.json"]
    codex = b["CODEX_CLI_0_162_1_CANDIDATE_BINDING.json"]
    future = b["DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json"]
    input_schema = b["STRUCTURED_INPUT.schema.json"]
    output_schema = b["STRUCTURED_OUTPUT.schema.json"]
    runtime_schema = b["RUNTIME_IDENTITY.schema.json"]
    adapter_schema = b["RUNTIME_ADAPTER_IDENTITY.schema.json"]
    return all([
        main.get("identity") == IDENTITY,
        main.get("status") == "STATIC_CONTRACT_CANDIDATE",
        main.get("default_policy") == "DENY",
        len(main.get("required_sections", [])) == 15,
        main.get("canonical_lifecycle") == LIFECYCLE,
        main.get("pre_discovery_state") == "NOT_DISCOVERED",
        main.get("contract_pass_effect") == "CONTRACT_ONLY_NO_COMPATIBILITY_EXECUTION_OR_RUNTIME_AUTHORITY",
        life.get("ordered_acceptance_states") == LIFECYCLE,
        life.get("pre_lifecycle_states") == ["NOT_DISCOVERED"],
        life.get("skip_or_reverse_transition") == "PROHIBITED",
        set(life.get("transition_requirements", {})) == {
            "NOT_DISCOVERED_TO_DISCOVERED", "DISCOVERED_TO_IDENTITY_PINNED",
            "IDENTITY_PINNED_TO_COMPATIBILITY_CONTRACTED",
            "COMPATIBILITY_CONTRACTED_TO_COMPATIBILITY_EXECUTION_AUTHORIZED",
            "COMPATIBILITY_EXECUTION_AUTHORIZED_TO_COMPATIBILITY_TESTED",
            "COMPATIBILITY_TESTED_TO_PASS_LOCKED", "PASS_LOCKED_TO_WORKER_EXECUTION_ELIGIBLE",
        },
        provider.get("allowed_discovery_states") == ["NOT_DISCOVERED", "DISCOVERED", "IDENTITY_PINNED"],
        provider.get("adapter_name_does_not_prove_provider_availability") is True,
        provider.get("model_name_endpoint_capabilities_and_access_must_be_independently_bound") is True,
        set(rid.get("required_fields", [])) == {"runtime_id", "provider", "discovery_state", "identity_state", "version", "binary_digest", "model_identity", "configuration_identity", "source_provenance", "availability_claim", "authoritative", "invocation_authorized", "invocation_count"},
        rid.get("identity_match_is_not_compatibility") is True,
        adapter.get("abstract_interface") == "SecurityWorkerRuntime",
        adapter.get("adapter_types") == ["CodexCliRuntime", "DaybreakRuntime", "FutureRuntimeAdapter"],
        adapter.get("generic_command_or_code_endpoint") == "PROHIBITED",
        adapter.get("provider_specific_argv_in_core") == "PROHIBITED",
        pin.get("moving_alias_or_latest") == "PROHIBITED",
        pin.get("binary_digest_or_model_identity_alone_is_sufficient") is False,
        "EXACT_BINARY_SHA256" in pin.get("binary_runtime_requirements", []),
        "EXACT_MODEL_IDENTITY" in pin.get("model_runtime_requirements", []),
        config.get("missing_required_setting") == "NOT_COMPATIBLE_FAIL_CLOSED",
        config.get("secret_values_in_contract_or_evidence") == "PROHIBITED",
        len(config.get("required", [])) == 10,
        caps.get("default_state") == "UNCLAIMED",
        caps.get("upstream_claim_is_compatibility_evidence") is False,
        caps.get("unknown_capability") == "FAIL_CLOSED_NOT_AVAILABLE",
        io.get("free_form_prose_authoritative") is False,
        io.get("unknown_input_or_output_field") == "REJECT",
        io.get("schema_or_request_identity_mismatch") == "FAIL_CLOSED",
        io.get("model_output_can_grant_authority") is False,
        tools.get("default") == "NO_TOOLS",
        tools.get("generic_shell_python_code_raw_args_or_package_install") == "PROHIBITED",
        tools.get("credential_or_network_tooling") == "REQUIRES_SEPARATE_EXACT_AUTHORIZATION",
        sandbox.get("substrate_identity") == "RUNTIME_SUBSTRATE_V5_PASS_LOCKED",
        sandbox.get("runtime_or_adapter_cannot_weaken_substrate") is True,
        "FAIL_CLOSED_NO_UNSANDBOXED_FALLBACK" in sandbox.get("requirements", []),
        failure.get("mandatory_failure_result") == "FAIL_CLOSED",
        failure.get("automatic_retry") == "PROHIBITED",
        failure.get("patch_relock_or_reclassify_consumed_identity") == "PROHIBITED",
        evidence.get("append_only") is True and evidence.get("digest_bound") is True,
        evidence.get("secret_material_in_evidence") == "PROHIBITED",
        evidence.get("incomplete_evidence") == "NO_PASS",
        suite.get("status") == "DEFINED_NOT_AUTHORIZED_NOT_EXECUTED",
        suite.get("case_count") == len(suite.get("cases", [])) == 18,
        len({case.get("case_id") for case in suite.get("cases", [])}) == 18,
        all(case.get("expected") == "PASS" and case.get("evidence_required") is True for case in suite.get("cases", [])),
        suite.get("execution_requires_separate_governance") is True,
        authority.get("contract_publication_authorized") is True,
        all(authority.get(key) is False for key in FALSE_FIELDS),
        zeros(authority.get("operation_counters")),
        authority.get("structural_counts") == {"contract_publication_event_count": 1, "suite_definition_case_count": 18},
        authority.get("authority_default") == "DENY",
        authority.get("contract_pass_is_not_compatibility_pass") is True,
        authority.get("compatibility_pass_is_not_worker_execution_authority") is True,
        upgrade.get("automatic_update") == "PROHIBITED",
        upgrade.get("candidate_may_replace_pass_locked_runtime_without_tests") is False,
        len(upgrade.get("required_successor_steps", [])) == 8,
        codex.get("version") == "0.162.1",
        codex.get("status") == "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED",
        codex.get("compatibility_state") == "CANDIDATE_ONLY_NOT_VALIDATED",
        codex.get("configuration_compliance") == "ABSENT_NOT_COMPLIANT",
        codex.get("invocation_count") == 0 and codex.get("invocation_authorized") is False,
        codex.get("compatibility_suite_executed") is False and codex.get("authoritative_runtime") is False,
        future.get("daybreak", {}).get("discovery_state") == "NOT_DISCOVERED",
        future.get("daybreak", {}).get("availability") == "NOT_ASSUMED",
        future.get("daybreak", {}).get("model_identity") == "UNBOUND",
        future.get("daybreak", {}).get("compatibility") == "NOT_ESTABLISHED",
        future.get("daybreak", {}).get("invocation_count") == 0,
        future.get("future_runtime", {}).get("availability") == "NOT_ASSUMED",
        future.get("adapter_contract_presence_is_availability_evidence") is False,
        runtime_schema.get("additionalProperties") is False,
        set(runtime_schema.get("required", [])) == set(rid.get("required_fields", [])),
        adapter_schema.get("additionalProperties") is False,
        input_schema.get("additionalProperties") is False and set(input_schema.get("required", [])) == set(io.get("input_required_fields", [])),
        output_schema.get("additionalProperties") is False and set(output_schema.get("required", [])) == set(io.get("output_required_fields", [])),
    ])


def mutations() -> list[tuple[str, Callable[[dict[str, dict[str, Any]]], None]]]:
    cases: list[tuple[str, Callable[[dict[str, dict[str, Any]]], None]]] = []
    def add(case_id: str, record: str, path: tuple[str, ...], value: Any) -> None:
        def mutate(bundle: dict[str, dict[str, Any]], rec=record, p=path, v=value) -> None:
            target: Any = bundle[rec]
            for key in p[:-1]:
                target = target[key]
            target[p[-1]] = v
        cases.append((case_id, mutate))
    add("N001_MISSING_RUNTIME_ID", "RUNTIME_IDENTITY_CONTRACT.json", ("required_fields",), [])
    add("N002_MOVING_VERSION", "VERSION_BINARY_MODEL_PIN_CONTRACT.json", ("moving_alias_or_latest",), "ALLOWED")
    add("N003_MISSING_BINARY_OR_MODEL_IDENTITY", "VERSION_BINARY_MODEL_PIN_CONTRACT.json", ("binary_runtime_requirements",), [])
    add("N004_MISSING_CONFIGURATION_IDENTITY", "CONFIGURATION_IDENTITY_CONTRACT.json", ("required",), [])
    add("N005_CONFIGURATION_DRIFT", "CONFIGURATION_IDENTITY_CONTRACT.json", ("missing_required_setting",), "ALLOW")
    add("N006_DAYBREAK_AVAILABILITY_ASSUMED", "DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json", ("daybreak", "availability"), "AVAILABLE")
    add("N007_DAYBREAK_MODEL_INVENTED", "DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json", ("daybreak", "model_identity"), "invented")
    add("N008_CAPABILITY_FROM_MARKETING", "RUNTIME_CAPABILITIES_CONTRACT.json", ("upstream_claim_is_compatibility_evidence",), True)
    add("N009_LIFECYCLE_SKIP", "COMPATIBILITY_LIFECYCLE_CONTRACT.json", ("transition_requirements",), {})
    add("N010_LIFECYCLE_REORDER", "COMPATIBILITY_LIFECYCLE_CONTRACT.json", ("ordered_acceptance_states",), list(reversed(LIFECYCLE)))
    add("N011_CONTRACT_PASS_IMPLIES_SUITE_AUTH", "AUTHORITY_STATE.json", ("compatibility_suite_execution_authorized",), True)
    add("N012_COMPAT_PASS_IMPLIES_WORKER_AUTH", "AUTHORITY_STATE.json", ("worker_execution_authorized",), True)
    add("N013_FREE_FORM_INPUT", "STRUCTURED_IO_CONTRACT.json", ("unknown_input_or_output_field",), "ALLOW")
    add("N014_FREE_FORM_OUTPUT", "STRUCTURED_IO_CONTRACT.json", ("free_form_prose_authoritative",), True)
    add("N015_UNKNOWN_INPUT_FIELD", "STRUCTURED_INPUT.schema.json", ("additionalProperties",), True)
    add("N016_UNKNOWN_OUTPUT_FIELD", "STRUCTURED_OUTPUT.schema.json", ("additionalProperties",), True)
    add("N017_GENERIC_SHELL", "TOOLING_CONTRACT.json", ("generic_shell_python_code_raw_args_or_package_install",), "ALLOWED")
    add("N018_ARBITRARY_CODE", "RUNTIME_ADAPTER_IDENTITY_CONTRACT.json", ("generic_command_or_code_endpoint",), "ALLOWED")
    add("N019_RAW_ADDITIONAL_ARGS", "TOOLING_CONTRACT.json", ("default",), "RAW_ARGS")
    add("N020_PACKAGE_INSTALL", "TOOLING_CONTRACT.json", ("generic_shell_python_code_raw_args_or_package_install",), "PACKAGE_INSTALL")
    add("N021_AUTOMATIC_UPDATE", "UPGRADE_AND_SUCCESSOR_SEMANTICS.json", ("automatic_update",), "ALLOWED")
    add("N022_SANDBOX_WEAKENING", "SANDBOX_EXPECTATION_CONTRACT.json", ("runtime_or_adapter_cannot_weaken_substrate",), False)
    add("N023_UNSANDBOXED_FALLBACK", "SANDBOX_EXPECTATION_CONTRACT.json", ("requirements",), [])
    add("N024_SECRET_IN_CONTEXT", "EVIDENCE_CONTRACT.json", ("secret_material_in_evidence",), "ALLOWED")
    add("N025_CREDENTIAL_USE", "AUTHORITY_STATE.json", ("credential_use_authorized",), True)
    add("N026_TARGET_ACCESS", "AUTHORITY_STATE.json", ("target_access_authorized",), True)
    add("N027_EXTERNAL_NETWORK", "AUTHORITY_STATE.json", ("external_network_authorized",), True)
    add("N028_EXPLOIT_REPLAY", "AUTHORITY_STATE.json", ("exploit_replay_authorized",), True)
    add("N029_SUBAGENT", "AUTHORITY_STATE.json", ("subagent_execution_authorized",), True)
    add("N030_PARALLELISM", "AUTHORITY_STATE.json", ("parallelism_authorized",), True)
    add("N031_CAPABILITY_EDGE", "AUTHORITY_STATE.json", ("capability_graph_authorized",), True)
    add("N032_CANDIDATE_PROMOTION", "AUTHORITY_STATE.json", ("candidate_promotion_authorized",), True)
    add("N033_SUBMISSION", "AUTHORITY_STATE.json", ("submission_automation_authorized",), True)
    add("N034_RETRY_AFTER_TERMINAL", "FAILURE_SEMANTICS.json", ("automatic_retry",), "ALLOWED")
    add("N035_EVIDENCE_INCOMPLETE_PASS", "EVIDENCE_CONTRACT.json", ("incomplete_evidence",), "PASS")
    add("N036_VALIDATOR_DISAGREEMENT_PASS", "FAILURE_SEMANTICS.json", ("mandatory_failure_result",), "PASS")
    add("N037_SCHEMA_DIGEST_MISMATCH", "STRUCTURED_IO_CONTRACT.json", ("schema_or_request_identity_mismatch",), "ALLOW")
    add("N038_RUNTIME_IDENTITY_MISMATCH", "RUNTIME_IDENTITY_CONTRACT.json", ("identity_match_is_not_compatibility",), False)
    add("N039_TOOL_REQUEST_OUTSIDE_ALLOWLIST", "TOOLING_CONTRACT.json", ("default",), "ALLOW_ALL")
    add("N040_EXTERNAL_REFERENCE_AUTHORITY", "AUTHORITY_STATE.json", ("contract_pass_is_not_compatibility_pass",), False)
    return cases


def main() -> None:
    historical_names = {
        "PRIMARY_STATIC_VALIDATION_RUN-0001.json", "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0001.json",
        "PRIMARY_STATIC_VALIDATION_RUN-0002.json", "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0002.json",
    }
    output_primary = ROOT / "PRIMARY_STATIC_VALIDATION_RUN-0003.json"
    output_negative = ROOT / "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003.json"
    if not all((ROOT / name).is_file() for name in historical_names):
        raise SystemExit("required historical RUN-0001/RUN-0002 evidence missing")
    if output_primary.exists() or output_primary.is_symlink() or output_negative.exists() or output_negative.is_symlink():
        raise SystemExit("append-only RUN-0002 validation result collision")
    actual = {path.name for path in ROOT.glob("*.json")}
    expected_input_set = set(MEMBERS) | historical_names
    if actual != expected_input_set:
        raise SystemExit(f"member set mismatch extra={sorted(actual-expected_input_set)} missing={sorted(expected_input_set-actual)}")
    bundle = {name: load(name) for name in MEMBERS}
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})
    for name in MEMBERS:
        check(f"P_MEMBER_{name}", (ROOT / name).is_file() and not (ROOT / name).is_symlink(), sha(ROOT / name))
    for script in ("build_contract.py", "static_validate.py", "independent_validate.py", "finalize_contract.py", "freeze_verify.py"):
        check(f"P_SYNTAX_{script}", ast.parse((ROOT / script).read_text(encoding="utf-8")) is not None, sha(ROOT / script))
    check("P_CANONICAL_BUNDLE", valid_bundle(bundle))
    check("P_IDENTITY_UNIFORM", all(value.get("contract_identity", value.get("identity", IDENTITY)) == IDENTITY for value in bundle.values() if not value.get("$schema")))
    check("P_SCHEMA_COUNT", sum(name.endswith(".schema.json") for name in MEMBERS) == 6)
    check("P_SCHEMAS_STRICT", all(bundle[name].get("additionalProperties") is False for name in MEMBERS if name.endswith(".schema.json")))
    check("P_SUITE_CASES", bundle["COMPATIBILITY_SUITE_DEFINITION.json"].get("case_count") == 18)
    check("P_NEGATIVE_FIXTURES_DEFINED", bundle["NEGATIVE_CONTRACT_FIXTURE_MATRIX.json"].get("fixture_count") == 40)
    check("P_ROUTING_COVERAGE", len(bundle["ROUTING_AND_SCOPE_DECISION.json"].get("route_ledger", [])) > 0)
    check("P_NO_SUBAGENTS", bundle["ROUTING_AND_SCOPE_DECISION.json"].get("subagents") == "NOT_USED")
    check("P_NO_NETWORK", bundle["ROUTING_AND_SCOPE_DECISION.json"].get("network") == "NOT_USED")
    check("P_NO_RUNTIME_INVOCATIONS", bundle["ROUTING_AND_SCOPE_DECISION.json"].get("runtime_or_model_invocations") == 0)
    check("P_ZERO_OPERATIONS", zeros(bundle["AUTHORITY_STATE.json"].get("operation_counters")))
    check("P_CODEX_CANDIDATE_ONLY", bundle["CODEX_CLI_0_162_1_CANDIDATE_BINDING.json"].get("status") == "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED")
    check("P_DAYBREAK_NOT_ASSUMED", bundle["DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json"].get("daybreak", {}).get("availability") == "NOT_ASSUMED")

    negative_results = []
    declared = [item.get("fixture_id") for item in bundle["NEGATIVE_CONTRACT_FIXTURE_MATRIX.json"].get("fixtures", [])]
    for case_id, mutate in mutations():
        candidate = copy.deepcopy(bundle)
        mutate(candidate)
        rejected = not valid_bundle(candidate)
        negative_results.append({"fixture_id": case_id, "expected": "REJECT_OR_FAIL_CLOSED", "actual": "REJECT" if rejected else "ACCEPT", "status": "PASS" if rejected else "FAIL"})
    check("P_NEGATIVE_IDENTITY_PARITY", declared == [case_id for case_id, _ in mutations()])
    check("P_NEGATIVE_ALL_REJECTED", all(item["status"] == "PASS" for item in negative_results))

    failed = [item for item in checks if item["status"] != "PASS"]
    primary = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_PRIMARY_STATIC_VALIDATION", "schema_version": "1.0",
        "contract_identity": IDENTITY, "run_id": "PRIMARY_STATIC_VALIDATION_RUN-0003",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "checks": checks, "operation_counters": bundle["AUTHORITY_STATE.json"]["operation_counters"],
    }
    negative_failed = [item for item in negative_results if item["status"] != "PASS"]
    negative = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_NEGATIVE_FIXTURE_RESULT", "schema_version": "1.0",
        "contract_identity": IDENTITY, "run_id": "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003",
        "status": "PASS" if not negative_failed else "FAIL_CLOSED",
        "tests_total": len(negative_results), "tests_passed": len(negative_results) - len(negative_failed), "tests_failed": len(negative_failed),
        "results": negative_results, "operation_counters": bundle["AUTHORITY_STATE.json"]["operation_counters"],
    }
    for name, value in (("PRIMARY_STATIC_VALIDATION_RUN-0003.json", primary), ("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003.json", negative)):
        with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
    print(json.dumps({"primary_status": primary["status"], "primary_checks": len(checks), "negative_status": negative["status"], "negative_tests": len(negative_results)}, sort_keys=True))
    if failed or negative_failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
