#!/usr/bin/env python3
"""Create immutable contract/governance manifests and locks."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1"
MILESTONE = "ESTABLISH_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1"
AUTH_ID = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1_PUBLICATION_AUTHORIZATION_GOVERNANCE_V1"
AUTH_LOCK_SHA = "6f0527943c04ad3d6dd5cfe757747e1fe8af77c4f9a7f593bf1adac8fb1640eb"
AUTH_MANIFEST_SHA = "4efa0e2b23c809fd4908dac672c84e796afcb2fd3f5262d5e1b1d7badac6131b"
AUTH_ROOT_SHA = "4187bdefd929f7762f6b0d39d331ff6e4b4ef1e488f0b7ddf59dc20a67651a47"
PUBLICATION_AUTH_SHA = "c432e1bfa8f6ac49534a790b399a614566f870972e8c0df14f0ecb7273fb208d"
CONTRACT_MEMBERS = [
    "RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT.json", "COMPATIBILITY_LIFECYCLE_CONTRACT.json",
    "PROVIDER_STATE_MODEL.json", "RUNTIME_IDENTITY_CONTRACT.json",
    "RUNTIME_ADAPTER_IDENTITY_CONTRACT.json", "VERSION_BINARY_MODEL_PIN_CONTRACT.json",
    "CONFIGURATION_IDENTITY_CONTRACT.json", "RUNTIME_CAPABILITIES_CONTRACT.json",
    "STRUCTURED_IO_CONTRACT.json", "TOOLING_CONTRACT.json",
    "SANDBOX_EXPECTATION_CONTRACT.json", "FAILURE_SEMANTICS.json", "EVIDENCE_CONTRACT.json",
    "COMPATIBILITY_SUITE_DEFINITION.json", "AUTHORITY_STATE.json",
    "UPGRADE_AND_SUCCESSOR_SEMANTICS.json", "CODEX_CLI_0_162_1_CANDIDATE_BINDING.json",
    "DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json", "PREDECESSOR_AUTHORIZATION_BINDING.json",
    "ROUTING_AND_SCOPE_DECISION.json", "RUNTIME_IDENTITY.schema.json",
    "RUNTIME_ADAPTER_IDENTITY.schema.json", "STRUCTURED_INPUT.schema.json",
    "STRUCTURED_OUTPUT.schema.json", "COMPATIBILITY_CASE.schema.json",
    "AUTHORITY_STATE.schema.json", "NEGATIVE_CONTRACT_FIXTURE_MATRIX.json",
]
RESULTS = [
    "PRIMARY_STATIC_VALIDATION_RUN-0001.json",
    "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0001.json",
    "PRIMARY_STATIC_VALIDATION_RUN-0002.json",
    "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0002.json",
    "PRIMARY_STATIC_VALIDATION_RUN-0003.json",
    "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003.json",
    "INDEPENDENT_VALIDATION_RUN-0001.json",
    "FREEZE_VERIFICATION_RUN-0001.json",
]
SCRIPTS = ["build_contract.py", "static_validate.py", "independent_validate.py", "finalize_contract.py", "freeze_verify.py"]
FALSE_FIELDS = [
    "contract_execution_authorized", "compatibility_execution_authorized",
    "compatibility_suite_execution_authorized", "runtime_invocation_authorized",
    "codex_cli_invocation_authorized", "daybreak_invocation_authorized",
    "future_runtime_invocation_authorized", "worker_execution_authorized",
    "subagent_execution_authorized", "credential_use_authorized",
    "target_access_authorized", "external_network_authorized",
    "exploit_replay_authorized", "parallelism_authorized",
    "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def write_once(name: str, value: object) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def member(name: str) -> dict[str, Any]:
    path = ROOT / name
    return {"path": name, "sha256": sha(path), "bytes": path.stat().st_size}


def canonical_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda item: str(item["path"]))).encode()
    return hashlib.sha256(raw).hexdigest()


def main() -> None:
    expected = set(CONTRACT_MEMBERS + RESULTS + SCRIPTS)
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected:
        raise SystemExit(f"prefinal set mismatch extra={sorted(actual-expected)} missing={sorted(expected-actual)}")
    historical_primary = load("PRIMARY_STATIC_VALIDATION_RUN-0001.json")
    historical_negative = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0001.json")
    historical_primary_2 = load("PRIMARY_STATIC_VALIDATION_RUN-0002.json")
    historical_negative_2 = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0002.json")
    primary = load("PRIMARY_STATIC_VALIDATION_RUN-0003.json")
    negative = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003.json")
    independent = load("INDEPENDENT_VALIDATION_RUN-0001.json")
    freeze = load("FREEZE_VERIFICATION_RUN-0001.json")
    if any(record.get("status") != "PASS" for record in (primary, negative, independent, freeze)):
        raise SystemExit("mandatory validation failure")
    if historical_primary.get("status") != "FAIL_CLOSED" or historical_negative.get("status") != "PASS" or historical_primary_2.get("status") != "FAIL_CLOSED" or historical_negative_2.get("status") != "FAIL_CLOSED":
        raise SystemExit("historical pre-lock lineage mismatch")
    authority = load("AUTHORITY_STATE.json")
    if authority.get("contract_publication_authorized") is not True or any(authority.get(key) is not False for key in FALSE_FIELDS):
        raise SystemExit("authority ceiling failure")
    if any(value != 0 for value in authority.get("operation_counters", {}).values()):
        raise SystemExit("nonzero operation counter")

    contract_members = [member(name) for name in CONTRACT_MEMBERS]
    contract_member_root = canonical_root(contract_members)
    contract_manifest = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_CONTRACT_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "contract_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "member_count": len(contract_members), "members": contract_members,
        "canonical_member_root_sha256": contract_member_root, "self_referential_hashes": False,
    }
    write_once("CONTRACT_ARTIFACT_MANIFEST.json", contract_manifest)
    contract_manifest_sha = sha(ROOT / "CONTRACT_ARTIFACT_MANIFEST.json")
    contract_root = canonical_root(contract_members + [member("CONTRACT_ARTIFACT_MANIFEST.json")])
    contract_lock = {
        "record_type": "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_LOCK",
        "schema_version": "1.0", "identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
        "publication_authorized": True,
        **{key: False for key in FALSE_FIELDS},
        "codex_cli": {"version": "0.162.1", "status": "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED", "invocation_count": 0},
        "daybreak": {"discovery_state": "NOT_DISCOVERED", "availability": "NOT_ASSUMED", "compatibility": "NOT_ESTABLISHED", "invocation_count": 0},
        "future_runtime": {"discovery_state": "NOT_DISCOVERED", "availability": "NOT_ASSUMED", "compatibility": "NOT_ESTABLISHED", "invocation_count": 0},
        "contract_manifest_sha256": contract_manifest_sha,
        "canonical_member_root_sha256": contract_member_root,
        "canonical_contract_root_sha256": contract_root,
        "contract_manifest_members": len(contract_members),
        "contract_root_members": len(contract_members) + 1,
        "authorization_governance_identity": AUTH_ID,
        "authorization_governance_lock_sha256": AUTH_LOCK_SHA,
        "authorization_governance_manifest_sha256": AUTH_MANIFEST_SHA,
        "authorization_governance_canonical_root_sha256": AUTH_ROOT_SHA,
        "publication_authorization_lock_sha256": PUBLICATION_AUTH_SHA,
        "operation_counters": authority["operation_counters"],
        "structural_counts": authority["structural_counts"],
    }
    write_once("CONTRACT_LOCK.json", contract_lock)
    publication = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_CONTRACT_PUBLICATION_RESULT",
        "schema_version": "1.0", "contract_identity": IDENTITY, "milestone": MILESTONE,
        "status": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
        "source": "CREATED_STATICALLY_VALIDATED_INDEPENDENTLY_VALIDATED_AND_FROZEN",
        "compatibility_suite": "DEFINED_NOT_AUTHORIZED_NOT_EXECUTED",
        "codex_cli": "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED_INVOCATION_COUNT_0",
        "daybreak": "NOT_DISCOVERED_AVAILABILITY_NOT_ASSUMED_INVOCATION_COUNT_0",
        "runtime_worker_subagent": "NOT_AUTHORIZED_NOT_EXECUTED",
        "credential_target_network": "NOT_AUTHORIZED_NOT_EXECUTED",
        "exploit_parallel_capability_promotion_submission": "NOT_AUTHORIZED_NOT_EXECUTED",
        "contract_lock_sha256": sha(ROOT / "CONTRACT_LOCK.json"),
        "operation_counters": authority["operation_counters"],
    }
    write_once("CONTRACT_PUBLICATION_RESULT.json", publication)
    next_legal = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_NEXT_LEGAL_MILESTONE",
        "schema_version": "1.0", "contract_identity": IDENTITY,
        "current_milestone": MILESTONE, "current_status": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
        "next_proposed_milestone": "AUTHORIZE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_ONLY",
        "next_status": "PROPOSAL_ONLY_REQUIRES_SEPARATE_PASS_LOCKED_GOVERNANCE",
        "compatibility_execution_authorized_now": False,
        "codex_or_daybreak_invocation_authorized_now": False,
        "worker_or_subagent_authorized_now": False,
        "credential_target_or_network_authorized_now": False,
    }
    write_once("NEXT_LEGAL_MILESTONE.json", next_legal)

    excluded = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    governance_names = sorted(path.name for path in ROOT.iterdir() if path.is_file() and path.name not in excluded)
    if any((ROOT / name).is_symlink() for name in governance_names):
        raise SystemExit("symlink in governance tree")
    governance_members = [member(name) for name in governance_names]
    governance_member_root = canonical_root(governance_members)
    governance_manifest = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "contract_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "member_count": len(governance_members), "members": governance_members,
        "canonical_member_root_sha256": governance_member_root, "self_referential_hashes": False,
    }
    write_once("GOVERNANCE_ARTIFACT_MANIFEST.json", governance_manifest)
    governance_manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    governance_root = canonical_root(governance_members + [member("GOVERNANCE_ARTIFACT_MANIFEST.json")])
    governance_lock = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_GOVERNANCE_LOCK",
        "schema_version": "1.0", "governance_identity": IDENTITY, "milestone": MILESTONE,
        "status": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
        "authorization_governance_identity": AUTH_ID,
        "authorization_governance_lock_sha256": AUTH_LOCK_SHA,
        "authorization_governance_manifest_sha256": AUTH_MANIFEST_SHA,
        "publication_authorization_lock_sha256": PUBLICATION_AUTH_SHA,
        "contract_lock_sha256": sha(ROOT / "CONTRACT_LOCK.json"),
        "contract_manifest_sha256": contract_manifest_sha,
        "canonical_contract_root_sha256": contract_root,
        "governance_manifest_sha256": governance_manifest_sha,
        "canonical_member_root_sha256": governance_member_root,
        "canonical_artifact_root_sha256": governance_root,
        "structural_counts": {
            "contract_manifest_members": len(contract_members),
            "contract_root_members": len(contract_members) + 1,
            "governance_manifest_members": len(governance_members),
            "governance_root_members": len(governance_members) + 1,
            "contract_publication_event_count": 1,
            "historical_prelock_result_count": 4,
            "successful_prelock_result_count": 2,
        },
        "validation_counts": {
            "primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
            "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
            "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
            "freeze_candidate": {"total": freeze["checks_total"], "passed": freeze["checks_passed"], "failed": freeze["checks_failed"]},
        },
        "contract_publication_authorized": True,
        **{key: False for key in FALSE_FIELDS},
        "operation_counters": authority["operation_counters"],
    }
    write_once("GOVERNANCE_LOCK.json", governance_lock)
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": governance_lock["status"],
        "contract_manifest_sha256": contract_manifest_sha,
        "contract_lock_sha256": sha(ROOT / "CONTRACT_LOCK.json"),
        "canonical_contract_root_sha256": contract_root,
        "governance_manifest_sha256": governance_manifest_sha,
        "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"),
        "canonical_artifact_root_sha256": governance_root,
        "governance_members": len(governance_members),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
