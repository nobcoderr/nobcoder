#!/usr/bin/env python3
"""Candidate and final freeze verification for compatibility contract V1."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1"
AUTH = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-contract-v1-publication-authorization-governance-v1-20261017")
EXPECTED_AUTH = {
    "GOVERNANCE_LOCK.json": "6f0527943c04ad3d6dd5cfe757747e1fe8af77c4f9a7f593bf1adac8fb1640eb",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "4efa0e2b23c809fd4908dac672c84e796afcb2fd3f5262d5e1b1d7badac6131b",
    "CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json": "c432e1bfa8f6ac49534a790b399a614566f870972e8c0df14f0ecb7273fb208d",
}
CONTRACT_MEMBERS = [
    "RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT.json", "COMPATIBILITY_LIFECYCLE_CONTRACT.json",
    "PROVIDER_STATE_MODEL.json", "RUNTIME_IDENTITY_CONTRACT.json",
    "RUNTIME_ADAPTER_IDENTITY_CONTRACT.json", "VERSION_BINARY_MODEL_PIN_CONTRACT.json",
    "CONFIGURATION_IDENTITY_CONTRACT.json", "RUNTIME_CAPABILITIES_CONTRACT.json",
    "STRUCTURED_IO_CONTRACT.json", "TOOLING_CONTRACT.json",
    "SANDBOX_EXPECTATION_CONTRACT.json", "FAILURE_SEMANTICS.json", "EVIDENCE_CONTRACT.json",
    "COMPATIBILITY_SUITE_DEFINITION.json", "AUTHORITY_STATE.json",
    "UPGRADE_AND_SUCCESSOR_SEMANTICS.json", "CODEX_CLI_0_162_1_CANDIDATE_BINDING.json",
    "DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json", "PREDECESSOR_AUTHORIZATION_BINDING.json",
    "ROUTING_AND_SCOPE_DECISION.json", "RUNTIME_IDENTITY.schema.json",
    "RUNTIME_ADAPTER_IDENTITY.schema.json", "STRUCTURED_INPUT.schema.json",
    "STRUCTURED_OUTPUT.schema.json", "COMPATIBILITY_CASE.schema.json",
    "AUTHORITY_STATE.schema.json", "NEGATIVE_CONTRACT_FIXTURE_MATRIX.json",
]
RESULTS_BEFORE_FREEZE = [
    "PRIMARY_STATIC_VALIDATION_RUN-0001.json", "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0001.json",
    "PRIMARY_STATIC_VALIDATION_RUN-0002.json", "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0002.json",
    "PRIMARY_STATIC_VALIDATION_RUN-0003.json", "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003.json",
    "INDEPENDENT_VALIDATION_RUN-0001.json",
]
SCRIPTS = ["build_contract.py", "static_validate.py", "independent_validate.py", "finalize_contract.py", "freeze_verify.py"]
FALSE_FIELDS = [
    "contract_execution_authorized", "compatibility_execution_authorized",
    "compatibility_suite_execution_authorized", "runtime_invocation_authorized",
    "codex_cli_invocation_authorized", "daybreak_invocation_authorized",
    "future_runtime_invocation_authorized", "worker_execution_authorized",
    "subagent_execution_authorized", "credential_use_authorized",
    "target_access_authorized", "external_network_authorized",
    "exploit_replay_authorized", "parallelism_authorized",
    "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized",
]
OPERATION_KEYS = {
    "compatibility_suite_executions", "runtime_invocations", "codex_cli_invocations",
    "daybreak_invocations", "future_runtime_invocations", "worker_processes",
    "subagent_processes", "credential_operations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def canonical_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda item: str(item["path"]))).encode()
    return hashlib.sha256(raw).hexdigest()


def zero_counters(value: Any) -> bool:
    return isinstance(value, dict) and set(value) == OPERATION_KEYS and all(item == 0 for item in value.values())


def verify(final: bool) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    expected = set(CONTRACT_MEMBERS + RESULTS_BEFORE_FREEZE + SCRIPTS)
    if final:
        expected |= {"FREEZE_VERIFICATION_RUN-0001.json", "CONTRACT_ARTIFACT_MANIFEST.json", "CONTRACT_LOCK.json", "CONTRACT_PUBLICATION_RESULT.json", "NEXT_LEGAL_MILESTONE.json", "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    check("F001_EXACT_FILE_SET", actual == expected, {"actual": len(actual), "expected": len(expected)})
    check("F002_NO_SYMLINKS", all(not path.is_symlink() for path in ROOT.iterdir()))
    check("F003_JSON_PARSE", all(isinstance(load(name), dict) for name in actual if name.endswith(".json")))
    for name, digest in EXPECTED_AUTH.items():
        check(f"F_AUTH_{name}", sha(AUTH / name) == digest)
    for script in SCRIPTS:
        check(f"F_SYNTAX_{script}", ast.parse((ROOT / script).read_text(encoding="utf-8")) is not None, sha(ROOT / script))

    main = load("RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT.json")
    life = load("COMPATIBILITY_LIFECYCLE_CONTRACT.json")
    authority = load("AUTHORITY_STATE.json")
    codex = load("CODEX_CLI_0_162_1_CANDIDATE_BINDING.json")
    future = load("DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json")
    suite = load("COMPATIBILITY_SUITE_DEFINITION.json")
    historical_primary = load("PRIMARY_STATIC_VALIDATION_RUN-0001.json")
    historical_negative = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0001.json")
    historical_primary_2 = load("PRIMARY_STATIC_VALIDATION_RUN-0002.json")
    historical_negative_2 = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0002.json")
    primary = load("PRIMARY_STATIC_VALIDATION_RUN-0003.json")
    negative = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003.json")
    independent = load("INDEPENDENT_VALIDATION_RUN-0001.json")
    expected_lifecycle = ["DISCOVERED", "IDENTITY_PINNED", "COMPATIBILITY_CONTRACTED", "COMPATIBILITY_EXECUTION_AUTHORIZED", "COMPATIBILITY_TESTED", "PASS_LOCKED", "WORKER_EXECUTION_ELIGIBLE"]

    check("F012_IDENTITY", main.get("identity") == IDENTITY)
    check("F013_MAIN_CANDIDATE", main.get("status") == "STATIC_CONTRACT_CANDIDATE")
    check("F014_DEFAULT_DENY", main.get("default_policy") == "DENY")
    check("F015_LIFECYCLE", main.get("canonical_lifecycle") == expected_lifecycle and life.get("ordered_acceptance_states") == expected_lifecycle)
    check("F016_PRE_DISCOVERY", main.get("pre_discovery_state") == "NOT_DISCOVERED" and life.get("pre_lifecycle_states") == ["NOT_DISCOVERED"])
    check("F017_PUBLICATION_AUTH", authority.get("contract_publication_authorized") is True)
    check("F018_AUTHORITY_FALSE", all(authority.get(key) is False for key in FALSE_FIELDS))
    check("F019_COUNTERS_ZERO", zero_counters(authority.get("operation_counters")))
    check("F020_TYPED_COUNTS", authority.get("structural_counts") == {"contract_publication_event_count": 1, "suite_definition_case_count": 18})
    check("F021_CONTRACT_PASS_NO_COMPAT", authority.get("contract_pass_is_not_compatibility_pass") is True)
    check("F022_COMPAT_NO_WORKER", authority.get("compatibility_pass_is_not_worker_execution_authority") is True)
    check("F023_CODEX_STATE", codex.get("version") == "0.162.1" and codex.get("status") == "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED")
    check("F024_CODEX_ZERO", codex.get("invocation_count") == 0 and codex.get("invocation_authorized") is False and codex.get("compatibility_suite_executed") is False)
    check("F025_DAYBREAK_STATE", future.get("daybreak", {}).get("discovery_state") == "NOT_DISCOVERED" and future.get("daybreak", {}).get("availability") == "NOT_ASSUMED" and future.get("daybreak", {}).get("compatibility") == "NOT_ESTABLISHED")
    check("F026_DAYBREAK_ZERO", future.get("daybreak", {}).get("invocation_count") == 0 and future.get("daybreak", {}).get("invocation_authorized") is False)
    check("F027_FUTURE_STATE", future.get("future_runtime", {}).get("discovery_state") == "NOT_DISCOVERED" and future.get("future_runtime", {}).get("availability") == "NOT_ASSUMED")
    check("F028_SUITE_DEFINITION", suite.get("status") == "DEFINED_NOT_AUTHORIZED_NOT_EXECUTED" and suite.get("case_count") == 18 and len(suite.get("cases", [])) == 18)
    check("F029_SUITE_SEPARATE_AUTH", suite.get("execution_requires_separate_governance") is True)
    check("F030_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0 and primary.get("checks_total") == primary.get("checks_passed"))
    check("F031_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 40 and negative.get("tests_failed") == 0)
    check("F032_INDEPENDENT_PASS", independent.get("status") == "PASS" and independent.get("checks_failed") == 0 and independent.get("checks_total") == independent.get("checks_passed"))
    check("F033_RESULT_COUNTER_PARITY", primary.get("operation_counters") == negative.get("operation_counters") == independent.get("operation_counters") == authority.get("operation_counters"))
    schemas = ["RUNTIME_IDENTITY.schema.json", "RUNTIME_ADAPTER_IDENTITY.schema.json", "STRUCTURED_INPUT.schema.json", "STRUCTURED_OUTPUT.schema.json", "COMPATIBILITY_CASE.schema.json", "AUTHORITY_STATE.schema.json"]
    check("F034_SCHEMA_STRICT", all(load(name).get("additionalProperties") is False for name in schemas))
    check("F035_SCHEMA_IDS", len({load(name).get("$id") for name in schemas}) == 6)
    check("F036_NEGATIVE_ALL_REJECT", all(item.get("actual") == "REJECT" and item.get("status") == "PASS" for item in negative.get("results", [])))
    check("F037_PREDECESSOR_IMMUTABLE", load("PREDECESSOR_AUTHORIZATION_BINDING.json").get("predecessor_mutation") == "PROHIBITED")
    check("F038_ROUTING_NO_SUBAGENT", load("ROUTING_AND_SCOPE_DECISION.json").get("subagents") == "NOT_USED")
    check("F039_ROUTING_NO_NETWORK", load("ROUTING_AND_SCOPE_DECISION.json").get("network") == "NOT_USED")
    check("F040_ROUTING_NO_RUNTIME", load("ROUTING_AND_SCOPE_DECISION.json").get("runtime_or_model_invocations") == 0)
    check("F041_HISTORICAL_PRIMARY", historical_primary.get("status") == "FAIL_CLOSED" and historical_primary.get("checks_failed") == 1)
    check("F042_HISTORICAL_NEGATIVE", historical_negative.get("status") == "PASS" and historical_negative.get("tests_passed") == 40)
    check("F043_HISTORICAL_RUN2", historical_primary_2.get("status") == "FAIL_CLOSED" and historical_primary_2.get("checks_failed") == 1 and historical_negative_2.get("status") == "FAIL_CLOSED" and historical_negative_2.get("tests_failed") == 1)

    if final:
        freeze = load("FREEZE_VERIFICATION_RUN-0001.json")
        contract_manifest = load("CONTRACT_ARTIFACT_MANIFEST.json")
        contract_lock = load("CONTRACT_LOCK.json")
        publication = load("CONTRACT_PUBLICATION_RESULT.json")
        next_legal = load("NEXT_LEGAL_MILESTONE.json")
        governance_manifest = load("GOVERNANCE_ARTIFACT_MANIFEST.json")
        governance_lock = load("GOVERNANCE_LOCK.json")
        check("F_FINAL_CANDIDATE_FREEZE_PASS", freeze.get("status") == "PASS" and freeze.get("checks_failed") == 0 and freeze.get("checks_total") == freeze.get("checks_passed"))
        cmembers = contract_manifest.get("members", [])
        check("F044_CONTRACT_MEMBER_COUNT", contract_manifest.get("member_count") == len(cmembers) == len(CONTRACT_MEMBERS))
        check("F045_CONTRACT_MEMBER_SET", {row.get("path") for row in cmembers} == set(CONTRACT_MEMBERS))
        check("F046_CONTRACT_DIGESTS", all(sha(ROOT / str(row["path"])) == row.get("sha256") and (ROOT / str(row["path"])).stat().st_size == row.get("bytes") for row in cmembers))
        check("F047_CONTRACT_MEMBER_ROOT", canonical_root(cmembers) == contract_manifest.get("canonical_member_root_sha256") == contract_lock.get("canonical_member_root_sha256"))
        cmanifest_sha = sha(ROOT / "CONTRACT_ARTIFACT_MANIFEST.json")
        croot = canonical_root(cmembers + [{"path": "CONTRACT_ARTIFACT_MANIFEST.json", "sha256": cmanifest_sha, "bytes": (ROOT / "CONTRACT_ARTIFACT_MANIFEST.json").stat().st_size}])
        check("F048_CONTRACT_LOCK_STATUS", contract_lock.get("status") == "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY")
        check("F049_CONTRACT_MANIFEST_SHA", contract_lock.get("contract_manifest_sha256") == cmanifest_sha)
        check("F050_CONTRACT_ROOT", contract_lock.get("canonical_contract_root_sha256") == croot)
        check("F051_CONTRACT_CEILING", all(contract_lock.get(key) is False for key in FALSE_FIELDS))
        check("F052_CONTRACT_COUNTERS", zero_counters(contract_lock.get("operation_counters")))
        check("F053_CONTRACT_CODEX", contract_lock.get("codex_cli") == {"version": "0.162.1", "status": "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED", "invocation_count": 0})
        check("F054_CONTRACT_DAYBREAK", contract_lock.get("daybreak", {}).get("availability") == "NOT_ASSUMED" and contract_lock.get("daybreak", {}).get("invocation_count") == 0)
        check("F055_PUBLICATION_STATUS", publication.get("status") == "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY")
        check("F056_PUBLICATION_LOCK", publication.get("contract_lock_sha256") == sha(ROOT / "CONTRACT_LOCK.json"))
        check("F057_PUBLICATION_NO_SUITE", publication.get("compatibility_suite") == "DEFINED_NOT_AUTHORIZED_NOT_EXECUTED")
        check("F058_NEXT_PROPOSAL", next_legal.get("next_proposed_milestone") == "AUTHORIZE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_ONLY")
        check("F059_NEXT_NOT_AUTHORIZED", next_legal.get("next_status") == "PROPOSAL_ONLY_REQUIRES_SEPARATE_PASS_LOCKED_GOVERNANCE" and next_legal.get("compatibility_execution_authorized_now") is False)
        gmembers = governance_manifest.get("members", [])
        expected_gmembers = actual - {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
        check("F060_GOVERNANCE_MEMBER_SET", {row.get("path") for row in gmembers} == expected_gmembers)
        check("F061_GOVERNANCE_MEMBER_COUNT", governance_manifest.get("member_count") == len(gmembers) == len(expected_gmembers))
        check("F062_GOVERNANCE_DIGESTS", all(sha(ROOT / str(row["path"])) == row.get("sha256") and (ROOT / str(row["path"])).stat().st_size == row.get("bytes") for row in gmembers))
        check("F063_GOVERNANCE_MEMBER_ROOT", canonical_root(gmembers) == governance_manifest.get("canonical_member_root_sha256") == governance_lock.get("canonical_member_root_sha256"))
        gmanifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
        groot = canonical_root(gmembers + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": gmanifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
        check("F064_GOVERNANCE_STATUS", governance_lock.get("status") == "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY")
        check("F065_GOVERNANCE_MANIFEST_SHA", governance_lock.get("governance_manifest_sha256") == gmanifest_sha)
        check("F066_GOVERNANCE_ROOT", governance_lock.get("canonical_artifact_root_sha256") == groot)
        check("F067_GOVERNANCE_CONTRACT_ROOT", governance_lock.get("canonical_contract_root_sha256") == croot)
        check("F068_GOVERNANCE_CEILING", all(governance_lock.get(key) is False for key in FALSE_FIELDS))
        check("F069_GOVERNANCE_COUNTERS", zero_counters(governance_lock.get("operation_counters")))
        check("F070_VALIDATION_COUNTS", governance_lock.get("validation_counts") == {"primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]}, "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]}, "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]}, "freeze_candidate": {"total": freeze["checks_total"], "passed": freeze["checks_passed"], "failed": freeze["checks_failed"]}})
        check("F071_FILES_READ_ONLY", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()))
        check("F072_ROOT_READ_ONLY", stat.S_IMODE(ROOT.stat().st_mode) == 0o555)

    failed = [item for item in checks if item["status"] != "PASS"]
    return checks, failed


def main() -> None:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--write-candidate", action="store_true")
    mode.add_argument("--verify-final", action="store_true")
    args = parser.parse_args()
    output = ROOT / "FREEZE_VERIFICATION_RUN-0001.json"
    if args.write_candidate and (output.exists() or output.is_symlink()):
        raise SystemExit("append-only freeze result collision")
    checks, failed = verify(final=args.verify_final)
    result = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_FREEZE_VERIFICATION",
        "schema_version": "1.0", "contract_identity": IDENTITY,
        "run_id": "FREEZE_VERIFICATION_RUN-0001" if args.write_candidate else "FINAL_READ_ONLY_FREEZE_VERIFICATION",
        "phase": "FREEZE_CANDIDATE" if args.write_candidate else "FINAL_READ_ONLY",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "checks": checks, "operation_counters": load("AUTHORITY_STATE.json")["operation_counters"],
    }
    if args.write_candidate:
        with output.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(result, handle, indent=2, sort_keys=True)
            handle.write("\n")
    summary = {"phase": result["phase"], "status": result["status"], "checks_total": result["checks_total"], "checks_passed": result["checks_passed"], "checks_failed": result["checks_failed"]}
    if args.verify_final:
        summary.update({"contract_lock_sha256": sha(ROOT / "CONTRACT_LOCK.json"), "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"), "governance_manifest_sha256": sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"), "canonical_artifact_root_sha256": load("GOVERNANCE_LOCK.json").get("canonical_artifact_root_sha256")})
    print(json.dumps(summary, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
