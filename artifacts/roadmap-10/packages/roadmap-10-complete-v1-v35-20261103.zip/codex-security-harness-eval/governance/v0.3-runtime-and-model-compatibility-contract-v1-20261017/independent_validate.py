#!/usr/bin/env python3
"""Independent static review of the compatibility contract package."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V1"
AUTH = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-contract-v1-publication-authorization-governance-v1-20261017")
EXPECTED_AUTH = {
    "GOVERNANCE_LOCK.json": "6f0527943c04ad3d6dd5cfe757747e1fe8af77c4f9a7f593bf1adac8fb1640eb",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "4efa0e2b23c809fd4908dac672c84e796afcb2fd3f5262d5e1b1d7badac6131b",
    "CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json": "c432e1bfa8f6ac49534a790b399a614566f870972e8c0df14f0ecb7273fb208d",
}
FALSE_FIELDS = [
    "contract_execution_authorized", "compatibility_execution_authorized",
    "compatibility_suite_execution_authorized", "runtime_invocation_authorized",
    "codex_cli_invocation_authorized", "daybreak_invocation_authorized",
    "future_runtime_invocation_authorized", "worker_execution_authorized",
    "subagent_execution_authorized", "credential_use_authorized",
    "target_access_authorized", "external_network_authorized",
    "exploit_replay_authorized", "parallelism_authorized",
    "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized",
]
OPERATION_KEYS = {
    "compatibility_suite_executions", "runtime_invocations", "codex_cli_invocations",
    "daybreak_invocations", "future_runtime_invocations", "worker_processes",
    "subagent_processes", "credential_operations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
}


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    output = ROOT / "INDEPENDENT_VALIDATION_RUN-0001.json"
    if output.exists() or output.is_symlink():
        raise SystemExit("append-only independent result collision")
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    for script in ("build_contract.py", "static_validate.py", "independent_validate.py", "finalize_contract.py", "freeze_verify.py"):
        check(f"I_SYNTAX_{script}", ast.parse((ROOT / script).read_text(encoding="utf-8")) is not None, sha(ROOT / script))
    for name, digest in EXPECTED_AUTH.items():
        check(f"I_AUTH_{name}", sha(AUTH / name) == digest)

    main = load("RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT.json")
    life = load("COMPATIBILITY_LIFECYCLE_CONTRACT.json")
    provider = load("PROVIDER_STATE_MODEL.json")
    rid = load("RUNTIME_IDENTITY_CONTRACT.json")
    adapter = load("RUNTIME_ADAPTER_IDENTITY_CONTRACT.json")
    pin = load("VERSION_BINARY_MODEL_PIN_CONTRACT.json")
    config = load("CONFIGURATION_IDENTITY_CONTRACT.json")
    caps = load("RUNTIME_CAPABILITIES_CONTRACT.json")
    io = load("STRUCTURED_IO_CONTRACT.json")
    tools = load("TOOLING_CONTRACT.json")
    sandbox = load("SANDBOX_EXPECTATION_CONTRACT.json")
    failure = load("FAILURE_SEMANTICS.json")
    evidence = load("EVIDENCE_CONTRACT.json")
    suite = load("COMPATIBILITY_SUITE_DEFINITION.json")
    authority = load("AUTHORITY_STATE.json")
    upgrade = load("UPGRADE_AND_SUCCESSOR_SEMANTICS.json")
    codex = load("CODEX_CLI_0_162_1_CANDIDATE_BINDING.json")
    future = load("DAYBREAK_AND_FUTURE_RUNTIME_UNBOUND_STATE.json")
    predecessor = load("PREDECESSOR_AUTHORIZATION_BINDING.json")
    routing = load("ROUTING_AND_SCOPE_DECISION.json")
    historical_primary_1 = load("PRIMARY_STATIC_VALIDATION_RUN-0001.json")
    historical_negative_1 = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0001.json")
    historical_primary_2 = load("PRIMARY_STATIC_VALIDATION_RUN-0002.json")
    historical_negative_2 = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0002.json")
    primary = load("PRIMARY_STATIC_VALIDATION_RUN-0003.json")
    negative = load("NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003.json")

    check("I001_IDENTITY", main.get("identity") == IDENTITY)
    check("I002_STATUS_CANDIDATE", main.get("status") == "STATIC_CONTRACT_CANDIDATE")
    check("I003_DENY_DEFAULT", main.get("default_policy") == "DENY")
    check("I004_SECTION_SET", set(main.get("required_sections", [])) == {"RuntimeIdentity", "RuntimeAdapterIdentity", "VersionPin", "BinaryDigestOrModelIdentity", "ConfigurationIdentity", "RuntimeCapabilities", "StructuredInputContract", "StructuredOutputContract", "ToolingContract", "SandboxExpectation", "FailureSemantics", "EvidenceContract", "CompatibilitySuiteDefinition", "AuthorityState", "UpgradeOrSuccessorSemantics"})
    expected_lifecycle = ["DISCOVERED", "IDENTITY_PINNED", "COMPATIBILITY_CONTRACTED", "COMPATIBILITY_EXECUTION_AUTHORIZED", "COMPATIBILITY_TESTED", "PASS_LOCKED", "WORKER_EXECUTION_ELIGIBLE"]
    check("I005_LIFECYCLE_MAIN", main.get("canonical_lifecycle") == expected_lifecycle)
    check("I006_LIFECYCLE_DETAIL", life.get("ordered_acceptance_states") == expected_lifecycle)
    check("I007_NOT_DISCOVERED_SEPARATE", main.get("pre_discovery_state") == "NOT_DISCOVERED" and life.get("pre_lifecycle_states") == ["NOT_DISCOVERED"])
    check("I008_NO_SKIP_REVERSE", life.get("skip_or_reverse_transition") == "PROHIBITED")
    check("I009_SEPARATE_EXEC_AUTH_GATE", life.get("transition_requirements", {}).get("COMPATIBILITY_CONTRACTED_TO_COMPATIBILITY_EXECUTION_AUTHORIZED") == ["SEPARATE_PASS_LOCKED_GOVERNANCE_AUTHORIZATION"])
    check("I010_WORKER_ELIGIBILITY_NOT_AUTH", "NO_WORKER_AUTHORITY_IMPLIED" in life.get("transition_requirements", {}).get("PASS_LOCKED_TO_WORKER_EXECUTION_ELIGIBLE", []))
    check("I011_PROVIDER_STATES", provider.get("allowed_discovery_states") == ["NOT_DISCOVERED", "DISCOVERED", "IDENTITY_PINNED"])
    check("I012_PROVIDER_NO_ASSUMPTION", provider.get("availability_claim_requires_evidence") is True and provider.get("adapter_name_does_not_prove_provider_availability") is True)
    check("I013_IDENTITY_FIELDS", len(rid.get("required_fields", [])) == 13 and "configuration_identity" in rid.get("required_fields", []))
    check("I014_IDENTITY_NOT_COMPAT", rid.get("identity_match_is_not_compatibility") is True)
    check("I015_COMPAT_NOT_EXEC", rid.get("compatibility_is_not_execution_authority") is True)
    check("I016_ADAPTER_INTERFACE", adapter.get("abstract_interface") == "SecurityWorkerRuntime")
    check("I017_ADAPTER_TYPES_SCHEMA_ONLY", adapter.get("adapter_type_is_not_availability_claim") is True)
    check("I018_NO_GENERIC_ENDPOINT", adapter.get("generic_command_or_code_endpoint") == "PROHIBITED")
    check("I019_NO_PROVIDER_ARGV_CORE", adapter.get("provider_specific_argv_in_core") == "PROHIBITED")
    check("I020_BINARY_PIN", set(["EXACT_VERSION", "EXACT_BINARY_SHA256", "EXACT_INSTALLATION_METHOD", "EXACT_TARGET_PLATFORM", "EXACT_PACKAGE_METADATA", "EXACT_CONFIGURATION_SHA256"]).issubset(pin.get("binary_runtime_requirements", [])))
    check("I021_MODEL_PIN", "EXACT_MODEL_IDENTITY" in pin.get("model_runtime_requirements", []) and "DATED_AVAILABILITY_EVIDENCE" in pin.get("model_runtime_requirements", []))
    check("I022_NO_LATEST", pin.get("moving_alias_or_latest") == "PROHIBITED")
    check("I023_DIGEST_NOT_SUFFICIENT", pin.get("binary_digest_or_model_identity_alone_is_sufficient") is False)
    check("I024_CONFIG_FIELDS", len(config.get("required", [])) == 10)
    check("I025_CONFIG_SECRET_POLICY", config.get("secret_values_in_contract_or_evidence") == "PROHIBITED")
    check("I026_CONFIG_FAIL_CLOSED", config.get("missing_required_setting") == "NOT_COMPATIBLE_FAIL_CLOSED")
    check("I027_CAPABILITY_STATES", caps.get("capability_states") == ["UNCLAIMED", "UPSTREAM_CLAIM", "IDENTITY_SUPPORTED", "COMPATIBILITY_TESTED", "PASS_LOCKED"])
    check("I028_CAPABILITY_CLAIM_NOT_EVIDENCE", caps.get("upstream_claim_is_compatibility_evidence") is False)
    check("I029_CAPABILITY_UNKNOWN_FAIL", caps.get("unknown_capability") == "FAIL_CLOSED_NOT_AVAILABLE")
    check("I030_IO_FIELDS", len(io.get("input_required_fields", [])) == 11 and len(io.get("output_required_fields", [])) == 10)
    check("I031_IO_NO_PROSE", io.get("free_form_prose_authoritative") is False)
    check("I032_IO_UNKNOWN_REJECT", io.get("unknown_input_or_output_field") == "REJECT")
    check("I033_OUTPUT_NO_AUTHORITY", io.get("model_output_can_grant_authority") is False)
    check("I034_TOOLS_DEFAULT_NONE", tools.get("default") == "NO_TOOLS")
    check("I035_TOOLS_TYPED", tools.get("typed_requests_only") is True)
    check("I036_TOOLS_DANGEROUS_DENIED", tools.get("generic_shell_python_code_raw_args_or_package_install") == "PROHIBITED")
    check("I037_TOOLS_CREDENTIAL_NETWORK_SEPARATE", tools.get("credential_or_network_tooling") == "REQUIRES_SEPARATE_EXACT_AUTHORIZATION")
    check("I038_SANDBOX_V5", sandbox.get("substrate_identity") == "RUNTIME_SUBSTRATE_V5_PASS_LOCKED")
    check("I039_SANDBOX_NO_WEAKEN", sandbox.get("runtime_or_adapter_cannot_weaken_substrate") is True)
    check("I040_SANDBOX_NO_FALLBACK", "FAIL_CLOSED_NO_UNSANDBOXED_FALLBACK" in sandbox.get("requirements", []))
    check("I041_FAILURE_TERMINAL", failure.get("mandatory_failure_result") == "FAIL_CLOSED")
    check("I042_FAILURE_EVIDENCE", failure.get("missing_evidence_result") == "BLOCKED_NO_PASS")
    check("I043_NO_RETRY", failure.get("automatic_retry") == "PROHIBITED")
    check("I044_NO_PATCH_RELOCK", failure.get("patch_relock_or_reclassify_consumed_identity") == "PROHIBITED")
    check("I045_EVIDENCE_BINDINGS", len(evidence.get("required_bindings", [])) >= 20)
    check("I046_EVIDENCE_APPEND_ONLY", evidence.get("append_only") is True and evidence.get("digest_bound") is True and evidence.get("provenance_bound") is True)
    check("I047_EVIDENCE_NO_SECRET", evidence.get("secret_material_in_evidence") == "PROHIBITED")
    check("I048_EVIDENCE_INCOMPLETE_NO_PASS", evidence.get("incomplete_evidence") == "NO_PASS")
    cases = suite.get("cases", [])
    check("I049_SUITE_DEFINED_ONLY", suite.get("status") == "DEFINED_NOT_AUTHORIZED_NOT_EXECUTED")
    check("I050_SUITE_COUNT", suite.get("case_count") == len(cases) == 18)
    check("I051_SUITE_UNIQUE", len({case.get("case_id") for case in cases}) == 18)
    check("I052_SUITE_ALL_MANDATORY", suite.get("all_mandatory") is True and all(case.get("evidence_required") is True for case in cases))
    check("I053_SUITE_SEPARATE_GOV", suite.get("execution_requires_separate_governance") is True)
    check("I054_SUITE_NO_SHARED_IDENTITY", suite.get("no_shared_attempt_between_distinct_runtime_identities") is True)
    check("I055_AUTH_PUBLICATION", authority.get("contract_publication_authorized") is True)
    for index, field in enumerate(FALSE_FIELDS, start=56):
        check(f"I{index:03d}_{field.upper()}_FALSE", authority.get(field) is False)
    counters = authority.get("operation_counters", {})
    check("I073_COUNTER_KEYS", set(counters) == OPERATION_KEYS)
    check("I074_COUNTERS_ZERO", all(value == 0 for value in counters.values()))
    check("I075_TYPED_STRUCTURAL_COUNTS", authority.get("structural_counts") == {"contract_publication_event_count": 1, "suite_definition_case_count": 18})
    check("I076_PASS_NO_COMPAT", authority.get("contract_pass_is_not_compatibility_pass") is True)
    check("I077_COMPAT_NO_WORKER", authority.get("compatibility_pass_is_not_worker_execution_authority") is True)
    check("I078_UPGRADE_CANDIDATE", upgrade.get("new_version_or_model_state") == "CANDIDATE_ONLY")
    check("I079_UPGRADE_NO_AUTO", upgrade.get("automatic_update") == "PROHIBITED")
    check("I080_UPGRADE_SUCCESSOR", len(upgrade.get("required_successor_steps", [])) == 8)
    check("I081_CODEX_VERSION", codex.get("version") == "0.162.1")
    check("I082_CODEX_CANDIDATE", codex.get("status") == "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED")
    check("I083_CODEX_CONFIG_BLOCK", codex.get("configuration_compliance") == "ABSENT_NOT_COMPLIANT")
    check("I084_CODEX_ZERO", codex.get("invocation_count") == 0 and codex.get("invocation_authorized") is False)
    check("I085_CODEX_NOT_TESTED", codex.get("compatibility_suite_executed") is False and codex.get("authoritative_runtime") is False)
    check("I086_DAYBREAK_NOT_DISCOVERED", future.get("daybreak", {}).get("discovery_state") == "NOT_DISCOVERED")
    check("I087_DAYBREAK_NOT_ASSUMED", future.get("daybreak", {}).get("availability") == "NOT_ASSUMED" and future.get("daybreak", {}).get("access") == "NOT_ASSUMED")
    check("I088_DAYBREAK_UNBOUND", future.get("daybreak", {}).get("provider") == "UNBOUND" and future.get("daybreak", {}).get("model_identity") == "UNBOUND" and future.get("daybreak", {}).get("endpoint") == "UNBOUND")
    check("I089_DAYBREAK_ZERO", future.get("daybreak", {}).get("invocation_count") == 0 and future.get("daybreak", {}).get("invocation_authorized") is False)
    check("I090_FUTURE_UNBOUND", future.get("future_runtime", {}).get("availability") == "NOT_ASSUMED" and future.get("future_runtime", {}).get("identity") == "UNBOUND")
    check("I091_PREDECESSOR_AUTH", predecessor.get("publication_authorization", {}).get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("I092_PREDECESSOR_V5", predecessor.get("runtime_substrate_v5", {}).get("status") == "PASS_LOCKED")
    check("I093_PREDECESSOR_IMMUTABLE", predecessor.get("predecessor_mutation") == "PROHIBITED")
    check("I094_ROUTING_NO_OPERATION", routing.get("subagents") == "NOT_USED" and routing.get("network") == "NOT_USED" and routing.get("runtime_or_model_invocations") == 0)
    check("I095_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0 and primary.get("checks_total") == primary.get("checks_passed"))
    check("I096_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 40 and negative.get("tests_failed") == 0)
    check("I097_RESULT_COUNTER_PARITY", primary.get("operation_counters") == negative.get("operation_counters") == counters)
    schemas = ["RUNTIME_IDENTITY.schema.json", "RUNTIME_ADAPTER_IDENTITY.schema.json", "STRUCTURED_INPUT.schema.json", "STRUCTURED_OUTPUT.schema.json", "COMPATIBILITY_CASE.schema.json", "AUTHORITY_STATE.schema.json"]
    check("I098_SCHEMA_STRICT", all(load(name).get("additionalProperties") is False for name in schemas))
    check("I099_SCHEMA_IDS_UNIQUE", len({load(name).get("$id") for name in schemas}) == 6)
    check("I100_NEGATIVE_RESULTS_EXPLICIT", all(item.get("actual") == "REJECT" and item.get("status") == "PASS" for item in negative.get("results", [])))
    check("I101_HISTORICAL_RUN1_PRESERVED", historical_primary_1.get("run_id") == "PRIMARY_STATIC_VALIDATION_RUN-0001" and historical_primary_1.get("status") == "FAIL_CLOSED" and historical_primary_1.get("checks_failed") == 1 and historical_negative_1.get("status") == "PASS")
    check("I102_HISTORICAL_RUN2_PRESERVED", historical_primary_2.get("run_id") == "PRIMARY_STATIC_VALIDATION_RUN-0002" and historical_primary_2.get("status") == "FAIL_CLOSED" and historical_primary_2.get("checks_failed") == 1 and historical_negative_2.get("status") == "FAIL_CLOSED" and historical_negative_2.get("tests_failed") == 1)
    check("I103_SUCCESSOR_RUN_IDS", primary.get("run_id") == "PRIMARY_STATIC_VALIDATION_RUN-0003" and negative.get("run_id") == "NEGATIVE_CONTRACT_FIXTURE_RESULT_RUN-0003")

    failed = [item for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_INDEPENDENT_VALIDATION", "schema_version": "1.0",
        "contract_identity": IDENTITY, "run_id": "INDEPENDENT_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "checks": checks, "independence": "SEPARATE_IMPLEMENTATION_NO_IMPORT_FROM_PRIMARY",
        "operation_counters": counters,
    }
    with output.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"status": result["status"], "checks": len(checks), "failed": len(failed)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
