#!/usr/bin/env python3
"""Read-only final verification of the frozen V2 bind-source erratum package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import stat
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
V1 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016"
V2 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016"
V3 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v3-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE_AND_INCOMPLETE_CONFINEMENT_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V3_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
V3_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
OPERATION_KEYS = (
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "containment_fixture_attempts", "exploit_replays",
    "external_network_operations", "parallel_operations",
    "real_worker_processes", "runtime_validation_attempts",
    "subagent_processes", "submission_operations", "target_operations",
)
EXPECTED_FILES = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_AND_V2_EVIDENCE_BINDING.json",
    "RUNTIME_VALIDATION_V2_TERMINAL_DISPOSITION.json", "BIND_SOURCE_NAMESPACE_RESOLUTION_ROOT_CAUSE.json",
    "DEFECT_OWNERSHIP_DECISION.json", "PARTIAL_EVIDENCE_ADMISSIBILITY.json",
    "RESOURCE_FEASIBILITY_PRESERVATION_DECISION.json", "BIND_SOURCE_NAMESPACE_MODEL.json",
    "BIND_SOURCE_RESOLUTION_PRECHECK_CONTRACT.json", "SEMANTIC_ARGV_VALIDATOR_V3_REQUIREMENTS.json",
    "RUNTIME_VALIDATION_V3_IDENTITY_AND_PATH_BINDING.json", "RUNTIME_VALIDATION_V3_SUCCESSOR_AUTHORIZATION_DECISION.json",
    "V3_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json", "V3_SINGLE_USE_EXECUTION_CONTRACT.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_TEST_RESULT.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "INDEPENDENT_VALIDATION_RESULT.json", "FREEZE_VERIFICATION_RESULT.json",
    "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{item['sha256']}  {item['path']}\n" for item in sorted(rows, key=lambda item: str(item["path"]))).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def zero_typed(value: dict[str, Any]) -> bool:
    counters = value.get("operation_counters")
    return isinstance(counters, dict) and set(counters) == set(OPERATION_KEYS) and all(counters[key] == 0 for key in OPERATION_KEYS)


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    manifest = load("GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load("GOVERNANCE_LOCK.json")
    members = manifest.get("members", [])
    check("F001_EXACT_FILE_SET", actual == EXPECTED_FILES, {"extra": sorted(actual-EXPECTED_FILES), "missing": sorted(EXPECTED_FILES-actual)})
    check("F002_NO_SYMLINKS", all(not path.is_symlink() for path in ROOT.iterdir()))
    check("F003_ALL_FILES_READ_ONLY", all(ro(path) for path in ROOT.iterdir() if path.is_file()))
    check("F004_DIRECTORY_READ_ONLY", ro(ROOT))
    check("F005_IDENTITY", manifest.get("governance_identity") == lock.get("governance_identity") == IDENTITY)
    check("F006_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F007_DECISION", lock.get("decision") == "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V3_CONDITIONALLY")
    check("F008_MANIFEST_MEMBER_COUNT", manifest.get("member_count") == len(members) == 26)
    check("F009_ROOT_MEMBER_COUNT", lock.get("root_member_count") == 27)
    listed = {str(item.get("path", "")) for item in members}
    check("F010_MANIFEST_COVERAGE", listed == EXPECTED_FILES - {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"})
    check("F011_LOCK_EXCLUDED", "GOVERNANCE_LOCK.json" not in listed)
    check("F012_MANIFEST_EXCLUDED", "GOVERNANCE_ARTIFACT_MANIFEST.json" not in listed)
    member_ok = True
    for item in members:
        path = ROOT / str(item.get("path", ""))
        member_ok = member_ok and path.is_file() and not path.is_symlink() and ro(path) and path.stat().st_size == item.get("bytes") and sha(path) == item.get("sha256")
    check("F013_MEMBER_BYTES", member_ok)
    member_root = rows_root(members)
    check("F014_MEMBER_ROOT", member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256"))
    manifest_hash = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    check("F015_MANIFEST_SHA", manifest_hash == lock.get("governance_manifest_sha256"))
    artifact_root = rows_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_hash, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    check("F016_ARTIFACT_ROOT", artifact_root == lock.get("canonical_artifact_root_sha256"))
    check("F017_STRUCTURAL_COUNTS", lock.get("structural_counts") == {"manifest_members": 26, "root_members": 27})

    disposition = load("RUNTIME_VALIDATION_V2_TERMINAL_DISPOSITION.json")
    root_cause = load("BIND_SOURCE_NAMESPACE_RESOLUTION_ROOT_CAUSE.json")
    ownership = load("DEFECT_OWNERSHIP_DECISION.json")
    partial = load("PARTIAL_EVIDENCE_ADMISSIBILITY.json")
    resource = load("RESOURCE_FEASIBILITY_PRESERVATION_DECISION.json")
    model = load("BIND_SOURCE_NAMESPACE_MODEL.json")
    precheck = load("BIND_SOURCE_RESOLUTION_PRECHECK_CONTRACT.json")
    validator = load("SEMANTIC_ARGV_VALIDATOR_V3_REQUIREMENTS.json")
    binding = load("RUNTIME_VALIDATION_V3_IDENTITY_AND_PATH_BINDING.json")
    successor = load("RUNTIME_VALIDATION_V3_SUCCESSOR_AUTHORIZATION_DECISION.json")
    gates = load("V3_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json")
    single = load("V3_SINGLE_USE_EXECUTION_CONTRACT.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
    next_gate = load("NEXT_LEGAL_MILESTONE.json")
    primary = load("GOVERNANCE_TEST_RESULT.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT.json")
    freeze = load("FREEZE_VERIFICATION_RESULT.json")

    check("F018_V2_TERMINAL", disposition.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY")
    check("F019_V2_ATTEMPT", disposition.get("attempt_count") == disposition.get("maximum_attempts") == lock.get("v2_attempt_count") == 1)
    check("F020_V2_PROHIBITIONS", disposition.get("retry_authorized") is False and disposition.get("patch_in_place_authorized") is False and disposition.get("relock_same_identity_authorized") is False and disposition.get("promotion_authorized") is False)
    check("F021_ROOT_CAUSE", root_cause.get("classification") == lock.get("root_cause") == "CONFIRMED_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE")
    facts = root_cause.get("confirmed_facts", {})
    check("F022_RESOURCE_PRECHECK_WORKED", facts.get("resource_limit_feasibility_precheck") == "PASS")
    check("F023_OFFENDING_SOURCE", facts.get("offending_source") == "/run/v0-3-runtime-substrate-source-v2/empty-home")
    check("F024_OFFENDING_DESTINATION", facts.get("offending_destination") == "/home/nobcoder")
    check("F025_SOURCE_CLASS", facts.get("source_namespace_class") == "FUTURE_CONSTRUCTED_SANDBOX_PATH")
    check("F026_CALLER_SOURCE_ABSENT", facts.get("source_exists_in_caller_namespace") is False)
    check("F027_BWRAP_OBSERVED", facts.get("bubblewrap_execve_observed") is True)
    check("F028_FIXTURE_NOT_EXECUTED", facts.get("fixture_python_execve_observed") is False)
    check("F029_OWNERSHIP", ownership.get("decision") == lock.get("defect_ownership"))
    check("F030_ARGV_DEFECT", ownership.get("execution_argv_construction_defect") is lock.get("execution_argv_construction_defect") is True)
    check("F031_VALIDATOR_GAP", ownership.get("semantic_argv_validator_coverage_gap") is lock.get("semantic_argv_validator_coverage_gap") is True)
    check("F032_RESOURCE_NOT_DEFECT", ownership.get("resource_limit_feasibility_defect") is lock.get("resource_limit_feasibility_defect") is False)
    check("F033_CONTROL_PLANE_NOT_DEFECT", ownership.get("control_plane_v2_defect") is lock.get("control_plane_v2_defect") is False)
    check("F034_NO_BYPASS", ownership.get("containment_bypass") is lock.get("containment_bypass") is False)
    check("F035_CONFINEMENT_NOT_PROVEN", partial.get("confinement") == lock.get("confinement") == "NOT_PROVEN")
    check("F036_PARTIAL_ONLY", partial.get("trace_coverage") == "PARTIAL_ONLY_BWRAP_STARTUP")
    check("F037_RESOURCE_FRESH_V3", resource.get("v3_requirement") == "FRESH_CONTEXT_MEASUREMENT_AND_INDEPENDENT_VALIDATION")
    check("F038_MODEL_CALLER", model.get("classes", {}).get("CALLER_NAMESPACE_EXISTING_PATH", "").startswith("MAY_BE_ELIGIBLE"))
    check("F039_MODEL_FUTURE_REJECT", model.get("classes", {}).get("FUTURE_CONSTRUCTED_SANDBOX_PATH") == "PROHIBITED_AS_BIND_SOURCE")
    check("F040_MODEL_UNKNOWN_FAIL", model.get("classes", {}).get("UNKNOWN") == "FAIL_CLOSED")
    check("F041_PRECHECK_REQUIRED", precheck.get("required") is True)
    check("F042_PRECHECK_ORDER", precheck.get("ordering", [])[-2:] == ["ONLY_THEN_WRITE_ATTEMPT_MARKER", "ONLY_THEN_LAUNCH_EXACT_CHILD"])
    check("F043_PRECHECK_NO_CONSUME", precheck.get("failure") == "STOP_BEFORE_ATTEMPT_MARKER_ATTEMPT_REMAINS_ZERO")
    check("F044_VALIDATOR_TYPED", "TYPE_EACH_BIND_SOURCE_AND_DESTINATION" in validator.get("requirements", []))
    check("F045_VALIDATOR_NO_SUBSTRING", validator.get("substring_or_raw_path_occurrence_counting") == "PROHIBITED")
    check("F046_V3_DECISION", successor.get("decision") == lock.get("decision") == "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V3_CONDITIONALLY")
    check("F047_V3_STATE", successor.get("status") == lock.get("v3_state") == "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F048_V3_IDENTITY", successor.get("execution_identity") == binding.get("execution_identity") == lock.get("v3_identity") == V3_IDENTITY)
    check("F049_V3_OPERATION", successor.get("operation") == binding.get("operation") == lock.get("v3_operation") == V3_OPERATION)
    check("F050_V3_PATH", binding.get("workspace") == lock.get("v3_workspace") == str(V3) and not V3.exists() and not V3.is_symlink())
    check("F051_V3_ATTEMPT_ZERO", successor.get("attempt_count") == binding.get("attempt_count") == lock.get("v3_attempt_count") == 0)
    check("F052_BOTH_PRECHECKS", successor.get("resource_limit_feasibility_precheck") == lock.get("resource_limit_feasibility_precheck") == "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION" and successor.get("bind_source_resolution_precheck") == lock.get("bind_source_resolution_precheck") == "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION")
    check("F053_GATE_BOTH_PRECHECKS", gates.get("attempt_marker_gate") == "BOTH_RESOURCE_AND_BIND_SOURCE_PRECHECKS_MUST_PASS_WITHIN_FRESHNESS_WINDOW")
    check("F054_SINGLE_USE", single.get("maximum_attempts") == 1 and single.get("automatic_retry") is False)
    check("F055_SUCCESS_CEILING", single.get("success_ceiling") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION")
    check("F056_GOVERNANCE_ONLY", authority.get("governance_only") is True and lock.get("runtime_or_fixture_execution_authorized_in_this_milestone") is False)
    check("F057_DEFAULT_DENY", matrix.get("default") == "DENY")
    check("F058_NO_V3_THIS_MILESTONE", matrix.get("operations", {}).get("CREATE_OR_EXECUTE_V3_DURING_THIS_GOVERNANCE") == "NOT_AUTHORIZED")
    check("F059_V2_PROHIBITED", matrix.get("operations", {}).get("PATCH_RELOCK_RETRY_OR_PROMOTE_V2") == "PROHIBITED")
    check("F060_DEFERRED_CAPABILITIES", all(matrix.get("operations", {}).get(key) == "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION" for key in ("CODEX_DAYBREAK_WORKER_SUBAGENT", "KERNEL_SANDBOX_PWNESCAPE_REPLAY", "TARGET_NETWORK_PARALLEL_CAPABILITY_FULL_CHAIN_SUBMISSION")))
    check("F061_NEXT_MILESTONE", next_gate.get("milestone") == lock.get("next_milestone"))
    check("F062_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_total") == primary.get("checks_passed") == 58 and primary.get("checks_failed") == 0)
    check("F063_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 36 and negative.get("tests_failed") == 0)
    check("F064_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_total") == independent.get("checks_passed") == 78 and independent.get("checks_failed") == 0)
    check("F065_FREEZE_CANDIDATE", freeze.get("status") == "PASS_CANDIDATE_PRE_FINAL_FREEZE" and all(freeze.get("checks", {}).values()))
    check("F066_ZERO_LOCK_COUNTERS", zero_typed(lock))
    check("F067_ZERO_PRIMARY_COUNTERS", zero_typed(primary))
    check("F068_ZERO_NEGATIVE_COUNTERS", zero_typed(negative))
    check("F069_ZERO_INDEPENDENT_COUNTERS", zero_typed(independent))
    check("F070_ZERO_FREEZE_COUNTERS", zero_typed(freeze))
    check("F071_VALIDATION_COUNTS", lock.get("validation_counts") == {"governance": {"total": 58, "passed": 58, "failed": 0}, "negative": {"total": 36, "passed": 36, "failed": 0}, "independent": {"total": 78, "passed": 78, "failed": 0}})
    check("F072_V2_STATIC_LOCK_UNCHANGED", sha(V2 / "locks/STATIC_EXECUTION_LOCK.json") == "6bb19fcd71f5378900c87003f088677366f98dff2c972c7a08e303ed7c55fbcc")
    check("F073_V2_TERMINAL_UNCHANGED", sha(V2 / "evidence-v2/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == "9891e7d5c9ff9e66689238b6640683ea34b2572cb44c1c31162dcd0cacd91b27")
    check("F074_V2_EVIDENCE_LOCK_UNCHANGED", sha(V2 / "evidence-v2/EVIDENCE_FREEZE_LOCK.json") == "d66e1c2cc53c850ae6e3f88afd60cb074448e267f72fd3a09f4313b3bf62d12c")
    check("F075_V2_READ_ONLY", all(ro(path) for path in V2.rglob("*") if path.is_file()))
    check("F076_V1_STATIC_LOCK_UNCHANGED", sha(V1 / "locks/STATIC_EXECUTION_LOCK.json") == "56e279a86749d756aa33d4a9c68c5c4d4609feb8d1ee1d2c449873c507d28d8e")
    check("F077_V1_TERMINAL_UNCHANGED", sha(V1 / "evidence-v1/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == "1943e30b28c726d79ba566b6a1d76bbe5d44e6fbd557671cfb7d56cbe7040fc5")
    check("F078_AUTHORITY_CEILING", all(lock.get(key) is False for key in ("runtime_or_fixture_execution_authorized_in_this_milestone", "worker_model_subagent_authorized", "target_network_authorized", "exploit_replay_authorized", "parallel_capability_full_chain_authorized", "candidate_promotion_or_submission_authorized")))

    failed = [item for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_FINAL_FREEZE_VERIFICATION",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed),
        "failed": failed,
        "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"),
        "governance_manifest_sha256": manifest_hash,
        "canonical_artifact_root_sha256": artifact_root,
        "operation_counters": lock.get("operation_counters"),
    }
    print(json.dumps(result, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
