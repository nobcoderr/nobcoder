#!/usr/bin/env python3
"""Build the Runtime Validation V2 bind-source erratum governance package.

This program is intentionally governance-only.  It reads frozen V1/V2 evidence
and writes new records only in this new governance directory.  It never invokes
bubblewrap, strace, a runtime fixture, Codex, a worker, a target, or a network.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
PREDECESSOR = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v1-launcher-process-limit-incompatibility-and-incomplete-evidence-erratum-and-successor-decision-governance-v1-20261016"
V1 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016"
V2 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016"
V3 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v3-20261016"

IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE_AND_INCOMPLETE_CONFINEMENT_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V2_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
V2_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
V3_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
V3_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
NEXT_MILESTONE = "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V3_THEN_EXECUTE_RUNTIME_VALIDATION_V3_ONCE_IF_ALL_GATES_PASS"
OFFENDING_SOURCE = "/run/v0-3-runtime-substrate-source-v2/empty-home"
OFFENDING_DESTINATION = "/home/nobcoder"

EXPECTED = {
    "predecessor_lock": "f9f5c895f34e7096155fe553aae51e3e30fc43591c36e8845655c817538e23ba",
    "predecessor_manifest": "6b7f6ecca77e07697be5712bbeeb7a322cdbf09132df8a9faf33bb151c4aafb9",
    "predecessor_root": "79da522e0f44d3e24e2e7b292d9726c24b424474375fe4ef2d559c95d2914a89",
    "v2_source_manifest": "88098fe876614ead43438ce1c26a0c13a63da57fbc8c3c54d4bce85ddc06022c",
    "v2_source_root": "fa87ee853b351710330dbfaaec6b56f6e6a7f443b9e4a06ddf17b58a90617394",
    "v2_static_lock": "6bb19fcd71f5378900c87003f088677366f98dff2c972c7a08e303ed7c55fbcc",
    "v2_lock_verification": "ab669ccf7cd52a5f8f1b773129c2b53f4a78a095a78605718fa84ad3bcd5d82e",
    "v2_exact_contract": "81e0683e19981eda78675b49b2ee1d16851338daabee6bc7e040f4c13b43cc3d",
    "v2_argv_validator": "5770499a98f287dc8eb4c299574b654a514e3d42c2791f19c318b9c8749181aa",
    "v2_resource_validator": "db4d07798189205df02edf0591951472545474b908e86750fc59533486c745c4",
    "v2_runner": "5fb9ad5a4a56d732a65343e214c19dbb84ea44ec790d46201354da2112b3287d",
    "v2_resource_precheck": "a17f03080db2876124d2498830efe345440d70e6d62722ed0c4ec729ed72c879",
    "v2_attempt": "e4e1bc8a60b7c70edc6c10354cb98c33f318641862a12d1918c9332ec951e0da",
    "v2_child_exit": "63fb7399f8b6c4023374971ffe158dcf941ad4492a8c95b248de140232ce13e6",
    "v2_terminal": "9891e7d5c9ff9e66689238b6640683ea34b2572cb44c1c31162dcd0cacd91b27",
    "v2_post_incomplete": "e30dffab68e82ca4ce7d67cec531c1d6c5ed0874e4195699610e156e33be91df",
    "v2_stderr": "10f8b0556f98333f39a2386ea4d8893f6745f3a8ab704d33de9b6525b0e77031",
    "v2_trace_parent": "8d78aabfe0b8d29082f33e04d248663adea253052d6a2d48c419afe1ffeaab49",
    "v2_trace_child": "2f5cbe927fb16c33785448a3a2265bbd6075007b482bff8c4ac81f604ae013f6",
    "v2_evidence_manifest": "4559708d56d6db4da1aba2ed95ae5bea1b9326f95b8c2f78ab1f294b9fe21fdb",
    "v2_evidence_lock": "d66e1c2cc53c850ae6e3f88afd60cb074448e267f72fd3a09f4313b3bf62d12c",
    "v2_evidence_root": "a57987796d33f2be80a6644fea3f65d16a5400cee5afa34a5d2deb1d18afb931",
    "v2_freeze_result": "60e3b2a95ff8d32f23a130d7b1105437403043d7cf968b11b1aa34c7f2b623f1",
    "v1_static_lock": "56e279a86749d756aa33d4a9c68c5c4d4609feb8d1ee1d2c449873c507d28d8e",
    "v1_terminal": "1943e30b28c726d79ba566b6a1d76bbe5d44e6fbd557671cfb7d56cbe7040fc5",
    "v1_evidence_lock": "794b016bb866f52f5ac0afc4da4b8ff738ac0f2ff31ad8ea46fa6c41203697e0",
}

OPERATION_KEYS = (
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "containment_fixture_attempts", "exploit_replays",
    "external_network_operations", "parallel_operations",
    "real_worker_processes", "runtime_validation_attempts",
    "subagent_processes", "submission_operations", "target_operations",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def dump_exclusive(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(
        f"{item['sha256']}  {item['path']}\n"
        for item in sorted(rows, key=lambda item: str(item["path"]))
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_only(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def zero_operations() -> dict[str, int]:
    return {key: 0 for key in OPERATION_KEYS}


def verify_governance(path: Path, expected_root: str) -> bool:
    manifest_path = path / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    lock_path = path / "GOVERNANCE_LOCK.json"
    manifest = load(manifest_path)
    lock = load(lock_path)
    members = manifest.get("members")
    if not isinstance(members, list):
        return False
    for item in members:
        member = path / str(item.get("path", ""))
        if not member.is_file() or member.is_symlink():
            return False
        if member.stat().st_size != item.get("bytes") or sha(member) != item.get("sha256"):
            return False
    member_root = rows_root(members)
    manifest_hash = sha(manifest_path)
    artifact_root = rows_root(members + [{
        "path": manifest_path.name,
        "sha256": manifest_hash,
        "bytes": manifest_path.stat().st_size,
    }])
    return (
        member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256")
        and manifest_hash == lock.get("governance_manifest_sha256")
        and artifact_root == lock.get("canonical_artifact_root_sha256") == expected_root
    )


def verify_member_manifest(root: Path, manifest_path: Path, root_key: str, expected_root: str) -> bool:
    manifest = load(manifest_path)
    members = manifest.get("members")
    if not isinstance(members, list):
        return False
    for item in members:
        member = root / str(item.get("path", ""))
        if not member.is_file() or member.is_symlink() or not read_only(member):
            return False
        if member.stat().st_size != item.get("bytes") or sha(member) != item.get("sha256"):
            return False
    return rows_root(members) == manifest.get(root_key) == expected_root


def add_check(checks: list[dict[str, Any]], check_id: str, passed: bool, evidence: Any = None) -> None:
    checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})


def is_canonical_absolute(value: str) -> bool:
    if not value.startswith("/"):
        return False
    pure = PurePosixPath(value)
    return str(pure) == value and ".." not in pure.parts and "." not in pure.parts


def parse_mount_operations(argv: list[str]) -> list[dict[str, Any]]:
    try:
        index = argv.index("/usr/bin/bwrap") + 1
    except ValueError as exc:
        raise ValueError("bubblewrap executable missing") from exc
    no_operand = {
        "--unshare-user", "--unshare-pid", "--unshare-net", "--unshare-ipc",
        "--unshare-uts", "--die-with-parent", "--new-session", "--clearenv",
    }
    one = {"--cap-drop", "--tmpfs", "--dir", "--proc", "--dev", "--chdir", "--remount-ro"}
    two = {"--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try", "--setenv"}
    mount_options = {"--tmpfs", "--dir", "--proc", "--dev", "--remount-ro", "--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try"}
    operations: list[dict[str, Any]] = []
    while index < len(argv):
        token = argv[index]
        if not token.startswith("--"):
            break
        option_index = index
        index += 1
        if token in no_operand:
            continue
        arity = 1 if token in one else 2 if token in two else None
        if arity is None or index + arity > len(argv):
            raise ValueError(f"unknown or malformed option: {token}")
        operands = argv[index:index + arity]
        if any(item.startswith("--") for item in operands):
            raise ValueError(f"option-like operand for {token}")
        if token in mount_options:
            operations.append({"option": token, "operands": operands, "argv_index": option_index})
        index += arity
    return operations


def classify_bind_sources(operations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    future_destinations: set[str] = set()
    result: list[dict[str, Any]] = []
    for item in operations:
        option = str(item["option"])
        operands = [str(value) for value in item["operands"]]
        if option in {"--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try"}:
            source, destination = operands
            source_path = Path(source)
            if source_path.exists() or source == "/":
                source_class = "CALLER_NAMESPACE_EXISTING_PATH"
            elif any(source == dest or source.startswith(dest.rstrip("/") + "/") for dest in future_destinations):
                source_class = "FUTURE_CONSTRUCTED_SANDBOX_PATH"
            else:
                source_class = "CALLER_NAMESPACE_MISSING_PATH"
            result.append({
                "option": option,
                "source": source,
                "destination": destination,
                "argv_index": item["argv_index"],
                "source_namespace_class": source_class,
                "caller_namespace_exists": source_path.exists() or source == "/",
            })
            future_destinations.add(destination)
        elif option in {"--tmpfs", "--dir", "--proc", "--dev"}:
            future_destinations.add(operands[-1])
    return result


def source_policy(case: dict[str, Any]) -> bool:
    return (
        case.get("source_namespace_class") == "CALLER_NAMESPACE_EXISTING_PATH"
        and case.get("exists_before_attempt") is True
        and case.get("exists_before_child_launch") is True
        and case.get("absolute") is True
        and case.get("canonical") is True
        and case.get("symlink") is False
        and case.get("type_matches") is True
        and case.get("identity_bound") is True
        and case.get("destination_absolute") is True
        and case.get("destination_canonical") is True
    )


def negative_matrix() -> list[dict[str, Any]]:
    valid = {
        "source_namespace_class": "CALLER_NAMESPACE_EXISTING_PATH",
        "exists_before_attempt": True,
        "exists_before_child_launch": True,
        "absolute": True,
        "canonical": True,
        "symlink": False,
        "type_matches": True,
        "identity_bound": True,
        "destination_absolute": True,
        "destination_canonical": True,
    }
    cases: list[tuple[str, dict[str, Any], str]] = [
        ("N001_VALID_CALLER_SOURCE", {}, "PASS"),
        ("N002_VALID_ROOT_SOURCE", {}, "PASS"),
        ("N003_VALID_READ_ONLY_DIRECTORY_SOURCE", {}, "PASS"),
        ("N004_VALID_WRITABLE_RUN_SOURCE", {}, "PASS"),
        ("N005_FUTURE_SANDBOX_SOURCE", {"source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH"}, "REJECT"),
        ("N006_MISSING_CALLER_SOURCE", {"source_namespace_class": "CALLER_NAMESPACE_MISSING_PATH"}, "REJECT"),
        ("N007_SOURCE_ABSENT_BEFORE_ATTEMPT", {"exists_before_attempt": False}, "REJECT"),
        ("N008_SOURCE_ABSENT_BEFORE_LAUNCH", {"exists_before_child_launch": False}, "REJECT"),
        ("N009_RELATIVE_SOURCE", {"absolute": False}, "REJECT"),
        ("N010_NONCANONICAL_SOURCE", {"canonical": False}, "REJECT"),
        ("N011_SOURCE_SYMLINK", {"symlink": True}, "REJECT"),
        ("N012_WRONG_SOURCE_TYPE", {"type_matches": False}, "REJECT"),
        ("N013_UNBOUND_SOURCE_IDENTITY", {"identity_bound": False}, "REJECT"),
        ("N014_RELATIVE_DESTINATION", {"destination_absolute": False}, "REJECT"),
        ("N015_NONCANONICAL_DESTINATION", {"destination_canonical": False}, "REJECT"),
        ("N016_SOURCE_DESTINATION_CONFUSION", {"source_namespace_class": "SANDBOX_DESTINATION"}, "REJECT"),
        ("N017_V2_EXACT_FAILURE", {"source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH", "exists_before_attempt": False, "exists_before_child_launch": False}, "REJECT"),
        ("N018_TMPFS_CHILD_AS_SOURCE", {"source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH"}, "REJECT"),
        ("N019_DIR_CREATED_LATER_AS_SOURCE", {"source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH"}, "REJECT"),
        ("N020_EARLIER_BIND_DEST_CHILD_AS_SOURCE", {"source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH"}, "REJECT"),
        ("N021_BIND_TRY_FUTURE_SOURCE", {"source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH"}, "REJECT"),
        ("N022_DEV_BIND_FUTURE_SOURCE", {"source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH"}, "REJECT"),
        ("N023_RO_BIND_TRY_MISSING_SOURCE", {"source_namespace_class": "CALLER_NAMESPACE_MISSING_PATH"}, "REJECT"),
        ("N024_DEV_BIND_TRY_MISSING_SOURCE", {"source_namespace_class": "CALLER_NAMESPACE_MISSING_PATH"}, "REJECT"),
        ("N025_STALE_EXISTENCE_PROOF", {"exists_before_child_launch": False}, "REJECT"),
        ("N026_SOURCE_REPLACED_BY_SYMLINK", {"symlink": True}, "REJECT"),
        ("N027_SOURCE_IDENTITY_DRIFT", {"identity_bound": False}, "REJECT"),
        ("N028_SOURCE_DIRECTORY_BECOMES_FILE", {"type_matches": False}, "REJECT"),
        ("N029_PATH_TRAVERSAL_SOURCE", {"canonical": False}, "REJECT"),
        ("N030_PATH_ALIAS_SOURCE", {"canonical": False}, "REJECT"),
        ("N031_MARKER_BEFORE_SOURCE_PRECHECK", {"exists_before_attempt": False}, "REJECT"),
        ("N032_MARKER_BEFORE_RESOURCE_PRECHECK", {"exists_before_attempt": False}, "REJECT"),
        ("N033_UNKNOWN_NAMESPACE_CLASS", {"source_namespace_class": "UNKNOWN"}, "REJECT"),
        ("N034_EMPTY_NAMESPACE_CLASS", {"source_namespace_class": ""}, "REJECT"),
        ("N035_DESTINATION_TRAVERSAL", {"destination_canonical": False}, "REJECT"),
        ("N036_UNEXPLAINED_SOURCE_PROVENANCE", {"identity_bound": False}, "REJECT"),
    ]
    result: list[dict[str, Any]] = []
    for test_id, delta, expected in cases:
        fixture = {**valid, **delta}
        observed = "PASS" if source_policy(fixture) else "REJECT"
        result.append({
            "test_id": test_id,
            "expected": expected,
            "observed": observed,
            "status": "PASS" if expected == observed else "FAIL",
        })
    return result


def main() -> None:
    checks: list[dict[str, Any]] = []
    add_check(checks, "G001_PREDECESSOR_LOCK_SHA", sha(PREDECESSOR / "GOVERNANCE_LOCK.json") == EXPECTED["predecessor_lock"])
    add_check(checks, "G002_PREDECESSOR_MANIFEST_SHA", sha(PREDECESSOR / "GOVERNANCE_ARTIFACT_MANIFEST.json") == EXPECTED["predecessor_manifest"])
    add_check(checks, "G003_PREDECESSOR_ROOT", verify_governance(PREDECESSOR, EXPECTED["predecessor_root"]))
    predecessor_lock = load(PREDECESSOR / "GOVERNANCE_LOCK.json")
    add_check(checks, "G004_PREDECESSOR_STATUS", predecessor_lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    add_check(checks, "G005_V2_WAS_AUTHORIZED", predecessor_lock.get("v2_state") == "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    add_check(checks, "G006_V2_SOURCE_MANIFEST_SHA", sha(V2 / "locks/STATIC_SOURCE_MANIFEST.json") == EXPECTED["v2_source_manifest"])
    add_check(checks, "G007_V2_SOURCE_MANIFEST_BYTES", verify_member_manifest(V2, V2 / "locks/STATIC_SOURCE_MANIFEST.json", "canonical_source_root_sha256", EXPECTED["v2_source_root"]))
    add_check(checks, "G008_V2_STATIC_LOCK_SHA", sha(V2 / "locks/STATIC_EXECUTION_LOCK.json") == EXPECTED["v2_static_lock"])
    add_check(checks, "G009_V2_LOCK_VERIFICATION_SHA", sha(V2 / "locks/STATIC_LOCK_VERIFICATION.json") == EXPECTED["v2_lock_verification"])
    add_check(checks, "G010_V2_EXACT_CONTRACT_SHA", sha(V2 / "contracts-v2/EXACT_EXECUTION_CONTRACT.json") == EXPECTED["v2_exact_contract"])
    add_check(checks, "G011_V2_ARGV_VALIDATOR_SHA", sha(V2 / "source-v2/lib/argv_semantics.py") == EXPECTED["v2_argv_validator"])
    add_check(checks, "G012_V2_RESOURCE_VALIDATOR_SHA", sha(V2 / "source-v2/lib/resource_feasibility.py") == EXPECTED["v2_resource_validator"])
    add_check(checks, "G013_V2_RUNNER_SHA", sha(V2 / "tooling/run_once.py") == EXPECTED["v2_runner"])
    add_check(checks, "G014_V2_RESOURCE_PRECHECK_SHA", sha(V2 / "evidence-v2/preflight/RESOURCE_LIMIT_FEASIBILITY_PRECHECK.json") == EXPECTED["v2_resource_precheck"])
    add_check(checks, "G015_V2_ATTEMPT_SHA", sha(V2 / "evidence-v2/runtime/ATTEMPT_STARTED.json") == EXPECTED["v2_attempt"])
    add_check(checks, "G016_V2_CHILD_EXIT_SHA", sha(V2 / "evidence-v2/runtime/CHILD_EXIT.json") == EXPECTED["v2_child_exit"])
    add_check(checks, "G017_V2_TERMINAL_SHA", sha(V2 / "evidence-v2/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == EXPECTED["v2_terminal"])
    add_check(checks, "G018_V2_POST_INCOMPLETE_SHA", sha(V2 / "evidence-v2/validation/POST_VALIDATION_INCOMPLETE.json") == EXPECTED["v2_post_incomplete"])
    add_check(checks, "G019_V2_STDERR_SHA", sha(V2 / "evidence-v2/logs/child.stderr") == EXPECTED["v2_stderr"])
    add_check(checks, "G020_V2_TRACE_PARENT_SHA", sha(V2 / "evidence-v2/traces/runtime.strace.59973") == EXPECTED["v2_trace_parent"])
    add_check(checks, "G021_V2_TRACE_CHILD_SHA", sha(V2 / "evidence-v2/traces/runtime.strace.59974") == EXPECTED["v2_trace_child"])
    add_check(checks, "G022_V2_EVIDENCE_MANIFEST_SHA", sha(V2 / "evidence-v2/EVIDENCE_MANIFEST.json") == EXPECTED["v2_evidence_manifest"])
    add_check(checks, "G023_V2_EVIDENCE_MANIFEST_BYTES", verify_member_manifest(V2, V2 / "evidence-v2/EVIDENCE_MANIFEST.json", "canonical_evidence_root_sha256", EXPECTED["v2_evidence_root"]))
    add_check(checks, "G024_V2_EVIDENCE_LOCK_SHA", sha(V2 / "evidence-v2/EVIDENCE_FREEZE_LOCK.json") == EXPECTED["v2_evidence_lock"])
    add_check(checks, "G025_V2_FREEZE_RESULT_SHA", sha(V2 / "evidence-v2/FREEZE_VERIFICATION_RESULT.json") == EXPECTED["v2_freeze_result"])

    static_lock = load(V2 / "locks/STATIC_EXECUTION_LOCK.json")
    resource = load(V2 / "evidence-v2/preflight/RESOURCE_LIMIT_FEASIBILITY_PRECHECK.json")
    attempt = load(V2 / "evidence-v2/runtime/ATTEMPT_STARTED.json")
    child = load(V2 / "evidence-v2/runtime/CHILD_EXIT.json")
    terminal = load(V2 / "evidence-v2/RUNTIME_VALIDATION_TERMINAL_RESULT.json")
    incomplete = load(V2 / "evidence-v2/validation/POST_VALIDATION_INCOMPLETE.json")
    evidence_lock = load(V2 / "evidence-v2/EVIDENCE_FREEZE_LOCK.json")
    exact = load(V2 / "evidence-v2/preflight/EXACT_EXECUTION.json")
    stderr = (V2 / "evidence-v2/logs/child.stderr").read_text(encoding="utf-8")
    trace_parent = (V2 / "evidence-v2/traces/runtime.strace.59973").read_text(encoding="utf-8", errors="replace")
    trace_child = (V2 / "evidence-v2/traces/runtime.strace.59974").read_text(encoding="utf-8", errors="replace")
    argv = exact.get("argv")
    if not isinstance(argv, list) or not all(isinstance(item, str) for item in argv):
        raise RuntimeError("invalid frozen argv")
    operations = parse_mount_operations(argv)
    inventory = classify_bind_sources(operations)
    offender = [item for item in inventory if item["source"] == OFFENDING_SOURCE and item["destination"] == OFFENDING_DESTINATION]

    add_check(checks, "G026_STATIC_LOCK_IDENTITY", static_lock.get("execution_identity") == V2_IDENTITY and static_lock.get("operation") == V2_OPERATION)
    add_check(checks, "G027_STATIC_LOCK_ARGV_DIGEST", static_lock.get("canonical_argv_array_sha256") == exact.get("canonical_argv_array_sha256") == "e6057adba5b084fe219209224751f080a19c9d02a4f0f09cff8123df85f8a960")
    add_check(checks, "G028_RESOURCE_PRECHECK_PASS", resource.get("status") == "PASS" and resource.get("predicate_result") is True)
    add_check(checks, "G029_RESOURCE_INDEPENDENT_PASS", resource.get("independent_validator_result", {}).get("status") == "PASS")
    add_check(checks, "G030_RESOURCE_ATTEMPT_ORDER", static_lock.get("attempt_consumption_order") == "RESOURCE_LIMIT_FEASIBILITY_PRECHECK_PASS_THEN_ATOMIC_ATTEMPT_MARKER_THEN_EXACT_CHILD_LAUNCH")
    add_check(checks, "G031_ATTEMPT_ONE_CONSUMED", attempt.get("attempt_count") == 1 and attempt.get("state") == "CONSUMED_NO_RETRY")
    add_check(checks, "G032_CHILD_EXIT_ONE", child.get("returncode") == 1)
    add_check(checks, "G033_TERMINAL_STATUS", terminal.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY")
    add_check(checks, "G034_TERMINAL_IDENTITY", terminal.get("execution_identity") == V2_IDENTITY and terminal.get("operation") == V2_OPERATION)
    add_check(checks, "G035_TERMINAL_ATTEMPT", terminal.get("attempt_count") == 1 and terminal.get("state") == "CONSUMED_NO_RETRY")
    add_check(checks, "G036_CONFINEMENT_NOT_PROVEN", terminal.get("runtime_gate_status") is None and terminal.get("independent_post_validation_status") is None)
    add_check(checks, "G037_POST_VALIDATION_INCOMPLETE", incomplete.get("status") == "FAIL_CLOSED_INCOMPLETE")
    add_check(checks, "G038_TOPOLOGY_INCOMPLETE", terminal.get("diagnostic_completeness", {}).get("topology_complete") is False)
    add_check(checks, "G039_FIXTURE_BODY_NOT_STARTED", not (V2 / "run-v2/fixture-output/FIXTURE_RESULT.json").exists())
    add_check(checks, "G040_EVIDENCE_FROZEN_TERMINAL", evidence_lock.get("status") == "FAIL_CLOSED_FROZEN_TERMINAL_EVIDENCE")
    add_check(checks, "G041_EVIDENCE_ATTEMPT", evidence_lock.get("attempt_count") == 1 and evidence_lock.get("state") == "CONSUMED_NO_RETRY")
    add_check(checks, "G042_STDERR_EXACT_BIND_SOURCE", stderr.strip() == f"bwrap: Can't find source path {OFFENDING_SOURCE}: No such file or directory")
    add_check(checks, "G043_TRACE_EXEC_BWRAP", trace_parent.count('execve("/usr/bin/bwrap"') == 1)
    add_check(checks, "G044_TRACE_NO_FIXTURE_PYTHON", 'execve("/usr/bin/python3.14"' not in trace_parent + trace_child)
    add_check(checks, "G045_TRACE_ERROR_WRITE", f"Can't find source path {OFFENDING_SOURCE}" in trace_child)
    add_check(checks, "G046_OFFENDER_UNIQUE", len(offender) == 1, offender)
    add_check(checks, "G047_OFFENDER_CLASS", len(offender) == 1 and offender[0]["source_namespace_class"] == "FUTURE_CONSTRUCTED_SANDBOX_PATH", offender)
    add_check(checks, "G048_OFFENDER_MISSING_CALLER_NAMESPACE", not Path(OFFENDING_SOURCE).exists())
    add_check(checks, "G049_OFFENDER_IS_BIND_SOURCE", len(offender) == 1 and offender[0]["option"] == "--ro-bind")
    add_check(checks, "G050_SOURCE_DESTINATION_DISTINCT", OFFENDING_SOURCE != OFFENDING_DESTINATION)
    add_check(checks, "G051_V2_TREE_READ_ONLY", all(read_only(path) for path in V2.rglob("*") if path.is_file()))
    add_check(checks, "G052_V3_PATH_ABSENT", not V3.exists() and not V3.is_symlink())
    add_check(checks, "G053_V1_STATIC_LOCK_UNCHANGED", sha(V1 / "locks/STATIC_EXECUTION_LOCK.json") == EXPECTED["v1_static_lock"])
    add_check(checks, "G054_V1_TERMINAL_UNCHANGED", sha(V1 / "evidence-v1/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == EXPECTED["v1_terminal"])
    add_check(checks, "G055_V1_EVIDENCE_LOCK_UNCHANGED", sha(V1 / "evidence-v1/EVIDENCE_FREEZE_LOCK.json") == EXPECTED["v1_evidence_lock"])
    forbidden = ("codex_cli_invocations", "real_worker_processes", "subagent_processes", "target_operations", "external_network_operations", "parallel_operations", "capability_edges", "candidate_promotions", "submission_operations", "exploit_replays")
    add_check(checks, "G056_FORBIDDEN_OPERATIONS_ZERO", all(terminal.get("operation_counters", {}).get(key) == 0 for key in forbidden))
    add_check(checks, "G057_V2_ATTEMPT_COUNTERS", terminal.get("operation_counters", {}).get("runtime_validation_attempts") == terminal.get("operation_counters", {}).get("containment_fixture_attempts") == 1)
    add_check(checks, "G058_NEW_IDENTITY_DIRECTORY_EXACT", ROOT.name == "v0.3-runtime-substrate-validation-v2-bind-source-namespace-resolution-failure-and-incomplete-confinement-evidence-erratum-and-successor-decision-governance-v1-20261016")

    failed = [item for item in checks if item["status"] != "PASS"]
    if failed:
        raise RuntimeError(f"governance preflight failed: {failed}")

    common = {"schema_version": "1.0", "governance_identity": IDENTITY}
    dump_exclusive("ROUTING_AND_SCOPE_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "scope": "IMMUTABLE_GOVERNANCE_ADJUDICATION_ONLY",
        "active_skills": ["mandatory-auto-router", "authorized-security-autopilot", "agentic-security-research-harness", "codex-security-harness", "contract-first"],
        "deferred": ["external-ai-security-tool-governor", "codex-runtime", "daybreak-runtime", "worker", "subagent", "owned-lab-exploit-replay", "target-network", "parallelism", "capability-graph", "candidate-promotion", "submission"],
        "not_applicable": ["live-target-testing", "prior-art-finding-search", "vulnerability-candidate-promotion"],
        "operation_counters": zero_operations(),
    })
    dump_exclusive("PREDECESSOR_AND_V2_EVIDENCE_BINDING.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_PREDECESSOR_AND_EVIDENCE_BINDING",
        "predecessor_governance": {"path": str(PREDECESSOR), "lock_sha256": EXPECTED["predecessor_lock"], "manifest_sha256": EXPECTED["predecessor_manifest"], "canonical_root_sha256": EXPECTED["predecessor_root"]},
        "runtime_validation_v2": {"path": str(V2), "source_manifest_sha256": EXPECTED["v2_source_manifest"], "source_root_sha256": EXPECTED["v2_source_root"], "static_execution_lock_sha256": EXPECTED["v2_static_lock"], "exact_execution_contract_sha256": EXPECTED["v2_exact_contract"], "argv_validator_sha256": EXPECTED["v2_argv_validator"], "runner_sha256": EXPECTED["v2_runner"]},
        "terminal_evidence": {"resource_precheck_sha256": EXPECTED["v2_resource_precheck"], "attempt_sha256": EXPECTED["v2_attempt"], "child_exit_sha256": EXPECTED["v2_child_exit"], "terminal_sha256": EXPECTED["v2_terminal"], "post_incomplete_sha256": EXPECTED["v2_post_incomplete"], "stderr_sha256": EXPECTED["v2_stderr"], "trace_parent_sha256": EXPECTED["v2_trace_parent"], "trace_child_sha256": EXPECTED["v2_trace_child"], "evidence_manifest_sha256": EXPECTED["v2_evidence_manifest"], "evidence_lock_sha256": EXPECTED["v2_evidence_lock"], "canonical_evidence_root_sha256": EXPECTED["v2_evidence_root"]},
        "historical_v1_anchors": {"static_execution_lock_sha256": EXPECTED["v1_static_lock"], "terminal_sha256": EXPECTED["v1_terminal"], "evidence_lock_sha256": EXPECTED["v1_evidence_lock"]},
    })
    dump_exclusive("RUNTIME_VALIDATION_V2_TERMINAL_DISPOSITION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_TERMINAL_DISPOSITION",
        "execution_identity": V2_IDENTITY,
        "operation": V2_OPERATION,
        "status": "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY",
        "attempt_count": 1,
        "maximum_attempts": 1,
        "retry_authorized": False,
        "patch_in_place_authorized": False,
        "relock_same_identity_authorized": False,
        "promotion_authorized": False,
        "confinement": "NOT_PROVEN",
    })
    dump_exclusive("BIND_SOURCE_NAMESPACE_RESOLUTION_ROOT_CAUSE.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_BIND_SOURCE_NAMESPACE_RESOLUTION_ROOT_CAUSE",
        "classification": "CONFIRMED_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE",
        "confirmed_facts": {
            "resource_limit_feasibility_precheck": "PASS",
            "attempt_consumed": True,
            "bubblewrap_execve_observed": True,
            "fixture_python_execve_observed": False,
            "stderr_exact": f"bwrap: Can't find source path {OFFENDING_SOURCE}: No such file or directory",
            "offending_option": "--ro-bind",
            "offending_source": OFFENDING_SOURCE,
            "offending_destination": OFFENDING_DESTINATION,
            "source_exists_in_caller_namespace": False,
            "source_namespace_class": "FUTURE_CONSTRUCTED_SANDBOX_PATH",
        },
        "causal_statement": "BUBBLEWRAP_RESOLVES_BIND_SOURCE_IN_CALLER_NAMESPACE_BEFORE_FUTURE_SANDBOX_DESTINATIONS_CAN_SUPPLY_THAT_SOURCE",
        "not_established": ["CONFINEMENT_BYPASS", "CONTROL_PLANE_V2_DEFECT", "RESOURCE_LIMIT_FEASIBILITY_DEFECT", "CONFINEMENT_PASS"],
    })
    dump_exclusive("DEFECT_OWNERSHIP_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_DEFECT_OWNERSHIP_DECISION",
        "decision": "EXECUTION_ARGV_CONSTRUCTION_AND_SEMANTIC_ARGV_VALIDATION_OWN_BIND_SOURCE_NAMESPACE_CORRECTNESS",
        "execution_argv_construction_defect": True,
        "semantic_argv_validator_coverage_gap": True,
        "resource_limit_feasibility_defect": False,
        "control_plane_v2_defect": False,
        "containment_bypass": False,
        "defect_components": {
            "future_constructed_sandbox_path_used_as_bind_source": "CONFIRMED",
            "source_resolution_namespace_not_modeled": "CONFIRMED_VALIDATOR_GAP",
            "resource_precheck_order_and_predicate": "WORKED_AS_DESIGNED",
        },
    })
    dump_exclusive("PARTIAL_EVIDENCE_ADMISSIBILITY.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_PARTIAL_EVIDENCE_ADMISSIBILITY",
        "resource_feasibility": "ADMISSIBLE_PASS_WITHIN_V2_CONTEXT",
        "attempt_and_process_evidence": "ADMISSIBLE",
        "bind_source_failure": "SYSCALL_AND_STDERR_SUPPORTED",
        "trace_coverage": "PARTIAL_ONLY_BWRAP_STARTUP",
        "mount_topology": "NOT_COMPLETED",
        "negative_write_probes": "NOT_EXECUTED",
        "positive_controls": "NOT_EXECUTED",
        "fixture_body": "NOT_STARTED",
        "independent_post_validation": "INCOMPLETE",
        "confinement": "NOT_PROVEN",
        "promotion": "PROHIBITED",
    })
    dump_exclusive("RESOURCE_FEASIBILITY_PRESERVATION_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_RESOURCE_FEASIBILITY_PRESERVATION_DECISION",
        "v2_precheck_status": "PASS",
        "v2_precheck_admissibility": "HISTORICAL_EVIDENCE_ONLY_NOT_REUSABLE_AS_V3_LIVE_PRECHECK",
        "contract_requirement_for_v3": "RESOURCE_LIMIT_FEASIBILITY_PRECHECK_REMAINS_MANDATORY_BEFORE_ATTEMPT",
        "v3_requirement": "FRESH_CONTEXT_MEASUREMENT_AND_INDEPENDENT_VALIDATION",
        "old_measurement_cannot_authorize_new_attempt": True,
    })
    dump_exclusive("BIND_SOURCE_NAMESPACE_MODEL.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V3_BIND_SOURCE_NAMESPACE_MODEL",
        "classes": {
            "CALLER_NAMESPACE_EXISTING_PATH": "MAY_BE_ELIGIBLE_AS_BIND_SOURCE_AFTER_ALL_IDENTITY_AND_TYPE_GATES_PASS",
            "SANDBOX_DESTINATION": "MAY_BE_ELIGIBLE_ONLY_AS_DESTINATION_WITH_VALID_ORDERING",
            "FUTURE_CONSTRUCTED_SANDBOX_PATH": "PROHIBITED_AS_BIND_SOURCE",
            "CALLER_NAMESPACE_MISSING_PATH": "PROHIBITED_AS_BIND_SOURCE",
            "UNKNOWN": "FAIL_CLOSED",
        },
        "core_invariant": "EVERY_BIND_SOURCE_MUST_EXIST_IN_THE_NAMESPACE_USED_BY_THE_LAUNCHER_TO_RESOLVE_SOURCE_OPERANDS_BEFORE_BWRAP_ATTEMPTS_THE_BIND",
        "source_and_destination_are_distinct_typed_roles": True,
        "option_order_does_not_transform_a_future_sandbox_destination_into_A_CALLER_NAMESPACE_SOURCE": True,
    })
    dump_exclusive("BIND_SOURCE_RESOLUTION_PRECHECK_CONTRACT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V3_BIND_SOURCE_RESOLUTION_PRECHECK_CONTRACT",
        "required": True,
        "applies_to": ["--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try"],
        "required_fields_per_source": ["option", "source", "destination", "source_namespace_class", "absolute", "canonical", "exists_before_attempt", "exists_before_child_launch", "symlink", "expected_type", "observed_type", "identity_binding", "measurement_time", "freshness_limit", "independent_result"],
        "ordering": ["LOCK_EXACT_ARGV", "ENUMERATE_BIND_OPERATIONS_SEMANTICALLY", "CLASSIFY_SOURCE_AND_DESTINATION_NAMESPACES", "VERIFY_CALLER_NAMESPACE_SOURCE_IDENTITY_TYPE_AND_NO_SYMLINK", "VERIFY_RESOURCE_LIMIT_FEASIBILITY", "INDEPENDENTLY_RECOMPUTE_BOTH_PRECHECKS", "RECHECK_BOTH_WITHIN_LOCKED_FRESHNESS_WINDOW", "ONLY_THEN_WRITE_ATTEMPT_MARKER", "ONLY_THEN_LAUNCH_EXACT_CHILD"],
        "failure": "STOP_BEFORE_ATTEMPT_MARKER_ATTEMPT_REMAINS_ZERO",
        "unknown_or_ambiguous_namespace": "FAIL_CLOSED_BEFORE_ATTEMPT",
        "application_level_path_string_match_alone": "INSUFFICIENT",
    })
    dump_exclusive("SEMANTIC_ARGV_VALIDATOR_V3_REQUIREMENTS.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V3_SEMANTIC_ARGV_VALIDATOR_REQUIREMENTS",
        "requirements": ["PARSE_OPTION_ARITY_AND_APPLICATION_BOUNDARY", "VERIFY_EXACT_CANONICAL_ARGV_DIGEST", "TYPE_EACH_BIND_SOURCE_AND_DESTINATION", "REJECT_FUTURE_CONSTRUCTED_SANDBOX_SOURCE", "REJECT_MISSING_CALLER_SOURCE", "REJECT_SYMLINK_OR_NONCANONICAL_SOURCE", "VERIFY_SOURCE_TYPE_AND_IDENTITY", "VERIFY_DESTINATION_CREATION_ORDER", "PRESERVE_EXACTLY_ONE_AUTHORIZED_WRITABLE_HOST_BIND", "REJECT_UNKNOWN_MOUNT_OPTIONS", "INDEPENDENT_IMPLEMENTATION_PARITY"],
        "mandatory_regressions": ["REPRODUCE_V2_FUTURE_SANDBOX_SOURCE_FAILURE", "VALID_CALLER_NAMESPACE_SOURCE_PASSES", "MISSING_SOURCE_FAILS_BEFORE_ATTEMPT", "SYMLINK_SOURCE_FAILS", "WRONG_TYPE_FAILS", "SOURCE_REPLACEMENT_BETWEEN_CHECKS_FAILS", "BIND_TRY_AND_DEV_BIND_VARIANTS_CLASSIFIED", "SOURCE_DESTINATION_ROLE_SWAP_FAILS", "PATH_TRAVERSAL_AND_ALIAS_FAIL", "ATTEMPT_MARKER_BEFORE_PRECHECK_FAILS"],
        "substring_or_raw_path_occurrence_counting": "PROHIBITED",
        "unknown_semantics": "FAIL_CLOSED",
    })
    dump_exclusive("RUNTIME_VALIDATION_V3_IDENTITY_AND_PATH_BINDING.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V3_IDENTITY_AND_PATH_BINDING",
        "execution_identity": V3_IDENTITY,
        "operation": V3_OPERATION,
        "workspace": str(V3),
        "workspace_state": "NOT_CREATED",
        "attempt_count": 0,
        "maximum_attempts": 1,
        "fresh_source_required": True,
        "fresh_tests_required": True,
        "fresh_static_manifest_required": True,
        "fresh_static_execution_lock_required": True,
        "fresh_one_shot_contract_required": True,
    })
    dump_exclusive("RUNTIME_VALIDATION_V3_SUCCESSOR_AUTHORIZATION_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V3_SUCCESSOR_AUTHORIZATION_DECISION",
        "decision": "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V3_CONDITIONALLY",
        "status": "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "execution_identity": V3_IDENTITY,
        "operation": V3_OPERATION,
        "attempt_count": 0,
        "maximum_attempts": 1,
        "authorization_effective_only_if_this_governance_is_pass_locked": True,
        "resource_limit_feasibility_precheck": "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION",
        "bind_source_resolution_precheck": "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION",
        "solution_implementation": "DEFERRED_TO_FRESH_V3_SOURCE_AND_MUST_BE_STATICALLY_LOCKED",
    })
    dump_exclusive("V3_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V3_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT",
        "required": ["FRESH_V3_SOURCE_IDENTITY", "V2_FAILURE_REGRESSION", "BIND_SOURCE_NAMESPACE_MODEL", "PRIMARY_STATIC_VALIDATION", "INDEPENDENT_STATIC_VALIDATION", "EXACT_ARGV_ENVIRONMENT_AND_RUNTIME_BINDING", "FRESH_STATIC_SOURCE_MANIFEST", "FRESH_STATIC_EXECUTION_LOCK", "LOCK_REREAD_VERIFICATION", "HUMAN_GATE", "RESOURCE_LIMIT_FEASIBILITY_PRECHECK_PASS", "BIND_SOURCE_RESOLUTION_PRECHECK_PASS", "INDEPENDENT_PRECHECK_PARITY"],
        "attempt_marker_gate": "BOTH_RESOURCE_AND_BIND_SOURCE_PRECHECKS_MUST_PASS_WITHIN_FRESHNESS_WINDOW",
        "no_execution_during_this_governance": True,
        "no_mutable_import_from_v2": True,
    })
    dump_exclusive("V3_SINGLE_USE_EXECUTION_CONTRACT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V3_SINGLE_USE_EXECUTION_CONTRACT",
        "execution_identity": V3_IDENTITY,
        "operation": V3_OPERATION,
        "attempt_count_initial": 0,
        "maximum_attempts": 1,
        "automatic_retry": False,
        "attempt_consumption_event": "ATOMIC_ATTEMPT_MARKER_IMMEDIATELY_BEFORE_ACTUAL_CHILD_LAUNCH_AFTER_RESOURCE_AND_BIND_SOURCE_PRECHECKS_PASS",
        "failure_before_attempt_marker": "BLOCKED_BEFORE_ATTEMPT_ATTEMPT_REMAINS_ZERO",
        "failure_after_attempt_marker": "TERMINAL_CONSUMED_NO_RETRY",
        "success_ceiling": "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION",
    })
    dump_exclusive("AUTHORITY_NON_ESCALATION_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION",
        "governance_only": True,
        "v3_created_or_executed": False,
        "runtime_or_fixture_execution_authorized_in_this_milestone": False,
        "worker_model_subagent_authorized": False,
        "target_network_authorized": False,
        "exploit_replay_authorized": False,
        "parallel_capability_full_chain_authorized": False,
        "candidate_promotion_or_submission_authorized": False,
        "authorization_to_engineer_v3_after_pass_locked_is_not_execution_without_all_v3_gates": True,
    })
    dump_exclusive("OPERATION_AUTHORIZATION_MATRIX.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_OPERATION_AUTHORIZATION_MATRIX",
        "default": "DENY",
        "operations": {
            "ADJUDICATE_FROZEN_V2_EVIDENCE": "AUTHORIZED_AND_COMPLETED",
            "PATCH_RELOCK_RETRY_OR_PROMOTE_V2": "PROHIBITED",
            "CREATE_OR_EXECUTE_V3_DURING_THIS_GOVERNANCE": "NOT_AUTHORIZED",
            "IMPLEMENT_V3_AFTER_PASS_LOCKED": "AUTHORIZED_FUTURE_MILESTONE",
            "EXECUTE_V3_AFTER_ALL_FRESH_GATES": "CONDITIONAL_SINGLE_USE_FUTURE_AUTHORIZATION",
            "CODEX_DAYBREAK_WORKER_SUBAGENT": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
            "KERNEL_SANDBOX_PWNESCAPE_REPLAY": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
            "TARGET_NETWORK_PARALLEL_CAPABILITY_FULL_CHAIN_SUBMISSION": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
            "PUBLISH_GOVERNANCE_PACKAGE": "CONDITIONAL_ON_ALL_VALIDATION_AND_FINAL_FREEZE_PASS",
        },
    })
    dump_exclusive("NEXT_LEGAL_MILESTONE.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_NEXT_LEGAL_MILESTONE",
        "milestone": NEXT_MILESTONE,
        "status": "AUTHORIZED_ONLY_IF_THIS_GOVERNANCE_IS_PASS_LOCKED",
        "initial_v3_attempt_count": 0,
        "mandatory_pre_attempt_gates": ["RESOURCE_LIMIT_FEASIBILITY_PRECHECK", "BIND_SOURCE_RESOLUTION_PRECHECK"],
        "stop_after": "RUNTIME_VALIDATION_V3_EVIDENCE_FREEZE_FOR_SEPARATE_ACCEPTANCE_ADJUDICATION",
        "still_deferred": ["CODEX", "DAYBREAK", "WORKER", "SUBAGENT", "TARGET", "NETWORK", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION"],
    })

    matrix = negative_matrix()
    dump_exclusive("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "policy": "EXPLICIT_TYPED_BIND_SOURCE_NAMESPACE_AND_IDENTITY_GATES",
        "tests": [{"test_id": item["test_id"], "expected": item["expected"]} for item in matrix],
    })
    negative_failed = [item for item in matrix if item["status"] != "PASS"]
    dump_exclusive("NEGATIVE_GOVERNANCE_TEST_RESULT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "status": "PASS" if not negative_failed else "FAIL_CLOSED",
        "tests_total": len(matrix),
        "tests_passed": len(matrix) - len(negative_failed),
        "tests_failed": len(negative_failed),
        "failed": negative_failed,
        "results": matrix,
        "operation_counters": zero_operations(),
    })
    dump_exclusive("GOVERNANCE_TEST_RESULT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_GOVERNANCE_TEST_RESULT",
        "status": "PASS",
        "checks_total": len(checks),
        "checks_passed": len(checks),
        "checks_failed": 0,
        "failed": [],
        "checks": checks,
        "semantic_bind_inventory": inventory,
        "operation_counters": zero_operations(),
    })
    if negative_failed:
        raise RuntimeError(f"negative governance tests failed: {negative_failed}")
    print(json.dumps({"status": "PASS", "governance_checks": len(checks), "negative_tests": len(matrix)}, sort_keys=True))


if __name__ == "__main__":
    main()
