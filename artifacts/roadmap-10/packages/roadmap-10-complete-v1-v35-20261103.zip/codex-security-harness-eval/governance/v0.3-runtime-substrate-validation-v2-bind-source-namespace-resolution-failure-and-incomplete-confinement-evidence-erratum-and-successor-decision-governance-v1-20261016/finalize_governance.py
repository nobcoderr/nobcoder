#!/usr/bin/env python3
"""Freeze the V2 bind-source erratum governance package after all PASS gates."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
V2 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016"
V3 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v3-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE_AND_INCOMPLETE_CONFINEMENT_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V3_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
V3_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
NEXT_MILESTONE = "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V3_THEN_EXECUTE_RUNTIME_VALIDATION_V3_ONCE_IF_ALL_GATES_PASS"
OPERATION_KEYS = (
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "containment_fixture_attempts", "exploit_replays",
    "external_network_operations", "parallel_operations",
    "real_worker_processes", "runtime_validation_attempts",
    "subagent_processes", "submission_operations", "target_operations",
)
PRE_FINAL_MEMBERS = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_AND_V2_EVIDENCE_BINDING.json",
    "RUNTIME_VALIDATION_V2_TERMINAL_DISPOSITION.json", "BIND_SOURCE_NAMESPACE_RESOLUTION_ROOT_CAUSE.json",
    "DEFECT_OWNERSHIP_DECISION.json", "PARTIAL_EVIDENCE_ADMISSIBILITY.json",
    "RESOURCE_FEASIBILITY_PRESERVATION_DECISION.json", "BIND_SOURCE_NAMESPACE_MODEL.json",
    "BIND_SOURCE_RESOLUTION_PRECHECK_CONTRACT.json", "SEMANTIC_ARGV_VALIDATOR_V3_REQUIREMENTS.json",
    "RUNTIME_VALIDATION_V3_IDENTITY_AND_PATH_BINDING.json", "RUNTIME_VALIDATION_V3_SUCCESSOR_AUTHORIZATION_DECISION.json",
    "V3_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json", "V3_SINGLE_USE_EXECUTION_CONTRACT.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_TEST_RESULT.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "INDEPENDENT_VALIDATION_RESULT.json",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def dump_exclusive(name: str, value: dict[str, Any]) -> str:
    path = ROOT / name
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return sha(path)


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{item['sha256']}  {item['path']}\n" for item in sorted(rows, key=lambda item: str(item["path"]))).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def zero_typed(value: dict[str, Any]) -> bool:
    counters = value.get("operation_counters")
    return isinstance(counters, dict) and set(counters) == set(OPERATION_KEYS) and all(counters[key] == 0 for key in OPERATION_KEYS)


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != PRE_FINAL_MEMBERS:
        raise RuntimeError(f"unexpected pre-final file set: extra={sorted(actual-PRE_FINAL_MEMBERS)} missing={sorted(PRE_FINAL_MEMBERS-actual)}")
    primary = load("GOVERNANCE_TEST_RESULT.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT.json")
    if not (primary.get("status") == "PASS" and primary.get("checks_total") == primary.get("checks_passed") == 58 and primary.get("checks_failed") == 0):
        raise RuntimeError("primary governance validation is not exact PASS")
    if not (negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 36 and negative.get("tests_failed") == 0):
        raise RuntimeError("negative governance validation is not exact PASS")
    if not (independent.get("status") == "PASS" and independent.get("checks_total") == independent.get("checks_passed") == 78 and independent.get("checks_failed") == 0):
        raise RuntimeError("independent governance validation is not exact PASS")
    if not all(zero_typed(item) for item in (primary, negative, independent)):
        raise RuntimeError("governance operation counters are not exact zero")
    if V3.exists() or V3.is_symlink():
        raise RuntimeError("V3 path collision before authorization freeze")
    if sha(V2 / "evidence-v2/RUNTIME_VALIDATION_TERMINAL_RESULT.json") != "9891e7d5c9ff9e66689238b6640683ea34b2572cb44c1c31162dcd0cacd91b27":
        raise RuntimeError("V2 terminal evidence changed")
    if sha(V2 / "evidence-v2/EVIDENCE_FREEZE_LOCK.json") != "d66e1c2cc53c850ae6e3f88afd60cb074448e267f72fd3a09f4313b3bf62d12c":
        raise RuntimeError("V2 evidence lock changed")

    freeze_candidate = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_FREEZE_VERIFICATION_CANDIDATE",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "status": "PASS_CANDIDATE_PRE_FINAL_FREEZE",
        "checks": {
            "exact_pre_final_file_set": True,
            "primary_validation_58_of_58": True,
            "negative_validation_36_of_36": True,
            "independent_validation_78_of_78": True,
            "v2_terminal_evidence_unchanged": True,
            "v2_execution_not_invoked": True,
            "v3_path_absent": True,
            "operation_counters_zero": True,
        },
        "operation_counters": {key: 0 for key in OPERATION_KEYS},
    }
    dump_exclusive("FREEZE_VERIFICATION_RESULT.json", freeze_candidate)
    member_names = PRE_FINAL_MEMBERS | {"FREEZE_VERIFICATION_RESULT.json"}
    members = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in sorted(member_names)]
    member_root = rows_root(members)
    manifest = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "member_count": len(members),
        "members": members,
        "canonical_member_root_sha256": member_root,
        "self_referential_hashes": False,
    }
    manifest_sha = dump_exclusive("GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    artifact_root = rows_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    lock = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V3_CONDITIONALLY",
        "v2_state": "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY",
        "v2_attempt_count": 1,
        "root_cause": "CONFIRMED_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE",
        "defect_ownership": "EXECUTION_ARGV_CONSTRUCTION_AND_SEMANTIC_ARGV_VALIDATION_OWN_BIND_SOURCE_NAMESPACE_CORRECTNESS",
        "resource_limit_feasibility_defect": False,
        "control_plane_v2_defect": False,
        "execution_argv_construction_defect": True,
        "semantic_argv_validator_coverage_gap": True,
        "containment_bypass": False,
        "confinement": "NOT_PROVEN",
        "v3_state": "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v3_identity": V3_IDENTITY,
        "v3_operation": V3_OPERATION,
        "v3_workspace": str(V3),
        "v3_attempt_count": 0,
        "resource_limit_feasibility_precheck": "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION",
        "bind_source_resolution_precheck": "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION",
        "next_milestone": NEXT_MILESTONE,
        "governance_manifest_sha256": manifest_sha,
        "canonical_member_root_sha256": member_root,
        "canonical_artifact_root_sha256": artifact_root,
        "root_member_count": len(members) + 1,
        "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 1},
        "validation_counts": {
            "governance": {"total": 58, "passed": 58, "failed": 0},
            "negative": {"total": 36, "passed": 36, "failed": 0},
            "independent": {"total": 78, "passed": 78, "failed": 0},
        },
        "operation_counters": {key: 0 for key in OPERATION_KEYS},
        "runtime_or_fixture_execution_authorized_in_this_milestone": False,
        "worker_model_subagent_authorized": False,
        "target_network_authorized": False,
        "exploit_replay_authorized": False,
        "parallel_capability_full_chain_authorized": False,
        "candidate_promotion_or_submission_authorized": False,
    }
    lock_sha = dump_exclusive("GOVERNANCE_LOCK.json", lock)
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": lock["status"],
        "manifest_sha256": manifest_sha,
        "lock_sha256": lock_sha,
        "canonical_artifact_root": artifact_root,
        "manifest_members": len(members),
        "root_members": len(members) + 1,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
