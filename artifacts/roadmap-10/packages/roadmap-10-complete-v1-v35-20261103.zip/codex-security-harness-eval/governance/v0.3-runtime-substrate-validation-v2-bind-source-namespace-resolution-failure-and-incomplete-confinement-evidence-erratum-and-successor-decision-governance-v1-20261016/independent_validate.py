#!/usr/bin/env python3
"""Independent governance validator for the Runtime Validation V2 erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import stat
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
V1 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016"
V2 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016"
V3 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v3-20261016"
PREDECESSOR = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v1-launcher-process-limit-incompatibility-and-incomplete-evidence-erratum-and-successor-decision-governance-v1-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE_AND_INCOMPLETE_CONFINEMENT_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V2_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
V3_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
V3_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V3"
OFFENDING_SOURCE = "/run/v0-3-runtime-substrate-source-v2/empty-home"
OFFENDING_DESTINATION = "/home/nobcoder"
OPERATION_KEYS = (
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "containment_fixture_attempts", "exploit_replays",
    "external_network_operations", "parallel_operations",
    "real_worker_processes", "runtime_validation_attempts",
    "subagent_processes", "submission_operations", "target_operations",
)
EXPECTED = {
    "predecessor_lock": "f9f5c895f34e7096155fe553aae51e3e30fc43591c36e8845655c817538e23ba",
    "predecessor_manifest": "6b7f6ecca77e07697be5712bbeeb7a322cdbf09132df8a9faf33bb151c4aafb9",
    "v2_source_manifest": "88098fe876614ead43438ce1c26a0c13a63da57fbc8c3c54d4bce85ddc06022c",
    "v2_static_lock": "6bb19fcd71f5378900c87003f088677366f98dff2c972c7a08e303ed7c55fbcc",
    "v2_terminal": "9891e7d5c9ff9e66689238b6640683ea34b2572cb44c1c31162dcd0cacd91b27",
    "v2_evidence_manifest": "4559708d56d6db4da1aba2ed95ae5bea1b9326f95b8c2f78ab1f294b9fe21fdb",
    "v2_evidence_lock": "d66e1c2cc53c850ae6e3f88afd60cb074448e267f72fd3a09f4313b3bf62d12c",
    "v2_stderr": "10f8b0556f98333f39a2386ea4d8893f6745f3a8ab704d33de9b6525b0e77031",
    "v2_trace_parent": "8d78aabfe0b8d29082f33e04d248663adea253052d6a2d48c419afe1ffeaab49",
    "v2_trace_child": "2f5cbe927fb16c33785448a3a2265bbd6075007b482bff8c4ac81f604ae013f6",
    "v1_static_lock": "56e279a86749d756aa33d4a9c68c5c4d4609feb8d1ee1d2c449873c507d28d8e",
    "v1_terminal": "1943e30b28c726d79ba566b6a1d76bbe5d44e6fbd557671cfb7d56cbe7040fc5",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name_or_path: str | Path) -> dict[str, Any]:
    path = Path(name_or_path)
    if not path.is_absolute():
        path = ROOT / path
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def read_only(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def independent_mount_walk(argv: list[str]) -> list[tuple[str, list[str], int]]:
    start = argv.index("/usr/bin/bwrap") + 1
    arities = {
        "--unshare-user": 0, "--unshare-pid": 0, "--unshare-net": 0,
        "--unshare-ipc": 0, "--unshare-uts": 0, "--die-with-parent": 0,
        "--new-session": 0, "--clearenv": 0, "--cap-drop": 1,
        "--tmpfs": 1, "--dir": 1, "--proc": 1, "--dev": 1,
        "--chdir": 1, "--remount-ro": 1, "--setenv": 2,
        "--bind": 2, "--ro-bind": 2, "--bind-try": 2,
        "--ro-bind-try": 2, "--dev-bind": 2, "--dev-bind-try": 2,
    }
    mount = {"--tmpfs", "--dir", "--proc", "--dev", "--remount-ro", "--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try"}
    result: list[tuple[str, list[str], int]] = []
    index = start
    while index < len(argv) and argv[index].startswith("--"):
        option = argv[index]
        if option not in arities:
            raise ValueError(option)
        arity = arities[option]
        operands = argv[index + 1:index + 1 + arity]
        if len(operands) != arity or any(value.startswith("--") for value in operands):
            raise ValueError(f"malformed {option}")
        if option in mount:
            result.append((option, operands, index))
        index += 1 + arity
    return result


def zero_typed(value: dict[str, Any]) -> bool:
    counters = value.get("operation_counters")
    return isinstance(counters, dict) and set(counters) == set(OPERATION_KEYS) and all(counters[key] == 0 for key in OPERATION_KEYS)


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    routing = load("ROUTING_AND_SCOPE_DECISION.json")
    binding = load("PREDECESSOR_AND_V2_EVIDENCE_BINDING.json")
    disposition = load("RUNTIME_VALIDATION_V2_TERMINAL_DISPOSITION.json")
    root_cause = load("BIND_SOURCE_NAMESPACE_RESOLUTION_ROOT_CAUSE.json")
    ownership = load("DEFECT_OWNERSHIP_DECISION.json")
    partial = load("PARTIAL_EVIDENCE_ADMISSIBILITY.json")
    resource_preservation = load("RESOURCE_FEASIBILITY_PRESERVATION_DECISION.json")
    namespace_model = load("BIND_SOURCE_NAMESPACE_MODEL.json")
    source_precheck = load("BIND_SOURCE_RESOLUTION_PRECHECK_CONTRACT.json")
    validator = load("SEMANTIC_ARGV_VALIDATOR_V3_REQUIREMENTS.json")
    v3_binding = load("RUNTIME_VALIDATION_V3_IDENTITY_AND_PATH_BINDING.json")
    successor = load("RUNTIME_VALIDATION_V3_SUCCESSOR_AUTHORIZATION_DECISION.json")
    gates = load("V3_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json")
    single = load("V3_SINGLE_USE_EXECUTION_CONTRACT.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
    next_gate = load("NEXT_LEGAL_MILESTONE.json")
    primary = load("GOVERNANCE_TEST_RESULT.json")
    negative_matrix = load("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    terminal = load(V2 / "evidence-v2/RUNTIME_VALIDATION_TERMINAL_RESULT.json")
    resource = load(V2 / "evidence-v2/preflight/RESOURCE_LIMIT_FEASIBILITY_PRECHECK.json")
    exact = load(V2 / "evidence-v2/preflight/EXACT_EXECUTION.json")
    argv = exact.get("argv", [])
    operations = independent_mount_walk(argv)
    binds = [item for item in operations if item[0] in {"--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try"}]
    offending = [item for item in binds if item[1] == [OFFENDING_SOURCE, OFFENDING_DESTINATION]]
    destinations_seen: set[str] = set()
    future_source_detected = False
    for option, operands, _ in operations:
        if option in {"--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try"}:
            source, destination = operands
            if source == OFFENDING_SOURCE and any(source == dest or source.startswith(dest.rstrip("/") + "/") for dest in destinations_seen) and not Path(source).exists():
                future_source_detected = True
            destinations_seen.add(destination)
        elif option in {"--tmpfs", "--dir", "--proc", "--dev"}:
            destinations_seen.add(operands[-1])

    check("I001_IDENTITY", routing.get("governance_identity") == IDENTITY)
    check("I002_GOVERNANCE_ONLY", routing.get("scope") == "IMMUTABLE_GOVERNANCE_ADJUDICATION_ONLY")
    check("I003_ZERO_ROUTING_OPERATIONS", zero_typed(routing))
    check("I004_PREDECESSOR_LOCK_SHA", sha(PREDECESSOR / "GOVERNANCE_LOCK.json") == EXPECTED["predecessor_lock"])
    check("I005_PREDECESSOR_MANIFEST_SHA", sha(PREDECESSOR / "GOVERNANCE_ARTIFACT_MANIFEST.json") == EXPECTED["predecessor_manifest"])
    check("I006_BINDING_PREDECESSOR", binding.get("predecessor_governance", {}).get("lock_sha256") == EXPECTED["predecessor_lock"])
    check("I007_V2_SOURCE_MANIFEST_SHA", sha(V2 / "locks/STATIC_SOURCE_MANIFEST.json") == EXPECTED["v2_source_manifest"])
    check("I008_V2_STATIC_LOCK_SHA", sha(V2 / "locks/STATIC_EXECUTION_LOCK.json") == EXPECTED["v2_static_lock"])
    check("I009_V2_TERMINAL_SHA", sha(V2 / "evidence-v2/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == EXPECTED["v2_terminal"])
    check("I010_V2_EVIDENCE_MANIFEST_SHA", sha(V2 / "evidence-v2/EVIDENCE_MANIFEST.json") == EXPECTED["v2_evidence_manifest"])
    check("I011_V2_EVIDENCE_LOCK_SHA", sha(V2 / "evidence-v2/EVIDENCE_FREEZE_LOCK.json") == EXPECTED["v2_evidence_lock"])
    check("I012_STDERR_SHA", sha(V2 / "evidence-v2/logs/child.stderr") == EXPECTED["v2_stderr"])
    check("I013_TRACE_PARENT_SHA", sha(V2 / "evidence-v2/traces/runtime.strace.59973") == EXPECTED["v2_trace_parent"])
    check("I014_TRACE_CHILD_SHA", sha(V2 / "evidence-v2/traces/runtime.strace.59974") == EXPECTED["v2_trace_child"])
    check("I015_V2_TERMINAL", disposition.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY")
    check("I016_V2_ATTEMPT_ONE", disposition.get("attempt_count") == disposition.get("maximum_attempts") == 1)
    check("I017_V2_RETRY_PROHIBITED", disposition.get("retry_authorized") is False)
    check("I018_V2_PATCH_PROHIBITED", disposition.get("patch_in_place_authorized") is False)
    check("I019_V2_RELOCK_PROHIBITED", disposition.get("relock_same_identity_authorized") is False)
    check("I020_V2_PROMOTION_PROHIBITED", disposition.get("promotion_authorized") is False)
    check("I021_CONFINEMENT_NOT_PROVEN", disposition.get("confinement") == partial.get("confinement") == "NOT_PROVEN")
    check("I022_RESOURCE_PRECHECK_PASS", resource.get("status") == "PASS" and resource.get("predicate_result") is True)
    check("I023_RESOURCE_NOT_DEFECT", ownership.get("resource_limit_feasibility_defect") is False)
    check("I024_CONTROL_PLANE_NOT_DEFECT", ownership.get("control_plane_v2_defect") is False)
    check("I025_ARGV_CONSTRUCTION_DEFECT", ownership.get("execution_argv_construction_defect") is True)
    check("I026_VALIDATOR_COVERAGE_GAP", ownership.get("semantic_argv_validator_coverage_gap") is True)
    check("I027_NO_BYPASS", ownership.get("containment_bypass") is False)
    check("I028_ROOT_CAUSE_CONFIRMED", root_cause.get("classification") == "CONFIRMED_BIND_SOURCE_NAMESPACE_RESOLUTION_FAILURE")
    check("I029_OFFENDER_UNIQUE", len(offending) == 1, offending)
    check("I030_OFFENDER_OPTION", len(offending) == 1 and offending[0][0] == "--ro-bind")
    check("I031_OFFENDER_SOURCE_MISSING", not Path(OFFENDING_SOURCE).exists())
    check("I032_FUTURE_SOURCE_SEMANTICS", future_source_detected)
    check("I033_STDERR_EXACT", (V2 / "evidence-v2/logs/child.stderr").read_text(encoding="utf-8").strip() == f"bwrap: Can't find source path {OFFENDING_SOURCE}: No such file or directory")
    traces = (V2 / "evidence-v2/traces/runtime.strace.59973").read_text(encoding="utf-8", errors="replace") + (V2 / "evidence-v2/traces/runtime.strace.59974").read_text(encoding="utf-8", errors="replace")
    check("I034_BWRAP_EXEC_ONLY", traces.count('execve("/usr/bin/bwrap"') == 1 and 'execve("/usr/bin/python3.14"' not in traces)
    check("I035_FIXTURE_NOT_STARTED", partial.get("fixture_body") == "NOT_STARTED")
    check("I036_POST_INCOMPLETE", partial.get("independent_post_validation") == "INCOMPLETE")
    check("I037_NO_NEGATIVE_PROBES", partial.get("negative_write_probes") == "NOT_EXECUTED")
    check("I038_NO_POSITIVE_CONTROLS", partial.get("positive_controls") == "NOT_EXECUTED")
    check("I039_RESOURCE_EVIDENCE_HISTORICAL_ONLY", resource_preservation.get("v2_precheck_admissibility") == "HISTORICAL_EVIDENCE_ONLY_NOT_REUSABLE_AS_V3_LIVE_PRECHECK")
    check("I040_RESOURCE_FRESH_V3_REQUIRED", resource_preservation.get("v3_requirement") == "FRESH_CONTEXT_MEASUREMENT_AND_INDEPENDENT_VALIDATION")
    classes = namespace_model.get("classes", {})
    check("I041_CALLER_SOURCE_CLASS", classes.get("CALLER_NAMESPACE_EXISTING_PATH", "").startswith("MAY_BE_ELIGIBLE"))
    check("I042_DESTINATION_CLASS", classes.get("SANDBOX_DESTINATION", "").startswith("MAY_BE_ELIGIBLE_ONLY_AS_DESTINATION"))
    check("I043_FUTURE_SOURCE_REJECTED", classes.get("FUTURE_CONSTRUCTED_SANDBOX_PATH") == "PROHIBITED_AS_BIND_SOURCE")
    check("I044_MISSING_SOURCE_REJECTED", classes.get("CALLER_NAMESPACE_MISSING_PATH") == "PROHIBITED_AS_BIND_SOURCE")
    check("I045_UNKNOWN_FAIL_CLOSED", classes.get("UNKNOWN") == "FAIL_CLOSED")
    check("I046_SOURCE_PRECHECK_REQUIRED", source_precheck.get("required") is True)
    check("I047_SOURCE_PRECHECK_ALL_BIND_TYPES", set(source_precheck.get("applies_to", [])) == {"--bind", "--ro-bind", "--bind-try", "--ro-bind-try", "--dev-bind", "--dev-bind-try"})
    check("I048_SOURCE_PRECHECK_BEFORE_MARKER", source_precheck.get("ordering", [])[-2:] == ["ONLY_THEN_WRITE_ATTEMPT_MARKER", "ONLY_THEN_LAUNCH_EXACT_CHILD"])
    check("I049_SOURCE_FAILURE_NO_CONSUME", source_precheck.get("failure") == "STOP_BEFORE_ATTEMPT_MARKER_ATTEMPT_REMAINS_ZERO")
    check("I050_VALIDATOR_TYPED", "TYPE_EACH_BIND_SOURCE_AND_DESTINATION" in validator.get("requirements", []))
    check("I051_VALIDATOR_FUTURE_REJECT", "REJECT_FUTURE_CONSTRUCTED_SANDBOX_SOURCE" in validator.get("requirements", []))
    check("I052_VALIDATOR_NO_SUBSTRING", validator.get("substring_or_raw_path_occurrence_counting") == "PROHIBITED")
    check("I053_REQUIRED_REGRESSIONS", len(validator.get("mandatory_regressions", [])) == 10)
    check("I054_SUCCESSOR_AUTHORIZED", successor.get("decision") == "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V3_CONDITIONALLY")
    check("I055_SUCCESSOR_STATE", successor.get("status") == "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I056_V3_IDENTITY", successor.get("execution_identity") == v3_binding.get("execution_identity") == V3_IDENTITY)
    check("I057_V3_OPERATION", successor.get("operation") == v3_binding.get("operation") == V3_OPERATION)
    check("I058_V3_PATH", v3_binding.get("workspace") == str(V3) and not V3.exists() and not V3.is_symlink())
    check("I059_V3_FRESH_LINEAGE", all(v3_binding.get(key) is True for key in ("fresh_source_required", "fresh_tests_required", "fresh_static_manifest_required", "fresh_static_execution_lock_required", "fresh_one_shot_contract_required")))
    check("I060_BOTH_PRECHECKS_REQUIRED", successor.get("resource_limit_feasibility_precheck") == successor.get("bind_source_resolution_precheck") == "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION")
    check("I061_STATIC_GATES_BOTH_PRECHECKS", gates.get("attempt_marker_gate") == "BOTH_RESOURCE_AND_BIND_SOURCE_PRECHECKS_MUST_PASS_WITHIN_FRESHNESS_WINDOW")
    check("I062_SINGLE_USE", single.get("maximum_attempts") == 1 and single.get("automatic_retry") is False and single.get("attempt_count_initial") == 0)
    check("I063_ATTEMPT_EVENT", "AFTER_RESOURCE_AND_BIND_SOURCE_PRECHECKS_PASS" in single.get("attempt_consumption_event", ""))
    check("I064_SUCCESS_CEILING", single.get("success_ceiling") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION")
    check("I065_GOVERNANCE_ONLY", authority.get("governance_only") is True and authority.get("v3_created_or_executed") is False)
    check("I066_DEFAULT_DENY", matrix.get("default") == "DENY")
    check("I067_V2_PROHIBITED", matrix.get("operations", {}).get("PATCH_RELOCK_RETRY_OR_PROMOTE_V2") == "PROHIBITED")
    check("I068_NO_V3_NOW", matrix.get("operations", {}).get("CREATE_OR_EXECUTE_V3_DURING_THIS_GOVERNANCE") == "NOT_AUTHORIZED")
    check("I069_DEFERRED_CAPABILITIES", all(matrix.get("operations", {}).get(key) == "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION" for key in ("CODEX_DAYBREAK_WORKER_SUBAGENT", "KERNEL_SANDBOX_PWNESCAPE_REPLAY", "TARGET_NETWORK_PARALLEL_CAPABILITY_FULL_CHAIN_SUBMISSION")))
    check("I070_NEXT_MILESTONE", next_gate.get("milestone") == "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V3_THEN_EXECUTE_RUNTIME_VALIDATION_V3_ONCE_IF_ALL_GATES_PASS")
    check("I071_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I072_NEGATIVE_MATRIX_COUNT", len(negative_matrix.get("tests", [])) == 36)
    check("I073_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 36 and negative.get("tests_failed") == 0)
    check("I074_ZERO_PRIMARY_COUNTERS", zero_typed(primary))
    check("I075_ZERO_NEGATIVE_COUNTERS", zero_typed(negative))
    check("I076_V2_BYTES_READ_ONLY", all(read_only(path) for path in V2.rglob("*") if path.is_file()))
    check("I077_V1_ANCHORS", sha(V1 / "locks/STATIC_EXECUTION_LOCK.json") == EXPECTED["v1_static_lock"] and sha(V1 / "evidence-v1/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == EXPECTED["v1_terminal"])
    check("I078_V2_COUNTERS", terminal.get("operation_counters", {}).get("runtime_validation_attempts") == terminal.get("operation_counters", {}).get("containment_fixture_attempts") == 1)

    failed = [item for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_ERRATUM_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "implementation": "INDEPENDENT_POSITIONAL_ARGV_WALK_AND_DIRECT_FROZEN_EVIDENCE_REREAD_V1",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed),
        "failed": failed,
        "checks": checks,
        "operation_counters": {key: 0 for key in OPERATION_KEYS},
    }
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"status": result["status"], "checks_total": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
