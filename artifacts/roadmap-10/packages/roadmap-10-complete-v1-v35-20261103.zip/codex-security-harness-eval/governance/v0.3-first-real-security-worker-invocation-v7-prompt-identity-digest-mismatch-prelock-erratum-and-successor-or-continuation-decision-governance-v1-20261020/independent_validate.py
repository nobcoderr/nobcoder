#!/usr/bin/env python3
"""Independent validation for the governance-only V7 prompt-identity erratum."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V7 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v7-20261020")
V8 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v8-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V7_PROMPT_IDENTITY_DIGEST_MISMATCH_"
    "PRELOCK_ERRATUM_AND_SUCCESSOR_OR_CONTINUATION_DECISION_GOVERNANCE_ONLY"
)
DECISION = (
    "TERMINALIZE_V7_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8_"
    "CONDITIONALLY"
)
NEXT = (
    "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_"
    "V8_ONCE_IF_ALL_GATES_PASS"
)
V7_ROOT = "770e0cf5baa0935714fac0883a01c702d0d165508a503eb63d137c9c262cc736"
ACTUAL_PROMPT = "8df9ae7a2021bfda0abf90df8cbdf3b23b2c3f27d2e280256d906f9e5b3a680f"
BOUND_PROMPT = "63f247baa09a97d9012059238b4922e7bebf05efa113245af14f3a0b0caad9da"
SCRIPTS = {
    "build_governance.py", "validate_governance.py", "independent_validate.py",
    "finalize_governance.py",
}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V7_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", "V7_PRELOCK_EVIDENCE_BINDING.json",
    "V7_TERMINAL_DISPOSITION.json", "PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "PROMPT_IDENTITY_BINDING_CONTRACT_V8.json",
    "V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V8_REQUIREMENTS.json",
    "SUCCESSOR_V8_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def tree(path: Path) -> tuple[str, int]:
    files = sorted(node for node in path.rglob("*") if node.is_file())
    material = "".join(
        f"{sha(item)}  {item.relative_to(path).as_posix()}\n" for item in files
    ).encode()
    return hashlib.sha256(material).hexdigest(), len(files)


def write(payload: dict[str, Any]) -> None:
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open(
        "x", encoding="utf-8", newline="\n"
    ) as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"independent input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("I_SCRIPT_" + script, valid)
    for artifact in sorted(BASE | RESULTS):
        try:
            doc = read(artifact)
            valid = doc.get("governance_identity") == IDENTITY
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            valid = False
        check("I_JSON_" + artifact, valid)

    root, members = tree(V7)
    check("I001_V7_ROOT", root == V7_ROOT and members == 39, {"root": root, "members": members})
    check("I002_V8_ABSENT", not V8.exists() and not V8.is_symlink())
    check("I003_NO_STATIC_LOCK", not (V7 / "STATIC_EXECUTION_LOCK.json").exists())
    check("I004_NO_FRESH_PREFLIGHT", not (V7 / "results/prelock/fresh-preflight-run-0001.json").exists())
    check("I005_NO_ATTEMPT", not (V7 / "static-run-v7/ATTEMPT_MARKER.json").exists())
    check(
        "I006_STATIC_RUN_EMPTY",
        (V7 / "static-run-v7").is_dir() and not any((V7 / "static-run-v7").iterdir()),
    )
    actual_prompt = sha(V7 / "fixture/worker-prompt.txt")
    request = json.loads((V7 / "contracts/WORKER_REQUEST.json").read_text(encoding="utf-8"))
    bound_prompt = request.get("prompt", {}).get("sha256")
    check("I007_ACTUAL_PROMPT_SHA", actual_prompt == ACTUAL_PROMPT, actual_prompt)
    check("I008_BOUND_PROMPT_SHA", bound_prompt == BOUND_PROMPT, bound_prompt)
    check("I009_MISMATCH_PROVEN", actual_prompt != bound_prompt)

    unit = json.loads((V7 / "results/prelock/unit-fixtures-run-0001.json").read_text(encoding="utf-8"))
    primary_native = json.loads((V7 / "results/prelock/primary-static-validation-run-0001.json").read_text(encoding="utf-8"))
    independent_native = json.loads((V7 / "results/prelock/independent-static-validation-run-0001.json").read_text(encoding="utf-8"))
    native_failures = [row["check_id"] for row in independent_native["checks"] if row["status"] == "FAIL"]
    check("I010_UNIT", unit["status"] == "PASS" and unit["checks_passed"] == unit["checks_total"] == 100)
    check("I011_PRIMARY_NATIVE", primary_native["status"] == "PASS" and primary_native["checks_passed"] == primary_native["checks_total"] == 100)
    check("I012_INDEPENDENT_NATIVE", independent_native["status"] == "FAIL_CLOSED" and independent_native["checks_passed"] == 77 and independent_native["checks_total"] == 78)
    check("I013_ONLY_I027", native_failures == ["I027_PROMPT_DIGEST"], native_failures)

    terminal = read("V7_TERMINAL_DISPOSITION.json")
    check("I014_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_PRELOCK_REFERENCE_PREDECESSOR" and terminal["immutable"] is True)
    check("I015_COUNTS_ZERO", terminal["attempt"] == "0_OF_1_NOT_CONSUMED" and terminal["worker_invocation"] == "0_OF_1" and terminal["codex_as_worker_invocation"] == "0_OF_1")
    check("I016_NO_RUNTIME_EVIDENCE", terminal["runtime_or_worker_evidence"] == "NONE_EXECUTION_NOT_STARTED")
    check("I017_NO_CONTINUATION", all(terminal[key] == "PROHIBITED" for key in (
        "patch_worker_request", "prompt_mutation", "preflight_continuation", "static_lock_issuance",
        "revalidation", "execution", "continuation",
    )))

    mismatch = read("PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION.json")
    check("I018_MISMATCH", mismatch["status"] == "DEFECT_CONFIRMED" and mismatch["actual_prompt_sha256"] == ACTUAL_PROMPT and mismatch["worker_request_bound_prompt_sha256"] == BOUND_PROMPT)
    check("I019_CAUSAL_UNKNOWN", mismatch["causal_history"].startswith("NOT_ESTABLISHED") and len(mismatch["prohibited_causal_claims"]) == 4)
    check("I020_NO_FALSE_CAUSAL_CLAIM", set(mismatch["prohibited_causal_claims"]) == {
        "STALE_DIGEST_WAS_COPIED", "PROMPT_WAS_EDITED_AFTER_BIND", "DIGEST_WAS_HAND_ENTERED",
        "GENERATION_ORDER_WAS_THE_CAUSE",
    })

    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    check("I021_OWNERSHIP", ownership["worker_request_prompt_binding_defect"] == "YES" and ownership["primary_validator_cross_artifact_binding_coverage_gap"] == "YES")
    check("I022_DRIFT_OBSERVATION_ONLY", ownership["prompt_artifact_identity_drift"] == "YES_AS_OBSERVED_STATE_NOT_CAUSAL_HISTORY")
    check("I023_ORDER_NOT_ESTABLISHED", ownership["prompt_digest_generation_order_defect"] == "NOT_ESTABLISHED")
    check("I024_VALIDATOR_DISPOSITION", ownership["independent_validator_defect"].startswith("NO_") and ownership["prompt_policy_semantics_defect"] == "NO")
    check("I025_NO_RUNTIME_DEFECT", ownership["security_worker_runtime_v1_defect"] == "NO" and ownership["codex_runtime_0_163_0_defect"] == "NOT_ESTABLISHED")

    contract = read("PROMPT_IDENTITY_BINDING_CONTRACT_V8.json")
    order = contract["canonical_order"]
    check("I026_FINAL_PROMPT_FIRST", order[0] == "FINALIZE_PROMPT_BYTES" and contract["final_prompt_first_digest_binding"] == "REQUIRED")
    check("I027_COMPUTE_THEN_BIND", order.index("COMPUTE_SHA256_FROM_FINAL_PROMPT_BYTES") < order.index("BIND_COMPUTED_DIGEST_INTO_WORKER_REQUEST"))
    check("I028_REREAD_REHASH", order.index("REREAD_PROMPT_FROM_BOUND_CANONICAL_PATH") < order.index("REHASH_REREAD_BYTES") < order.index("COMPARE_ACTUAL_BOUND_AND_REREAD_DIGESTS"))
    check("I029_NO_HAND_ENTRY", contract["digest_hand_entry"] == "PROHIBITED")
    check("I030_NO_POST_BIND_MUTATION", contract["post_bind_prompt_mutation"] == "PROHIBITED_AND_DETECTED_BY_REREAD_REHASH")
    check("I031_FAIL_CLOSED_ZERO", contract["mismatch_semantics"] == {
        "status": "STOP_FAIL_CLOSED", "attempt_count": 0,
        "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
    })
    check("I032_MULTI_GATE_RECHECK", set(contract["required_independent_checks"]) == {
        "PRIMARY_VALIDATOR_RECOMPUTES_PROMPT_SHA_AND_COMPARES_WORKER_REQUEST_BINDING",
        "INDEPENDENT_VALIDATOR_RECOMPUTES_PROMPT_SHA_AND_COMPARES_WORKER_REQUEST_BINDING",
        "FRESH_PREFLIGHT_REREADS_AND_REHASHES", "POST_LOCK_PREFLIGHT_REREADS_AND_REHASHES",
    })

    regression = read("V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX.json")
    cases = regression["cases"]
    check("I033_REGRESSIONS", len(cases) == 10 and len({row["case_id"] for row in cases}) == 10)
    check("I034_REGRESSION_EXPECTATIONS", sum(row["expected"] == "PASS" for row in cases) == 2 and sum(row["expected"] == "FAIL_CLOSED" for row in cases) == 8)
    check("I035_HISTORICAL_REGRESSION", any(row["case_id"] == "R003_V7_ACTUAL_VS_BOUND_MISMATCH" and row["expected"] == "FAIL_CLOSED" for row in cases))

    requirements = set(read("SUCCESSOR_V8_REQUIREMENTS.json")["mandatory_requirements"])
    check("I036_PROMPT_REQUIREMENTS", {
        "FINAL_PROMPT_FIRST_DIGEST_BINDING", "PROMPT_DIGEST_COMPUTED_FROM_FINAL_BYTES_NOT_HAND_ENTERED",
        "REREAD_AND_REHASH_VERIFICATION", "NO_POST_BIND_PROMPT_MUTATION",
        "FAIL_CLOSED_PROMPT_IDENTITY_MISMATCH",
        "PRIMARY_AND_INDEPENDENT_CROSS_ARTIFACT_PROMPT_IDENTITY_VALIDATION",
        "FRESH_AND_POST_LOCK_PREFLIGHT_PROMPT_IDENTITY_RECHECK",
    }.issubset(requirements))
    check("I037_CARRY_FORWARD", {
        "EXACT_CODEX_0_163_0_IDENTITY_AND_CONFIG_BINDING", "COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE",
        "CARRY_FORWARD_V1_THROUGH_V7_REGRESSIONS", "TYPED_FD_ANNOTATION_GRAMMAR",
        "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    }.issubset(requirements))

    successor = read("SUCCESSOR_V8_AUTHORIZATION_DECISION.json")
    check("I038_DECISION", successor["decision"] == DECISION and successor["continuation_v7"] == "DO_NOT_AUTHORIZE")
    check("I039_V8_STATE", successor["successor_identity"] == "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8" and successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I040_V8_ZERO", successor["attempt_count"] == successor["worker_invocation_count"] == successor["codex_as_worker_invocation_count"] == 0)
    check("I041_ONE_SHOT_LIMITS", successor["attempt_limit"] == successor["worker_invocation_limit"] == successor["codex_as_worker_invocation_limit"] == 1)
    check("I042_NOT_CREATED_NOW", successor["creation_or_execution_this_milestone"] is False)

    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    counters = authority["current_governance_operation_counters"]
    check("I043_ZERO_OPERATIONS", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {
        key: value for key, value in authority.items()
        if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False
    }
    check("I044_NO_CURRENT_ESCALATION", not escalations, escalations)

    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I045_PRIMARY", primary["status"] == "PASS" and primary["checks_passed"] == primary["checks_total"] and primary["checks_failed"] == 0)
    check("I046_NEGATIVE", negative["status"] == "PASS" and negative["tests_passed"] == negative["tests_total"] == 30 and negative["tests_failed"] == 0)
    matrix = read("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    check("I047_NEGATIVE_MATRIX", len(matrix["cases"]) == 30 and all(row["expected"] == "REJECT" for row in matrix["cases"]))
    routing = read("ROUTING_LEDGER.json")
    check("I048_ROUTING_NO_OPERATIONS", routing["subagents_used"] is False and routing["codex_invoked_during_governance"] is False and routing["worker_invoked_during_governance"] is False and routing["network_used_during_governance"] is False)
    summary = read("GOVERNANCE_DECISION_SUMMARY.json")
    check("I049_SUMMARY", summary["successor_decision"] == DECISION and summary["continuation_decision"] == "DO_NOT_AUTHORIZE_CONTINUATION_V7" and summary["causal_history"] == "NOT_ESTABLISHED")
    next_step = read("NEXT_LEGAL_MILESTONE.json")
    check("I050_NEXT", next_step["next_if_pass_locked"] == NEXT and next_step["v8_may_be_created_during_this_governance_milestone"] is False and next_step["v7_may_be_continued"] is False)

    failed = [row for row in checks if row["status"] == "FAIL"]
    write({
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0", "run_id": "INDEPENDENT_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks": checks,
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed), "operation_counters": counters,
    })
    print(json.dumps({
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "passed": len(checks) - len(failed), "total": len(checks),
    }, sort_keys=True))
    if failed:
        raise SystemExit("independent validation failed: " + ",".join(row["check_id"] for row in failed))


if __name__ == "__main__":
    main()
