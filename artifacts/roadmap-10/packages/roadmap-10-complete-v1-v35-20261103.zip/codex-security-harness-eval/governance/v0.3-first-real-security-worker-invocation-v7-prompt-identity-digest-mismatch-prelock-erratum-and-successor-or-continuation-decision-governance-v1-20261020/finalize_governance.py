#!/usr/bin/env python3
"""Final verification and immutable freeze for the V7 prompt-identity erratum."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V7 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v7-20261020")
V8 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v8-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V7_PROMPT_IDENTITY_DIGEST_MISMATCH_"
    "PRELOCK_ERRATUM_AND_SUCCESSOR_OR_CONTINUATION_DECISION_GOVERNANCE_ONLY"
)
DECISION = (
    "TERMINALIZE_V7_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8_"
    "CONDITIONALLY"
)
NEXT = (
    "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_"
    "V8_ONCE_IF_ALL_GATES_PASS"
)
V7_ROOT = "770e0cf5baa0935714fac0883a01c702d0d165508a503eb63d137c9c262cc736"
ACTUAL_PROMPT = "8df9ae7a2021bfda0abf90df8cbdf3b23b2c3f27d2e280256d906f9e5b3a680f"
BOUND_PROMPT = "63f247baa09a97d9012059238b4922e7bebf05efa113245af14f3a0b0caad9da"
SCRIPTS = {
    "build_governance.py", "validate_governance.py", "independent_validate.py",
    "finalize_governance.py",
}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V7_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", "V7_PRELOCK_EVIDENCE_BINDING.json",
    "V7_TERMINAL_DISPOSITION.json", "PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "PROMPT_IDENTITY_BINDING_CONTRACT_V8.json",
    "V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V8_REQUIREMENTS.json",
    "SUCCESSOR_V8_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def tree(path: Path) -> tuple[str, int]:
    files = sorted(node for node in path.rglob("*") if node.is_file())
    material = "".join(
        f"{sha(item)}  {item.relative_to(path).as_posix()}\n" for item in files
    ).encode()
    return hashlib.sha256(material).hexdigest(), len(files)


def canonical(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"])
    )
    return hashlib.sha256(material.encode()).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"finalizer input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SCRIPT_" + script, valid)

    v7_root, v7_members = tree(V7)
    check("F001_V7_UNCHANGED", v7_root == V7_ROOT and v7_members == 39, {"root": v7_root, "members": v7_members})
    check("F002_V8_ABSENT", not V8.exists() and not V8.is_symlink())
    check("F003_NO_STATIC_LOCK", not (V7 / "STATIC_EXECUTION_LOCK.json").exists())
    check("F004_NO_FRESH_PREFLIGHT", not (V7 / "results/prelock/fresh-preflight-run-0001.json").exists())
    check("F005_NO_ATTEMPT", not (V7 / "static-run-v7/ATTEMPT_MARKER.json").exists())
    check("F006_STATIC_RUN_EMPTY", (V7 / "static-run-v7").is_dir() and not any((V7 / "static-run-v7").iterdir()))
    actual_prompt = sha(V7 / "fixture/worker-prompt.txt")
    request = json.loads((V7 / "contracts/WORKER_REQUEST.json").read_text(encoding="utf-8"))
    bound_prompt = request.get("prompt", {}).get("sha256")
    check("F007_PROMPT_MISMATCH", actual_prompt == ACTUAL_PROMPT and bound_prompt == BOUND_PROMPT and actual_prompt != bound_prompt)

    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = read("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F008_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_passed"] == primary["checks_total"] and primary["checks_failed"] == 0)
    check("F009_NEGATIVE_PASS", negative["status"] == "PASS" and negative["tests_passed"] == negative["tests_total"] == 30 and negative["tests_failed"] == 0)
    check("F010_INDEPENDENT_PASS", independent["status"] == "PASS" and independent["checks_passed"] == independent["checks_total"] and independent["checks_failed"] == 0)
    check("F011_RESULT_IDENTITIES", all(document["governance_identity"] == IDENTITY for document in (primary, negative, independent)))

    terminal = read("V7_TERMINAL_DISPOSITION.json")
    mismatch = read("PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION.json")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    contract = read("PROMPT_IDENTITY_BINDING_CONTRACT_V8.json")
    regression = read("V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX.json")
    requirements = read("SUCCESSOR_V8_REQUIREMENTS.json")
    successor = read("SUCCESSOR_V8_AUTHORIZATION_DECISION.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    summary = read("GOVERNANCE_DECISION_SUMMARY.json")
    next_step = read("NEXT_LEGAL_MILESTONE.json")
    snapshot = read("V7_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json")
    binding = read("V7_PRELOCK_EVIDENCE_BINDING.json")

    check("F012_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_PRELOCK_REFERENCE_PREDECESSOR" and terminal["immutable"] is True)
    check("F013_V7_ZERO", terminal["attempt"] == "0_OF_1_NOT_CONSUMED" and terminal["worker_invocation"] == "0_OF_1" and terminal["codex_as_worker_invocation"] == "0_OF_1")
    check("F014_NO_EXECUTION_EVIDENCE", terminal["runtime_or_worker_evidence"] == "NONE_EXECUTION_NOT_STARTED")
    check("F015_V7_PROHIBITED", all(terminal[key] == "PROHIBITED" for key in (
        "patch_worker_request", "prompt_mutation", "preflight_continuation", "static_lock_issuance",
        "revalidation", "execution", "continuation",
    )))
    check("F016_SNAPSHOT", snapshot["canonical_tree_root_sha256"] == V7_ROOT and snapshot["member_count"] == len(snapshot["members"]) == 39)
    check("F017_BINDING", binding["canonical_tree_root_sha256"] == V7_ROOT and binding["member_count"] == 39 and binding["content_mutation_during_governance"] == "PROHIBITED")
    check("F018_MISMATCH_ADJUDICATED", mismatch["status"] == "DEFECT_CONFIRMED" and mismatch["actual_prompt_sha256"] == ACTUAL_PROMPT and mismatch["worker_request_bound_prompt_sha256"] == BOUND_PROMPT)
    check("F019_CAUSAL_HISTORY_UNKNOWN", mismatch["causal_history"].startswith("NOT_ESTABLISHED") and len(mismatch["prohibited_causal_claims"]) == 4)
    check("F020_OWNERSHIP", ownership["worker_request_prompt_binding_defect"] == "YES" and ownership["primary_validator_cross_artifact_binding_coverage_gap"] == "YES")
    check("F021_NO_INVENTED_ORDER_CAUSE", ownership["prompt_digest_generation_order_defect"] == "NOT_ESTABLISHED")
    check("F022_NO_PROMPT_OR_RUNTIME_DEFECT", ownership["prompt_policy_semantics_defect"] == "NO" and ownership["security_worker_runtime_v1_defect"] == "NO" and ownership["codex_runtime_0_163_0_defect"] == "NOT_ESTABLISHED")

    order = contract["canonical_order"]
    check("F023_FINAL_PROMPT_FIRST", order[0] == "FINALIZE_PROMPT_BYTES" and contract["final_prompt_first_digest_binding"] == "REQUIRED")
    check("F024_BINDING_ORDER", order.index("COMPUTE_SHA256_FROM_FINAL_PROMPT_BYTES") < order.index("BIND_COMPUTED_DIGEST_INTO_WORKER_REQUEST") < order.index("REREAD_PROMPT_FROM_BOUND_CANONICAL_PATH"))
    check("F025_REREAD_REHASH", order.index("REREAD_PROMPT_FROM_BOUND_CANONICAL_PATH") < order.index("REHASH_REREAD_BYTES") < order.index("COMPARE_ACTUAL_BOUND_AND_REREAD_DIGESTS"))
    check("F026_NO_MUTATION_OR_HAND_ENTRY", contract["digest_hand_entry"] == "PROHIBITED" and contract["post_bind_prompt_mutation"] == "PROHIBITED_AND_DETECTED_BY_REREAD_REHASH")
    check("F027_MISMATCH_FAIL_CLOSED", contract["mismatch_semantics"] == {
        "status": "STOP_FAIL_CLOSED", "attempt_count": 0,
        "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
    })
    check("F028_REGRESSIONS", len(regression["cases"]) == 10 and sum(row["expected"] == "FAIL_CLOSED" for row in regression["cases"]) == 8)
    required = set(requirements["mandatory_requirements"])
    check("F029_V8_REQUIREMENTS", {
        "FRESH_V8_IDENTITY_SOURCE_TESTS_LOCK_AND_ONE_SHOT_ATTEMPT",
        "V7_REFERENCE_PREDECESSOR_IMMUTABLE", "FINAL_PROMPT_FIRST_DIGEST_BINDING",
        "PROMPT_DIGEST_COMPUTED_FROM_FINAL_BYTES_NOT_HAND_ENTERED",
        "REREAD_AND_REHASH_VERIFICATION", "NO_POST_BIND_PROMPT_MUTATION",
        "FAIL_CLOSED_PROMPT_IDENTITY_MISMATCH",
        "PRIMARY_AND_INDEPENDENT_CROSS_ARTIFACT_PROMPT_IDENTITY_VALIDATION",
        "FRESH_AND_POST_LOCK_PREFLIGHT_PROMPT_IDENTITY_RECHECK",
        "COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE", "ONE_SHOT_EXECUTION",
        "SEPARATE_ACCEPTANCE_ADJUDICATION",
    }.issubset(required))
    check("F030_SUCCESSOR", successor["decision"] == DECISION and successor["continuation_v7"] == "DO_NOT_AUTHORIZE" and successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F031_SUCCESSOR_ZERO", successor["attempt_count"] == successor["worker_invocation_count"] == successor["codex_as_worker_invocation_count"] == 0)
    check("F032_SUCCESSOR_NOT_CREATED", successor["creation_or_execution_this_milestone"] is False)
    counters = authority["current_governance_operation_counters"]
    check("F033_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {
        key: value for key, value in authority.items()
        if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False
    }
    check("F034_NO_CURRENT_ESCALATION", not escalations, escalations)
    check("F035_SUMMARY", summary["successor_decision"] == DECISION and summary["continuation_decision"] == "DO_NOT_AUTHORIZE_CONTINUATION_V7" and summary["prompt_identity_match"] is False and summary["causal_history"] == "NOT_ESTABLISHED")
    check("F036_NEXT", next_step["next_if_pass_locked"] == NEXT and next_step["v8_may_be_created_during_this_governance_milestone"] is False and next_step["v7_may_be_continued"] is False)

    failed = [row for row in checks if row["status"] == "FAIL"]
    if failed:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failed))

    write(FREEZE, {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT",
        "schema_version": "1.0", "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001",
        "status": "PASS", "checks": checks, "checks_total": len(checks),
        "checks_passed": len(checks), "checks_failed": 0,
        "v7_tree_root_sha256": V7_ROOT, "v7_member_count": 39,
        "actual_prompt_sha256": ACTUAL_PROMPT, "worker_request_bound_prompt_sha256": BOUND_PROMPT,
        "prompt_identity_match": False, "v8_absent": True,
        "current_governance_operation_counters": counters,
        "read_only_freeze_enforced_by_successful_finalizer_exit": True,
    })

    names = sorted(expected | {FREEZE})
    rows = [
        {"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size}
        for name in names
    ]
    artifact_root = canonical(rows)
    write(MANIFEST, {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "member_count": len(rows), "members": rows,
        "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    snapshot_sha = sha(ROOT / "V7_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json")
    write(LOCK, {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0", "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": DECISION,
        "v7_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V7",
        "v7_disposition": "FAIL_CLOSED_PRELOCK_REFERENCE_PREDECESSOR",
        "v7_immutable": True, "v7_attempt_count": 0, "v7_attempt_limit": 1,
        "v7_worker_invocation_count": 0, "v7_worker_invocation_limit": 1,
        "v7_codex_as_worker_invocation_count": 0, "v7_codex_as_worker_invocation_limit": 1,
        "v7_fresh_preflight": "NOT_RUN", "v7_static_lock": "NOT_ISSUED",
        "v7_runtime_or_worker_evidence": "NONE_EXECUTION_NOT_STARTED",
        "v7_workspace_root_sha256": V7_ROOT,
        "v7_prelock_evidence_snapshot_manifest_sha256": snapshot_sha,
        "actual_prompt_sha256": ACTUAL_PROMPT,
        "worker_request_bound_prompt_sha256": BOUND_PROMPT,
        "actual_prompt_bytes_equal_bound_prompt_identity": False,
        "prompt_identity_digest_mismatch": "CONFIRMED",
        "causal_history": "NOT_ESTABLISHED",
        "worker_request_prompt_binding_defect": "YES",
        "prompt_artifact_identity_drift": "YES_AS_OBSERVED_STATE_NOT_CAUSAL_HISTORY",
        "prompt_digest_generation_order_defect": "NOT_ESTABLISHED",
        "primary_validator_cross_artifact_binding_coverage_gap": "YES",
        "independent_validator_defect": "NO_INDEPENDENT_VALIDATOR_CORRECTLY_FAILED_CLOSED",
        "prompt_policy_semantics_defect": "NO",
        "security_worker_runtime_v1_defect": "NO",
        "codex_runtime_0_163_0_defect": "NOT_ESTABLISHED",
        "worker_behavior_defect": "NOT_ESTABLISHED_EXECUTION_NEVER_STARTED",
        "continuation_v7": "DO_NOT_AUTHORIZE",
        "v8_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8",
        "v8_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v8_attempt_count": 0, "v8_attempt_limit": 1,
        "v8_worker_invocation_count": 0, "v8_worker_invocation_limit": 1,
        "v8_codex_as_worker_invocation_count": 0, "v8_codex_as_worker_invocation_limit": 1,
        "v8_final_prompt_first_digest_binding": "REQUIRED",
        "v8_digest_source": "FINAL_IMMUTABLE_PROMPT_BYTES_ONLY",
        "v8_reread_and_rehash_verification": "REQUIRED",
        "v8_post_bind_prompt_mutation": "PROHIBITED_AND_MUST_BE_DETECTED",
        "v8_prompt_identity_mismatch": "STOP_FAIL_CLOSED_BEFORE_ATTEMPT",
        "v8_primary_and_independent_cross_artifact_validation": "REQUIRED",
        "v8_fresh_and_post_lock_prompt_identity_recheck": "REQUIRED",
        "one_shot_execution": "REQUIRED",
        "separate_acceptance_adjudication": "REQUIRED",
        "worker_execution_authorized_now": False,
        "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False,
        "external_network_authorized": False, "subagent_authorized": False,
        "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "validation": {
            "primary": {"status": primary["status"], "passed": primary["checks_passed"], "total": primary["checks_total"]},
            "negative": {"status": negative["status"], "passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent": {"status": independent["status"], "passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        },
        "operation_counters": counters,
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "next_legal_milestone": NEXT,
        "authority_ceiling": (
            "V8_ENGINEERING_AND_ONE_LOCAL_FIXTURE_WORKER_INVOCATION_CONDITIONALLY_AUTHORIZED_"
            "ONLY_AFTER_THIS_LOCK_NO_CURRENT_WORKER_CODEX_TARGET_CREDENTIAL_SUBAGENT_PARALLEL_"
            "EXPLOIT_CAPABILITY_PROMOTION_OR_SUBMISSION_AUTHORITY"
        ),
    })

    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)

    readonly = all(
        (path.stat().st_mode & 0o222) == 0
        for path in ROOT.iterdir() if path.is_file()
    )
    v7_after, count_after = tree(V7)
    if (
        not readonly or v7_after != V7_ROOT or count_after != 39
        or V8.exists() or V8.is_symlink()
        or (V7 / "STATIC_EXECUTION_LOCK.json").exists()
        or (V7 / "results/prelock/fresh-preflight-run-0001.json").exists()
        or any((V7 / "static-run-v7").iterdir())
    ):
        raise SystemExit("post-freeze verification failed")
    print(json.dumps({
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "files": len(rows) + 2,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
