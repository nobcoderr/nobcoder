#!/usr/bin/env python3
"""Build the governance-only V7 prompt-identity erratum package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V7 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v7-20261020")
V8 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v8-20261020")
V6_GOV = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v6-tcpv6-fd-annotation-grammar-and-"
    "downstream-classifier-incompleteness-post-validation-failure-erratum-and-"
    "successor-decision-governance-v1-20261020"
)
WORKER_ACCEPT = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-security-worker-runtime-v1-frozen-evidence-acceptance-and-pass-locked-"
    "decision-governance-v1-20261020"
)
CODEX_ACCEPT = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-runtime-and-model-compatibility-execution-v7-frozen-evidence-acceptance-"
    "and-codex-0-163-0-pass-locked-decision-governance-v1-20261020"
)
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")

IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V7_PROMPT_IDENTITY_DIGEST_MISMATCH_"
    "PRELOCK_ERRATUM_AND_SUCCESSOR_OR_CONTINUATION_DECISION_GOVERNANCE_ONLY"
)
V7_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V7"
V8_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8"
DECISION = "TERMINALIZE_V7_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8_ONCE_IF_ALL_GATES_PASS"

HASHES = {
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
    "v7_tree_root": "770e0cf5baa0935714fac0883a01c702d0d165508a503eb63d137c9c262cc736",
    "prompt_actual": "8df9ae7a2021bfda0abf90df8cbdf3b23b2c3f27d2e280256d906f9e5b3a680f",
    "prompt_bound": "63f247baa09a97d9012059238b4922e7bebf05efa113245af14f3a0b0caad9da",
    "worker_request": "4104aa2e064860665d072dc83db7974e8954a21567b1bfb2c5ec23cb5628ade6",
    "invocation_source": "cb12158d8260277f159e601191a9b7a6d7601635dced847c704b2ef0c51e4f80",
    "human_gate": "0da759da4acf51458c1f97fe10a7cafb81349517eb608c39f55ca71b740fcc48",
    "identity_bindings": "c9d3b0e7d0ddabfcfe80437fd777b9631ec59f115416d5fa523153472dc410ce",
    "typed_fd_contract": "1a0045474db27b3b9ec526ffa6c76fad10e519e5a2afc67aa6324325acf5394a",
    "unit": "4c1f8189b3b05ac83b335a5c8ce68ba3c4fead63309b406c4f963ebc2551857d",
    "primary": "ce5591522065b503a4c34b1a62a59c20fa98be8864cd9b389be6bee1462b12fc",
    "independent": "091c122fc9abad9d1465f62f47016fbd06acca2772030b90726ad920ba891696",
    "v6_governance_lock": "c316ae31fb18da53e46031f11153d48ef012f6e7aa063bf0bdf901d76dfd9ba7",
    "v6_governance_manifest": "786723620898abf627c9044e9db86f9debb78477a292950b0cbd50521a1022ac",
    "worker_runtime_lock": "cc7928e67b9d5c74f04a750d8faae5bbdf97f2dd7fd4337885ddf10f85d6e8f7",
    "worker_runtime_manifest": "82aadd2c610409915cfc687ee9449eec4a9141b1aac99b654505a6b61db3dbad",
    "codex_lock": "3aedf0a656fd12680311f07fcf01e911e7a6a62f0b81871af347a55bc1ba7fef",
    "codex_manifest": "916f32ae710ee9a1721a151b4a1d0d16a05b268c2ef1ff2985e4235f4a64d1ae",
}

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
OPERATION_KEYS = [
    "worker_invocations", "codex_as_worker_invocations", "subagent_invocations",
    "credential_operations", "target_operations", "external_network_operations",
    "daybreak_invocations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def tree(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = [
        {
            "path": item.relative_to(path).as_posix(),
            "sha256": sha(item),
            "bytes": item.stat().st_size,
            "writable": bool(item.stat().st_mode & 0o222),
        }
        for item in sorted(node for node in path.rglob("*") if node.is_file())
    ]
    return canonical_root(rows), rows


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_fixed_inputs() -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any], dict[str, Any]]:
    if sha(ROUTER_MAP) != HASHES["router_map"]:
        raise SystemExit("router map drift")
    predecessors = [
        (V6_GOV, "v6_governance_lock", "v6_governance_manifest"),
        (WORKER_ACCEPT, "worker_runtime_lock", "worker_runtime_manifest"),
        (CODEX_ACCEPT, "codex_lock", "codex_manifest"),
    ]
    for path, lock_key, manifest_key in predecessors:
        if sha(path / "GOVERNANCE_LOCK.json") != HASHES[lock_key]:
            raise SystemExit(f"predecessor lock drift: {path}")
        if sha(path / "GOVERNANCE_ARTIFACT_MANIFEST.json") != HASHES[manifest_key]:
            raise SystemExit(f"predecessor manifest drift: {path}")
    root, rows = tree(V7)
    if root != HASHES["v7_tree_root"] or len(rows) != 39:
        raise SystemExit(f"V7 tree drift: root={root} members={len(rows)}")
    fixed = {
        "fixture/worker-prompt.txt": "prompt_actual",
        "contracts/WORKER_REQUEST.json": "worker_request",
        "src/invocation_v7.py": "invocation_source",
        "HUMAN_GATE.json": "human_gate",
        "contracts/IDENTITY_BINDINGS.json": "identity_bindings",
        "contracts/TYPED_FD_ANNOTATION_CONTRACT.json": "typed_fd_contract",
        "results/prelock/unit-fixtures-run-0001.json": "unit",
        "results/prelock/primary-static-validation-run-0001.json": "primary",
        "results/prelock/independent-static-validation-run-0001.json": "independent",
    }
    for relative, key in fixed.items():
        if sha(V7 / relative) != HASHES[key]:
            raise SystemExit(f"V7 evidence drift: {relative}")
    request = load(V7 / "contracts/WORKER_REQUEST.json")
    if request.get("prompt", {}).get("sha256") != HASHES["prompt_bound"]:
        raise SystemExit("WorkerRequest bound digest drift")
    if HASHES["prompt_actual"] == HASHES["prompt_bound"]:
        raise SystemExit("adjudicated mismatch unexpectedly absent")
    if (V7 / "STATIC_EXECUTION_LOCK.json").exists():
        raise SystemExit("V7 static lock unexpectedly exists")
    if (V7 / "results/prelock/fresh-preflight-run-0001.json").exists():
        raise SystemExit("V7 fresh preflight unexpectedly exists")
    if any((V7 / "static-run-v7").iterdir()):
        raise SystemExit("V7 static-run is not empty")
    if V8.exists() or V8.is_symlink():
        raise SystemExit("V8 must not exist during governance adjudication")
    return (
        rows,
        load(V7 / "results/prelock/unit-fixtures-run-0001.json"),
        load(V7 / "results/prelock/primary-static-validation-run-0001.json"),
        load(V7 / "results/prelock/independent-static-validation-run-0001.json"),
    )


def routing_decisions() -> list[dict[str, str]]:
    routing = load(ROUTER_MAP)
    active_conditional = {"agentic-security-research-harness", "external-ai-security-tool-governor"}
    decisions: list[dict[str, str]] = []
    for name, route in sorted(routing["skill_routes"].items()):
        if route.get("mode") == "always":
            state, reason = "ACTIVE", "MANDATORY_CORE_POLICY"
        elif name in active_conditional:
            state, reason = "ACTIVE", "LOCAL_AGENTIC_RUNTIME_IDENTITY_GOVERNANCE"
        else:
            state, reason = "NOT_APPLICABLE", "GOVERNANCE_ONLY_NO_TARGET_DISCOVERY_OR_EXECUTION"
        decisions.append({"module": name, "state": state, "reason": reason})
    decisions.append({"module": "codex-security-harness", "state": "ACTIVE", "reason": "LOCAL_HARNESS_GOVERNANCE_IDENTITY"})
    return decisions


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != SCRIPTS or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    rows, unit, primary, independent = verify_fixed_inputs()
    failed_ids = [row["check_id"] for row in independent["checks"] if row["status"] == "FAIL"]
    decisions = routing_decisions()

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0",
        "scope": "GOVERNANCE_ONLY_READ_ONLY_V7_PRELOCK_EVIDENCE_ADJUDICATION",
        "scope_evidence_card": {
            "asset": str(V7),
            "asset_kind": "LOCAL_FAIL_CLOSED_PRELOCK_WORKER_INVOCATION_WORKSPACE",
            "allowed_mode": "READ_ONLY_EVIDENCE_ADJUDICATION_LOCAL_GOVERNANCE_VALIDATION_AND_FREEZE",
            "target": "NONE", "credential": "NONE", "target_network": "NONE",
            "codex_invocation": "NONE", "worker_or_subagent": "NONE", "v8_implementation": "NONE",
        },
        "authorized_actions": [
            "READ_EXACT_V7_PRELOCK_EVIDENCE", "ADJUDICATE_PROMPT_IDENTITY_DIGEST_MISMATCH",
            "CLASSIFY_DEFECT_WITHOUT_UNPROVEN_CAUSAL_HISTORY", "CHOOSE_CONTINUATION_OR_SUCCESSOR",
            "DEFINE_SUCCESSOR_V8_PROMPT_IDENTITY_REQUIREMENTS", "ISSUE_CONDITIONAL_V8_DECISION",
            "RUN_LOCAL_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE",
        ],
        "forbidden_actions": [
            "PATCH_WORKER_REQUEST_OR_PROMPT", "CONTINUE_PREFLIGHT_LOCK_OR_EXECUTE_V7",
            "CREATE_OR_EXECUTE_V8", "CODEX_WORKER_OR_SUBAGENT_INVOCATION",
            "CREDENTIAL_TARGET_OR_NETWORK_OPERATION", "DAYBREAK_INVOCATION", "EXPLOIT_REPLAY",
            "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION",
        ],
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_ROUTING_LEDGER",
        "schema_version": "1.0", "router_map_sha256": HASHES["router_map"],
        "module_decisions": decisions,
        "active_count": sum(row["state"] == "ACTIVE" for row in decisions),
        "deferred_count": 0,
        "not_applicable_count": sum(row["state"] == "NOT_APPLICABLE" for row in decisions),
        "subagents_used": False, "codex_invoked_during_governance": False,
        "worker_invoked_during_governance": False, "network_used_during_governance": False,
    })
    v6_lock = load(V6_GOV / "GOVERNANCE_LOCK.json")
    worker_lock = load(WORKER_ACCEPT / "GOVERNANCE_LOCK.json")
    codex_lock = load(CODEX_ACCEPT / "GOVERNANCE_LOCK.json")
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_PREDECESSOR_CHAIN_BINDING",
        "schema_version": "1.0",
        "v7_authorization": {
            "identity": v6_lock["governance_identity"], "status": v6_lock["status"],
            "decision": v6_lock["decision"], "lock_sha256": HASHES["v6_governance_lock"],
            "manifest_sha256": HASHES["v6_governance_manifest"],
        },
        "security_worker_runtime_v1": {
            "status": worker_lock["security_worker_runtime_v1"], "lock_sha256": HASHES["worker_runtime_lock"],
            "manifest_sha256": HASHES["worker_runtime_manifest"],
        },
        "codex_runtime_0_163_0": {
            "status": codex_lock["codex_runtime_0_163_0"], "lock_sha256": HASHES["codex_lock"],
            "manifest_sha256": HASHES["codex_manifest"],
        },
    })
    write("V7_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST",
        "schema_version": "1.0", "execution_identity": V7_IDENTITY, "workspace": str(V7),
        "member_count": len(rows), "members": rows, "canonical_tree_root_sha256": HASHES["v7_tree_root"],
        "snapshot_kind": "EXTERNAL_GOVERNANCE_BINDING_OF_FAIL_CLOSED_PRELOCK_REFERENCE_PREDECESSOR",
        "source_workspace_mutated_during_governance": False,
    })
    write("V7_PRELOCK_EVIDENCE_BINDING.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_PRELOCK_EVIDENCE_BINDING",
        "schema_version": "1.0", "execution_identity": V7_IDENTITY, "workspace": str(V7),
        "member_count": len(rows), "canonical_tree_root_sha256": HASHES["v7_tree_root"],
        "key_artifact_sha256": {
            "fixture/worker-prompt.txt": HASHES["prompt_actual"],
            "contracts/WORKER_REQUEST.json": HASHES["worker_request"],
            "src/invocation_v7.py": HASHES["invocation_source"],
            "HUMAN_GATE.json": HASHES["human_gate"],
            "contracts/IDENTITY_BINDINGS.json": HASHES["identity_bindings"],
            "contracts/TYPED_FD_ANNOTATION_CONTRACT.json": HASHES["typed_fd_contract"],
            "results/prelock/unit-fixtures-run-0001.json": HASHES["unit"],
            "results/prelock/primary-static-validation-run-0001.json": HASHES["primary"],
            "results/prelock/independent-static-validation-run-0001.json": HASHES["independent"],
        },
        "content_mutation_during_governance": "PROHIBITED",
        "binding_semantics": "EXACT_BYTES_BOUND_WITHOUT_PATCH_REVALIDATION_CONTINUATION_OR_EXECUTION",
    })
    write("V7_TERMINAL_DISPOSITION.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_TERMINAL_DISPOSITION",
        "schema_version": "1.0", "execution_identity": V7_IDENTITY,
        "disposition": "FAIL_CLOSED_PRELOCK_REFERENCE_PREDECESSOR", "immutable": True,
        "unit_fixtures": f"{unit['checks_passed']}_OF_{unit['checks_total']}_{unit['status']}",
        "primary_static_validation": f"{primary['checks_passed']}_OF_{primary['checks_total']}_{primary['status']}",
        "independent_validation": f"{independent['checks_passed']}_OF_{independent['checks_total']}_{independent['status']}",
        "failed_check_ids": failed_ids, "fresh_preflight": "NOT_RUN", "static_lock": "NOT_ISSUED",
        "attempt": "0_OF_1_NOT_CONSUMED", "worker_invocation": "0_OF_1",
        "codex_as_worker_invocation": "0_OF_1", "runtime_or_worker_evidence": "NONE_EXECUTION_NOT_STARTED",
        "patch_worker_request": "PROHIBITED", "prompt_mutation": "PROHIBITED",
        "preflight_continuation": "PROHIBITED", "static_lock_issuance": "PROHIBITED",
        "revalidation": "PROHIBITED", "execution": "PROHIBITED", "continuation": "PROHIBITED",
    })
    write("PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION",
        "schema_version": "1.0", "status": "DEFECT_CONFIRMED",
        "actual_prompt_path": "fixture/worker-prompt.txt", "actual_prompt_sha256": HASHES["prompt_actual"],
        "worker_request_path": "contracts/WORKER_REQUEST.json", "worker_request_bound_prompt_sha256": HASHES["prompt_bound"],
        "actual_prompt_bytes_equal_bound_prompt_identity": False,
        "failed_gate": "I027_PROMPT_DIGEST", "mismatch_detected_by": "INDEPENDENT_STATIC_VALIDATOR",
        "prompt_semantic_policy_status": "PASS_NOT_RELEVANT_TO_BYTE_IDENTITY_MISMATCH",
        "typed_fd_grammar_status": "PASSED_UNIT_AND_PRIMARY_NOT_THE_CURRENT_BLOCKER",
        "causal_history": "NOT_ESTABLISHED_NO_PROVEN_EVENT_HISTORY_FOR_WHEN_OR_WHY_BYTES_AND_BINDING_DIVERGED",
        "prohibited_causal_claims": [
            "STALE_DIGEST_WAS_COPIED", "PROMPT_WAS_EDITED_AFTER_BIND", "DIGEST_WAS_HAND_ENTERED",
            "GENERATION_ORDER_WAS_THE_CAUSE",
        ],
        "compatibility": "NOT_ESTABLISHED_BY_V7", "confinement": "NOT_PROVEN_BY_V7",
    })
    write("DEFECT_OWNERSHIP_DECISION.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_DEFECT_OWNERSHIP_DECISION",
        "schema_version": "1.0",
        "worker_request_prompt_binding_defect": "YES",
        "prompt_artifact_identity_drift": "YES_AS_OBSERVED_STATE_NOT_CAUSAL_HISTORY",
        "prompt_digest_generation_order_defect": "NOT_ESTABLISHED",
        "primary_validator_cross_artifact_binding_coverage_gap": "YES",
        "independent_validator_defect": "NO_INDEPENDENT_VALIDATOR_CORRECTLY_FAILED_CLOSED",
        "prompt_policy_semantics_defect": "NO", "typed_fd_annotation_grammar_defect_in_v7": "NO_CURRENT_BLOCKER",
        "security_worker_runtime_v1_defect": "NO", "codex_runtime_0_163_0_defect": "NOT_ESTABLISHED",
        "worker_behavior_defect": "NOT_ESTABLISHED_EXECUTION_NEVER_STARTED",
        "owned_by": ["V7_WORKER_REQUEST_TO_PROMPT_ARTIFACT_IDENTITY_BINDING_CONTRACT", "V7_PRIMARY_CROSS_ARTIFACT_IDENTITY_VALIDATION_COVERAGE"],
    })
    write("PROMPT_IDENTITY_BINDING_CONTRACT_V8.json", {
        "record_type": "FIRST_WORKER_V8_PROMPT_IDENTITY_BINDING_CONTRACT",
        "schema_version": "1.0", "execution_identity": V8_IDENTITY,
        "canonical_order": [
            "FINALIZE_PROMPT_BYTES", "REJECT_SYMLINK_OR_NON_REGULAR_PROMPT", "COMPUTE_SHA256_FROM_FINAL_PROMPT_BYTES",
            "BIND_COMPUTED_DIGEST_INTO_WORKER_REQUEST", "REREAD_PROMPT_FROM_BOUND_CANONICAL_PATH",
            "REHASH_REREAD_BYTES", "COMPARE_ACTUAL_BOUND_AND_REREAD_DIGESTS", "ONLY_THEN_ALLOW_VALIDATION_TO_PASS",
        ],
        "final_prompt_first_digest_binding": "REQUIRED", "digest_hand_entry": "PROHIBITED",
        "post_bind_prompt_mutation": "PROHIBITED_AND_DETECTED_BY_REREAD_REHASH",
        "authoritative_identity_tuple": ["CANONICAL_PROMPT_PATH", "PROMPT_BYTE_LENGTH", "PROMPT_SHA256", "WORKER_REQUEST_SHA256"],
        "required_independent_checks": [
            "PRIMARY_VALIDATOR_RECOMPUTES_PROMPT_SHA_AND_COMPARES_WORKER_REQUEST_BINDING",
            "INDEPENDENT_VALIDATOR_RECOMPUTES_PROMPT_SHA_AND_COMPARES_WORKER_REQUEST_BINDING",
            "FRESH_PREFLIGHT_REREADS_AND_REHASHES", "POST_LOCK_PREFLIGHT_REREADS_AND_REHASHES",
        ],
        "mismatch_semantics": {"status": "STOP_FAIL_CLOSED", "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0},
    })
    regression_cases = [
        {"case_id": "R001_FINAL_BYTES_BOUND_EXACTLY", "kind": "POSITIVE", "expected": "PASS"},
        {"case_id": "R002_REREAD_REHASH_MATCH", "kind": "POSITIVE", "expected": "PASS"},
        {"case_id": "R003_V7_ACTUAL_VS_BOUND_MISMATCH", "kind": "HISTORICAL_NEGATIVE", "expected": "FAIL_CLOSED"},
        {"case_id": "R004_PROMPT_MUTATED_AFTER_BIND", "kind": "NEGATIVE", "expected": "FAIL_CLOSED"},
        {"case_id": "R005_WORKER_REQUEST_DIGEST_MUTATED", "kind": "NEGATIVE", "expected": "FAIL_CLOSED"},
        {"case_id": "R006_PROMPT_PATH_SYMLINK", "kind": "NEGATIVE", "expected": "FAIL_CLOSED"},
        {"case_id": "R007_PROMPT_PATH_MISSING", "kind": "NEGATIVE", "expected": "FAIL_CLOSED"},
        {"case_id": "R008_SEMANTICALLY_EQUIVALENT_BUT_BYTE_DIFFERENT", "kind": "NEGATIVE", "expected": "FAIL_CLOSED"},
        {"case_id": "R009_STALE_COPIED_DIGEST", "kind": "NEGATIVE", "expected": "FAIL_CLOSED"},
        {"case_id": "R010_NO_REREAD_AFTER_BIND", "kind": "NEGATIVE", "expected": "FAIL_CLOSED"},
    ]
    write("V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX",
        "schema_version": "1.0", "cases": regression_cases,
        "historical_actual_prompt_sha256": HASHES["prompt_actual"],
        "historical_bound_prompt_sha256": HASHES["prompt_bound"],
    })
    write("SUCCESSOR_V8_REQUIREMENTS.json", {
        "record_type": "FIRST_WORKER_V8_SUCCESSOR_REQUIREMENTS", "schema_version": "1.0",
        "execution_identity": V8_IDENTITY,
        "mandatory_requirements": [
            "FRESH_V8_IDENTITY_SOURCE_TESTS_LOCK_AND_ONE_SHOT_ATTEMPT", "V7_REFERENCE_PREDECESSOR_IMMUTABLE",
            "FINAL_PROMPT_FIRST_DIGEST_BINDING", "PROMPT_DIGEST_COMPUTED_FROM_FINAL_BYTES_NOT_HAND_ENTERED",
            "REREAD_AND_REHASH_VERIFICATION", "NO_POST_BIND_PROMPT_MUTATION", "FAIL_CLOSED_PROMPT_IDENTITY_MISMATCH",
            "PRIMARY_AND_INDEPENDENT_CROSS_ARTIFACT_PROMPT_IDENTITY_VALIDATION",
            "FRESH_AND_POST_LOCK_PREFLIGHT_PROMPT_IDENTITY_RECHECK",
            "EXACT_CODEX_0_163_0_IDENTITY_AND_CONFIG_BINDING", "COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE",
            "CARRY_FORWARD_V1_THROUGH_V7_REGRESSIONS", "TYPED_FD_ANNOTATION_GRAMMAR",
            "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION",
        ],
        "pre_attempt_gate": "PROMPT_IDENTITY_BINDING_PRECHECK_PASS_REQUIRED_BEFORE_ATTEMPT_MARKER",
        "failure_semantics": {"status": "STOP_FAIL_CLOSED", "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0},
    })
    write("SUCCESSOR_V8_AUTHORIZATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V8_SUCCESSOR_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": DECISION, "continuation_v7": "DO_NOT_AUTHORIZE",
        "successor_identity": V8_IDENTITY, "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "creation_or_execution_this_milestone": False, "attempt_count": 0, "attempt_limit": 1,
        "worker_invocation_count": 0, "worker_invocation_limit": 1,
        "codex_as_worker_invocation_count": 0, "codex_as_worker_invocation_limit": 1,
        "exact_codex_runtime": "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED",
        "authorization_effective_only_if_this_package": "PASS_LOCKED_GOVERNANCE_ONLY",
    })
    counters = {key: 0 for key in OPERATION_KEYS}
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION",
        "schema_version": "1.0", "current_governance_operation_counters": counters,
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "v7_continuation_authorized": False, "v8_implementation_or_execution_authorized_during_governance": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_OPERATION_AUTHORIZATION_MATRIX",
        "schema_version": "1.0",
        "current_milestone": {
            "read_v7_evidence": "AUTHORIZED_READ_ONLY", "governance_validation": "AUTHORIZED_LOCAL_ONLY",
            "governance_freeze": "AUTHORIZED_IF_ALL_GATES_PASS",
        },
        "not_authorized_current_milestone": [
            "PATCH_WORKER_REQUEST", "MUTATE_PROMPT", "CONTINUE_V7", "FRESH_PREFLIGHT_V7", "STATIC_LOCK_V7",
            "CREATE_OR_EXECUTE_V8", "CODEX_OR_WORKER_INVOCATION", "SUBAGENT", "CREDENTIAL", "TARGET", "NETWORK",
            "DAYBREAK", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "PROMOTION", "SUBMISSION",
        ],
    })
    negative_cases = [
        "ALLOW_CONTINUATION_V7", "PATCH_WORKER_REQUEST_DIGEST", "REWRITE_PROMPT_TO_MATCH_STALE_DIGEST",
        "RUN_FRESH_PREFLIGHT_V7", "ISSUE_STATIC_LOCK_V7", "INVOKE_CODEX_V7", "INVOKE_WORKER_V7",
        "CREATE_V8_DURING_GOVERNANCE", "CLAIM_ACTUAL_EQUALS_BOUND", "CLAIM_PROMPT_POLICY_DEFECT",
        "CLAIM_INDEPENDENT_VALIDATOR_DEFECT", "CLAIM_CODEX_DEFECT", "CLAIM_WORKER_DEFECT",
        "CLAIM_CAUSE_STALE_COPY", "CLAIM_CAUSE_POST_BIND_EDIT", "CLAIM_CAUSE_HAND_ENTRY",
        "CLAIM_CAUSE_GENERATION_ORDER", "OMIT_FINAL_PROMPT_FIRST", "OMIT_REREAD_REHASH",
        "ALLOW_POST_BIND_MUTATION", "ALLOW_DIGEST_HAND_ENTRY", "ALLOW_MISMATCH_WITH_WARNING",
        "ALLOW_PROMPT_SYMLINK", "OMIT_PRIMARY_CROSS_ARTIFACT_CHECK", "OMIT_INDEPENDENT_CROSS_ARTIFACT_CHECK",
        "OPEN_TARGET_OR_NETWORK", "OPEN_CREDENTIAL_OR_SUBAGENT", "OPEN_PARALLELISM_OR_CAPABILITY_GRAPH",
        "OPEN_PROMOTION_OR_SUBMISSION", "PROMOTE_V7_TO_PASS_LOCKED",
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "schema_version": "1.0", "cases": [
            {"case_id": f"N{index:03d}", "mutation": mutation, "expected": "REJECT"}
            for index, mutation in enumerate(negative_cases, 1)
        ],
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_GOVERNANCE_DECISION_SUMMARY",
        "schema_version": "1.0", "v7_disposition": "FAIL_CLOSED_PRELOCK_REFERENCE_PREDECESSOR",
        "v7_attempt_count": 0, "v7_worker_invocation_count": 0, "v7_codex_as_worker_invocation_count": 0,
        "actual_prompt_sha256": HASHES["prompt_actual"], "bound_prompt_sha256": HASHES["prompt_bound"],
        "prompt_identity_match": False, "causal_history": "NOT_ESTABLISHED",
        "continuation_decision": "DO_NOT_AUTHORIZE_CONTINUATION_V7", "successor_decision": DECISION,
        "compatibility": "NOT_ESTABLISHED_BY_V7", "confinement": "NOT_PROVEN_BY_V7", "pass_locked": "NO",
        "governance_status_before_freeze": "VALIDATION_REQUIRED",
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_NEXT_LEGAL_MILESTONE",
        "schema_version": "1.0", "next_if_pass_locked": NEXT,
        "v8_may_be_created_during_this_governance_milestone": False,
        "v7_may_be_continued": False,
    })
    print(json.dumps({"status": "BUILT_NOT_VALIDATED", "files": 17, "decision": DECISION}, sort_keys=True))


if __name__ == "__main__":
    main()
