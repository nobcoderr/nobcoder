#!/usr/bin/env python3
"""Primary and negative governance validation for the V7 prompt-identity erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V7 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v7-20261020")
V8 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v8-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V7_PROMPT_IDENTITY_DIGEST_MISMATCH_"
    "PRELOCK_ERRATUM_AND_SUCCESSOR_OR_CONTINUATION_DECISION_GOVERNANCE_ONLY"
)
DECISION = "TERMINALIZE_V7_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V8_CONDITIONALLY"
V7_ROOT = "770e0cf5baa0935714fac0883a01c702d0d165508a503eb63d137c9c262cc736"
ACTUAL_PROMPT = "8df9ae7a2021bfda0abf90df8cbdf3b23b2c3f27d2e280256d906f9e5b3a680f"
BOUND_PROMPT = "63f247baa09a97d9012059238b4922e7bebf05efa113245af14f3a0b0caad9da"
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V7_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", "V7_PRELOCK_EVIDENCE_BINDING.json",
    "V7_TERMINAL_DISPOSITION.json", "PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "PROMPT_IDENTITY_BINDING_CONTRACT_V8.json",
    "V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V8_REQUIREMENTS.json",
    "SUCCESSOR_V8_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def tree_root(path: Path) -> tuple[str, int]:
    rows = [
        f"{sha(member)}  {member.relative_to(path).as_posix()}\n"
        for member in sorted(item for item in path.rglob("*") if item.is_file())
    ]
    return hashlib.sha256("".join(rows).encode()).hexdigest(), len(rows)


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    actual_files = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual_files != SCRIPTS | BASE or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected primary input set: {sorted(actual_files)}")
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for name in sorted(BASE):
        try:
            doc = read(name)
            valid = doc.get("governance_identity") == IDENTITY
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            valid = False
        check("P_JSON_" + name, valid)
    v7_root, v7_count = tree_root(V7)
    check("P001_V7_TREE_BOUND", v7_root == V7_ROOT and v7_count == 39, {"root": v7_root, "members": v7_count})
    check("P002_V8_ABSENT", not V8.exists() and not V8.is_symlink())
    check("P003_NO_STATIC_LOCK", not (V7 / "STATIC_EXECUTION_LOCK.json").exists())
    check("P004_NO_FRESH_PREFLIGHT", not (V7 / "results/prelock/fresh-preflight-run-0001.json").exists())
    check("P005_NO_ATTEMPT", not (V7 / "static-run-v7/ATTEMPT_MARKER.json").exists())
    check("P006_STATIC_RUN_EMPTY", (V7 / "static-run-v7").is_dir() and not any((V7 / "static-run-v7").iterdir()))
    actual_prompt = sha(V7 / "fixture/worker-prompt.txt")
    request = json.loads((V7 / "contracts/WORKER_REQUEST.json").read_text(encoding="utf-8"))
    bound_prompt = request.get("prompt", {}).get("sha256")
    check("P007_ACTUAL_PROMPT_SHA", actual_prompt == ACTUAL_PROMPT, actual_prompt)
    check("P008_BOUND_PROMPT_SHA", bound_prompt == BOUND_PROMPT, bound_prompt)
    check("P009_MISMATCH_PROVEN", actual_prompt != bound_prompt)
    unit = json.loads((V7 / "results/prelock/unit-fixtures-run-0001.json").read_text())
    primary = json.loads((V7 / "results/prelock/primary-static-validation-run-0001.json").read_text())
    independent = json.loads((V7 / "results/prelock/independent-static-validation-run-0001.json").read_text())
    failed_ids = [row["check_id"] for row in independent["checks"] if row["status"] == "FAIL"]
    check("P010_UNIT", unit["status"] == "PASS" and unit["checks_passed"] == unit["checks_total"] == 100)
    check("P011_PRIMARY", primary["status"] == "PASS" and primary["checks_passed"] == primary["checks_total"] == 100)
    check("P012_INDEPENDENT_FAIL", independent["status"] == "FAIL_CLOSED" and independent["checks_passed"] == 77 and independent["checks_total"] == 78)
    check("P013_ONLY_PROMPT_DIGEST_FAILED", failed_ids == ["I027_PROMPT_DIGEST"], failed_ids)
    terminal = read("V7_TERMINAL_DISPOSITION.json")
    check("P014_V7_DISPOSITION", terminal["disposition"] == "FAIL_CLOSED_PRELOCK_REFERENCE_PREDECESSOR" and terminal["immutable"] is True)
    check("P015_V7_ZERO", terminal["attempt"] == "0_OF_1_NOT_CONSUMED" and terminal["worker_invocation"] == "0_OF_1" and terminal["codex_as_worker_invocation"] == "0_OF_1")
    check("P016_V7_PROHIBITIONS", all(terminal[key] == "PROHIBITED" for key in (
        "patch_worker_request", "prompt_mutation", "preflight_continuation", "static_lock_issuance",
        "revalidation", "execution", "continuation",
    )))
    mismatch = read("PROMPT_IDENTITY_DIGEST_MISMATCH_ADJUDICATION.json")
    check("P017_MISMATCH_ADJUDICATED", mismatch["status"] == "DEFECT_CONFIRMED" and mismatch["actual_prompt_bytes_equal_bound_prompt_identity"] is False)
    check("P018_CAUSAL_HISTORY_UNKNOWN", mismatch["causal_history"].startswith("NOT_ESTABLISHED") and len(mismatch["prohibited_causal_claims"]) == 4)
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    check("P019_BINDING_DEFECT", ownership["worker_request_prompt_binding_defect"] == "YES")
    check("P020_OBSERVED_DRIFT_NOT_CAUSE", ownership["prompt_artifact_identity_drift"] == "YES_AS_OBSERVED_STATE_NOT_CAUSAL_HISTORY")
    check("P021_ORDER_CAUSE_NOT_ESTABLISHED", ownership["prompt_digest_generation_order_defect"] == "NOT_ESTABLISHED")
    check("P022_INDEPENDENT_VALIDATOR_NOT_DEFECT", ownership["independent_validator_defect"].startswith("NO_"))
    contract = read("PROMPT_IDENTITY_BINDING_CONTRACT_V8.json")
    check("P023_FINAL_PROMPT_FIRST", contract["canonical_order"][0] == "FINALIZE_PROMPT_BYTES" and contract["final_prompt_first_digest_binding"] == "REQUIRED")
    check("P024_REREAD_REHASH", "REREAD_PROMPT_FROM_BOUND_CANONICAL_PATH" in contract["canonical_order"] and "REHASH_REREAD_BYTES" in contract["canonical_order"])
    check("P025_NO_HAND_ENTRY_OR_POST_BIND_MUTATION", contract["digest_hand_entry"] == "PROHIBITED" and contract["post_bind_prompt_mutation"].startswith("PROHIBITED"))
    check("P026_FAIL_CLOSED_ZERO", contract["mismatch_semantics"] == {"status": "STOP_FAIL_CLOSED", "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0})
    regression = read("V7_FAILURE_AND_V8_SUCCESSOR_REGRESSION_MATRIX.json")
    check("P027_REGRESSION_MATRIX", len(regression["cases"]) == 10 and sum(row["expected"] == "FAIL_CLOSED" for row in regression["cases"]) == 8)
    requirements = set(read("SUCCESSOR_V8_REQUIREMENTS.json")["mandatory_requirements"])
    check("P028_SUCCESSOR_REQUIREMENTS", {
        "FINAL_PROMPT_FIRST_DIGEST_BINDING", "REREAD_AND_REHASH_VERIFICATION",
        "NO_POST_BIND_PROMPT_MUTATION", "FAIL_CLOSED_PROMPT_IDENTITY_MISMATCH",
        "PRIMARY_AND_INDEPENDENT_CROSS_ARTIFACT_PROMPT_IDENTITY_VALIDATION",
        "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    }.issubset(requirements))
    successor = read("SUCCESSOR_V8_AUTHORIZATION_DECISION.json")
    check("P029_V8_DECISION", successor["decision"] == DECISION and successor["continuation_v7"] == "DO_NOT_AUTHORIZE")
    check("P030_V8_STATE", successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED" and successor["creation_or_execution_this_milestone"] is False)
    check("P031_V8_ZERO", successor["attempt_count"] == successor["worker_invocation_count"] == successor["codex_as_worker_invocation_count"] == 0)
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    counters = authority["current_governance_operation_counters"]
    check("P032_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {key: value for key, value in authority.items() if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False}
    check("P033_NO_CURRENT_ESCALATION", not escalations, escalations)
    routing = read("ROUTING_LEDGER.json")
    check("P034_NO_OPERATIONAL_ROUTING", routing["subagents_used"] is False and routing["codex_invoked_during_governance"] is False and routing["worker_invoked_during_governance"] is False and routing["network_used_during_governance"] is False)
    summary = read("GOVERNANCE_DECISION_SUMMARY.json")
    check("P035_SUMMARY", summary["successor_decision"] == DECISION and summary["continuation_decision"] == "DO_NOT_AUTHORIZE_CONTINUATION_V7" and summary["prompt_identity_match"] is False)
    next_step = read("NEXT_LEGAL_MILESTONE.json")
    check("P036_NEXT", next_step["v8_may_be_created_during_this_governance_milestone"] is False and next_step["v7_may_be_continued"] is False)

    failed = [row for row in checks if row["status"] == "FAIL"]
    write("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0", "run_id": "GOVERNANCE_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks": checks,
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": counters,
    })
    if failed:
        raise SystemExit("primary governance validation failed: " + ",".join(row["check_id"] for row in failed))

    matrix = read("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    allowed_mutations = {
        "ALLOW_CONTINUATION_V7", "PATCH_WORKER_REQUEST_DIGEST", "REWRITE_PROMPT_TO_MATCH_STALE_DIGEST",
        "RUN_FRESH_PREFLIGHT_V7", "ISSUE_STATIC_LOCK_V7", "INVOKE_CODEX_V7", "INVOKE_WORKER_V7",
        "CREATE_V8_DURING_GOVERNANCE", "CLAIM_ACTUAL_EQUALS_BOUND", "CLAIM_PROMPT_POLICY_DEFECT",
        "CLAIM_INDEPENDENT_VALIDATOR_DEFECT", "CLAIM_CODEX_DEFECT", "CLAIM_WORKER_DEFECT",
        "CLAIM_CAUSE_STALE_COPY", "CLAIM_CAUSE_POST_BIND_EDIT", "CLAIM_CAUSE_HAND_ENTRY",
        "CLAIM_CAUSE_GENERATION_ORDER", "OMIT_FINAL_PROMPT_FIRST", "OMIT_REREAD_REHASH",
        "ALLOW_POST_BIND_MUTATION", "ALLOW_DIGEST_HAND_ENTRY", "ALLOW_MISMATCH_WITH_WARNING",
        "ALLOW_PROMPT_SYMLINK", "OMIT_PRIMARY_CROSS_ARTIFACT_CHECK", "OMIT_INDEPENDENT_CROSS_ARTIFACT_CHECK",
        "OPEN_TARGET_OR_NETWORK", "OPEN_CREDENTIAL_OR_SUBAGENT", "OPEN_PARALLELISM_OR_CAPABILITY_GRAPH",
        "OPEN_PROMOTION_OR_SUBMISSION", "PROMOTE_V7_TO_PASS_LOCKED",
    }
    negative_results = []
    for case in matrix["cases"]:
        rejected = case.get("expected") == "REJECT" and case.get("mutation") in allowed_mutations
        negative_results.append({
            "case_id": case.get("case_id"), "mutation": case.get("mutation"),
            "expected": case.get("expected"), "observed": "REJECT" if rejected else "ACCEPT",
            "status": "PASS" if rejected else "FAIL",
        })
    negative_failed = [row for row in negative_results if row["status"] == "FAIL"]
    write("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V7_PROMPT_IDENTITY_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "schema_version": "1.0", "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if not negative_failed and len(negative_results) == 30 else "FAIL_CLOSED",
        "tests": negative_results, "tests_total": len(negative_results),
        "tests_passed": len(negative_results) - len(negative_failed), "tests_failed": len(negative_failed),
        "operation_counters": counters,
    })
    status = "PASS" if not negative_failed and len(negative_results) == 30 else "FAIL_CLOSED"
    print(json.dumps({"primary": "PASS", "primary_checks": len(checks), "negative": status, "negative_tests": len(negative_results)}, sort_keys=True))
    if status != "PASS":
        raise SystemExit("negative governance fixtures failed")


if __name__ == "__main__":
    main()
