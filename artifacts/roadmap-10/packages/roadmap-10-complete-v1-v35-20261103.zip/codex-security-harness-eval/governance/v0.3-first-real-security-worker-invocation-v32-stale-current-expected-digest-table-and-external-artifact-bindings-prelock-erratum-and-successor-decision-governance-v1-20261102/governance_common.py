"""Read-only evidence helpers for the V32 governance-only adjudication."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parent
V32 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v32-20261102")
V31 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102")
V33 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v33-20261102")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V32_STALE_CURRENT_EXPECTED_DIGEST_"
    "TABLE_AND_EXTERNAL_ARTIFACT_BINDINGS_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_"
    "GOVERNANCE_ONLY"
)
V32_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V32"
V33_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V33"
V32_STATUS = "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE"
V32_ROOT_SHA = "6cd2d2f2f3134683d73426fcac0f2e19ec0da670f7621bafe488bfada9a631c5"
V32_TERMINAL_SHA = "ef3e0b4adfc003fae338e5a5de67144f1cb1cfb0c051b531cc49afb4ebe7322c"
V32_MANIFEST_SHA = "46e1dd5743aaa4260b6cf0c77c8ab7f24880a8292f25ad9ef60c8b51eb8a24e2"
V32_FREEZE_SHA = "9996517d88e886284c926fc1f2b8436477737246c7d514f4aafcc4167475898b"
V32_UNIT_SHA = "02781f0b68ac0f11c5eefd98ab933de67cd0be703a5729b6c4c3def42a5c5f7e"
CLOSURE_SHA = "bda0e42fdeda1facb47b5eed49d05f22b831661e227ce415bb824422c5ee4d48"
BINDING_SHA = "fe220f7224927dc5cb2146e46fdd8c5312519511aafa54cbb16b2070b1eb782d"
UNIFIED_SHA = "b0105d8f570b51cab970497b6157cb2c6fc5bb86333e657f4ad149c49923e784"
CURRENT_GENERATION = "V32_CURRENT_GOVERNANCE_BOUND_TYPED_PREFLIGHT_BINDING_GENERATION_0001"
HISTORICAL_GENERATION = "V31_CURRENT_GOVERNANCE_BOUND_TYPED_PREFLIGHT_BINDING_GENERATION_0001"

FAILURES = {
    "U063_EXTERNAL_successor_v32_requirements",
    "U065_EXTERNAL_typed_historical_decision_registry",
    "U066_EXTERNAL_typed_historical_decision_registry_contract",
    "U067_EXTERNAL_unified_binding_generation_contract",
    "U104_EXTERNAL_v32_symbol_resolution_regression_matrix",
    "U105_EXTERNAL_v32_typed_module_identity_contract",
}

ARTIFACTS = {
    "successor_v32_requirements": {
        "path": "contracts/SUCCESSOR_V32_REQUIREMENTS.json",
        "historical_path": "contracts/SUCCESSOR_V31_REQUIREMENTS.json",
        "logical_identity": "SUCCESSOR_V32_REQUIREMENTS",
        "historical_logical_identity": "SUCCESSOR_V31_REQUIREMENTS",
    },
    "typed_historical_decision_registry": {
        "path": "contracts/TYPED_HISTORICAL_DECISION_REGISTRY.json",
        "historical_path": "contracts/TYPED_HISTORICAL_DECISION_REGISTRY.json",
        "logical_identity": "V32_TYPED_HISTORICAL_DECISION_REGISTRY",
        "historical_logical_identity": "V31_TYPED_HISTORICAL_DECISION_REGISTRY",
    },
    "typed_historical_decision_registry_contract": {
        "path": "contracts/TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT.json",
        "historical_path": "contracts/TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT.json",
        "logical_identity": "V32_TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT",
        "historical_logical_identity": "V31_TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT",
    },
    "unified_binding_generation_contract": {
        "path": "contracts/UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json",
        "historical_path": "contracts/UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json",
        "logical_identity": "V32_UNIFIED_BINDING_GENERATION_CONTRACT",
        "historical_logical_identity": "V31_UNIFIED_BINDING_GENERATION_CONTRACT",
    },
    "v32_symbol_resolution_regression_matrix": {
        "path": "contracts/V32_STANDARD_LIBRARY_SYMBOL_RESOLUTION_REGRESSION_MATRIX.json",
        "historical_path": "contracts/V31_STANDARD_LIBRARY_SYMBOL_RESOLUTION_REGRESSION_MATRIX.json",
        "logical_identity": "V32_SYMBOL_RESOLUTION_REGRESSION_MATRIX",
        "historical_logical_identity": "V31_SYMBOL_RESOLUTION_REGRESSION_MATRIX",
    },
    "v32_typed_module_identity_contract": {
        "path": "contracts/TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json",
        "historical_path": "contracts/TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json",
        "logical_identity": "V32_TYPED_CANONICAL_MODULE_IDENTITY_CONTRACT",
        "historical_logical_identity": "V31_TYPED_CANONICAL_MODULE_IDENTITY_CONTRACT",
    },
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_once(path: Path, value: Any) -> None:
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"append-only output exists: {path}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def paths() -> dict[str, Path]:
    pre = V32 / "results/prelock"
    return {
        "terminal": pre / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
        "manifest": pre / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
        "freeze": pre / "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
        "unit": pre / "unit-fixtures-run-0001.json",
        "closure": V32 / "contracts/AUTHORITATIVE_ARTIFACT_CREATION_CLOSURE.json",
        "binding": V32 / "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json",
        "unified": V32 / "contracts/UNIFIED_AUTHORITATIVE_BINDING_GENERATION.json",
        "symbols": V32 / "contracts/LOCKED_ENTRYPOINT_SYMBOL_BINDING_MANIFEST.json",
        "source": V32 / "src/invocation_v32.py",
    }


def expected_digests_from_source() -> dict[str, str]:
    tree = ast.parse(paths()["source"].read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "EXPECTED_DIGESTS" for t in node.targets):
            value = ast.literal_eval(node.value)
            if not isinstance(value, dict):
                break
            return value
    raise ValueError("EXPECTED_DIGESTS not statically resolvable")


def current_binding_rows() -> dict[str, dict[str, Any]]:
    generation = load(paths()["unified"])
    by_identity = {row["logical_artifact_identity"]: row for row in generation["members"]}
    return {key: by_identity[meta["logical_identity"]] for key, meta in ARTIFACTS.items()}


def comparison_rows() -> list[dict[str, Any]]:
    expected = expected_digests_from_source()
    current = current_binding_rows()
    rows = []
    for key, meta in ARTIFACTS.items():
        current_path = V32 / meta["path"]
        historical_path = V31 / meta["historical_path"]
        binding = current[key]
        rows.append({
            "binding_key": key,
            "logical_artifact_identity": meta["logical_identity"],
            "historical_logical_artifact_identity": meta["historical_logical_identity"],
            "artifact_role": binding["artifact_role"],
            "owner_identity": binding["owner_identity"],
            "historical_owner_identity": "V31",
            "finalized_v32_sha256": sha256(current_path),
            "registry_bound_v32_sha256": binding["sha256"],
            "stale_expected_carry_forward_sha256": expected[key],
            "predecessor_source": str(historical_path),
            "predecessor_source_sha256": sha256(historical_path),
            "current_v32_generation_identity": binding["generation_identity"],
            "historical_generation_identity": HISTORICAL_GENERATION,
            "artifact_bytes_changed_legitimately": current_path.read_bytes() != historical_path.read_bytes(),
            "owner_changed": "YES_EXPECTED_SUCCESSOR_OWNER_REBIND_V31_TO_V32",
            "role_changed": False,
            "current_readiness_state": "FINALIZED_V32_CURRENT_REGISTRY_MEMBER",
            "historical_readiness_state": "ADMISSIBLE_HISTORY_NOT_CURRENT_AUTHORITY",
        })
    return rows


def verify_v32_frozen() -> dict[str, Any]:
    p = paths()
    terminal, manifest, unit = load(p["terminal"]), load(p["manifest"]), load(p["unit"])
    members = manifest.get("members", [])
    exact = []
    for row in members:
        member = V32 / row.get("path", "")
        exact.append(
            member.is_file() and not member.is_symlink()
            and sha256(member) == row.get("sha256")
            and member.stat().st_size == row.get("bytes")
            and stat.S_IMODE(member.stat().st_mode) == 0o444
        )
    root_rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    computed_root = hashlib.sha256(root_rows.encode()).hexdigest()
    failed = {row.get("id") for row in unit.get("checks", []) if row.get("status") != "PASS"}
    closure, binding, unified, symbols = (load(p[name]) for name in ("closure", "binding", "unified", "symbols"))
    checks = {
        "terminal_digest": sha256(p["terminal"]) == V32_TERMINAL_SHA,
        "manifest_digest": sha256(p["manifest"]) == V32_MANIFEST_SHA,
        "freeze_digest": sha256(p["freeze"]) == V32_FREEZE_SHA,
        "unit_digest": sha256(p["unit"]) == V32_UNIT_SHA,
        "root_exact": computed_root == manifest.get("canonical_evidence_root_sha256") == V32_ROOT_SHA,
        "members_exact": len(members) == manifest.get("member_count") == 317 and all(exact),
        "workspace_read_only": stat.S_IMODE(V32.stat().st_mode) == 0o555,
        "terminal_state": terminal.get("status") == V32_STATUS,
        "unit_counts": unit.get("validation_counts") == {"failed": 6, "passed": 368, "total": 374},
        "failure_set": failed == FAILURES,
        "later_gates_not_started": terminal.get("primary") == terminal.get("independent") == terminal.get("fresh_preflight") == "NOT_STARTED",
        "static_lock_absent": terminal.get("static_lock") == "NOT_ISSUED" and not (V32 / "STATIC_EXECUTION_LOCK.json").exists(),
        "attempt_absent": not (V32 / "static-run-v32/attempt-marker-0001.json").exists(),
        "runtime_absent": not (V32 / "static-run-v32/runtime-result-0001.json").exists(),
        "counts_zero": terminal.get("attempt_count") == terminal.get("worker_invocation_count") == terminal.get("codex_as_worker_invocation_count") == 0,
        "no_bytecode": not any(V32.rglob("*.pyc")) and not any(q.name == "__pycache__" for q in V32.rglob("*")),
        "closure_exact": sha256(p["closure"]) == CLOSURE_SHA and closure.get("member_count") == 171 and closure.get("symbol_manifest_present_before_closure") is True,
        "binding_exact": sha256(p["binding"]) == BINDING_SHA and binding.get("member_count") == 171 and binding.get("reread_and_rehash") == "PASS" and binding.get("member_set_unchanged_after_binding") is True,
        "unified_exact": sha256(p["unified"]) == UNIFIED_SHA and unified.get("generation_identity") == CURRENT_GENERATION,
        "symbol_manifest_exact": symbols.get("symbol_count") == 94 and symbols.get("status") == "PASS",
    }
    return {
        "record_type": "V32_FROZEN_FAILURE_EVIDENCE_VERDICT",
        "checks": checks,
        "member_count": len(members),
        "canonical_evidence_root_sha256": computed_root,
        "status": "PASS" if all(checks.values()) else "FAIL_CLOSED",
    }


def expected_view_verdict(candidate: Mapping[str, Any]) -> bool:
    """Pure model for a derived current-readiness expected-digest view."""
    return bool(
        candidate.get("artifact_exists")
        and candidate.get("actual_digest") == candidate.get("authoritative_registry_digest") == candidate.get("expected_view_digest")
        and candidate.get("logical_identity_exact")
        and candidate.get("owner_identity_exact")
        and candidate.get("owner_governance_digest_exact")
        and candidate.get("owning_contract_digest_exact")
        and candidate.get("selected_generation") == candidate.get("current_generation")
        and not candidate.get("historical_binding_selected_as_current")
        and not candidate.get("mixed_generation")
        and candidate.get("view_derivation") == "DERIVED_FROM_FINALIZED_AUTHORITATIVE_ARTIFACT_REGISTRY"
        and candidate.get("reread_rehash_exact")
    )
