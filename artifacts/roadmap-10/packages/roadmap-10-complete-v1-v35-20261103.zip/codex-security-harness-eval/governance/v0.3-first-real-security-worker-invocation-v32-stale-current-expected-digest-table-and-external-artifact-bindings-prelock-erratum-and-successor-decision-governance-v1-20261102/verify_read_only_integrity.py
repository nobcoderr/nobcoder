#!/usr/bin/env python3
"""Verify V32 immutability and authority ceiling before governance freeze."""

from governance_common import ROOT, V32, V33, load, verify_v32_frozen, write_once


def main() -> int:
    required = ["PRIMARY_GOVERNANCE_VALIDATION.json", "NEGATIVE_GOVERNANCE_FIXTURES.json", "INDEPENDENT_GOVERNANCE_VALIDATION.json"]
    checks = {
        "R001_V32_BYTE_EXACT": verify_v32_frozen()["status"] == "PASS",
        "R002_VALIDATIONS_PASS": all(load(ROOT / name)["status"] == "PASS" for name in required),
        "R003_STATIC_LOCK_ABSENT": not (V32 / "STATIC_EXECUTION_LOCK.json").exists(),
        "R004_ATTEMPT_ABSENT": not (V32 / "static-run-v32/attempt-marker-0001.json").exists(),
        "R005_RUNTIME_ABSENT": not (V32 / "static-run-v32/runtime-result-0001.json").exists(),
        "R006_V33_ABSENT": not V33.exists(),
        "R007_BIND_SOURCE_PRESERVED": (V32 / "static-run-v32").is_dir(),
        "R008_NO_BYTECODE": not any(V32.rglob("*.pyc")) and not any(path.name == "__pycache__" for path in V32.rglob("*")),
    }
    result = {"record_type": "READ_ONLY_INTEGRITY_VERIFICATION", "checks": [{"id": k, "status": "PASS" if v else "FAIL"} for k, v in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "READ_ONLY_INTEGRITY_VERIFICATION.json", result)
    print(f"READ_ONLY_INTEGRITY={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
