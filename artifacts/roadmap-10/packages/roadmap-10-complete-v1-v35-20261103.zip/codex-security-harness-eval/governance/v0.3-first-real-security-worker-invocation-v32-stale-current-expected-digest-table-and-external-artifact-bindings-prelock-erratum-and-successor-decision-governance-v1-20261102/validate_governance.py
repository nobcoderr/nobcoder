#!/usr/bin/env python3
"""Primary governance validation for the V32 adjudication."""

from governance_common import CURRENT_GENERATION, ROOT, V33, load, verify_v32_frozen, write_once


def main() -> int:
    comparison = load(ROOT / "V32_EXPECTED_DIGEST_STALENESS_EVIDENCE_COMPARISON.json")
    adjudication = load(ROOT / "V32_STALE_CURRENT_EXPECTED_DIGEST_TABLE_ADJUDICATION.json")
    finalization = load(ROOT / "V32_FINALIZATION_LIFECYCLE_PRESERVATION_ADJUDICATION.json")
    contract = load(ROOT / "SUCCESSOR_V33_DERIVED_CURRENT_EXPECTED_DIGEST_VIEW_CONTRACT.json")
    matrix = load(ROOT / "V32_FAILURE_AND_V33_REGRESSION_MATRIX.json")
    decision = load(ROOT / "V32_TERMINAL_AND_V33_SUCCESSOR_DECISION.json")
    rows = comparison["artifacts"]
    checks = {
        "G001_V32_FROZEN": verify_v32_frozen()["status"] == "PASS",
        "G002_SIX_ROWS": comparison["affected_artifact_count"] == len(rows) == 6,
        "G003_CURRENT_REGISTRY_EXACT": all(r["finalized_v32_sha256"] == r["registry_bound_v32_sha256"] for r in rows),
        "G004_EXPECTED_EQUALS_PREDECESSOR": all(r["stale_expected_carry_forward_sha256"] == r["predecessor_source_sha256"] for r in rows),
        "G005_CURRENT_DIFFERS_STALE": all(r["finalized_v32_sha256"] != r["stale_expected_carry_forward_sha256"] for r in rows),
        "G006_LEGITIMATE_SUCCESSOR_BYTES": all(r["artifact_bytes_changed_legitimately"] is True for r in rows),
        "G007_GENERATIONS_EXACT": all(r["current_v32_generation_identity"] == CURRENT_GENERATION and r["historical_generation_identity"].startswith("V31_") for r in rows),
        "G008_HISTORICAL_NOT_CURRENT": all(r["historical_readiness_state"] == "ADMISSIBLE_HISTORY_NOT_CURRENT_AUTHORITY" for r in rows),
        "G009_TABLE_STALENESS": adjudication["CURRENT_READINESS_EXPECTED_DIGEST_TABLE_STALENESS"] == "YES",
        "G010_EXTERNAL_BINDING_DEFECT": adjudication["CARRIED_FORWARD_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT"] == "YES",
        "G011_FINALIZED_IDENTITY_NO_DEFECT": adjudication["FINALIZED_V32_ARTIFACT_IDENTITY_DEFECT"] == "NO",
        "G012_FINALIZATION_PRESERVED": finalization["AUTHORITATIVE_ARTIFACT_FINALIZATION_LIFECYCLE_DEFECT"] == "NO" and finalization["finalized_member_count"] == 171,
        "G013_DERIVED_VIEW": contract["current_digest_source_of_truth"] == "FINALIZED_AUTHORITATIVE_ARTIFACT_REGISTRY",
        "G014_MANUAL_TABLE_PROHIBITED": contract["independent_manual_expected_digest_table"] == "PROHIBITED_FOR_CURRENT_READINESS",
        "G015_HISTORICAL_ONLY": contract["historical_digest_policy"].startswith("PRESERVE_AS_HISTORICAL_ONLY"),
        "G016_ORDER_COMPLETE": len(contract["required_order"]) == 9 and contract["required_order"][-1] == "BEGIN_UNIT_AND_STATIC_VALIDATION",
        "G017_REGRESSIONS": matrix["count"] == len(set(matrix["required_regressions"])) == 8,
        "G018_V32_TERMINAL": decision["v32_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY",
        "G019_V33_CONDITIONAL": decision["v33_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "G020_RUNTIME_NOT_ESTABLISHED": decision["securityworker_runtime"] == decision["codex_worker_runtime"] == decision["temporal_runtime"] == "NOT_ESTABLISHED",
        "G021_V33_ABSENT": not V33.exists(),
    }
    result = {"record_type": "PRIMARY_GOVERNANCE_VALIDATION", "checks": [{"id": k, "status": "PASS" if v else "FAIL"} for k, v in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "PRIMARY_GOVERNANCE_VALIDATION.json", result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
