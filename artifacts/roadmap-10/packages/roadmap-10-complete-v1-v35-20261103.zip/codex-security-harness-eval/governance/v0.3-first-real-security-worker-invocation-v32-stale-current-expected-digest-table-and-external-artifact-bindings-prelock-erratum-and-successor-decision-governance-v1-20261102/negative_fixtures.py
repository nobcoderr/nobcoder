#!/usr/bin/env python3
"""Pure, filesystem-neutral fixtures for derived expected-digest selection."""

from copy import deepcopy

from governance_common import ROOT, expected_view_verdict, write_once


def main() -> int:
    digest = "a" * 64
    exact = {
        "artifact_exists": True,
        "actual_digest": digest,
        "authoritative_registry_digest": digest,
        "expected_view_digest": digest,
        "logical_identity_exact": True,
        "owner_identity_exact": True,
        "owner_governance_digest_exact": True,
        "owning_contract_digest_exact": True,
        "selected_generation": "V33_CURRENT_GENERATION_0001",
        "current_generation": "V33_CURRENT_GENERATION_0001",
        "historical_binding_selected_as_current": False,
        "mixed_generation": False,
        "view_derivation": "DERIVED_FROM_FINALIZED_AUTHORITATIVE_ARTIFACT_REGISTRY",
        "reread_rehash_exact": True,
    }

    def changed(**values):
        candidate = deepcopy(exact)
        candidate.update(values)
        return candidate

    fixtures = [
        ("N001_EXACT_DERIVED_CURRENT_VIEW", expected_view_verdict(exact)),
        ("N002_STALE_PREDECESSOR_EXPECTED_DIGEST", not expected_view_verdict(changed(expected_view_digest="b" * 64))),
        ("N003_HISTORICAL_DIGEST_SELECTED_CURRENT", not expected_view_verdict(changed(historical_binding_selected_as_current=True))),
        ("N004_CORRECT_DIGEST_STALE_OWNER", not expected_view_verdict(changed(owner_identity_exact=False))),
        ("N005_PREDECESSOR_GENERATION_SELECTED", not expected_view_verdict(changed(selected_generation="V32_PREDECESSOR_GENERATION"))),
        ("N006_MIXED_HISTORICAL_CURRENT_VIEW", not expected_view_verdict(changed(mixed_generation=True))),
        ("N007_MANUAL_HARDCODE_INCONSISTENT", not expected_view_verdict(changed(view_derivation="MANUAL_HARDCODED_TABLE"))),
        ("N008_CORRECT_OWNER_WRONG_GOVERNANCE", not expected_view_verdict(changed(owner_governance_digest_exact=False))),
        ("N009_EXACT_CURRENT_ARTIFACT_DIGEST", expected_view_verdict(exact)),
        ("N010_STALE_OWNING_CONTRACT", not expected_view_verdict(changed(owning_contract_digest_exact=False))),
    ]
    result = {"record_type": "NEGATIVE_GOVERNANCE_FIXTURES", "fixtures": [{"id": i, "status": "PASS" if ok else "FAIL"} for i, ok in fixtures], "passed": sum(ok for _, ok in fixtures), "total": len(fixtures), "filesystem_mutations": 0, "status": "PASS" if all(ok for _, ok in fixtures) else "FAIL_CLOSED"}
    write_once(ROOT / "NEGATIVE_GOVERNANCE_FIXTURES.json", result)
    print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
