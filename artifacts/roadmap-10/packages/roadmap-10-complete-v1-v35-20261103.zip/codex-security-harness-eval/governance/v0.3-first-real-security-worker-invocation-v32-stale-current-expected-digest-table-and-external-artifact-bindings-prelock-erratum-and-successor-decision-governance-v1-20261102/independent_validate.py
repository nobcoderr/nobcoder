#!/usr/bin/env python3
"""Independent reconstruction of the V32 stale-digest failure."""

import ast
import hashlib
import json
import stat
from pathlib import Path

from governance_common import ROOT, V32, V33, write_once


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def source_expected(path: Path) -> dict[str, str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "EXPECTED_DIGESTS" for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError("missing EXPECTED_DIGESTS")


def main() -> int:
    pre = V32 / "results/prelock"
    terminal_path = pre / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json"
    manifest_path = pre / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json"
    freeze_path = pre / "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json"
    unit_path = pre / "unit-fixtures-run-0001.json"
    terminal, manifest, unit = map(read, (terminal_path, manifest_path, unit_path))
    rows_text = "".join(f"{r['sha256']}  {r['path']}\n" for r in manifest["members"])
    root_sha = hashlib.sha256(rows_text.encode()).hexdigest()
    members_exact = all(
        (V32 / row["path"]).is_file() and not (V32 / row["path"]).is_symlink()
        and digest(V32 / row["path"]) == row["sha256"]
        and (V32 / row["path"]).stat().st_size == row["bytes"]
        and stat.S_IMODE((V32 / row["path"]).stat().st_mode) == 0o444
        for row in manifest["members"]
    )
    failed = {row["id"] for row in unit["checks"] if row["status"] != "PASS"}
    paths = {
        "successor_v32_requirements": "contracts/SUCCESSOR_V32_REQUIREMENTS.json",
        "typed_historical_decision_registry": "contracts/TYPED_HISTORICAL_DECISION_REGISTRY.json",
        "typed_historical_decision_registry_contract": "contracts/TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT.json",
        "unified_binding_generation_contract": "contracts/UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json",
        "v32_symbol_resolution_regression_matrix": "contracts/V32_STANDARD_LIBRARY_SYMBOL_RESOLUTION_REGRESSION_MATRIX.json",
        "v32_typed_module_identity_contract": "contracts/TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json",
    }
    historical = {
        "successor_v32_requirements": "/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102/contracts/SUCCESSOR_V31_REQUIREMENTS.json",
        "typed_historical_decision_registry": "/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102/contracts/TYPED_HISTORICAL_DECISION_REGISTRY.json",
        "typed_historical_decision_registry_contract": "/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102/contracts/TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT.json",
        "unified_binding_generation_contract": "/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102/contracts/UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json",
        "v32_symbol_resolution_regression_matrix": "/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102/contracts/V31_STANDARD_LIBRARY_SYMBOL_RESOLUTION_REGRESSION_MATRIX.json",
        "v32_typed_module_identity_contract": "/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102/contracts/TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json",
    }
    expected = source_expected(V32 / "src/invocation_v32.py")
    current = {key: digest(V32 / rel) for key, rel in paths.items()}
    prior = {key: digest(Path(path)) for key, path in historical.items()}
    generation = read(V32 / "contracts/UNIFIED_AUTHORITATIVE_BINDING_GENERATION.json")
    current_registry = {r["logical_artifact_identity"]: r for r in generation["members"]}
    current_identities = {
        "successor_v32_requirements": "SUCCESSOR_V32_REQUIREMENTS",
        "typed_historical_decision_registry": "V32_TYPED_HISTORICAL_DECISION_REGISTRY",
        "typed_historical_decision_registry_contract": "V32_TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT",
        "unified_binding_generation_contract": "V32_UNIFIED_BINDING_GENERATION_CONTRACT",
        "v32_symbol_resolution_regression_matrix": "V32_SYMBOL_RESOLUTION_REGRESSION_MATRIX",
        "v32_typed_module_identity_contract": "V32_TYPED_CANONICAL_MODULE_IDENTITY_CONTRACT",
    }
    adjudication = read(ROOT / "V32_STALE_CURRENT_EXPECTED_DIGEST_TABLE_ADJUDICATION.json")
    decision = read(ROOT / "V32_TERMINAL_AND_V33_SUCCESSOR_DECISION.json")
    checks = {
        "I001_TERMINAL_SHA": digest(terminal_path) == "ef3e0b4adfc003fae338e5a5de67144f1cb1cfb0c051b531cc49afb4ebe7322c",
        "I002_MANIFEST_SHA": digest(manifest_path) == "46e1dd5743aaa4260b6cf0c77c8ab7f24880a8292f25ad9ef60c8b51eb8a24e2",
        "I003_FREEZE_SHA": digest(freeze_path) == "9996517d88e886284c926fc1f2b8436477737246c7d514f4aafcc4167475898b",
        "I004_ROOT": root_sha == manifest["canonical_evidence_root_sha256"] == "6cd2d2f2f3134683d73426fcac0f2e19ec0da670f7621bafe488bfada9a631c5",
        "I005_MEMBERS": len(manifest["members"]) == 317 and members_exact,
        "I006_COUNTS": unit["validation_counts"] == {"failed": 6, "passed": 368, "total": 374},
        "I007_FAILURES": failed == {"U063_EXTERNAL_successor_v32_requirements", "U065_EXTERNAL_typed_historical_decision_registry", "U066_EXTERNAL_typed_historical_decision_registry_contract", "U067_EXTERNAL_unified_binding_generation_contract", "U104_EXTERNAL_v32_symbol_resolution_regression_matrix", "U105_EXTERNAL_v32_typed_module_identity_contract"},
        "I008_ALL_EXPECTED_ARE_V31": all(expected[k] == prior[k] for k in paths),
        "I009_ALL_CURRENT_DIFFER": all(current[k] != expected[k] for k in paths),
        "I010_ALL_CURRENT_REGISTRY_EXACT": all(current_registry[current_identities[k]]["sha256"] == current[k] for k in paths),
        "I011_CURRENT_GENERATION": generation["generation_identity"] == "V32_CURRENT_GOVERNANCE_BOUND_TYPED_PREFLIGHT_BINDING_GENERATION_0001",
        "I012_CLOSURE": digest(V32 / "contracts/AUTHORITATIVE_ARTIFACT_CREATION_CLOSURE.json") == "bda0e42fdeda1facb47b5eed49d05f22b831661e227ce415bb824422c5ee4d48",
        "I013_BINDING": digest(V32 / "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json") == "fe220f7224927dc5cb2146e46fdd8c5312519511aafa54cbb16b2070b1eb782d",
        "I014_UNIFIED": digest(V32 / "contracts/UNIFIED_AUTHORITATIVE_BINDING_GENERATION.json") == "b0105d8f570b51cab970497b6157cb2c6fc5bb86333e657f4ad149c49923e784",
        "I015_ADJUDICATION": adjudication["CURRENT_READINESS_EXPECTED_DIGEST_TABLE_STALENESS"] == adjudication["CARRIED_FORWARD_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT"] == "YES" and adjudication["FINALIZED_V32_ARTIFACT_IDENTITY_DEFECT"] == "NO",
        "I016_PRIMARY_PASS": read(ROOT / "PRIMARY_GOVERNANCE_VALIDATION.json")["status"] == "PASS",
        "I017_NEGATIVES_PASS": read(ROOT / "NEGATIVE_GOVERNANCE_FIXTURES.json")["status"] == "PASS",
        "I018_V32_TERMINAL": decision["v32_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY",
        "I019_V33_CONDITIONAL": decision["v33_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "I020_NO_EXECUTION": terminal["static_lock"] == "NOT_ISSUED" and not (V32 / "STATIC_EXECUTION_LOCK.json").exists() and not (V32 / "static-run-v32/attempt-marker-0001.json").exists(),
        "I021_V33_ABSENT": not V33.exists(),
    }
    result = {"record_type": "INDEPENDENT_GOVERNANCE_VALIDATION", "checks": [{"id": k, "status": "PASS" if v else "FAIL"} for k, v in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION.json", result)
    print(f"INDEPENDENT_GOVERNANCE_VALIDATION={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
