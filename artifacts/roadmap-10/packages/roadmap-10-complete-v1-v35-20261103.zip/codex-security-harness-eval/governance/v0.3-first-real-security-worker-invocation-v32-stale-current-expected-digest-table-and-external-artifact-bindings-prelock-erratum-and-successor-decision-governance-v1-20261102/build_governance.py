#!/usr/bin/env python3
"""Build the governance-only V32 digest-staleness adjudication."""

from governance_common import (
    ARTIFACTS, BINDING_SHA, CLOSURE_SHA, CURRENT_GENERATION, FAILURES,
    HISTORICAL_GENERATION, IDENTITY, ROOT, UNIFIED_SHA, V32, V32_IDENTITY,
    V33, V33_IDENTITY, comparison_rows, verify_v32_frozen, write_once,
)


def emit(name: str, value: dict) -> None:
    write_once(ROOT / name, value)


def main() -> int:
    frozen = verify_v32_frozen()
    if frozen["status"] != "PASS":
        raise SystemExit("V32 frozen evidence verification failed")
    if V33.exists():
        raise SystemExit("governance-only milestone forbids V33 creation")
    rows = comparison_rows()
    if len(rows) != 6 or not all(
        row["finalized_v32_sha256"] == row["registry_bound_v32_sha256"]
        and row["stale_expected_carry_forward_sha256"] == row["predecessor_source_sha256"]
        and row["finalized_v32_sha256"] != row["stale_expected_carry_forward_sha256"]
        for row in rows
    ):
        raise SystemExit("six-row frozen comparison did not establish carried-forward staleness")

    lifecycle = {
        "record_type": "SUCCESSOR_V33_DERIVED_CURRENT_EXPECTED_DIGEST_VIEW_CONTRACT",
        "contract_identity": "V33_DERIVED_CURRENT_READINESS_EXPECTED_DIGEST_VIEW_CONTRACT_V1",
        "successor_identity": V33_IDENTITY,
        "authorizing_governance_identity": IDENTITY,
        "authorizing_governance_lock": "EXACT_SHA256_OF_THIS_PACKAGE_GOVERNANCE_LOCK_JSON",
        "required_order": [
            "FINALIZE_ALL_AUTHORITATIVE_ARTIFACT_BYTES",
            "CLOSE_AUTHORITATIVE_MEMBER_SET",
            "VERIFY_REQUIRED_IMMUTABLE_MODES_AND_OWNERSHIP",
            "DERIVE_CURRENT_DIGESTS_FROM_CLOSED_AUTHORITATIVE_REGISTRY",
            "BIND_LOGICAL_ARTIFACT_IDENTITIES_AND_OWNERS",
            "BIND_EXACT_CURRENT_SUCCESSOR_GENERATION",
            "DERIVE_EXPECTED_DIGEST_CURRENT_READINESS_VIEW",
            "REREAD_REHASH_AND_VERIFY_EXACT_VIEW_EQUIVALENCE",
            "BEGIN_UNIT_AND_STATIC_VALIDATION",
        ],
        "current_digest_source_of_truth": "FINALIZED_AUTHORITATIVE_ARTIFACT_REGISTRY",
        "independent_manual_expected_digest_table": "PROHIBITED_FOR_CURRENT_READINESS",
        "historical_digest_policy": "PRESERVE_AS_HISTORICAL_ONLY_NEVER_SELECT_AS_CURRENT_READINESS",
        "mixed_generation_policy": "FAIL_CLOSED",
        "simple_digest_substitution_without_identity_owner_role_authority_and_generation_proof": "PROHIBITED",
        "status": "NORMATIVE_FOR_CONDITIONALLY_AUTHORIZED_SUCCESSOR_ONLY",
    }
    regressions = [
        "CURRENT_SUCCESSOR_ARTIFACT_WITH_STALE_PREDECESSOR_EXPECTED_DIGEST_FAILS_CLOSED",
        "CURRENT_ARTIFACT_WITH_EXACT_CURRENT_DIGEST_PASSES",
        "HISTORICAL_DIGEST_SELECTED_AS_CURRENT_FAILS_CLOSED",
        "CORRECT_ARTIFACT_DIGEST_WITH_STALE_OWNER_OR_GENERATION_FAILS_CLOSED",
        "PREDECESSOR_GENERATION_SELECTED_FOR_CURRENT_ARTIFACT_FAILS_CLOSED",
        "MIXED_HISTORICAL_AND_CURRENT_EXPECTED_DIGEST_VIEW_FAILS_CLOSED",
        "MANUALLY_HARDCODED_EXPECTED_DIGEST_INCONSISTENT_WITH_REGISTRY_FAILS_CLOSED",
        "EXACT_DERIVED_CURRENT_EXPECTED_DIGEST_VIEW_PASSES",
    ]

    emit("GOVERNANCE_CHARTER.json", {
        "record_type": "GOVERNANCE_CHARTER", "governance_identity": IDENTITY,
        "scope": "GOVERNANCE_ONLY",
        "prohibited": ["PATCH_V32", "RERUN_V32", "REGENERATE_V32_DIGEST_TABLES", "RUN_PRIMARY_OR_INDEPENDENT_V32", "RUN_FRESH_PREFLIGHT_V32", "ISSUE_STATIC_LOCK", "INVOKE_SECURITY_WORKER", "INVOKE_CODEX", "CREATE_OR_EXECUTE_V33"],
        "status": "ACTIVE",
    })
    emit("ROUTING_LEDGER.json", {
        "record_type": "ROUTING_LEDGER",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness"],
        "deferred": [],
        "not_applicable": ["target-recon", "prior-art-web-search", "exploit-execution", "paid-tools", "subagents", "parallelism"],
        "reason": "LOCAL_GOVERNANCE_ONLY_FROZEN_EVIDENCE_ADJUDICATION", "status": "PASS",
    })
    emit("V32_FROZEN_FAILURE_EVIDENCE_BINDING.json", {
        "record_type": "V32_FROZEN_FAILURE_EVIDENCE_BINDING", "execution_identity": V32_IDENTITY,
        "terminal_sha256": "ef3e0b4adfc003fae338e5a5de67144f1cb1cfb0c051b531cc49afb4ebe7322c",
        "failure_manifest_sha256": "46e1dd5743aaa4260b6cf0c77c8ab7f24880a8292f25ad9ef60c8b51eb8a24e2",
        "freeze_verification_sha256": "9996517d88e886284c926fc1f2b8436477737246c7d514f4aafcc4167475898b",
        "canonical_evidence_root_sha256": "6cd2d2f2f3134683d73426fcac0f2e19ec0da670f7621bafe488bfada9a631c5",
        "verification": frozen, "status": "PASS",
    })
    emit("V32_FAILURE_FACTS.json", {
        "record_type": "V32_FAILURE_FACTS", "unit": "368/374 PASS", "failed_gates": sorted(FAILURES),
        "primary": "NOT_STARTED", "independent": "NOT_STARTED", "preflight": "NOT_STARTED",
        "static_lock": "NOT_ISSUED", "attempt": "0/1", "worker": "0/1", "codex": "0/1",
        "attempt_marker": "ABSENT", "runtime_evidence": "ABSENT", "status": "PASS",
    })
    emit("V32_EXPECTED_DIGEST_STALENESS_EVIDENCE_COMPARISON.json", {
        "record_type": "V32_EXPECTED_DIGEST_STALENESS_EVIDENCE_COMPARISON",
        "current_generation_identity": CURRENT_GENERATION,
        "historical_generation_identity": HISTORICAL_GENERATION,
        "affected_artifact_count": len(rows), "artifacts": rows,
        "comparison_result": "ALL_SIX_CURRENT_REGISTRY_DIGESTS_EXACT_ALL_SIX_SOURCE_EXPECTATIONS_EQUAL_HISTORICAL_V31_DIGESTS",
        "status": "PASS",
    })
    emit("V32_STALE_CURRENT_EXPECTED_DIGEST_TABLE_ADJUDICATION.json", {
        "record_type": "V32_STALE_CURRENT_EXPECTED_DIGEST_TABLE_ADJUDICATION",
        "CURRENT_READINESS_EXPECTED_DIGEST_TABLE_STALENESS": "YES",
        "CARRIED_FORWARD_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT": "YES",
        "FINALIZED_V32_ARTIFACT_IDENTITY_DEFECT": "NO",
        "cause": "CURRENT_READINESS_EXPECTED_DIGESTS_RETAINED_PREDECESSOR_V31_VALUES_WHILE_FINALIZED_V32_REGISTRY_BOUND_LEGITIMATE_SUCCESSOR_BYTES",
        "simple_digest_substitution_authorized": False,
        "current_source_of_truth": "FINALIZED_V32_AUTHORITATIVE_ARTIFACT_REGISTRY",
        "status": "PASS",
    })
    emit("V32_FINALIZATION_LIFECYCLE_PRESERVATION_ADJUDICATION.json", {
        "record_type": "V32_FINALIZATION_LIFECYCLE_PRESERVATION_ADJUDICATION",
        "finalized_member_count": 171, "required_immutable_mode": "0444",
        "symbol_binding_manifest_symbol_count": 94, "symbol_manifest_before_creation_closure": True,
        "creation_closure_sha256": CLOSURE_SHA, "artifact_binding_sha256": BINDING_SHA,
        "unified_generation_sha256": UNIFIED_SHA,
        "AUTHORITATIVE_ARTIFACT_FINALIZATION_LIFECYCLE_DEFECT": "NO",
        "preservation": "SUCCESSFUL_V32_FINALIZATION_FACTS_REMAIN_HISTORICAL_STATIC_EVIDENCE_ONLY",
        "status": "PASS",
    })
    emit("SUCCESSOR_V33_DERIVED_CURRENT_EXPECTED_DIGEST_VIEW_CONTRACT.json", lifecycle)
    emit("V32_FAILURE_AND_V33_REGRESSION_MATRIX.json", {
        "record_type": "V32_FAILURE_AND_V33_REGRESSION_MATRIX", "required_regressions": regressions,
        "count": len(regressions),
        "carry_forward": "ALL_APPLICABLE_V1_THROUGH_V32_CONTROLS_NOT_IMPLICATED_BY_FROZEN_EVIDENCE",
        "preserved_controls": ["EXACT_CODEX_0_166_0_RUNTIME_AUTHORITY", "BIND_SOURCE_LIFECYCLE", "MOUNT_OUTPUT_IDENTITY", "TYPED_PREFLIGHT_PREDICATES", "TYPED_HISTORICAL_REGISTRY", "PREDECESSOR_TRANSITIVE_RESOLUTION", "MODULE_SYMBOL_SEMANTICS", "PYTHON_CACHE_POLICY", "WORKSPACE_BOUNDARY", "TRANSACTIONAL_TELEMETRY", "ALL_FIVE_TEMPORAL_FIXTURES", "STRICT_N_OF_N_COVERAGE"],
        "status": "PASS",
    })
    emit("V32_TERMINAL_AND_V33_SUCCESSOR_DECISION.json", {
        "record_type": "V32_TERMINAL_AND_V33_SUCCESSOR_DECISION",
        "decision": "TERMINALIZE_V32_AND_AUTHORIZE_DISTINCT_V33_CONDITIONALLY",
        "v32_disposition": "TERMINAL_IMMUTABLE_NO_RETRY",
        "v33_disposition": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt": "0/1", "worker_invocation": "0/1", "codex_as_worker_invocation": "0/1",
        "securityworker_runtime": "NOT_ESTABLISHED", "codex_worker_runtime": "NOT_ESTABLISHED",
        "temporal_runtime": "NOT_ESTABLISHED", "process_lineage": "NOT_PROVEN",
        "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN", "status": "PASS",
    })
    emit("V32_IMMUTABILITY_AND_AUTHORITY_CEILING.json", {
        "record_type": "V32_IMMUTABILITY_AND_AUTHORITY_CEILING", "v32": "READ_ONLY_FROZEN",
        "v33_created": False, "target": 0, "credential": 0, "target_network": 0,
        "subagent": 0, "parallelism": 0, "promotion": 0, "submission": 0,
        "worker": 0, "codex": 0, "status": "PASS",
    })
    emit("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "NEXT_LEGAL_MILESTONE",
        "milestone": "IMPLEMENT_FRESH_V33_ONLY_UNDER_SEPARATE_ENGINEERING_REQUEST",
        "v33_created": False, "v33_executed": False, "status": "PASS",
    })
    print("GOVERNANCE_BUILD=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
