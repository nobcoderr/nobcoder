#!/usr/bin/env python3
"""Freeze the validated governance-only package append-only."""

import hashlib
import os

from governance_common import IDENTITY, ROOT, V32, V33, load, sha256, verify_v32_frozen, write_once


def main() -> int:
    validations = ["PRIMARY_GOVERNANCE_VALIDATION.json", "NEGATIVE_GOVERNANCE_FIXTURES.json", "INDEPENDENT_GOVERNANCE_VALIDATION.json", "READ_ONLY_INTEGRITY_VERIFICATION.json"]
    if verify_v32_frozen()["status"] != "PASS" or not all(load(ROOT / name)["status"] == "PASS" for name in validations):
        raise SystemExit("governance readiness failed")
    if V33.exists() or (V32 / "STATIC_EXECUTION_LOCK.json").exists() or (V32 / "static-run-v32/attempt-marker-0001.json").exists():
        raise SystemExit("authority ceiling violated")
    reserved = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION.json"}
    members = [{"path": p.name, "sha256": sha256(p), "bytes": p.stat().st_size} for p in sorted((p for p in ROOT.iterdir() if p.is_file() and p.name not in reserved), key=lambda p: p.name.encode())]
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    root_sha = hashlib.sha256(rows.encode()).hexdigest()
    write_once(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", {"record_type": "GOVERNANCE_ARTIFACT_MANIFEST", "governance_identity": IDENTITY, "members": members, "member_count": len(members), "canonical_governance_root_sha256": root_sha, "status": "PASS"})
    lock = {
        "record_type": "V32_STALE_CURRENT_EXPECTED_DIGEST_TABLE_AND_EXTERNAL_ARTIFACT_BINDINGS_ERRATUM_AND_V33_SUCCESSOR_DECISION_GOVERNANCE_LOCK",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "canonical_governance_root_sha256": root_sha,
        "governance_artifact_manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "CURRENT_READINESS_EXPECTED_DIGEST_TABLE_STALENESS": "YES",
        "CARRIED_FORWARD_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT": "YES",
        "FINALIZED_V32_ARTIFACT_IDENTITY_DEFECT": "NO",
        "AUTHORITATIVE_ARTIFACT_FINALIZATION_LIFECYCLE_DEFECT": "NO",
        "v32_disposition": "TERMINAL_IMMUTABLE_NO_RETRY",
        "v33_disposition": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt": "0/1", "worker_invocation": "0/1", "codex_as_worker_invocation": "0/1",
        "securityworker_runtime": "NOT_ESTABLISHED", "temporal_runtime": "NOT_ESTABLISHED",
        "process_lineage": "NOT_PROVEN", "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN",
        "next_legal_milestone": "IMPLEMENT_FRESH_V33_ONLY_UNDER_SEPARATE_ENGINEERING_REQUEST",
    }
    write_once(ROOT / "GOVERNANCE_LOCK.json", lock)
    write_once(ROOT / "FINAL_FREEZE_VERIFICATION.json", {"record_type": "FINAL_FREEZE_VERIFICATION", "manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"), "governance_lock_sha256": sha256(ROOT / "GOVERNANCE_LOCK.json"), "member_count": len(members), "canonical_governance_root_sha256": root_sha, "v32_reverified": True, "v33_absent": True, "status": "PASS"})
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(f"GOVERNANCE_FREEZE=PASS ROOT={root_sha} LOCK_SHA256={sha256(ROOT / 'GOVERNANCE_LOCK.json')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
