#!/usr/bin/env python3
"""Read-only final verifier for the frozen governance package."""

import hashlib
import stat

from governance_common import ROOT, V32, V33, load, sha256, verify_v32_frozen


def main() -> int:
    manifest = load(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load(ROOT / "GOVERNANCE_LOCK.json")
    final = load(ROOT / "FINAL_FREEZE_VERIFICATION.json")
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in manifest["members"])
    root_sha = hashlib.sha256(rows.encode()).hexdigest()
    exact = all((ROOT / row["path"]).is_file() and not (ROOT / row["path"]).is_symlink() and sha256(ROOT / row["path"]) == row["sha256"] and (ROOT / row["path"]).stat().st_size == row["bytes"] and stat.S_IMODE((ROOT / row["path"]).stat().st_mode) == 0o444 for row in manifest["members"])
    checks = {
        "F001_ROOT": root_sha == manifest["canonical_governance_root_sha256"] == lock["canonical_governance_root_sha256"] == final["canonical_governance_root_sha256"],
        "F002_MANIFEST": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock["governance_artifact_manifest_sha256"] == final["manifest_sha256"],
        "F003_LOCK": sha256(ROOT / "GOVERNANCE_LOCK.json") == final["governance_lock_sha256"],
        "F004_MEMBERS": exact and len(manifest["members"]) == manifest["member_count"] == final["member_count"],
        "F005_READ_ONLY": stat.S_IMODE(ROOT.stat().st_mode) == 0o555 and all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()),
        "F006_DEFECTS": lock["CURRENT_READINESS_EXPECTED_DIGEST_TABLE_STALENESS"] == lock["CARRIED_FORWARD_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT"] == "YES",
        "F007_FINALIZED_IDENTITY": lock["FINALIZED_V32_ARTIFACT_IDENTITY_DEFECT"] == lock["AUTHORITATIVE_ARTIFACT_FINALIZATION_LIFECYCLE_DEFECT"] == "NO",
        "F008_DECISION": lock["v32_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY" and lock["v33_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "F009_V32_FROZEN": verify_v32_frozen()["status"] == "PASS",
        "F010_NO_V32_EXECUTION": not (V32 / "STATIC_EXECUTION_LOCK.json").exists() and not (V32 / "static-run-v32/attempt-marker-0001.json").exists() and not (V32 / "static-run-v32/runtime-result-0001.json").exists(),
        "F011_V33_ABSENT": not V33.exists(),
        "F012_FINAL": final["status"] == "PASS",
    }
    passed = sum(checks.values())
    status = "PASS" if all(checks.values()) else "FAIL_CLOSED"
    print(f"FINAL_FREEZE_VERIFICATION={passed}/{len(checks)} {status}")
    print(f"GOVERNANCE_ROOT_SHA256={root_sha}")
    print(f"GOVERNANCE_LOCK_SHA256={sha256(ROOT / 'GOVERNANCE_LOCK.json')}")
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
