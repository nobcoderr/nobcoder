#!/usr/bin/env python3
"""Final read-only verifier for the frozen governance package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import stat
from typing import Any


ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016")
V2 = Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016")
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V1_LAUNCHER_PROCESS_LIMIT_INCOMPATIBILITY_AND_INCOMPLETE_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
FILES = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_AND_EVIDENCE_BINDING.json",
    "RUNTIME_VALIDATION_V1_TERMINAL_DISPOSITION.json", "PROCESS_LIMIT_EVIDENCE_CLASSIFICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "PARTIAL_EVIDENCE_ADMISSIBILITY.json",
    "PROVENANCE_GAP_AND_CLAIM_CEILING.json", "RUNTIME_VALIDATION_V2_SUCCESSOR_AUTHORIZATION_DECISION.json",
    "RUNTIME_VALIDATION_V2_IDENTITY_AND_PATH_BINDING.json", "RESOURCE_LIMIT_FEASIBILITY_PRECHECK_CONTRACT.json",
    "V2_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json", "V2_SINGLE_USE_EXECUTION_CONTRACT.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_TEST_RESULT.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "INDEPENDENT_VALIDATION_RESULT.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0002.json", "FREEZE_VERIFICATION_RESULT.json",
    "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json",
}
OPERATION_KEYS = frozenset({"candidate_promotions", "capability_edges", "codex_cli_invocations", "containment_fixture_attempts", "exploit_replays", "external_network_operations", "parallel_operations", "real_worker_processes", "runtime_validation_attempts", "subagent_processes", "submission_operations", "target_operations"})


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{item['sha256']}  {item['path']}\n" for item in sorted(rows, key=lambda item: str(item["path"]))).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def zero_typed(document: dict[str, Any]) -> bool:
    counters = document.get("operation_counters")
    return isinstance(counters, dict) and frozenset(counters) == OPERATION_KEYS and all(type(value) is int and value == 0 for value in counters.values())


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    check("F001_EXACT_FILE_SET", actual == FILES, {"extra": sorted(actual-FILES), "missing": sorted(FILES-actual)})
    check("F002_NO_SUBDIRECTORIES", not any(path.is_dir() for path in ROOT.iterdir()))
    check("F003_ROOT_READ_ONLY", ro(ROOT))
    check("F004_FILES_REGULAR_READ_ONLY", all(path.is_file() and not path.is_symlink() and ro(path) for path in ROOT.iterdir()))
    manifest = load("GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load("GOVERNANCE_LOCK.json")
    members = manifest.get("members", [])
    check("F005_IDENTITY", manifest.get("governance_identity") == lock.get("governance_identity") == IDENTITY)
    check("F006_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F007_MANIFEST_MEMBER_COUNT", manifest.get("member_count") == len(members) == 25)
    check("F008_ROOT_MEMBER_COUNT", lock.get("root_member_count") == 26)
    listed = {str(item.get("path", "")) for item in members}
    check("F009_MANIFEST_COVERAGE", listed == FILES - {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"})
    check("F010_LOCK_EXCLUDED", "GOVERNANCE_LOCK.json" not in listed)
    check("F011_MANIFEST_EXCLUDED", "GOVERNANCE_ARTIFACT_MANIFEST.json" not in listed)
    member_ok = True
    for item in members:
        path = ROOT / str(item.get("path", ""))
        member_ok = member_ok and path.is_file() and not path.is_symlink() and ro(path) and path.stat().st_size == item.get("bytes") and sha(path) == item.get("sha256")
    check("F012_MEMBER_BYTES", member_ok)
    member_root = rows_root(members)
    check("F013_MEMBER_ROOT", member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256"))
    manifest_hash = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    check("F014_MANIFEST_SHA", manifest_hash == lock.get("governance_manifest_sha256"))
    artifact_root = rows_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_hash, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    check("F015_ARTIFACT_ROOT", artifact_root == lock.get("canonical_artifact_root_sha256"))
    check("F016_STRUCTURAL_COUNTS", lock.get("structural_counts") == {"manifest_members": 25, "root_members": 26})

    disposition = load("RUNTIME_VALIDATION_V1_TERMINAL_DISPOSITION.json")
    process = load("PROCESS_LIMIT_EVIDENCE_CLASSIFICATION.json")
    ownership = load("DEFECT_OWNERSHIP_DECISION.json")
    partial = load("PARTIAL_EVIDENCE_ADMISSIBILITY.json")
    gap = load("PROVENANCE_GAP_AND_CLAIM_CEILING.json")
    successor = load("RUNTIME_VALIDATION_V2_SUCCESSOR_AUTHORIZATION_DECISION.json")
    binding = load("RUNTIME_VALIDATION_V2_IDENTITY_AND_PATH_BINDING.json")
    feasibility = load("RESOURCE_LIMIT_FEASIBILITY_PRECHECK_CONTRACT.json")
    gates = load("V2_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json")
    single = load("V2_SINGLE_USE_EXECUTION_CONTRACT.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
    next_gate = load("NEXT_LEGAL_MILESTONE.json")
    primary = load("GOVERNANCE_TEST_RESULT.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    historical_independent = load("INDEPENDENT_VALIDATION_RESULT.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT_RUN-0002.json")
    freeze = load("FREEZE_VERIFICATION_RESULT.json")

    check("F017_V1_TERMINAL", disposition.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY")
    check("F018_V1_ATTEMPT", disposition.get("attempt_count") == disposition.get("maximum_attempts") == 1)
    check("F019_V1_PROHIBITIONS", disposition.get("retry_authorized") is False and disposition.get("patch_in_place_authorized") is False and disposition.get("relock_same_identity_authorized") is False)
    check("F020_ROOT_CAUSE_CLASS", process.get("root_cause_classification") == "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED")
    check("F021_LIMIT_32", process.get("confirmed_facts", {}).get("locked_rlimit_nproc") == 32)
    check("F022_POST_FAILURE_81", process.get("post_failure_observation", {}).get("uid_process_population") == 81)
    check("F023_OBSERVATION_SCOPE", process.get("post_failure_observation", {}).get("time_relation") == "AFTER_TERMINAL_FAILURE" and process.get("post_failure_observation", {}).get("cannot_prove_prelaunch_population") is True)
    check("F024_TRACE_STDERR_ABSENT", process.get("confirmed_facts", {}).get("stderr_bytes") == process.get("confirmed_facts", {}).get("trace_file_count") == 0)
    check("F025_NO_SYSCALL_OVERCLAIM", "EXACT_FAILED_SYSCALL" in process.get("unsupported_claims", []) and "EXACT_ERRNO" in process.get("unsupported_claims", []))
    check("F026_CONFIDENCE_CEILING", gap.get("claim_ceiling") == "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED")
    check("F027_OWNERSHIP", ownership.get("decision") == "LAUNCHER_RESOURCE_LIMIT_CONTRACT_OWNS_FEASIBILITY_AND_DIAGNOSTIC_COMPLETENESS")
    check("F028_FEASIBILITY_GAP", ownership.get("defect_components", {}).get("missing_execution_context_feasibility_precheck") == "CONFIRMED_CONTRACT_GAP")
    check("F029_DIRECT_CAUSE_LIMITED", ownership.get("defect_components", {}).get("rlimit_nproc_as_direct_cause") == "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED")
    check("F030_CONFINEMENT_NOT_PROVEN", partial.get("confinement") == lock.get("confinement") == "NOT_PROVEN")
    check("F031_SUCCESSOR_DECISION", successor.get("decision") == lock.get("decision") == "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V2_CONDITIONALLY")
    check("F032_V2_STATE", successor.get("status") == lock.get("v2_state") == "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F033_V2_PATH", binding.get("workspace") == lock.get("v2_workspace") == str(V2) and not V2.exists() and not V2.is_symlink())
    check("F034_V2_FRESH", all(binding.get(key) is True for key in ("fresh_source_required", "fresh_tests_required", "fresh_static_lock_required", "fresh_one_shot_contract_required")))
    check("F035_PRECHECK_REQUIRED", successor.get("resource_limit_feasibility_precheck") == lock.get("resource_limit_feasibility_precheck") == "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION")
    check("F036_PRECHECK_ORDER", feasibility.get("ordering", [])[-2:] == ["ONLY_THEN_WRITE_ATTEMPT_MARKER", "ONLY_THEN_LAUNCH_CHILD"])
    check("F037_PRECHECK_FAIL_NO_CONSUME", feasibility.get("precheck_failure") == "STOP_BEFORE_ATTEMPT_MARKER_ATTEMPT_REMAINS_ZERO")
    check("F038_STALE_FAIL", feasibility.get("missing_or_stale_measurement") == "FAIL_CLOSED_BEFORE_ATTEMPT")
    check("F039_STATIC_INSUFFICIENT", feasibility.get("static_or_syntactic_limit_validation_alone") == "INSUFFICIENT")
    check("F040_REGRESSIONS", len(gates.get("regressions", [])) == 6)
    check("F041_SINGLE_USE", single.get("maximum_attempts") == 1 and single.get("automatic_retry") is False)
    check("F042_ATTEMPT_ZERO", successor.get("attempt_count") == lock.get("v2_attempt_count") == 0)
    check("F043_SUCCESS_CEILING", single.get("success_ceiling") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION")
    check("F044_GOVERNANCE_ONLY", authority.get("governance_only") is True and lock.get("runtime_or_fixture_execution_authorized_in_this_milestone") is False)
    check("F045_DEFAULT_DENY", matrix.get("default") == "DENY")
    check("F046_V1_PROHIBITED", matrix.get("operations", {}).get("PATCH_RELOCK_OR_RETRY_V1") == "PROHIBITED")
    check("F047_NO_V2_THIS_MILESTONE", matrix.get("operations", {}).get("CREATE_OR_EXECUTE_V2_DURING_THIS_GOVERNANCE") == "NOT_AUTHORIZED")
    check("F048_CAPABILITIES_DEFERRED", all(matrix.get("operations", {}).get(key) == "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION" for key in ("CODEX_DAYBREAK_WORKER_SUBAGENT", "KERNEL_SANDBOX_PWNESCAPE_REPLAY", "TARGET_NETWORK_PARALLEL_CAPABILITY_FULL_CHAIN_SUBMISSION")))
    check("F049_NEXT_MILESTONE", next_gate.get("milestone") == lock.get("next_milestone"))
    check("F050_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_total") == primary.get("checks_passed") == 50 and primary.get("checks_failed") == 0)
    check("F051_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 32 and negative.get("tests_failed") == 0)
    check("F052_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_total") == independent.get("checks_passed") == 60 and independent.get("checks_failed") == 0)
    check("F053_FREEZE_CANDIDATE", freeze.get("status") == "PASS_CANDIDATE_PRE_FINAL_FREEZE" and all(freeze.get("checks", {}).values()))
    check("F054_ZERO_LOCK_COUNTERS", zero_typed(lock))
    check("F055_ZERO_PRIMARY_COUNTERS", zero_typed(primary))
    check("F056_ZERO_NEGATIVE_COUNTERS", zero_typed(negative))
    check("F057_ZERO_INDEPENDENT_COUNTERS", zero_typed(independent))
    check("F058_ZERO_FREEZE_COUNTERS", zero_typed(freeze))
    check("F059_VALIDATION_COUNTS", all(value.get("total") == value.get("passed") and value.get("failed") == 0 for value in lock.get("validation_counts", {}).values()))
    check("F060_V1_STATIC_MANIFEST_UNCHANGED", sha(V1 / "locks/STATIC_SOURCE_MANIFEST.json") == "12f742dcb75d27b569be8f1c6765651dfe114792993f93ea1c92b4ac39eab9b6")
    check("F061_V1_STATIC_LOCK_UNCHANGED", sha(V1 / "locks/STATIC_EXECUTION_LOCK.json") == "56e279a86749d756aa33d4a9c68c5c4d4609feb8d1ee1d2c449873c507d28d8e")
    check("F062_V1_TERMINAL_UNCHANGED", sha(V1 / "evidence-v1/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == "1943e30b28c726d79ba566b6a1d76bbe5d44e6fbd557671cfb7d56cbe7040fc5")
    check("F063_V1_EVIDENCE_MANIFEST_UNCHANGED", sha(V1 / "evidence-v1/EVIDENCE_MANIFEST.json") == "1d8c6d2da3f3271d8d9225e1d1bee64fca20b22d21a577d06e8f445c5668a17e")
    check("F064_V1_EVIDENCE_LOCK_UNCHANGED", sha(V1 / "evidence-v1/EVIDENCE_FREEZE_LOCK.json") == "794b016bb866f52f5ac0afc4da4b8ff738ac0f2ff31ad8ea46fa6c41203697e0")
    check("F065_V1_READ_ONLY", all(ro(path) for path in V1.rglob("*") if path.is_file()))
    check("F066_LOCK_AUTHORITY_CEILING", all(lock.get(key) is False for key in ("runtime_or_fixture_execution_authorized_in_this_milestone", "worker_model_subagent_authorized", "target_network_authorized", "exploit_replay_authorized", "parallel_capability_full_chain_authorized")))
    check("F067_HISTORICAL_INDEPENDENT_PRESERVED", historical_independent.get("status") == "FAIL_CLOSED" and historical_independent.get("checks_total") == 60 and historical_independent.get("checks_passed") == 59 and historical_independent.get("checks_failed") == 1)
    check("F068_HISTORICAL_FAILURE_EXACT", [item.get("check_id") for item in historical_independent.get("failed", [])] == ["I003_ZERO_OPERATIONS"] and lock.get("historical_prefreeze_validation", {}).get("disposition") == "PRESERVED_PRE_FREEZE_VERIFIER_SCHEMA_FIELD_MISMATCH_SUPERSEDED_BY_APPEND_ONLY_RUN_0002")

    failed = [item for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_FINAL_FREEZE_VERIFICATION",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed),
        "failed": failed,
        "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"),
        "governance_manifest_sha256": manifest_hash,
        "canonical_artifact_root_sha256": artifact_root,
        "operation_counters": lock.get("operation_counters"),
    }
    print(json.dumps(result, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
