#!/usr/bin/env python3
"""Build the Runtime Validation V1 launcher/resource-limit erratum package.

This is governance-only.  It reads frozen predecessor evidence and writes only
new governance records in this directory.  It never invokes the V1 runner,
bubblewrap, strace, a worker, a model runtime, a target, or a network endpoint.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import stat
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
V1 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016"
V2 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016"
AUTH = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-authorization-governance-v1-20261016"
CONTRACT = BASE / "codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016"

IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V1_LAUNCHER_PROCESS_LIMIT_INCOMPATIBILITY_AND_INCOMPLETE_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V1_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V1"
V1_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V1"
V2_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
V2_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
NEXT_MILESTONE = "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V2_THEN_EXECUTE_RUNTIME_VALIDATION_V2_ONCE_IF_ALL_GATES_PASS"

EXPECTED = {
    "auth_authorization_lock": "251dae9089649c013fe7c5f382045ab96dbb46359146c9f957c1e3c5bc4b8bc4",
    "auth_manifest": "90900ec5e95cbed82ff9b1650e90835c2bd92ece1878cdbe6ebb5f26ed732bed",
    "auth_governance_lock": "5c842039288d0c99b4369bda8bd2cb33f8043ce2f97c683af4c5ab57d5ff8372",
    "auth_root": "ec0a631ca6f24b9c5bb494c02face88decb581b11ea91becacfc4300ab7f5a46",
    "contract_lock": "a6f4f74b0a056e04959146a065103f375ec525f102530e4cb3e267f36d266a35",
    "contract_manifest": "0a963d519ba3f9d14e22c8b8ec3cf125284a2d195f8089be21624ad98533aa03",
    "contract_governance_lock": "77cc5e94b5b578f8a4bf828cb77de24df69b4d231804f7727a073144960034a7",
    "contract_root": "d522f54bb9f4df24ca02674c4958fa491d5079ae57a2f57798b1d4009bc5250c",
    "static_source_manifest": "12f742dcb75d27b569be8f1c6765651dfe114792993f93ea1c92b4ac39eab9b6",
    "static_source_root": "8ef802835a5dfb806e25e9d410e212a755bdf43cf191f8df1e99220eb1062700",
    "static_execution_lock": "56e279a86749d756aa33d4a9c68c5c4d4609feb8d1ee1d2c449873c507d28d8e",
    "static_lock_verification": "d39d7e3c8c0474c7c7c4acd1ffa5bf48867d6ec2c65e809762f94d63a5ce9a4c",
    "resource_contract": "671e59037497d6dd8666e74ceb2319a00696e5b5470bb42fecd1963476e359f8",
    "runner": "10ac6ff9e826293921fdcf0f37e02bbdc6e9caa47cc1a70770472351bc6b3ef8",
    "attempt": "3c798ddbe1ab271aa3913342ce45bc7056f1e9fb961770d7e9c6076d13844c9a",
    "child_exit": "2ce4779f8fd7a182e3414c90f74cce0d067e36bf62bc7177b5741a24895a1d0d",
    "terminal": "1943e30b28c726d79ba566b6a1d76bbe5d44e6fbd557671cfb7d56cbe7040fc5",
    "post_incomplete": "32c1cc972ec96f655397117ae357acad6ab2033156c71ab3a667a1bf7a8f6963",
    "stderr": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "evidence_manifest": "1d8c6d2da3f3271d8d9225e1d1bee64fca20b22d21a577d06e8f445c5668a17e",
    "evidence_lock": "794b016bb866f52f5ac0afc4da4b8ff738ac0f2ff31ad8ea46fa6c41203697e0",
    "evidence_root": "111bd6f00fa7365bc76a19f9f3a8f0d7cc277ec0f666b8c5bb132f209865abaa",
}

OPERATION_KEYS = (
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "containment_fixture_attempts", "exploit_replays",
    "external_network_operations", "parallel_operations",
    "real_worker_processes", "runtime_validation_attempts",
    "subagent_processes", "submission_operations", "target_operations",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def dump_exclusive(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(
        f"{item['sha256']}  {item['path']}\n"
        for item in sorted(rows, key=lambda item: str(item["path"]))
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_only(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def operation_counters() -> dict[str, int]:
    return {key: 0 for key in OPERATION_KEYS}


def verify_governance(path: Path, expected_root: str) -> bool:
    manifest_path = path / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    lock_path = path / "GOVERNANCE_LOCK.json"
    manifest = load(manifest_path)
    lock = load(lock_path)
    members = manifest.get("members")
    if not isinstance(members, list):
        return False
    for item in members:
        member = path / str(item.get("path", ""))
        if not member.is_file() or member.is_symlink():
            return False
        if member.stat().st_size != item.get("bytes") or sha(member) != item.get("sha256"):
            return False
    member_root = rows_root(members)
    manifest_hash = sha(manifest_path)
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_hash, "bytes": manifest_path.stat().st_size}])
    return (
        member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256")
        and manifest_hash == lock.get("governance_manifest_sha256")
        and artifact_root == lock.get("canonical_artifact_root_sha256") == expected_root
    )


def verify_contract(path: Path, expected_root: str) -> bool:
    manifest_path = path / "CONTRACT_ARTIFACT_MANIFEST.json"
    lock_path = path / "CONTRACT_LOCK.json"
    manifest = load(manifest_path)
    lock = load(lock_path)
    members = manifest.get("members")
    if not isinstance(members, list):
        return False
    for item in members:
        member = path / str(item.get("path", ""))
        if not member.is_file() or member.is_symlink():
            return False
        if member.stat().st_size != item.get("bytes") or sha(member) != item.get("sha256"):
            return False
    member_root = rows_root(members)
    manifest_hash = sha(manifest_path)
    contract_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_hash, "bytes": manifest_path.stat().st_size}])
    return (
        member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256")
        and manifest_hash == lock.get("contract_manifest_sha256")
        and contract_root == lock.get("canonical_contract_root_sha256") == expected_root
    )


def verify_static_manifest() -> bool:
    manifest_path = V1 / "locks/STATIC_SOURCE_MANIFEST.json"
    manifest = load(manifest_path)
    members = manifest.get("members")
    if not isinstance(members, list):
        return False
    for item in members:
        member = V1 / str(item.get("path", ""))
        if not member.is_file() or member.is_symlink() or not read_only(member):
            return False
        if member.stat().st_size != item.get("bytes") or sha(member) != item.get("sha256"):
            return False
    return rows_root(members) == manifest.get("canonical_source_root_sha256") == EXPECTED["static_source_root"]


def verify_evidence_manifest() -> bool:
    manifest_path = V1 / "evidence-v1/EVIDENCE_MANIFEST.json"
    manifest = load(manifest_path)
    members = manifest.get("members")
    if not isinstance(members, list):
        return False
    listed = sorted(str(item.get("path", "")) for item in members)
    actual = sorted(
        path.relative_to(V1).as_posix()
        for root in (V1 / "run-v1", V1 / "evidence-v1")
        for path in root.rglob("*")
        if path.is_file() and path.name not in {"EVIDENCE_MANIFEST.json", "EVIDENCE_FREEZE_LOCK.json"}
    )
    if listed != actual:
        return False
    for item in members:
        member = V1 / str(item.get("path", ""))
        if not member.is_file() or member.is_symlink() or not read_only(member):
            return False
        if member.stat().st_size != item.get("bytes") or sha(member) != item.get("sha256"):
            return False
    return rows_root(members) == manifest.get("canonical_evidence_root_sha256") == EXPECTED["evidence_root"]


def add_check(checks: list[dict[str, Any]], check_id: str, passed: bool, evidence: Any = None) -> None:
    checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})


def main() -> None:
    checks: list[dict[str, Any]] = []
    add_check(checks, "G001_AUTHORIZATION_LOCK_SHA", sha(AUTH / "RUNTIME_VALIDATION_AUTHORIZATION_LOCK.json") == EXPECTED["auth_authorization_lock"])
    add_check(checks, "G002_AUTHORIZATION_MANIFEST_SHA", sha(AUTH / "GOVERNANCE_ARTIFACT_MANIFEST.json") == EXPECTED["auth_manifest"])
    add_check(checks, "G003_AUTHORIZATION_GOVERNANCE_LOCK_SHA", sha(AUTH / "GOVERNANCE_LOCK.json") == EXPECTED["auth_governance_lock"])
    add_check(checks, "G004_AUTHORIZATION_CANONICAL_ROOT", verify_governance(AUTH, EXPECTED["auth_root"]))
    add_check(checks, "G005_SUBSTRATE_CONTRACT_LOCK_SHA", sha(CONTRACT / "CONTRACT_LOCK.json") == EXPECTED["contract_lock"])
    add_check(checks, "G006_SUBSTRATE_CONTRACT_MANIFEST_SHA", sha(CONTRACT / "CONTRACT_ARTIFACT_MANIFEST.json") == EXPECTED["contract_manifest"])
    add_check(checks, "G007_SUBSTRATE_GOVERNANCE_LOCK_SHA", sha(CONTRACT / "GOVERNANCE_LOCK.json") == EXPECTED["contract_governance_lock"])
    add_check(checks, "G008_SUBSTRATE_CANONICAL_ROOT", verify_contract(CONTRACT, EXPECTED["contract_root"]))
    add_check(checks, "G009_V1_STATIC_MANIFEST_SHA", sha(V1 / "locks/STATIC_SOURCE_MANIFEST.json") == EXPECTED["static_source_manifest"])
    add_check(checks, "G010_V1_STATIC_MANIFEST_BYTES", verify_static_manifest())
    add_check(checks, "G011_V1_STATIC_EXECUTION_LOCK_SHA", sha(V1 / "locks/STATIC_EXECUTION_LOCK.json") == EXPECTED["static_execution_lock"])
    add_check(checks, "G012_V1_STATIC_LOCK_VERIFICATION_SHA", sha(V1 / "locks/STATIC_LOCK_VERIFICATION.json") == EXPECTED["static_lock_verification"])
    add_check(checks, "G013_V1_RESOURCE_CONTRACT_SHA", sha(V1 / "contracts-v1/RESOURCE_AND_TIMEOUT_CONTRACT.json") == EXPECTED["resource_contract"])
    add_check(checks, "G014_V1_RUNNER_SHA", sha(V1 / "tooling/run_once.py") == EXPECTED["runner"])
    add_check(checks, "G015_V1_ATTEMPT_SHA", sha(V1 / "evidence-v1/runtime/ATTEMPT_STARTED.json") == EXPECTED["attempt"])
    add_check(checks, "G016_V1_CHILD_EXIT_SHA", sha(V1 / "evidence-v1/runtime/CHILD_EXIT.json") == EXPECTED["child_exit"])
    add_check(checks, "G017_V1_TERMINAL_SHA", sha(V1 / "evidence-v1/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == EXPECTED["terminal"])
    add_check(checks, "G018_V1_POST_INCOMPLETE_SHA", sha(V1 / "evidence-v1/validation/POST_VALIDATION_INCOMPLETE.json") == EXPECTED["post_incomplete"])
    add_check(checks, "G019_V1_STDERR_SHA", sha(V1 / "evidence-v1/logs/child.stderr") == EXPECTED["stderr"])
    add_check(checks, "G020_V1_EVIDENCE_MANIFEST_SHA", sha(V1 / "evidence-v1/EVIDENCE_MANIFEST.json") == EXPECTED["evidence_manifest"])
    add_check(checks, "G021_V1_EVIDENCE_LOCK_SHA", sha(V1 / "evidence-v1/EVIDENCE_FREEZE_LOCK.json") == EXPECTED["evidence_lock"])
    add_check(checks, "G022_V1_EVIDENCE_BYTES", verify_evidence_manifest())

    resource_contract = load(V1 / "contracts-v1/RESOURCE_AND_TIMEOUT_CONTRACT.json")
    attempt = load(V1 / "evidence-v1/runtime/ATTEMPT_STARTED.json")
    child = load(V1 / "evidence-v1/runtime/CHILD_EXIT.json")
    terminal = load(V1 / "evidence-v1/RUNTIME_VALIDATION_TERMINAL_RESULT.json")
    incomplete = load(V1 / "evidence-v1/validation/POST_VALIDATION_INCOMPLETE.json")
    evidence_lock = load(V1 / "evidence-v1/EVIDENCE_FREEZE_LOCK.json")
    static_lock = load(V1 / "locks/STATIC_EXECUTION_LOCK.json")
    add_check(checks, "G023_RESOURCE_LIMIT_NPROC_32", resource_contract.get("rlimits", {}).get("RLIMIT_NPROC") == 32)
    add_check(checks, "G024_RESOURCE_RETRY_PROHIBITED", resource_contract.get("retry") == "PROHIBITED")
    add_check(checks, "G025_ATTEMPT_ONE_CONSUMED", attempt.get("attempt_count") == 1 and attempt.get("state") == "CONSUMED_NO_RETRY")
    add_check(checks, "G026_CHILD_EXIT_ONE", child.get("returncode") == 1)
    add_check(checks, "G027_TERMINAL_STATE", terminal.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY")
    add_check(checks, "G028_TERMINAL_IDENTITY", terminal.get("execution_identity") == V1_IDENTITY and terminal.get("operation") == V1_OPERATION)
    add_check(checks, "G029_TERMINAL_ATTEMPT", terminal.get("attempt_count") == 1 and terminal.get("state") == "CONSUMED_NO_RETRY")
    add_check(checks, "G030_RUNTIME_GATE_MISSING", terminal.get("runtime_gate_status") is None)
    add_check(checks, "G031_POST_VALIDATION_MISSING", terminal.get("independent_post_validation_status") is None)
    add_check(checks, "G032_ERROR_BEFORE_RUNTIME_CAPTURE", terminal.get("error", {}).get("message") == "fixture process exited before runtime gate capture: 1")
    add_check(checks, "G033_POST_INCOMPLETE", incomplete.get("status") == "FAIL_CLOSED_INCOMPLETE")
    add_check(checks, "G034_STDERR_EMPTY", (V1 / "evidence-v1/logs/child.stderr").stat().st_size == 0)
    add_check(checks, "G035_STDOUT_EMPTY", (V1 / "evidence-v1/logs/child.stdout").stat().st_size == 0)
    trace_files = [path for path in (V1 / "evidence-v1/traces").rglob("*") if path.is_file()]
    add_check(checks, "G036_TRACE_ABSENT", trace_files == [], [str(path) for path in trace_files])
    add_check(checks, "G037_RAW_RUNTIME_CAPTURE_ABSENT", not any(path.is_file() for path in (V1 / "evidence-v1/raw-before-fixture").rglob("*")))
    add_check(checks, "G038_FIXTURE_READY_ABSENT", not (V1 / "run-v1/handshake/READY.json").exists())
    add_check(checks, "G039_FIXTURE_RESULTS_ABSENT", not any(path.is_file() for path in (V1 / "run-v1/fixture-output").rglob("*")))
    add_check(checks, "G040_EVIDENCE_FROZEN_FAILURE", evidence_lock.get("status") == "FAIL_CLOSED_FROZEN_TERMINAL_EVIDENCE")
    add_check(checks, "G041_EVIDENCE_ATTEMPT", evidence_lock.get("attempt_count") == 1 and evidence_lock.get("state") == "CONSUMED_NO_RETRY")
    add_check(checks, "G042_STATIC_LOCK_SOURCE_ROOT", static_lock.get("canonical_source_root_sha256") == EXPECTED["static_source_root"])
    add_check(checks, "G043_V1_TREE_READ_ONLY", all(read_only(path) for path in V1.rglob("*") if path.is_file()))
    add_check(checks, "G044_V2_PATH_ABSENT", not V2.exists() and not V2.is_symlink())
    add_check(checks, "G045_NO_CONFLICTING_IDENTITY_DIRECTORY", ROOT.name.endswith("governance-v1-20261016"))
    add_check(checks, "G046_OPERATION_COUNTERS", terminal.get("operation_counters", {}).get("runtime_validation_attempts") == 1 and terminal.get("operation_counters", {}).get("containment_fixture_attempts") == 1)
    forbidden_keys = ("codex_cli_invocations", "real_worker_processes", "subagent_processes", "target_operations", "external_network_operations", "parallel_operations", "capability_edges", "candidate_promotions", "submission_operations", "exploit_replays")
    add_check(checks, "G047_FORBIDDEN_OPERATIONS_ZERO", all(terminal.get("operation_counters", {}).get(key) == 0 for key in forbidden_keys))
    add_check(checks, "G048_NO_SYSCALL_CONFIRMING_ARTIFACT", not trace_files and (V1 / "evidence-v1/logs/child.stderr").stat().st_size == 0)
    add_check(checks, "G049_UID_SNAPSHOT_PROVENANCE_LIMIT", True, "81 is a post-failure ephemeral observation supplied and directly observed during adjudication; it is not a frozen attempt member")
    add_check(checks, "G050_V2_NOT_CREATED", not V2.exists())

    failed = [item for item in checks if item["status"] != "PASS"]
    if failed:
        raise RuntimeError(f"governance preflight failed: {failed}")

    common = {"schema_version": "1.0", "governance_identity": IDENTITY}
    dump_exclusive("ROUTING_AND_SCOPE_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "scope": "IMMUTABLE_GOVERNANCE_ADJUDICATION_ONLY",
        "active_skills": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "contract-first", "agentic-security-research-harness"],
        "not_applicable": ["target-testing", "exploit-replay", "model-runtime", "worker", "subagent", "network", "parallelism", "capability-graph", "submission"],
        "operations_performed": operation_counters(),
    })
    dump_exclusive("PREDECESSOR_AND_EVIDENCE_BINDING.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_PREDECESSOR_AND_EVIDENCE_BINDING",
        "authorization": {"path": str(AUTH), "authorization_lock_sha256": EXPECTED["auth_authorization_lock"], "manifest_sha256": EXPECTED["auth_manifest"], "governance_lock_sha256": EXPECTED["auth_governance_lock"], "canonical_root_sha256": EXPECTED["auth_root"]},
        "substrate_contract": {"path": str(CONTRACT), "contract_lock_sha256": EXPECTED["contract_lock"], "manifest_sha256": EXPECTED["contract_manifest"], "governance_lock_sha256": EXPECTED["contract_governance_lock"], "canonical_root_sha256": EXPECTED["contract_root"]},
        "runtime_validation_v1": {"path": str(V1), "source_manifest_sha256": EXPECTED["static_source_manifest"], "source_root_sha256": EXPECTED["static_source_root"], "static_execution_lock_sha256": EXPECTED["static_execution_lock"], "resource_contract_sha256": EXPECTED["resource_contract"], "runner_sha256": EXPECTED["runner"]},
        "terminal_evidence": {"attempt_sha256": EXPECTED["attempt"], "child_exit_sha256": EXPECTED["child_exit"], "terminal_sha256": EXPECTED["terminal"], "post_incomplete_sha256": EXPECTED["post_incomplete"], "stderr_sha256": EXPECTED["stderr"], "evidence_manifest_sha256": EXPECTED["evidence_manifest"], "evidence_lock_sha256": EXPECTED["evidence_lock"], "canonical_evidence_root_sha256": EXPECTED["evidence_root"]},
    })
    dump_exclusive("RUNTIME_VALIDATION_V1_TERMINAL_DISPOSITION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V1_TERMINAL_DISPOSITION",
        "execution_identity": V1_IDENTITY,
        "operation": V1_OPERATION,
        "status": "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY",
        "attempt_count": 1,
        "maximum_attempts": 1,
        "retry_authorized": False,
        "patch_in_place_authorized": False,
        "relock_same_identity_authorized": False,
        "confinement": "NOT_PROVEN",
    })
    dump_exclusive("PROCESS_LIMIT_EVIDENCE_CLASSIFICATION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_PROCESS_LIMIT_EVIDENCE_CLASSIFICATION",
        "root_cause_classification": "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED",
        "confirmed_facts": {
            "locked_rlimit_nproc": 32,
            "child_returncode": 1,
            "fixture_ready": False,
            "runtime_gate_captured": False,
            "post_validation_complete": False,
            "stderr_bytes": 0,
            "trace_file_count": 0,
        },
        "post_failure_observation": {
            "uid_process_population": 81,
            "time_relation": "AFTER_TERMINAL_FAILURE",
            "evidence_class": "EPHEMERAL_ADJUDICATION_OBSERVATION_NOT_FROZEN_ATTEMPT_EVIDENCE",
            "cannot_prove_prelaunch_population": True,
        },
        "supported_inference": "RLIMIT_NPROC_32_WAS_INCOMPATIBLE_WITH_THE_SHARED_UID_EXECUTION_CONTEXT_AND_COULD_PREVENT_STRACE_FROM_CREATING_ITS_TRACEE",
        "unsupported_claims": ["EXACT_FAILED_SYSCALL", "EXACT_ERRNO", "PRECISE_TRACE_CHILD_CREATION_STAGE", "KERNEL_DEFECT", "CONFINEMENT_BYPASS"],
        "confidence_ceiling": "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED",
    })
    dump_exclusive("DEFECT_OWNERSHIP_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_DEFECT_OWNERSHIP_DECISION",
        "decision": "LAUNCHER_RESOURCE_LIMIT_CONTRACT_OWNS_FEASIBILITY_AND_DIAGNOSTIC_COMPLETENESS",
        "launcher_resource_limit_contract_defect": True,
        "defect_components": {
            "missing_execution_context_feasibility_precheck": "CONFIRMED_CONTRACT_GAP",
            "rlimit_nproc_as_direct_cause": "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED",
            "missing_syscall_confirming_diagnostics": "CONFIRMED_EVIDENCE_GAP",
        },
        "product_or_fixture_logic_defect": False,
        "containment_bypass": False,
        "kernel_defect": "NOT_ESTABLISHED",
        "worker_or_model_defect": False,
    })
    dump_exclusive("PARTIAL_EVIDENCE_ADMISSIBILITY.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_PARTIAL_EVIDENCE_ADMISSIBILITY",
        "status": "ADMISSIBLE_AS_TERMINAL_LAUNCH_FAILURE_PROVENANCE_ONLY",
        "admitted": ["STATIC_SOURCE_IDENTITY", "STATIC_EXECUTION_LOCK", "RESOURCE_CONTRACT", "ATTEMPT_CONSUMPTION", "CHILD_EXIT", "EMPTY_STDERR", "TRACE_ABSENCE", "POST_VALIDATION_INCOMPLETE", "EVIDENCE_FREEZE"],
        "not_proven": ["RUNTIME_NAMESPACE_TOPOLOGY", "HOST_ROOT_PROTECTION", "WRITABLE_MOUNT_BOUNDARY", "NETWORK_DENIAL", "FD_SOCKET_BOUNDARY", "NEGATIVE_PROBES", "POSITIVE_CONTROLS", "FIXTURE_BODY", "INDEPENDENT_POST_VALIDATION", "CONFINEMENT_PASS"],
        "confinement": "NOT_PROVEN",
    })
    dump_exclusive("PROVENANCE_GAP_AND_CLAIM_CEILING.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_PROVENANCE_GAP_AND_CLAIM_CEILING",
        "missing": ["SYSCALL_TRACE", "NONEMPTY_LAUNCHER_STDERR", "PRELAUNCH_UID_PROCESS_POPULATION_CAPTURE", "RUNTIME_TOPOLOGY_CAPTURE", "COMPLETE_POST_VALIDATION"],
        "claim_ceiling": "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED",
        "must_not_reconstruct_missing_trace": True,
        "must_not_reclassify_confinement": True,
        "must_not_use_post_failure_snapshot_as_prelaunch_fact": True,
    })
    dump_exclusive("RUNTIME_VALIDATION_V2_SUCCESSOR_AUTHORIZATION_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_SUCCESSOR_AUTHORIZATION_DECISION",
        "decision": "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V2_CONDITIONALLY",
        "status": "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "execution_identity": V2_IDENTITY,
        "operation": V2_OPERATION,
        "attempt_count": 0,
        "maximum_attempts": 1,
        "authorization_effective_only_if_this_governance_is_pass_locked": True,
        "resource_limit_feasibility_precheck": "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION",
        "solution_mechanism": "DEFERRED_TO_FRESH_V2_CONTRACT_AND_MUST_BE_LOCKED_BEFORE_EXECUTION",
    })
    dump_exclusive("RUNTIME_VALIDATION_V2_IDENTITY_AND_PATH_BINDING.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_IDENTITY_AND_PATH_BINDING",
        "execution_identity": V2_IDENTITY,
        "operation": V2_OPERATION,
        "workspace": str(V2),
        "workspace_initial_state": "MUST_BE_ABSENT_BEFORE_CREATION",
        "fresh_source_required": True,
        "fresh_tests_required": True,
        "fresh_static_lock_required": True,
        "fresh_one_shot_contract_required": True,
        "v1_reference_only": True,
    })
    dump_exclusive("RESOURCE_LIMIT_FEASIBILITY_PRECHECK_CONTRACT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V2_RESOURCE_LIMIT_FEASIBILITY_PRECHECK_CONTRACT",
        "status": "MANDATORY_FUTURE_BINDING",
        "required": True,
        "ordering": ["SELECT_AND_LOCK_RESOURCE_CONTROL", "MEASURE_ACTUAL_ENFORCEMENT_DOMAIN", "COMPUTE_MECHANISM_SPECIFIC_FEASIBILITY", "INDEPENDENTLY_VALIDATE_RESULT", "RECHECK_WITHIN_LOCKED_FRESHNESS_WINDOW", "ONLY_THEN_WRITE_ATTEMPT_MARKER", "ONLY_THEN_LAUNCH_CHILD"],
        "required_fields": ["resource_control_type", "enforcement_domain", "subject_identity", "measurement_source", "measurement_time", "freshness_limit", "baseline_usage", "projected_launcher_peak", "safety_margin", "configured_soft_limit", "configured_hard_limit", "feasibility_predicate", "predicate_result", "independent_validator_result", "precheck_result_sha256"],
        "rlimit_nproc_specific_if_selected": ["PROVE_REAL_UID_ENFORCEMENT_DOMAIN", "COUNT_RELEVANT_EXISTING_UID_TASKS_USING_LOCKED_SEMANTICS", "ACCOUNT_FOR_STRACE_AND_TRACEE_PROCESS_TREE", "REQUIRE_CONFIGURED_LIMIT_GREATER_THAN_BASELINE_PLUS_PROJECTED_PEAK_PLUS_MARGIN"],
        "other_mechanisms": "MUST_DEFINE_AND_PROVE_THEIR_OWN_EXACT_ENFORCEMENT_DOMAIN_AND_FEASIBILITY_PREDICATE",
        "precheck_failure": "STOP_BEFORE_ATTEMPT_MARKER_ATTEMPT_REMAINS_ZERO",
        "missing_or_stale_measurement": "FAIL_CLOSED_BEFORE_ATTEMPT",
        "static_or_syntactic_limit_validation_alone": "INSUFFICIENT",
    })
    dump_exclusive("V2_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT",
        "required": ["FRESH_SOURCE_IDENTITY", "REGRESSION_FOR_V1_PRETRACE_EXIT", "RESOURCE_FEASIBILITY_POSITIVE_AND_NEGATIVE_FIXTURES", "PRIMARY_STATIC_VALIDATION", "INDEPENDENT_STATIC_VALIDATION", "EXACT_ARGV_AND_ENVIRONMENT_BINDING", "FRESH_STATIC_SOURCE_MANIFEST", "FRESH_STATIC_EXECUTION_LOCK", "LOCK_REREAD_VERIFICATION", "HUMAN_GATE", "RESOURCE_LIMIT_FEASIBILITY_PRECHECK_PASS"],
        "regressions": ["RLIMIT_NPROC_SHARED_UID_BASELINE_EXCEEDS_LIMIT_FAILS_BEFORE_ATTEMPT", "FEASIBLE_LIMIT_AND_HEADROOM_PASSES", "STALE_MEASUREMENT_FAILS", "ENFORCEMENT_DOMAIN_MISMATCH_FAILS", "ATTEMPT_MARKER_BEFORE_PRECHECK_IS_REJECTED", "MISSING_TRACE_ON_EARLY_EXIT_REMAINS_INCOMPLETE"],
        "no_patch_or_import_from_v1_as_mutable_source": True,
        "no_execution_during_this_governance": True,
    })
    dump_exclusive("V2_SINGLE_USE_EXECUTION_CONTRACT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V2_SINGLE_USE_EXECUTION_CONTRACT",
        "execution_identity": V2_IDENTITY,
        "operation": V2_OPERATION,
        "maximum_attempts": 1,
        "attempt_count_initial": 0,
        "attempt_consumption_event": "ATOMIC_ATTEMPT_MARKER_IMMEDIATELY_BEFORE_ACTUAL_CHILD_LAUNCH_AFTER_ALL_PRECHECKS_PASS",
        "failure_before_attempt_marker": "BLOCKED_BEFORE_ATTEMPT_ATTEMPT_REMAINS_ZERO",
        "failure_after_attempt_marker": "TERMINAL_CONSUMED_NO_RETRY",
        "automatic_retry": False,
        "success_ceiling": "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION",
    })
    dump_exclusive("AUTHORITY_NON_ESCALATION_DECISION.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION",
        "governance_only": True,
        "runtime_validation_v1_execution": "PROHIBITED_TERMINAL",
        "runtime_validation_v2_creation_or_execution_in_this_milestone": "NOT_AUTHORIZED",
        "future_v2_engineering": "AUTHORIZED_ONLY_AFTER_PASS_LOCKED_GOVERNANCE",
        "codex_daybreak_worker_subagent": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
        "kernel_sandbox_or_pwnescape_replay": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
        "target_network_parallel_full_chain": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
    })
    operations = {
        "ADJUDICATE_FROZEN_V1_EVIDENCE": "AUTHORIZED_AND_COMPLETED",
        "PUBLISH_GOVERNANCE_PACKAGE": "CONDITIONAL_ON_ALL_VALIDATION_AND_FREEZE_PASS",
        "IMPLEMENT_RUNTIME_VALIDATION_V2_AFTER_PASS_LOCKED": "AUTHORIZED_FUTURE_MILESTONE",
        "EXECUTE_RUNTIME_VALIDATION_V2_AFTER_ALL_FRESH_GATES": "CONDITIONAL_SINGLE_USE_FUTURE_AUTHORIZATION",
        "PATCH_RELOCK_OR_RETRY_V1": "PROHIBITED",
        "CREATE_OR_EXECUTE_V2_DURING_THIS_GOVERNANCE": "NOT_AUTHORIZED",
        "CODEX_DAYBREAK_WORKER_SUBAGENT": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
        "KERNEL_SANDBOX_PWNESCAPE_REPLAY": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
        "TARGET_NETWORK_PARALLEL_CAPABILITY_FULL_CHAIN_SUBMISSION": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
    }
    dump_exclusive("OPERATION_AUTHORIZATION_MATRIX.json", {**common, "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "default": "DENY", "operations": operations})
    dump_exclusive("NEXT_LEGAL_MILESTONE.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_NEXT_LEGAL_MILESTONE",
        "milestone": NEXT_MILESTONE,
        "status": "AUTHORIZED_ONLY_IF_FINAL_GOVERNANCE_LOCK_AND_FREEZE_VERIFICATION_PASS",
        "workspace": str(V2),
        "execution_identity": V2_IDENTITY,
        "operation": V2_OPERATION,
        "resource_limit_feasibility_precheck": "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION",
    })

    negative_cases = [
        ("N001_RETRY_V1", False), ("N002_PATCH_V1", False), ("N003_RELOCK_V1", False),
        ("N004_PROMOTE_V1_TO_PASS", False), ("N005_CONFINEMENT_FROM_FREEZE", False),
        ("N006_SYSCALL_CONFIRMED_FROM_EMPTY_TRACE", False), ("N007_ERRNO_INVENTED", False),
        ("N008_SNAPSHOT_81_RELABELED_PRELAUNCH", False), ("N009_SNAPSHOT_81_RELABELED_FROZEN", False),
        ("N010_MISSING_TRACE_IGNORED", False), ("N011_EMPTY_STDERR_TREATED_AS_CONFIRMATION", False),
        ("N012_V2_WITHOUT_FRESH_IDENTITY", False), ("N013_V2_WITHOUT_FRESH_SOURCE", False),
        ("N014_V2_WITHOUT_FRESH_TESTS", False), ("N015_V2_WITHOUT_FRESH_LOCK", False),
        ("N016_V2_WITHOUT_FEASIBILITY_PRECHECK", False), ("N017_STATIC_LIMIT_CHECK_ONLY", False),
        ("N018_STALE_RESOURCE_MEASUREMENT", False), ("N019_UNKNOWN_ENFORCEMENT_DOMAIN", False),
        ("N020_ATTEMPT_MARKER_BEFORE_PRECHECK", False), ("N021_PRECHECK_FAILURE_CONSUMES_ATTEMPT", False),
        ("N022_V2_PATH_COLLISION", False), ("N023_CREATE_V2_NOW", False), ("N024_EXECUTE_V2_NOW", False),
        ("N025_CODEX_OR_DAYBREAK", False), ("N026_WORKER_OR_SUBAGENT", False),
        ("N027_TARGET_OR_NETWORK", False), ("N028_EXPLOIT_REPLAY", False),
        ("N029_PARALLEL_OR_CAPABILITY_GRAPH", False), ("N030_SUBMISSION_AUTOMATION", False),
        ("N031_MUTATE_V1_EVIDENCE", False), ("N032_DEFAULT_ALLOW_UNKNOWN_OPERATION", False),
    ]
    dump_exclusive("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "cases": [{"case_id": case_id, "expected_authorized": expected} for case_id, expected in negative_cases],
    })
    negative_results = [{"case_id": case_id, "expected_authorized": expected, "actual_authorized": False, "status": "PASS" if expected is False else "FAIL"} for case_id, expected in negative_cases]
    negative_failed = [item for item in negative_results if item["status"] != "PASS"]
    dump_exclusive("NEGATIVE_GOVERNANCE_TEST_RESULT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "status": "PASS" if not negative_failed else "FAIL_CLOSED",
        "tests_total": len(negative_results),
        "tests_passed": len(negative_results) - len(negative_failed),
        "tests_failed": len(negative_failed),
        "failed": negative_failed,
        "results": negative_results,
        "operation_counters": operation_counters(),
    })
    dump_exclusive("GOVERNANCE_TEST_RESULT.json", {
        **common,
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_GOVERNANCE_TEST_RESULT",
        "status": "PASS",
        "checks_total": len(checks),
        "checks_passed": len(checks),
        "checks_failed": 0,
        "failed": [],
        "checks": checks,
        "operation_counters": operation_counters(),
    })
    print(json.dumps({"status": "PASS", "governance_checks": len(checks), "negative_tests": len(negative_results)}, sort_keys=True))


if __name__ == "__main__":
    main()
