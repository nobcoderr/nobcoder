#!/usr/bin/env python3
"""Create the immutable manifest and lock after every validation passes."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V2 = Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016")
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V1_LAUNCHER_PROCESS_LIMIT_INCOMPATIBILITY_AND_INCOMPLETE_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V2_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
V2_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
NEXT_MILESTONE = "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V2_THEN_EXECUTE_RUNTIME_VALIDATION_V2_ONCE_IF_ALL_GATES_PASS"

PRE_FINAL_MEMBERS = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_AND_EVIDENCE_BINDING.json",
    "RUNTIME_VALIDATION_V1_TERMINAL_DISPOSITION.json", "PROCESS_LIMIT_EVIDENCE_CLASSIFICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "PARTIAL_EVIDENCE_ADMISSIBILITY.json",
    "PROVENANCE_GAP_AND_CLAIM_CEILING.json", "RUNTIME_VALIDATION_V2_SUCCESSOR_AUTHORIZATION_DECISION.json",
    "RUNTIME_VALIDATION_V2_IDENTITY_AND_PATH_BINDING.json", "RESOURCE_LIMIT_FEASIBILITY_PRECHECK_CONTRACT.json",
    "V2_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json", "V2_SINGLE_USE_EXECUTION_CONTRACT.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_TEST_RESULT.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "INDEPENDENT_VALIDATION_RESULT.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0002.json",
}
OPERATION_KEYS = ("candidate_promotions", "capability_edges", "codex_cli_invocations", "containment_fixture_attempts", "exploit_replays", "external_network_operations", "parallel_operations", "real_worker_processes", "runtime_validation_attempts", "subagent_processes", "submission_operations", "target_operations")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def dump_exclusive(path: Path, value: dict[str, Any]) -> str:
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return sha(path)


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{item['sha256']}  {item['path']}\n" for item in sorted(rows, key=lambda item: str(item["path"]))).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != PRE_FINAL_MEMBERS:
        raise RuntimeError(f"unexpected pre-final file set: extra={sorted(actual-PRE_FINAL_MEMBERS)} missing={sorted(PRE_FINAL_MEMBERS-actual)}")
    primary = load(ROOT / "GOVERNANCE_TEST_RESULT.json")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    historical_independent = load(ROOT / "INDEPENDENT_VALIDATION_RESULT.json")
    independent = load(ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0002.json")
    if historical_independent.get("status") != "FAIL_CLOSED" or historical_independent.get("checks_total") != 60 or historical_independent.get("checks_passed") != 59 or historical_independent.get("checks_failed") != 1:
        raise RuntimeError("historical independent schema mismatch failure is not preserved")
    if [item.get("check_id") for item in historical_independent.get("failed", [])] != ["I003_ZERO_OPERATIONS"]:
        raise RuntimeError("unexpected historical independent failure")
    if any(item.get("status") != "PASS" for item in (primary, negative, independent)):
        raise RuntimeError("all governance validation must PASS before freeze")
    if V2.exists() or V2.is_symlink():
        raise RuntimeError("V2 path collision before authorization freeze")

    freeze_candidate = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_FREEZE_VERIFICATION_CANDIDATE",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "status": "PASS_CANDIDATE_PRE_FINAL_FREEZE",
        "checks": {
            "exact_pre_final_file_set": True,
            "primary_validation_pass": True,
            "negative_validation_pass": True,
            "independent_validation_pass": True,
            "v2_path_absent": True,
            "v1_execution_not_invoked": True,
            "operation_counters_zero": True,
        },
        "operation_counters": {key: 0 for key in OPERATION_KEYS},
    }
    dump_exclusive(ROOT / "FREEZE_VERIFICATION_RESULT.json", freeze_candidate)
    members_set = PRE_FINAL_MEMBERS | {"FREEZE_VERIFICATION_RESULT.json"}
    members = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in sorted(members_set)]
    member_root = rows_root(members)
    manifest = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "member_count": len(members),
        "members": members,
        "canonical_member_root_sha256": member_root,
        "self_referential_hashes": False,
    }
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest_sha = dump_exclusive(manifest_path, manifest)
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}])
    lock = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V2_CONDITIONALLY",
        "v1_state": "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY",
        "v1_attempt_count": 1,
        "root_cause": "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED",
        "defect_ownership": "LAUNCHER_RESOURCE_LIMIT_CONTRACT_OWNS_FEASIBILITY_AND_DIAGNOSTIC_COMPLETENESS",
        "confinement": "NOT_PROVEN",
        "v2_state": "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v2_identity": V2_IDENTITY,
        "v2_operation": V2_OPERATION,
        "v2_workspace": str(V2),
        "v2_attempt_count": 0,
        "resource_limit_feasibility_precheck": "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION",
        "next_milestone": NEXT_MILESTONE,
        "governance_manifest_sha256": manifest_sha,
        "canonical_member_root_sha256": member_root,
        "canonical_artifact_root_sha256": artifact_root,
        "root_member_count": len(members) + 1,
        "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 1},
        "validation_counts": {
            "governance": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
            "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
            "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
        },
        "historical_prefreeze_validation": {
            "artifact": "INDEPENDENT_VALIDATION_RESULT.json",
            "status": "FAIL_CLOSED",
            "total": 60,
            "passed": 59,
            "failed": 1,
            "failed_check": "I003_ZERO_OPERATIONS",
            "disposition": "PRESERVED_PRE_FREEZE_VERIFIER_SCHEMA_FIELD_MISMATCH_SUPERSEDED_BY_APPEND_ONLY_RUN_0002",
        },
        "operation_counters": {key: 0 for key in OPERATION_KEYS},
        "runtime_or_fixture_execution_authorized_in_this_milestone": False,
        "worker_model_subagent_authorized": False,
        "target_network_authorized": False,
        "exploit_replay_authorized": False,
        "parallel_capability_full_chain_authorized": False,
    }
    lock_sha = dump_exclusive(ROOT / "GOVERNANCE_LOCK.json", lock)
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": lock["status"], "manifest_sha256": manifest_sha, "lock_sha256": lock_sha, "canonical_artifact_root": artifact_root, "manifest_members": len(members), "root_members": len(members) + 1}, sort_keys=True))


if __name__ == "__main__":
    main()
