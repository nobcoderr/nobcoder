#!/usr/bin/env python3
"""Independent evidence-only validation for the V1 process-limit erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import stat
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
V1 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016"
V2 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v2-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V1_LAUNCHER_PROCESS_LIMIT_INCOMPATIBILITY_AND_INCOMPLETE_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V2_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
V2_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V2"
OPERATION_KEYS = frozenset({"candidate_promotions", "capability_edges", "codex_cli_invocations", "containment_fixture_attempts", "exploit_replays", "external_network_operations", "parallel_operations", "real_worker_processes", "runtime_validation_attempts", "subagent_processes", "submission_operations", "target_operations"})


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def zero_typed(document: dict[str, Any]) -> bool:
    counters = document.get("operation_counters")
    return isinstance(counters, dict) and frozenset(counters) == OPERATION_KEYS and all(type(value) is int and value == 0 for value in counters.values())


def zero_typed_operations_performed(document: dict[str, Any]) -> bool:
    counters = document.get("operations_performed")
    return isinstance(counters, dict) and frozenset(counters) == OPERATION_KEYS and all(type(value) is int and value == 0 for value in counters.values())


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    route = load("ROUTING_AND_SCOPE_DECISION.json")
    binding = load("PREDECESSOR_AND_EVIDENCE_BINDING.json")
    disposition = load("RUNTIME_VALIDATION_V1_TERMINAL_DISPOSITION.json")
    process = load("PROCESS_LIMIT_EVIDENCE_CLASSIFICATION.json")
    ownership = load("DEFECT_OWNERSHIP_DECISION.json")
    partial = load("PARTIAL_EVIDENCE_ADMISSIBILITY.json")
    gap = load("PROVENANCE_GAP_AND_CLAIM_CEILING.json")
    successor = load("RUNTIME_VALIDATION_V2_SUCCESSOR_AUTHORIZATION_DECISION.json")
    path_binding = load("RUNTIME_VALIDATION_V2_IDENTITY_AND_PATH_BINDING.json")
    feasibility = load("RESOURCE_LIMIT_FEASIBILITY_PRECHECK_CONTRACT.json")
    gates = load("V2_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT.json")
    single = load("V2_SINGLE_USE_EXECUTION_CONTRACT.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
    next_gate = load("NEXT_LEGAL_MILESTONE.json")
    primary = load("GOVERNANCE_TEST_RESULT.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")

    check("I001_IDENTITY", all(doc.get("governance_identity") == IDENTITY for doc in (route, binding, disposition, process, ownership, partial, gap, successor, path_binding, feasibility, gates, single, authority, matrix, next_gate, primary, negative)))
    check("I002_GOVERNANCE_ONLY", route.get("scope") == "IMMUTABLE_GOVERNANCE_ADJUDICATION_ONLY")
    check("I003_ZERO_OPERATIONS", zero_typed_operations_performed(route))
    check("I004_PREDECESSOR_STATIC_SHA", binding.get("runtime_validation_v1", {}).get("source_manifest_sha256") == sha(V1 / "locks/STATIC_SOURCE_MANIFEST.json"))
    check("I005_PREDECESSOR_LOCK_SHA", binding.get("runtime_validation_v1", {}).get("static_execution_lock_sha256") == sha(V1 / "locks/STATIC_EXECUTION_LOCK.json"))
    check("I006_RESOURCE_SHA", binding.get("runtime_validation_v1", {}).get("resource_contract_sha256") == sha(V1 / "contracts-v1/RESOURCE_AND_TIMEOUT_CONTRACT.json"))
    check("I007_RUNNER_SHA", binding.get("runtime_validation_v1", {}).get("runner_sha256") == sha(V1 / "tooling/run_once.py"))
    check("I008_TERMINAL_SHA", binding.get("terminal_evidence", {}).get("terminal_sha256") == sha(V1 / "evidence-v1/RUNTIME_VALIDATION_TERMINAL_RESULT.json"))
    check("I009_EVIDENCE_MANIFEST_SHA", binding.get("terminal_evidence", {}).get("evidence_manifest_sha256") == sha(V1 / "evidence-v1/EVIDENCE_MANIFEST.json"))
    check("I010_EVIDENCE_LOCK_SHA", binding.get("terminal_evidence", {}).get("evidence_lock_sha256") == sha(V1 / "evidence-v1/EVIDENCE_FREEZE_LOCK.json"))
    check("I011_V1_TERMINAL", disposition.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION_REFERENCE_ONLY")
    check("I012_ATTEMPT_ONE", disposition.get("attempt_count") == disposition.get("maximum_attempts") == 1)
    check("I013_NO_RETRY_PATCH_RELOCK", disposition.get("retry_authorized") is False and disposition.get("patch_in_place_authorized") is False and disposition.get("relock_same_identity_authorized") is False)
    check("I014_CONFINEMENT_NOT_PROVEN", disposition.get("confinement") == partial.get("confinement") == "NOT_PROVEN")
    check("I015_CLASSIFICATION_EXACT", process.get("root_cause_classification") == "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED")
    check("I016_LOCKED_LIMIT_32", process.get("confirmed_facts", {}).get("locked_rlimit_nproc") == 32)
    check("I017_SNAPSHOT_81", process.get("post_failure_observation", {}).get("uid_process_population") == 81)
    check("I018_SNAPSHOT_TEMPORAL_SCOPE", process.get("post_failure_observation", {}).get("time_relation") == "AFTER_TERMINAL_FAILURE")
    check("I019_SNAPSHOT_NOT_FROZEN", process.get("post_failure_observation", {}).get("evidence_class") == "EPHEMERAL_ADJUDICATION_OBSERVATION_NOT_FROZEN_ATTEMPT_EVIDENCE")
    check("I020_NO_PRELAUNCH_CLAIM", process.get("post_failure_observation", {}).get("cannot_prove_prelaunch_population") is True)
    check("I021_STDERR_ZERO", process.get("confirmed_facts", {}).get("stderr_bytes") == 0 and (V1 / "evidence-v1/logs/child.stderr").stat().st_size == 0)
    check("I022_TRACE_ZERO", process.get("confirmed_facts", {}).get("trace_file_count") == 0 and not any(path.is_file() for path in (V1 / "evidence-v1/traces").rglob("*")))
    check("I023_NO_SYSCALL_OVERCLAIM", {"EXACT_FAILED_SYSCALL", "EXACT_ERRNO"}.issubset(set(process.get("unsupported_claims", []))))
    check("I024_CONFIDENCE_CEILING", process.get("confidence_ceiling") == gap.get("claim_ceiling") == "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED")
    check("I025_OWNERSHIP", ownership.get("decision") == "LAUNCHER_RESOURCE_LIMIT_CONTRACT_OWNS_FEASIBILITY_AND_DIAGNOSTIC_COMPLETENESS")
    check("I026_FEASIBILITY_GAP_CONFIRMED", ownership.get("defect_components", {}).get("missing_execution_context_feasibility_precheck") == "CONFIRMED_CONTRACT_GAP")
    check("I027_DIRECT_CAUSE_NOT_CONFIRMED", ownership.get("defect_components", {}).get("rlimit_nproc_as_direct_cause") == "STRONGLY_INDICATED_NOT_SYSCALL_CONFIRMED")
    check("I028_DIAGNOSTIC_GAP", ownership.get("defect_components", {}).get("missing_syscall_confirming_diagnostics") == "CONFIRMED_EVIDENCE_GAP")
    check("I029_NO_PRODUCT_DEFECT", ownership.get("product_or_fixture_logic_defect") is False)
    check("I030_NO_BYPASS", ownership.get("containment_bypass") is False)
    check("I031_PARTIAL_ONLY", partial.get("status") == "ADMISSIBLE_AS_TERMINAL_LAUNCH_FAILURE_PROVENANCE_ONLY")
    check("I032_GAP_NO_RECONSTRUCTION", gap.get("must_not_reconstruct_missing_trace") is True)
    check("I033_SUCCESSOR_AUTHORIZED", successor.get("decision") == "AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V2_CONDITIONALLY")
    check("I034_SUCCESSOR_STATE", successor.get("status") == "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I035_V2_IDENTITY", successor.get("execution_identity") == path_binding.get("execution_identity") == V2_IDENTITY)
    check("I036_V2_OPERATION", successor.get("operation") == path_binding.get("operation") == V2_OPERATION)
    check("I037_V2_ATTEMPT_ZERO", successor.get("attempt_count") == 0 and successor.get("maximum_attempts") == 1)
    check("I038_V2_PATH", path_binding.get("workspace") == str(V2) and not V2.exists() and not V2.is_symlink())
    check("I039_FRESH_LINEAGE", all(path_binding.get(key) is True for key in ("fresh_source_required", "fresh_tests_required", "fresh_static_lock_required", "fresh_one_shot_contract_required")))
    check("I040_FEASIBILITY_REQUIRED", successor.get("resource_limit_feasibility_precheck") == "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION" and feasibility.get("required") is True)
    check("I041_PRECHECK_ORDER", feasibility.get("ordering", [])[-2:] == ["ONLY_THEN_WRITE_ATTEMPT_MARKER", "ONLY_THEN_LAUNCH_CHILD"])
    check("I042_PRECHECK_FIELDS", {"enforcement_domain", "baseline_usage", "projected_launcher_peak", "safety_margin", "configured_soft_limit", "feasibility_predicate", "predicate_result", "precheck_result_sha256"}.issubset(set(feasibility.get("required_fields", []))))
    check("I043_RLIMIT_SPECIFIC", "ACCOUNT_FOR_STRACE_AND_TRACEE_PROCESS_TREE" in feasibility.get("rlimit_nproc_specific_if_selected", []))
    check("I044_MECHANISM_DEFERRED", successor.get("solution_mechanism") == "DEFERRED_TO_FRESH_V2_CONTRACT_AND_MUST_BE_LOCKED_BEFORE_EXECUTION")
    check("I045_FAIL_BEFORE_ATTEMPT", feasibility.get("precheck_failure") == "STOP_BEFORE_ATTEMPT_MARKER_ATTEMPT_REMAINS_ZERO")
    check("I046_STATIC_ONLY_INSUFFICIENT", feasibility.get("static_or_syntactic_limit_validation_alone") == "INSUFFICIENT")
    check("I047_REQUIRED_REGRESSIONS", all(item in gates.get("regressions", []) for item in ("RLIMIT_NPROC_SHARED_UID_BASELINE_EXCEEDS_LIMIT_FAILS_BEFORE_ATTEMPT", "FEASIBLE_LIMIT_AND_HEADROOM_PASSES", "STALE_MEASUREMENT_FAILS", "ATTEMPT_MARKER_BEFORE_PRECHECK_IS_REJECTED")))
    check("I048_SINGLE_USE", single.get("maximum_attempts") == 1 and single.get("automatic_retry") is False)
    check("I049_ATTEMPT_EVENT", single.get("attempt_consumption_event", "").startswith("ATOMIC_ATTEMPT_MARKER"))
    check("I050_SUCCESS_CEILING", single.get("success_ceiling") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION")
    check("I051_DEFAULT_DENY", matrix.get("default") == "DENY")
    check("I052_V1_PROHIBITED", matrix.get("operations", {}).get("PATCH_RELOCK_OR_RETRY_V1") == "PROHIBITED")
    check("I053_NO_V2_NOW", matrix.get("operations", {}).get("CREATE_OR_EXECUTE_V2_DURING_THIS_GOVERNANCE") == "NOT_AUTHORIZED")
    check("I054_DEFERRED_CAPABILITIES", all(matrix.get("operations", {}).get(key) == "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION" for key in ("CODEX_DAYBREAK_WORKER_SUBAGENT", "KERNEL_SANDBOX_PWNESCAPE_REPLAY", "TARGET_NETWORK_PARALLEL_CAPABILITY_FULL_CHAIN_SUBMISSION")))
    check("I055_NEXT_MILESTONE", next_gate.get("execution_identity") == V2_IDENTITY and next_gate.get("resource_limit_feasibility_precheck") == "REQUIRED_BEFORE_ATTEMPT_CONSUMPTION")
    check("I056_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I057_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 32 and negative.get("tests_failed") == 0)
    check("I058_ZERO_PRIMARY_COUNTERS", zero_typed(primary))
    check("I059_ZERO_NEGATIVE_COUNTERS", zero_typed(negative))
    check("I060_V1_BYTES_READ_ONLY", all(ro(path) for path in V1.rglob("*") if path.is_file()))

    failed = [item for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V1_ERRATUM_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed),
        "failed": failed,
        "checks": checks,
        "operation_counters": {key: 0 for key in sorted(OPERATION_KEYS)},
    }
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0002.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"status": result["status"], "total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
