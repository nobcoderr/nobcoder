#!/usr/bin/env python3
"""Issue the immutable governance manifest and lock after every candidate gate passes."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
V5 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v5-20261020")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4_NON_NUMERIC_STRACE_EXIT_RETURN_GRAMMAR_AND_MISSING_RUNTIME_RESULT_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"

SCRIPTS = {"build_governance.py", "validate_governance.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V4_FROZEN_EVIDENCE_BINDING.json", "V4_TERMINAL_DISPOSITION.json",
    "TRACE_TERMINATION_EVENT_INVENTORY.json", "STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json",
    "SYSCALL_FAMILY_DISPATCH_DECISION.json", "MISSING_RUNTIME_RESULT_ADJUDICATION.json",
    "POST_VALIDATION_INCOMPLETENESS_DECISION.json", "CAUSAL_OWNERSHIP_ADJUDICATION.json",
    "SUCCESSOR_V5_REQUIREMENTS.json", "SUCCESSOR_V5_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEXT_LEGAL_MILESTONE.json",
    "GOVERNANCE_DECISION_SUMMARY.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    data = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(data.encode()).hexdigest()


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS | {FREEZE}
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"finalize file-set mismatch: actual={len(actual)} expected={len(expected)}")
    if V5.exists() or V5.is_symlink():
        raise SystemExit("V5 exists before successor engineering milestone")
    if not all((path.stat().st_mode & 0o222) == 0 for path in V4.rglob("*") if path.is_file()):
        raise SystemExit("V4 immutability failed")

    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    freeze = load(FREEZE)
    required_passes = [
        primary["status"] == "PASS" and primary["checks_failed"] == 0,
        negative["status"] == "PASS" and negative["tests_failed"] == 0,
        independent["status"] == "PASS" and independent["checks_failed"] == 0,
        freeze["status"] == "PASS" and freeze["checks_failed"] == 0,
    ]
    if not all(required_passes):
        raise SystemExit("not all governance gates passed")
    terminal = load("V4_TERMINAL_DISPOSITION.json")
    grammar = load("STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json")
    dispatch = load("SYSCALL_FAMILY_DISPATCH_DECISION.json")
    missing = load("MISSING_RUNTIME_RESULT_ADJUDICATION.json")
    post = load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")
    successor = load("SUCCESSOR_V5_AUTHORIZATION_DECISION.json")
    requirements = load("SUCCESSOR_V5_REQUIREMENTS.json")
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    if terminal["disposition"] != "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY":
        raise SystemExit("V4 terminal disposition changed")
    if grammar["strace_return_value_grammar_defect"] != "YES":
        raise SystemExit("grammar defect is not adjudicated")
    if missing["status"] != "NOT_EMITTED" or post["compatibility"] != "NOT_ESTABLISHED" or post["confinement"] != "NOT_PROVEN":
        raise SystemExit("missing-result or non-promotion state changed")
    if successor["decision"] != "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V5_CONDITIONALLY":
        raise SystemExit("V5 successor decision missing")
    if not all(value == 0 for value in authority["governance_operation_counters"].values()):
        raise SystemExit("governance operation counter nonzero")

    members = [
        {"path": path.name, "sha256": sha(path), "bytes": path.stat().st_size}
        for path in sorted(ROOT.iterdir(), key=lambda item: item.name)
        if path.is_file()
    ]
    member_root = canonical_root(members)
    manifest = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "canonical_member_root_sha256": member_root, "member_count": len(members),
        "members": members, "self_referential_hashes": False,
    }
    with (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True); handle.write("\n")
    manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    artifact_root = canonical_root(members + [{
        "path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha,
        "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size,
    }])
    lock = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": successor["decision"],
        "v4_disposition": terminal["disposition"], "v4_attempt": terminal["attempt"],
        "v4_codex_invocation_count": terminal["codex_cli_invocation_count"],
        "runtime_result": missing["status"], "independent_post_validation": terminal["independent_post_validation"],
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "pass_locked_compatibility_issued": False,
        "strace_return_value_grammar_defect": grammar["strace_return_value_grammar_defect"],
        "syscall_family_dispatch_order_defect": ownership["syscall_family_dispatch_order_defect"],
        "missing_runtime_result_classification": missing["causal_classification"],
        "runtime_pass_inferred": False, "runtime_failure_inferred": False,
        "required_parse_order": dispatch["required_order"],
        "v5_mandatory_requirements": requirements["mandatory_requirements"],
        "v5_execution_identity": successor["successor_execution_identity"],
        "v5_suite_identity": successor["successor_suite_identity"], "v5_path": successor["successor_path"],
        "v5_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_AT_FREEZE",
        "v5_attempt_count": 0, "v5_attempt_limit": 1,
        "v5_codex_invocation_count": 0, "v5_codex_invocation_limit": 1,
        "separate_acceptance_after_v5_execution": True,
        "worker_execution_authorized": False, "subagent_execution_authorized": False,
        "credential_use_authorized": False, "target_access_authorized": False,
        "external_network_authorized": False, "daybreak_invocation_authorized": False,
        "exploit_replay_authorized": False, "parallelism_authorized": False,
        "capability_graph_authorized": False, "candidate_promotion_authorized": False,
        "submission_automation_authorized": False,
        "operation_counters": authority["governance_operation_counters"],
        "validation_counts": {
            "primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
            "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
            "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
            "final_freeze_candidate": {"total": freeze["checks_total"], "passed": freeze["checks_passed"], "failed": freeze["checks_failed"]},
        },
        "canonical_member_root_sha256": member_root,
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 2},
        "next_legal_milestone": load("NEXT_LEGAL_MILESTONE.json")["next_if_pass_locked"],
    }
    with (ROOT / "GOVERNANCE_LOCK.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(lock, handle, indent=2, sort_keys=True); handle.write("\n")
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": lock["status"], "decision": lock["decision"], "member_count": len(members),
        "governance_manifest_sha256": manifest_sha, "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"),
        "canonical_artifact_root_sha256": artifact_root,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
