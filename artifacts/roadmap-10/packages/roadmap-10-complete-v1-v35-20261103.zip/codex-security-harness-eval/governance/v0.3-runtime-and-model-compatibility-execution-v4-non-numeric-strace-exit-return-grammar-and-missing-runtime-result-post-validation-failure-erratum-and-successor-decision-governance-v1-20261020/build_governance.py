#!/usr/bin/env python3
"""Build the V4 parser-failure governance adjudication from frozen evidence only."""

from __future__ import annotations

import gzip
import hashlib
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v3-non-path-pipe-payload-misclassification-post-validation-failure-erratum-and-successor-decision-governance-v1-20261018")
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
V5 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v5-20261020")
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")
EXIT_MAN = Path("/usr/share/man/man2/_exit.2.gz")
EXIT_GROUP_MAN = Path("/usr/share/man/man2/exit_group.2.gz")

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4_NON_NUMERIC_STRACE_EXIT_RETURN_GRAMMAR_AND_MISSING_RUNTIME_RESULT_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V4_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4"
V4_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V5"
V5_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5"
V5_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V6"

HASHES = {
    "predecessor_lock": "832db854d1f6fbdb596a9da9e171d8d223de8fcf5587b982fd1a8778a6e86eb0",
    "predecessor_manifest": "3a1e96a443f30b0f329db760587e5d56fc78a096f9a729a60661fc9596a7f120",
    "predecessor_root": "4bc7e76969c225dcceabc69fce2f798b0515912f162204bf3bdfa7725b6107d7",
    "v4_source_manifest": "8f24fddb5891e1acdb909dd7f2b31f6e1a19451081ca3819c823343b2317602c",
    "v4_static_lock": "4be5265022687561f0756f18b0ac400e783c2e2d2cc3b85aa343afedeb2ba2f0",
    "v4_lock_verification": "2d92ca09e48714f9eb4ea0b4fd4b2938f82c75beafd4d64dc20e1091121fc45e",
    "v4_attempt": "f4c89039ce9832dbb491903be91c7879b9ebd3fe6ca684819e616353dca739e0",
    "v4_terminal": "8c592167d1a5d85708cda564f7ac152b2f46c55300e7b2989de34d051cfa1fed",
    "v4_post": "68b3cb1bf0c0c5f5b4934f17870659c338748412b34bea77397e4d099d649909",
    "v4_evidence_manifest": "80d700f0c4cf291dfa88f5c6e445f9ad599771088854d9b5eaba7fa13aa2423d",
    "v4_evidence_lock": "6f4c1a6abc5f499322ba878f4b2de79ff861127d315e138e3a54126bf419eebc",
    "v4_source_root": "43e9dfd2968554eae1aef9f756b05083b5fb3604246acea6b24d97fb7615067f",
    "v4_evidence_root": "64a40476e75feab3e6e02561588ba17cfe5f366412c73fffd4e577a2c56918da",
    "exit_man": "5e6f56afae0887fcd8a5cd66217502b496cb73e8df87abd5751c1314358278fc",
    "exit_group_man": "4f03ebc84e5b6248097b61512cde1d58cea5f9385488034bae7f6589868b14f1",
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
}

OPERATION_KEYS = [
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "compatibility_suite_executions", "credential_operations", "daybreak_invocations",
    "exploit_replays", "external_network_operations", "future_runtime_invocations",
    "parallel_operations", "runtime_invocations", "subagent_processes",
    "submission_operations", "target_operations", "worker_processes",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    payload = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(payload.encode()).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    data = {"governance_identity": IDENTITY, **payload}
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_manifest(base: Path, manifest: dict[str, Any], root_field: str) -> None:
    for row in manifest["members"]:
        path = base / row["path"]
        if not path.is_file() or path.is_symlink():
            raise SystemExit(f"manifest member unavailable: {path}")
        if sha(path) != row["sha256"] or path.stat().st_size != row["bytes"]:
            raise SystemExit(f"manifest member mismatch: {path}")
    if canonical_root(manifest["members"]) != manifest[root_field]:
        raise SystemExit("canonical root mismatch")


def termination_events() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    pattern = re.compile(r"^(?P<name>exit|exit_group)\((?P<status>-?[0-9]+)\)\s+=\s+\?$")
    for path in sorted((V4 / "static-run-v1").glob("trace.*")):
        for line_number, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            match = pattern.match(raw)
            if match:
                rows.append({
                    "trace": path.name,
                    "line_number": line_number,
                    "line": raw,
                    "line_sha256": hashlib.sha256((raw + "\n").encode()).hexdigest(),
                    "syscall_family": "NON_RETURNING_PROCESS_TERMINATION",
                    "syscall": match.group("name"),
                    "status_argument": int(match.group("status")),
                    "return_token": "?",
                    "typed_event": "NON_RETURNING_TERMINATION_EVENT",
                })
    return rows


def main() -> None:
    expected_sources = {"build_governance.py", "validate_governance.py", "finalize_governance.py"}
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected_sources or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    if V5.exists() or V5.is_symlink():
        raise SystemExit("successor V5 must not exist during governance adjudication")

    expected = {
        PRED / "GOVERNANCE_LOCK.json": HASHES["predecessor_lock"],
        PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json": HASHES["predecessor_manifest"],
        V4 / "STATIC_SOURCE_MANIFEST.json": HASHES["v4_source_manifest"],
        V4 / "STATIC_EXECUTION_LOCK.json": HASHES["v4_static_lock"],
        V4 / "STATIC_EXECUTION_LOCK_VERIFICATION.json": HASHES["v4_lock_verification"],
        V4 / "static-run-v1/ATTEMPT_MARKER.json": HASHES["v4_attempt"],
        V4 / "static-run-v1/RUNNER_TERMINAL_FAILURE_RECORD.json": HASHES["v4_terminal"],
        V4 / "static-run-v1/independent-post-validation-0001.json": HASHES["v4_post"],
        V4 / "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json": HASHES["v4_evidence_manifest"],
        V4 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json": HASHES["v4_evidence_lock"],
        EXIT_MAN: HASHES["exit_man"], EXIT_GROUP_MAN: HASHES["exit_group_man"],
        ROUTER_MAP: HASHES["router_map"],
    }
    failed = [str(path) for path, digest in expected.items() if not path.is_file() or sha(path) != digest]
    if failed:
        raise SystemExit("canonical preflight digest failure: " + ", ".join(failed))

    source_manifest = load(V4 / "STATIC_SOURCE_MANIFEST.json")
    evidence_manifest = load(V4 / "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json")
    verify_manifest(V4, source_manifest, "canonical_source_root_sha256")
    verify_manifest(V4 / "static-run-v1", evidence_manifest, "canonical_evidence_root_sha256")
    if source_manifest["canonical_source_root_sha256"] != HASHES["v4_source_root"]:
        raise SystemExit("V4 source root mismatch")
    if evidence_manifest["canonical_evidence_root_sha256"] != HASHES["v4_evidence_root"]:
        raise SystemExit("V4 evidence root mismatch")
    if not all((path.stat().st_mode & 0o222) == 0 for path in V4.rglob("*") if path.is_file()):
        raise SystemExit("V4 contains writable files")

    predecessor = load(PRED / "GOVERNANCE_LOCK.json")
    terminal = load(V4 / "static-run-v1/RUNNER_TERMINAL_FAILURE_RECORD.json")
    post = load(V4 / "static-run-v1/independent-post-validation-0001.json")
    attempt = load(V4 / "static-run-v1/ATTEMPT_MARKER.json")
    evidence_lock = load(V4 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json")
    parser_source = (V4 / "src/compatibility_v4.py").read_text(encoding="utf-8")
    runner_source = (V4 / "src/runner_v4.py").read_text(encoding="utf-8")
    required_fragments = [
        'rc = re.match(r"^-?[0-9]+", result)',
        'raise ValueError("ambiguous syscall return value")',
        'event = parse_syscall_line(line)',
        'if event is None or event.name != "execve":',
        'codex_count = successful_codex_exec_count(traces)',
        'append_only_json(STATIC_RUN / "runtime-result-0001.json"',
    ]
    if not all(fragment in parser_source + runner_source for fragment in required_fragments):
        raise SystemExit("locked parser/runner source no longer matches failure model")
    events = termination_events()
    if len(events) != 14 or {row["syscall"] for row in events} != {"exit", "exit_group"}:
        raise SystemExit("unexpected frozen termination-event inventory")
    with gzip.open(EXIT_MAN, "rt", encoding="utf-8") as handle:
        exit_text = handle.read()
    with gzip.open(EXIT_GROUP_MAN, "rt", encoding="utf-8") as handle:
        exit_group_text = handle.read()
    if "These functions do not return." not in exit_text or "This system call does not return." not in exit_group_text:
        raise SystemExit("local syscall semantic references do not match")

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0", "scope": "GOVERNANCE_ONLY_FROZEN_EVIDENCE_ADJUDICATION",
        "authorized_actions": ["READ_FROZEN_V4_EVIDENCE", "ADJUDICATE_TYPED_SYSCALL_GRAMMAR", "ISSUE_SUCCESSOR_DECISION", "RUN_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE"],
        "forbidden_actions": ["PATCH_V4", "RELOCK_V4", "REVALIDATE_V4", "RETRY_V4", "INVOKE_CODEX", "CREATE_OR_EXECUTE_V5", "WORKER_OR_SUBAGENT_EXECUTION", "CREDENTIAL_OR_TARGET_OR_NETWORK_OPERATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION"],
        "target_or_runtime_execution_authority": False,
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_ROUTING_LEDGER", "schema_version": "1.0",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "agentic-security-research-harness", "external-ai-security-tool-governor", "codex-security-harness"],
        "deferred": ["compatibility runtime execution", "worker/subagent execution", "target/network access", "exploit research", "parallel agent research"],
        "not_applicable": ["program-impact-boundary finding adjudication", "prior-art vulnerability screening", "live offensive validation"],
        "subagents_used": False, "codex_invoked": False, "runtime_invoked": False,
        "router_map_sha256": HASHES["router_map"],
    })
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_PREDECESSOR_CHAIN_BINDING", "schema_version": "1.0",
        "predecessor_governance_identity": predecessor["governance_identity"], "predecessor_status": predecessor["status"],
        "predecessor_decision": predecessor["decision"], "predecessor_lock_sha256": HASHES["predecessor_lock"],
        "predecessor_manifest_sha256": HASHES["predecessor_manifest"],
        "predecessor_canonical_artifact_root_sha256": HASHES["predecessor_root"],
        "authorized_v4_execution_identity": predecessor["v4_execution_identity"],
        "authorized_v4_suite_identity": predecessor["v4_suite_identity"],
    })
    write("V4_FROZEN_EVIDENCE_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_FROZEN_EVIDENCE_BINDING", "schema_version": "1.0",
        "v4_path": str(V4), "execution_identity": V4_EXECUTION, "suite_identity": V4_SUITE,
        "source_manifest_sha256": HASHES["v4_source_manifest"], "canonical_source_root_sha256": HASHES["v4_source_root"],
        "static_execution_lock_sha256": HASHES["v4_static_lock"], "static_lock_verification_sha256": HASHES["v4_lock_verification"],
        "attempt_marker_sha256": HASHES["v4_attempt"], "terminal_record_sha256": HASHES["v4_terminal"],
        "independent_post_validation_sha256": HASHES["v4_post"],
        "evidence_manifest_sha256": HASHES["v4_evidence_manifest"], "evidence_freeze_lock_sha256": HASHES["v4_evidence_lock"],
        "canonical_evidence_root_sha256": HASHES["v4_evidence_root"],
        "source_member_count": source_manifest["member_count"], "evidence_member_count": evidence_manifest["member_count"],
        "source_integrity": "PASS", "evidence_integrity": "PASS", "all_v4_files_read_only": True,
    })
    write("V4_TERMINAL_DISPOSITION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "execution_identity": V4_EXECUTION, "suite_identity": V4_SUITE,
        "disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "attempt": "1_OF_1_CONSUMED_NO_RETRY", "attempt_count": attempt["attempt_count"],
        "codex_cli_invocation_count": 1, "runtime_result": "NOT_EMITTED",
        "independent_post_validation": post["status"], "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "pass_locked_issued": False, "patch": "PROHIBITED", "relock": "PROHIBITED",
        "revalidation": "PROHIBITED", "retry": "PROHIBITED", "promotion": "PROHIBITED",
        "terminal_evidence_status": evidence_lock["status"],
    })
    write("TRACE_TERMINATION_EVENT_INVENTORY.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_TRACE_TERMINATION_EVENT_INVENTORY", "schema_version": "1.0",
        "trace_set": "FROZEN_V4_TRACE_SET", "event_count": len(events), "events": events,
        "observed_grammar": ["exit(status) = ?", "exit_group(status) = ?"],
        "claim_scope": "FROZEN_V4_TRACE_SET_ONLY",
    })
    write("STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION", "schema_version": "1.0",
        "strace_return_value_grammar_defect": "YES",
        "verdict": "CONFIRMED_NUMERIC_RETURN_PARSE_PRECEDED_SYSCALL_FAMILY_DISPATCH",
        "locked_failure_flow": ["PARSE_GENERIC_SYSCALL_LINE", "FORCE_NUMERIC_RETURN_TOKEN", "RAISE_ON_QUESTION_MARK", "EXECVE_FILTER_NOT_REACHED", "RUNTIME_RESULT_NOT_EMITTED"],
        "affected_frozen_events": len(events), "affected_syscalls": ["exit", "exit_group"], "accepted_typed_return_token": "?",
        "accepted_only_for_family": "NON_RETURNING_PROCESS_TERMINATION",
        "local_semantic_references": [
            {"path": str(EXIT_MAN), "sha256": HASHES["exit_man"], "fact": "_exit/_Exit do not return"},
            {"path": str(EXIT_GROUP_MAN), "sha256": HASHES["exit_group_man"], "fact": "exit_group does not return"},
        ],
        "scope_limit": "DOES_NOT_AUTHORIZE_NON_NUMERIC_RETURN_TOKENS_FOR_OTHER_SYSCALL_FAMILIES",
    })
    write("SYSCALL_FAMILY_DISPATCH_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_SYSCALL_FAMILY_DISPATCH_DECISION", "schema_version": "1.0",
        "required_order": ["PARSE_SYSCALL_IDENTITY_AND_ARGUMENT_STRUCTURE", "CLASSIFY_SYSCALL_FAMILY", "APPLY_FAMILY_SPECIFIC_RETURN_GRAMMAR", "EMIT_TYPED_EVENT"],
        "prohibited_order": ["PARSE_ALL_RETURN_VALUES_AS_NUMERIC", "THEN_CLASSIFY_SYSCALL"],
        "termination_family": {"members": ["exit", "exit_group"], "return_grammar": ["NON_RETURNING_QUESTION_MARK_SENTINEL"], "event_type": "NON_RETURNING_TERMINATION_EVENT"},
        "unknown_or_ambiguous_family_policy": "FAIL_CLOSED_WITH_DIAGNOSTIC_RECORD",
        "numeric_return_required_only_where_family_contract_requires_it": True,
    })
    write("MISSING_RUNTIME_RESULT_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_MISSING_RUNTIME_RESULT_ADJUDICATION", "schema_version": "1.0",
        "runtime_result_artifact": "static-run-v1/runtime-result-0001.json", "status": "NOT_EMITTED",
        "causal_classification": "CONSEQUENCE_OF_POST_RUNTIME_PRIMARY_TRACE_PARSER_ABORT",
        "runtime_pass_inferred": False, "runtime_failure_inferred": False,
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "no_reconstruction": True,
        "successor_requirement": "EMIT_APPEND_ONLY_DIAGNOSTIC_COMPLETE_RUNTIME_RESULT_ENVELOPE_ON_EVERY_POST_LAUNCH_TERMINAL_PATH_WITH_UNKNOWN_FIELDS_EXPLICITLY_MARKED_UNKNOWN",
    })
    write("POST_VALIDATION_INCOMPLETENESS_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_POST_VALIDATION_INCOMPLETENESS_DECISION", "schema_version": "1.0",
        "locked_post_status": post["status"], "completed": False,
        "reason": "LOCKED_RUNNER_ABORTED_BEFORE_RUNTIME_RESULT_AND_LOCKED_POST_VALIDATOR_COULD_NOT_EVALUATE_FULL_TRACE_SET",
        "partial_passes_do_not_promote": True, "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "pass_locked_compatibility_issued": False,
    })
    write("CAUSAL_OWNERSHIP_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_CAUSAL_OWNERSHIP_ADJUDICATION", "schema_version": "1.0",
        "ownership_defect": "POST_RUNTIME_PRIMARY_TRACE_PARSER_CONTRACT_DEFECT",
        "strace_return_value_grammar_defect": "YES", "syscall_family_dispatch_order_defect": "YES",
        "runtime_result_diagnostic_completeness_gap": "YES",
        "codex_runtime_defect": "NOT_PROVEN", "runtime_compatibility_defect": "NOT_PROVEN",
        "v4_static_lock_defect": "NO", "v4_execution_identity_defect": "NO",
        "confinement_bypass": "NO_EVIDENCE_OF_BYPASS_BUT_CONFINEMENT_NOT_PROVEN",
    })
    mandatory = [
        "FRESH_V5_IDENTITY_SOURCE_TESTS_AND_LOCK", "CARRY_FORWARD_V1_V2_V3_V4_REGRESSIONS",
        "SYSCALL_TYPE_DISPATCH_BEFORE_RETURN_PARSE", "EXPLICIT_NON_NUMERIC_EXIT_RETURN_GRAMMAR",
        "TYPED_EXIT_AND_EXIT_GROUP_TERMINATION_EVENTS", "UNKNOWN_SYSCALL_FAMILY_FAIL_CLOSED",
        "RUNTIME_RESULT_DIAGNOSTIC_COMPLETENESS", "NO_RECONSTRUCTION_OF_MISSING_V4_RUNTIME_RESULT",
        "SEMANTIC_EXECVE_LINEAGE_CLASSIFICATION", "NAMESPACE_SETUP_WRITE_PROOF",
        "SEMANTIC_SYSCALL_PATH_CLASSIFICATION", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE",
        "DEDICATED_CONFIG_CONSUMPTION_PROOF", "EXACT_BINARY_CONFIG_ARGV_ENV_CWD_BINDING",
        "STATIC_LOCK_BEFORE_ATTEMPT", "EXACTLY_ONE_SUCCESSOR_ATTEMPT_AND_CODEX_INVOCATION",
        "INDEPENDENT_POST_VALIDATION", "EVIDENCE_FREEZE", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    write("SUCCESSOR_V5_REQUIREMENTS.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_SUCCESSOR_V5_REQUIREMENTS", "schema_version": "1.0",
        "successor_execution_identity": V5_EXECUTION, "successor_suite_identity": V5_SUITE,
        "mandatory_requirements": mandatory,
        "regression_fixtures": [
            {"case": "exit_group_question_mark", "expected": "TYPED_TERMINATION_EVENT_PASS"},
            {"case": "exit_question_mark", "expected": "TYPED_TERMINATION_EVENT_PASS"},
            {"case": "execve_numeric_success", "expected": "TYPED_EXECVE_EVENT_PASS"},
            {"case": "openat_question_mark", "expected": "FAIL_CLOSED_WRONG_FAMILY_GRAMMAR"},
            {"case": "execve_question_mark", "expected": "FAIL_CLOSED_WRONG_FAMILY_GRAMMAR"},
            {"case": "unknown_syscall_question_mark", "expected": "FAIL_CLOSED_UNKNOWN_FAMILY"},
            {"case": "malformed_termination_arguments", "expected": "FAIL_CLOSED_ARGUMENT_GRAMMAR"},
            {"case": "parser_failure_after_launch", "expected": "DIAGNOSTIC_RUNTIME_RESULT_EMITTED_FAIL_CLOSED"},
        ],
    })
    write("SUCCESSOR_V5_AUTHORIZATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_SUCCESSOR_V5_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V5_CONDITIONALLY",
        "successor_execution_identity": V5_EXECUTION, "successor_suite_identity": V5_SUITE, "successor_path": str(V5),
        "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt_count": 0, "attempt_limit": 1, "codex_invocation_count": 0, "codex_invocation_limit": 1,
        "creation_or_execution_this_milestone": False, "separate_acceptance_required": True,
        "authority_ceiling": "COMPATIBILITY_VALIDATION_ONLY_NO_WORKER_TARGET_OR_NETWORK_AUTHORITY",
    })
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "governance_only": True, "runtime_invoked_this_milestone": False, "codex_invoked_this_milestone": False,
        "v5_created_this_milestone": False, "global_config_mutated": False,
        "governance_operation_counters": {key: 0 for key in OPERATION_KEYS},
        "supported_but_deferred": ["worker", "subagent", "credential_injection", "target_access", "external_network", "exploit_replay", "parallelism", "capability_graph", "candidate_promotion", "submission_automation", "daybreak_runtime"],
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "currently_authorized": ["READ_FROZEN_V4_EVIDENCE", "GOVERNANCE_VALIDATION", "GOVERNANCE_FREEZE"],
        "conditionally_authorized_after_this_lock": ["CREATE_VALIDATE_LOCK_V5", "ONE_IDENTITY_BOUND_V5_COMPATIBILITY_ATTEMPT_IF_ALL_GATES_PASS"],
        "deferred_requires_separate_authorization": ["worker", "subagent", "credentials", "target", "network", "Daybreak", "exploit_replay", "parallelism", "capability_graph", "promotion", "submission"],
        "permanently_prohibited": ["worker_self_authorization", "worker_self_promotion", "raw_secret_in_prompt_repository_or_evidence", "unsandboxed_fallback", "out_of_scope_third_party_targeting"],
    })
    fixtures = [
        {"id": "N001", "case": "exit_group(0) = ?", "expected": "ACCEPT_TYPED_TERMINATION"},
        {"id": "N002", "case": "exit(0) = ?", "expected": "ACCEPT_TYPED_TERMINATION"},
        {"id": "N003", "case": "exit_group(7) = ?", "expected": "ACCEPT_TYPED_TERMINATION"},
        {"id": "N004", "case": "execve(quoted_path, argv, env) = 0", "expected": "ACCEPT_NUMERIC_RETURN"},
        {"id": "N005", "case": "openat(AT_FDCWD, quoted_path, O_RDONLY) = 3", "expected": "ACCEPT_NUMERIC_RETURN"},
        {"id": "N006", "case": "openat(AT_FDCWD, quoted_path, O_RDONLY) = ?", "expected": "REJECT_WRONG_FAMILY_RETURN_GRAMMAR"},
        {"id": "N007", "case": "execve(quoted_path, argv, env) = ?", "expected": "REJECT_WRONG_FAMILY_RETURN_GRAMMAR"},
        {"id": "N008", "case": "mystery() = ?", "expected": "REJECT_UNKNOWN_FAMILY"},
        {"id": "N009", "case": "exit() = ?", "expected": "REJECT_MISSING_STATUS"},
        {"id": "N010", "case": "exit_group(x) = ?", "expected": "REJECT_NON_NUMERIC_STATUS"},
        {"id": "N011", "case": "exit_group(0) = success", "expected": "REJECT_INVALID_TERMINATION_SENTINEL"},
        {"id": "N012", "case": "question_mark_seen_before_family_dispatch", "expected": "REJECT_IMPLEMENTATION_ORDER"},
        {"id": "N013", "case": "missing_runtime_result_promoted_to_runtime_pass", "expected": "REJECT_PROMOTION"},
        {"id": "N014", "case": "missing_runtime_result_promoted_to_runtime_failure", "expected": "REJECT_UNPROVEN_RUNTIME_OUTCOME"},
        {"id": "N015", "case": "partial_post_validation_promoted_to_compatibility_pass", "expected": "REJECT_PROMOTION"},
        {"id": "N016", "case": "partial_post_validation_promoted_to_confinement_pass", "expected": "REJECT_PROMOTION"},
        {"id": "N017", "case": "patch_v4", "expected": "REJECT_TERMINAL_IDENTITY_MUTATION"},
        {"id": "N018", "case": "retry_v4", "expected": "REJECT_CONSUMED_IDENTITY_RETRY"},
        {"id": "N019", "case": "create_v5_during_governance", "expected": "REJECT_AUTHORITY_ESCALATION"},
        {"id": "N020", "case": "invoke_codex_during_governance", "expected": "REJECT_AUTHORITY_ESCALATION"},
        {"id": "N021", "case": "worker_execution_from_v5_authorization", "expected": "REJECT_AUTHORITY_INFERENCE"},
        {"id": "N022", "case": "target_network_from_v5_authorization", "expected": "REJECT_AUTHORITY_INFERENCE"},
        {"id": "N023", "case": "free_text_return_inference", "expected": "REJECT_UNTYPED_EVIDENCE"},
        {"id": "N024", "case": "unknown_family_default_accept", "expected": "REJECT_FAIL_OPEN"},
        {"id": "N025", "case": "diagnostic_record_omits_parser_stage", "expected": "REJECT_INCOMPLETE_DIAGNOSTIC"},
        {"id": "N026", "case": "diagnostic_record_fabricates_runtime_exit", "expected": "REJECT_FABRICATED_FACT"},
        {"id": "N027", "case": "v5_reuses_v4_identity", "expected": "REJECT_IDENTITY_REUSE"},
        {"id": "N028", "case": "v5_attempt_before_static_lock", "expected": "REJECT_PRELOCK_EXECUTION"},
        {"id": "N029", "case": "v5_second_attempt", "expected": "REJECT_RETRY"},
        {"id": "N030", "case": "v5_acceptance_without_separate_adjudication", "expected": "REJECT_IMPLICIT_PROMOTION"},
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0",
        "fixture_count": len(fixtures), "fixtures": fixtures,
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_if_pass_locked": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5_ONCE_IF_ALL_GATES_PASS",
        "successor_execution_identity": V5_EXECUTION, "successor_suite_identity": V5_SUITE,
        "attempt_initial": "0_OF_1", "codex_invocation_initial": "0_OF_1",
        "v4_remains_terminal": True,
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "v4_disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "strace_return_value_grammar_defect": "YES", "syscall_family_dispatch_order_defect": "YES",
        "missing_runtime_result": "PARSER_ABORT_CONSEQUENCE_NOT_RUNTIME_PASS_OR_FAILURE_PROOF",
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "successor_decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V5_CONDITIONALLY",
        "pass_locked_governance_pending_validation_and_freeze": True,
    })
    print(json.dumps({"status": "GOVERNANCE_BASE_ARTIFACTS_CREATED", "termination_events": len(events), "v5_created": False}, sort_keys=True))


if __name__ == "__main__":
    main()
