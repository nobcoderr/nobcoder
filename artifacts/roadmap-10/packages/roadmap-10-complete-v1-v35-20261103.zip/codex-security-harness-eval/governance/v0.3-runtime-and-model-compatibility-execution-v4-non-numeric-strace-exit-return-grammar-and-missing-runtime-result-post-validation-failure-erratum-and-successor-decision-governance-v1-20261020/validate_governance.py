#!/usr/bin/env python3
"""Primary, negative, independent, and freeze validation for the governance package."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import stat
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v3-non-path-pipe-payload-misclassification-post-validation-failure-erratum-and-successor-decision-governance-v1-20261018")
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
V5 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v5-20261020")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4_NON_NUMERIC_STRACE_EXIT_RETURN_GRAMMAR_AND_MISSING_RUNTIME_RESULT_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V5_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5"
V5_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V6"

SCRIPTS = {"build_governance.py", "validate_governance.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V4_FROZEN_EVIDENCE_BINDING.json", "V4_TERMINAL_DISPOSITION.json",
    "TRACE_TERMINATION_EVENT_INVENTORY.json", "STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json",
    "SYSCALL_FAMILY_DISPATCH_DECISION.json", "MISSING_RUNTIME_RESULT_ADJUDICATION.json",
    "POST_VALIDATION_INCOMPLETENESS_DECISION.json", "CAUSAL_OWNERSHIP_ADJUDICATION.json",
    "SUCCESSOR_V5_REQUIREMENTS.json", "SUCCESSOR_V5_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEXT_LEGAL_MILESTONE.json",
    "GOVERNANCE_DECISION_SUMMARY.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def canonical_root(rows: list[dict[str, Any]]) -> str:
    data = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(data.encode()).hexdigest()


def check_collector() -> tuple[list[dict[str, Any]], Callable[[str, bool, Any], None]]:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    return checks, check


def primary_checks() -> list[dict[str, Any]]:
    checks, check = check_collector()
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    allowed = SCRIPTS | BASE
    check("P001_ROOT", ROOT.is_dir() and not ROOT.is_symlink())
    check("P002_FILE_SET", actual == allowed, {"actual": len(actual), "expected": len(allowed)})
    check("P003_NO_SYMLINKS", all(not path.is_symlink() for path in ROOT.iterdir()))
    check("P004_V4_EXISTS", V4.is_dir() and not V4.is_symlink())
    check("P005_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    for name in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / name).read_text(encoding="utf-8")); okay = True
        except Exception:
            okay = False
        check(f"P_SYNTAX_{name}", okay)
    check("P006_JSON_PARSE", all(isinstance(load(name), dict) for name in BASE))
    check("P007_IDENTITY", all(load(name).get("governance_identity") == IDENTITY for name in BASE))
    check("P008_PRED_LOCK", sha(PRED / "GOVERNANCE_LOCK.json") == "832db854d1f6fbdb596a9da9e171d8d223de8fcf5587b982fd1a8778a6e86eb0")
    check("P009_PRED_MANIFEST", sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "3a1e96a443f30b0f329db760587e5d56fc78a096f9a729a60661fc9596a7f120")
    fixed = {
        "STATIC_SOURCE_MANIFEST.json": "8f24fddb5891e1acdb909dd7f2b31f6e1a19451081ca3819c823343b2317602c",
        "STATIC_EXECUTION_LOCK.json": "4be5265022687561f0756f18b0ac400e783c2e2d2cc3b85aa343afedeb2ba2f0",
        "STATIC_EXECUTION_LOCK_VERIFICATION.json": "2d92ca09e48714f9eb4ea0b4fd4b2938f82c75beafd4d64dc20e1091121fc45e",
        "static-run-v1/ATTEMPT_MARKER.json": "f4c89039ce9832dbb491903be91c7879b9ebd3fe6ca684819e616353dca739e0",
        "static-run-v1/RUNNER_TERMINAL_FAILURE_RECORD.json": "8c592167d1a5d85708cda564f7ac152b2f46c55300e7b2989de34d051cfa1fed",
        "static-run-v1/independent-post-validation-0001.json": "68b3cb1bf0c0c5f5b4934f17870659c338748412b34bea77397e4d099d649909",
        "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json": "80d700f0c4cf291dfa88f5c6e445f9ad599771088854d9b5eaba7fa13aa2423d",
        "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json": "6f4c1a6abc5f499322ba878f4b2de79ff861127d315e138e3a54126bf419eebc",
    }
    for index, (name, digest) in enumerate(fixed.items(), 10):
        check(f"P{index:03d}_V4_{Path(name).name}", sha(V4 / name) == digest)
    check("P018_V4_READ_ONLY", all((path.stat().st_mode & 0o222) == 0 for path in V4.rglob("*") if path.is_file()))
    binding = load("V4_FROZEN_EVIDENCE_BINDING.json")
    check("P019_SOURCE_ROOT", binding["canonical_source_root_sha256"] == "43e9dfd2968554eae1aef9f756b05083b5fb3604246acea6b24d97fb7615067f")
    check("P020_EVIDENCE_ROOT", binding["canonical_evidence_root_sha256"] == "64a40476e75feab3e6e02561588ba17cfe5f366412c73fffd4e577a2c56918da")
    check("P021_SOURCE_MEMBERS", binding["source_member_count"] == 23)
    check("P022_EVIDENCE_MEMBERS", binding["evidence_member_count"] == 18)
    terminal = load("V4_TERMINAL_DISPOSITION.json")
    check("P023_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("P024_CONSUMED", terminal["attempt_count"] == 1 and terminal["codex_cli_invocation_count"] == 1)
    check("P025_NO_CONTINUATION", all(terminal[key] == "PROHIBITED" for key in ("patch", "relock", "revalidation", "retry", "promotion")))
    check("P026_MISSING_RESULT", terminal["runtime_result"] == "NOT_EMITTED")
    check("P027_NOT_COMPATIBLE", terminal["compatibility"] == "NOT_ESTABLISHED")
    check("P028_NOT_CONFINED", terminal["confinement"] == "NOT_PROVEN")
    inventory = load("TRACE_TERMINATION_EVENT_INVENTORY.json")
    check("P029_EVENT_COUNT", inventory["event_count"] == len(inventory["events"]) == 14)
    check("P030_EVENT_FAMILIES", {row["syscall"] for row in inventory["events"]} == {"exit", "exit_group"})
    check("P031_EVENT_TOKEN", all(row["return_token"] == "?" and row["typed_event"] == "NON_RETURNING_TERMINATION_EVENT" for row in inventory["events"]))
    grammar = load("STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json")
    check("P032_GRAMMAR_DEFECT", grammar["strace_return_value_grammar_defect"] == "YES")
    check("P033_DEFECT_VERDICT", grammar["verdict"] == "CONFIRMED_NUMERIC_RETURN_PARSE_PRECEDED_SYSCALL_FAMILY_DISPATCH")
    check("P034_SCOPE_LIMIT", grammar["accepted_only_for_family"] == "NON_RETURNING_PROCESS_TERMINATION")
    dispatch = load("SYSCALL_FAMILY_DISPATCH_DECISION.json")
    check("P035_ORDER", dispatch["required_order"][1:3] == ["CLASSIFY_SYSCALL_FAMILY", "APPLY_FAMILY_SPECIFIC_RETURN_GRAMMAR"])
    check("P036_PROHIBITED_ORDER", dispatch["prohibited_order"] == ["PARSE_ALL_RETURN_VALUES_AS_NUMERIC", "THEN_CLASSIFY_SYSCALL"])
    check("P037_UNKNOWN_FAILS", dispatch["unknown_or_ambiguous_family_policy"] == "FAIL_CLOSED_WITH_DIAGNOSTIC_RECORD")
    missing = load("MISSING_RUNTIME_RESULT_ADJUDICATION.json")
    check("P038_RESULT_ABSENT", missing["status"] == "NOT_EMITTED")
    check("P039_ABORT_CONSEQUENCE", missing["causal_classification"] == "CONSEQUENCE_OF_POST_RUNTIME_PRIMARY_TRACE_PARSER_ABORT")
    check("P040_NO_OUTCOME_INFERENCE", missing["runtime_pass_inferred"] is False and missing["runtime_failure_inferred"] is False)
    check("P041_NO_RECONSTRUCTION", missing["no_reconstruction"] is True)
    post = load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")
    check("P042_POST_INCOMPLETE", post["completed"] is False and post["locked_post_status"] == "INCOMPLETE")
    check("P043_NO_PROMOTION", post["partial_passes_do_not_promote"] is True and post["pass_locked_compatibility_issued"] is False)
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    check("P044_OWNERSHIP", ownership["ownership_defect"] == "POST_RUNTIME_PRIMARY_TRACE_PARSER_CONTRACT_DEFECT")
    check("P045_NO_RUNTIME_DEFECT_CLAIM", ownership["codex_runtime_defect"] == ownership["runtime_compatibility_defect"] == "NOT_PROVEN")
    successor = load("SUCCESSOR_V5_AUTHORIZATION_DECISION.json")
    check("P046_SUCCESSOR", successor["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V5_CONDITIONALLY")
    check("P047_V5_ID", successor["successor_execution_identity"] == V5_EXECUTION and successor["successor_suite_identity"] == V5_SUITE)
    check("P048_V5_ZERO", successor["attempt_count"] == successor["codex_invocation_count"] == 0)
    check("P049_V5_LIMIT", successor["attempt_limit"] == successor["codex_invocation_limit"] == 1)
    check("P050_V5_NOT_CREATED", successor["creation_or_execution_this_milestone"] is False and not V5.exists())
    requirements = load("SUCCESSOR_V5_REQUIREMENTS.json")["mandatory_requirements"]
    for index, requirement in enumerate((
        "SYSCALL_TYPE_DISPATCH_BEFORE_RETURN_PARSE", "EXPLICIT_NON_NUMERIC_EXIT_RETURN_GRAMMAR",
        "TYPED_EXIT_AND_EXIT_GROUP_TERMINATION_EVENTS", "RUNTIME_RESULT_DIAGNOSTIC_COMPLETENESS",
        "SEMANTIC_EXECVE_LINEAGE_CLASSIFICATION", "NAMESPACE_SETUP_WRITE_PROOF",
        "SEMANTIC_SYSCALL_PATH_CLASSIFICATION", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE",
        "DEDICATED_CONFIG_CONSUMPTION_PROOF", "STATIC_LOCK_BEFORE_ATTEMPT",
        "INDEPENDENT_POST_VALIDATION", "EVIDENCE_FREEZE", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ), 51):
        check(f"P{index:03d}_REQ_{requirement}", requirement in requirements)
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    check("P064_GOVERNANCE_ONLY", authority["governance_only"] is True)
    check("P065_NO_INVOCATION", authority["runtime_invoked_this_milestone"] is False and authority["codex_invoked_this_milestone"] is False)
    check("P066_ZERO_OPS", all(value == 0 for value in authority["governance_operation_counters"].values()))
    check("P067_NO_SUBAGENTS", load("ROUTING_LEDGER.json")["subagents_used"] is False)
    check("P068_MATRIX_COUNT", load("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")["fixture_count"] == 30)
    check("P069_NEXT", load("NEXT_LEGAL_MILESTONE.json")["successor_execution_identity"] == V5_EXECUTION)
    check("P070_SUMMARY", load("GOVERNANCE_DECISION_SUMMARY.json")["successor_decision"] == successor["decision"])
    return checks


LINE_RE = re.compile(r"^(?P<name>[A-Za-z0-9_]+)\((?P<args>.*)\)\s+=\s+(?P<result>.+)$")


def independent_typed_parse(line: str) -> str:
    match = LINE_RE.match(line)
    if not match:
        return "REJECT_SYNTAX"
    name, args, result = match.group("name"), match.group("args"), match.group("result")
    if name in {"exit", "exit_group"}:
        if not re.fullmatch(r"-?[0-9]+", args):
            return "REJECT_ARGUMENT_GRAMMAR"
        return "TYPED_TERMINATION" if result == "?" else "REJECT_RETURN_GRAMMAR"
    if name not in {"execve", "openat"}:
        return "REJECT_UNKNOWN_FAMILY"
    return "TYPED_NUMERIC_RETURN" if re.match(r"^-?[0-9]+(?:\s|$)", result) else "REJECT_RETURN_GRAMMAR"


def negative_results() -> list[dict[str, Any]]:
    matrix = load("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    expected_ids = [f"N{i:03d}" for i in range(1, 31)]
    if [row["id"] for row in matrix["fixtures"]] != expected_ids:
        raise SystemExit("negative fixture identity/order mismatch")
    samples = {
        "N001": (independent_typed_parse("exit_group(0) = ?") == "TYPED_TERMINATION"),
        "N002": (independent_typed_parse("exit(0) = ?") == "TYPED_TERMINATION"),
        "N003": (independent_typed_parse("exit_group(7) = ?") == "TYPED_TERMINATION"),
        "N004": (independent_typed_parse('execve("/x", ["x"], 0x0) = 0') == "TYPED_NUMERIC_RETURN"),
        "N005": (independent_typed_parse('openat(AT_FDCWD, "/x", O_RDONLY) = 3') == "TYPED_NUMERIC_RETURN"),
        "N006": (independent_typed_parse('openat(AT_FDCWD, "/x", O_RDONLY) = ?') == "REJECT_RETURN_GRAMMAR"),
        "N007": (independent_typed_parse('execve("/x", ["x"], 0x0) = ?') == "REJECT_RETURN_GRAMMAR"),
        "N008": (independent_typed_parse("mystery() = ?") == "REJECT_UNKNOWN_FAMILY"),
        "N009": (independent_typed_parse("exit() = ?") == "REJECT_ARGUMENT_GRAMMAR"),
        "N010": (independent_typed_parse("exit_group(x) = ?") == "REJECT_ARGUMENT_GRAMMAR"),
        "N011": (independent_typed_parse("exit_group(0) = success") == "REJECT_RETURN_GRAMMAR"),
    }
    grammar = load("STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json")
    terminal = load("V4_TERMINAL_DISPOSITION.json")
    missing = load("MISSING_RUNTIME_RESULT_ADJUDICATION.json")
    post = load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")
    successor = load("SUCCESSOR_V5_AUTHORIZATION_DECISION.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    requirements = load("SUCCESSOR_V5_REQUIREMENTS.json")["mandatory_requirements"]
    samples.update({
        "N012": grammar["verdict"] == "CONFIRMED_NUMERIC_RETURN_PARSE_PRECEDED_SYSCALL_FAMILY_DISPATCH",
        "N013": missing["runtime_pass_inferred"] is False,
        "N014": missing["runtime_failure_inferred"] is False,
        "N015": post["compatibility"] == "NOT_ESTABLISHED",
        "N016": post["confinement"] == "NOT_PROVEN",
        "N017": terminal["patch"] == "PROHIBITED",
        "N018": terminal["retry"] == "PROHIBITED" and terminal["attempt_count"] == 1,
        "N019": successor["creation_or_execution_this_milestone"] is False and not V5.exists(),
        "N020": authority["codex_invoked_this_milestone"] is False,
        "N021": "worker" in authority["supported_but_deferred"],
        "N022": all(item in authority["supported_but_deferred"] for item in ("target_access", "external_network")),
        "N023": "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE" in requirements,
        "N024": load("SYSCALL_FAMILY_DISPATCH_DECISION.json")["unknown_or_ambiguous_family_policy"].startswith("FAIL_CLOSED"),
        "N025": "RUNTIME_RESULT_DIAGNOSTIC_COMPLETENESS" in requirements,
        "N026": missing["no_reconstruction"] is True,
        "N027": successor["successor_execution_identity"] != terminal["execution_identity"],
        "N028": "STATIC_LOCK_BEFORE_ATTEMPT" in requirements,
        "N029": successor["attempt_limit"] == 1,
        "N030": successor["separate_acceptance_required"] is True,
    })
    return [{"fixture_id": row["id"], "expected": row["expected"], "status": "PASS" if samples[row["id"]] else "FAIL"} for row in matrix["fixtures"]]


def independent_checks() -> list[dict[str, Any]]:
    checks, check = check_collector()
    terminal_path = V4 / "static-run-v1/RUNNER_TERMINAL_FAILURE_RECORD.json"
    post_path = V4 / "static-run-v1/independent-post-validation-0001.json"
    parser_path = V4 / "src/compatibility_v4.py"
    runner_path = V4 / "src/runner_v4.py"
    terminal = json.loads(terminal_path.read_text())
    post = json.loads(post_path.read_text())
    parser = parser_path.read_text()
    runner = runner_path.read_text()
    check("I001_V4_IMMUTABLE", all((path.stat().st_mode & 0o222) == 0 for path in V4.rglob("*") if path.is_file()))
    check("I002_TERMINAL_HASH", sha(terminal_path) == "8c592167d1a5d85708cda564f7ac152b2f46c55300e7b2989de34d051cfa1fed")
    check("I003_POST_HASH", sha(post_path) == "68b3cb1bf0c0c5f5b4934f17870659c338748412b34bea77397e4d099d649909")
    check("I004_TERMINAL_STAGE", terminal["failure"]["stage"] == "POST_RUNTIME_PRIMARY_TRACE_CLASSIFICATION")
    check("I005_TERMINAL_MESSAGE", terminal["failure"]["message"] == "ambiguous syscall return value")
    check("I006_RESULT_ABSENT", not (V4 / "static-run-v1/runtime-result-0001.json").exists())
    check("I007_POST_INCOMPLETE", post["status"] == "INCOMPLETE" and post["validation_counts"] == {"total": 4, "passed": 2, "failed": 2})
    numeric_position = parser.index('rc = re.match(r"^-?[0-9]+", result)')
    exec_filter_position = parser.index('if event is None or event.name != "execve":')
    call_position = parser.index("event = parse_syscall_line(line)", parser.index("def parse_execve_events"))
    check("I008_NUMERIC_PARSE_PRESENT", numeric_position >= 0)
    check("I009_EXEC_FILTER_AFTER_PARSE_CALL", call_position < exec_filter_position)
    check("I010_RUNTIME_RESULT_AFTER_CLASSIFIER", runner.index("codex_count = successful_codex_exec_count(traces)") < runner.index('append_only_json(STATIC_RUN / "runtime-result-0001.json"'))
    inventory = load("TRACE_TERMINATION_EVENT_INVENTORY.json")
    for index, row in enumerate(inventory["events"], 11):
        path = V4 / "static-run-v1" / row["trace"]
        lines = path.read_text(errors="replace").splitlines()
        actual = lines[row["line_number"] - 1]
        check(f"I{index:03d}_TRACE_ANCHOR", actual == row["line"] and hashlib.sha256((actual + "\n").encode()).hexdigest() == row["line_sha256"])
    check("I025_ALL_TERMINATION_TYPED", all(independent_typed_parse(row["line"].strip()) == "TYPED_TERMINATION" for row in inventory["events"]))
    grammar = load("STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json")
    check("I026_NARROW_GRAMMAR", grammar["scope_limit"].startswith("DOES_NOT_AUTHORIZE"))
    check("I027_NO_COMPAT", load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")["compatibility"] == "NOT_ESTABLISHED")
    check("I028_NO_CONFINEMENT", load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")["confinement"] == "NOT_PROVEN")
    check("I029_OWNERSHIP", load("CAUSAL_OWNERSHIP_ADJUDICATION.json")["ownership_defect"] == "POST_RUNTIME_PRIMARY_TRACE_PARSER_CONTRACT_DEFECT")
    successor = load("SUCCESSOR_V5_AUTHORIZATION_DECISION.json")
    check("I030_V5_CONDITIONAL", successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I031_V5_ABSENT", not V5.exists())
    check("I032_NO_RUNTIME", load("AUTHORITY_NON_ESCALATION_DECISION.json")["runtime_invoked_this_milestone"] is False)
    check("I033_ZERO_OPS", all(value == 0 for value in load("AUTHORITY_NON_ESCALATION_DECISION.json")["governance_operation_counters"].values()))
    check("I034_NEGATIVE_DESIGN", load("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")["fixture_count"] == 30)
    return checks


def emit_result(name: str, record_type: str, rows: list[dict[str, Any]], count_prefix: str) -> None:
    failed = [row for row in rows if row["status"] == "FAIL"]
    write(name, {
        "record_type": record_type, "schema_version": "1.0", "run_id": name.removesuffix(".json"),
        "status": "PASS" if not failed else "FAIL_CLOSED",
        f"{count_prefix}_total": len(rows), f"{count_prefix}_passed": len(rows) - len(failed), f"{count_prefix}_failed": len(failed),
        "checks" if count_prefix == "checks" else "results": rows,
        "operation_counters": {key: 0 for key in load("AUTHORITY_NON_ESCALATION_DECISION.json")["governance_operation_counters"]},
    })
    print(json.dumps({"status": "PASS" if not failed else "FAIL_CLOSED", "total": len(rows), "passed": len(rows) - len(failed), "failed": len(failed)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


def freeze_checks(final: bool) -> list[dict[str, Any]]:
    checks, check = check_collector()
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    candidate = SCRIPTS | BASE | RESULTS
    check("F001_ROOT", ROOT.is_dir() and not ROOT.is_symlink())
    check("F002_V4_READ_ONLY", all((path.stat().st_mode & 0o222) == 0 for path in V4.rglob("*") if path.is_file()))
    check("F003_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    check("F004_NO_SYMLINKS", all(not path.is_symlink() for path in ROOT.iterdir()))
    check("F005_FILE_SET", actual == (candidate | ({FREEZE, "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"} if final else set())), {"actual": len(actual), "expected": len(candidate) + (3 if final else 0)})
    for name in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / name).read_text()); okay = True
        except Exception:
            okay = False
        check(f"F_SYNTAX_{name}", okay)
    check("F006_JSON", all(isinstance(load(name), dict) for name in BASE | RESULTS))
    check("F007_IDENTITY", all(load(name).get("governance_identity") == IDENTITY for name in BASE | RESULTS))
    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F008_PRIMARY", primary["status"] == "PASS" and primary["checks_total"] == primary["checks_passed"] and primary["checks_failed"] == 0)
    check("F009_NEGATIVE", negative["status"] == "PASS" and negative["tests_total"] == negative["tests_passed"] == 30 and negative["tests_failed"] == 0)
    check("F010_INDEPENDENT", independent["status"] == "PASS" and independent["checks_total"] == independent["checks_passed"] and independent["checks_failed"] == 0)
    check("F011_TERMINAL", load("V4_TERMINAL_DISPOSITION.json")["disposition"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("F012_DEFECT", load("STRACE_RETURN_VALUE_GRAMMAR_ADJUDICATION.json")["strace_return_value_grammar_defect"] == "YES")
    check("F013_MISSING", load("MISSING_RUNTIME_RESULT_ADJUDICATION.json")["status"] == "NOT_EMITTED")
    check("F014_NOT_COMPAT", load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")["compatibility"] == "NOT_ESTABLISHED")
    check("F015_NOT_CONFINED", load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")["confinement"] == "NOT_PROVEN")
    check("F016_SUCCESSOR", load("SUCCESSOR_V5_AUTHORIZATION_DECISION.json")["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V5_CONDITIONALLY")
    check("F017_ZERO_OPS", all(value == 0 for value in load("AUTHORITY_NON_ESCALATION_DECISION.json")["governance_operation_counters"].values()))
    if final:
        manifest = load("GOVERNANCE_ARTIFACT_MANIFEST.json")
        lock = load("GOVERNANCE_LOCK.json")
        freeze = load(FREEZE)
        members = manifest["members"]
        check("F018_FREEZE_RESULT", freeze["status"] == "PASS" and freeze["checks_total"] == freeze["checks_passed"] and freeze["checks_failed"] == 0)
        check("F019_MEMBER_COUNT", manifest["member_count"] == len(members))
        check("F020_MEMBER_HASHES", all((ROOT / row["path"]).is_file() and sha(ROOT / row["path"]) == row["sha256"] and (ROOT / row["path"]).stat().st_size == row["bytes"] for row in members))
        member_root = canonical_root(members)
        check("F021_MEMBER_ROOT", member_root == manifest["canonical_member_root_sha256"] == lock["canonical_member_root_sha256"])
        manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
        check("F022_MANIFEST_SHA", manifest_sha == lock["governance_manifest_sha256"])
        artifact_root = canonical_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
        check("F023_ARTIFACT_ROOT", artifact_root == lock["canonical_artifact_root_sha256"])
        check("F024_LOCK", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY" and lock["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V5_CONDITIONALLY")
        check("F025_LOCK_V4", lock["v4_disposition"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
        check("F026_LOCK_DEFECT", lock["strace_return_value_grammar_defect"] == "YES")
        check("F027_LOCK_MISSING", lock["runtime_result"] == "NOT_EMITTED")
        check("F028_LOCK_NO_PROMOTION", lock["compatibility"] == "NOT_ESTABLISHED" and lock["confinement"] == "NOT_PROVEN")
        check("F029_LOCK_V5", lock["v5_state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_AT_FREEZE")
        check("F030_LOCK_ZERO", all(value == 0 for value in lock["operation_counters"].values()))
        check("F031_FILES_READ_ONLY", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()))
        check("F032_ROOT_READ_ONLY", stat.S_IMODE(ROOT.stat().st_mode) == 0o555)
    return checks


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["primary", "negative", "independent", "freeze-candidate", "final"])
    args = parser.parse_args()
    if args.mode == "primary":
        emit_result("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_GOVERNANCE_VALIDATION_RESULT", primary_checks(), "checks")
    elif args.mode == "negative":
        emit_result("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT", negative_results(), "tests")
    elif args.mode == "independent":
        emit_result("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json", "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_INDEPENDENT_VALIDATION_RESULT", independent_checks(), "checks")
    else:
        final = args.mode == "final"
        rows = freeze_checks(final)
        failed = [row for row in rows if row["status"] == "FAIL"]
        payload = {
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_V4_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT",
            "schema_version": "1.0", "run_id": "FINAL_READ_ONLY_FREEZE_VERIFICATION" if final else "FINAL_FREEZE_VERIFICATION_RUN-0001",
            "phase": "FINAL_READ_ONLY" if final else "FINAL_FREEZE_CANDIDATE", "status": "PASS" if not failed else "FAIL_CLOSED",
            "checks_total": len(rows), "checks_passed": len(rows) - len(failed), "checks_failed": len(failed), "checks": rows,
            "operation_counters": load("AUTHORITY_NON_ESCALATION_DECISION.json")["governance_operation_counters"],
        }
        if not final:
            write(FREEZE, payload)
        summary = {key: payload[key] for key in ("phase", "status", "checks_total", "checks_passed", "checks_failed")}
        if final and not failed:
            lock = load("GOVERNANCE_LOCK.json")
            summary.update(governance_lock_sha256=sha(ROOT / "GOVERNANCE_LOCK.json"), governance_manifest_sha256=sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"), canonical_artifact_root_sha256=lock["canonical_artifact_root_sha256"])
        print(json.dumps(summary, sort_keys=True))
        if failed:
            raise SystemExit(1)


if __name__ == "__main__":
    main()
