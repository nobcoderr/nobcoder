#!/usr/bin/env python3
"""Independent evidence and authority validation for the V11 erratum."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_"
    "INDEPENDENT_VALIDATOR_SOURCE_ORDER_ANCHOR_DEFECT_PRELOCK_ERRATUM_"
    "AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "CONTINUATION_V11_VALIDATOR_ONLY_CORRECTION_AUTHORIZED"
EXPECTED_BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json",
    "V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", "V11_PRELOCK_EVIDENCE_BINDING.json",
    "V11_PRELOCK_DISPOSITION.json", "SOURCE_ORDER_EVIDENCE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "CONTINUATION_V11_AUTHORIZATION_DECISION.json",
    "CONTINUATION_V11_SCOPE_LOCK.json", "VALIDATOR_CORRECTION_REQUIREMENTS.json",
    "V11_CONTINUATION_REGRESSION_MATRIX.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "GOVERNANCE_VALIDATION_RESULT_RUN-0002.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json",
    "GOVERNANCE_VALIDATION_RESULT_RUN-0003.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0003.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def emit(payload: dict[str, Any]) -> None:
    destination = ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0002.json"
    if os.path.lexists(destination):
        raise RuntimeError("refusing to overwrite independent validation result")
    with destination.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def current_snapshot() -> tuple[list[dict[str, Any]], str]:
    rows = [
        {"path": item.relative_to(V11).as_posix(), "bytes": item.stat().st_size, "sha256": digest(item)}
        for item in sorted(node for node in V11.rglob("*") if node.is_file())
    ]
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in rows).encode("utf-8")
    return rows, hashlib.sha256(material).hexdigest()


def dotted(node: ast.AST) -> str:
    parts: list[str] = []
    cursor = node
    while isinstance(cursor, ast.Attribute):
        parts.append(cursor.attr)
        cursor = cursor.value
    if isinstance(cursor, ast.Name):
        parts.append(cursor.id)
    return ".".join(reversed(parts))


def attempt_operand(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.BinOp)
        and isinstance(node.op, ast.Div)
        and isinstance(node.left, ast.Name)
        and node.left.id == "STATIC_RUN"
        and isinstance(node.right, ast.Constant)
        and node.right.value == "ATTEMPT_MARKER.json"
    )


def independent_source_facts() -> dict[str, Any]:
    runner_text = (V11 / "src/runner_v11.py").read_text(encoding="utf-8")
    runner_tree = ast.parse(runner_text)
    start: list[int] = []
    readiness: list[int] = []
    creation: list[int] = []
    non_creation_check: list[int] = []
    for node in ast.walk(runner_tree):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id == "observer_process" and isinstance(node.value, ast.Call) and dotted(node.value.func) == "subprocess.Popen":
                start.append(node.lineno)
            if node.targets[0].id == "observer_ready" and isinstance(node.value, ast.Call) and dotted(node.value.func) == "wait_for_json":
                args = node.value.args
                if len(args) >= 2 and isinstance(args[0], ast.Name) and args[0].id == "OBSERVER_READY" and isinstance(args[1], ast.Constant) and args[1].value == "OBSERVER_READY":
                    readiness.append(node.lineno)
        if isinstance(node, ast.Call) and dotted(node.func) == "append_only_json" and node.args and attempt_operand(node.args[0]):
            creation.append(node.lineno)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "exists" and attempt_operand(node.func.value):
            non_creation_check.append(node.lineno)

    validator_text = (V11 / "validators/independent_static_validate.py").read_text(encoding="utf-8")
    validator_tree = ast.parse(validator_text)
    raw_marker_indexes: list[int] = []
    for node in ast.walk(validator_tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "index"
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "runner_source"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Constant)
            and node.args[0].value == 'STATIC_RUN / "ATTEMPT_MARKER.json"'
        ):
            raw_marker_indexes.append(node.lineno)
    return {
        "start": sorted(start), "readiness": sorted(readiness),
        "creation": sorted(creation), "non_creation_check": sorted(non_creation_check),
        "raw_marker_index_calls": sorted(raw_marker_indexes),
    }


def main() -> None:
    expected = EXPECTED_BASE | SCRIPTS | RESULTS
    actual = {item.name for item in ROOT.iterdir() if item.is_file()}
    if actual != expected or any(item.is_dir() or item.is_symlink() for item in ROOT.iterdir()):
        raise SystemExit(f"independent validator input set mismatch: {sorted(actual)}")

    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    historical_independent = load("INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    check(
        "I000_HISTORICAL_INDEPENDENT_FAILURE_PRESERVED",
        historical_independent["status"] == "FAIL_CLOSED"
        and historical_independent["checks_passed"] == 48
        and historical_independent["checks_total"] == 50
        and historical_independent["checks_failed"] == 2,
    )

    rows, root_digest = current_snapshot()
    snapshot = load("V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json")
    check("I001_V11_SNAPSHOT", rows == snapshot["members"] and len(rows) == snapshot["member_count"] == 52)
    check("I002_V11_ROOT", root_digest == snapshot["canonical_tree_root_sha256"], root_digest)
    check("I003_V12_ABSENT", not V12.exists() and not V12.is_symlink())
    check("I004_NO_STATIC_LOCK", not (V11 / "STATIC_EXECUTION_LOCK.json").exists())
    check("I005_NO_PREFLIGHT", not (V11 / "results/prelock/fresh-preflight-run-0001.json").exists())
    check("I006_NO_ATTEMPT", not (V11 / "static-run-v11/ATTEMPT_MARKER.json").exists())
    check("I007_STATIC_RUN_EMPTY", not any((V11 / "static-run-v11").iterdir()))

    unit = json.loads((V11 / "results/prelock/unit-fixtures-run-0001.json").read_text(encoding="utf-8"))
    primary_static = json.loads((V11 / "results/prelock/primary-static-validation-run-0001.json").read_text(encoding="utf-8"))
    independent_static = json.loads((V11 / "results/prelock/independent-static-validation-run-0001.json").read_text(encoding="utf-8"))
    failed = [row for row in independent_static["checks"] if row["status"] == "FAIL"]
    check("I008_UNIT", (unit["status"], unit["checks_passed"], unit["checks_total"]) == ("PASS", 126, 126))
    check("I009_PRIMARY", (primary_static["status"], primary_static["checks_passed"], primary_static["checks_total"]) == ("PASS", 134, 134))
    check("I010_INDEPENDENT", (independent_static["status"], independent_static["checks_passed"], independent_static["checks_total"]) == ("FAIL_CLOSED", 94, 95))
    check("I011_I065_ONLY", len(failed) == 1 and failed[0].get("check_id") == "I065_OBSERVER_READY_BEFORE_ATTEMPT_SOURCE_ORDER")

    facts = independent_source_facts()
    check("I012_TYPED_START", facts["start"] == [359], facts)
    check("I013_TYPED_READY", facts["readiness"] == [367], facts)
    check("I014_TYPED_CREATE", facts["creation"] == [398], facts)
    check("I015_TYPED_ORDER", facts["start"][0] < facts["readiness"][0] < facts["creation"][0])
    check("I016_CHECK_SEPARATE", facts["non_creation_check"] == [295] and facts["non_creation_check"][0] < facts["start"][0])
    check("I017_DEFECTIVE_INDEX", facts["raw_marker_index_calls"] == [693])

    adjudication = load("SOURCE_ORDER_EVIDENCE_ADJUDICATION.json")
    ownership = load("DEFECT_OWNERSHIP_DECISION.json")
    check("I018_ADJUDICATION_MATCHES_INDEPENDENT_FACTS", adjudication["semantic_anchors"] == {
        "attempt_marker_creation_lines": facts["creation"],
        "attempt_marker_non_creation_reference_lines": facts["non_creation_check"],
        "observer_readiness_proof_lines": facts["readiness"],
        "observer_start_lines": facts["start"],
        "semantic_order_pass": True,
    })
    check("I019_DEFECT_OWNER", ownership["independent_validator_source_order_anchor_defect"] == "YES")
    check("I020_IMPLEMENTATION_NOT_DEFECTIVE", ownership["observer_ready_before_attempt_implementation_defect"] == "NO_BASED_ON_STATIC_SOURCE_ORDER_EVIDENCE")
    check("I021_NO_RUNTIME_PROMOTION", ownership["temporal_observer_runtime_defect"] == "NOT_ESTABLISHED_EXECUTION_NOT_STARTED" and adjudication["runtime_temporal_observer_pass"] == "NOT_ESTABLISHED_NO_EXECUTION")

    disposition = load("V11_PRELOCK_DISPOSITION.json")
    check("I022_DISPOSITION", disposition["disposition"] == "FAIL_CLOSED_DURING_INDEPENDENT_VALIDATION_PRELOCK")
    check("I023_ZERO", disposition["attempt"] == "0_OF_1_NOT_CONSUMED" and disposition["worker_invocation"] == disposition["codex_as_worker_invocation"] == "0_OF_1")
    check("I024_FAILURE_EVIDENCE_REFERENCE", disposition["failure_evidence"] == "IMMUTABLE_REFERENCE")

    decision = load("CONTINUATION_V11_AUTHORIZATION_DECISION.json")
    scope = load("CONTINUATION_V11_SCOPE_LOCK.json")
    check("I025_DECISION", decision["decision"] == DECISION)
    check("I026_CONTINUATION_SCOPED", decision["continuation_v11"] == "AUTHORIZED_ONLY_UNDER_CONTINUATION_SCOPE_LOCK")
    check("I027_NO_V12", decision["fresh_v12"] == "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I028_ALLOWLIST", set(scope["mutable_allowlist"]) == {"validators/independent_static_validate.py", "tests/run_unit_fixtures.py"})
    check("I029_RUNNER_PROTECTED", "src/runner_v11.py" in scope["protected_exact_members"] and "RUNNER_EXECUTION_ORDER" in scope["protected_semantics"])
    check("I030_OBSERVER_PROTECTED", "src/topology_observer_v11.py" in scope["protected_exact_members"] and "OBSERVER_IMPLEMENTATION" in scope["protected_semantics"])
    check("I031_FAILED_RESULT_PROTECTED", scope["original_failed_independent_result_mutation"] == "PROHIBITED")

    correction = load("VALIDATOR_CORRECTION_REQUIREMENTS.json")
    check("I032_TYPED_A_B_C", correction["semantic_anchors"] == {"A": "EXACT_OBSERVER_START_OPERATION", "B": "SUCCESSFUL_OBSERVER_READINESS_PROOF", "C": "AUTHORITATIVE_ATTEMPT_MARKER_CREATION_OR_APPEND_ONLY_WRITE"})
    check("I033_ORDER", correction["required_relation"] == "A_LT_B_LT_C")
    check("I034_NO_SUBSTRING", correction["prohibited_implementation"] == "FIRST_FREE_TEXT_OR_SUBSTRING_OCCURRENCE")
    check("I035_FULL_RERUN", correction["full_validation_after_correction"][:3] == ["UNIT_FROM_SCRATCH", "PRIMARY_FROM_SCRATCH", "INDEPENDENT_FROM_SCRATCH"] and correction["reuse_of_94_of_95_as_success"] == "PROHIBITED")

    regression = load("V11_CONTINUATION_REGRESSION_MATRIX.json")
    cases = {row["id"]: row for row in regression["cases"]}
    check("I036_REGRESSIONS", len(cases) == 10 and set(cases) == {f"R{index:03d}" for index in range(1, 11)})
    check("I037_CHECK_REFERENCE_POSITIVE", cases["R002"]["expected"] == "PASS_CHECK_IGNORED_AS_NON_CREATION")
    check("I038_CREATE_BEFORE_READY_NEGATIVE", cases["R004"]["expected"] == "FAIL_CLOSED")
    check("I039_SCOPE_VIOLATION_NEGATIVE", cases["R010"]["expected"] == "DENIED_BY_AUTHORITY")

    historical_primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    historical_negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    intermediate_primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0002.json")
    intermediate_negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    primary_result = load("GOVERNANCE_VALIDATION_RESULT_RUN-0003.json")
    negative_result = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0003.json")
    check("I039A_HISTORICAL_PRIMARY_FAILURE", historical_primary["status"] == "FAIL_CLOSED" and historical_primary["checks_passed"] == 50 and historical_primary["checks_total"] == 52)
    check("I039B_HISTORICAL_NEGATIVE_PASS", historical_negative["status"] == "PASS" and historical_negative["tests_passed"] == historical_negative["tests_total"] == 16)
    check("I039C_INTERMEDIATE_PRIMARY_PASS", intermediate_primary["status"] == "PASS" and intermediate_primary["checks_passed"] == intermediate_primary["checks_total"] == 54)
    check("I039D_INTERMEDIATE_NEGATIVE_PASS", intermediate_negative["status"] == "PASS" and intermediate_negative["tests_passed"] == intermediate_negative["tests_total"] == 16)
    check("I040_PRIMARY_GOV_PASS", primary_result["status"] == "PASS" and primary_result["checks_passed"] == primary_result["checks_total"] and primary_result["checks_failed"] == 0)
    check("I041_NEGATIVE_GOV_PASS", negative_result["status"] == "PASS" and negative_result["tests_passed"] == negative_result["tests_total"] == 16 and negative_result["tests_failed"] == 0)

    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    counters = authority["operation_counters"]
    check("I042_COUNTERS_ZERO", len(counters) == 19 and all(value == 0 for value in counters.values()), counters)
    matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
    denied = set(matrix["not_authorized_this_milestone"])
    check("I043_NO_EXECUTION", {"WORKER_INVOCATION", "CODEX_INVOCATION", "ATTEMPT_CONSUMPTION"}.issubset(denied))
    check("I044_NO_TARGET_OR_AGENT", {"TARGET_ACCESS", "EXTERNAL_NETWORK", "CREDENTIAL_USE", "SUBAGENT", "PARALLELISM"}.issubset(denied))
    check("I045_NO_PROMOTION_OR_SUBMISSION", {"CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION"}.issubset(denied))
    check("I046_NO_PATCH_DURING_GOVERNANCE", "V11_VALIDATOR_PATCH" in denied and "V11_REVALIDATION" in denied)

    summary = load("GOVERNANCE_DECISION_SUMMARY.json")
    next_step = load("NEXT_LEGAL_MILESTONE.json")
    check("I047_SUMMARY", summary["decision"] == DECISION and summary["runtime_observer_pass"] == "NOT_ESTABLISHED")
    check("I048_NEXT", next_step["next_if_pass_locked"].startswith("CORRECT_ONLY_V11_I065") and next_step["v12_may_be_created"] is False)

    failures = [row for row in checks if row["status"] == "FAIL"]
    emit({
        "record_type": "V11_SOURCE_ORDER_ERRATUM_INDEPENDENT_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0",
        "run_id": "INDEPENDENT_GOVERNANCE_VALIDATION_RUN-0002",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failures),
        "checks_failed": len(failures),
        "operation_counters": counters,
    })
    print(json.dumps({"status": "PASS" if not failures else "FAIL_CLOSED", "passed": len(checks) - len(failures), "total": len(checks)}, sort_keys=True))
    if failures:
        raise SystemExit("independent governance validation failed: " + ",".join(row["check_id"] for row in failures))


if __name__ == "__main__":
    main()
