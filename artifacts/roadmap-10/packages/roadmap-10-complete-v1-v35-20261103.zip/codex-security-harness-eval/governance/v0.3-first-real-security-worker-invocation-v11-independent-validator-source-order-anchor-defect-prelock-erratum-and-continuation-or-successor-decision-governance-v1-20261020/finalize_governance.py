#!/usr/bin/env python3
"""Final verification and immutable freeze for the V11 validator-anchor erratum."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_"
    "INDEPENDENT_VALIDATOR_SOURCE_ORDER_ANCHOR_DEFECT_PRELOCK_ERRATUM_"
    "AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "CONTINUATION_V11_VALIDATOR_ONLY_CORRECTION_AUTHORIZED"
NEXT = (
    "CORRECT_ONLY_V11_I065_INDEPENDENT_VALIDATOR_ANCHOR_LOGIC_ADD_SCOPED_"
    "REGRESSIONS_AND_RERUN_FULL_PRELOCK_VALIDATION_CHAIN"
)
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json",
    "V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", "V11_PRELOCK_EVIDENCE_BINDING.json",
    "V11_PRELOCK_DISPOSITION.json", "SOURCE_ORDER_EVIDENCE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "CONTINUATION_V11_AUTHORIZATION_DECISION.json",
    "CONTINUATION_V11_SCOPE_LOCK.json", "VALIDATOR_CORRECTION_REQUIREMENTS.json",
    "V11_CONTINUATION_REGRESSION_MATRIX.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "GOVERNANCE_VALIDATION_RESULT_RUN-0002.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json",
    "GOVERNANCE_VALIDATION_RESULT_RUN-0003.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0003.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0002.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write_once(name: str, payload: dict[str, Any]) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite final governance artifact: {name}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def v11_rows() -> list[dict[str, Any]]:
    return [
        {"path": item.relative_to(V11).as_posix(), "bytes": item.stat().st_size, "sha256": sha256(item)}
        for item in sorted(node for node in V11.rglob("*") if node.is_file())
    ]


def canonical(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda value: value["path"])
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {item.name for item in ROOT.iterdir() if item.is_file()}
    if actual != expected or any(item.is_dir() or item.is_symlink() for item in ROOT.iterdir()):
        raise SystemExit(f"finalizer input set mismatch: {sorted(actual)}")

    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SCRIPT_" + script, valid)

    snapshot = read("V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json")
    rows = v11_rows()
    root_digest = canonical(rows)
    check("F001_V11_UNCHANGED", rows == snapshot["members"] and len(rows) == snapshot["member_count"] == 52)
    check("F002_V11_ROOT", root_digest == snapshot["canonical_tree_root_sha256"], root_digest)
    check("F003_V12_ABSENT", not V12.exists() and not V12.is_symlink())
    check("F004_STATIC_LOCK_ABSENT", not (V11 / "STATIC_EXECUTION_LOCK.json").exists())
    check("F005_PREFLIGHT_ABSENT", not (V11 / "results/prelock/fresh-preflight-run-0001.json").exists())
    check("F006_ATTEMPT_ABSENT", not (V11 / "static-run-v11/ATTEMPT_MARKER.json").exists())
    check("F007_STATIC_RUN_EMPTY", (V11 / "static-run-v11").is_dir() and not any((V11 / "static-run-v11").iterdir()))

    historical_primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    historical_negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    intermediate_primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0002.json")
    intermediate_negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    historical_independent = read("INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0003.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0003.json")
    independent = read("INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0002.json")
    check("F008A_HISTORICAL_PRIMARY_FAILURE", historical_primary["status"] == "FAIL_CLOSED" and historical_primary["checks_passed"] == 50 and historical_primary["checks_total"] == 52)
    check("F008B_HISTORICAL_NEGATIVE_PASS", historical_negative["status"] == "PASS" and historical_negative["tests_passed"] == historical_negative["tests_total"] == 16)
    check("F008C_INTERMEDIATE_PRIMARY_PASS", intermediate_primary["status"] == "PASS" and intermediate_primary["checks_passed"] == intermediate_primary["checks_total"] == 54)
    check("F008D_INTERMEDIATE_NEGATIVE_PASS", intermediate_negative["status"] == "PASS" and intermediate_negative["tests_passed"] == intermediate_negative["tests_total"] == 16)
    check("F008E_HISTORICAL_INDEPENDENT_FAILURE", historical_independent["status"] == "FAIL_CLOSED" and historical_independent["checks_passed"] == 48 and historical_independent["checks_total"] == 50)
    check("F008_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_passed"] == primary["checks_total"] and primary["checks_failed"] == 0)
    check("F009_NEGATIVE_PASS", negative["status"] == "PASS" and negative["tests_passed"] == negative["tests_total"] == 16 and negative["tests_failed"] == 0)
    check("F010_INDEPENDENT_PASS", independent["status"] == "PASS" and independent["checks_passed"] == independent["checks_total"] and independent["checks_failed"] == 0)
    check("F011_RESULT_IDENTITIES", all(result["governance_identity"] == IDENTITY for result in (primary, negative, independent)))

    binding = read("V11_PRELOCK_EVIDENCE_BINDING.json")
    disposition = read("V11_PRELOCK_DISPOSITION.json")
    order = read("SOURCE_ORDER_EVIDENCE_ADJUDICATION.json")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    decision = read("CONTINUATION_V11_AUTHORIZATION_DECISION.json")
    scope = read("CONTINUATION_V11_SCOPE_LOCK.json")
    correction = read("VALIDATOR_CORRECTION_REQUIREMENTS.json")
    regression = read("V11_CONTINUATION_REGRESSION_MATRIX.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    operation_matrix = read("OPERATION_AUTHORIZATION_MATRIX.json")
    summary = read("GOVERNANCE_DECISION_SUMMARY.json")
    next_step = read("NEXT_LEGAL_MILESTONE.json")

    check("F012_BINDING", binding["canonical_tree_root_sha256"] == root_digest and binding["member_count"] == 52)
    check("F013_FAILURE_RESULT_HASH", binding["independent_result"]["sha256"] == sha256(V11 / "results/prelock/independent-static-validation-run-0001.json"))
    check("F014_DISPOSITION", disposition["disposition"] == "FAIL_CLOSED_DURING_INDEPENDENT_VALIDATION_PRELOCK")
    check("F015_COUNTS_ZERO", disposition["attempt"] == "0_OF_1_NOT_CONSUMED" and disposition["worker_invocation"] == disposition["codex_as_worker_invocation"] == "0_OF_1")
    check("F016_NO_RUNTIME", disposition["runtime_observer_proof"] == "NOT_ESTABLISHED_EXECUTION_NOT_STARTED")
    anchors = order["semantic_anchors"]
    check("F017_TYPED_ORDER", anchors["observer_start_lines"] == [359] and anchors["observer_readiness_proof_lines"] == [367] and anchors["attempt_marker_creation_lines"] == [398] and anchors["semantic_order_pass"] is True)
    check("F018_REFERENCE_DISTINCT", anchors["attempt_marker_non_creation_reference_lines"] == [295] and order["non_creation_reference_is_not_creation_event"] is True)
    check("F019_NO_RUNTIME_PROMOTION", order["runtime_temporal_observer_pass"] == "NOT_ESTABLISHED_NO_EXECUTION" and order["confinement"] == "NOT_PROVEN")
    check("F020_OWNERSHIP", ownership["independent_validator_source_order_anchor_defect"] == "YES" and ownership["observer_ready_before_attempt_implementation_defect"] == "NO_BASED_ON_STATIC_SOURCE_ORDER_EVIDENCE")
    check("F021_NO_UNPROVEN_CAUSE", ownership["causal_history"].startswith("ONLY_THE_OBSERVED"))
    check("F022_DECISION", decision["decision"] == DECISION and decision["fresh_v12"] == "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F023_NO_ACTION_THIS_MILESTONE", not decision["current_milestone_performs_correction"] and not decision["current_milestone_performs_revalidation"] and not decision["current_milestone_performs_execution"])
    check("F024_ALLOWLIST", scope["mutable_allowlist"] == ["validators/independent_static_validate.py", "tests/run_unit_fixtures.py"])
    check("F025_PROTECTED_COMPONENTS", {"src/runner_v11.py", "src/topology_observer_v11.py", "contracts/WORKER_REQUEST.json", "fixture/worker-prompt.txt", "runtime-config-candidate/config.toml"}.issubset(set(scope["protected_exact_members"])))
    check("F026_ORIGINAL_RESULT_IMMUTABLE", scope["original_failed_independent_result_mutation"] == "PROHIBITED")
    check("F027_CORRECTION_SEMANTIC", correction["required_relation"] == "A_LT_B_LT_C" and correction["prohibited_implementation"] == "FIRST_FREE_TEXT_OR_SUBSTRING_OCCURRENCE")
    check("F028_FULL_CHAIN", correction["full_validation_after_correction"] == ["UNIT_FROM_SCRATCH", "PRIMARY_FROM_SCRATCH", "INDEPENDENT_FROM_SCRATCH", "FRESH_PREFLIGHT", "COMPLETE_DEPENDENCY_CLOSURE", "STATIC_LOCK", "LOCK_VERIFICATION", "POST_LOCK_PREFLIGHT"])
    check("F029_REGRESSIONS", len(regression["cases"]) == 10 and regression["all_cases_required"] is True)
    counters = authority["operation_counters"]
    check("F030_COUNTERS_ZERO", len(counters) == 19 and all(value == 0 for value in counters.values()), counters)
    denied = set(operation_matrix["not_authorized_this_milestone"])
    check("F031_NO_PATCH_OR_REVALIDATE", {"V11_VALIDATOR_PATCH", "V11_REVALIDATION", "FRESH_PREFLIGHT", "STATIC_LOCK"}.issubset(denied))
    check("F032_NO_EXECUTION", {"ATTEMPT_CONSUMPTION", "WORKER_INVOCATION", "CODEX_INVOCATION"}.issubset(denied))
    check("F033_NO_EXPANSION", {"V12_CREATION", "CREDENTIAL_USE", "TARGET_ACCESS", "EXTERNAL_NETWORK", "SUBAGENT", "PARALLELISM", "EXPLOIT_REPLAY", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION", "DAYBREAK_INVOCATION"}.issubset(denied))
    check("F034_SUMMARY", summary["decision"] == DECISION and summary["runtime_observer_pass"] == "NOT_ESTABLISHED")
    check("F035_NEXT", next_step["next_if_pass_locked"] == NEXT and next_step["full_prelock_validation_chain_must_restart"] is True and next_step["v12_may_be_created"] is False)

    failures = [row for row in checks if row["status"] == "FAIL"]
    if failures:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failures))

    write_once(FREEZE, {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT",
        "schema_version": "1.0",
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001",
        "status": "PASS",
        "checks": checks,
        "checks_total": len(checks),
        "checks_passed": len(checks),
        "checks_failed": 0,
        "v11_workspace_root_sha256": root_digest,
        "v11_member_count": len(rows),
        "v12_absent": True,
        "operation_counters": counters,
        "freeze_precondition": "PRIMARY_NEGATIVE_AND_INDEPENDENT_ALL_PASS",
    })

    members = sorted(expected | {FREEZE})
    manifest_rows = [
        {"path": name, "bytes": (ROOT / name).stat().st_size, "sha256": sha256(ROOT / name)}
        for name in members
    ]
    artifact_root = canonical(manifest_rows)
    write_once(MANIFEST, {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0",
        "member_count": len(manifest_rows),
        "members": manifest_rows,
        "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha256(ROOT / MANIFEST)
    write_once(LOCK, {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": DECISION,
        "v11_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11",
        "v11_disposition": "FAIL_CLOSED_DURING_INDEPENDENT_VALIDATION_PRELOCK",
        "v11_pre_correction_reference_snapshot_immutable": True,
        "v11_attempt_count": 0,
        "v11_attempt_limit": 1,
        "v11_worker_invocation_count": 0,
        "v11_worker_invocation_limit": 1,
        "v11_codex_as_worker_invocation_count": 0,
        "v11_codex_as_worker_invocation_limit": 1,
        "v11_fresh_preflight": "NOT_STARTED",
        "v11_static_lock": "NOT_ISSUED",
        "v11_workspace_root_sha256_at_adjudication": root_digest,
        "v11_member_count_at_adjudication": len(rows),
        "independent_static_failure_result_sha256": binding["independent_result"]["sha256"],
        "independent_validator_source_order_anchor_defect": "YES",
        "observer_ready_before_attempt_implementation_defect": "NO_BASED_ON_STATIC_SOURCE_ORDER_EVIDENCE",
        "source_order_observer_start_line": 359,
        "source_order_observer_ready_line": 367,
        "source_order_attempt_marker_creation_line": 398,
        "attempt_marker_non_creation_reference_line": 295,
        "temporal_observer_runtime_pass": "NOT_ESTABLISHED_EXECUTION_NOT_STARTED",
        "confinement": "NOT_PROVEN",
        "continuation_v11": "AUTHORIZED_VALIDATOR_ONLY_UNDER_SCOPE_LOCK",
        "continuation_mutable_allowlist": scope["mutable_allowlist"],
        "all_unlisted_v11_mutation": "PROHIBITED",
        "v12_state": "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "semantic_anchor_requirement": "OBSERVER_START_LT_OBSERVER_READY_LT_ATTEMPT_MARKER_CREATION",
        "free_text_or_substring_path_inference": "PROHIBITED",
        "full_validation_chain_after_correction": correction["full_validation_after_correction"],
        "reuse_of_failed_94_of_95_result": "PROHIBITED",
        "worker_execution_authorized_during_governance": False,
        "codex_invocation_authorized_during_governance": False,
        "credential_target_network_authorized": False,
        "subagent_parallel_exploit_capability_promotion_submission_authorized": False,
        "validation": {
            "primary_governance": {"status": primary["status"], "passed": primary["checks_passed"], "total": primary["checks_total"]},
            "negative_governance": {"status": negative["status"], "passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent_governance": {"status": independent["status"], "passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        },
        "operation_counters": counters,
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "next_legal_milestone": NEXT,
        "authority_ceiling": (
            "VALIDATOR_ONLY_CORRECTION_AND_SCOPED_REGRESSION_THEN_FULL_PRELOCK_"
            "REVALIDATION_NO_NEW_CAPABILITY_AND_NO_EXECUTION_DURING_THIS_GOVERNANCE"
        ),
    })

    for item in ROOT.iterdir():
        if item.is_file() and not item.is_symlink():
            os.chmod(item, 0o444)
    os.chmod(ROOT, 0o555)

    readonly = all((item.stat().st_mode & 0o222) == 0 for item in ROOT.iterdir() if item.is_file())
    after_rows = v11_rows()
    if (
        not readonly
        or after_rows != rows
        or V12.exists()
        or V12.is_symlink()
        or (V11 / "STATIC_EXECUTION_LOCK.json").exists()
        or (V11 / "results/prelock/fresh-preflight-run-0001.json").exists()
        or (V11 / "static-run-v11/ATTEMPT_MARKER.json").exists()
        or any((V11 / "static-run-v11").iterdir())
    ):
        raise SystemExit("post-freeze verification failed")

    print(json.dumps({
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": DECISION,
        "manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "files": len(manifest_rows) + 2,
        "v11_attempt": "0/1",
        "worker_invocation": "0/1",
        "codex_invocation": "0/1",
    }, sort_keys=True))


if __name__ == "__main__":
    main()
