#!/usr/bin/env python3
"""Build the governance-only V11 source-order validator erratum package."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_"
    "INDEPENDENT_VALIDATOR_SOURCE_ORDER_ANCHOR_DEFECT_PRELOCK_ERRATUM_"
    "AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "CONTINUATION_V11_VALIDATOR_ONLY_CORRECTION_AUTHORIZED"
NEXT = (
    "CORRECT_ONLY_V11_I065_INDEPENDENT_VALIDATOR_ANCHOR_LOGIC_ADD_SCOPED_"
    "REGRESSIONS_AND_RERUN_FULL_PRELOCK_VALIDATION_CHAIN"
)
SCRIPTS = {
    "build_governance.py",
    "validate_governance.py",
    "independent_validate.py",
    "finalize_governance.py",
}
BASE_ARTIFACTS = {
    "ROUTING_AND_SCOPE_DECISION.json",
    "ROUTING_LEDGER.json",
    "V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json",
    "V11_PRELOCK_EVIDENCE_BINDING.json",
    "V11_PRELOCK_DISPOSITION.json",
    "SOURCE_ORDER_EVIDENCE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json",
    "CONTINUATION_V11_AUTHORIZATION_DECISION.json",
    "CONTINUATION_V11_SCOPE_LOCK.json",
    "VALIDATOR_CORRECTION_REQUIREMENTS.json",
    "V11_CONTINUATION_REGRESSION_MATRIX.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json",
    "NEXT_LEGAL_MILESTONE.json",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def inventory(path: Path) -> list[dict[str, Any]]:
    return [
        {
            "path": item.relative_to(path).as_posix(),
            "bytes": item.stat().st_size,
            "sha256": sha256(item),
        }
        for item in sorted(node for node in path.rglob("*") if node.is_file())
    ]


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n"
        for row in sorted(rows, key=lambda value: value["path"])
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return f"{call_name(node.value)}.{node.attr}"
    return ""


def is_attempt_path(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.BinOp)
        and isinstance(node.op, ast.Div)
        and isinstance(node.left, ast.Name)
        and node.left.id == "STATIC_RUN"
        and isinstance(node.right, ast.Constant)
        and node.right.value == "ATTEMPT_MARKER.json"
    )


def runner_anchors(path: Path) -> dict[str, Any]:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    starts: list[int] = []
    ready: list[int] = []
    creates: list[int] = []
    references: list[int] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            value = node.value
            names = {target.id for target in targets if isinstance(target, ast.Name)}
            if "observer_process" in names and isinstance(value, ast.Call) and call_name(value.func) == "subprocess.Popen":
                starts.append(node.lineno)
            if "observer_ready" in names and isinstance(value, ast.Call) and call_name(value.func) == "wait_for_json":
                if len(value.args) >= 2 and isinstance(value.args[0], ast.Name) and value.args[0].id == "OBSERVER_READY" and isinstance(value.args[1], ast.Constant) and value.args[1].value == "OBSERVER_READY":
                    ready.append(node.lineno)
        if isinstance(node, ast.Call):
            if call_name(node.func) == "append_only_json" and node.args and is_attempt_path(node.args[0]):
                creates.append(node.lineno)
            if isinstance(node.func, ast.Attribute) and node.func.attr == "exists" and is_attempt_path(node.func.value):
                references.append(node.lineno)
    return {
        "observer_start_lines": sorted(starts),
        "observer_readiness_proof_lines": sorted(ready),
        "attempt_marker_creation_lines": sorted(creates),
        "attempt_marker_non_creation_reference_lines": sorted(references),
        "semantic_order_pass": len(starts) == len(ready) == len(creates) == 1 and starts[0] < ready[0] < creates[0],
    }


def validator_anchor_defect(path: Path) -> dict[str, Any]:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(path))
    index_literals: list[dict[str, Any]] = []
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == "runner_source"
            and node.func.attr == "index"
            and len(node.args) == 1
            and isinstance(node.args[0], ast.Constant)
            and isinstance(node.args[0].value, str)
        ):
            index_literals.append({"line": node.lineno, "literal": node.args[0].value})
    marker_indexes = [row for row in index_literals if 'STATIC_RUN / "ATTEMPT_MARKER.json"' in row["literal"]]
    first_text_line = next(
        (number for number, line in enumerate(source.splitlines(), 1) if 'STATIC_RUN / "ATTEMPT_MARKER.json"' in line),
        None,
    )
    return {
        "runner_source_dot_index_calls": sorted(index_literals, key=lambda row: (row["line"], row["literal"])),
        "attempt_marker_literal_index_call_count": len(marker_indexes),
        "first_textual_attempt_marker_reference_line": first_text_line,
        "uses_first_textual_occurrence_for_creation_order": len(marker_indexes) == 1,
        "typed_attempt_marker_creation_anchor_present": False,
    }


def write_json(name: str, payload: dict[str, Any]) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite governance artifact: {name}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    unexpected = {path.name for path in ROOT.iterdir()} - SCRIPTS
    if unexpected:
        raise SystemExit(f"governance workspace not fresh: {sorted(unexpected)}")
    if not V11.is_dir() or V11.is_symlink():
        raise SystemExit("V11 workspace missing or non-canonical")
    if V12.exists() or V12.is_symlink():
        raise SystemExit("V12 must not exist during this governance milestone")

    unit_path = V11 / "results/prelock/unit-fixtures-run-0001.json"
    primary_path = V11 / "results/prelock/primary-static-validation-run-0001.json"
    independent_path = V11 / "results/prelock/independent-static-validation-run-0001.json"
    runner_path = V11 / "src/runner_v11.py"
    validator_path = V11 / "validators/independent_static_validate.py"
    unit = load(unit_path)
    primary = load(primary_path)
    independent = load(independent_path)
    failed = [row for row in independent.get("checks", []) if row.get("status") == "FAIL"]
    rows = inventory(V11)
    tree_root = canonical_root(rows)
    anchors = runner_anchors(runner_path)
    validator_defect = validator_anchor_defect(validator_path)

    hard_preconditions = {
        "unit_126_of_126_pass": unit.get("status") == "PASS" and unit.get("checks_passed") == unit.get("checks_total") == 126,
        "primary_134_of_134_pass": primary.get("status") == "PASS" and primary.get("checks_passed") == primary.get("checks_total") == 134,
        "independent_94_of_95_fail_closed": independent.get("status") == "FAIL_CLOSED" and independent.get("checks_passed") == 94 and independent.get("checks_total") == 95,
        "only_i065_failed": len(failed) == 1 and failed[0].get("check_id") == "I065_OBSERVER_READY_BEFORE_ATTEMPT_SOURCE_ORDER",
        "static_lock_absent": not (V11 / "STATIC_EXECUTION_LOCK.json").exists(),
        "fresh_preflight_absent": not (V11 / "results/prelock/fresh-preflight-run-0001.json").exists(),
        "attempt_marker_absent": not (V11 / "static-run-v11/ATTEMPT_MARKER.json").exists(),
        "static_run_empty": (V11 / "static-run-v11").is_dir() and not any((V11 / "static-run-v11").iterdir()),
        "semantic_source_order_pass": anchors["semantic_order_pass"],
        "validator_uses_defective_text_anchor": validator_defect["uses_first_textual_occurrence_for_creation_order"],
    }
    if not all(hard_preconditions.values()):
        raise SystemExit("governance preconditions failed: " + ",".join(key for key, value in hard_preconditions.items() if not value))

    write_json("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0",
        "status": "PASS",
        "scope": "GOVERNANCE_ONLY_READ_FROZEN_V11_SOURCE_AND_PRELOCK_EVIDENCE",
        "active_skills": [
            "mandatory-auto-router", "authorized-security-autopilot",
            "agentic-security-research-harness", "codex-security-harness",
            "expert-python-engineer", "secure-code-reviewer",
        ],
        "authority_ceiling": "ADJUDICATION_AND_CONTINUATION_DECISION_ONLY",
        "subagents_used": False,
        "runtime_worker_codex_network_target_operations": 0,
    })
    write_json("ROUTING_LEDGER.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_ROUTING_LEDGER",
        "schema_version": "1.0",
        "status": "PASS",
        "router_map_evaluated": True,
        "router_evaluated_skill_count": 75,
        "router_active_count": 13,
        "router_deferred_count": 4,
        "router_not_applicable_count": 58,
        "task_specific_active_overrides": ["agentic-security-research-harness", "codex-security-harness"],
        "deferred_capabilities": [
            "worker_execution", "codex_as_worker_invocation", "credential_use",
            "target_access", "external_network", "subagent", "parallelism",
            "exploit_replay", "capability_graph", "candidate_promotion",
            "submission_automation", "daybreak_invocation",
        ],
        "not_applicable_routes": [
            "live_target_testing", "prior_art_search", "recon", "fuzzing",
            "exploit_execution", "multi_agent_execution", "v13_methodology_lab",
        ],
    })
    write_json("V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", {
        "record_type": "V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST",
        "schema_version": "1.0",
        "status": "FROZEN_REFERENCE_SNAPSHOT",
        "workspace": str(V11),
        "member_count": len(rows),
        "members": rows,
        "canonical_tree_root_sha256": tree_root,
        "snapshot_is_reference_not_static_execution_lock": True,
    })
    write_json("V11_PRELOCK_EVIDENCE_BINDING.json", {
        "record_type": "V11_PRELOCK_EVIDENCE_BINDING",
        "schema_version": "1.0",
        "status": "PASS_BOUND_READ_ONLY_DURING_GOVERNANCE",
        "canonical_tree_root_sha256": tree_root,
        "member_count": len(rows),
        "unit_result": {"path": str(unit_path), "sha256": sha256(unit_path), "status": unit["status"], "passed": 126, "total": 126},
        "primary_result": {"path": str(primary_path), "sha256": sha256(primary_path), "status": primary["status"], "passed": 134, "total": 134},
        "independent_result": {"path": str(independent_path), "sha256": sha256(independent_path), "status": independent["status"], "passed": 94, "total": 95, "failed_gate": "I065_OBSERVER_READY_BEFORE_ATTEMPT_SOURCE_ORDER"},
        "failed_independent_result_must_remain_immutable": True,
        "v11_content_mutation_during_governance": "PROHIBITED",
    })
    write_json("V11_PRELOCK_DISPOSITION.json", {
        "record_type": "V11_PRELOCK_DISPOSITION",
        "schema_version": "1.0",
        "status": "ADJUDICATED",
        "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11",
        "disposition": "FAIL_CLOSED_DURING_INDEPENDENT_VALIDATION_PRELOCK",
        "attempt": "0_OF_1_NOT_CONSUMED",
        "worker_invocation": "0_OF_1",
        "codex_as_worker_invocation": "0_OF_1",
        "fresh_preflight": "NOT_STARTED",
        "static_lock": "NOT_ISSUED",
        "runtime_observer_proof": "NOT_ESTABLISHED_EXECUTION_NOT_STARTED",
        "runtime_or_worker_evidence": "NONE_EXECUTION_NOT_STARTED",
        "failure_evidence": "IMMUTABLE_REFERENCE",
        "patch_during_governance": "PROHIBITED",
        "validator_rerun_during_governance": "PROHIBITED",
        "execution_during_governance": "PROHIBITED",
    })
    write_json("SOURCE_ORDER_EVIDENCE_ADJUDICATION.json", {
        "record_type": "V11_SOURCE_ORDER_EVIDENCE_ADJUDICATION",
        "schema_version": "1.0",
        "status": "SOURCE_ORDER_PROVEN_RUNTIME_BEHAVIOR_NOT_PROVEN",
        "runner_path": str(runner_path),
        "runner_sha256": sha256(runner_path),
        "semantic_anchors": anchors,
        "required_relation": "OBSERVER_START_OPERATION_LT_SUCCESSFUL_READINESS_PROOF_LT_AUTHORITATIVE_ATTEMPT_MARKER_CREATION",
        "observed_relation": "PASS",
        "non_creation_reference_is_not_creation_event": True,
        "runtime_temporal_observer_pass": "NOT_ESTABLISHED_NO_EXECUTION",
        "confinement": "NOT_PROVEN",
    })
    write_json("DEFECT_OWNERSHIP_DECISION.json", {
        "record_type": "V11_SOURCE_ORDER_DEFECT_OWNERSHIP_DECISION",
        "schema_version": "1.0",
        "status": "DEFECT_OWNERSHIP_ADJUDICATED",
        "independent_validator_source_order_anchor_defect": "YES",
        "observer_ready_before_attempt_implementation_defect": "NO_BASED_ON_STATIC_SOURCE_ORDER_EVIDENCE",
        "temporal_observer_runtime_defect": "NOT_ESTABLISHED_EXECUTION_NOT_STARTED",
        "security_worker_runtime_v1_defect": "NOT_ESTABLISHED_EXECUTION_NOT_STARTED",
        "codex_runtime_defect": "NOT_ESTABLISHED_EXECUTION_NOT_STARTED",
        "validator_path": str(validator_path),
        "validator_sha256": sha256(validator_path),
        "defective_anchor_evidence": validator_defect,
        "causal_history": "ONLY_THE_OBSERVED_ANCHOR_LOGIC_DEFECT_IS_ESTABLISHED_NO_UNPROVEN_HISTORY_RECONSTRUCTION",
    })
    write_json("CONTINUATION_V11_AUTHORIZATION_DECISION.json", {
        "record_type": "V11_CONTINUATION_OR_SUCCESSOR_DECISION",
        "schema_version": "1.0",
        "status": "PASS_DECISION_ISSUED",
        "decision": DECISION,
        "continuation_v11": "AUTHORIZED_ONLY_UNDER_CONTINUATION_SCOPE_LOCK",
        "fresh_v12": "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "basis": [
            "STATIC_LOCK_NOT_ISSUED",
            "ATTEMPT_AND_INVOCATION_COUNTS_REMAIN_ZERO",
            "RUNNER_SEMANTIC_SOURCE_ORDER_IS_CORRECT",
            "FAILED_COMPONENT_IS_ISOLATED_TO_INDEPENDENT_VALIDATOR_ANCHOR_LOGIC",
            "CONTINUATION_CAN_BE_CONFINED_TO_EXACT_VALIDATOR_AND_REGRESSION_PATHS",
        ],
        "current_milestone_performs_correction": False,
        "current_milestone_performs_revalidation": False,
        "current_milestone_performs_execution": False,
    })
    write_json("CONTINUATION_V11_SCOPE_LOCK.json", {
        "record_type": "V11_VALIDATOR_ONLY_CONTINUATION_SCOPE_LOCK",
        "schema_version": "1.0",
        "status": "MANDATORY_FOR_ANY_CONTINUATION",
        "mutable_allowlist": [
            "validators/independent_static_validate.py",
            "tests/run_unit_fixtures.py",
        ],
        "allowed_change_classes": [
            "I065_SEMANTIC_ANCHOR_OR_AST_LOGIC_ONLY",
            "I065_POSITIVE_AND_NEGATIVE_REGRESSION_FIXTURES_ONLY",
        ],
        "protected_exact_members": [
            "src/runner_v11.py",
            "src/topology_observer_v11.py",
            "src/invocation_v11.py",
            "src/worker_launch_gate_v11.py",
            "contracts/TEMPORAL_PROCESS_IDENTITY_OBSERVER_CONTRACT.json",
            "contracts/TEMPORAL_TRACE_CORRELATION_CONTRACT.json",
            "contracts/WORKER_REQUEST.json",
            "contracts/IDENTITY_BINDINGS.json",
            "contracts/EXECUTION_CONTRACT.json",
            "contracts/EXPECTED_EXECUTION_PLAN.json",
            "fixture/worker-prompt.txt",
            "runtime-config-candidate/config.toml",
            "HUMAN_GATE.json",
        ],
        "protected_semantics": [
            "OBSERVER_IMPLEMENTATION", "OBSERVER_CONTRACT", "RUNNER_EXECUTION_ORDER",
            "WORKER_REQUEST", "PROMPT", "RUNTIME_BINDINGS", "AUTHORIZATION",
            "CODEX_CONFIG", "EXECUTION_SEMANTICS",
        ],
        "original_failed_independent_result_mutation": "PROHIBITED",
        "all_unlisted_v11_member_mutation": "PROHIBITED",
        "scope_violation": "STOP_FAIL_CLOSED_REQUIRE_NEW_GOVERNANCE",
    })
    write_json("VALIDATOR_CORRECTION_REQUIREMENTS.json", {
        "record_type": "V11_I065_VALIDATOR_CORRECTION_REQUIREMENTS",
        "schema_version": "1.0",
        "status": "REQUIRED_FOR_CONTINUATION",
        "semantic_anchors": {
            "A": "EXACT_OBSERVER_START_OPERATION",
            "B": "SUCCESSFUL_OBSERVER_READINESS_PROOF",
            "C": "AUTHORITATIVE_ATTEMPT_MARKER_CREATION_OR_APPEND_ONLY_WRITE",
        },
        "required_relation": "A_LT_B_LT_C",
        "accepted_implementation": "AST_OR_CONTROL_FLOW_AWARE_MATCHING_OR_EXACT_CONTRACTED_CALL_IDENTITIES",
        "prohibited_implementation": "FIRST_FREE_TEXT_OR_SUBSTRING_OCCURRENCE",
        "attempt_marker_read_check_reference_is_creation": False,
        "unknown_or_ambiguous_anchor": "FAIL_CLOSED",
        "full_validation_after_correction": [
            "UNIT_FROM_SCRATCH", "PRIMARY_FROM_SCRATCH", "INDEPENDENT_FROM_SCRATCH",
            "FRESH_PREFLIGHT", "COMPLETE_DEPENDENCY_CLOSURE",
            "STATIC_LOCK", "LOCK_VERIFICATION", "POST_LOCK_PREFLIGHT",
        ],
        "reuse_of_94_of_95_as_success": "PROHIBITED",
    })
    regression_cases = [
        {"id": "R001", "case": "observer_start_then_ready_then_marker_creation", "expected": "PASS"},
        {"id": "R002", "case": "attempt_marker_exists_check_before_observer_then_start_ready_create", "expected": "PASS_CHECK_IGNORED_AS_NON_CREATION"},
        {"id": "R003", "case": "comment_or_string_mentions_attempt_marker_before_observer", "expected": "PASS_TEXT_IGNORED"},
        {"id": "R004", "case": "actual_marker_creation_before_readiness", "expected": "FAIL_CLOSED"},
        {"id": "R005", "case": "observer_start_missing", "expected": "FAIL_CLOSED"},
        {"id": "R006", "case": "readiness_proof_missing", "expected": "FAIL_CLOSED"},
        {"id": "R007", "case": "duplicate_or_ambiguous_attempt_marker_creation", "expected": "FAIL_CLOSED"},
        {"id": "R008", "case": "raw_substring_first_occurrence_anchor", "expected": "FAIL_CLOSED"},
        {"id": "R009", "case": "wrong_observer_or_marker_call_identity", "expected": "FAIL_CLOSED"},
        {"id": "R010", "case": "mutation_requested_outside_continuation_allowlist", "expected": "DENIED_BY_AUTHORITY"},
    ]
    write_json("V11_CONTINUATION_REGRESSION_MATRIX.json", {
        "record_type": "V11_CONTINUATION_REGRESSION_MATRIX",
        "schema_version": "1.0",
        "status": "MANDATORY",
        "cases": regression_cases,
        "all_cases_required": True,
    })
    counters = {
        "v11_files_modified_during_governance": 0,
        "validator_corrections_during_governance": 0,
        "validation_reruns_during_governance": 0,
        "fresh_preflight_runs": 0,
        "static_lock_issuances": 0,
        "attempts_consumed": 0,
        "worker_invocations": 0,
        "codex_as_worker_invocations": 0,
        "credential_uses": 0,
        "target_accesses": 0,
        "external_network_operations": 0,
        "subagent_invocations": 0,
        "parallel_operations": 0,
        "exploit_replays": 0,
        "capability_graph_mutations": 0,
        "candidate_promotions": 0,
        "submission_operations": 0,
        "daybreak_invocations": 0,
        "v12_workspaces_created": 0,
    }
    write_json("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION",
        "schema_version": "1.0",
        "status": "PASS_NO_EXECUTION_AUTHORITY_EXERCISED",
        "implementation_authorized_after_governance_lock": "ONLY_SCOPED_VALIDATOR_AND_REGRESSION_CORRECTION",
        "worker_execution_authorized_during_governance": False,
        "codex_invocation_authorized_during_governance": False,
        "credential_target_network_authorized": False,
        "subagent_parallel_exploit_capability_promotion_submission_authorized": False,
        "operation_counters": counters,
    })
    write_json("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_OPERATION_AUTHORIZATION_MATRIX",
        "schema_version": "1.0",
        "status": "DENY_BY_DEFAULT",
        "currently_authorized": [
            "READ_V11_FROZEN_SOURCE_AND_PRELOCK_EVIDENCE",
            "CREATE_VALIDATE_AND_FREEZE_THIS_GOVERNANCE_PACKAGE",
        ],
        "authorized_only_after_pass_locked": [
            "PATCH_ONLY_INDEPENDENT_VALIDATOR_I065_ANCHOR_LOGIC",
            "ADD_ONLY_SCOPED_I065_REGRESSION_FIXTURES",
            "RERUN_COMPLETE_PRELOCK_VALIDATION_CHAIN_FROM_SCRATCH",
        ],
        "not_authorized_this_milestone": [
            "V11_VALIDATOR_PATCH", "V11_REVALIDATION", "FRESH_PREFLIGHT",
            "STATIC_LOCK", "ATTEMPT_CONSUMPTION", "WORKER_INVOCATION",
            "CODEX_INVOCATION", "V12_CREATION", "CREDENTIAL_USE",
            "TARGET_ACCESS", "EXTERNAL_NETWORK", "SUBAGENT", "PARALLELISM",
            "EXPLOIT_REPLAY", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION",
            "SUBMISSION_AUTOMATION", "DAYBREAK_INVOCATION",
        ],
    })
    negative_cases = [
        {"id": "N001", "request": "treat_attempt_marker_exists_check_as_creation", "expected": "REJECT"},
        {"id": "N002", "request": "accept_raw_substring_offset_order", "expected": "REJECT"},
        {"id": "N003", "request": "accept_marker_creation_before_readiness", "expected": "REJECT"},
        {"id": "N004", "request": "accept_missing_readiness_anchor", "expected": "REJECT"},
        {"id": "N005", "request": "accept_ambiguous_duplicate_creation", "expected": "REJECT"},
        {"id": "N006", "request": "modify_runner_v11", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N007", "request": "modify_topology_observer", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N008", "request": "modify_observer_contract", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N009", "request": "modify_worker_request_prompt_or_runtime_binding", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N010", "request": "overwrite_failed_independent_result", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N011", "request": "rerun_only_i065_and_promote", "expected": "REJECT_FULL_CHAIN_REQUIRED"},
        {"id": "N012", "request": "claim_temporal_observer_runtime_pass", "expected": "REJECT_NOT_PROVEN"},
        {"id": "N013", "request": "issue_static_lock_during_governance", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N014", "request": "consume_attempt_or_invoke_worker_codex", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N015", "request": "create_v12", "expected": "DENY_BY_AUTHORITY"},
        {"id": "N016", "request": "open_target_network_credential_or_subagent", "expected": "DENY_BY_AUTHORITY"},
    ]
    write_json("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "schema_version": "1.0",
        "status": "MANDATORY",
        "cases": negative_cases,
    })
    write_json("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_GOVERNANCE_DECISION_SUMMARY",
        "schema_version": "1.0",
        "status": "DECISION_READY_FOR_VALIDATION",
        "v11_disposition": "FAIL_CLOSED_DURING_INDEPENDENT_VALIDATION_PRELOCK",
        "attempt_worker_codex_counts": "0_OF_1_EACH",
        "independent_validator_source_order_anchor_defect": "YES",
        "observer_ready_before_attempt_implementation_defect": "NO_BASED_ON_STATIC_SOURCE_ORDER_EVIDENCE",
        "runtime_observer_pass": "NOT_ESTABLISHED",
        "decision": DECISION,
        "v12_decision": "DO_NOT_AUTHORIZE_OR_CREATE_V12",
        "governance_freeze_condition": "PRIMARY_NEGATIVE_INDEPENDENT_AND_FINAL_FREEZE_ALL_PASS",
    })
    write_json("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_NEXT_LEGAL_MILESTONE",
        "schema_version": "1.0",
        "status": "CONDITIONAL_ON_PASS_LOCKED_GOVERNANCE",
        "next_if_pass_locked": NEXT,
        "continuation_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_VALIDATOR_ONLY_CORRECTION_CONTINUATION_1",
        "mutation_scope": "EXACT_ALLOWLIST_ONLY",
        "full_prelock_validation_chain_must_restart": True,
        "one_shot_attempt_remains": "0_OF_1_UNCONSUMED",
        "v12_may_be_created": False,
        "execution_during_this_governance_milestone": False,
    })

    print(json.dumps({
        "status": "BUILT_GOVERNANCE_ONLY",
        "identity": IDENTITY,
        "decision": DECISION,
        "v11_tree_root_sha256": tree_root,
        "v11_member_count": len(rows),
        "runner_anchors": anchors,
        "artifacts": len(BASE_ARTIFACTS),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
