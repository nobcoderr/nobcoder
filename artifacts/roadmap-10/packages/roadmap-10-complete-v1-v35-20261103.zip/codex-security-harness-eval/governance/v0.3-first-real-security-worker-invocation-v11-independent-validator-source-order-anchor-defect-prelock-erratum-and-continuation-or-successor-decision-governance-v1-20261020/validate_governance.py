#!/usr/bin/env python3
"""Primary governance validation and negative fixtures for the V11 erratum."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_"
    "INDEPENDENT_VALIDATOR_SOURCE_ORDER_ANCHOR_DEFECT_PRELOCK_ERRATUM_"
    "AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "CONTINUATION_V11_VALIDATOR_ONLY_CORRECTION_AUTHORIZED"
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json",
    "V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json", "V11_PRELOCK_EVIDENCE_BINDING.json",
    "V11_PRELOCK_DISPOSITION.json", "SOURCE_ORDER_EVIDENCE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "CONTINUATION_V11_AUTHORIZATION_DECISION.json",
    "CONTINUATION_V11_SCOPE_LOCK.json", "VALIDATOR_CORRECTION_REQUIREMENTS.json",
    "V11_CONTINUATION_REGRESSION_MATRIX.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
HISTORICAL_RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "GOVERNANCE_VALIDATION_RESULT_RUN-0002.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write_once(name: str, payload: dict[str, Any]) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite validation result: {name}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda value: value["path"])
    )
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def semantic_order(events: list[str]) -> bool:
    allowed = {"OBSERVER_START", "OBSERVER_READY", "ATTEMPT_CREATE", "ATTEMPT_CHECK", "TEXT_REFERENCE"}
    if any(event not in allowed for event in events):
        return False
    anchors = {name: [index for index, event in enumerate(events) if event == name] for name in ("OBSERVER_START", "OBSERVER_READY", "ATTEMPT_CREATE")}
    if any(len(value) != 1 for value in anchors.values()):
        return False
    return anchors["OBSERVER_START"][0] < anchors["OBSERVER_READY"][0] < anchors["ATTEMPT_CREATE"][0]


def main() -> None:
    expected = BASE | SCRIPTS | HISTORICAL_RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance member set before primary validation: {sorted(actual)}")

    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("G_SCRIPT_" + script, valid)

    historical_primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    historical_negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    intermediate_primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0002.json")
    intermediate_negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    historical_independent = read("INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    check(
        "G000A_HISTORICAL_PRIMARY_FAILURE_PRESERVED",
        historical_primary["status"] == "FAIL_CLOSED"
        and historical_primary["checks_passed"] == 50
        and historical_primary["checks_total"] == 52
        and historical_primary["checks_failed"] == 2,
    )
    check(
        "G000B_HISTORICAL_NEGATIVE_PASS_PRESERVED",
        historical_negative["status"] == "PASS"
        and historical_negative["tests_passed"] == historical_negative["tests_total"] == 16
        and historical_negative["tests_failed"] == 0,
    )
    check(
        "G000C_INTERMEDIATE_PRIMARY_PASS_PRESERVED",
        intermediate_primary["status"] == "PASS"
        and intermediate_primary["checks_passed"] == intermediate_primary["checks_total"] == 54
        and intermediate_primary["checks_failed"] == 0,
    )
    check(
        "G000D_INTERMEDIATE_NEGATIVE_PASS_PRESERVED",
        intermediate_negative["status"] == "PASS"
        and intermediate_negative["tests_passed"] == intermediate_negative["tests_total"] == 16
        and intermediate_negative["tests_failed"] == 0,
    )
    check(
        "G000E_HISTORICAL_INDEPENDENT_FAILURE_PRESERVED",
        historical_independent["status"] == "FAIL_CLOSED"
        and historical_independent["checks_passed"] == 48
        and historical_independent["checks_total"] == 50
        and historical_independent["checks_failed"] == 2,
    )

    snapshot = read("V11_PRELOCK_EVIDENCE_SNAPSHOT_MANIFEST.json")
    current_rows = [
        {"path": path.relative_to(V11).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}
        for path in sorted(node for node in V11.rglob("*") if node.is_file())
    ]
    check("G001_V11_MEMBER_COUNT", len(current_rows) == snapshot["member_count"] == 52, len(current_rows))
    check("G002_V11_MEMBER_SET_AND_HASHES", current_rows == snapshot["members"])
    check("G003_V11_ROOT", canonical_root(current_rows) == snapshot["canonical_tree_root_sha256"])
    check("G004_V12_ABSENT", not V12.exists() and not V12.is_symlink())
    check("G005_STATIC_LOCK_ABSENT", not (V11 / "STATIC_EXECUTION_LOCK.json").exists())
    check("G006_FRESH_PREFLIGHT_ABSENT", not (V11 / "results/prelock/fresh-preflight-run-0001.json").exists())
    check("G007_ATTEMPT_ABSENT", not (V11 / "static-run-v11/ATTEMPT_MARKER.json").exists())
    check("G008_STATIC_RUN_EMPTY", (V11 / "static-run-v11").is_dir() and not any((V11 / "static-run-v11").iterdir()))

    binding = read("V11_PRELOCK_EVIDENCE_BINDING.json")
    unit = json.loads((V11 / "results/prelock/unit-fixtures-run-0001.json").read_text(encoding="utf-8"))
    primary = json.loads((V11 / "results/prelock/primary-static-validation-run-0001.json").read_text(encoding="utf-8"))
    independent = json.loads((V11 / "results/prelock/independent-static-validation-run-0001.json").read_text(encoding="utf-8"))
    failed = [row for row in independent["checks"] if row["status"] == "FAIL"]
    check("G009_UNIT_RESULT", unit["status"] == "PASS" and unit["checks_passed"] == unit["checks_total"] == 126)
    check("G010_PRIMARY_RESULT", primary["status"] == "PASS" and primary["checks_passed"] == primary["checks_total"] == 134)
    check("G011_INDEPENDENT_RESULT", independent["status"] == "FAIL_CLOSED" and independent["checks_passed"] == 94 and independent["checks_total"] == 95)
    check("G012_ONLY_I065_FAILED", len(failed) == 1 and failed[0]["check_id"] == "I065_OBSERVER_READY_BEFORE_ATTEMPT_SOURCE_ORDER")
    check("G013_FAILED_RESULT_IMMUTABLE_BINDING", binding["independent_result"]["sha256"] == sha256(V11 / "results/prelock/independent-static-validation-run-0001.json") and binding["failed_independent_result_must_remain_immutable"] is True)

    disposition = read("V11_PRELOCK_DISPOSITION.json")
    check("G014_PRELOCK_DISPOSITION", disposition["disposition"] == "FAIL_CLOSED_DURING_INDEPENDENT_VALIDATION_PRELOCK")
    check("G015_ZERO_COUNTS", disposition["attempt"] == "0_OF_1_NOT_CONSUMED" and disposition["worker_invocation"] == disposition["codex_as_worker_invocation"] == "0_OF_1")
    check("G016_NO_RUNTIME_CLAIM", disposition["runtime_observer_proof"] == "NOT_ESTABLISHED_EXECUTION_NOT_STARTED" and disposition["runtime_or_worker_evidence"] == "NONE_EXECUTION_NOT_STARTED")

    order = read("SOURCE_ORDER_EVIDENCE_ADJUDICATION.json")
    anchors = order["semantic_anchors"]
    check("G017_SINGLE_TYPED_ANCHORS", anchors["observer_start_lines"] == [359] and anchors["observer_readiness_proof_lines"] == [367] and anchors["attempt_marker_creation_lines"] == [398])
    check("G018_NON_CREATION_REFERENCE_SEPARATE", anchors["attempt_marker_non_creation_reference_lines"] == [295] and order["non_creation_reference_is_not_creation_event"] is True)
    check("G019_SOURCE_ORDER", anchors["semantic_order_pass"] is True and order["observed_relation"] == "PASS")
    check("G020_RUNTIME_NOT_PROMOTED", order["runtime_temporal_observer_pass"] == "NOT_ESTABLISHED_NO_EXECUTION" and order["confinement"] == "NOT_PROVEN")

    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    check("G021_VALIDATOR_DEFECT", ownership["independent_validator_source_order_anchor_defect"] == "YES")
    check("G022_IMPLEMENTATION_DEFECT_NO", ownership["observer_ready_before_attempt_implementation_defect"] == "NO_BASED_ON_STATIC_SOURCE_ORDER_EVIDENCE")
    check("G023_RUNTIME_DEFECT_UNKNOWN", ownership["temporal_observer_runtime_defect"] == "NOT_ESTABLISHED_EXECUTION_NOT_STARTED")
    defect = ownership["defective_anchor_evidence"]
    check(
        "G024_DEFECTIVE_FIRST_TEXT_ANCHOR",
        defect["first_textual_attempt_marker_reference_line"] == 693
        and defect["uses_first_textual_occurrence_for_creation_order"] is True
        and defect["typed_attempt_marker_creation_anchor_present"] is False
        and anchors["attempt_marker_non_creation_reference_lines"] == [295],
    )

    continuation = read("CONTINUATION_V11_AUTHORIZATION_DECISION.json")
    scope = read("CONTINUATION_V11_SCOPE_LOCK.json")
    check("G025_CONTINUATION_DECISION", continuation["decision"] == DECISION and continuation["continuation_v11"] == "AUTHORIZED_ONLY_UNDER_CONTINUATION_SCOPE_LOCK")
    check("G026_V12_NOT_AUTHORIZED", continuation["fresh_v12"] == "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("G027_NO_CORRECTION_THIS_MILESTONE", not continuation["current_milestone_performs_correction"] and not continuation["current_milestone_performs_revalidation"] and not continuation["current_milestone_performs_execution"])
    check("G028_MUTABLE_ALLOWLIST", scope["mutable_allowlist"] == ["validators/independent_static_validate.py", "tests/run_unit_fixtures.py"])
    check("G029_PROTECTED_RUNNER", "src/runner_v11.py" in scope["protected_exact_members"] and "RUNNER_EXECUTION_ORDER" in scope["protected_semantics"])
    check("G030_FAILED_RESULT_PROTECTED", scope["original_failed_independent_result_mutation"] == "PROHIBITED")
    check("G031_UNLISTED_MUTATION_PROHIBITED", scope["all_unlisted_v11_member_mutation"] == "PROHIBITED")

    requirements = read("VALIDATOR_CORRECTION_REQUIREMENTS.json")
    check("G032_TYPED_RELATION", requirements["required_relation"] == "A_LT_B_LT_C")
    check("G033_TYPED_OR_AST", "AST_OR_CONTROL_FLOW_AWARE" in requirements["accepted_implementation"])
    check("G034_FREE_TEXT_PROHIBITED", requirements["prohibited_implementation"] == "FIRST_FREE_TEXT_OR_SUBSTRING_OCCURRENCE")
    check("G035_UNKNOWN_FAIL_CLOSED", requirements["unknown_or_ambiguous_anchor"] == "FAIL_CLOSED")
    check("G036_FULL_CHAIN_REQUIRED", len(requirements["full_validation_after_correction"]) == 8 and requirements["reuse_of_94_of_95_as_success"] == "PROHIBITED")

    regression = read("V11_CONTINUATION_REGRESSION_MATRIX.json")
    check("G037_REGRESSION_COUNT", len(regression["cases"]) == 10 and regression["all_cases_required"] is True)
    check("G038_REGRESSION_POSITIVE_AND_NEGATIVE", sum(row["expected"].startswith("PASS") for row in regression["cases"]) == 3 and sum("FAIL_CLOSED" in row["expected"] for row in regression["cases"]) == 6)

    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    counters = authority["operation_counters"]
    check("G039_COUNTERS_ZERO", len(counters) == 19 and all(value == 0 for value in counters.values()), counters)
    check("G040_NO_GOVERNANCE_EXECUTION", authority["worker_execution_authorized_during_governance"] is False and authority["codex_invocation_authorized_during_governance"] is False)
    matrix = read("OPERATION_AUTHORIZATION_MATRIX.json")
    check("G041_GOVERNANCE_ONLY_AUTHORIZED", matrix["currently_authorized"] == ["READ_V11_FROZEN_SOURCE_AND_PRELOCK_EVIDENCE", "CREATE_VALIDATE_AND_FREEZE_THIS_GOVERNANCE_PACKAGE"])
    check("G042_FUTURE_CORRECTION_SCOPED", len(matrix["authorized_only_after_pass_locked"]) == 3)
    check("G043_DANGEROUS_OPERATIONS_DENIED", {"WORKER_INVOCATION", "CODEX_INVOCATION", "V12_CREATION", "TARGET_ACCESS", "EXTERNAL_NETWORK", "SUBAGENT"}.issubset(set(matrix["not_authorized_this_milestone"])))
    summary = read("GOVERNANCE_DECISION_SUMMARY.json")
    next_step = read("NEXT_LEGAL_MILESTONE.json")
    check("G044_SUMMARY", summary["decision"] == DECISION and summary["v12_decision"] == "DO_NOT_AUTHORIZE_OR_CREATE_V12")
    check("G045_FREEZE_CONDITION", summary["governance_freeze_condition"] == "PRIMARY_NEGATIVE_INDEPENDENT_AND_FINAL_FREEZE_ALL_PASS")
    check("G046_NEXT", next_step["next_if_pass_locked"].startswith("CORRECT_ONLY_V11_I065") and next_step["full_prelock_validation_chain_must_restart"] is True and next_step["v12_may_be_created"] is False)
    routing = read("ROUTING_AND_SCOPE_DECISION.json")
    ledger = read("ROUTING_LEDGER.json")
    check("G047_ROUTING", routing["status"] == "PASS" and routing["subagents_used"] is False and routing["runtime_worker_codex_network_target_operations"] == 0)
    check("G048_ROUTE_COVERAGE", ledger["router_evaluated_skill_count"] == ledger["router_active_count"] + ledger["router_deferred_count"] + ledger["router_not_applicable_count"] == 75)

    failures = [row for row in checks if row["status"] == "FAIL"]
    write_once("GOVERNANCE_VALIDATION_RESULT_RUN-0003.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0",
        "run_id": "GOVERNANCE_VALIDATION_RUN-0003",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failures),
        "checks_failed": len(failures),
        "operation_counters": counters,
    })

    direct_negative = [
        ("N001", semantic_order(["ATTEMPT_CHECK", "OBSERVER_START", "OBSERVER_READY", "ATTEMPT_CREATE"]), True),
        ("N002", semantic_order(["TEXT_REFERENCE", "OBSERVER_START", "OBSERVER_READY", "ATTEMPT_CREATE"]), True),
        ("N003", semantic_order(["OBSERVER_START", "ATTEMPT_CREATE", "OBSERVER_READY"]), False),
        ("N004", semantic_order(["OBSERVER_START", "ATTEMPT_CREATE"]), False),
        ("N005", semantic_order(["OBSERVER_START", "OBSERVER_READY", "ATTEMPT_CREATE", "ATTEMPT_CREATE"]), False),
    ]
    negative_matrix = read("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    negative_results: list[dict[str, Any]] = []
    for case_id, observed, expected_value in direct_negative:
        negative_results.append({"test_id": case_id, "status": "PASS" if observed is expected_value else "FAIL", "observed_semantic_order": observed, "expected_semantic_order": expected_value})
    denied = set(matrix["not_authorized_this_milestone"])
    policy_results = {
        "N006": "V11_VALIDATOR_PATCH" in denied,
        "N007": "V11_VALIDATOR_PATCH" in denied and "src/topology_observer_v11.py" in scope["protected_exact_members"],
        "N008": "contracts/TEMPORAL_PROCESS_IDENTITY_OBSERVER_CONTRACT.json" in scope["protected_exact_members"],
        "N009": all(value in scope["protected_semantics"] for value in ("WORKER_REQUEST", "PROMPT", "RUNTIME_BINDINGS")),
        "N010": scope["original_failed_independent_result_mutation"] == "PROHIBITED",
        "N011": requirements["reuse_of_94_of_95_as_success"] == "PROHIBITED",
        "N012": order["runtime_temporal_observer_pass"] == "NOT_ESTABLISHED_NO_EXECUTION",
        "N013": "STATIC_LOCK" in denied,
        "N014": "WORKER_INVOCATION" in denied and "CODEX_INVOCATION" in denied,
        "N015": "V12_CREATION" in denied and continuation["fresh_v12"] == "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "N016": all(value in denied for value in ("TARGET_ACCESS", "EXTERNAL_NETWORK", "SUBAGENT")),
    }
    negative_results.extend({"test_id": key, "status": "PASS" if value else "FAIL"} for key, value in policy_results.items())
    declared_ids = [row["id"] for row in negative_matrix["cases"]]
    actual_ids = [row["test_id"] for row in negative_results]
    if declared_ids != actual_ids:
        negative_results.append({"test_id": "MATRIX_IDENTITY", "status": "FAIL", "declared": declared_ids, "actual": actual_ids})
    negative_failures = [row for row in negative_results if row["status"] == "FAIL"]
    write_once("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0003.json", {
        "record_type": "V11_SOURCE_ORDER_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "schema_version": "1.0",
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0003",
        "status": "PASS" if not negative_failures else "FAIL_CLOSED",
        "tests": negative_results,
        "tests_total": len(negative_results),
        "tests_passed": len(negative_results) - len(negative_failures),
        "tests_failed": len(negative_failures),
        "operation_counters": counters,
    })

    print(json.dumps({
        "primary": {"status": "PASS" if not failures else "FAIL_CLOSED", "passed": len(checks) - len(failures), "total": len(checks)},
        "negative": {"status": "PASS" if not negative_failures else "FAIL_CLOSED", "passed": len(negative_results) - len(negative_failures), "total": len(negative_results)},
    }, sort_keys=True))
    if failures or negative_failures:
        raise SystemExit("governance validation failed")


if __name__ == "__main__":
    main()
