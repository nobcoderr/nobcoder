#!/usr/bin/env python3
"""Build a governance-only authorization package; never execute the substrate."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PRE = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016"
)
GOV_ID = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_AUTHORIZATION_GOVERNANCE_V1"
MILESTONE = "AUTHORIZE_V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES"
FUTURE_MILESTONE = "IMPLEMENT_AND_VALIDATE_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V1"
FUTURE_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V1"
FUTURE_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V1"
WORKSPACE = Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016")
RUN = WORKSPACE / "run-v1"
EVIDENCE = WORKSPACE / "evidence-v1"
SANDBOX_RUN = "/run/v0-3-runtime-substrate-fixtures-v1"
EXPECTED = {
    "CONTRACT_LOCK.json": "a6f4f74b0a056e04959146a065103f375ec525f102530e4cb3e267f36d266a35",
    "CONTRACT_ARTIFACT_MANIFEST.json": "0a963d519ba3f9d14e22c8b8ec3cf125284a2d195f8089be21624ad98533aa03",
    "GOVERNANCE_LOCK.json": "77cc5e94b5b578f8a4bf828cb77de24df69b4d231804f7727a073144960034a7",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "7ee4baf60f2e55f3eab86951766dff63d79360f6fd572300da6047ec3aa02fd4",
}
DENIED_AUTHORITY = [
    "general_runtime_execution_authorized",
    "real_worker_execution_authorized",
    "subagent_execution_authorized",
    "codex_cli_invocation_authorized",
    "target_operation_authorized",
    "external_network_operation_authorized",
    "parallelism_authorized",
    "capability_graph_authorized",
    "candidate_promotion_authorized",
    "submission_automation_authorized",
    "exploit_replay_authorized",
    "v0_3_b0_authorized",
]
OP_COUNTERS = {
    "runtime_validation_attempts": 0,
    "containment_fixture_attempts": 0,
    "real_worker_processes": 0,
    "subagent_processes": 0,
    "codex_cli_invocations": 0,
    "target_operations": 0,
    "external_network_operations": 0,
    "parallel_operations": 0,
    "capability_edges": 0,
    "candidate_promotions": 0,
    "submission_operations": 0,
    "exploit_replays": 0,
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(name: str, value: object) -> None:
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main() -> None:
    for name, digest in EXPECTED.items():
        if sha(PRE / name) != digest:
            raise SystemExit(f"predecessor mismatch: {name}")
    pre_lock = json.loads((PRE / "GOVERNANCE_LOCK.json").read_text())
    pre_manifest = json.loads((PRE / "GOVERNANCE_ARTIFACT_MANIFEST.json").read_text())
    for item in pre_manifest["members"]:
        path = PRE / item["path"]
        if not path.is_file() or path.is_symlink() or sha(path) != item["sha256"]:
            raise SystemExit(f"predecessor member mismatch: {item['path']}")
    if pre_lock.get("status") != "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY":
        raise SystemExit("predecessor not accepted")
    if any(pre_lock.get("operation_counters", {}).values()):
        raise SystemExit("predecessor operation counter nonzero")
    if WORKSPACE.exists() or WORKSPACE.is_symlink():
        raise SystemExit("future workspace collision")

    predecessor = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_PREDECESSOR_BINDING_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "contract_identity": pre_lock["governance_identity"],
        "contract_path": str(PRE),
        "contract_lock_sha256": EXPECTED["CONTRACT_LOCK.json"],
        "contract_manifest_sha256": EXPECTED["CONTRACT_ARTIFACT_MANIFEST.json"],
        "governance_lock_sha256": EXPECTED["GOVERNANCE_LOCK.json"],
        "governance_manifest_sha256": EXPECTED["GOVERNANCE_ARTIFACT_MANIFEST.json"],
        "canonical_contract_root_sha256": pre_lock["canonical_contract_root_sha256"],
        "canonical_artifact_root_sha256": pre_lock["canonical_artifact_root_sha256"],
        "status": pre_lock["status"],
        "fixture_runner_v2": "PASS_LOCKED_NO_REPLAY",
        "predecessor_operation_counters": pre_lock["operation_counters"],
    }

    identity = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_IDENTITY_AND_PATH_BINDING",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "future_milestone": FUTURE_MILESTONE,
        "execution_identity": FUTURE_IDENTITY,
        "operation": FUTURE_OPERATION,
        "workspace": str(WORKSPACE),
        "workspace_state": "ABSENT_NOT_CREATED",
        "fixture_writable_host_path": str(RUN),
        "host_side_evidence_path": str(EVIDENCE),
        "sandbox_fixture_destination": SANDBOX_RUN,
        "sandbox_destination_parent": "/run",
        "source_and_contract_subtrees": "READ_ONLY_DURING_EXECUTION",
        "maximum_attempts": 1,
        "attempt_count": 0,
    }

    authority = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_TYPED_AUTHORITY_CEILING_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "default": "DENY",
        "future_workspace_creation_authorized": True,
        "validation_tooling_implementation_authorized": True,
        "static_validation_and_lock_authorized": True,
        "read_only_runtime_identity_inspection_authorized": True,
        "runtime_substrate_validation_authorized": True,
        "safe_containment_fixture_execution_authorized": True,
        "safe_containment_fixture_execution_condition": "CONDITIONAL_SINGLE_USE_AFTER_ALL_STATIC_LOCK_HUMAN_AND_RUNTIME_ENTRY_GATES_PASS",
        **{name: False for name in DENIED_AUTHORITY},
        "operation_counters": OP_COUNTERS,
        "unknown_authority_field": "FAIL_CLOSED",
    }

    decision = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_AND_SAFE_FIXTURE_AUTHORIZATION_DECISION_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "milestone": MILESTONE,
        "decision": "AUTHORIZE_MINIMAL_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_ONLY",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "future_milestone": FUTURE_MILESTONE,
        "future_identity": FUTURE_IDENTITY,
        "future_operation": FUTURE_OPERATION,
        "future_state": "CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt_count": 0,
        "maximum_attempts": 1,
        "separate_acceptance_after_success": "REQUIRED",
        "authority": authority,
    }

    single_use = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_SINGLE_USE_EXECUTION_CONTRACT",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "execution_identity": FUTURE_IDENTITY,
        "operation": FUTURE_OPERATION,
        "attempt_count": 0,
        "maximum_attempts": 1,
        "attempt_transition": "0_TO_1_IMMEDIATELY_BEFORE_CANONICAL_BWRAP_STRACE_PIPELINE_START",
        "preliminary_execution_under_same_identity": "PROHIBITED",
        "failure_after_start": "FAIL_CLOSED_TERMINAL_NO_RETRY",
        "patch_relock_or_reclassify_after_start": "PROHIBITED",
        "missing_or_ambiguous_consumption_evidence": "CONSUMED_FAIL_CLOSED",
        "separate_frozen_evidence_acceptance": "REQUIRED",
    }

    inspection = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_INSPECTION_CONTRACT_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "execution_identity": FUTURE_IDENTITY,
        "inspection_classes": [
            "kernel_release_version_and_boot_identity",
            "kernel_package_and_patch_backport_provenance_limit",
            "bubblewrap_binary_package_and_native_dependency_identity",
            "strace_binary_package_and_trace_configuration_identity",
            "python_fixture_runtime_binary_package_and_native_dependency_identity",
            "namespace_identity_and_mount_topology",
            "seccomp_no_new_privs_capability_and_LSM_state",
            "file_descriptor_socket_and_IPC_inventory",
            "host_backed_mount_inventory_and_effective_write_properties",
            "network_namespace_and_host_network_path_absence",
            "monitor_kill_controller_and_evidence_writer_separation",
        ],
        "read_only_preflight": "ALLOWED_WITHOUT_CONSUMING_ATTEMPT_WHEN_NO_SANDBOX_OR_FIXTURE_PROCESS_STARTS",
        "runtime_observation": "MUST_OCCUR_INSIDE_THE_SINGLE_CANONICAL_ATTEMPT",
        "worker_report_authority": "NONE",
        "host_side_observation_required": True,
        "identity_drift": "BLOCK_BEFORE_START_OR_TERMINATE_AFTER_START",
        "codex_runtime": "EXCLUDED_NOT_INVOKED_SEPARATE_COMPATIBILITY_LINEAGE",
        "vmm_hypervisor": "EXCLUDED_NOT_ENABLED_REQUIRES_CONTRACT_SUCCESSOR",
    }

    topology = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "semantic_mount_order": [
            {"type": "ROOT_READ_ONLY_BIND", "source": "/", "destination": "/"},
            {"type": "EPHEMERAL_PARENT_TMPFS", "destination": "/run"},
            {"type": "DESTINATION_DIRECTORY_CREATE", "destination": SANDBOX_RUN},
            {"type": "AUTHORIZED_FIXTURE_RW_BIND", "source": str(RUN), "destination": SANDBOX_RUN},
        ],
        "validation": "SEMANTIC_OPTION_AND_OPERAND_PARSING_NO_STRING_CARDINALITY_HEURISTIC",
        "host_root": "READ_ONLY",
        "sandbox_persistent_writable_bind_count": 1,
        "fixture_writable_host_path": str(RUN),
        "fixture_writable_sandbox_path": SANDBOX_RUN,
        "host_side_evidence_path": str(EVIDENCE),
        "evidence_path_visible_or_writable_to_fixture": False,
        "source_contract_and_validators": "READ_ONLY",
        "symlink_alias_overlap_or_path_traversal": "PROHIBITED",
        "unexpected_mount_or_write": "FAIL_CLOSED",
        "unsandboxed_fallback": "PROHIBITED",
    }

    process_policy = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_PROCESS_NETWORK_IPC_POLICY",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "expected_executable_classes": ["PINNED_BUBBLEWRAP", "PINNED_STRACE", "PINNED_PYTHON_FIXTURE_RUNTIME"],
        "exact_paths_digests_argv_and_lineage": "MUST_BE_STATICALLY_LOCKED_BEFORE_ATTEMPT",
        "unknown_executable_or_child": "FAIL_CLOSED",
        "trace_scope": "COMPLETE_FOLLOW_FORK_EXECVE_EXECVEAT_FILE_NETWORK_PROCESS_DESC_SIGNAL",
        "trace_missing_truncated_or_unattributed": "FAIL_CLOSED",
        "network_namespace": "ISOLATED_NO_HOST_BACKED_NETWORK_PATH",
        "external_network_requests": "PROHIBITED_ZERO",
        "loopback_packet_fixture": "NOT_AUTHORIZED_BY_THIS_GOVERNANCE",
        "tun_tap_virtio_bridge_raw_socket": "PROHIBITED",
        "FD_socket_IPC_default": "DENY_EXCEPT_EXACT_LOCKED_ALLOWLIST",
        "worker_subagent_codex_process": "PROHIBITED",
    }

    control = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_CONTROL_PLANE_AND_EVIDENCE_SEPARATION",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "fixture_cannot_access": [
            "host_monitor_configuration", "host_trace_controller", "kill_controller",
            "governance_policy", "frozen_evidence_store", "host_or_control_plane_secrets",
            "target_credentials", "Codex_configuration_or_credentials",
        ],
        "monitor_and_kill_location": "HOST_SIDE_OUTSIDE_FIXTURE_NAMESPACE_CONTROL",
        "evidence_writer": "HOST_SIDE_APPEND_ONLY_CONTENT_ADDRESSED",
        "fixture_output": "UNTRUSTED_INPUT_TO_HOST_SIDE_VALIDATOR",
        "fixture_cannot_finalize_verdict": True,
        "fixture_cannot_modify_attempt_state": True,
        "fixture_cannot_promote_candidate": True,
    }

    fixture_cases = [
        {
            "fixture_id": "F001_PINNED_RUNTIME_IDENTITY_MATCH",
            "class": "POSITIVE_CONTROL",
            "action": "READ_SANDBOX_VISIBLE_IDENTITY_AND_COMPARE_TO_HOST_CAPTURE",
            "network": False,
            "destructive": False,
            "oracle": "EXACT_LOCKED_IDENTITY_MATCH",
        },
        {
            "fixture_id": "F002_AUTHORIZED_WORKSPACE_WRITE_READBACK",
            "class": "POSITIVE_CONTROL",
            "action": "CREATE_EXCLUSIVE_INERT_CANARY_INSIDE_AUTHORIZED_RUN_PATH_AND_READ_BACK",
            "network": False,
            "destructive": False,
            "oracle": "SUCCESS_AND_EXACT_READBACK",
        },
        {
            "fixture_id": "F003_READ_ONLY_SOURCE_WRITE_DENIED",
            "class": "NEGATIVE_WRITE",
            "action": "EXCLUSIVE_INERT_CANARY_CREATE_UNDER_DEDICATED_READ_ONLY_SYNTHETIC_SOURCE_CANARY",
            "network": False,
            "destructive": False,
            "oracle": "EROFS_OR_EACCES_NO_OBJECT_CREATED",
        },
        {
            "fixture_id": "F004_GOVERNANCE_WRITE_DENIED",
            "class": "NEGATIVE_WRITE",
            "action": "OPEN_EXISTING_DEDICATED_CANARY_WITH_WRITE_INTENT_WITHOUT_TRUNCATION",
            "network": False,
            "destructive": False,
            "oracle": "EROFS_OR_EACCES_BYTES_UNCHANGED",
        },
        {
            "fixture_id": "F005_UNAUTHORIZED_MOUNT_ALIAS_ABSENT",
            "class": "TOPOLOGY_NEGATIVE",
            "action": "COMPARE_HOST_SIDE_MOUNTINFO_TO_LOCKED_SEMANTIC_INVENTORY",
            "network": False,
            "destructive": False,
            "oracle": "NO_EXTRA_WRITABLE_HOST_BACKED_MOUNT",
        },
        {
            "fixture_id": "F006_FD_SOCKET_IPC_ALLOWLIST",
            "class": "EXPOSURE_NEGATIVE",
            "action": "ENUMERATE_ONLY_NO_CONNECT_NO_SEND",
            "network": False,
            "destructive": False,
            "oracle": "EXACT_ALLOWLIST_NO_UNKNOWN_ENDPOINT",
        },
        {
            "fixture_id": "F007_HOST_NETWORK_PATH_ABSENT",
            "class": "NETWORK_NEGATIVE",
            "action": "INSPECT_NAMESPACE_INTERFACES_ROUTES_AND_SOCKET_INVENTORY_ONLY",
            "network": False,
            "destructive": False,
            "oracle": "NO_HOST_BACKED_PATH_AND_NO_EXTERNAL_PACKET",
        },
        {
            "fixture_id": "F008_CONTROL_PLANE_PATH_UNREACHABLE",
            "class": "AUTHORITY_NEGATIVE",
            "action": "CHECK_DECLARED_SYNTHETIC_SENTINEL_ABSENCE_OR_READ_ONLY_STATUS",
            "network": False,
            "destructive": False,
            "oracle": "NO_WRITE_DELETE_POLICY_OR_KILL_CAPABILITY",
        },
        {
            "fixture_id": "F009_WORKER_METADATA_NOT_HOST_FACT",
            "class": "TRUST_NEGATIVE",
            "action": "EMIT_FALSE_SYNTHETIC_METADATA_CLAIM",
            "network": False,
            "destructive": False,
            "oracle": "HOST_VALIDATOR_REJECTS_CLAIM_AGAINST_HOST_EVIDENCE",
        },
    ]
    fixtures = {
        "record_type": "V0_3_SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "execution_identity": FUTURE_IDENTITY,
        "fixture_workload": "FIXED_INERT_PYTHON_WORKLOAD_NOT_A_WORKER_NOT_CODEX",
        "fixtures": fixture_cases,
        "fixture_count": len(fixture_cases),
        "all_inputs": "SYNTHETIC_RESEARCHER_OWNED_INERT",
        "external_target_or_network": "NONE",
        "exploit_payload_or_prior_art_replay": "PROHIBITED",
        "arbitrary_command_or_plugin_loading": "PROHIBITED",
        "cleanup": "AUTHORIZED_RUN_PATH_ONLY_AFTER_HOST_SIDE_READBACK_AND_EVIDENCE_FREEZE_IF_CANONICAL_CONTRACT_REQUIRES",
        "unexpected_success": "TERMINATE_PRESERVE_EVIDENCE_NO_RETRY",
    }

    evidence = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_EVIDENCE_CAPTURE_CONTRACT",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "host_side_destination": str(EVIDENCE),
        "destination_not_mounted_writable_to_fixture": True,
        "capture_before_fixture_body": [
            "attempt_transition_record", "exact_argv_and_environment", "binary_digests",
            "namespace_links", "raw_mountinfo", "FD_socket_IPC_inventory", "security_state",
        ],
        "capture_during_and_after": [
            "complete_strace_files", "process_lineage", "stdout_stderr_structured_result",
            "fixture_oracles", "write_inventory", "network_syscall_inventory", "exit_status",
            "source_lock_reread", "historical_predecessor_reread",
        ],
        "raw_evidence_first": True,
        "missing_raw_mountinfo_or_trace": "FAIL_CLOSED_TERMINAL",
        "fixture_claims": "UNTRUSTED_UNTIL_INDEPENDENT_HOST_SIDE_VALIDATION",
        "content_addressing": "SHA256_EXACT_BYTES",
        "manifest": "COMPLETE_NON_CIRCULAR",
        "freeze": "READ_ONLY_AFTER_SUCCESSFUL_INDEPENDENT_VALIDATION",
    }

    gates = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_STATIC_AND_RUNTIME_GATE_MATRIX",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "pre_attempt_static_gates": [
            "PREDECESSOR_CONTRACT_INTEGRITY_PASS",
            "FUTURE_WORKSPACE_PATH_ABSENT_BEFORE_CREATION",
            "SOURCE_AND_FIXTURE_BYTES_COMPLETE",
            "NO_FORBIDDEN_EXECUTION_CAPABILITY_IN_SOURCE",
            "SEMANTIC_ARGV_VALIDATOR_PASS",
            "INERT_FIXTURE_ORACLES_PASS",
            "PRIMARY_STATIC_VALIDATION_PASS",
            "INDEPENDENT_STATIC_VALIDATION_PASS",
            "EXACT_RUNTIME_IDENTITY_CLOSURE_PASS",
            "SOURCE_MANIFEST_AND_STATIC_EXECUTION_LOCK_PASS",
            "LOCK_REREAD_PASS",
            "HUMAN_ACTIVATION_GATE_PASS",
        ],
        "inside_attempt_before_fixture_gates": [
            "ATTEMPT_TRANSITION_DURABLY_RECORDED",
            "RUNTIME_IDENTITY_MATCH",
            "NAMESPACE_AND_MOUNT_TOPOLOGY_PASS",
            "HOST_ROOT_READ_ONLY",
            "EXACT_ONE_FIXTURE_WRITABLE_BIND",
            "HOST_EVIDENCE_PATH_NOT_VISIBLE_WRITABLE",
            "NO_UNEXPECTED_FD_SOCKET_IPC",
            "NETWORK_ISOLATION_PASS",
            "MONITOR_TRACE_AND_KILL_SEPARATION_PASS",
            "RAW_EVIDENCE_CAPTURE_STARTED",
        ],
        "gate_failure_before_start": "BLOCK_BEFORE_ATTEMPT",
        "gate_failure_after_start": "FAIL_CLOSED_TERMINAL_NO_RETRY",
        "source_mutation_after_lock": "INVALIDATE_AND_STOP_NO_RELOCK",
    }

    failure = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_FAIL_CLOSED_CONTRACT",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "terminal_conditions": [
            "runtime_identity_mismatch", "kernel_or_security_state_drift", "topology_drift",
            "namespace_mismatch", "raw_mountinfo_missing", "trace_missing_or_incomplete",
            "unexpected_executable_or_child", "unexpected_FD_socket_or_IPC",
            "unexpected_writable_mount_or_alias", "out_of_scope_successful_write",
            "host_network_path_or_external_network_attempt", "monitor_or_kill_control_loss",
            "control_plane_or_secret_exposure", "kernel_fault_or_host_instability",
            "fixture_oracle_failure", "validator_disagreement", "evidence_digest_or_schema_gap",
        ],
        "retry": "PROHIBITED_AFTER_ATTEMPT_START",
        "evidence": "PRESERVE_AVAILABLE_BYTES_AND_MARK_INCOMPLETE_WHEN_REQUIRED",
        "runtime_or_worker_pass_from_partial_evidence": "PROHIBITED",
    }

    independent = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "independent_implementation_required": True,
        "same_frozen_evidence_required": True,
        "required_reviews": [
            "runtime_identity", "semantic_mount_topology", "writable_scope", "namespace_security_state",
            "FD_socket_IPC", "process_lineage_and_executable_allowlist", "network_syscalls",
            "write_inventory", "control_plane_separation", "fixture_oracles", "source_immutability",
            "attempt_count", "manifest_and_evidence_root", "historical_immutability",
        ],
        "disagreement_or_missing_evidence": "BLOCKED_OR_FAIL_CLOSED_NO_PASS",
        "successful_technical_run": "REQUIRES_SEPARATE_FROZEN_EVIDENCE_ACCEPTANCE_GOVERNANCE",
        "runtime_pass_locked_issued_here": False,
        "worker_execution_authority_issued_here": False,
    }

    prior_art = {
        "record_type": "V0_3_RUNTIME_VALIDATION_V1_PRIOR_ART_BOUNDARY",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "pwnescape": {
            "reference": "https://pwn.ai/blog/pwnescape",
            "classification": "PUBLIC_PRIOR_ART_REFERENCE",
            "new_finding": False,
            "execution_authorization": False,
            "exploit_or_PoC_replay_authorized": False,
            "lesson": "WORKER_OR_GUEST_METADATA_CANNOT_BECOME_HOST_FACT_WITHOUT_HOST_SIDE_CORROBORATION",
        },
        "external_reference_code_commands_or_payloads": "UNTRUSTED_REFERENCE_ONLY",
    }

    operations = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_OPERATION_MATRIX_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "default": "DENY",
        "operations": {
            "CREATE_FUTURE_VALIDATION_WORKSPACE": "AUTHORIZED_FUTURE_MILESTONE_ONLY",
            "IMPLEMENT_STATIC_VALIDATION_AND_INERT_FIXTURE_TOOLING": "AUTHORIZED_FUTURE_MILESTONE_ONLY",
            "READ_LOCAL_RUNTIME_IDENTITY_WITHOUT_STARTING_SANDBOX": "AUTHORIZED_FUTURE_MILESTONE_ONLY",
            "CREATE_STATIC_SOURCE_AND_EXECUTION_LOCK": "AUTHORIZED_AFTER_ALL_STATIC_GATES_PASS",
            "EXECUTE_ONE_RUNTIME_VALIDATION_AND_SAFE_FIXTURE_ATTEMPT": "CONDITIONAL_SINGLE_USE_AFTER_ALL_GATES_PASS",
            "EXECUTE_REAL_WORKER_SUBAGENT_OR_CODEX": "NOT_AUTHORIZED",
            "ACCESS_TARGET_OR_EXTERNAL_NETWORK": "NOT_AUTHORIZED",
            "EXECUTE_PARALLEL_OPERATIONS": "NOT_AUTHORIZED",
            "CREATE_CAPABILITY_GRAPH_OR_PROMOTE_CANDIDATE": "NOT_AUTHORIZED",
            "REPLAY_EXPLOIT_OR_PWNESCAPE_POC": "NOT_AUTHORIZED",
            "SUBMIT_REPORT_OR_AUTOMATE_SUBMISSION": "NOT_AUTHORIZED",
            "IMPLEMENT_V0_3_B0": "NOT_AUTHORIZED",
        },
    }

    routing = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_ROUTING_AND_SCOPE_DECISION_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "active_skills": ["mandatory-auto-router", "agentic-security-research-harness", "codex-security-harness", "contract-first"],
        "authorized_security_autopilot": "POLICY_ACTIVE_NO_TARGET_RESEARCH_ROUTE",
        "scope": "GOVERNANCE_ONLY_AUTHORIZATION",
        "target_scope_card": "NOT_APPLICABLE_NO_TARGET",
        "subagents": "NOT_USED_NOT_AUTHORIZED",
        "external_tools": "NOT_EXECUTED",
        "conditional_research_modules": "DEFERRED_UNTIL_AUTHORIZED_TARGET_CAMPAIGN",
        "operations_this_milestone": OP_COUNTERS,
    }

    next_step = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_NEXT_LEGAL_MILESTONE_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "milestone": FUTURE_MILESTONE,
        "status": "CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_STARTED",
        "execution_identity": FUTURE_IDENTITY,
        "operation": FUTURE_OPERATION,
        "workspace": str(WORKSPACE),
        "attempt_count": 0,
        "maximum_attempts": 1,
        "stop_after": "ONE_TECHNICAL_ATTEMPT_INDEPENDENT_POST_VALIDATION_AND_EVIDENCE_FREEZE",
        "next_after_success": "SEPARATE_FROZEN_EVIDENCE_ACCEPTANCE_AND_RUNTIME_LOCK_GOVERNANCE",
        "worker_execution_after_success": "STILL_REQUIRES_SEPARATE_AUTHORIZATION",
    }

    cases = [
        ("N001_PREDECESSOR_NOT_PASS", "predecessor_pass", False),
        ("N002_WORKSPACE_COLLISION", "workspace_absent", False),
        ("N003_DEFAULT_ALLOW", "default_deny", False),
        ("N004_GENERAL_RUNTIME", "general_runtime_execution_authorized", True),
        ("N005_REAL_WORKER", "real_worker_execution_authorized", True),
        ("N006_SUBAGENT", "subagent_execution_authorized", True),
        ("N007_CODEX", "codex_cli_invocation_authorized", True),
        ("N008_TARGET", "target_operation_authorized", True),
        ("N009_EXTERNAL_NETWORK", "external_network_operation_authorized", True),
        ("N010_PARALLEL", "parallelism_authorized", True),
        ("N011_CAPABILITY", "capability_graph_authorized", True),
        ("N012_PROMOTION", "candidate_promotion_authorized", True),
        ("N013_SUBMISSION", "submission_automation_authorized", True),
        ("N014_EXPLOIT_REPLAY", "exploit_replay_authorized", True),
        ("N015_B0", "v0_3_b0_authorized", True),
        ("N016_TWO_ATTEMPTS", "maximum_attempts", 2),
        ("N017_ATTEMPT_ALREADY_USED", "attempt_count", 1),
        ("N018_UNSANDBOXED_FALLBACK", "unsandboxed_fallback_prohibited", False),
        ("N019_EVIDENCE_VISIBLE_RW", "evidence_path_visible_or_writable_to_fixture", True),
        ("N020_TWO_WRITABLE_BINDS", "sandbox_persistent_writable_bind_count", 2),
        ("N021_STRING_CARDINALITY", "semantic_argv_required", False),
        ("N022_TRACE_OPTIONAL", "trace_complete_required", False),
        ("N023_RAW_MOUNTINFO_OPTIONAL", "raw_mountinfo_required", False),
        ("N024_WORKER_FACT", "worker_metadata_authoritative", True),
        ("N025_MONITOR_WORKER_CONTROLLED", "monitor_outside_worker", False),
        ("N026_EXTERNAL_PACKET", "external_packet_allowed", True),
        ("N027_ARBITRARY_PLUGIN", "arbitrary_plugin_allowed", True),
        ("N028_PWNESCAPE_AUTH", "pwnescape_execution_authorization", True),
        ("N029_AUTO_RETRY", "automatic_retry", True),
        ("N030_TECHNICAL_PASS_AUTO_ACCEPT", "separate_acceptance_required", False),
        ("N031_NONZERO_COUNTER", "operation_counters.runtime_validation_attempts", 1),
        ("N032_UNKNOWN_AUTHORITY", "unknown_authority_field_fail_closed", False),
    ]
    negative = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_NEGATIVE_GOVERNANCE_TEST_MATRIX_V1",
        "schema_version": "1.0",
        "governance_identity": GOV_ID,
        "method": "IN_MEMORY_TYPED_MUTATION_NO_RUNTIME_OR_FIXTURE_EXECUTION",
        "cases": [{"case_id": cid, "field": field, "value": value, "expected": "REJECT"} for cid, field, value in cases],
    }

    artifacts = {
        "PREDECESSOR_CONTRACT_BINDING.json": predecessor,
        "AUTHORIZATION_DECISION.json": decision,
        "RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json": identity,
        "TYPED_AUTHORITY_CEILING.json": authority,
        "SINGLE_USE_EXECUTION_CONTRACT.json": single_use,
        "RUNTIME_SUBSTRATE_INSPECTION_CONTRACT.json": inspection,
        "TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json": topology,
        "PROCESS_NETWORK_IPC_POLICY.json": process_policy,
        "CONTROL_PLANE_AND_EVIDENCE_SEPARATION.json": control,
        "SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json": fixtures,
        "EVIDENCE_CAPTURE_CONTRACT.json": evidence,
        "STATIC_AND_RUNTIME_GATE_MATRIX.json": gates,
        "FAIL_CLOSED_AND_SINGLE_USE_FAILURE_CONTRACT.json": failure,
        "INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json": independent,
        "PRIOR_ART_BOUNDARY.json": prior_art,
        "OPERATION_AUTHORIZATION_MATRIX.json": operations,
        "ROUTING_AND_SCOPE_DECISION.json": routing,
        "NEXT_LEGAL_MILESTONE.json": next_step,
        "NEGATIVE_GOVERNANCE_TEST_MATRIX.json": negative,
    }
    for name, value in artifacts.items():
        dump(name, value)


if __name__ == "__main__":
    main()
