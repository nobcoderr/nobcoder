#!/usr/bin/env python3
"""Finalize the non-circular authorization manifest and locks."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path


ROOT=Path(__file__).resolve().parent
GOV_ID="V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_AUTHORIZATION_GOVERNANCE_V1"
MILESTONE="AUTHORIZE_V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES"
FUTURE="IMPLEMENT_AND_VALIDATE_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V1"
PRE_ROOT="9a7e5116a7007e29e8b7db8ebcec919ffc4993e5693cc2d9c55653b20c620332"


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n): return json.loads((ROOT/n).read_text())
def dump(n,v): (ROOT/n).write_text(json.dumps(v,indent=2,sort_keys=True)+"\n")
def member(p): return {"path":p.name,"sha256":sha(p),"bytes":p.stat().st_size}
def root_hash(items):
    data="".join(f"{x['sha256']}  {x['path']}\n" for x in sorted(items,key=lambda y:y['path']))
    return hashlib.sha256(data.encode()).hexdigest()


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--freeze",action="store_true"); args=ap.parse_args()
    primary=load("GOVERNANCE_TEST_RESULT_RUN-0002.json"); negative=load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json"); independent=load("INDEPENDENT_VALIDATION_RESULT_RUN-0002.json")
    if any(x.get("status")!="PASS" for x in [primary,negative,independent]): raise SystemExit("validation failure")
    decision=load("AUTHORIZATION_DECISION.json"); authority=load("TYPED_AUTHORITY_CEILING.json"); ident=load("RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json")
    if any(authority.get(k) is not False for k in ["general_runtime_execution_authorized","real_worker_execution_authorized","subagent_execution_authorized","codex_cli_invocation_authorized","target_operation_authorized","external_network_operation_authorized","parallelism_authorized","capability_graph_authorized","candidate_promotion_authorized","submission_automation_authorized","exploit_replay_authorized","v0_3_b0_authorized"]): raise SystemExit("authority ceiling")
    if any(authority["operation_counters"].values()): raise SystemExit("operation counter")
    freeze=load("FREEZE_VERIFICATION_RESULT.json") if (ROOT/"FREEZE_VERIFICATION_RESULT.json").exists() else None
    auth_lock={
        "record_type":"V0_3_RUNTIME_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_AUTHORIZATION_LOCK_V1",
        "schema_version":"1.0","governance_identity":GOV_ID,"milestone":MILESTONE,
        "status":"PASS_LOCKED_GOVERNANCE_ONLY","decision":decision["decision"],
        "future_milestone":FUTURE,"future_identity":ident["execution_identity"],"future_operation":ident["operation"],
        "future_workspace":ident["workspace"],"future_state":decision["future_state"],
        "attempt_count":0,"maximum_attempts":1,
        "runtime_substrate_validation_authorized":True,"safe_containment_fixture_execution_authorized":True,
        "authorization_condition":"ALL_STATIC_LOCK_HUMAN_AND_RUNTIME_ENTRY_GATES_PASS",
        "general_runtime_execution_authorized":False,"real_worker_execution_authorized":False,
        "subagent_execution_authorized":False,"codex_cli_invocation_authorized":False,
        "target_operation_authorized":False,"external_network_operation_authorized":False,
        "parallelism_authorized":False,"capability_graph_authorized":False,
        "candidate_promotion_authorized":False,"submission_automation_authorized":False,
        "exploit_replay_authorized":False,"v0_3_b0_authorized":False,
        "separate_frozen_evidence_acceptance_required":True,
        "operation_counters":authority["operation_counters"],
        "predecessor_canonical_artifact_root_sha256":PRE_ROOT,
        "validation_counts":{
            "governance":{"passed":primary["checks_passed"],"failed":primary["checks_failed"],"total":primary["checks_total"]},
            "negative":{"passed":negative["tests_passed"],"failed":negative["tests_failed"],"total":negative["tests_total"]},
            "independent":{"passed":independent["checks_passed"],"failed":independent["checks_failed"],"total":independent["checks_total"]},
            "freeze_candidate":({"passed":freeze["checks_passed"],"failed":freeze["checks_failed"],"total":freeze["checks_total"]} if freeze else "PENDING"),
        },
    }
    dump("RUNTIME_VALIDATION_AUTHORIZATION_LOCK.json",auth_lock)
    excluded={"GOVERNANCE_ARTIFACT_MANIFEST.json","GOVERNANCE_LOCK.json"}
    paths=sorted([p for p in ROOT.iterdir() if p.is_file() and p.name not in excluded],key=lambda p:p.name)
    if any(p.is_symlink() for p in paths): raise SystemExit("symlink")
    members=[member(p) for p in paths]; member_root=root_hash(members)
    manifest={"record_type":"V0_3_RUNTIME_VALIDATION_AUTHORIZATION_GOVERNANCE_ARTIFACT_MANIFEST_V1","schema_version":"1.0","governance_identity":GOV_ID,"canonical_serialization":"UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE","member_count":len(members),"members":members,"canonical_member_root_sha256":member_root,"self_referential_hashes":False}
    dump("GOVERNANCE_ARTIFACT_MANIFEST.json",manifest)
    mh=sha(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json"); root_members=members+[member(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json")]; canonical=root_hash(root_members)
    lock={
        "record_type":"V0_3_RUNTIME_VALIDATION_AUTHORIZATION_GOVERNANCE_LOCK_V1","schema_version":"1.0",
        "governance_identity":GOV_ID,"milestone":MILESTONE,"status":"PASS_LOCKED_GOVERNANCE_ONLY",
        "decision":decision["decision"],"authorization_lock_sha256":sha(ROOT/"RUNTIME_VALIDATION_AUTHORIZATION_LOCK.json"),
        "governance_manifest_sha256":mh,"canonical_member_root_sha256":member_root,"canonical_artifact_root_sha256":canonical,
        "predecessor_canonical_artifact_root_sha256":PRE_ROOT,
        "future_milestone":FUTURE,"future_identity":ident["execution_identity"],"future_workspace":ident["workspace"],
        "future_state":decision["future_state"],"attempt_count":0,"maximum_attempts":1,
        "runtime_substrate_validation_authorized":True,"safe_containment_fixture_execution_authorized":True,
        "general_runtime_execution_authorized":False,"real_worker_execution_authorized":False,
        "subagent_execution_authorized":False,"codex_cli_invocation_authorized":False,
        "target_operation_authorized":False,"external_network_operation_authorized":False,
        "parallelism_authorized":False,"capability_graph_authorized":False,"candidate_promotion_authorized":False,
        "submission_automation_authorized":False,"exploit_replay_authorized":False,"v0_3_b0_authorized":False,
        "operation_counters":authority["operation_counters"],
        "validation_counts":auth_lock["validation_counts"],
        "structural_counts":{"manifest_members":len(members),"root_members":len(root_members)},
    }
    dump("GOVERNANCE_LOCK.json",lock)
    if args.freeze:
        for p in ROOT.iterdir():
            if p.is_file(): os.chmod(p,0o444)
        os.chmod(ROOT,0o555)
    print(json.dumps({"authorization_lock_sha256":sha(ROOT/"RUNTIME_VALIDATION_AUTHORIZATION_LOCK.json"),"governance_manifest_sha256":mh,"governance_lock_sha256":sha(ROOT/"GOVERNANCE_LOCK.json"),"canonical_artifact_root_sha256":canonical,"members":len(members),"frozen":args.freeze},sort_keys=True))


if __name__=="__main__": main()
