#!/usr/bin/env python3
"""Freeze candidate and final read-only verification."""

from __future__ import annotations

import argparse, hashlib, json, stat
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PRE=Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016")
GOV_ID="V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_AUTHORIZATION_GOVERNANCE_V1"
EXPECTED={"CONTRACT_LOCK.json":"a6f4f74b0a056e04959146a065103f375ec525f102530e4cb3e267f36d266a35","CONTRACT_ARTIFACT_MANIFEST.json":"0a963d519ba3f9d14e22c8b8ec3cf125284a2d195f8089be21624ad98533aa03","GOVERNANCE_LOCK.json":"77cc5e94b5b578f8a4bf828cb77de24df69b4d231804f7727a073144960034a7","GOVERNANCE_ARTIFACT_MANIFEST.json":"7ee4baf60f2e55f3eab86951766dff63d79360f6fd572300da6047ec3aa02fd4"}
DENIED=["general_runtime_execution_authorized","real_worker_execution_authorized","subagent_execution_authorized","codex_cli_invocation_authorized","target_operation_authorized","external_network_operation_authorized","parallelism_authorized","capability_graph_authorized","candidate_promotion_authorized","submission_automation_authorized","exploit_replay_authorized","v0_3_b0_authorized"]

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n): return json.loads((ROOT/n).read_text())
def root_hash(items):
    return hashlib.sha256("".join(f"{x['sha256']}  {x['path']}\n" for x in sorted(items,key=lambda y:y['path'])).encode()).hexdigest()

def verify(final):
    checks=[]
    def ck(cid,ok,detail=None): checks.append({"check_id":cid,"status":"PASS" if bool(ok) else "FAIL","detail":detail})
    for i,(n,d) in enumerate(EXPECTED.items(),1): ck(f"F{i:03d}_PRE_{n}",sha(PRE/n)==d)
    required=["PREDECESSOR_CONTRACT_BINDING.json","AUTHORIZATION_DECISION.json","RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json","TYPED_AUTHORITY_CEILING.json","SINGLE_USE_EXECUTION_CONTRACT.json","RUNTIME_SUBSTRATE_INSPECTION_CONTRACT.json","TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json","PROCESS_NETWORK_IPC_POLICY.json","CONTROL_PLANE_AND_EVIDENCE_SEPARATION.json","SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json","EVIDENCE_CAPTURE_CONTRACT.json","STATIC_AND_RUNTIME_GATE_MATRIX.json","FAIL_CLOSED_AND_SINGLE_USE_FAILURE_CONTRACT.json","INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json","PRIOR_ART_BOUNDARY.json","OPERATION_AUTHORIZATION_MATRIX.json","ROUTING_AND_SCOPE_DECISION.json","NEXT_LEGAL_MILESTONE.json","NEGATIVE_GOVERNANCE_TEST_MATRIX.json","GOVERNANCE_TEST_RESULT.json","NEGATIVE_GOVERNANCE_TEST_RESULT.json","GOVERNANCE_TEST_RESULT_RUN-0002.json","NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json","INDEPENDENT_VALIDATION_RESULT.json","INDEPENDENT_VALIDATION_RESULT_RUN-0002.json","RUNTIME_VALIDATION_AUTHORIZATION_LOCK.json","GOVERNANCE_ARTIFACT_MANIFEST.json","GOVERNANCE_LOCK.json","build_governance.py","governance_self_test.py","independent_validate.py","finalize_governance.py","freeze_verify.py"]
    if final: required.append("FREEZE_VERIFICATION_RESULT.json")
    ck("F005_FILES",all((ROOT/n).is_file() for n in required))
    ck("F006_NO_SYMLINK",all(not (ROOT/n).is_symlink() for n in required))
    ck("F007_JSON_PARSE",all(isinstance(load(n),dict) for n in required if n.endswith('.json')))
    a=load("RUNTIME_VALIDATION_AUTHORIZATION_LOCK.json"); g=load("GOVERNANCE_LOCK.json"); m=load("GOVERNANCE_ARTIFACT_MANIFEST.json")
    p=load("GOVERNANCE_TEST_RESULT_RUN-0002.json"); n=load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json"); i=load("INDEPENDENT_VALIDATION_RESULT_RUN-0002.json")
    ck("F008_AUTH_ID",a.get("governance_identity")==GOV_ID)
    ck("F009_AUTH_STATUS",a.get("status")=="PASS_LOCKED_GOVERNANCE_ONLY")
    ck("F010_AUTH_DECISION",a.get("decision")=="AUTHORIZE_MINIMAL_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_ONLY")
    ck("F011_AUTH_STATE",a.get("future_state")=="CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    ck("F012_AUTH_ATTEMPT",a.get("attempt_count")==0 and a.get("maximum_attempts")==1)
    ck("F013_ALLOWED",a.get("runtime_substrate_validation_authorized") is True and a.get("safe_containment_fixture_execution_authorized") is True)
    ck("F014_DENIED",all(a.get(k) is False for k in DENIED))
    ck("F015_SEPARATE_ACCEPT",a.get("separate_frozen_evidence_acceptance_required") is True)
    ck("F016_COUNTERS_ZERO",all(v==0 for v in a.get("operation_counters",{}).values()))
    ck("F017_PRIMARY",p.get("status")=="PASS" and p.get("checks_failed")==0 and p.get("checks_total")==121)
    ck("F018_NEGATIVE",n.get("status")=="PASS" and n.get("tests_failed")==0 and n.get("tests_total")==32)
    ck("F019_INDEPENDENT",i.get("status")=="PASS" and i.get("checks_failed")==0 and i.get("checks_total")==121)
    ck("F020_COUNTER_PARITY",p.get("operation_counters")==n.get("operation_counters")==i.get("operation_counters")==a.get("operation_counters"))
    d=load("AUTHORIZATION_DECISION.json"); ident=load("RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json")
    ck("F021_DECISION_PARITY",d.get("future_identity")==a.get("future_identity"))
    ck("F022_PATH_ABSENT",ident.get("workspace_state")=="ABSENT_NOT_CREATED" and not Path(ident["workspace"]).exists())
    ck("F023_PATH_SEPARATION",len({ident.get("workspace"),ident.get("fixture_writable_host_path"),ident.get("host_side_evidence_path")})==3)
    single=load("SINGLE_USE_EXECUTION_CONTRACT.json")
    ck("F024_SINGLE_USE",single.get("maximum_attempts")==1 and single.get("attempt_count")==0)
    ck("F025_FAILURE_TERMINAL",single.get("failure_after_start")=="FAIL_CLOSED_TERMINAL_NO_RETRY")
    topo=load("TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json")
    ck("F026_TOPOLOGY_ORDER",[x["type"] for x in topo["semantic_mount_order"]]==["ROOT_READ_ONLY_BIND","EPHEMERAL_PARENT_TMPFS","DESTINATION_DIRECTORY_CREATE","AUTHORIZED_FIXTURE_RW_BIND"])
    ck("F027_ONE_RW",topo.get("sandbox_persistent_writable_bind_count")==1)
    ck("F028_EVIDENCE_NOT_RW",topo.get("evidence_path_visible_or_writable_to_fixture") is False)
    ck("F029_SEMANTIC_ARGV",str(topo.get("validation","")).startswith("SEMANTIC_"))
    ck("F030_NO_FALLBACK",topo.get("unsandboxed_fallback")=="PROHIBITED")
    proc=load("PROCESS_NETWORK_IPC_POLICY.json")
    ck("F031_NETWORK_ZERO",proc.get("external_network_requests")=="PROHIBITED_ZERO")
    ck("F032_NO_WORKER",proc.get("worker_subagent_codex_process")=="PROHIBITED")
    ck("F033_TRACE_REQUIRED",str(proc.get("trace_scope","")).startswith("COMPLETE_"))
    fx=load("SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json")
    ck("F034_FIXTURE_COUNT",fx.get("fixture_count")==len(fx.get("fixtures",[]))==9)
    ck("F035_FIXTURES_SAFE",all(x.get("network") is False and x.get("destructive") is False for x in fx["fixtures"]))
    ck("F036_NO_EXPLOIT",fx.get("exploit_payload_or_prior_art_replay")=="PROHIBITED")
    ev=load("EVIDENCE_CAPTURE_CONTRACT.json")
    ck("F037_RAW_FIRST",ev.get("raw_evidence_first") is True)
    ck("F038_RAW_REQUIRED",ev.get("missing_raw_mountinfo_or_trace")=="FAIL_CLOSED_TERMINAL")
    ck("F039_HOST_EVIDENCE",ev.get("destination_not_mounted_writable_to_fixture") is True)
    gate=load("STATIC_AND_RUNTIME_GATE_MATRIX.json")
    ck("F040_GATE_COUNTS",len(gate.get("pre_attempt_static_gates",[]))==12 and len(gate.get("inside_attempt_before_fixture_gates",[]))==10)
    ck("F041_GATE_TERMINAL",gate.get("gate_failure_after_start")=="FAIL_CLOSED_TERMINAL_NO_RETRY")
    ind=load("INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json")
    ck("F042_ACCEPT_SEPARATE",str(ind.get("successful_technical_run","")).startswith("REQUIRES_SEPARATE_"))
    pa=load("PRIOR_ART_BOUNDARY.json")["pwnescape"]
    ck("F043_PWNESCAPE_REFERENCE",pa.get("classification")=="PUBLIC_PRIOR_ART_REFERENCE")
    ck("F044_PWNESCAPE_NO_AUTH",pa.get("execution_authorization") is False and pa.get("exploit_or_PoC_replay_authorized") is False)
    route=load("ROUTING_AND_SCOPE_DECISION.json")
    ck("F045_ROUTE_GOV",route.get("scope")=="GOVERNANCE_ONLY_AUTHORIZATION")
    ck("F046_ROUTE_NO_SUBAGENT",route.get("subagents")=="NOT_USED_NOT_AUTHORIZED")
    ck("F047_ROUTE_ZERO",all(v==0 for v in route.get("operations_this_milestone",{}).values()))
    ck("F048_LOCK_STATUS",g.get("status")=="PASS_LOCKED_GOVERNANCE_ONLY")
    ck("F049_LOCK_AUTH_HASH",g.get("authorization_lock_sha256")==sha(ROOT/"RUNTIME_VALIDATION_AUTHORIZATION_LOCK.json"))
    ck("F050_LOCK_COUNTERS",all(v==0 for v in g.get("operation_counters",{}).values()))
    if final:
        fr=load("FREEZE_VERIFICATION_RESULT.json")
        ck("F051_FREEZE_CANDIDATE",fr.get("status")=="PASS" and fr.get("checks_total")==50 and fr.get("checks_failed")==0)
        actual=sorted(x.name for x in ROOT.iterdir() if x.is_file() and x.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json","GOVERNANCE_LOCK.json"})
        listed=sorted(x["path"] for x in m["members"])
        ck("F052_COVERAGE",actual==listed,{"actual":actual,"listed":listed})
        ck("F053_MEMBER_COUNT",m.get("member_count")==len(m["members"])==len(actual))
        ck("F054_UNIQUE",len(set(listed))==len(listed))
        ck("F055_DIGESTS",all(sha(ROOT/x["path"])==x["sha256"] for x in m["members"]))
        ck("F056_BYTES",all((ROOT/x["path"]).stat().st_size==x["bytes"] for x in m["members"]))
        ck("F057_MEMBER_ROOT",root_hash(m["members"])==m.get("canonical_member_root_sha256"))
        roots=m["members"]+[{'path':'GOVERNANCE_ARTIFACT_MANIFEST.json','sha256':sha(ROOT/'GOVERNANCE_ARTIFACT_MANIFEST.json'),'bytes':(ROOT/'GOVERNANCE_ARTIFACT_MANIFEST.json').stat().st_size}]
        ck("F058_MANIFEST_HASH",g.get("governance_manifest_sha256")==sha(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json"))
        ck("F059_ARTIFACT_ROOT",g.get("canonical_artifact_root_sha256")==root_hash(roots))
        ck("F060_MODES",all(stat.S_IMODE(x.stat().st_mode)==0o444 for x in ROOT.iterdir() if x.is_file()) and stat.S_IMODE(ROOT.stat().st_mode)==0o555)
        ck("F061_NO_SYMLINK_ANY",all(not x.is_symlink() for x in ROOT.iterdir()))
        ck("F062_STRUCTURAL",g.get("structural_counts")=={"manifest_members":len(actual),"root_members":len(actual)+1})
        ck("F063_VALIDATION_COUNTS",g.get("validation_counts",{}).get("freeze_candidate")=={"passed":50,"failed":0,"total":50})
        ck("F064_DENIED_FINAL",all(g.get(k) is False for k in DENIED))
        ck("F065_ATTEMPT_FINAL",g.get("attempt_count")==0 and g.get("maximum_attempts")==1)
    failed=[x for x in checks if x["status"]!="PASS"]
    return checks,failed

def main():
    ap=argparse.ArgumentParser(); x=ap.add_mutually_exclusive_group(required=True); x.add_argument("--write-candidate",action="store_true"); x.add_argument("--verify-final",action="store_true"); args=ap.parse_args()
    checks,failed=verify(args.verify_final)
    result={"record_type":"V0_3_RUNTIME_VALIDATION_AUTHORIZATION_FREEZE_VERIFICATION_RESULT_V1","schema_version":"1.0","governance_identity":GOV_ID,"phase":"FREEZE_CANDIDATE" if args.write_candidate else "FINAL_READ_ONLY","status":"PASS" if not failed else "FAIL_CLOSED","checks_total":len(checks),"checks_passed":len(checks)-len(failed),"checks_failed":len(failed),"failed":failed,"checks":checks,"operation_counters":load("TYPED_AUTHORITY_CEILING.json")["operation_counters"]}
    if args.write_candidate:
        p=ROOT/"FREEZE_VERIFICATION_RESULT.json"
        if p.exists() or p.is_symlink(): raise SystemExit("append-only collision")
        p.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"phase":result["phase"],"status":result["status"],"passed":result["checks_passed"],"total":result["checks_total"]},sort_keys=True))
    if failed: raise SystemExit(1)

if __name__=="__main__": main()
