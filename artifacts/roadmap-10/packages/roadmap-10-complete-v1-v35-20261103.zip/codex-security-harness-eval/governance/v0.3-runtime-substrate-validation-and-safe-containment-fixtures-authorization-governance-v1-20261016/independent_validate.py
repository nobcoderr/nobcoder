#!/usr/bin/env python3
"""Independent governance verifier with separate logic."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PRE = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016")
GOV_ID = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_AUTHORIZATION_GOVERNANCE_V1"
FUTURE_ID = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V1"
WORKSPACE = Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016")
EXPECTED = {
    "CONTRACT_LOCK.json": "a6f4f74b0a056e04959146a065103f375ec525f102530e4cb3e267f36d266a35",
    "CONTRACT_ARTIFACT_MANIFEST.json": "0a963d519ba3f9d14e22c8b8ec3cf125284a2d195f8089be21624ad98533aa03",
    "GOVERNANCE_LOCK.json": "77cc5e94b5b578f8a4bf828cb77de24df69b4d231804f7727a073144960034a7",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "7ee4baf60f2e55f3eab86951766dff63d79360f6fd572300da6047ec3aa02fd4",
}
DENIED = {
    "general_runtime_execution_authorized", "real_worker_execution_authorized",
    "subagent_execution_authorized", "codex_cli_invocation_authorized",
    "target_operation_authorized", "external_network_operation_authorized",
    "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized", "exploit_replay_authorized", "v0_3_b0_authorized",
}


def load(name: str) -> dict[str, object]:
    value = json.loads((ROOT/name).read_text())
    if not isinstance(value, dict): raise TypeError(name)
    return value


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    out = ROOT/"INDEPENDENT_VALIDATION_RESULT_RUN-0002.json"
    if out.exists() or out.is_symlink(): raise SystemExit("append-only collision")
    checks=[]
    def ck(cid, ok, detail=None): checks.append({"check_id":cid,"status":"PASS" if bool(ok) else "FAIL","detail":detail})

    files = [
        "PREDECESSOR_CONTRACT_BINDING.json", "AUTHORIZATION_DECISION.json",
        "RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json", "TYPED_AUTHORITY_CEILING.json",
        "SINGLE_USE_EXECUTION_CONTRACT.json", "RUNTIME_SUBSTRATE_INSPECTION_CONTRACT.json",
        "TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json", "PROCESS_NETWORK_IPC_POLICY.json",
        "CONTROL_PLANE_AND_EVIDENCE_SEPARATION.json", "SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json",
        "EVIDENCE_CAPTURE_CONTRACT.json", "STATIC_AND_RUNTIME_GATE_MATRIX.json",
        "FAIL_CLOSED_AND_SINGLE_USE_FAILURE_CONTRACT.json", "INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json",
        "PRIOR_ART_BOUNDARY.json", "OPERATION_AUTHORIZATION_MATRIX.json", "ROUTING_AND_SCOPE_DECISION.json",
        "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
        "GOVERNANCE_TEST_RESULT_RUN-0002.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json",
    ]
    ck("I001_FILES", all((ROOT/n).is_file() for n in files))
    ck("I002_NO_SYMLINK", all(not (ROOT/n).is_symlink() for n in files))
    ck("I003_PARSE", all(isinstance(load(n),dict) for n in files))
    for i,(name,digest) in enumerate(EXPECTED.items(),4): ck(f"I{i:03d}_{name}",sha(PRE/name)==digest)
    pm= json.loads((PRE/"GOVERNANCE_ARTIFACT_MANIFEST.json").read_text())
    ck("I008_PRE_MEMBER_COUNT",pm.get("member_count")==34)
    ck("I009_PRE_DIGESTS",all(sha(PRE/x["path"])==x["sha256"] for x in pm["members"]))
    ck("I010_PRE_COUNTERS",all(v==0 for v in json.loads((PRE/"GOVERNANCE_LOCK.json").read_text())["operation_counters"].values()))
    ck("I011_WORKSPACE_ABSENT",not WORKSPACE.exists() and not WORKSPACE.is_symlink())

    decision=load("AUTHORIZATION_DECISION.json"); authority=load("TYPED_AUTHORITY_CEILING.json")
    ck("I012_GOV_ID",decision.get("governance_identity")==GOV_ID)
    ck("I013_DECISION",decision.get("decision")=="AUTHORIZE_MINIMAL_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_ONLY")
    ck("I014_FUTURE_ID",decision.get("future_identity")==FUTURE_ID)
    ck("I015_FUTURE_STATE",decision.get("future_state")=="CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    ck("I016_ATTEMPT_ZERO",decision.get("attempt_count")==0)
    ck("I017_MAX_ONE",decision.get("maximum_attempts")==1)
    ck("I018_SEPARATE_ACCEPTANCE",decision.get("separate_acceptance_after_success")=="REQUIRED")
    ck("I019_DECISION_AUTHORITY_PARITY",decision.get("authority")==authority)
    ck("I020_DEFAULT_DENY",authority.get("default")=="DENY")
    ck("I021_EXACT_DENIED_FIELDS",all(authority.get(k) is False for k in DENIED))
    ck("I022_ALLOWED_FIELDS",all(authority.get(k) is True for k in ["future_workspace_creation_authorized","validation_tooling_implementation_authorized","static_validation_and_lock_authorized","read_only_runtime_identity_inspection_authorized","runtime_substrate_validation_authorized","safe_containment_fixture_execution_authorized"]))
    ck("I023_CONDITIONAL_FIXTURE",str(authority.get("safe_containment_fixture_execution_condition","")).startswith("CONDITIONAL_SINGLE_USE"))
    ck("I024_COUNTER_KEYSET",set(authority.get("operation_counters",{}))=={"runtime_validation_attempts","containment_fixture_attempts","real_worker_processes","subagent_processes","codex_cli_invocations","target_operations","external_network_operations","parallel_operations","capability_edges","candidate_promotions","submission_operations","exploit_replays"})
    ck("I025_COUNTERS_ZERO",all(v==0 and type(v) is int for v in authority.get("operation_counters",{}).values()))
    ck("I026_UNKNOWN_FAILS",authority.get("unknown_authority_field")=="FAIL_CLOSED")

    ident=load("RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json")
    ck("I027_IDENTITY",ident.get("execution_identity")==FUTURE_ID)
    ck("I028_OPERATION",ident.get("operation")=="V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V1")
    ck("I029_WORKSPACE",ident.get("workspace")==str(WORKSPACE))
    ck("I030_PATH_SEPARATION",len({ident.get("fixture_writable_host_path"),ident.get("host_side_evidence_path"),ident.get("workspace")})==3)
    ck("I031_EVIDENCE_PATH",ident.get("host_side_evidence_path")==str(WORKSPACE/"evidence-v1"))
    ck("I032_RUN_PATH",ident.get("fixture_writable_host_path")==str(WORKSPACE/"run-v1"))

    single=load("SINGLE_USE_EXECUTION_CONTRACT.json")
    ck("I033_TRANSITION",single.get("attempt_transition")=="0_TO_1_IMMEDIATELY_BEFORE_CANONICAL_BWRAP_STRACE_PIPELINE_START")
    ck("I034_PRELIMINARY_DENIED",single.get("preliminary_execution_under_same_identity")=="PROHIBITED")
    ck("I035_TERMINAL",single.get("failure_after_start")=="FAIL_CLOSED_TERMINAL_NO_RETRY")
    ck("I036_PATCH_DENIED",single.get("patch_relock_or_reclassify_after_start")=="PROHIBITED")
    ck("I037_AMBIGUOUS_CONSUMED",single.get("missing_or_ambiguous_consumption_evidence")=="CONSUMED_FAIL_CLOSED")

    inspect=load("RUNTIME_SUBSTRATE_INSPECTION_CONTRACT.json")
    ck("I038_INSPECTION_COUNT",len(inspect.get("inspection_classes",[]))==11)
    ck("I039_RUNTIME_INSIDE_ATTEMPT",inspect.get("runtime_observation")=="MUST_OCCUR_INSIDE_THE_SINGLE_CANONICAL_ATTEMPT")
    ck("I040_HOST_OBSERVATION",inspect.get("host_side_observation_required") is True)
    ck("I041_CODEX_EXCLUDED","EXCLUDED" in str(inspect.get("codex_runtime")))
    ck("I042_VMM_EXCLUDED","EXCLUDED" in str(inspect.get("vmm_hypervisor")))

    topo=load("TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json"); ops=topo.get("semantic_mount_order",[])
    ck("I043_MOUNT_COUNT",len(ops)==4)
    ck("I044_MOUNT_ORDER",[x.get("type") for x in ops]==["ROOT_READ_ONLY_BIND","EPHEMERAL_PARENT_TMPFS","DESTINATION_DIRECTORY_CREATE","AUTHORIZED_FIXTURE_RW_BIND"])
    ck("I045_ROOT_RO",topo.get("host_root")=="READ_ONLY")
    ck("I046_ONE_RW_BIND",topo.get("sandbox_persistent_writable_bind_count")==1)
    ck("I047_EVIDENCE_HIDDEN_RW",topo.get("evidence_path_visible_or_writable_to_fixture") is False)
    ck("I048_SEMANTIC_VALIDATION",str(topo.get("validation","")).startswith("SEMANTIC_"))
    ck("I049_PATH_ESCAPE_DENIED",topo.get("symlink_alias_overlap_or_path_traversal")=="PROHIBITED")
    ck("I050_NO_FALLBACK",topo.get("unsandboxed_fallback")=="PROHIBITED")

    proc=load("PROCESS_NETWORK_IPC_POLICY.json")
    ck("I051_EXEC_ALLOWLIST",set(proc.get("expected_executable_classes",[]))=={"PINNED_BUBBLEWRAP","PINNED_STRACE","PINNED_PYTHON_FIXTURE_RUNTIME"})
    ck("I052_EXACT_BINARY_BINDING",str(proc.get("exact_paths_digests_argv_and_lineage","")).startswith("MUST_BE_STATICALLY_LOCKED"))
    ck("I053_TRACE_COMPLETE",str(proc.get("trace_scope","")).startswith("COMPLETE_"))
    ck("I054_TRACE_FAILS",proc.get("trace_missing_truncated_or_unattributed")=="FAIL_CLOSED")
    ck("I055_NET_ISOLATED",proc.get("network_namespace")=="ISOLATED_NO_HOST_BACKED_NETWORK_PATH")
    ck("I056_EXTERNAL_ZERO",proc.get("external_network_requests")=="PROHIBITED_ZERO")
    ck("I057_NO_TUN_TAP",proc.get("tun_tap_virtio_bridge_raw_socket")=="PROHIBITED")
    ck("I058_NO_WORKER_CODEX",proc.get("worker_subagent_codex_process")=="PROHIBITED")

    control=load("CONTROL_PLANE_AND_EVIDENCE_SEPARATION.json")
    ck("I059_PROTECTED_LIST",len(control.get("fixture_cannot_access",[]))==8)
    ck("I060_MONITOR_EXTERNAL",str(control.get("monitor_and_kill_location","")).startswith("HOST_SIDE_OUTSIDE"))
    ck("I061_HOST_EVIDENCE",control.get("evidence_writer")=="HOST_SIDE_APPEND_ONLY_CONTENT_ADDRESSED")
    ck("I062_FIXTURE_UNTRUSTED",control.get("fixture_output")=="UNTRUSTED_INPUT_TO_HOST_SIDE_VALIDATOR")
    ck("I063_NO_SELF_VERDICT",control.get("fixture_cannot_finalize_verdict") is True)
    ck("I064_NO_SELF_PROMOTION",control.get("fixture_cannot_promote_candidate") is True)

    fixtures=load("SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json"); fx=fixtures.get("fixtures",[])
    ck("I065_FIXED_FIXTURE",fixtures.get("fixture_workload")=="FIXED_INERT_PYTHON_WORKLOAD_NOT_A_WORKER_NOT_CODEX")
    ck("I066_FIXTURE_COUNT",len(fx)==fixtures.get("fixture_count")==9)
    ck("I067_NO_NETWORK_FIXTURES",all(x.get("network") is False for x in fx))
    ck("I068_NONDESTRUCTIVE_FIXTURES",all(x.get("destructive") is False for x in fx))
    ck("I069_UNIQUE_FIXTURES",len({x.get("fixture_id") for x in fx})==9)
    ck("I070_ORACLES",all(x.get("oracle") for x in fx))
    ck("I071_NO_EXPLOIT",fixtures.get("exploit_payload_or_prior_art_replay")=="PROHIBITED")
    ck("I072_NO_PLUGIN",fixtures.get("arbitrary_command_or_plugin_loading")=="PROHIBITED")

    evidence=load("EVIDENCE_CAPTURE_CONTRACT.json")
    ck("I073_EVIDENCE_HOST",evidence.get("host_side_destination")==str(WORKSPACE/"evidence-v1"))
    ck("I074_NOT_VISIBLE_RW",evidence.get("destination_not_mounted_writable_to_fixture") is True)
    ck("I075_RAW_FIRST",evidence.get("raw_evidence_first") is True)
    ck("I076_CAPTURE_PRE_COUNT",len(evidence.get("capture_before_fixture_body",[]))==7)
    ck("I077_CAPTURE_POST_COUNT",len(evidence.get("capture_during_and_after",[]))==9)
    ck("I078_MISSING_TERMINAL",evidence.get("missing_raw_mountinfo_or_trace")=="FAIL_CLOSED_TERMINAL")
    ck("I079_SHA256",evidence.get("content_addressing")=="SHA256_EXACT_BYTES")
    ck("I080_NONCIRCULAR",evidence.get("manifest")=="COMPLETE_NON_CIRCULAR")

    gates=load("STATIC_AND_RUNTIME_GATE_MATRIX.json")
    ck("I081_STATIC_GATES",len(gates.get("pre_attempt_static_gates",[]))==12)
    ck("I082_RUNTIME_GATES",len(gates.get("inside_attempt_before_fixture_gates",[]))==10)
    ck("I083_HUMAN_GATE","HUMAN_ACTIVATION_GATE_PASS" in gates.get("pre_attempt_static_gates",[]))
    ck("I084_LOCK_GATE","SOURCE_MANIFEST_AND_STATIC_EXECUTION_LOCK_PASS" in gates.get("pre_attempt_static_gates",[]))
    ck("I085_FAIL_BEFORE",gates.get("gate_failure_before_start")=="BLOCK_BEFORE_ATTEMPT")
    ck("I086_FAIL_AFTER",gates.get("gate_failure_after_start")=="FAIL_CLOSED_TERMINAL_NO_RETRY")

    failure=load("FAIL_CLOSED_AND_SINGLE_USE_FAILURE_CONTRACT.json")
    ck("I087_TERMINAL_CONDITIONS",len(set(failure.get("terminal_conditions",[])))==17)
    ck("I088_NO_RETRY",failure.get("retry")=="PROHIBITED_AFTER_ATTEMPT_START")
    ck("I089_NO_PARTIAL_PASS",failure.get("runtime_or_worker_pass_from_partial_evidence")=="PROHIBITED")

    ind=load("INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json")
    ck("I090_INDEPENDENT_REQUIRED",ind.get("independent_implementation_required") is True)
    ck("I091_SAME_EVIDENCE",ind.get("same_frozen_evidence_required") is True)
    ck("I092_REVIEW_COUNT",len(ind.get("required_reviews",[]))==14)
    ck("I093_DISAGREEMENT_BLOCKS",ind.get("disagreement_or_missing_evidence")=="BLOCKED_OR_FAIL_CLOSED_NO_PASS")
    ck("I094_SEPARATE_ACCEPTANCE",str(ind.get("successful_technical_run","")).startswith("REQUIRES_SEPARATE_"))
    ck("I095_NO_RUNTIME_LOCK",ind.get("runtime_pass_locked_issued_here") is False)
    ck("I096_NO_WORKER_AUTH",ind.get("worker_execution_authority_issued_here") is False)

    pa=load("PRIOR_ART_BOUNDARY.json").get("pwnescape",{})
    ck("I097_PWNESCAPE_REFERENCE",pa.get("classification")=="PUBLIC_PRIOR_ART_REFERENCE")
    ck("I098_PWNESCAPE_NO_FINDING",pa.get("new_finding") is False)
    ck("I099_PWNESCAPE_NO_AUTH",pa.get("execution_authorization") is False and pa.get("exploit_or_PoC_replay_authorized") is False)

    matrix=load("OPERATION_AUTHORIZATION_MATRIX.json").get("operations",{})
    ck("I100_OPERATION_ALLOW_COUNT",sum(1 for v in matrix.values() if str(v).startswith("AUTHORIZED") or str(v).startswith("CONDITIONAL"))==5)
    ck("I101_OPERATION_DENY_COUNT",sum(1 for v in matrix.values() if v=="NOT_AUTHORIZED")==7)
    ck("I102_NO_REAL_WORKER",matrix.get("EXECUTE_REAL_WORKER_SUBAGENT_OR_CODEX")=="NOT_AUTHORIZED")
    ck("I103_NO_TARGET_NET",matrix.get("ACCESS_TARGET_OR_EXTERNAL_NETWORK")=="NOT_AUTHORIZED")
    ck("I104_NO_EXPLOIT_REPLAY",matrix.get("REPLAY_EXPLOIT_OR_PWNESCAPE_POC")=="NOT_AUTHORIZED")

    route=load("ROUTING_AND_SCOPE_DECISION.json")
    ck("I105_ROUTE",route.get("scope")=="GOVERNANCE_ONLY_AUTHORIZATION")
    ck("I106_NO_TARGET",route.get("target_scope_card")=="NOT_APPLICABLE_NO_TARGET")
    ck("I107_NO_SUBAGENTS",route.get("subagents")=="NOT_USED_NOT_AUTHORIZED")
    ck("I108_NO_TOOL_EXEC",route.get("external_tools")=="NOT_EXECUTED")
    ck("I109_ROUTE_ZERO",all(v==0 for v in route.get("operations_this_milestone",{}).values()))

    nxt=load("NEXT_LEGAL_MILESTONE.json")
    ck("I110_NEXT",nxt.get("milestone")=="IMPLEMENT_AND_VALIDATE_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V1")
    ck("I111_NEXT_CONDITIONAL",nxt.get("status")=="CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_STARTED")
    ck("I112_NEXT_ATTEMPT",nxt.get("attempt_count")==0 and nxt.get("maximum_attempts")==1)
    ck("I113_NEXT_SEPARATE_ACCEPT",nxt.get("next_after_success")=="SEPARATE_FROZEN_EVIDENCE_ACCEPTANCE_AND_RUNTIME_LOCK_GOVERNANCE")
    ck("I114_WORKER_STILL_SEPARATE",nxt.get("worker_execution_after_success")=="STILL_REQUIRES_SEPARATE_AUTHORIZATION")

    primary=load("GOVERNANCE_TEST_RESULT_RUN-0002.json"); negative=load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    ck("I115_PRIMARY_PASS",primary.get("status")=="PASS" and primary.get("checks_failed")==0)
    ck("I116_PRIMARY_COUNT",primary.get("checks_total")==121 and primary.get("checks_passed")==121)
    ck("I117_NEGATIVE_PASS",negative.get("status")=="PASS" and negative.get("tests_failed")==0)
    ck("I118_NEGATIVE_COUNT",negative.get("tests_total")==32 and negative.get("tests_passed")==32)
    ck("I119_RESULT_COUNTERS",primary.get("operation_counters")==negative.get("operation_counters")==authority.get("operation_counters"))

    imports=set(); calls=[]
    for p in ROOT.glob("*.py"):
        tree=ast.parse(p.read_text())
        for node in ast.walk(tree):
            if isinstance(node,ast.Import): imports.update(x.name.split('.')[0] for x in node.names)
            elif isinstance(node,ast.ImportFrom) and node.module: imports.add(node.module.split('.')[0])
            elif isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in {"system","popen","execv","execve","spawn","fork"}: calls.append(node.func.attr)
    ck("I120_NO_EXEC_IMPORT",not imports.intersection({"subprocess","socket","urllib","requests","httpx","asyncio"}),sorted(imports))
    ck("I121_NO_PROCESS_CALL",not calls,calls)

    failed=[x for x in checks if x["status"]!="PASS"]
    result={"record_type":"V0_3_RUNTIME_VALIDATION_AUTHORIZATION_INDEPENDENT_VALIDATION_RESULT_V1","schema_version":"1.0","governance_identity":GOV_ID,"run_id":"INDEPENDENT_VALIDATION_RESULT_RUN-0002","independence":"SEPARATE_IMPLEMENTATION_DOES_NOT_IMPORT_PRIMARY_VALIDATOR","status":"PASS" if not failed else "FAIL_CLOSED","checks_total":len(checks),"checks_passed":len(checks)-len(failed),"checks_failed":len(failed),"failed":failed,"checks":checks,"operation_counters":authority["operation_counters"],"validated_input_digests":{n:sha(ROOT/n) for n in files}}
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"status":result["status"],"passed":result["checks_passed"],"total":result["checks_total"]},sort_keys=True))
    if failed: raise SystemExit(1)


if __name__=="__main__": main()
