#!/usr/bin/env python3
"""Primary governance validation and inert negative authorization fixtures."""

from __future__ import annotations

import ast
import copy
import hashlib
import json
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PRE = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016")
GOV_ID = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_AUTHORIZATION_GOVERNANCE_V1"
FUTURE_ID = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V1"
WORKSPACE = Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v1-20261016")
EXPECTED = {
    "CONTRACT_LOCK.json": "a6f4f74b0a056e04959146a065103f375ec525f102530e4cb3e267f36d266a35",
    "CONTRACT_ARTIFACT_MANIFEST.json": "0a963d519ba3f9d14e22c8b8ec3cf125284a2d195f8089be21624ad98533aa03",
    "GOVERNANCE_LOCK.json": "77cc5e94b5b578f8a4bf828cb77de24df69b4d231804f7727a073144960034a7",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "7ee4baf60f2e55f3eab86951766dff63d79360f6fd572300da6047ec3aa02fd4",
}
DENIED = [
    "general_runtime_execution_authorized", "real_worker_execution_authorized",
    "subagent_execution_authorized", "codex_cli_invocation_authorized",
    "target_operation_authorized", "external_network_operation_authorized",
    "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized", "exploit_replay_authorized", "v0_3_b0_authorized",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, object]:
    value = json.loads((ROOT / name).read_text())
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def write_once(name: str, value: object) -> None:
    p = ROOT / name
    if p.exists() or p.is_symlink():
        raise SystemExit(f"append-only collision: {name}")
    p.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def base_model() -> dict[str, object]:
    authority = load("TYPED_AUTHORITY_CEILING.json")
    identity = load("RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json")
    topology = load("TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json")
    process = load("PROCESS_NETWORK_IPC_POLICY.json")
    control = load("CONTROL_PLANE_AND_EVIDENCE_SEPARATION.json")
    evidence = load("EVIDENCE_CAPTURE_CONTRACT.json")
    single = load("SINGLE_USE_EXECUTION_CONTRACT.json")
    independent = load("INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json")
    prior = load("PRIOR_ART_BOUNDARY.json")
    return {
        "predecessor_pass": load("PREDECESSOR_CONTRACT_BINDING.json").get("status") == "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
        "workspace_absent": not WORKSPACE.exists() and not WORKSPACE.is_symlink(),
        "default_deny": authority.get("default") == "DENY",
        **{k: authority.get(k) for k in DENIED},
        "maximum_attempts": identity.get("maximum_attempts"),
        "attempt_count": identity.get("attempt_count"),
        "unsandboxed_fallback_prohibited": topology.get("unsandboxed_fallback") == "PROHIBITED",
        "evidence_path_visible_or_writable_to_fixture": topology.get("evidence_path_visible_or_writable_to_fixture"),
        "sandbox_persistent_writable_bind_count": topology.get("sandbox_persistent_writable_bind_count"),
        "semantic_argv_required": str(topology.get("validation", "")).startswith("SEMANTIC_"),
        "trace_complete_required": str(process.get("trace_scope", "")).startswith("COMPLETE_"),
        "raw_mountinfo_required": "raw_mountinfo" in evidence.get("capture_before_fixture_body", []),
        "worker_metadata_authoritative": control.get("fixture_output") != "UNTRUSTED_INPUT_TO_HOST_SIDE_VALIDATOR",
        "monitor_outside_worker": str(control.get("monitor_and_kill_location", "")).startswith("HOST_SIDE_OUTSIDE"),
        "external_packet_allowed": process.get("external_network_requests") != "PROHIBITED_ZERO",
        "arbitrary_plugin_allowed": load("SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json").get("arbitrary_command_or_plugin_loading") != "PROHIBITED",
        "pwnescape_execution_authorization": prior.get("pwnescape", {}).get("execution_authorization"),
        "automatic_retry": single.get("failure_after_start") != "FAIL_CLOSED_TERMINAL_NO_RETRY",
        "separate_acceptance_required": independent.get("successful_technical_run") == "REQUIRES_SEPARATE_FROZEN_EVIDENCE_ACCEPTANCE_GOVERNANCE",
        "operation_counters": authority.get("operation_counters"),
        "unknown_authority_field_fail_closed": authority.get("unknown_authority_field") == "FAIL_CLOSED",
    }


def model_valid(m: dict[str, object]) -> bool:
    if not (m.get("predecessor_pass") and m.get("workspace_absent") and m.get("default_deny")):
        return False
    if any(m.get(k) is not False for k in DENIED):
        return False
    if m.get("maximum_attempts") != 1 or m.get("attempt_count") != 0:
        return False
    for key in ["unsandboxed_fallback_prohibited", "semantic_argv_required", "trace_complete_required", "raw_mountinfo_required", "monitor_outside_worker", "separate_acceptance_required", "unknown_authority_field_fail_closed"]:
        if m.get(key) is not True:
            return False
    for key in ["evidence_path_visible_or_writable_to_fixture", "worker_metadata_authoritative", "external_packet_allowed", "arbitrary_plugin_allowed", "pwnescape_execution_authorization", "automatic_retry"]:
        if m.get(key) is not False:
            return False
    if m.get("sandbox_persistent_writable_bind_count") != 1:
        return False
    counters = m.get("operation_counters")
    return isinstance(counters, dict) and bool(counters) and all(v == 0 and isinstance(v, int) and not isinstance(v, bool) for v in counters.values())


def mutate(model: dict[str, object], dotted: str, value: object) -> None:
    node = model
    bits = dotted.split(".")
    for bit in bits[:-1]:
        child = node.get(bit)
        if not isinstance(child, dict):
            raise ValueError(dotted)
        node = child
    node[bits[-1]] = value


def main() -> None:
    checks: list[dict[str, object]] = []
    def ck(name: str, value: object, evidence: object = None) -> None:
        checks.append({"check_id": name, "status": "PASS" if bool(value) else "FAIL", "evidence": evidence})

    source_files = [
        "PREDECESSOR_CONTRACT_BINDING.json", "AUTHORIZATION_DECISION.json",
        "RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json", "TYPED_AUTHORITY_CEILING.json",
        "SINGLE_USE_EXECUTION_CONTRACT.json", "RUNTIME_SUBSTRATE_INSPECTION_CONTRACT.json",
        "TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json", "PROCESS_NETWORK_IPC_POLICY.json",
        "CONTROL_PLANE_AND_EVIDENCE_SEPARATION.json", "SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json",
        "EVIDENCE_CAPTURE_CONTRACT.json", "STATIC_AND_RUNTIME_GATE_MATRIX.json",
        "FAIL_CLOSED_AND_SINGLE_USE_FAILURE_CONTRACT.json",
        "INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json", "PRIOR_ART_BOUNDARY.json",
        "OPERATION_AUTHORIZATION_MATRIX.json", "ROUTING_AND_SCOPE_DECISION.json",
        "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    ]
    ck("G001_SOURCE_FILES_PRESENT", all((ROOT / n).is_file() for n in source_files))
    ck("G002_NO_SOURCE_SYMLINK", all(not (ROOT / n).is_symlink() for n in source_files))
    ck("G003_JSON_OBJECTS", all(isinstance(load(n), dict) for n in source_files))
    for i, (name, digest) in enumerate(EXPECTED.items(), 4):
        ck(f"G{i:03d}_PREDECESSOR_{name}", sha(PRE / name) == digest)
    pre = load("PREDECESSOR_CONTRACT_BINDING.json")
    ck("G008_PREDECESSOR_STATUS", pre.get("status") == "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY")
    ck("G009_PREDECESSOR_ROOT", pre.get("canonical_artifact_root_sha256") == "9a7e5116a7007e29e8b7db8ebcec919ffc4993e5693cc2d9c55653b20c620332")
    ck("G010_RUNNER_NO_REPLAY", pre.get("fixture_runner_v2") == "PASS_LOCKED_NO_REPLAY")
    ck("G011_PREDECESSOR_COUNTERS_ZERO", all(v == 0 for v in pre.get("predecessor_operation_counters", {}).values()))
    ck("G012_PREDECESSOR_FILES_RO", all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in PRE.iterdir() if p.is_file()))
    ck("G013_PREDECESSOR_ROOT_RO", stat.S_IMODE(PRE.stat().st_mode) == 0o555)

    decision = load("AUTHORIZATION_DECISION.json")
    ck("G014_GOV_ID", decision.get("governance_identity") == GOV_ID)
    ck("G015_DECISION", decision.get("decision") == "AUTHORIZE_MINIMAL_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_ONLY")
    ck("G016_DECISION_STATUS", decision.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    ck("G017_FUTURE_IDENTITY", decision.get("future_identity") == FUTURE_ID)
    ck("G018_FUTURE_STATE", decision.get("future_state") == "CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    ck("G019_ONE_ATTEMPT", decision.get("attempt_count") == 0 and decision.get("maximum_attempts") == 1)
    ck("G020_SEPARATE_ACCEPTANCE", decision.get("separate_acceptance_after_success") == "REQUIRED")

    authority = load("TYPED_AUTHORITY_CEILING.json")
    ck("G021_AUTH_DEFAULT_DENY", authority.get("default") == "DENY")
    ck("G022_FUTURE_WORKSPACE_ALLOWED", authority.get("future_workspace_creation_authorized") is True)
    ck("G023_TOOLING_ALLOWED", authority.get("validation_tooling_implementation_authorized") is True)
    ck("G024_STATIC_ALLOWED", authority.get("static_validation_and_lock_authorized") is True)
    ck("G025_INSPECTION_ALLOWED", authority.get("read_only_runtime_identity_inspection_authorized") is True)
    ck("G026_RUNTIME_VALIDATION_ALLOWED", authority.get("runtime_substrate_validation_authorized") is True)
    ck("G027_SAFE_FIXTURE_ALLOWED", authority.get("safe_containment_fixture_execution_authorized") is True)
    ck("G028_SAFE_FIXTURE_CONDITIONAL", str(authority.get("safe_containment_fixture_execution_condition", "")).startswith("CONDITIONAL_SINGLE_USE"))
    for i, key in enumerate(DENIED, 29):
        ck(f"G{i:03d}_{key.upper()}_FALSE", authority.get(key) is False)
    ck("G041_AUTH_COUNTERS_ZERO", all(v == 0 for v in authority.get("operation_counters", {}).values()))
    ck("G042_UNKNOWN_AUTH_FAILS", authority.get("unknown_authority_field") == "FAIL_CLOSED")

    identity = load("RUNTIME_VALIDATION_IDENTITY_AND_PATH_BINDING.json")
    ck("G043_WORKSPACE_ABSENT", not WORKSPACE.exists() and not WORKSPACE.is_symlink())
    ck("G044_EXACT_WORKSPACE", identity.get("workspace") == str(WORKSPACE))
    ck("G045_EXACT_RUN", identity.get("fixture_writable_host_path") == str(WORKSPACE / "run-v1"))
    ck("G046_EXACT_EVIDENCE", identity.get("host_side_evidence_path") == str(WORKSPACE / "evidence-v1"))
    ck("G047_EXACT_SANDBOX", identity.get("sandbox_fixture_destination") == "/run/v0-3-runtime-substrate-fixtures-v1")

    single = load("SINGLE_USE_EXECUTION_CONTRACT.json")
    ck("G048_ATTEMPT_TRANSITION", str(single.get("attempt_transition", "")).startswith("0_TO_1_IMMEDIATELY"))
    ck("G049_NO_PRELIMINARY_EXEC", single.get("preliminary_execution_under_same_identity") == "PROHIBITED")
    ck("G050_FAILURE_TERMINAL", single.get("failure_after_start") == "FAIL_CLOSED_TERMINAL_NO_RETRY")
    ck("G051_AMBIGUOUS_CONSUMED", single.get("missing_or_ambiguous_consumption_evidence") == "CONSUMED_FAIL_CLOSED")

    inspection = load("RUNTIME_SUBSTRATE_INSPECTION_CONTRACT.json")
    ck("G052_INSPECTION_CLASS_COUNT", len(inspection.get("inspection_classes", [])) == 11)
    ck("G053_HOST_OBSERVATION", inspection.get("host_side_observation_required") is True)
    ck("G054_WORKER_REPORT_NONE", inspection.get("worker_report_authority") == "NONE")
    ck("G055_CODEX_EXCLUDED", str(inspection.get("codex_runtime", "")).startswith("EXCLUDED_"))
    ck("G056_VMM_EXCLUDED", str(inspection.get("vmm_hypervisor", "")).startswith("EXCLUDED_"))

    topology = load("TOPOLOGY_AND_WRITABLE_SCOPE_CONTRACT.json")
    order = [x.get("type") for x in topology.get("semantic_mount_order", [])]
    ck("G057_TOPOLOGY_ORDER", order == ["ROOT_READ_ONLY_BIND", "EPHEMERAL_PARENT_TMPFS", "DESTINATION_DIRECTORY_CREATE", "AUTHORIZED_FIXTURE_RW_BIND"])
    ck("G058_SEMANTIC_ARGV", str(topology.get("validation", "")).startswith("SEMANTIC_"))
    ck("G059_ROOT_RO", topology.get("host_root") == "READ_ONLY")
    ck("G060_ONE_WRITABLE_BIND", topology.get("sandbox_persistent_writable_bind_count") == 1)
    ck("G061_EVIDENCE_NOT_VISIBLE_RW", topology.get("evidence_path_visible_or_writable_to_fixture") is False)
    ck("G062_NO_UNSANDBOXED", topology.get("unsandboxed_fallback") == "PROHIBITED")

    process = load("PROCESS_NETWORK_IPC_POLICY.json")
    ck("G063_EXEC_CLASSES", set(process.get("expected_executable_classes", [])) == {"PINNED_BUBBLEWRAP", "PINNED_STRACE", "PINNED_PYTHON_FIXTURE_RUNTIME"})
    ck("G064_TRACE_COMPLETE", str(process.get("trace_scope", "")).startswith("COMPLETE_"))
    ck("G065_NETWORK_ISOLATED", process.get("network_namespace") == "ISOLATED_NO_HOST_BACKED_NETWORK_PATH")
    ck("G066_EXTERNAL_NETWORK_ZERO", process.get("external_network_requests") == "PROHIBITED_ZERO")
    ck("G067_TUN_TAP_DENIED", process.get("tun_tap_virtio_bridge_raw_socket") == "PROHIBITED")
    ck("G068_NO_WORKER_PROCESS", process.get("worker_subagent_codex_process") == "PROHIBITED")

    control = load("CONTROL_PLANE_AND_EVIDENCE_SEPARATION.json")
    ck("G069_CONTROL_SURFACE_COUNT", len(control.get("fixture_cannot_access", [])) == 8)
    ck("G070_MONITOR_HOST_SIDE", str(control.get("monitor_and_kill_location", "")).startswith("HOST_SIDE_OUTSIDE"))
    ck("G071_EVIDENCE_APPEND_ONLY", control.get("evidence_writer") == "HOST_SIDE_APPEND_ONLY_CONTENT_ADDRESSED")
    ck("G072_FIXTURE_UNTRUSTED", control.get("fixture_output") == "UNTRUSTED_INPUT_TO_HOST_SIDE_VALIDATOR")
    ck("G073_NO_VERDICT_OR_PROMOTION", control.get("fixture_cannot_finalize_verdict") is True and control.get("fixture_cannot_promote_candidate") is True)

    fixtures = load("SAFE_CONTAINMENT_FIXTURE_EXECUTION_CONTRACT.json")
    ck("G074_FIXED_INERT_WORKLOAD", fixtures.get("fixture_workload") == "FIXED_INERT_PYTHON_WORKLOAD_NOT_A_WORKER_NOT_CODEX")
    ck("G075_FIXTURE_COUNT", fixtures.get("fixture_count") == len(fixtures.get("fixtures", [])) == 9)
    ck("G076_FIXTURES_NO_NETWORK", all(x.get("network") is False for x in fixtures.get("fixtures", [])))
    ck("G077_FIXTURES_NONDESTRUCTIVE", all(x.get("destructive") is False for x in fixtures.get("fixtures", [])))
    ck("G078_NO_EXPLOIT_REPLAY", fixtures.get("exploit_payload_or_prior_art_replay") == "PROHIBITED")
    ck("G079_NO_ARBITRARY_PLUGIN", fixtures.get("arbitrary_command_or_plugin_loading") == "PROHIBITED")

    evidence = load("EVIDENCE_CAPTURE_CONTRACT.json")
    ck("G080_EVIDENCE_HOST_SIDE", evidence.get("host_side_destination") == str(WORKSPACE / "evidence-v1"))
    ck("G081_EVIDENCE_NOT_MOUNTED_RW", evidence.get("destination_not_mounted_writable_to_fixture") is True)
    ck("G082_RAW_FIRST", evidence.get("raw_evidence_first") is True)
    ck("G083_RAW_MOUNTINFO", "raw_mountinfo" in evidence.get("capture_before_fixture_body", []))
    ck("G084_TRACE_REQUIRED", "complete_strace_files" in evidence.get("capture_during_and_after", []))
    ck("G085_MISSING_TERMINAL", evidence.get("missing_raw_mountinfo_or_trace") == "FAIL_CLOSED_TERMINAL")

    gates = load("STATIC_AND_RUNTIME_GATE_MATRIX.json")
    ck("G086_STATIC_GATE_COUNT", len(gates.get("pre_attempt_static_gates", [])) == 12)
    ck("G087_RUNTIME_GATE_COUNT", len(gates.get("inside_attempt_before_fixture_gates", [])) == 10)
    ck("G088_BEFORE_START_BLOCK", gates.get("gate_failure_before_start") == "BLOCK_BEFORE_ATTEMPT")
    ck("G089_AFTER_START_TERMINAL", gates.get("gate_failure_after_start") == "FAIL_CLOSED_TERMINAL_NO_RETRY")
    ck("G090_NO_RELOCK", gates.get("source_mutation_after_lock") == "INVALIDATE_AND_STOP_NO_RELOCK")

    faildoc = load("FAIL_CLOSED_AND_SINGLE_USE_FAILURE_CONTRACT.json")
    ck("G091_FAILURE_COUNT", len(faildoc.get("terminal_conditions", [])) == 17)
    ck("G092_RETRY_PROHIBITED", faildoc.get("retry") == "PROHIBITED_AFTER_ATTEMPT_START")
    ck("G093_NO_PARTIAL_PASS", faildoc.get("runtime_or_worker_pass_from_partial_evidence") == "PROHIBITED")

    independent = load("INDEPENDENT_VALIDATION_AND_ACCEPTANCE_CONTRACT.json")
    ck("G094_INDEPENDENT", independent.get("independent_implementation_required") is True)
    ck("G095_SAME_EVIDENCE", independent.get("same_frozen_evidence_required") is True)
    ck("G096_REVIEW_COUNT", len(independent.get("required_reviews", [])) == 14)
    ck("G097_DISAGREEMENT_BLOCK", independent.get("disagreement_or_missing_evidence") == "BLOCKED_OR_FAIL_CLOSED_NO_PASS")
    ck("G098_SEPARATE_ACCEPTANCE_GOV", str(independent.get("successful_technical_run", "")).startswith("REQUIRES_SEPARATE_"))
    ck("G099_NO_RUNTIME_LOCK_HERE", independent.get("runtime_pass_locked_issued_here") is False)
    ck("G100_NO_WORKER_AUTH_HERE", independent.get("worker_execution_authority_issued_here") is False)

    prior = load("PRIOR_ART_BOUNDARY.json").get("pwnescape", {})
    ck("G101_PRIOR_ART", prior.get("classification") == "PUBLIC_PRIOR_ART_REFERENCE")
    ck("G102_NOT_FINDING", prior.get("new_finding") is False)
    ck("G103_NO_PWNESCAPE_AUTH", prior.get("execution_authorization") is False and prior.get("exploit_or_PoC_replay_authorized") is False)

    operations = load("OPERATION_AUTHORIZATION_MATRIX.json")
    ck("G104_OPERATION_DEFAULT_DENY", operations.get("default") == "DENY")
    ck("G105_REAL_WORKER_DENY", operations.get("operations", {}).get("EXECUTE_REAL_WORKER_SUBAGENT_OR_CODEX") == "NOT_AUTHORIZED")
    ck("G106_TARGET_NETWORK_DENY", operations.get("operations", {}).get("ACCESS_TARGET_OR_EXTERNAL_NETWORK") == "NOT_AUTHORIZED")
    ck("G107_EXPLOIT_DENY", operations.get("operations", {}).get("REPLAY_EXPLOIT_OR_PWNESCAPE_POC") == "NOT_AUTHORIZED")

    route = load("ROUTING_AND_SCOPE_DECISION.json")
    ck("G108_ROUTE_GOV_ONLY", route.get("scope") == "GOVERNANCE_ONLY_AUTHORIZATION")
    ck("G109_NO_TARGET_CARD", route.get("target_scope_card") == "NOT_APPLICABLE_NO_TARGET")
    ck("G110_NO_SUBAGENTS", route.get("subagents") == "NOT_USED_NOT_AUTHORIZED")
    ck("G111_NO_TOOLS", route.get("external_tools") == "NOT_EXECUTED")
    ck("G112_ROUTE_COUNTERS_ZERO", all(v == 0 for v in route.get("operations_this_milestone", {}).values()))

    next_step = load("NEXT_LEGAL_MILESTONE.json")
    ck("G113_NEXT_MILESTONE", next_step.get("milestone") == "IMPLEMENT_AND_VALIDATE_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V1")
    ck("G114_NEXT_CONDITIONAL", next_step.get("status") == "CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_STARTED")
    ck("G115_NEXT_ONE_ATTEMPT", next_step.get("attempt_count") == 0 and next_step.get("maximum_attempts") == 1)
    ck("G116_STOP_AFTER_FREEZE", str(next_step.get("stop_after", "")).endswith("EVIDENCE_FREEZE"))
    ck("G117_WORKER_STILL_SEPARATE", next_step.get("worker_execution_after_success") == "STILL_REQUIRES_SEPARATE_AUTHORIZATION")

    scripts = ["build_governance.py", "governance_self_test.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py"]
    imports: set[str] = set(); calls: list[str] = []
    for name in scripts:
        path = ROOT / name
        if not path.exists():
            continue
        tree = ast.parse(path.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import): imports.update(x.name.split(".")[0] for x in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module: imports.add(node.module.split(".")[0])
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in {"system", "popen", "execv", "execve", "spawn", "fork"}: calls.append(node.func.attr)
    ck("G118_NO_PROCESS_NETWORK_IMPORT", not imports.intersection({"subprocess", "socket", "urllib", "requests", "httpx", "asyncio"}), sorted(imports))
    ck("G119_NO_PROCESS_CALL", not calls, calls)

    matrix = load("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    results = []
    base = base_model()
    for case in matrix.get("cases", []):
        model = copy.deepcopy(base)
        mutate(model, case["field"], case["value"])
        actual = "ACCEPT" if model_valid(model) else "REJECT"
        results.append({"case_id": case["case_id"], "expected": case["expected"], "actual": actual, "pass": actual == case["expected"]})
    neg_failed = [x for x in results if not x["pass"]]
    ck("G120_NEGATIVE_COUNT", len(results) == 32)
    ck("G121_NEGATIVE_PASS", not neg_failed, neg_failed)

    failed = [x for x in checks if x["status"] != "PASS"]
    primary = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_GOVERNANCE_TEST_RESULT_V1",
        "schema_version": "1.0", "governance_identity": GOV_ID,
        "run_id": "GOVERNANCE_TEST_RESULT_RUN-0002",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed),
        "failed": failed, "checks": checks, "operation_counters": authority["operation_counters"],
        "validated_input_digests": {n: sha(ROOT/n) for n in source_files},
    }
    negative = {
        "record_type": "V0_3_RUNTIME_VALIDATION_AUTHORIZATION_NEGATIVE_TEST_RESULT_V1",
        "schema_version": "1.0", "governance_identity": GOV_ID,
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002",
        "status": "PASS" if not neg_failed else "FAIL_CLOSED",
        "tests_total": len(results), "tests_passed": len(results)-len(neg_failed), "tests_failed": len(neg_failed),
        "failed": neg_failed, "results": results, "operation_counters": authority["operation_counters"],
    }
    write_once("GOVERNANCE_TEST_RESULT_RUN-0002.json", primary)
    write_once("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json", negative)
    print(json.dumps({"primary":[primary["checks_passed"],primary["checks_total"]],"negative":[negative["tests_passed"],negative["tests_total"]],"status":primary["status"]},sort_keys=True))
    if failed or neg_failed: raise SystemExit(1)


if __name__ == "__main__":
    main()
