#!/usr/bin/env python3
"""Independent validation of the V11 provenance governance decision."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
PREV_LOCK = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-v11-independent-validator-source-order-anchor-defect-prelock-erratum-and-continuation-or-successor-decision-governance-v1-20261020/GOVERNANCE_LOCK.json")
OUT = ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CHAIN_STATIC_LOCK_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def main() -> None:
    if os.path.lexists(OUT):
        raise SystemExit("refusing to overwrite independent result")
    checks: list[dict[str, Any]] = []

    def check(cid: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": cid, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    disposition = read("V11_PRELOCK_DISPOSITION.json")
    bindings = read("EVIDENCE_INPUT_BINDINGS.json")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    provenance = read("NORMATIVE_PROVENANCE_CHAIN_DECISION.json")
    scope = read("CONTINUATION_V11_SCOPE_LOCK.json")
    decision = read("CONTINUATION_DECISION.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    negative_matrix = read("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")

    check("I001_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_failed"] == 0)
    check("I002_NEGATIVE_PASS", negative["status"] == "PASS" and negative["tests_passed"] == negative["tests_total"] == 12)
    check("I003_V11_STATUS", disposition["status"].startswith("FAIL_CLOSED_BEFORE_STATIC_LOCK"))
    check("I004_COUNTS_ZERO", disposition["attempt"] == "0_OF_1_NOT_CONSUMED" and disposition["worker_invocation"] == disposition["codex_as_worker_invocation"] == "0_OF_1")
    check("I005_NO_LOCK", not (V11 / "STATIC_EXECUTION_LOCK.json").exists())
    check("I006_NO_ATTEMPT", not (V11 / "static-run-v11/ATTEMPT_MARKER.json").exists())

    historical_path = V11 / "results/prelock/independent-static-validation-run-0001.json"
    historical = json.loads(historical_path.read_text(encoding="utf-8"))
    check("I007_HISTORICAL_HASH", digest(historical_path) == bindings["historical_v11_evidence"]["independent_run_0001_sha256"])
    check("I008_HISTORICAL_FAIL", historical["status"] == "FAIL_CLOSED" and historical["checks_passed"] == 94 and historical["checks_total"] == 95)
    check("I009_PRIOR_GOV_HASH", digest(PREV_LOCK) == bindings["prior_continuation_governance"]["lock_sha256"])
    prior = json.loads(PREV_LOCK.read_text(encoding="utf-8"))
    check("I010_PRIOR_GOV_PASS", prior["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")

    independent_source = V11 / "validators/independent_static_validate.py"
    tests_source = V11 / "tests/run_unit_fixtures.py"
    check("I011_CORRECTED_VALIDATOR_IDENTITY", digest(independent_source) == bindings["continuation_source_identity"]["validators/independent_static_validate.py"])
    check("I012_CORRECTED_TEST_IDENTITY", digest(tests_source) == bindings["continuation_source_identity"]["tests/run_unit_fixtures.py"])
    runner = V11 / "src/runner_v11.py"
    check("I013_RUNNER_PROTECTED", digest(runner) == bindings["continuation_source_identity"]["src/runner_v11.py"])

    check("I014_GAP_YES", ownership["continuation_evidence_provenance_binding_gap"] == "YES")
    check("I015_SELECTOR_YES", ownership["static_lock_current_evidence_selector_defect"] == "YES")
    check("I016_NO_CAUSAL_INVENTION", ownership["unproven_history_reconstruction"] == "PROHIBITED")
    check("I017_HISTORY_APPEND_ONLY", provenance["history_model"] == "APPEND_ONLY_VERSIONED_VALIDATION_EVIDENCE")
    check("I018_RUN0001_PRESERVED", provenance["historical_evidence"]["independent-static-validation-run-0001.json"]["role"] == "IMMUTABLE_HISTORICAL_FAILURE_EVIDENCE")
    check("I019_RUN0002_CURRENT", provenance["current_admissible_validation"]["required_identity"] == "independent-static-validation-run-0002.json")
    check("I020_RUN0002_AFTER_AUTH", provenance["current_admissible_validation"]["required_generation_time"] == "AFTER_CONTINUATION_AUTHORITY_GOVERNANCE_LOCK")
    check("I021_NO_HISTORY_REPLACEMENT", provenance["supersession_semantics"]["run_0002_replaces_or_invalidates_run_0001_as_history"] is False)
    check("I022_UNIQUE_CURRENT", provenance["current_readiness_selection"]["must_be_unique"] is True and provenance["current_readiness_selection"]["fallback_to_historical_failure_or_ambiguous_pass"] == "PROHIBITED")

    allow = set(scope["mutable_allowlist"])
    check("I023_ALLOWLIST_NARROW", len(allow) == 11 and "prepare_static_lock.py" in allow and "src/runner_v11.py" not in allow)
    protected = set(scope["must_not_change"])
    check("I024_EXECUTION_PROTECTED", {"src/runner_v11.py", "src/topology_observer_v11.py", "contracts/WORKER_REQUEST.json", "fixture/worker-prompt.txt"}.issubset(protected))
    check("I025_RUN0001_MUTATION_DENIED", scope["historical_run_0001_mutation"] == "PROHIBITED")
    check("I026_DECISION_CONTINUE", decision["decision"] == "CONTINUATION_V11_STATIC_LOCK_PROVENANCE_ONLY_CORRECTION_AUTHORIZED")
    check("I027_NO_CURRENT_ACTION", not decision["current_milestone_performs_correction"] and not decision["current_milestone_issues_static_lock"] and not decision["current_milestone_performs_execution"])
    check("I028_V12_DENIED", decision["v12"] == "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I029_COUNTERS_ZERO", all(value == 0 for value in authority["operation_counters"].values()))
    check("I030_MATRIX_EXACT", [row["id"] for row in negative_matrix["cases"]] == [f"N{i:03d}" for i in range(1, 13)])

    failures = [row for row in checks if row["status"] == "FAIL"]
    payload = {
        "governance_identity": IDENTITY,
        "record_type": "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT",
        "run_id": "INDEPENDENT_GOVERNANCE_VALIDATION_RUN-0001",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failures),
        "checks_failed": len(failures),
        "failure_ids": [row["check_id"] for row in failures],
        "checks": checks,
    }
    with OUT.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({k: payload[k] for k in ("status", "checks_passed", "checks_total", "failure_ids")}, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
