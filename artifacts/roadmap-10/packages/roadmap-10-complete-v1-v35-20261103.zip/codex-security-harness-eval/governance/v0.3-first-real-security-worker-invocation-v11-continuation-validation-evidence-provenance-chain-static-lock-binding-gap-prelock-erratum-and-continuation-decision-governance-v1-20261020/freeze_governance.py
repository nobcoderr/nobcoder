#!/usr/bin/env python3
"""Final freeze verification and immutable governance lock publication."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CHAIN_STATIC_LOCK_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"
DECISION = "CONTINUATION_V11_STATIC_LOCK_PROVENANCE_ONLY_CORRECTION_AUTHORIZED"
FINAL = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"
SOURCES = {
    "GOVERNANCE_CHARTER.json", "V11_PRELOCK_DISPOSITION.json", "EVIDENCE_INPUT_BINDINGS.json",
    "DEFECT_OWNERSHIP_DECISION.json", "NORMATIVE_PROVENANCE_CHAIN_DECISION.json",
    "CONTINUATION_V11_SCOPE_LOCK.json", "CONTINUATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "NEXT_LEGAL_MILESTONE.json", "validate_governance.py", "run_negative_governance_fixtures.py",
    "independent_validate.py", "freeze_governance.py", "verify_governance_freeze.py",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def canonical(rows: list[dict[str, Any]]) -> str:
    text = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_once(name: str, payload: dict[str, Any]) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite {name}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    expected = SOURCES | RESULTS
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"freeze input set mismatch: {sorted(actual ^ expected)}")
    checks: list[dict[str, Any]] = []

    def check(cid: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": cid, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(name for name in SOURCES if name.endswith(".py")):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            parsed = True
        except (SyntaxError, UnicodeDecodeError):
            parsed = False
        check("F_SCRIPT_" + script, parsed)
    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = load("INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    decision = load("CONTINUATION_DECISION.json")
    disposition = load("V11_PRELOCK_DISPOSITION.json")
    provenance = load("NORMATIVE_PROVENANCE_CHAIN_DECISION.json")
    scope = load("CONTINUATION_V11_SCOPE_LOCK.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    bindings = load("EVIDENCE_INPUT_BINDINGS.json")

    check("F001_PRIMARY", primary["status"] == "PASS" and primary["checks_failed"] == 0)
    check("F002_NEGATIVE", negative["status"] == "PASS" and negative["tests_passed"] == negative["tests_total"] == 12)
    check("F003_INDEPENDENT", independent["status"] == "PASS" and independent["checks_failed"] == 0)
    check("F004_DECISION", decision["decision"] == DECISION)
    check("F005_V11_PRELOCK", disposition["static_lock"] == "NOT_ISSUED" and disposition["attempt"] == "0_OF_1_NOT_CONSUMED")
    check("F006_V11_ACTUAL_LOCK_ABSENT", not os.path.lexists(V11 / "STATIC_EXECUTION_LOCK.json"))
    check("F007_V11_ACTUAL_ATTEMPT_ABSENT", not os.path.lexists(V11 / "static-run-v11/ATTEMPT_MARKER.json"))
    check("F008_HISTORICAL_RUN_HASH", sha(V11 / "results/prelock/independent-static-validation-run-0001.json") == bindings["historical_v11_evidence"]["independent_run_0001_sha256"])
    check("F009_RUNNER_HASH", sha(V11 / "src/runner_v11.py") == bindings["continuation_source_identity"]["src/runner_v11.py"])
    check("F010_HISTORY_MODEL", provenance["history_model"] == "APPEND_ONLY_VERSIONED_VALIDATION_EVIDENCE")
    check("F011_UNIQUE_CURRENT", provenance["current_readiness_selection"]["must_be_unique"] is True)
    check("F012_SCOPE", len(scope["mutable_allowlist"]) == 11 and scope["all_unlisted_v11_member_mutation"] == "PROHIBITED")
    check("F013_ZERO_COUNTERS", all(value == 0 for value in authority["operation_counters"].values()))
    check("F014_NO_RUNTIME", disposition["temporal_runtime"] == "NOT_ESTABLISHED" and disposition["confinement"] == "NOT_PROVEN")
    check("F015_V12_DENIED", decision["v12"] == "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")

    failures = [row for row in checks if row["status"] == "FAIL"]
    if failures:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failures))
    write_once(FINAL, {
        "record_type": "FINAL_FREEZE_VERIFICATION_RESULT",
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001",
        "status": "PASS",
        "checks_total": len(checks),
        "checks_passed": len(checks),
        "checks_failed": 0,
        "checks": checks,
    })
    members = sorted(expected | {FINAL})
    rows = [{"path": name, "bytes": (ROOT / name).stat().st_size, "sha256": sha(ROOT / name)} for name in members]
    root_digest = canonical(rows)
    write_once(MANIFEST, {
        "record_type": "GOVERNANCE_ARTIFACT_MANIFEST",
        "member_count": len(rows),
        "members": rows,
        "canonical_artifact_root_sha256": root_digest,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    write_once(LOCK, {
        "record_type": "GOVERNANCE_LOCK",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": DECISION,
        "continuation_evidence_provenance_binding_gap": "YES",
        "v11_state": "FAIL_CLOSED_BEFORE_STATIC_LOCK_ON_CONTINUATION_EVIDENCE_PROVENANCE_BINDING",
        "v11_attempt_count": 0,
        "v11_worker_invocation_count": 0,
        "v11_codex_as_worker_invocation_count": 0,
        "v11_static_lock": "NOT_ISSUED",
        "temporal_runtime": "NOT_ESTABLISHED",
        "confinement": "NOT_PROVEN",
        "historical_run_0001": "IMMUTABLE_FAILURE_EVIDENCE_MUST_REMAIN",
        "current_admissible_continuation_evidence": "DISTINCT_APPEND_ONLY_RUN_0002_REQUIRED",
        "run_0002_supersedes_run_0001": "EXECUTION_READINESS_ONLY_NOT_HISTORY",
        "static_lock_must_bind": provenance["static_lock_must_bind"],
        "continuation_mutable_allowlist": scope["mutable_allowlist"],
        "all_unlisted_v11_mutation": "PROHIBITED",
        "v12": "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "governance_validation": {"status": "PASS", "passed": primary["checks_passed"], "total": primary["checks_total"]},
        "negative_fixtures": {"status": "PASS", "passed": negative["tests_passed"], "total": negative["tests_total"]},
        "independent_validation": {"status": "PASS", "passed": independent["checks_passed"], "total": independent["checks_total"]},
        "final_freeze_verification": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        "operation_counters": authority["operation_counters"],
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": root_digest,
        "next_legal_milestone": "CORRECT_ONLY_V11_STATIC_LOCK_PROVENANCE_CHAIN_UNDER_EXACT_SCOPE_LOCK_EMIT_APPEND_ONLY_RUN_0002_AND_RERUN_FULL_PRELOCK_CHAIN_FROM_SCRATCH"
    })
    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION, "member_count": len(rows), "canonical_artifact_root_sha256": root_digest}, sort_keys=True))


if __name__ == "__main__":
    main()
