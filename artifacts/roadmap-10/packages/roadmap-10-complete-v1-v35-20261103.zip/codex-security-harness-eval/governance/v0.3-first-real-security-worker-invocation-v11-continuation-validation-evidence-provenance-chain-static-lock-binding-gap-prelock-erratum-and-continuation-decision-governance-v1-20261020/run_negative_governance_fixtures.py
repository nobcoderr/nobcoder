#!/usr/bin/env python3
"""Negative fixtures for V11 continuation-evidence provenance selection."""

from __future__ import annotations

import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CHAIN_STATIC_LOCK_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"


def admissible(*, history: bool, current_count: int, authorized: bool, after: bool,
               digest_ok: bool, history_immutable: bool, scope_ok: bool,
               governance_digest_ok: bool, binds_history: bool, selects_current: bool) -> bool:
    return all((history, current_count == 1, authorized, after, digest_ok,
                history_immutable, scope_ok, governance_digest_ok,
                binds_history, selects_current))


def main() -> None:
    if os.path.lexists(OUT):
        raise SystemExit("refusing to overwrite negative result")
    base = dict(history=True, current_count=1, authorized=True, after=True,
                digest_ok=True, history_immutable=True, scope_ok=True,
                governance_digest_ok=True, binds_history=True, selects_current=True)
    vectors = [
        ("N001", {}, True),
        ("N002", {"current_count": 0}, False),
        ("N003", {"authorized": False}, False),
        ("N004", {"after": False}, False),
        ("N005", {"digest_ok": False}, False),
        ("N006", {"history_immutable": False}, False),
        ("N007", {"current_count": 2}, False),
        ("N008", {"scope_ok": False}, False),
        ("N009", {"governance_digest_ok": False}, False),
        ("N010", {"binds_history": False}, False),
        ("N011", {"selects_current": False}, False),
        ("N012", {"scope_ok": False, "digest_ok": False}, False),
    ]
    rows = []
    for case_id, changes, expected in vectors:
        given = {**base, **changes}
        actual = admissible(**given)
        rows.append({"case_id": case_id, "expected_admissible": expected, "actual_admissible": actual, "status": "PASS" if actual == expected else "FAIL"})
    failed = [row for row in rows if row["status"] == "FAIL"]
    payload = {
        "governance_identity": IDENTITY,
        "record_type": "NEGATIVE_GOVERNANCE_TEST_RESULT",
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "tests_total": len(rows),
        "tests_passed": len(rows) - len(failed),
        "tests_failed": len(failed),
        "failure_ids": [row["case_id"] for row in failed],
        "tests": rows,
    }
    with OUT.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({k: payload[k] for k in ("status", "tests_passed", "tests_total", "failure_ids")}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
