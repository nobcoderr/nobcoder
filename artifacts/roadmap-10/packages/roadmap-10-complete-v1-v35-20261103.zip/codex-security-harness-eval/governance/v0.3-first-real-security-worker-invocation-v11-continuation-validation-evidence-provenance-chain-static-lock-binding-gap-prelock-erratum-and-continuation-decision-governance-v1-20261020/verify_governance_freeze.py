#!/usr/bin/env python3
"""Read-only verification of the frozen V11 provenance governance package."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(rows: list[dict[str, object]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda value: str(value["path"])))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def main() -> None:
    manifest = json.loads((ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").read_text(encoding="utf-8"))
    lock = json.loads((ROOT / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8"))
    final = json.loads((ROOT / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json").read_text(encoding="utf-8"))
    failures = []
    for row in manifest["members"]:
        path = ROOT / str(row["path"])
        if not path.is_file() or sha(path) != row["sha256"] or path.stat().st_size != row["bytes"]:
            failures.append(str(row["path"]))
    if canonical(manifest["members"]) != manifest["canonical_artifact_root_sha256"]:
        failures.append("canonical_root")
    if sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") != lock["governance_manifest_sha256"]:
        failures.append("manifest_digest")
    if lock["canonical_artifact_root_sha256"] != manifest["canonical_artifact_root_sha256"]:
        failures.append("lock_root")
    if lock["status"] != "PASS_LOCKED_GOVERNANCE_ONLY" or final["status"] != "PASS":
        failures.append("status")
    if any(path.stat().st_mode & 0o222 for path in ROOT.iterdir() if path.is_file()):
        failures.append("writable_member")
    if ROOT.stat().st_mode & 0o222:
        failures.append("writable_root")
    payload = {"status": "PASS" if not failures else "FAIL_CLOSED", "member_count": manifest["member_count"], "failures": failures}
    print(json.dumps(payload, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
