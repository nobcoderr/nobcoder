#!/usr/bin/env python3
"""Primary validation for the V11 continuation-provenance adjudication."""

from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
PREV = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-v11-independent-validator-source-order-anchor-defect-prelock-erratum-and-continuation-or-successor-decision-governance-v1-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CHAIN_STATIC_LOCK_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"
OUT = ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    if os.path.lexists(OUT):
        raise SystemExit("refusing to overwrite primary governance result")
    checks: list[dict[str, Any]] = []

    def check(cid: str, ok: bool, evidence: Any = None) -> None:
        checks.append({"check_id": cid, "status": "PASS" if ok else "FAIL", "evidence": evidence})

    charter = load(ROOT / "GOVERNANCE_CHARTER.json")
    disposition = load(ROOT / "V11_PRELOCK_DISPOSITION.json")
    bindings = load(ROOT / "EVIDENCE_INPUT_BINDINGS.json")
    ownership = load(ROOT / "DEFECT_OWNERSHIP_DECISION.json")
    provenance = load(ROOT / "NORMATIVE_PROVENANCE_CHAIN_DECISION.json")
    scope = load(ROOT / "CONTINUATION_V11_SCOPE_LOCK.json")
    decision = load(ROOT / "CONTINUATION_DECISION.json")
    authority = load(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    negatives = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    next_step = load(ROOT / "NEXT_LEGAL_MILESTONE.json")

    for name, value in {
        "charter": charter, "disposition": disposition, "bindings": bindings,
        "ownership": ownership, "provenance": provenance, "scope": scope,
        "decision": decision, "authority": authority, "negatives": negatives,
        "next": next_step,
    }.items():
        check("P_JSON_IDENTITY_" + name.upper(), value.get("governance_identity") == IDENTITY)

    check("P001_SCOPE_GOVERNANCE_ONLY", charter["scope"] == "ADJUDICATE_CONTINUATION_EVIDENCE_PROVENANCE_AND_STATIC_LOCK_BINDING_ONLY")
    check("P002_NO_ACTION", not any([charter["current_milestone_may_patch_v11"], charter["current_milestone_may_issue_static_lock"], charter["current_milestone_may_consume_attempt"], charter["current_milestone_may_invoke_worker_or_codex"]]))
    check("P003_DISPOSITION", disposition["status"] == "FAIL_CLOSED_BEFORE_STATIC_LOCK_ON_CONTINUATION_EVIDENCE_PROVENANCE_BINDING")
    check("P004_VALIDATION_COUNTS", [disposition["unit"], disposition["primary"], disposition["independent"], disposition["fresh_preflight"]] == ["136_OF_136_PASS", "134_OF_134_PASS", "95_OF_95_PASS_CONTINUATION_EVIDENCE", "55_OF_55_PASS"])
    check("P005_ZERO_EXECUTION", disposition["attempt"] == "0_OF_1_NOT_CONSUMED" and disposition["worker_invocation"] == disposition["codex_as_worker_invocation"] == "0_OF_1")
    check("P006_RUNTIME_NOT_ESTABLISHED", disposition["temporal_runtime"] == "NOT_ESTABLISHED" and disposition["confinement"] == "NOT_PROVEN")

    expected_hashes = {
        "unit-fixtures-run-0001.json": "cb4742c4597ce88e4c709615f4a29567eda4e9c1d4048dbbfbf4c4f95436355e",
        "primary-static-validation-run-0001.json": "e77590b7ae4d0d00bd6a2817928e1b991e407debbe4313c3bf981f1d6339a7c3",
        "independent-static-validation-run-0001.json": "e2730827d6fd5ddfc3ff9c2decf5ef044f967a171957f116db028d3b9a971dbb",
        "fresh-preflight-run-0001.json": "03647ca262ed180e21d829f2daec1ae78ed47700e735f9081da754db2b1676eb",
        "dependency-closure-run-0001.json": "530552bf5e106dc88f3ed9004c1c325ae60639cb3dd8261008f5eb1266689c77",
    }
    for filename, digest in expected_hashes.items():
        path = V11 / "results/prelock" / filename
        check("P_HISTORICAL_" + filename.upper(), path.is_file() and sha(path) == digest, digest)
    historical = load(V11 / "results/prelock/independent-static-validation-run-0001.json")
    check("P007_HISTORICAL_FAIL_EXACT", historical["status"] == "FAIL_CLOSED" and historical["checks_passed"] == 94 and historical["checks_total"] == 95)

    check("P008_PRIOR_GOV_LOCK", sha(PREV / "GOVERNANCE_LOCK.json") == bindings["prior_continuation_governance"]["lock_sha256"])
    check("P009_PRIOR_SCOPE_LOCK", sha(PREV / "CONTINUATION_V11_SCOPE_LOCK.json") == bindings["prior_continuation_governance"]["scope_lock_sha256"])
    previous_lock = load(PREV / "GOVERNANCE_LOCK.json")
    check("P010_PRIOR_AUTHORITY", previous_lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY" and previous_lock["continuation_v11"] == "AUTHORIZED_VALIDATOR_ONLY_UNDER_SCOPE_LOCK")

    source_hashes = bindings["continuation_source_identity"]
    for rel, digest in source_hashes.items():
        check("P_SOURCE_" + rel.replace("/", "_").upper(), sha(V11 / rel) == digest)
    check("P011_STATIC_LOCK_ABSENT", not os.path.lexists(V11 / "STATIC_EXECUTION_LOCK.json"))
    check("P012_ATTEMPT_ABSENT", not os.path.lexists(V11 / "static-run-v11/ATTEMPT_MARKER.json"))

    check("P013_OWNERSHIP_GAP", ownership["continuation_evidence_provenance_binding_gap"] == "YES" and ownership["static_lock_current_evidence_selector_defect"] == "YES")
    check("P014_NO_RUNTIME_BLAME", ownership["worker_defect"] == ownership["codex_defect"] == ownership["observer_runtime_defect"] == "NOT_ESTABLISHED_NO_EXECUTION")
    check("P015_APPEND_ONLY", provenance["history_model"] == "APPEND_ONLY_VERSIONED_VALIDATION_EVIDENCE")
    check("P016_HISTORICAL_IMMUTABLE", provenance["historical_evidence"]["independent-static-validation-run-0001.json"]["may_be_overwritten_deleted_renamed_or_hidden"] is False)
    current = provenance["current_admissible_validation"]
    check("P017_CURRENT_RUN_0002", current["required_identity"] == "independent-static-validation-run-0002.json" and current["required_status"] == "PASS_95_OF_95")
    check("P018_AFTER_AUTHORITY", current["required_generation_time"] == "AFTER_CONTINUATION_AUTHORITY_GOVERNANCE_LOCK")
    check("P019_SUPERSESSION_LIMIT", provenance["supersession_semantics"]["run_0002_supersedes_run_0001_for_execution_readiness_only"] is True and provenance["supersession_semantics"]["run_0002_replaces_or_invalidates_run_0001_as_history"] is False)
    check("P020_LOCK_BINDS_CHAIN", set(provenance["static_lock_must_bind"]) >= {"ALL_HISTORICAL_RUN_0001_EVIDENCE", "THIS_STATIC_LOCK_PROVENANCE_CONTINUATION_GOVERNANCE_LOCK", "CURRENT_ADMISSIBLE_RUN_0002_VALIDATION_CHAIN"})
    check("P021_COUNTERS_ZERO", all(value == 0 for value in provenance["required_prelock_counters"].values()))

    required_allowlist = {
        "prepare_static_lock.py", "verify_static_lock.py", "preflight.py", "src/invocation_v11.py",
        "tests/run_unit_fixtures.py", "validators/primary_static_validate.py",
        "validators/independent_static_validate.py", "bind_authoritative_artifact_digests.py",
        "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json",
        "contracts/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CONTRACT.json",
        "schemas/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE.schema.json",
    }
    check("P022_EXACT_ALLOWLIST", set(scope["mutable_allowlist"]) == required_allowlist)
    check("P023_PROTECTED_RUNTIME", {"src/runner_v11.py", "src/topology_observer_v11.py", "contracts/WORKER_REQUEST.json", "fixture/worker-prompt.txt", "runtime-config-candidate/config.toml"}.issubset(set(scope["must_not_change"])))
    check("P024_RUN_0001_PROTECTED", scope["historical_run_0001_mutation"] == "PROHIBITED")
    check("P025_DECISION", decision["decision"] == "CONTINUATION_V11_STATIC_LOCK_PROVENANCE_ONLY_CORRECTION_AUTHORIZED")
    check("P026_DECISION_NO_ACTION", not any([decision["current_milestone_performs_correction"], decision["current_milestone_performs_revalidation"], decision["current_milestone_issues_static_lock"], decision["current_milestone_performs_execution"]]))
    check("P027_V12_NOT_AUTHORIZED", decision["v12"] == "NOT_AUTHORIZED_NOT_CREATED_NOT_EXECUTED" and charter["v12_authorized"] is False)
    check("P028_AUTHORITY_CEILING", authority["authority_ceiling"] == "V11_STATIC_LOCK_PROVENANCE_ONLY_CORRECTION_THEN_FULL_PRELOCK_CHAIN_RERUN")
    check("P029_OPERATION_COUNTERS_ZERO", len(authority["operation_counters"]) == 18 and all(v == 0 for v in authority["operation_counters"].values()))
    check("P030_NEGATIVE_MATRIX", len(negatives["cases"]) == 12 and negatives["all_cases_required"] is True)
    check("P031_NEXT_ORDER", next_step["v12_may_be_created"] is False and "EMIT_APPEND_ONLY_RUN_0002_UNIT_PRIMARY_INDEPENDENT" in next_step["required_order"])

    failures = [row for row in checks if row["status"] == "FAIL"]
    payload = {
        "governance_identity": IDENTITY,
        "record_type": "PRIMARY_GOVERNANCE_VALIDATION_RESULT",
        "run_id": "GOVERNANCE_VALIDATION_RUN-0001",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failures),
        "checks_failed": len(failures),
        "failure_ids": [row["check_id"] for row in failures],
        "checks": checks,
    }
    with OUT.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({k: payload[k] for k in ("status", "checks_passed", "checks_total", "failure_ids")}, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
