#!/usr/bin/env python3
"""Independent governance validation for the V5 worker-invocation erratum."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V5 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v6-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_CROSS_NAMESPACE_PID_PPID_CORRELATION_AND_DEPENDENT_MOUNT_WRITE_CLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6_CONDITIONALLY"
V5_ROOT = "ec95c4806ce0b8bef7690de362bb4a8c25a6b785faf5ae47b23a5fa60abf6927"
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json", "V5_TERMINAL_EVIDENCE_BINDING.json", "V5_TERMINAL_DISPOSITION.json",
    "CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION.json", "CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT.json",
    "DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION.json", "MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT.json",
    "DEFECT_OWNERSHIP_DECISION.json", "FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json",
    "V5_FAILURE_AND_V6_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V6_REQUIREMENTS.json",
    "SUCCESSOR_V6_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json",
}
OUTPUT = "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted(node for node in path.rglob("*") if node.is_file())]
    material = "".join(f"{digest}  {name}\n" for name, digest in rows).encode()
    return hashlib.sha256(material).hexdigest(), len(rows)


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(payload: dict[str, Any]) -> None:
    with (ROOT / OUTPUT).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"independent input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("I_SCRIPT_" + script, valid)
    v5_root, v5_members = tree(V5)
    check("I001_V5_ROOT", v5_root == V5_ROOT and v5_members == 117, {"root": v5_root, "members": v5_members})
    check("I002_V6_ABSENT", not V6.exists() and not V6.is_symlink())
    terminal_native = json.loads((V5 / "static-run-v5/TERMINAL_ENGINEERING_RESULT.json").read_text())
    runtime = json.loads((V5 / "static-run-v5/runtime-result-0001.json").read_text())
    post_native = json.loads((V5 / "static-run-v5/independent-post-validation-0001.json").read_text())
    marker = json.loads((V5 / "static-run-v5/ATTEMPT_MARKER.json").read_text())
    freeze_lock = json.loads((V5 / "static-run-v5/EVIDENCE_FREEZE_LOCK.json").read_text())
    topology = json.loads((V5 / "static-run-v5/runtime-topology-snapshot-0001.json").read_text())
    controller = json.loads((V5 / "static-run-v5/controller-worker-result-0001.json").read_text())
    check("I003_NATIVE_STATUS", terminal_native["status"] == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE")
    check("I004_NATIVE_COUNTS", terminal_native["attempt_count"] == marker["attempt_count"] == 1 and terminal_native["worker_invocation_count"] == marker["worker_invocation_count"] == 1 and terminal_native["codex_as_worker_invocation_count"] == marker["codex_as_worker_invocation_count"] == 1)
    check("I005_RUNTIME_EXEC", runtime["exit_status"] == 0 and runtime["semantic_codex_exec_count"] == 1)
    check("I006_WORKER_RESULT", runtime["worker_result_state"] == "EMITTED_AND_CONTROLLER_WRAPPED" and controller["status"] == "PROPOSAL_COMPLETE")
    check("I007_QUARANTINE", controller["proposals"][0]["candidate_initial_state"] == "HYPOTHESIS_QUARANTINED" and terminal_native["candidate_promotion_count"] == 0)
    check("I008_POST_FAILURE", post_native["status"] == "FAIL_CLOSED_DIAGNOSTIC_COMPLETE" and post_native["checks_passed"] == 55 and post_native["checks_total"] == 58)
    check("I009_FAILURE_IDS", set(post_native["failure_ids"]) == {"P010_RUNTIME_PASS", "P013_SEMANTIC_PROCESS_LINEAGE", "P046_MOUNT_PROVENANCE_WRITE_CLASSIFICATION"})
    check("I010_FAILURE_FREEZE", freeze_lock["evidence_freeze_state"] == "FROZEN_FAILURE_EVIDENCE" and freeze_lock["pass_locked"] is False)
    terminal = read("V5_TERMINAL_DISPOSITION.json")
    check("I011_GOV_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY" and terminal["immutable"] is True)
    check("I012_NO_CONTINUATION", all(terminal[key] == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "evidence_reclassification", "promotion"]))
    trace_launcher = (V5 / "static-run-v5/trace.402361").read_text(encoding="utf-8", errors="strict")
    trace_namespace = (V5 / "static-run-v5/trace.402362").read_text(encoding="utf-8", errors="strict")
    check("I013_FIRST_CLONE_HOST_PID", "CLONE_NEWPID" in trace_launcher and ") = 402362" in trace_launcher)
    check("I014_NESTED_CLONE_LOCAL_PID", "clone(" in trace_namespace and ") = 2" in trace_namespace)
    observations = topology["process_observations"]
    runtime_obs = [row for row in observations if row["pid"] == 402363 and row["ppid"] == 402362]
    child_obs = [row for row in observations if row["pid"] == 402447 and row["ppid"] == 402363]
    check("I015_PROC_RUNTIME_EDGE", len(runtime_obs) == 1 and runtime_obs[0]["pid_namespace"] == "pid:[4026532408]")
    check("I016_PROC_CHILD_EDGE", len(child_obs) == 1 and child_obs[0]["pid_namespace"] == "pid:[4026532408]")
    parent_map = runtime["semantic_process_lineage"]["parent_map"]
    check("I017_V5_LOCAL_PARENT_MAP", parent_map.get("2") == 402362 and parent_map.get("402363") is None)
    check("I018_V5_LINEAGE_FAILED", runtime["semantic_process_lineage"]["status"] == "FAIL_CLOSED" and runtime["semantic_process_lineage"]["checks"]["runtime_descends_from_launcher"] is False)
    corr = read("CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION.json")
    check("I019_DEFECT_DECISION", corr["status"] == "DEFECT_CONFIRMED" and corr["cross_namespace_pid_ppid_correlation_classifier_defect"] == "YES")
    check("I020_NO_LOCAL_HOST_EQUIVALENCE", corr["local_pid_equals_host_pid_assumption"] == "INVALID")
    check("I021_NO_LINEAGE_PROMOTION", corr["semantic_decision"]["expected_runtime_descendant_lineage_proven"] == "NO" and corr["semantic_decision"]["lineage_disposition"] == "UNKNOWN_FAIL_CLOSED")
    identity_contract = read("CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT.json")
    fields = set(identity_contract["identity_fields"])
    check("I022_MODEL_FIELDS", fields == {"local_pid", "host_pid", "parent_local_pid", "parent_host_pid", "trace_file_pid", "namespace_id", "proc_topology_identity"})
    rules = identity_contract["rules"]
    check("I023_MAPPING_RULES", rules["mapping_requires_evidence_refs"] is True and rules["mapping_requires_namespace_ids"] is True and rules["mapping_requires_temporally_bound_proc_topology"] is True)
    check("I024_UNKNOWN_LINEAGE", rules["unknown_lineage"] == "FAIL_CLOSED" and rules["ambiguous_or_reused_identity"] == "FAIL_CLOSED")
    writes = runtime["typed_write_evidence"]
    check("I025_WRITE_REJECTIONS", len(writes["rejected"]) == 67 and writes["authorized_write_count"] == 5)
    check("I026_MOUNT_IDS_PRESENT", {553, 558, 567}.issubset({row.get("mount_id") for row in writes["rejected"]}))
    mount = read("DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION.json")
    check("I027_MOUNT_CAPTURE_NOT_DEFECT", mount["mount_provenance_capture_defect"] == "NO")
    check("I028_PRODUCER_UNPROVEN", mount["semantic_decision"]["producer_lineage_authorization_proven"] == "NO" and mount["semantic_decision"]["final_write_authorization_proven"] == "NO")
    check("I029_NO_HOST_ACTIVITY_PROOF", mount["semantic_decision"]["actual_out_of_scope_host_filesystem_activity_proven"] == "NO")
    mount_contract = read("MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT.json")
    check("I030_SEPARATE_GATES", mount_contract["mount_provenance_gate"]["separate_gate"] is True and mount_contract["producer_authorization_gate"]["separate_gate"] is True)
    check("I031_BOTH_GATES", mount_contract["final_write_authorization"] == "MOUNT_PROVENANCE_GATE_PASS_AND_PRODUCER_AUTHORIZATION_GATE_PASS")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    check("I032_OWNERSHIP", ownership["cross_namespace_process_lineage_correlation_contract_defect"] == "YES" and ownership["dependent_mount_write_authorization_classifier_defect"] == "YES")
    check("I033_NOT_BASE_DEFECT", ownership["security_worker_runtime_v1_defect"] == "NO" and ownership["codex_runtime_0_163_0_compatibility_defect"] == "NO" and ownership["worker_output_or_quarantine_defect"] == "NO")
    check("I034_CONFINEMENT_NOT_PROVEN", ownership["confinement_pass"] == "NOT_PROVEN" and ownership["confinement_bypass"] == "NO")
    successor = read("SUCCESSOR_V6_AUTHORIZATION_DECISION.json")
    check("I035_SUCCESSOR", successor["decision"] == DECISION and successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I036_SUCCESSOR_ZERO", successor["attempt_count"] == 0 and successor["worker_invocation_count"] == 0 and successor["semantic_codex_execution_count"] == 0)
    requirements = set(read("SUCCESSOR_V6_REQUIREMENTS.json")["mandatory_requirements"])
    check("I037_REQUIRED_MODEL", {"CROSS_NAMESPACE_PROCESS_IDENTITY_MODEL", "HOST_PID_LOCAL_PID_MAPPING_EVIDENCE_BOUND", "SEMANTIC_PROCESS_LINEAGE_CORRELATION"}.issubset(requirements))
    check("I038_REQUIRED_WRITE_GATES", {"MOUNT_PROVENANCE_CLASSIFICATION_SEPARATE_GATE", "PRODUCER_AUTHORIZATION_SEPARATE_GATE", "MOUNT_PROVENANCE_DOES_NOT_IMPLY_PRODUCER_AUTHORIZATION"}.issubset(requirements))
    check("I039_REQUIRED_FREEZE", "IMMUTABLE_FAILURE_EVIDENCE_FREEZE" in requirements)
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    counters = authority["current_governance_operation_counters"]
    check("I040_ZERO_OPERATIONS", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    historical_negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    check("I041_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_failed"] == 0)
    check("I042_HISTORICAL_NEGATIVE_PRESERVED", historical_negative["status"] == "FAIL_CLOSED" and historical_negative["tests_passed"] == 25 and historical_negative["tests_failed"] == 7)
    check("I043_NEGATIVE_PASS", negative["status"] == "PASS" and negative["tests_passed"] == 32 and negative["tests_failed"] == 0 and negative["historical_predecessor_run"] == "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    failed = [row for row in checks if row["status"] == "FAIL"]
    write({
        "record_type": "FIRST_WORKER_V5_ERRATUM_INDEPENDENT_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "INDEPENDENT_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": counters,
    })
    print(json.dumps({"status": "PASS" if not failed else "FAIL_CLOSED", "passed": len(checks) - len(failed), "total": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit("independent validation failed: " + ",".join(row["check_id"] for row in failed))


if __name__ == "__main__":
    main()
