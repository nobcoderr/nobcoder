#!/usr/bin/env python3
"""Build the governance-only V5 worker-invocation erratum package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V5 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v6-20261020")
V4_GOV = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-v4-startup-process-lineage-ephemeral-tmpfs-write-classification-token-budget-semantics-and-post-validation-failure-erratum-and-successor-decision-governance-v1-20261020")
WORKER_ACCEPT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-security-worker-runtime-v1-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261020")
CODEX_ACCEPT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v7-frozen-evidence-acceptance-and-codex-0-163-0-pass-locked-decision-governance-v1-20261020")
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")

IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_CROSS_NAMESPACE_PID_PPID_CORRELATION_AND_DEPENDENT_MOUNT_WRITE_CLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V5_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5"
V6_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6_ONCE_IF_ALL_GATES_PASS"

HASHES = {
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
    "v5_tree_root": "ec95c4806ce0b8bef7690de362bb4a8c25a6b785faf5ae47b23a5fa60abf6927",
    "static_lock": "d9650d2fef7fce6fba0393e17b06a9fd198059c854874beada6c727f68d75d0c",
    "static_manifest": "fc63b8e18680b0b1e043572489f357883f3b8c5d44a69e3f80542a81dba0d156",
    "lock_verification": "2e9639c5bf66b080cd7941eb740478ed70a65af71e9073412110a39371751fc6",
    "attempt_marker": "57122cf1ffbd937b073d04f1089466fceddcc9f408447323f413e94f52468974",
    "runtime_result": "20c633ea8174417eb224e068eaa59219d15574f06f3802fa11bfd4b6357eb3b6",
    "post_validation": "ef1b3f2950d6c32c4a085f3995725470711f054b8c589eac351169e222db1c02",
    "topology": "2b4086df84349a13ba09036d1a841b4ee58908752aca011862b6ebba7958ac82",
    "controller_result": "9796d04c537656b05d6a9f4360d3ec61e5ecdc8f623fa922812591d3d28a530d",
    "last_message": "2cbfac03f1f89c0f15a97d7ec3eb85d42ee68516344dd26d68f6fc3a279d7cce",
    "events": "96b1a38e4d935865a4a57947d3948d7900780ce19a35693ad4d1ab2837d77c0c",
    "evidence_manifest": "65293cab21cab5625ccd8a0e4d1c5405be394f47dc2dcab3f22c2bb6e5e75801",
    "evidence_lock": "8ebd5731c636a78d8ad52bb71dd059a4cc0c519668b9c866f1869a60f1d082ba",
    "evidence_verification": "be4f7bba5617a88845edf3844a9f55de9a1d4c54a5d2154c0742cd0f0b4586a8",
    "terminal_result": "be06cad925d521901dc1102ac3db8dd3fc7673496e97638c78ff4324038c42f3",
    "lineage_contract": "e2ae5f1818e842970ad312701c88f64f731810f88773d822321f7c786b4fd2cd",
    "mount_contract": "2d79a41ea4dae89470b61364f438dafa2d2f68ddaf6975e5037f49dbdc64fbfa",
    "invocation_source": "2c4647a3092298ea21f8649e674b312b12620a8916de59da16fa17a8ce878495",
    "post_validator": "12445394955b0ca2de00ae87e551149dc819722f25a840d9fb699590fd9b8fd9",
    "v4_governance_lock": "771117ba0a1357e19ece3d7451c0e98290acfc522b9ba05db016a90fb7a7d3b8",
    "v4_governance_manifest": "93df444c5c591d1b71324ebc8186e868464dd3ed69ad9814bf19b19b4086563c",
    "worker_runtime_lock": "cc7928e67b9d5c74f04a750d8faae5bbdf97f2dd7fd4337885ddf10f85d6e8f7",
    "worker_runtime_manifest": "82aadd2c610409915cfc687ee9449eec4a9141b1aac99b654505a6b61db3dbad",
    "codex_lock": "3aedf0a656fd12680311f07fcf01e911e7a6a62f0b81871af347a55bc1ba7fef",
    "codex_manifest": "916f32ae710ee9a1721a151b4a1d0d16a05b268c2ef1ff2985e4235f4a64d1ae",
}

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
OPERATION_KEYS = [
    "worker_invocations", "codex_as_worker_invocations", "subagent_invocations",
    "credential_operations", "target_operations", "external_network_operations",
    "daybreak_invocations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def tree(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = [
        {"path": item.relative_to(path).as_posix(), "sha256": sha(item), "bytes": item.stat().st_size}
        for item in sorted(node for node in path.rglob("*") if node.is_file())
    ]
    return canonical_root(rows), rows


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_inputs() -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    if sha(ROUTER_MAP) != HASHES["router_map"]:
        raise SystemExit("router map drift")
    for path, lock_key, manifest_key in [
        (V4_GOV, "v4_governance_lock", "v4_governance_manifest"),
        (WORKER_ACCEPT, "worker_runtime_lock", "worker_runtime_manifest"),
        (CODEX_ACCEPT, "codex_lock", "codex_manifest"),
    ]:
        if sha(path / "GOVERNANCE_LOCK.json") != HASHES[lock_key]:
            raise SystemExit(f"predecessor lock drift: {path}")
        if sha(path / "GOVERNANCE_ARTIFACT_MANIFEST.json") != HASHES[manifest_key]:
            raise SystemExit(f"predecessor manifest drift: {path}")
    root, rows = tree(V5)
    if root != HASHES["v5_tree_root"] or len(rows) != 117:
        raise SystemExit(f"V5 tree drift: {root} members={len(rows)}")
    fixed = {
        "STATIC_EXECUTION_LOCK.json": "static_lock",
        "STATIC_SOURCE_MANIFEST.json": "static_manifest",
        "STATIC_EXECUTION_LOCK_VERIFICATION.json": "lock_verification",
        "static-run-v5/ATTEMPT_MARKER.json": "attempt_marker",
        "static-run-v5/runtime-result-0001.json": "runtime_result",
        "static-run-v5/independent-post-validation-0001.json": "post_validation",
        "static-run-v5/runtime-topology-snapshot-0001.json": "topology",
        "static-run-v5/controller-worker-result-0001.json": "controller_result",
        "static-run-v5/last-message.json": "last_message",
        "static-run-v5/events.jsonl": "events",
        "static-run-v5/EVIDENCE_MANIFEST.json": "evidence_manifest",
        "static-run-v5/EVIDENCE_FREEZE_LOCK.json": "evidence_lock",
        "static-run-v5/EVIDENCE_FREEZE_VERIFICATION.json": "evidence_verification",
        "static-run-v5/TERMINAL_ENGINEERING_RESULT.json": "terminal_result",
        "contracts/PROCESS_LINEAGE_CONTRACT.json": "lineage_contract",
        "contracts/MOUNT_PROVENANCE_WRITE_CONTRACT.json": "mount_contract",
        "src/invocation_v5.py": "invocation_source",
        "validators/post_validate.py": "post_validator",
    }
    for relative, key in fixed.items():
        if sha(V5 / relative) != HASHES[key]:
            raise SystemExit(f"V5 evidence drift: {relative}")
    if V6.exists() or V6.is_symlink():
        raise SystemExit("V6 must not exist during governance adjudication")
    return (
        rows,
        load(V5 / "static-run-v5/TERMINAL_ENGINEERING_RESULT.json"),
        load(V5 / "static-run-v5/runtime-result-0001.json"),
        load(V5 / "static-run-v5/independent-post-validation-0001.json"),
        load(V5 / "static-run-v5/runtime-topology-snapshot-0001.json"),
        load(V5 / "static-run-v5/controller-worker-result-0001.json"),
    )


def routing_decisions() -> list[dict[str, str]]:
    routing = load(ROUTER_MAP)
    active_conditional = {"agentic-security-research-harness", "external-ai-security-tool-governor"}
    decisions = []
    for name, route in sorted(routing["skill_routes"].items()):
        if route.get("mode") == "always":
            state, reason = "ACTIVE", "MANDATORY_CORE_POLICY"
        elif name in active_conditional:
            state, reason = "ACTIVE", "LOCAL_AGENTIC_WORKER_AND_EXTERNAL_RUNTIME_GOVERNANCE"
        else:
            state, reason = "NOT_APPLICABLE", "GOVERNANCE_ONLY_NO_TARGET_DISCOVERY_OR_EXECUTION"
        decisions.append({"module": name, "state": state, "reason": reason})
    decisions.append({"module": "codex-security-harness", "state": "ACTIVE", "reason": "LOCAL_HARNESS_GOVERNANCE_IDENTITY"})
    return decisions


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != SCRIPTS or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    rows, terminal, runtime, post, topology, controller = verify_inputs()
    marker = load(V5 / "static-run-v5/ATTEMPT_MARKER.json")
    evidence_lock = load(V5 / "static-run-v5/EVIDENCE_FREEZE_LOCK.json")
    evidence_verification = load(V5 / "static-run-v5/EVIDENCE_FREEZE_VERIFICATION.json")
    lineage = runtime["semantic_process_lineage"]
    writes = runtime["typed_write_evidence"]
    process_observations = topology["process_observations"]
    observation_by_pid = {row["pid"]: row for row in process_observations}
    runtime_observation = observation_by_pid[402363]
    startup_observation = observation_by_pid[402447]
    decisions = routing_decisions()

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_ROUTING_AND_SCOPE_DECISION", "schema_version": "1.0",
        "scope": "GOVERNANCE_ONLY_READ_ONLY_V5_FROZEN_FAILURE_EVIDENCE_ADJUDICATION",
        "scope_evidence_card": {
            "asset": str(V5), "asset_kind": "LOCAL_FROZEN_TERMINAL_WORKER_INVOCATION_WORKSPACE",
            "allowed_mode": "READ_ONLY_EVIDENCE_ADJUDICATION_LOCAL_GOVERNANCE_VALIDATION_AND_FREEZE",
            "target": "NONE", "credential": "NONE", "network": "NONE", "codex_invocation": "NONE",
            "worker_or_subagent": "NONE", "v6_implementation": "NONE", "candidate_promotion": "NONE",
        },
        "authorized_actions": [
            "READ_FROZEN_TERMINAL_V5_EVIDENCE", "ADJUDICATE_TWO_DISTINCT_CLASSIFIER_DEFECTS",
            "DEFINE_CROSS_NAMESPACE_PROCESS_IDENTITY_MODEL", "SEPARATE_MOUNT_PROVENANCE_FROM_PRODUCER_AUTHORIZATION",
            "DEFINE_SUCCESSOR_V6_REQUIREMENTS", "ISSUE_CONDITIONAL_V6_DECISION",
            "RUN_LOCAL_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE",
        ],
        "forbidden_actions": [
            "PATCH_RELOCK_REVALIDATE_RETRY_CONTINUE_OR_RECLASSIFY_V5", "CREATE_OR_EXECUTE_V6",
            "CODEX_WORKER_OR_SUBAGENT_INVOCATION", "CREDENTIAL_TARGET_OR_NETWORK_OPERATION",
            "DAYBREAK_INVOCATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH",
            "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION",
        ],
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_ROUTING_LEDGER", "schema_version": "1.0",
        "router_map_sha256": HASHES["router_map"], "module_decisions": decisions,
        "active_count": sum(row["state"] == "ACTIVE" for row in decisions),
        "deferred_count": 0, "not_applicable_count": sum(row["state"] == "NOT_APPLICABLE" for row in decisions),
        "subagents_used": False, "codex_invoked_during_governance": False,
        "worker_invoked_during_governance": False, "network_used": False,
    })
    v4_lock = load(V4_GOV / "GOVERNANCE_LOCK.json")
    worker_lock = load(WORKER_ACCEPT / "GOVERNANCE_LOCK.json")
    codex_lock = load(CODEX_ACCEPT / "GOVERNANCE_LOCK.json")
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_PREDECESSOR_CHAIN_BINDING", "schema_version": "1.0",
        "v5_authorization": {
            "identity": v4_lock["governance_identity"], "status": v4_lock["status"], "decision": v4_lock["decision"],
            "lock_sha256": HASHES["v4_governance_lock"], "manifest_sha256": HASHES["v4_governance_manifest"],
        },
        "security_worker_runtime_v1": {
            "status": worker_lock["security_worker_runtime_v1"],
            "lock_sha256": HASHES["worker_runtime_lock"], "manifest_sha256": HASHES["worker_runtime_manifest"],
        },
        "codex_runtime_0_163_0": {
            "status": codex_lock["codex_runtime_0_163_0"],
            "lock_sha256": HASHES["codex_lock"], "manifest_sha256": HASHES["codex_manifest"],
        },
    })
    write("V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json", {
        "record_type": "FIRST_WORKER_V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST", "schema_version": "1.0",
        "execution_identity": V5_IDENTITY, "workspace": str(V5), "member_count": len(rows), "members": rows,
        "canonical_tree_root_sha256": HASHES["v5_tree_root"],
        "snapshot_kind": "FROZEN_FAILURE_EVIDENCE_EXTERNAL_GOVERNANCE_BINDING",
        "pass_locked_implication": "NONE", "source_workspace_mutated": False,
    })
    write("V5_TERMINAL_EVIDENCE_BINDING.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_TERMINAL_EVIDENCE_BINDING", "schema_version": "1.0",
        "execution_identity": V5_IDENTITY, "workspace": str(V5), "member_count": len(rows),
        "canonical_tree_root_sha256": HASHES["v5_tree_root"],
        "fixed_evidence_sha256": {key: HASHES[key] for key in [
            "static_lock", "static_manifest", "lock_verification", "attempt_marker", "runtime_result",
            "post_validation", "topology", "controller_result", "last_message", "events", "evidence_manifest",
            "evidence_lock", "evidence_verification", "terminal_result", "lineage_contract", "mount_contract",
            "invocation_source", "post_validator",
        ]},
        "native_v5_evidence_freeze_status": evidence_lock["evidence_freeze_state"],
        "native_v5_evidence_root_sha256": evidence_lock["canonical_evidence_root_sha256"],
        "native_v5_evidence_member_count": evidence_verification["member_count"],
        "governance_snapshot_status": "FROZEN_FAILURE_EVIDENCE",
        "binding_semantics": "GOVERNANCE_BINDS_EXACT_TERMINAL_BYTES_WITHOUT_RECLASSIFYING_V5_AS_PASS_OR_MUTATING_V5",
        "content_mutation_during_governance": "PROHIBITED",
    })
    write("V5_TERMINAL_DISPOSITION.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "execution_identity": V5_IDENTITY, "disposition": "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "immutable": True, "attempt": "1_OF_1_CONSUMED_NO_RETRY", "worker_invocation": 1,
        "codex_as_worker_invocation": 1, "semantic_codex_execution": 1, "runtime_exit": 0,
        "worker_result": "EMITTED_AND_CONTROLLER_WRAPPED", "candidate": "HYPOTHESIS_QUARANTINED",
        "post_validation": "55_OF_58_FAIL_CLOSED_DIAGNOSTIC_COMPLETE", "failed_post_validation_checks": post["failure_ids"],
        "confinement": "NOT_PROVEN", "pass_locked": "NOT_ISSUED", "failure_evidence": "FROZEN_FAILURE_EVIDENCE",
        "patch": "PROHIBITED", "relock": "PROHIBITED", "revalidation": "PROHIBITED", "retry": "PROHIBITED",
        "continuation": "PROHIBITED", "evidence_reclassification": "PROHIBITED", "promotion": "PROHIBITED",
    })
    write("CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V5_CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION", "schema_version": "1.0",
        "status": "DEFECT_CONFIRMED", "cross_namespace_pid_ppid_correlation_classifier_defect": "YES",
        "local_pid_equals_host_pid_assumption": "INVALID", "trace_file_pid_namespace": "HOST_OBSERVED_TRACE_PROCESS_ID",
        "clone_return_value_namespace": "TRACEE_VISIBLE_PID_NAMESPACE_CONTEXT_DEPENDENT",
        "proc_topology_pid_namespace": "HOST_OBSERVED_PROC_SNAPSHOT_WITH_EXPLICIT_NAMESPACE_ID",
        "v5_evidence": {
            "launcher_trace_file_pid": 402361, "first_namespace_child_host_pid": 402362,
            "nested_clone_parent_trace_file_pid": 402362, "nested_clone_return_local_pid": 2,
            "runtime_trace_file_pid": 402363, "runtime_proc_ppid": runtime_observation["ppid"],
            "runtime_pid_namespace": runtime_observation["pid_namespace"],
            "startup_child_trace_file_pid": 402447, "startup_child_proc_ppid": startup_observation["ppid"],
            "startup_child_pid_namespace": startup_observation["pid_namespace"],
            "v5_parent_map_local_pid_2_parent": lineage["parent_map"].get("2"),
            "v5_runtime_ancestor_chain": next(row["ancestor_chain"] for row in lineage["classified"] if row["pid"] == 402363),
        },
        "semantic_decision": {
            "expected_runtime_descendant_lineage_proven": "NO",
            "actual_unexpected_executable_execution_proven": "NO",
            "lineage_disposition": "UNKNOWN_FAIL_CLOSED",
            "confinement_pass": "NOT_PROVEN",
        },
        "v5_result_preserved": "P013_SEMANTIC_PROCESS_LINEAGE_REMAINS_FAIL_AND_IS_NOT_RECLASSIFIED",
    })
    write("CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT.json", {
        "record_type": "FIRST_WORKER_V5_CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT", "schema_version": "1.0",
        "required": True, "identity_fields": [
            "local_pid", "host_pid", "parent_local_pid", "parent_host_pid", "trace_file_pid",
            "namespace_id", "proc_topology_identity",
        ],
        "mapping_evidence_classes": [
            "TRACE_FILE_IDENTITY", "TYPED_CLONE_OR_FORK_EVENT_WITH_SOURCE_NAMESPACE",
            "PROC_TOPOLOGY_SNAPSHOT_WITH_TIMESTAMP_AND_NAMESPACE", "EXPLICIT_NAMESPACE_MEMBERSHIP",
            "LAUNCHER_CHILD_HANDSHAKE_OR_EQUIVALENT_IDENTITY_RECORD",
        ],
        "rules": {
            "single_pid_field_canonical_across_namespaces": "PROHIBITED",
            "local_pid_equals_host_pid_without_evidence": "PROHIBITED",
            "clone_return_value_as_host_pid_without_namespace_proof": "PROHIBITED",
            "trace_file_pid_as_namespace_local_pid_without_evidence": "PROHIBITED",
            "mapping_requires_evidence_refs": True,
            "mapping_requires_namespace_ids": True,
            "mapping_requires_temporally_bound_proc_topology": True,
            "ambiguous_or_reused_identity": "FAIL_CLOSED",
            "unknown_lineage": "FAIL_CLOSED",
        },
        "semantic_lineage_acceptance": "EVERY_PARENT_EDGE_AND_RUNTIME_ANCESTRY_EDGE_MUST_BE_EVIDENCE_BOUND",
    })
    rejected = writes["rejected"]
    tmpfs_rows = [row for row in rejected if row.get("mount_id") == 553 and row.get("filesystem_type") == "tmpfs"]
    dev_rows = [row for row in rejected if row.get("mount_id") == 567 and row.get("path") == "/dev/null"]
    output_rows = [row for row in rejected if row.get("mount_id") == 558]
    write("DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V5_DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION", "schema_version": "1.0",
        "status": "DEPENDENT_AUTHORIZATION_DEFECT_CONFIRMED",
        "mount_provenance_capture_defect": "NO", "producer_lineage_authorization_defect": "DEPENDENT_ON_CROSS_NAMESPACE_MAPPING_GAP",
        "v5_evidence": {
            "rejected_write_count": len(rejected), "tmpfs_mount_id_553_write_count": len(tmpfs_rows),
            "private_dev_mount_id_567_write_count": len(dev_rows), "authorized_output_mount_id_558_write_count": len(output_rows),
            "runtime_mount_namespace": topology["runtime_mount_namespace"],
            "tmpfs_mount": {"mount_id": 553, "filesystem_type": "tmpfs", "mount_point": "/home/nobcoder", "mount_source": "tmpfs"},
            "private_dev_mount": {"mount_id": 567, "filesystem_type": "devtmpfs", "mount_point": "/dev/null", "topology_origin": "BWRAP_PRIVATE_DEV"},
            "authorized_output_mount": {"mount_id": 558, "filesystem_type": "ext4", "mount_point": "/run/nobcoder-first-worker-v5/output", "topology_role": "DECLARED_HOST_OUTPUT_BIND"},
        },
        "semantic_decision": {
            "mount_provenance_may_be_resolved_independently": "YES",
            "mount_provenance_implies_producer_authorization": "NO",
            "producer_lineage_authorization_proven": "NO",
            "final_write_authorization_proven": "NO",
            "actual_out_of_scope_host_filesystem_activity_proven": "NO",
            "confinement_pass": "NOT_PROVEN",
        },
        "v5_result_preserved": "P046_MOUNT_PROVENANCE_WRITE_CLASSIFICATION_REMAINS_FAIL_AND_IS_NOT_RECLASSIFIED",
    })
    write("MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT.json", {
        "record_type": "FIRST_WORKER_V5_MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT", "schema_version": "1.0",
        "mount_provenance_gate": {
            "separate_gate": True,
            "required_fields": ["path", "mount_id", "filesystem_type", "mount_source", "mount_point", "mount_namespace", "backing_provenance", "topology_role"],
            "path_string_only_inference": "PROHIBITED", "unknown_mount_provenance": "FAIL_CLOSED",
        },
        "producer_authorization_gate": {
            "separate_gate": True,
            "required_fields": ["trace_file_pid", "host_pid", "local_pid", "namespace_id", "process_class", "lifecycle_phase", "evidence_refs"],
            "requires_cross_namespace_lineage_pass": True, "path_or_mount_class_may_not_substitute_for_lineage": True,
            "unknown_producer_lineage": "FAIL_CLOSED",
        },
        "final_write_authorization": "MOUNT_PROVENANCE_GATE_PASS_AND_PRODUCER_AUTHORIZATION_GATE_PASS",
        "partial_gate_pass_is_not_authorization": True,
    })
    write("DEFECT_OWNERSHIP_DECISION.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_DEFECT_OWNERSHIP_DECISION", "schema_version": "1.0",
        "cross_namespace_process_lineage_correlation_contract_defect": "YES",
        "pid_namespace_aware_capture_and_mapping_gap": "YES",
        "dependent_mount_write_authorization_classifier_defect": "YES",
        "mount_provenance_capture_defect": "NO", "typed_token_budget_defect": "NO_REPEATED",
        "strict_schema_compatibility_defect": "NO_REPEATED", "bind_destination_feasibility_defect": "NO_REPEATED",
        "security_worker_runtime_v1_defect": "NO", "codex_runtime_0_163_0_compatibility_defect": "NO",
        "worker_output_or_quarantine_defect": "NO", "confinement_bypass": "NO", "confinement_pass": "NOT_PROVEN",
        "owned_by": ["V5_CROSS_NAMESPACE_PROCESS_IDENTITY_CLASSIFIER", "V5_DEPENDENT_WRITE_AUTHORIZATION_CLASSIFIER"],
        "not_owned_by": ["SECURITY_WORKER_RUNTIME_V1_CONTROL_PLANE", "CODEX_0_163_0_BASE_COMPATIBILITY", "WORKER_MODEL_PROPOSAL_BEHAVIOR"],
    })
    write("FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V5_FAILURE_EVIDENCE_FREEZE_ADJUDICATION", "schema_version": "1.0",
        "decision": "V5_FROZEN_FAILURE_EVIDENCE_IS_VALID_TERMINAL_PRESERVATION_NOT_ACCEPTANCE",
        "evidence_freeze_state": evidence_lock["evidence_freeze_state"],
        "evidence_root_sha256": evidence_lock["canonical_evidence_root_sha256"],
        "evidence_member_count": evidence_verification["member_count"],
        "freeze_verification": f"{evidence_verification['checks_passed']}_OF_{evidence_verification['checks_total']}_PASS",
        "pass_locked": "NO", "acceptance_promotion": "NO", "confinement": "NOT_PROVEN",
        "successor_requirement": "IMMUTABLE_FAILURE_EVIDENCE_FREEZE_REQUIRED_FOR_ANY_POST_ATTEMPT_TERMINAL_FAILURE",
    })
    regression_cases = [
        {"id": "R001_V5_LOCAL_PID_2_NOT_HOST_PID_402363", "expected": "FAIL_CLOSED_WITHOUT_EVIDENCE_BOUND_MAPPING"},
        {"id": "R002_TRACE_FILE_PID_AND_CLONE_RETURN_SEPARATE", "expected": "PASS_TYPED_REPRESENTATION"},
        {"id": "R003_PROC_TOPOLOGY_BINDS_HOST_PARENT_402363_TO_402362", "expected": "PASS"},
        {"id": "R004_STARTUP_CHILD_HOST_402447_PARENT_402363", "expected": "PASS"},
        {"id": "R005_MISSING_NAMESPACE_ID", "expected": "FAIL_CLOSED"},
        {"id": "R006_AMBIGUOUS_PID_MAPPING", "expected": "FAIL_CLOSED"},
        {"id": "R007_TMPFS_PROVEN_PRODUCER_UNKNOWN", "expected": "MOUNT_PASS_PRODUCER_FAIL_FINAL_FAIL"},
        {"id": "R008_PRIVATE_DEV_PROVEN_PRODUCER_UNKNOWN", "expected": "MOUNT_PASS_PRODUCER_FAIL_FINAL_FAIL"},
        {"id": "R009_OUTPUT_MOUNT_PROVEN_PRODUCER_UNKNOWN", "expected": "MOUNT_PASS_PRODUCER_FAIL_FINAL_FAIL"},
        {"id": "R010_HOST_BACKED_UNAUTHORIZED_WRITE", "expected": "FAIL_CLOSED"},
        {"id": "R011_FULL_EVIDENCE_BOUND_LINEAGE_AND_ALLOWED_MOUNT", "expected": "PASS"},
        {"id": "R012_FAILURE_EVIDENCE_FREEZE_NOT_PASS_LOCKED", "expected": "PASS_TYPED_FAILURE_FREEZE"},
    ]
    write("V5_FAILURE_AND_V6_SUCCESSOR_REGRESSION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V5_FAILURE_AND_V6_SUCCESSOR_REGRESSION_MATRIX", "schema_version": "1.0",
        "cases": regression_cases, "all_cases_required_before_v6_attempt": True,
    })
    requirements = [
        "FRESH_V6_IDENTITY_SOURCE_TESTS_LOCK_AND_ONE_SHOT_ATTEMPT",
        "CROSS_NAMESPACE_PROCESS_IDENTITY_MODEL",
        "LOCAL_PID_HOST_PID_PARENT_LOCAL_PID_PARENT_HOST_PID_TRACE_FILE_PID_NAMESPACE_ID_AND_PROC_TOPOLOGY_FIELDS",
        "HOST_PID_LOCAL_PID_MAPPING_EVIDENCE_BOUND",
        "SEMANTIC_PROCESS_LINEAGE_CORRELATION",
        "NO_SINGLE_PID_FIELD_CANONICAL_ACROSS_NAMESPACES",
        "UNKNOWN_OR_AMBIGUOUS_LINEAGE_FAIL_CLOSED",
        "MOUNT_PROVENANCE_CLASSIFICATION_SEPARATE_GATE",
        "PRODUCER_AUTHORIZATION_SEPARATE_GATE",
        "MOUNT_PROVENANCE_DOES_NOT_IMPLY_PRODUCER_AUTHORIZATION",
        "FINAL_WRITE_AUTHORIZATION_REQUIRES_BOTH_GATES",
        "IMMUTABLE_FAILURE_EVIDENCE_FREEZE",
        "PROMPT_NORMALIZATION_REGRESSIONS",
        "BIND_DESTINATION_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT",
        "STRICT_SCHEMA_COMPATIBILITY_PRECHECK_BEFORE_ATTEMPT",
        "PINNED_SUPPORTED_STRICT_SCHEMA_KEYWORD_ALLOWLIST",
        "TYPED_FD_ANNOTATION_GRAMMAR",
        "DIAGNOSTIC_COMPLETE_RUNTIME_RESULT_AND_POST_VALIDATION",
        "SEMANTIC_CODEX_EXECVE_CLASSIFICATION",
        "EXACT_NAMESPACE_SETUP_WRITE_CLASSIFICATION",
        "TYPED_SYSCALL_PATH_CLASSIFICATION",
        "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE",
        "COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE",
        "STATIC_LOCK_BEFORE_ATTEMPT",
        "EXACT_CODEX_0_163_0_BINARY_CONFIG_ARGV_ENV_CWD_BINDING",
        "TYPED_TOKEN_BUDGET_CONTRACT_AND_PRECHECK",
        "EXACT_ONE_SEMANTIC_CODEX_EXEC",
        "ONE_SHOT_EXECUTION",
        "STRUCTURED_WORKER_RESULT_AND_CONTROLLER_WRAPPER",
        "PROPOSAL_ONLY_AND_HYPOTHESIS_QUARANTINED",
        "NO_SELF_PROMOTION_OR_MODEL_TOOL_CALLS",
        "DENY_CREDENTIAL_TARGET_NETWORK_SUBAGENT_PARALLEL_EXPLOIT_CAPABILITY_PROMOTION_AND_SUBMISSION",
        "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    write("SUCCESSOR_V6_REQUIREMENTS.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_SUCCESSOR_V6_REQUIREMENTS", "schema_version": "1.0",
        "successor_identity": V6_IDENTITY, "mandatory_requirements": requirements,
        "pre_attempt_failure_semantics": "STOP_FAIL_CLOSED_ATTEMPT_REMAINS_0_OF_1_WORKER_AND_CODEX_COUNTS_REMAIN_ZERO",
        "post_attempt_failure_semantics": "TERMINAL_NO_RETRY_DIAGNOSTIC_COMPLETE_FROZEN_FAILURE_EVIDENCE",
        "maximum_engineering_outcome": "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION",
    })
    write("SUCCESSOR_V6_AUTHORIZATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_SUCCESSOR_V6_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": DECISION, "authorization_effective_only_if_governance_lock_passes": True,
        "successor_identity": V6_IDENTITY, "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "scope": "ONE_CAMPAIGN_ONE_LANE_ONE_WORKER_EXACT_CODEX_0_163_0_SERIAL_LOCAL_FIXTURE_ONLY",
        "creation_or_execution_this_milestone": False,
        "attempt_count": 0, "attempt_limit": 1, "worker_invocation_count": 0, "worker_invocation_limit": 1,
        "semantic_codex_execution_count": 0, "semantic_codex_execution_limit": 1,
    })
    counters = {key: 0 for key in OPERATION_KEYS}
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "current_governance_operation_counters": counters,
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "authority_ceiling": "GOVERNANCE_ADJUDICATION_AND_CONDITIONAL_FRESH_V6_SUCCESSOR_DECISION_ONLY",
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "current_milestone": {"read_v5_evidence": "AUTHORIZED", "governance_validation": "AUTHORIZED", "governance_freeze": "AUTHORIZED"},
        "future_v6": "CONDITIONAL_ONLY_AFTER_PASS_LOCKED_GOVERNANCE_PACKAGE",
        "prohibited_current_operations": {
            "v5_mutation_or_continuation": "NOT_AUTHORIZED", "v6_creation_or_execution": "NOT_AUTHORIZED",
            "codex_invocation": "NOT_AUTHORIZED", "worker_or_subagent_invocation": "NOT_AUTHORIZED",
            "credential_use": "NOT_AUTHORIZED", "target_or_network_access": "NOT_AUTHORIZED",
            "daybreak_invocation": "NOT_AUTHORIZED", "exploit_replay": "NOT_AUTHORIZED",
            "parallelism": "NOT_AUTHORIZED", "capability_graph": "NOT_AUTHORIZED",
            "candidate_promotion": "NOT_AUTHORIZED", "submission_automation": "NOT_AUTHORIZED",
        },
    })
    negative_cases = [
        ("N001_V5_DISPOSITION_MUTATION", "Change V5 terminal disposition"),
        ("N002_ATTEMPT_RESET", "Reset consumed V5 attempt"),
        ("N003_WORKER_COUNT_ERASURE", "Erase V5 worker invocation"),
        ("N004_CODEX_COUNT_ERASURE", "Erase V5 Codex invocation"),
        ("N005_V5_RETRY", "Authorize V5 retry"),
        ("N006_V5_REVALIDATION", "Authorize V5 revalidation"),
        ("N007_V5_RECLASSIFICATION", "Rewrite locked V5 failed checks"),
        ("N008_LOCAL_PID_EQUALS_HOST", "Map namespace-local PID to host PID by integer equality"),
        ("N009_CLONE_RETURN_AS_HOST_PID", "Treat clone return as host PID without namespace proof"),
        ("N010_TRACE_PID_AS_LOCAL_PID", "Treat trace-file PID as local PID without evidence"),
        ("N011_MISSING_NAMESPACE_ID", "Accept mapping without namespace identity"),
        ("N012_MISSING_MAPPING_EVIDENCE", "Accept mapping without evidence references"),
        ("N013_STALE_PROC_TOPOLOGY", "Accept temporally unbound proc topology"),
        ("N014_AMBIGUOUS_MAPPING", "Accept one local PID mapped to multiple host PIDs"),
        ("N015_REUSED_LOCAL_PID", "Ignore local PID reuse across namespaces"),
        ("N016_UNKNOWN_LINEAGE_ALLOW", "Permit unknown producer lineage"),
        ("N017_MOUNT_IMPLIES_PRODUCER", "Authorize writer from mount provenance alone"),
        ("N018_PATH_IMPLIES_TMPFS", "Infer tmpfs from path prefix"),
        ("N019_PATH_IMPLIES_PRIVATE_DEV", "Infer private dev from /dev path only"),
        ("N020_OUTPUT_MOUNT_AUTO_AUTH", "Authorize output write without producer lineage"),
        ("N021_UNKNOWN_MOUNT_ALLOW", "Permit unknown mount provenance"),
        ("N022_MERGED_WRITE_GATES", "Collapse provenance and producer gates"),
        ("N023_FAILURE_FREEZE_AS_PASS", "Treat frozen failure evidence as PASS_LOCKED"),
        ("N024_FAILURE_EVIDENCE_OVERWRITE", "Overwrite V5 frozen failure evidence"),
        ("N025_V6_CREATED", "Create V6 during governance"),
        ("N026_CURRENT_CODEX_AUTHORITY", "Authorize Codex invocation now"),
        ("N027_TARGET_NETWORK_AUTHORITY", "Authorize target or network"),
        ("N028_CREDENTIAL_AUTHORITY", "Authorize credential use"),
        ("N029_SUBAGENT_PARALLEL_AUTHORITY", "Authorize subagent or parallelism"),
        ("N030_CAPABILITY_PROMOTION_AUTHORITY", "Authorize capability edge or promotion"),
        ("N031_SUBMISSION_AUTHORITY", "Authorize submission"),
        ("N032_DROP_ONE_SHOT_OR_ACCEPTANCE", "Remove one-shot or separate acceptance"),
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0",
        "cases": [{"case_id": case_id, "mutation": mutation, "expected": "REJECT"} for case_id, mutation in negative_cases],
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "governance_status_before_freeze": "VALIDATION_REQUIRED", "v5_disposition": "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "v5_immutable": True, "attempt": "1_OF_1_CONSUMED_NO_RETRY", "worker_invocation": 1,
        "codex_as_worker_invocation": 1, "semantic_codex_execution": 1, "runtime_exit": 0,
        "worker_result": "EMITTED_AND_CONTROLLER_WRAPPED", "candidate": "HYPOTHESIS_QUARANTINED",
        "post_validation": "55_OF_58_FAIL_CLOSED_DIAGNOSTIC_COMPLETE", "confinement": "NOT_PROVEN",
        "failure_evidence_status": "FROZEN_FAILURE_EVIDENCE", "pass_locked": "NO",
        "cross_namespace_pid_ppid_correlation_classifier_defect": "YES",
        "dependent_mount_write_authorization_classifier_defect": "YES",
        "mount_provenance_capture_defect": "NO", "successor_decision": DECISION,
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "FIRST_WORKER_V5_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_if_pass_locked": NEXT, "separate_acceptance_after_v6": "REQUIRED",
        "v5_may_be_modified_reclassified_or_executed": False,
        "v6_may_be_created_during_this_governance_milestone": False,
    })
    print(json.dumps({"status": "BUILT", "identity": IDENTITY, "base_artifacts": 20, "v5_members_bound": len(rows)}, sort_keys=True))


if __name__ == "__main__":
    main()
