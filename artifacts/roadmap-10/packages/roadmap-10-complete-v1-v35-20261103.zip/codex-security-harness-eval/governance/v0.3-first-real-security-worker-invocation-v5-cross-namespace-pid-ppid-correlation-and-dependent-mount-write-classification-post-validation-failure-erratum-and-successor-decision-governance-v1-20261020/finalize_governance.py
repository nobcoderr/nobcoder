#!/usr/bin/env python3
"""Final freeze verification, manifest, lock, and read-only freeze."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V5 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v6-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_CROSS_NAMESPACE_PID_PPID_CORRELATION_AND_DEPENDENT_MOUNT_WRITE_CLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6_ONCE_IF_ALL_GATES_PASS"
V5_ROOT = "ec95c4806ce0b8bef7690de362bb4a8c25a6b785faf5ae47b23a5fa60abf6927"
V5_EVIDENCE_ROOT = "1bd623deae197f326e8aed9c21df9b4797acceae1b9c8e10b0911e8fdb0784a2"
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json", "V5_TERMINAL_EVIDENCE_BINDING.json", "V5_TERMINAL_DISPOSITION.json",
    "CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION.json", "CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT.json",
    "DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION.json", "MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT.json",
    "DEFECT_OWNERSHIP_DECISION.json", "FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json",
    "V5_FAILURE_AND_V6_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V6_REQUIREMENTS.json",
    "SUCCESSOR_V6_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json",
    "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def tree(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted(node for node in path.rglob("*") if node.is_file())]
    material = "".join(f"{digest}  {name}\n" for name, digest in rows).encode()
    return hashlib.sha256(material).hexdigest(), len(rows)


def canonical(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"finalizer input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SCRIPT_" + script, valid)
    v5_root, v5_members = tree(V5)
    check("F001_V5_UNCHANGED", v5_root == V5_ROOT and v5_members == 117, {"root": v5_root, "members": v5_members})
    check("F002_V6_ABSENT", not V6.exists() and not V6.is_symlink())
    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    historical_negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    independent = read("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F003_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_failed"] == 0)
    check("F004_HISTORICAL_NEGATIVE_PRESERVED", historical_negative["status"] == "FAIL_CLOSED" and historical_negative["tests_passed"] == 25 and historical_negative["tests_failed"] == 7)
    check("F004A_NEGATIVE_PASS", negative["status"] == "PASS" and negative["tests_passed"] == 32 and negative["tests_failed"] == 0 and negative["historical_predecessor_run"] == "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("F005_INDEPENDENT_PASS", independent["status"] == "PASS" and independent["checks_failed"] == 0)
    check("F006_RESULT_IDENTITIES", all(doc["governance_identity"] == IDENTITY for doc in [primary, historical_negative, negative, independent]))
    terminal = read("V5_TERMINAL_DISPOSITION.json")
    binding = read("V5_TERMINAL_EVIDENCE_BINDING.json")
    snapshot = read("V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json")
    corr = read("CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION.json")
    identity_contract = read("CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT.json")
    mount = read("DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION.json")
    write_contract = read("MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT.json")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    failure_freeze = read("FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json")
    requirements = read("SUCCESSOR_V6_REQUIREMENTS.json")
    successor = read("SUCCESSOR_V6_AUTHORIZATION_DECISION.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    summary = read("GOVERNANCE_DECISION_SUMMARY.json")
    next_step = read("NEXT_LEGAL_MILESTONE.json")
    check("F007_V5_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY" and terminal["immutable"] is True)
    check("F008_V5_COUNTS", terminal["attempt"] == "1_OF_1_CONSUMED_NO_RETRY" and terminal["worker_invocation"] == 1 and terminal["codex_as_worker_invocation"] == 1 and terminal["semantic_codex_execution"] == 1)
    check("F009_V5_OUTPUT", terminal["runtime_exit"] == 0 and terminal["worker_result"] == "EMITTED_AND_CONTROLLER_WRAPPED" and terminal["candidate"] == "HYPOTHESIS_QUARANTINED")
    check("F010_V5_FAILURE", terminal["post_validation"] == "55_OF_58_FAIL_CLOSED_DIAGNOSTIC_COMPLETE" and terminal["confinement"] == "NOT_PROVEN" and terminal["pass_locked"] == "NOT_ISSUED")
    check("F011_NO_V5_CONTINUATION", all(terminal[key] == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "evidence_reclassification", "promotion"]))
    check("F012_SNAPSHOT", snapshot["canonical_tree_root_sha256"] == V5_ROOT and snapshot["member_count"] == len(snapshot["members"]) == 117)
    check("F013_BINDING", binding["native_v5_evidence_freeze_status"] == "FROZEN_FAILURE_EVIDENCE" and binding["native_v5_evidence_root_sha256"] == V5_EVIDENCE_ROOT)
    check("F014_CORRELATION_DEFECT", corr["cross_namespace_pid_ppid_correlation_classifier_defect"] == "YES" and corr["local_pid_equals_host_pid_assumption"] == "INVALID")
    check("F015_PID_EVIDENCE", corr["v5_evidence"]["nested_clone_return_local_pid"] == 2 and corr["v5_evidence"]["runtime_trace_file_pid"] == 402363 and corr["v5_evidence"]["runtime_proc_ppid"] == 402362)
    check("F016_LINEAGE_UNKNOWN", corr["semantic_decision"]["lineage_disposition"] == "UNKNOWN_FAIL_CLOSED" and corr["semantic_decision"]["expected_runtime_descendant_lineage_proven"] == "NO")
    check("F017_NO_EXEC_RECLASSIFICATION", corr["semantic_decision"]["actual_unexpected_executable_execution_proven"] == "NO" and "REMAINS_FAIL" in corr["v5_result_preserved"])
    fields = set(identity_contract["identity_fields"])
    check("F018_IDENTITY_MODEL", fields == {"local_pid", "host_pid", "parent_local_pid", "parent_host_pid", "trace_file_pid", "namespace_id", "proc_topology_identity"})
    check("F019_EVIDENCE_BOUND_MAPPING", identity_contract["rules"]["mapping_requires_evidence_refs"] is True and identity_contract["rules"]["mapping_requires_namespace_ids"] is True)
    check("F020_UNKNOWN_LINEAGE", identity_contract["rules"]["unknown_lineage"] == "FAIL_CLOSED" and identity_contract["rules"]["ambiguous_or_reused_identity"] == "FAIL_CLOSED")
    check("F021_MOUNT_SEPARATE", mount["mount_provenance_capture_defect"] == "NO" and mount["semantic_decision"]["mount_provenance_implies_producer_authorization"] == "NO")
    check("F022_PRODUCER_UNPROVEN", mount["semantic_decision"]["producer_lineage_authorization_proven"] == "NO" and mount["semantic_decision"]["final_write_authorization_proven"] == "NO")
    check("F023_NO_HOST_ACTIVITY_PROMOTION", mount["semantic_decision"]["actual_out_of_scope_host_filesystem_activity_proven"] == "NO" and mount["semantic_decision"]["confinement_pass"] == "NOT_PROVEN")
    check("F024_TWO_GATES", write_contract["mount_provenance_gate"]["separate_gate"] is True and write_contract["producer_authorization_gate"]["separate_gate"] is True and write_contract["partial_gate_pass_is_not_authorization"] is True)
    check("F025_OWNERSHIP", ownership["cross_namespace_process_lineage_correlation_contract_defect"] == "YES" and ownership["dependent_mount_write_authorization_classifier_defect"] == "YES")
    check("F026_NO_BASE_DEFECT", ownership["security_worker_runtime_v1_defect"] == "NO" and ownership["codex_runtime_0_163_0_compatibility_defect"] == "NO" and ownership["worker_output_or_quarantine_defect"] == "NO")
    check("F027_FAILURE_FREEZE", failure_freeze["evidence_freeze_state"] == "FROZEN_FAILURE_EVIDENCE" and failure_freeze["pass_locked"] == "NO" and failure_freeze["acceptance_promotion"] == "NO")
    check("F028_SUCCESSOR", successor["decision"] == DECISION and successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F029_SUCCESSOR_ZERO", successor["attempt_count"] == 0 and successor["worker_invocation_count"] == 0 and successor["semantic_codex_execution_count"] == 0)
    required = set(requirements["mandatory_requirements"])
    check("F030_REQUIREMENTS", {"CROSS_NAMESPACE_PROCESS_IDENTITY_MODEL", "HOST_PID_LOCAL_PID_MAPPING_EVIDENCE_BOUND", "SEMANTIC_PROCESS_LINEAGE_CORRELATION", "MOUNT_PROVENANCE_CLASSIFICATION_SEPARATE_GATE", "PRODUCER_AUTHORIZATION_SEPARATE_GATE", "IMMUTABLE_FAILURE_EVIDENCE_FREEZE", "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION"}.issubset(required))
    counters = authority["current_governance_operation_counters"]
    check("F031_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {key: value for key, value in authority.items() if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False}
    check("F032_NO_CURRENT_ESCALATION", not escalations, escalations)
    check("F033_SUMMARY", summary["successor_decision"] == DECISION and summary["confinement"] == "NOT_PROVEN" and summary["pass_locked"] == "NO")
    check("F034_NEXT", next_step["next_if_pass_locked"] == NEXT and next_step["v6_may_be_created_during_this_governance_milestone"] is False)
    failed = [row for row in checks if row["status"] == "FAIL"]
    if failed:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failed))
    write(FREEZE, {
        "record_type": "FIRST_WORKER_V5_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT", "schema_version": "1.0",
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001", "status": "PASS",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "v5_tree_root_sha256": V5_ROOT, "v5_member_count": 117, "v6_absent": True,
        "v5_failure_evidence_root_sha256": V5_EVIDENCE_ROOT,
        "failure_evidence_state": "FROZEN_FAILURE_EVIDENCE", "failure_evidence_does_not_imply_pass_locked": True,
        "current_governance_operation_counters": counters, "read_only_freeze_enforced_by_successful_finalizer_exit": True,
    })
    names = sorted(expected | {FREEZE})
    rows = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in names]
    artifact_root = canonical(rows)
    write(MANIFEST, {
        "record_type": "FIRST_WORKER_V5_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0",
        "member_count": len(rows), "members": rows, "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    snapshot_sha = sha(ROOT / "V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json")
    write(LOCK, {
        "record_type": "FIRST_WORKER_V5_ERRATUM_GOVERNANCE_LOCK", "schema_version": "1.0",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "v5_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5",
        "v5_disposition": "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY", "v5_immutable": True,
        "v5_attempt_count": 1, "v5_attempt_limit": 1, "v5_worker_invocation_count": 1,
        "v5_codex_as_worker_invocation_count": 1, "v5_semantic_codex_execution_count": 1, "v5_runtime_exit": 0,
        "v5_worker_result": "EMITTED_AND_CONTROLLER_WRAPPED", "v5_candidate": "HYPOTHESIS_QUARANTINED",
        "v5_post_validation": "55_OF_58_FAIL_CLOSED_DIAGNOSTIC_COMPLETE", "v5_confinement": "NOT_PROVEN", "v5_pass_locked": "NOT_ISSUED",
        "v5_failure_evidence_status": "FROZEN_FAILURE_EVIDENCE", "v5_failure_evidence_root_sha256": V5_EVIDENCE_ROOT,
        "v5_failure_evidence_snapshot_manifest_sha256": snapshot_sha, "v5_workspace_root_sha256": V5_ROOT,
        "failure_freeze_implies_pass_locked": False,
        "cross_namespace_process_lineage_correlation_contract_defect": "YES",
        "local_pid_equals_host_pid_assumption": "PROHIBITED",
        "cross_namespace_process_identity_model": "REQUIRED",
        "identity_fields": ["local_pid", "host_pid", "parent_local_pid", "parent_host_pid", "trace_file_pid", "namespace_id", "proc_topology_identity"],
        "host_pid_local_pid_mapping": "EVIDENCE_BOUND",
        "semantic_process_lineage_correlation": "REQUIRED", "unknown_or_ambiguous_lineage": "FAIL_CLOSED",
        "mount_provenance_capture_defect": "NO", "dependent_mount_write_authorization_classifier_defect": "YES",
        "mount_provenance_classification": "SEPARATE_GATE", "producer_authorization": "SEPARATE_GATE",
        "mount_provenance_implies_producer_authorization": False,
        "final_write_authorization": "MOUNT_PROVENANCE_GATE_PASS_AND_PRODUCER_AUTHORIZATION_GATE_PASS",
        "producer_lineage_authorization_in_v5": "NOT_PROVEN", "actual_out_of_scope_host_filesystem_activity_proven": "NO",
        "security_worker_runtime_v1_defect": "NO", "codex_runtime_0_163_0_compatibility_defect": "NO",
        "worker_output_or_quarantine_defect": "NO", "confinement_bypass": "NO",
        "v6_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6",
        "v6_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v6_attempt_count": 0, "v6_attempt_limit": 1, "v6_worker_invocation_count": 0, "v6_worker_invocation_limit": 1,
        "v6_semantic_codex_execution_count": 0, "v6_semantic_codex_execution_limit": 1,
        "one_shot_execution": "REQUIRED", "immutable_failure_evidence_freeze": "REQUIRED",
        "separate_acceptance_adjudication": "REQUIRED",
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "validation": {
            "primary": {"status": primary["status"], "passed": primary["checks_passed"], "total": primary["checks_total"]},
            "negative": {"status": negative["status"], "passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent": {"status": independent["status"], "passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        },
        "operation_counters": counters, "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root, "next_legal_milestone": NEXT,
        "authority_ceiling": "V6_ENGINEERING_AND_ONE_LOCAL_FIXTURE_WORKER_INVOCATION_CONDITIONALLY_AUTHORIZED_ONLY_AFTER_THIS_LOCK_NO_CURRENT_RUNTIME_TARGET_CREDENTIAL_SUBAGENT_OR_PARALLEL_AUTHORITY",
    })
    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    readonly = all((path.stat().st_mode & 0o222) == 0 for path in ROOT.iterdir() if path.is_file())
    v5_after, count_after = tree(V5)
    if not readonly or v5_after != V5_ROOT or count_after != 117 or V6.exists():
        raise SystemExit("post-freeze verification failed")
    print(json.dumps({"status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION, "manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root, "files": len(rows) + 2}, sort_keys=True))


if __name__ == "__main__":
    main()
