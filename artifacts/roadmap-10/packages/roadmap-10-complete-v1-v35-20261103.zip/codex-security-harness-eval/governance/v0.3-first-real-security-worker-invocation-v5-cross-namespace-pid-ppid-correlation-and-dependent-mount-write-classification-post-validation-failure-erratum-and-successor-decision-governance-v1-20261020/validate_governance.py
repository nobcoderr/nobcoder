#!/usr/bin/env python3
"""Primary validation and executable negative fixtures for the V5 erratum."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V5 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v6-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_CROSS_NAMESPACE_PID_PPID_CORRELATION_AND_DEPENDENT_MOUNT_WRITE_CLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6_CONDITIONALLY"
V5_ROOT = "ec95c4806ce0b8bef7690de362bb4a8c25a6b785faf5ae47b23a5fa60abf6927"
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json", "V5_TERMINAL_EVIDENCE_BINDING.json", "V5_TERMINAL_DISPOSITION.json",
    "CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION.json", "CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT.json",
    "DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION.json", "MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT.json",
    "DEFECT_OWNERSHIP_DECISION.json", "FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json",
    "V5_FAILURE_AND_V6_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V6_REQUIREMENTS.json",
    "SUCCESSOR_V6_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
PRIMARY_RESULT = "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"
NEGATIVE_RESULT_RUN1 = "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"
NEGATIVE_RESULT_RUN2 = "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted(node for node in path.rglob("*") if node.is_file())]
    material = "".join(f"{digest}  {name}\n" for name, digest in rows).encode()
    return hashlib.sha256(material).hexdigest(), len(rows)


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def pid_mapping_allowed(fixture: dict[str, Any]) -> bool:
    required = {
        "local_pid", "host_pid", "parent_local_pid", "parent_host_pid", "trace_file_pid",
        "namespace_id", "proc_topology_identity", "mapping_evidence_refs", "proc_snapshot_bound",
    }
    if not required.issubset(fixture):
        return False
    if not fixture["namespace_id"] or not fixture["mapping_evidence_refs"] or not fixture["proc_snapshot_bound"]:
        return False
    if fixture.get("ambiguous") or fixture.get("reused_without_namespace_key"):
        return False
    if fixture.get("basis") in {"INTEGER_EQUALITY_ONLY", "CLONE_RETURN_ONLY", "TRACE_FILENAME_ONLY"}:
        return False
    if fixture["local_pid"] == fixture["host_pid"] and fixture.get("cross_namespace") and not fixture.get("same_value_evidence"):
        return False
    return True


def write_authorized(fixture: dict[str, Any]) -> bool:
    provenance = fixture.get("mount_provenance")
    producer = fixture.get("producer_authorization")
    if provenance not in {"EPHEMERAL_SANDBOX_TMPFS", "PRIVATE_DEV_OBJECT", "AUTHORIZED_HOST_OUTPUT"}:
        return False
    if fixture.get("path_only") or fixture.get("merged_gate"):
        return False
    if producer != "PASS_EVIDENCE_BOUND_LINEAGE":
        return False
    return True


def authority_mutation_rejected(case_id: str, terminal: dict[str, Any], authority: dict[str, Any], operation: dict[str, Any]) -> bool:
    if case_id == "N001_V5_DISPOSITION_MUTATION":
        return terminal["immutable"] and terminal["disposition"].endswith("REFERENCE_ONLY")
    if case_id == "N002_ATTEMPT_RESET":
        return terminal["attempt"] == "1_OF_1_CONSUMED_NO_RETRY"
    if case_id == "N003_WORKER_COUNT_ERASURE":
        return terminal["worker_invocation"] == 1
    if case_id == "N004_CODEX_COUNT_ERASURE":
        return terminal["codex_as_worker_invocation"] == 1 and terminal["semantic_codex_execution"] == 1
    if case_id in {"N005_V5_RETRY", "N006_V5_REVALIDATION", "N007_V5_RECLASSIFICATION"}:
        key = {"N005_V5_RETRY": "retry", "N006_V5_REVALIDATION": "revalidation", "N007_V5_RECLASSIFICATION": "evidence_reclassification"}[case_id]
        return terminal[key] == "PROHIBITED"
    if case_id in {"N023_FAILURE_FREEZE_AS_PASS", "N024_FAILURE_EVIDENCE_OVERWRITE"}:
        return terminal["pass_locked"] == "NOT_ISSUED" and terminal["failure_evidence"] == "FROZEN_FAILURE_EVIDENCE" and terminal["evidence_reclassification"] == "PROHIBITED"
    if case_id == "N025_V6_CREATED":
        return not V6.exists() and operation["prohibited_current_operations"]["v6_creation_or_execution"] == "NOT_AUTHORIZED"
    mapping = {
        "N026_CURRENT_CODEX_AUTHORITY": "codex_as_worker_invocation_authorized_now",
        "N027_TARGET_NETWORK_AUTHORITY": "target_access_authorized",
        "N028_CREDENTIAL_AUTHORITY": "credential_use_authorized",
        "N029_SUBAGENT_PARALLEL_AUTHORITY": "subagent_authorized",
        "N030_CAPABILITY_PROMOTION_AUTHORITY": "candidate_promotion_authorized",
        "N031_SUBMISSION_AUTHORITY": "submission_automation_authorized",
    }
    if case_id in mapping:
        if authority[mapping[case_id]] is not False:
            return False
        if case_id == "N027_TARGET_NETWORK_AUTHORITY":
            return authority["external_network_authorized"] is False
        if case_id == "N029_SUBAGENT_PARALLEL_AUTHORITY":
            return authority["parallelism_authorized"] is False
        if case_id == "N030_CAPABILITY_PROMOTION_AUTHORITY":
            return authority["capability_graph_authorized"] is False
        return True
    if case_id == "N032_DROP_ONE_SHOT_OR_ACCEPTANCE":
        req = set(read("SUCCESSOR_V6_REQUIREMENTS.json")["mandatory_requirements"])
        return {"ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION"}.issubset(req)
    return False


def run_negative(matrix: dict[str, Any], terminal: dict[str, Any], authority: dict[str, Any], operation: dict[str, Any]) -> list[dict[str, Any]]:
    valid_mapping = {
        "local_pid": 1, "host_pid": 1001, "parent_local_pid": 0, "parent_host_pid": 1000,
        "trace_file_pid": 1001, "namespace_id": "pid:[x]", "proc_topology_identity": "proc-snapshot-1",
        "mapping_evidence_refs": ["trace-1", "proc-1"], "proc_snapshot_bound": True,
        "basis": "TRACE_PLUS_PROC_PLUS_NAMESPACE", "cross_namespace": True, "same_value_evidence": False,
        "ambiguous": False, "reused_without_namespace_key": False,
    }
    cases: dict[str, bool] = {}
    for case in matrix["cases"]:
        cid = case["case_id"]
        if cid[1:4].isdigit() and 8 <= int(cid[1:4]) <= 16:
            fixture = dict(valid_mapping)
            if cid == "N008_LOCAL_PID_EQUALS_HOST":
                fixture.update(local_pid=1001, host_pid=1001, basis="INTEGER_EQUALITY_ONLY")
            elif cid == "N009_CLONE_RETURN_AS_HOST_PID":
                fixture["basis"] = "CLONE_RETURN_ONLY"
            elif cid == "N010_TRACE_PID_AS_LOCAL_PID":
                fixture["basis"] = "TRACE_FILENAME_ONLY"
            elif cid == "N011_MISSING_NAMESPACE_ID":
                fixture["namespace_id"] = None
            elif cid == "N012_MISSING_MAPPING_EVIDENCE":
                fixture["mapping_evidence_refs"] = []
            elif cid == "N013_STALE_PROC_TOPOLOGY":
                fixture["proc_snapshot_bound"] = False
            elif cid == "N014_AMBIGUOUS_MAPPING":
                fixture["ambiguous"] = True
            elif cid == "N015_REUSED_LOCAL_PID":
                fixture["reused_without_namespace_key"] = True
            elif cid == "N016_UNKNOWN_LINEAGE_ALLOW":
                fixture.pop("parent_host_pid")
            cases[cid] = not pid_mapping_allowed(fixture)
        elif cid in {"N017_MOUNT_IMPLIES_PRODUCER", "N018_PATH_IMPLIES_TMPFS", "N019_PATH_IMPLIES_PRIVATE_DEV", "N020_OUTPUT_MOUNT_AUTO_AUTH", "N021_UNKNOWN_MOUNT_ALLOW", "N022_MERGED_WRITE_GATES"}:
            fixture = {"mount_provenance": "EPHEMERAL_SANDBOX_TMPFS", "producer_authorization": "PASS_EVIDENCE_BOUND_LINEAGE", "path_only": False, "merged_gate": False}
            if cid == "N017_MOUNT_IMPLIES_PRODUCER":
                fixture["producer_authorization"] = "UNKNOWN"
            elif cid == "N018_PATH_IMPLIES_TMPFS":
                fixture["path_only"] = True
            elif cid == "N019_PATH_IMPLIES_PRIVATE_DEV":
                fixture.update(mount_provenance="PRIVATE_DEV_OBJECT", path_only=True)
            elif cid == "N020_OUTPUT_MOUNT_AUTO_AUTH":
                fixture.update(mount_provenance="AUTHORIZED_HOST_OUTPUT", producer_authorization="UNKNOWN")
            elif cid == "N021_UNKNOWN_MOUNT_ALLOW":
                fixture["mount_provenance"] = "UNKNOWN"
            elif cid == "N022_MERGED_WRITE_GATES":
                fixture["merged_gate"] = True
            cases[cid] = not write_authorized(fixture)
        else:
            cases[cid] = authority_mutation_rejected(cid, terminal, authority, operation)
    return [{"case_id": case["case_id"], "expected": "REJECT", "status": "PASS" if cases[case["case_id"]] else "FAIL"} for case in matrix["cases"]]


def main() -> None:
    rerun = (ROOT / PRIMARY_RESULT).exists() or (ROOT / NEGATIVE_RESULT_RUN1).exists()
    expected = SCRIPTS | BASE | ({PRIMARY_RESULT, NEGATIVE_RESULT_RUN1} if rerun else set())
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"primary input set mismatch: {sorted(actual)}")
    if rerun:
        if not ((ROOT / PRIMARY_RESULT).exists() and (ROOT / NEGATIVE_RESULT_RUN1).exists()):
            raise SystemExit("partial historical validation result set")
        historical_primary = read(PRIMARY_RESULT)
        historical_negative = read(NEGATIVE_RESULT_RUN1)
        if historical_primary.get("status") != "PASS" or historical_primary.get("checks_failed") != 0:
            raise SystemExit("historical primary result is not PASS")
        if historical_negative.get("status") != "FAIL_CLOSED" or historical_negative.get("tests_failed", 0) == 0:
            raise SystemExit("historical negative result is not preserved FAIL_CLOSED")
        terminal = read("V5_TERMINAL_DISPOSITION.json")
        authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
        operation = read("OPERATION_AUTHORIZATION_MATRIX.json")
        matrix = read("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
        outcomes = run_negative(matrix, terminal, authority, operation)
        negative_failed = [row for row in outcomes if row["status"] == "FAIL"]
        write(NEGATIVE_RESULT_RUN2, {
            "record_type": "FIRST_WORKER_V5_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT", "schema_version": "1.0",
            "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0002", "status": "PASS" if not negative_failed else "FAIL_CLOSED",
            "historical_predecessor_run": NEGATIVE_RESULT_RUN1,
            "historical_predecessor_status": historical_negative["status"],
            "results": outcomes, "tests_total": len(outcomes), "tests_passed": len(outcomes) - len(negative_failed), "tests_failed": len(negative_failed),
            "operation_counters": authority["current_governance_operation_counters"],
        })
        print(json.dumps({"historical_negative": f"{historical_negative['tests_passed']}/{historical_negative['tests_total']}", "negative_run_0002": f"{len(outcomes) - len(negative_failed)}/{len(outcomes)}", "status": "PASS" if not negative_failed else "FAIL_CLOSED"}, sort_keys=True))
        if negative_failed:
            raise SystemExit("negative governance fixtures RUN-0002 failed")
        return
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("G_SCRIPT_" + script, valid)
    docs = {name: read(name) for name in BASE}
    check("G001_EXACT_BASE_SET", actual == expected)
    check("G002_IDENTITIES", all(doc.get("governance_identity") == IDENTITY for doc in docs.values()))
    v5_root, v5_members = tree(V5)
    check("G003_V5_IMMUTABLE_ROOT", v5_root == V5_ROOT and v5_members == 117, {"root": v5_root, "members": v5_members})
    check("G004_V6_ABSENT", not V6.exists() and not V6.is_symlink())
    terminal = docs["V5_TERMINAL_DISPOSITION.json"]
    check("G005_V5_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY" and terminal["immutable"] is True)
    check("G006_V5_COUNTS", terminal["attempt"] == "1_OF_1_CONSUMED_NO_RETRY" and terminal["worker_invocation"] == 1 and terminal["codex_as_worker_invocation"] == 1 and terminal["semantic_codex_execution"] == 1)
    check("G007_V5_RESULT", terminal["runtime_exit"] == 0 and terminal["worker_result"] == "EMITTED_AND_CONTROLLER_WRAPPED" and terminal["candidate"] == "HYPOTHESIS_QUARANTINED")
    check("G008_V5_FAILURE", terminal["post_validation"] == "55_OF_58_FAIL_CLOSED_DIAGNOSTIC_COMPLETE" and terminal["confinement"] == "NOT_PROVEN" and terminal["pass_locked"] == "NOT_ISSUED")
    check("G009_NO_V5_CONTINUATION", all(terminal[key] == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "evidence_reclassification", "promotion"]))
    binding = docs["V5_TERMINAL_EVIDENCE_BINDING.json"]
    check("G010_FROZEN_EVIDENCE", binding["native_v5_evidence_freeze_status"] == "FROZEN_FAILURE_EVIDENCE" and binding["native_v5_evidence_root_sha256"] == "1bd623deae197f326e8aed9c21df9b4797acceae1b9c8e10b0911e8fdb0784a2")
    snapshot = docs["V5_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json"]
    check("G011_SNAPSHOT_COMPLETE", snapshot["canonical_tree_root_sha256"] == V5_ROOT and snapshot["member_count"] == len(snapshot["members"]) == 117)
    corr = docs["CROSS_NAMESPACE_PID_PPID_CORRELATION_ADJUDICATION.json"]
    check("G012_CORRELATION_DEFECT", corr["cross_namespace_pid_ppid_correlation_classifier_defect"] == "YES" and corr["local_pid_equals_host_pid_assumption"] == "INVALID")
    evidence = corr["v5_evidence"]
    check("G013_PID_DIFFERENTIAL", evidence["nested_clone_return_local_pid"] == 2 and evidence["runtime_trace_file_pid"] == 402363 and evidence["runtime_proc_ppid"] == 402362)
    check("G014_LINEAGE_UNKNOWN", corr["semantic_decision"]["expected_runtime_descendant_lineage_proven"] == "NO" and corr["semantic_decision"]["lineage_disposition"] == "UNKNOWN_FAIL_CLOSED")
    check("G015_NO_UNEXPECTED_EXEC_PROOF", corr["semantic_decision"]["actual_unexpected_executable_execution_proven"] == "NO")
    identity_contract = docs["CROSS_NAMESPACE_PROCESS_IDENTITY_CONTRACT.json"]
    check("G016_IDENTITY_FIELDS", set(identity_contract["identity_fields"]) == {"local_pid", "host_pid", "parent_local_pid", "parent_host_pid", "trace_file_pid", "namespace_id", "proc_topology_identity"})
    check("G017_EVIDENCE_BOUND", identity_contract["rules"]["mapping_requires_evidence_refs"] is True and identity_contract["rules"]["unknown_lineage"] == "FAIL_CLOSED")
    mount = docs["DEPENDENT_MOUNT_WRITE_CLASSIFICATION_ADJUDICATION.json"]
    check("G018_MOUNT_SEPARATION", mount["mount_provenance_capture_defect"] == "NO" and mount["semantic_decision"]["mount_provenance_implies_producer_authorization"] == "NO")
    check("G019_PRODUCER_UNPROVEN", mount["semantic_decision"]["producer_lineage_authorization_proven"] == "NO" and mount["semantic_decision"]["final_write_authorization_proven"] == "NO")
    check("G020_NO_HOST_WRITE_PROOF", mount["semantic_decision"]["actual_out_of_scope_host_filesystem_activity_proven"] == "NO" and mount["semantic_decision"]["confinement_pass"] == "NOT_PROVEN")
    write_contract = docs["MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_CONTRACT.json"]
    check("G021_TWO_WRITE_GATES", write_contract["mount_provenance_gate"]["separate_gate"] is True and write_contract["producer_authorization_gate"]["separate_gate"] is True)
    check("G022_BOTH_REQUIRED", write_contract["final_write_authorization"] == "MOUNT_PROVENANCE_GATE_PASS_AND_PRODUCER_AUTHORIZATION_GATE_PASS" and write_contract["partial_gate_pass_is_not_authorization"] is True)
    ownership = docs["DEFECT_OWNERSHIP_DECISION.json"]
    check("G023_OWNERSHIP", ownership["cross_namespace_process_lineage_correlation_contract_defect"] == "YES" and ownership["dependent_mount_write_authorization_classifier_defect"] == "YES")
    check("G024_NO_BASE_DEFECT", ownership["security_worker_runtime_v1_defect"] == "NO" and ownership["codex_runtime_0_163_0_compatibility_defect"] == "NO" and ownership["worker_output_or_quarantine_defect"] == "NO")
    check("G025_CONFINEMENT", ownership["confinement_bypass"] == "NO" and ownership["confinement_pass"] == "NOT_PROVEN")
    freeze = docs["FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json"]
    check("G026_FAILURE_FREEZE", freeze["evidence_freeze_state"] == "FROZEN_FAILURE_EVIDENCE" and freeze["pass_locked"] == "NO" and freeze["acceptance_promotion"] == "NO")
    successor = docs["SUCCESSOR_V6_AUTHORIZATION_DECISION.json"]
    check("G027_SUCCESSOR", successor["decision"] == DECISION and successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("G028_SUCCESSOR_ZERO", successor["attempt_count"] == 0 and successor["worker_invocation_count"] == 0 and successor["semantic_codex_execution_count"] == 0)
    required = set(docs["SUCCESSOR_V6_REQUIREMENTS.json"]["mandatory_requirements"])
    check("G029_V6_CORE_REQUIREMENTS", {"CROSS_NAMESPACE_PROCESS_IDENTITY_MODEL", "HOST_PID_LOCAL_PID_MAPPING_EVIDENCE_BOUND", "SEMANTIC_PROCESS_LINEAGE_CORRELATION", "MOUNT_PROVENANCE_CLASSIFICATION_SEPARATE_GATE", "PRODUCER_AUTHORIZATION_SEPARATE_GATE", "UNKNOWN_OR_AMBIGUOUS_LINEAGE_FAIL_CLOSED", "IMMUTABLE_FAILURE_EVIDENCE_FREEZE"}.issubset(required))
    check("G030_V6_CARRY_FORWARD", {"STRICT_SCHEMA_COMPATIBILITY_PRECHECK_BEFORE_ATTEMPT", "BIND_DESTINATION_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT", "TYPED_TOKEN_BUDGET_CONTRACT_AND_PRECHECK", "COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE", "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION"}.issubset(required))
    authority = docs["AUTHORITY_NON_ESCALATION_DECISION.json"]
    counters = authority["current_governance_operation_counters"]
    check("G031_ZERO_OPERATIONS", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {key: value for key, value in authority.items() if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False}
    check("G032_NO_CURRENT_ESCALATION", not escalations, escalations)
    check("G033_NEXT", docs["NEXT_LEGAL_MILESTONE.json"]["next_if_pass_locked"] == "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V6_ONCE_IF_ALL_GATES_PASS")
    check("G034_NO_V6_NOW", docs["NEXT_LEGAL_MILESTONE.json"]["v6_may_be_created_during_this_governance_milestone"] is False)
    failed = [row for row in checks if row["status"] == "FAIL"]
    write(PRIMARY_RESULT, {
        "record_type": "FIRST_WORKER_V5_ERRATUM_GOVERNANCE_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "GOVERNANCE_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": counters,
    })
    if failed:
        raise SystemExit("primary governance validation failed")
    matrix = docs["NEGATIVE_GOVERNANCE_TEST_MATRIX.json"]
    outcomes = run_negative(matrix, terminal, authority, docs["OPERATION_AUTHORIZATION_MATRIX.json"])
    negative_failed = [row for row in outcomes if row["status"] == "FAIL"]
    write(NEGATIVE_RESULT_RUN1, {
        "record_type": "FIRST_WORKER_V5_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT", "schema_version": "1.0",
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001", "status": "PASS" if not negative_failed else "FAIL_CLOSED",
        "results": outcomes, "tests_total": len(outcomes), "tests_passed": len(outcomes) - len(negative_failed), "tests_failed": len(negative_failed),
        "operation_counters": counters,
    })
    print(json.dumps({"primary": f"{len(checks) - len(failed)}/{len(checks)}", "negative": f"{len(outcomes) - len(negative_failed)}/{len(outcomes)}", "status": "PASS" if not negative_failed else "FAIL_CLOSED"}, sort_keys=True))
    if negative_failed:
        raise SystemExit("negative governance fixtures failed")


if __name__ == "__main__":
    main()
