#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    manifest = load_json(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load_json(PACKAGE / "GOVERNANCE_LOCK.json")
    checks: list[dict[str, Any]] = []
    def check(identity: str, condition: bool, evidence: Any = None) -> None: checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    listed = []
    for item in manifest["members"]:
        path = PACKAGE / item["path"]; listed.append(path)
        check(f"F_MEMBER_{item['path']}", path.is_file() and not path.is_symlink() and sha256_file(path) == item["sha256"] and path.stat().st_size == item["bytes"] and is_read_only(path))
    check("F001_COUNT", len(listed) == manifest["member_count"])
    check("F002_ROOT", package_root(listed) == manifest["canonical_root_sha256"])
    check("F003_LOCK_BINDING", lock.get("manifest_sha256") == sha256_file(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json") and lock.get("canonical_root_sha256") == manifest["canonical_root_sha256"])
    check("F004_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY" and lock.get("decision") == DECISION)
    check("F005_LOCK_READ_ONLY", is_read_only(PACKAGE / "GOVERNANCE_LOCK.json") and is_read_only(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json"))
    try: assert_v24_frozen(); v24_ok = True
    except Exception as exc: v24_ok = False
    check("F006_V24_UNCHANGED", v24_ok)
    try: assert_v23_frozen(); v23_ok = True
    except Exception as exc: v23_ok = False
    check("F007_V23_UNCHANGED", v23_ok)
    check("F008_V24_NO_EXECUTION", not (V24 / "STATIC_EXECUTION_LOCK.json").exists() and not (V24 / "static-run-v24/ATTEMPT_MARKER.json").exists())
    check("F009_V25_ABSENT", not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v25-20261101").exists())
    check("F010_VALIDATIONS_PASS", all(load_json(PACKAGE / name).get("status") == "PASS" for name in VALIDATION_FILES))
    check("F010A_READ_ONLY_INTEGRITY_PASS", load_json(PACKAGE / "READ_ONLY_INTEGRITY_RESULT_RUN-0001.json").get("status") == "PASS")
    adjudication = load_json(PACKAGE / "V24_DEFECT_ADJUDICATION.json")
    check("F011_ADJUDICATION", adjudication.get("HISTORICAL_DECISION_REGISTRY_LOGICAL_IDENTITY_TO_RECORD_TYPE_BINDING_DEFECT") == "YES" and adjudication.get("FROZEN_HISTORICAL_DECISION_ARTIFACT_DEFECT") == "NO")
    failures = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {"record_type": "FINAL_GOVERNANCE_FREEZE_VERIFICATION", "governance_identity": GOVERNANCE_ID, "checks": checks, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "failure_ids": failures, "status": "PASS" if not failures else "FAIL_CLOSED", "governance_lock_sha256": sha256_file(PACKAGE / "GOVERNANCE_LOCK.json")}
    write_json_once(PACKAGE / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json", result)
    set_read_only(PACKAGE / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json")
    os.chmod(PACKAGE, 0o555)
    print(f"FINAL_FREEZE_VERIFICATION={result['status']} {len(checks)-len(failures)}/{len(checks)} LOCK_SHA256={result['governance_lock_sha256']}")
    if failures: raise SystemExit(1)


if __name__ == "__main__": main()
