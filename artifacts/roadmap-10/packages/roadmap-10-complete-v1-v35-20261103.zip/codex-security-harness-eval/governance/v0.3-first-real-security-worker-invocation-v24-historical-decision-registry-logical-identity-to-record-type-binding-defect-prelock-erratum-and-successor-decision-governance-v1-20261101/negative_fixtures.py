#!/usr/bin/env python3
from copy import deepcopy
from governance_common import *


def main() -> None:
    base = load_json(PACKAGE / "TYPED_HISTORICAL_DECISION_REGISTRY.json")["mappings"][0]
    cases: list[tuple[str, dict[str, Any], bool]] = []
    cases.append(("AUTHORIZED_DIFFERENT_PHYSICAL_RECORD_TYPE", deepcopy(base), True))
    value = deepcopy(base); value["physical_record_type_presence"] = "PRESENT"; value["physical_record_type"] = "UNAUTHORIZED_RECORD_TYPE"; cases.append(("UNAUTHORIZED_RECORD_TYPE", value, False))
    value = deepcopy(base); value["logical_decision_identity"] = "WRONG_LOGICAL_DECISION"; cases.append(("WRONG_LOGICAL_IDENTITY", value, False))
    value = deepcopy(base); value["artifact_role"] = "WRONG_ROLE"; cases.append(("WRONG_DECISION_ROLE", value, False))
    value = deepcopy(base); value["subject_identity"] = "WRONG_SUBJECT"; cases.append(("WRONG_SUBJECT", value, False))
    value = deepcopy(base); value["object_identity"] = "WRONG_OBJECT"; cases.append(("WRONG_OBJECT", value, False))
    value = deepcopy(base); value["mapping_authority"] = "SYNTHETIC_NON_GOVERNANCE_MAPPING"; cases.append(("SYNTHETIC_NON_GOVERNANCE_MAPPING", value, False))
    value = deepcopy(base); value["artifact_sha256"] = "0" * 64; cases.append(("DIGEST_MISMATCH", value, False))
    cases.append(("EXACT_GOVERNANCE_BOUND_TYPED_MAPPING_SUCCESS", deepcopy(base), True))
    results = []
    for identity, candidate, expected in cases:
        verdict = typed_mapping_verdict(candidate)
        actual = verdict["status"] == "PASS"
        results.append({"id": identity, "expected_pass": expected, "actual_pass": actual, "status": "PASS" if actual is expected else "FAIL", "verdict": verdict})
    failures = [row["id"] for row in results if row["status"] != "PASS"]
    result = {"record_type": "NEGATIVE_GOVERNANCE_TEST_RESULT", "governance_identity": GOVERNANCE_ID, "cases": results, "validation_counts": {"total": len(results), "passed": len(results)-len(failures), "failed": len(failures)}, "failure_ids": failures, "status": "PASS" if not failures else "FAIL_CLOSED"}
    write_json_once(PACKAGE / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", result)
    print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['status']} {len(results)-len(failures)}/{len(results)}")
    if failures: raise SystemExit(1)


if __name__ == "__main__":
    main()
