#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(identity: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    try:
        assert_v24_frozen(); v24_ok = True
    except Exception as exc:
        v24_ok = False; check("G001_V24_FROZEN", False, str(exc))
    else:
        check("G001_V24_FROZEN", True, V24_HASHES)
    try:
        assert_v23_frozen(); v23_ok = True
    except Exception as exc:
        v23_ok = False; check("G002_V23_FROZEN", False, str(exc))
    else:
        check("G002_V23_FROZEN", True, V23_HASHES)
    comparison = load_json(PACKAGE / "HISTORICAL_DECISION_ARTIFACT_COMPARISON.json")
    rows = comparison.get("comparisons", [])
    check("G003_EXACT_FIVE_COMPARISONS", isinstance(rows, list) and len(rows) == 5)
    for index, row in enumerate(rows, 1):
        check(f"G{index+3:03d}_HISTORICAL_ARTIFACT_{index}_VALID", row.get("historical_artifact_valid") is True, row)
        check(f"G{index+8:03d}_V24_MAPPING_{index}_INVALID", row.get("actual_physical_record_type") is None and row.get("physical_record_type_presence") == "ABSENT" and row.get("v24_logical_identity_to_record_type_mapping_valid") is False, row)
        observed = observe_historical_artifact(row)
        check(f"G{index+13:03d}_ARTIFACT_{index}_REREAD_EXACT", observed["artifact_sha256"] == row["artifact_sha256"] and observed["historical_artifact_valid"] is True)
    registry = load_json(PACKAGE / "TYPED_HISTORICAL_DECISION_REGISTRY.json")
    mappings = registry.get("mappings", [])
    check("G019_TYPED_REGISTRY_COUNT", registry.get("mapping_count") == len(mappings) == 5)
    check("G020_TYPED_REGISTRY_PASS", all(typed_mapping_verdict(row)["status"] == "PASS" for row in mappings), [typed_mapping_verdict(row) for row in mappings])
    contract = load_json(PACKAGE / "TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT.json")
    check("G021_TYPED_CONTRACT", contract.get("logical_to_physical_rule") == "EXPLICIT_MAPPING_NOT_STRING_EQUALITY" and contract.get("historical_artifact_mutation") == "PROHIBITED")
    adjudication = load_json(PACKAGE / "V24_DEFECT_ADJUDICATION.json")
    check("G022_DEFECT_YES", adjudication.get("HISTORICAL_DECISION_REGISTRY_LOGICAL_IDENTITY_TO_RECORD_TYPE_BINDING_DEFECT") == "YES")
    check("G023_HISTORICAL_ARTIFACT_DEFECT_NO", adjudication.get("FROZEN_HISTORICAL_DECISION_ARTIFACT_DEFECT") == "NO")
    check("G024_DIRECT_EQUALITY_INCORRECT", adjudication.get("DIRECT_LOGICAL_IDENTITY_PHYSICAL_RECORD_TYPE_EQUALITY_REQUIREMENT") == "INCORRECT")
    check("G025_V24_TERMINAL", adjudication.get("V24") == "TERMINAL_IMMUTABLE_NO_RETRY")
    check("G026_V25_CONDITIONAL", adjudication.get("V25") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    decision = load_json(PACKAGE / "V24_TERMINAL_AND_V25_SUCCESSOR_DECISION.json")
    check("G027_SUCCESSOR_DECISION", decision.get("decision") == DECISION and decision.get("v24_mutation_allowlist") == [] and decision.get("v25") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    requirements = load_json(PACKAGE / "SUCCESSOR_V25_REQUIREMENTS.json")
    required_regressions = set(requirements.get("required_regressions", []))
    check("G028_SUCCESSOR_REGRESSIONS", {"AUTHORIZED_DIFFERENT_PHYSICAL_RECORD_TYPE", "UNAUTHORIZED_RECORD_TYPE", "WRONG_LOGICAL_IDENTITY", "WRONG_DECISION_ROLE", "WRONG_SUBJECT_OBJECT_RELATION", "SYNTHETIC_NON_GOVERNANCE_MAPPING", "HISTORICAL_ARTIFACT_DIGEST_MISMATCH", "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING_SUCCESS"} <= required_regressions)
    fixture_results = sorted((V24 / "results/prelock/adversarial-selftests-run-0001").glob("*-0001-result.json"))
    check("G029_ALL_FIVE_FIXTURE_MODES_PASS", len(fixture_results) == 5 and all(load_json(path).get("status") == "PASS" for path in fixture_results))
    nested = load_json(V24 / "results/prelock/adversarial-selftests-run-0001/nested-0001-result.json")
    check("G030_NESTED_PIPELINE_PASS", nested.get("status") == "PASS" and nested.get("observer_exit_code") == 0 and nested.get("diagnostic_complete") is True)
    cache_members = [path for path in V24.rglob("*") if path.is_file() and (path.suffix == ".pyc" or "__pycache__" in path.parts)]
    check("G031_NO_UNDECLARED_BYTECODE", not cache_members, [str(path) for path in cache_members])
    check("G032_RUNTIME_NOT_ESTABLISHED", adjudication.get("runtime", {}).get("security_worker") == "NOT_ESTABLISHED" and adjudication.get("runtime", {}).get("process_lineage") == "NOT_PROVEN" and adjudication.get("runtime", {}).get("confinement") == "NOT_PROVEN")
    check("G033_V25_NOT_CREATED", not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v25-20261101").exists())
    check("G034_GOVERNANCE_ONLY", load_json(PACKAGE / "GOVERNANCE_CHARTER.json").get("milestone_type") == "GOVERNANCE_ONLY")
    failures = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {"record_type": "PRIMARY_GOVERNANCE_VALIDATION_RESULT", "governance_identity": GOVERNANCE_ID, "checks": checks, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "failure_ids": failures, "status": "PASS" if not failures else "FAIL_CLOSED"}
    write_json_once(PACKAGE / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failures)}/{len(checks)}")
    if failures: raise SystemExit(1)


if __name__ == "__main__":
    main()
