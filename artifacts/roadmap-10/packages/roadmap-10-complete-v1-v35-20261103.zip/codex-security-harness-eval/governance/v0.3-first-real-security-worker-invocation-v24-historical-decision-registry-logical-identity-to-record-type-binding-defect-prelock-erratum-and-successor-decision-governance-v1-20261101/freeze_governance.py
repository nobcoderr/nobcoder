#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    for name in VALIDATION_FILES:
        if load_json(PACKAGE / name).get("status") != "PASS":
            raise SystemExit(f"cannot freeze: {name}")
    if load_json(PACKAGE / "READ_ONLY_INTEGRITY_RESULT_RUN-0001.json").get("status") != "PASS":
        raise SystemExit("cannot freeze: read-only integrity")
    assert_v24_frozen(); assert_v23_frozen()
    excluded = ("GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json")
    members = package_member_paths(exclude=excluded)
    manifest = {"record_type": "GOVERNANCE_ARTIFACT_MANIFEST", "governance_identity": GOVERNANCE_ID, "member_count": len(members), "members": [{"path": path.name, "sha256": sha256_file(path), "bytes": path.stat().st_size} for path in members], "canonical_root_sha256": package_root(members)}
    write_json_once(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    lock = {
        "record_type": "GOVERNANCE_LOCK", "governance_identity": GOVERNANCE_ID,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "manifest_sha256": sha256_file(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "canonical_root_sha256": manifest["canonical_root_sha256"],
        "v24": V24_STATE, "v25": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt_v24": "0_OF_1", "worker_v24": "0_OF_1", "codex_v24": "0_OF_1",
    }
    write_json_once(PACKAGE / "GOVERNANCE_LOCK.json", lock)
    for path in package_member_paths(exclude=("FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",)):
        set_read_only(path)
    print(f"GOVERNANCE_FREEZE=PASS MEMBERS={len(members)} LOCK_SHA256={sha256_file(PACKAGE/'GOVERNANCE_LOCK.json')}")


if __name__ == "__main__": main()
