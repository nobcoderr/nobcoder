#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any


PACKAGE = Path(__file__).resolve().parent
V24 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v24-20261101")
V23 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v23-20261101")
GOVERNANCE_ID = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V24_HISTORICAL_DECISION_REGISTRY_"
    "LOGICAL_IDENTITY_TO_RECORD_TYPE_BINDING_DEFECT_PRELOCK_ERRATUM_AND_SUCCESSOR_"
    "DECISION_GOVERNANCE_ONLY"
)
DECISION = "TERMINALIZE_V24_AND_AUTHORIZE_DISTINCT_V25_CONDITIONALLY"
V24_STATE = "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE"
V24_HASHES = {
    "terminal": "d918fc6c483dcbb221e22832d60cdc6c4db10ef82d14091cb31cb90c2efe19cd",
    "manifest": "a23ca76ba8d9e9ff2fd1ecd69e10301a9ff2153a49c32579a8e4806ee92f6cd9",
    "freeze": "7710b5298a3a01f042bb4642fd0270eaf8f09748ae638acf31a332be2a84d25c",
    "unit": "56ee7e80f05311514e6eae602157a52619484b82607cf0a05628eb15222a2f66",
    "registry": "8c6f139e3fc6d61977744b6289d2bd10cc439cccf286f24d2cfe559bc566cf70",
}
V24_PATHS = {
    "terminal": V24 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "manifest": V24 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
    "freeze": V24 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
    "unit": V24 / "results/prelock/unit-fixtures-run-0001.json",
    "registry": V24 / "contracts/HISTORICAL_DECISION_RELATION_REGISTRY.json",
}
V23_HASHES = {
    "terminal": "ae3ad1f322452415200c8cdc6a63d4956577777dee6d71a747dfdb25fadd7d06",
    "manifest": "5bb596cdbbe57c64ccb7dea1cc1cbaa8ad6a3b72059038ba4169879ccc0106a0",
    "freeze": "633ff20b3cc22fc989998c0482cb4ef149d9cd5d44da8d551407f15b7c64b244",
}
V23_PATHS = {
    "terminal": V23 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "manifest": V23 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
    "freeze": V23 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
}
VALIDATION_FILES = (
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
)


def canonical_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path}")
    return value


def write_json_once(path: Path, value: object) -> None:
    data = canonical_json(value)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        os.close(fd)


def is_read_only(path: Path) -> bool:
    return path.is_file() and not path.is_symlink() and stat.S_IMODE(path.stat().st_mode) == 0o444


def set_read_only(path: Path) -> None:
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"unsafe freeze member: {path}")
    os.chmod(path, 0o444)


def assert_v24_frozen() -> None:
    for identity, path in V24_PATHS.items():
        if not path.is_file() or path.is_symlink() or sha256_file(path) != V24_HASHES[identity]:
            raise RuntimeError(f"V24 frozen evidence mismatch: {identity}")
    terminal = load_json(V24_PATHS["terminal"])
    state = terminal.get("execution_state", {})
    if terminal.get("status") != V24_STATE:
        raise RuntimeError("V24 terminal state mismatch")
    if not (
        state.get("static_lock") == "NOT_ISSUED"
        and state.get("attempt") == state.get("worker_invocation") == state.get("codex_as_worker_invocation") == "0/1"
        and state.get("attempt_marker") == state.get("runtime_evidence") == "ABSENT"
    ):
        raise RuntimeError("V24 execution counters changed")
    if (V24 / "results/prelock/primary-static-validation-run-0001.json").exists():
        raise RuntimeError("V24 primary unexpectedly exists")
    if (V24 / "results/prelock/independent-static-validation-run-0001.json").exists():
        raise RuntimeError("V24 independent unexpectedly exists")
    if (V24 / "STATIC_EXECUTION_LOCK.json").exists() or (V24 / "static-run-v24/ATTEMPT_MARKER.json").exists():
        raise RuntimeError("V24 lock or attempt unexpectedly exists")


def assert_v23_frozen() -> None:
    for identity, path in V23_PATHS.items():
        if not path.is_file() or path.is_symlink() or sha256_file(path) != V23_HASHES[identity]:
            raise RuntimeError(f"V23 frozen evidence mismatch: {identity}")


def registry_rows() -> list[dict[str, Any]]:
    registry = load_json(V24_PATHS["registry"])
    rows = registry.get("relations", [])
    if not isinstance(rows, list):
        raise RuntimeError("V24 registry rows unavailable")
    wanted = [row for row in rows if isinstance(row, dict) and row.get("object_identity") in {
        "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V18",
        "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V19",
        "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V20",
        "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V21",
        "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V22",
    }]
    if len(wanted) != 5:
        raise RuntimeError("exact five historical mismatch rows required")
    return wanted


def observe_historical_artifact(binding: dict[str, Any]) -> dict[str, Any]:
    path = Path(str(binding.get("canonical_locator", "")))
    if not path.is_absolute() or not path.is_file() or path.is_symlink():
        raise RuntimeError(f"historical artifact unavailable: {path}")
    artifact = load_json(path)
    lock_path = path.parent / "GOVERNANCE_LOCK.json"
    lock = load_json(lock_path)
    actual_record_type = artifact.get("record_type")
    historical_valid = (
        sha256_file(path) == binding.get("artifact_sha256")
        and path.stat().st_size == binding.get("artifact_size")
        and artifact.get("decision") == binding.get("relation_semantics")
        and sha256_file(lock_path) == binding.get("governance_lock_sha256")
        and lock.get("governance_identity") == binding.get("governance_identity")
    )
    return {
        **binding,
        "canonical_artifact_identity": f"SHA256:{binding['artifact_sha256']}",
        "actual_physical_record_type": actual_record_type,
        "physical_record_type_presence": "ABSENT" if actual_record_type is None else "PRESENT",
        "v24_expected_record_type_or_identity": binding["logical_decision_identity"],
        "historical_artifact_valid": historical_valid,
        "v24_logical_identity_to_record_type_mapping_valid": actual_record_type == binding["logical_decision_identity"],
        "typed_mapping_required": True,
    }


def typed_mapping_verdict(row: dict[str, Any]) -> dict[str, Any]:
    checks = {
        "logical_identity_exact": row.get("logical_decision_identity") == row.get("authorized_logical_decision_identity"),
        "physical_record_type_typed": (
            row.get("physical_record_type_presence") == "ABSENT" and row.get("physical_record_type") is None
        ) or (
            row.get("physical_record_type_presence") == "PRESENT" and isinstance(row.get("physical_record_type"), str)
        ),
        "physical_record_type_authorized": row.get("physical_record_type_presence") == row.get("authorized_physical_record_type_presence") and row.get("physical_record_type") == row.get("authorized_physical_record_type"),
        "artifact_role_exact": row.get("artifact_role") == row.get("authorized_artifact_role") == "TERMINAL_SUCCESSOR_DECISION",
        "governance_owner_exact": row.get("governance_owner") == row.get("authorized_governance_owner"),
        "subject_object_exact": row.get("subject_identity") == row.get("authorized_subject_identity") and row.get("object_identity") == row.get("authorized_object_identity") and row.get("subject_identity") != row.get("object_identity"),
        "decision_relation_exact": row.get("relation_semantics") == row.get("authorized_relation_semantics"),
        "artifact_identity_exact": isinstance(row.get("canonical_locator"), str) and Path(row["canonical_locator"]).is_absolute() and row.get("artifact_sha256") == row.get("authorized_artifact_sha256"),
        "governance_authority_exact": row.get("governance_identity") == row.get("authorized_governance_identity") and row.get("governance_lock_sha256") == row.get("authorized_governance_lock_sha256"),
        "mapping_authorized": row.get("mapping_authority") == "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING",
        "no_string_equality_inference": row.get("logical_to_physical_rule") == "EXPLICIT_MAPPING_NOT_STRING_EQUALITY",
        "historical_artifact_valid": row.get("historical_artifact_valid") is True,
    }
    return {"status": "PASS" if all(checks.values()) else "FAIL_CLOSED", "checks": checks}


def package_member_paths(exclude: tuple[str, ...] = ()) -> list[Path]:
    return sorted(path for path in PACKAGE.iterdir() if path.is_file() and path.name not in set(exclude))


def package_root(paths: list[Path]) -> str:
    stream = b"".join(path.name.encode("utf-8") + b"\0" + sha256_file(path).encode("ascii") + b"\n" for path in sorted(paths, key=lambda item: item.name))
    return hashlib.sha256(stream).hexdigest()
