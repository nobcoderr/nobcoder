#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    assert_v24_frozen()
    assert_v23_frozen()
    comparisons = [observe_historical_artifact(row) for row in registry_rows()]
    if not all(row["historical_artifact_valid"] and not row["v24_logical_identity_to_record_type_mapping_valid"] for row in comparisons):
        raise SystemExit("five exact valid-history/invalid-V24-mapping comparisons required")
    typed_rows = []
    for row in comparisons:
        typed = {
            **{key: row[key] for key in (
                "logical_decision_identity", "governance_owner", "artifact_role", "canonical_locator",
                "artifact_sha256", "artifact_size", "relation_semantics", "subject_identity",
                "object_identity", "governance_identity", "governance_lock_sha256",
            )},
            "physical_record_type_presence": row["physical_record_type_presence"],
            "physical_record_type": row["actual_physical_record_type"],
            "authorized_logical_decision_identity": row["logical_decision_identity"],
            "authorized_physical_record_type_presence": row["physical_record_type_presence"],
            "authorized_physical_record_type": row["actual_physical_record_type"],
            "authorized_artifact_role": row["artifact_role"],
            "authorized_governance_owner": row["governance_owner"],
            "authorized_subject_identity": row["subject_identity"],
            "authorized_object_identity": row["object_identity"],
            "authorized_relation_semantics": row["relation_semantics"],
            "authorized_artifact_sha256": row["artifact_sha256"],
            "authorized_governance_identity": row["governance_identity"],
            "authorized_governance_lock_sha256": row["governance_lock_sha256"],
            "mapping_authority": "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING",
            "logical_to_physical_rule": "EXPLICIT_MAPPING_NOT_STRING_EQUALITY",
            "historical_artifact_valid": True,
        }
        if typed_mapping_verdict(typed)["status"] != "PASS":
            raise SystemExit(f"typed row invalid: {typed['logical_decision_identity']}")
        typed_rows.append(typed)
    artifacts = {
        "GOVERNANCE_CHARTER.json": {
            "record_type": "V24_HISTORICAL_DECISION_REGISTRY_ERRATUM_GOVERNANCE_CHARTER",
            "governance_identity": GOVERNANCE_ID,
            "milestone_type": "GOVERNANCE_ONLY",
            "scope": "ADJUDICATE_V24_LOGICAL_IDENTITY_TO_PHYSICAL_RECORD_TYPE_BINDING_FAILURE_AND_DECIDE_SUCCESSOR",
            "prohibited": ["V24_MUTATION", "V24_RERUN", "V24_DUPLICATION", "HISTORICAL_ARTIFACT_MUTATION", "PRIMARY_OR_INDEPENDENT_V24_VALIDATION", "STATIC_LOCK", "SECURITY_WORKER_OR_CODEX_INVOCATION", "V25_CREATION_OR_EXECUTION"],
            "freeze_requires": ["PRIMARY_GOVERNANCE_VALIDATION_PASS", "NEGATIVE_FIXTURES_PASS", "INDEPENDENT_GOVERNANCE_VALIDATION_PASS", "READ_ONLY_INTEGRITY_PASS", "FINAL_FREEZE_VERIFICATION_PASS"],
        },
        "V24_FROZEN_FAILURE_EVIDENCE_BINDING.json": {
            "record_type": "V24_FROZEN_FAILURE_EVIDENCE_BINDING",
            "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V24",
            "state": V24_STATE,
            "unit": {"passed": 278, "failed": 2, "total": 280, "failure_ids": ["U049_PREDECESSOR", "U_V24_HISTORICAL_RELATION_REGISTRY_PASS"]},
            "hashes": V24_HASHES,
            "canonical_evidence_root_sha256": "4bfd0ed047bb1cb68ce94f65f2875c3937d8bd3cd6e3b8aa82a35000a3057b0f",
            "static_lock": "NOT_ISSUED", "attempt": "0_OF_1", "worker": "0_OF_1", "codex": "0_OF_1",
            "primary": "NOT_STARTED", "independent": "NOT_STARTED",
        },
        "HISTORICAL_DECISION_ARTIFACT_COMPARISON.json": {
            "record_type": "V24_HISTORICAL_DECISION_ARTIFACT_COMPARISON",
            "comparison_count": len(comparisons),
            "comparisons": comparisons,
            "conclusion": "HISTORICAL_ARTIFACTS_VALID_V24_DIRECT_EQUALITY_BINDINGS_INVALID",
        },
        "TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT.json": {
            "record_type": "V25_TYPED_HISTORICAL_DECISION_REGISTRY_CONTRACT",
            "selection": "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING",
            "logical_to_physical_rule": "EXPLICIT_MAPPING_NOT_STRING_EQUALITY",
            "physical_record_type": {"presence": ["PRESENT", "ABSENT"], "absent_value": None, "legacy_absence_requires_exact_digest": True},
            "required_fields": ["logical_decision_identity", "physical_record_type_presence", "physical_record_type", "artifact_role", "governance_owner", "subject_identity", "object_identity", "relation_semantics", "canonical_locator", "artifact_sha256", "artifact_size", "governance_identity", "governance_lock_sha256", "mapping_authority"],
            "mismatch": "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT",
            "historical_artifact_mutation": "PROHIBITED",
        },
        "TYPED_HISTORICAL_DECISION_REGISTRY.json": {
            "record_type": "V25_TYPED_HISTORICAL_DECISION_REGISTRY",
            "status": "NORMATIVE_SUCCESSOR_REQUIREMENT",
            "mapping_count": len(typed_rows),
            "mappings": typed_rows,
        },
        "V24_DEFECT_ADJUDICATION.json": {
            "record_type": "V24_HISTORICAL_DECISION_REGISTRY_DEFECT_ADJUDICATION",
            "HISTORICAL_DECISION_REGISTRY_LOGICAL_IDENTITY_TO_RECORD_TYPE_BINDING_DEFECT": "YES",
            "DIRECT_LOGICAL_IDENTITY_PHYSICAL_RECORD_TYPE_EQUALITY_REQUIREMENT": "INCORRECT",
            "FROZEN_HISTORICAL_DECISION_ARTIFACT_DEFECT": "NO",
            "historical_artifact_count": 5,
            "physical_record_type_state": "ABSENT_IN_ALL_FIVE_LEGACY_ARTIFACTS",
            "V24": "TERMINAL_IMMUTABLE_NO_RETRY",
            "V25": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
            "runtime": {"security_worker": "NOT_ESTABLISHED", "codex": "NOT_ESTABLISHED", "temporal": "NOT_ESTABLISHED", "process_lineage": "NOT_PROVEN", "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN"},
            "successful_fixture_facts": ["ALL_FIVE_ADVERSARIAL_TEMPORAL_MODES_PASS", "NESTED_ATOMIC_PUBLICATION_PASS", "NESTED_COMPLETION_GATE_PASS", "NESTED_PARSING_PASS", "NESTED_STRICT_N_OF_N_PASS", "NO_UNDECLARED_PYC_OR_PYCACHE"],
            "fixture_results_are_not_runtime_success": True,
        },
        "SUCCESSOR_V25_REQUIREMENTS.json": {
            "record_type": "SUCCESSOR_V25_REQUIREMENTS",
            "requirements": ["FRESH_WORKSPACE_AND_IDENTITY", "TYPED_CANONICAL_HISTORICAL_DECISION_REGISTRY", "EXPLICIT_GOVERNANCE_AUTHORIZED_LOGICAL_TO_PHYSICAL_RECORD_TYPE_MAPPING", "HISTORICAL_ARTIFACTS_READ_ONLY", "TRANSACTIONAL_ATOMIC_SELFTEST_TELEMETRY_PIPELINE_CARRIED_FORWARD", "ALL_APPLICABLE_V1_TO_V24_CONTROLS"],
            "required_regressions": ["AUTHORIZED_DIFFERENT_PHYSICAL_RECORD_TYPE", "UNAUTHORIZED_RECORD_TYPE", "WRONG_LOGICAL_IDENTITY", "WRONG_DECISION_ROLE", "WRONG_SUBJECT_OBJECT_RELATION", "SYNTHETIC_NON_GOVERNANCE_MAPPING", "HISTORICAL_ARTIFACT_DIGEST_MISMATCH", "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING_SUCCESS"],
            "prohibited": ["V24_MUTATION", "HISTORICAL_ARTIFACT_REWRITE", "STRING_EQUALITY_INFERENCE", "VERSION_OR_DIRECTORY_INFERENCE", "SYNTHETIC_RELATION", "N_OF_N_WEAKENING"],
        },
        "V24_FAILURE_AND_V25_REGRESSION_MATRIX.json": {
            "record_type": "V24_FAILURE_AND_V25_REGRESSION_MATRIX",
            "source_failure_ids": ["U049_PREDECESSOR", "U_V24_HISTORICAL_RELATION_REGISTRY_PASS"],
            "positive": ["VALID_LOGICAL_IDENTITY_AUTHORIZED_ABSENT_PHYSICAL_RECORD_TYPE", "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING_SUCCESS"],
            "negative": ["UNAUTHORIZED_RECORD_TYPE", "WRONG_LOGICAL_IDENTITY", "WRONG_DECISION_ROLE", "WRONG_SUBJECT", "WRONG_OBJECT", "SYNTHETIC_NON_GOVERNANCE_MAPPING", "DIGEST_MISMATCH"],
            "all_negative_outcomes": "FAIL_CLOSED",
        },
        "V24_TERMINAL_AND_V25_SUCCESSOR_DECISION.json": {
            "record_type": "V24_TERMINAL_AND_V25_SUCCESSOR_DECISION",
            "decision": DECISION,
            "reason": "V24_IS_FROZEN_TERMINAL_NO_RETRY_AND_THE_TYPED_REGISTRY_CORRECTION_REQUIRES_A_DISTINCT_EXECUTION_IDENTITY",
            "v24": V24_STATE, "v24_continuation": "PROHIBITED", "v24_retry": "PROHIBITED", "v24_mutation_allowlist": [],
            "v25": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED", "v25_attempt": "0_OF_1", "v25_worker": "0_OF_1", "v25_codex": "0_OF_1",
        },
        "NEXT_LEGAL_MILESTONE.json": {
            "record_type": "NEXT_LEGAL_MILESTONE",
            "milestone": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V25_ONCE_IF_ALL_GATES_PASS",
            "status": "CONDITIONALLY_AUTHORIZED_NOT_STARTED",
        },
        "NEGATIVE_GOVERNANCE_TEST_MATRIX.json": {
            "record_type": "V24_GOVERNANCE_NEGATIVE_TEST_MATRIX",
            "cases": ["AUTHORIZED_DIFFERENT_PHYSICAL_RECORD_TYPE", "UNAUTHORIZED_RECORD_TYPE", "WRONG_LOGICAL_IDENTITY", "WRONG_DECISION_ROLE", "WRONG_SUBJECT", "WRONG_OBJECT", "SYNTHETIC_NON_GOVERNANCE_MAPPING", "DIGEST_MISMATCH", "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING_SUCCESS"],
        },
        "ROUTING_LEDGER.json": {
            "record_type": "GOVERNANCE_ROUTING_LEDGER",
            "active": ["mandatory-auto-router", "codex-security-harness", "expert-python-engineer"],
            "not_applicable": ["LIVE_TARGET_TESTING", "RECON", "EXTERNAL_TOOLS", "WEB_API_MOBILE_BINARY_WEB3", "SUBAGENTS", "PARALLELISM"],
            "scope": "LOCAL_READ_ONLY_EVIDENCE_ADJUDICATION_AND_FRESH_GOVERNANCE_PACKAGE_ONLY",
        },
    }
    for name, value in artifacts.items():
        write_json_once(PACKAGE / name, value)
    print(f"GOVERNANCE_BUILD=PASS ARTIFACTS={len(artifacts)}")


if __name__ == "__main__":
    main()
