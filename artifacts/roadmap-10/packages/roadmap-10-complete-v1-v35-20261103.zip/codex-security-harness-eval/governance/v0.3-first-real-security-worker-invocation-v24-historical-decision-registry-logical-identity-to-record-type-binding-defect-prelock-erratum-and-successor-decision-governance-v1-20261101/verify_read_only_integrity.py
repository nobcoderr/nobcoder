#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(identity: str, condition: bool, evidence: Any = None) -> None: checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    for identity, path in V24_PATHS.items():
        check(f"R_V24_{identity}", path.is_file() and not path.is_symlink() and sha256_file(path) == V24_HASHES[identity], str(path))
    for identity, path in V23_PATHS.items():
        check(f"R_V23_{identity}", path.is_file() and not path.is_symlink() and sha256_file(path) == V23_HASHES[identity], str(path))
    check("R_V24_FAILURE_EVIDENCE_READ_ONLY", all(is_read_only(path) for name, path in V24_PATHS.items() if name in {"terminal", "manifest", "freeze", "unit"}))
    check("R_V23_FAILURE_EVIDENCE_READ_ONLY", all(is_read_only(path) for path in V23_PATHS.values()))
    check("R_V24_NO_PRIMARY_INDEPENDENT", not (V24 / "results/prelock/primary-static-validation-run-0001.json").exists() and not (V24 / "results/prelock/independent-static-validation-run-0001.json").exists())
    check("R_V24_NO_LOCK_ATTEMPT_RUNTIME", not (V24 / "STATIC_EXECUTION_LOCK.json").exists() and not (V24 / "static-run-v24/ATTEMPT_MARKER.json").exists() and not (V24 / "static-run-v24/runtime-result-0001.json").exists())
    failures = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {"record_type": "READ_ONLY_INTEGRITY_RESULT", "governance_identity": GOVERNANCE_ID, "checks": checks, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "failure_ids": failures, "status": "PASS" if not failures else "FAIL_CLOSED"}
    write_json_once(PACKAGE / "READ_ONLY_INTEGRITY_RESULT_RUN-0001.json", result)
    print(f"READ_ONLY_INTEGRITY={result['status']} {len(checks)-len(failures)}/{len(checks)}")
    if failures: raise SystemExit(1)


if __name__ == "__main__": main()
