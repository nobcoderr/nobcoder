#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path
from typing import Any


PACKAGE = Path(__file__).resolve().parent
V24 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v24-20261101")
V23 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v23-20261101")
GOVERNANCE_ID = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V24_HISTORICAL_DECISION_REGISTRY_LOGICAL_IDENTITY_TO_RECORD_TYPE_BINDING_DEFECT_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"


def sha(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise ValueError(path)
    return value
def write_once(path: Path, value: object) -> None:
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    with path.open("xb") as handle: handle.write(data); handle.flush()


def independent_typed_verdict(row: dict[str, Any]) -> bool:
    physical_typed = (row.get("physical_record_type_presence") == "ABSENT" and row.get("physical_record_type") is None) or (row.get("physical_record_type_presence") == "PRESENT" and isinstance(row.get("physical_record_type"), str))
    return all((
        row.get("logical_decision_identity") == row.get("authorized_logical_decision_identity"),
        physical_typed,
        row.get("physical_record_type_presence") == row.get("authorized_physical_record_type_presence"),
        row.get("physical_record_type") == row.get("authorized_physical_record_type"),
        row.get("artifact_role") == row.get("authorized_artifact_role") == "TERMINAL_SUCCESSOR_DECISION",
        row.get("governance_owner") == row.get("authorized_governance_owner"),
        row.get("subject_identity") == row.get("authorized_subject_identity"),
        row.get("object_identity") == row.get("authorized_object_identity"),
        row.get("relation_semantics") == row.get("authorized_relation_semantics"),
        row.get("artifact_sha256") == row.get("authorized_artifact_sha256"),
        row.get("governance_identity") == row.get("authorized_governance_identity"),
        row.get("governance_lock_sha256") == row.get("authorized_governance_lock_sha256"),
        row.get("mapping_authority") == "EXACT_GOVERNANCE_BOUND_TYPED_MAPPING",
        row.get("logical_to_physical_rule") == "EXPLICIT_MAPPING_NOT_STRING_EQUALITY",
        row.get("historical_artifact_valid") is True,
    ))


def main() -> None:
    checks = []
    def check(identity: str, condition: bool, evidence: Any = None) -> None: checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    exact_v24 = {
        "PRELOCK_TERMINAL_ENGINEERING_RESULT.json": "d918fc6c483dcbb221e22832d60cdc6c4db10ef82d14091cb31cb90c2efe19cd",
        "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json": "a23ca76ba8d9e9ff2fd1ecd69e10301a9ff2153a49c32579a8e4806ee92f6cd9",
        "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json": "7710b5298a3a01f042bb4642fd0270eaf8f09748ae638acf31a332be2a84d25c",
        "unit-fixtures-run-0001.json": "56ee7e80f05311514e6eae602157a52619484b82607cf0a05628eb15222a2f66",
    }
    check("I001_V24_HASHES", all(sha(V24 / "results/prelock" / name) == digest for name, digest in exact_v24.items()))
    exact_v23 = {"PRELOCK_TERMINAL_ENGINEERING_RESULT.json": "ae3ad1f322452415200c8cdc6a63d4956577777dee6d71a747dfdb25fadd7d06", "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json": "5bb596cdbbe57c64ccb7dea1cc1cbaa8ad6a3b72059038ba4169879ccc0106a0", "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json": "633ff20b3cc22fc989998c0482cb4ef149d9cd5d44da8d551407f15b7c64b244"}
    check("I002_V23_HASHES", all(sha(V23 / "results/prelock" / name) == digest for name, digest in exact_v23.items()))
    comparison = load(PACKAGE / "HISTORICAL_DECISION_ARTIFACT_COMPARISON.json")
    rows = comparison.get("comparisons", [])
    check("I003_FIVE_ROWS", isinstance(rows, list) and len(rows) == 5)
    for index, row in enumerate(rows, 1):
        path = Path(row["canonical_locator"]); artifact = load(path); lock = load(path.parent / "GOVERNANCE_LOCK.json")
        exact = artifact.get("record_type") is None and artifact.get("decision") == row["relation_semantics"] and sha(path) == row["artifact_sha256"] and path.stat().st_size == row["artifact_size"] and sha(path.parent / "GOVERNANCE_LOCK.json") == row["governance_lock_sha256"] and lock.get("governance_identity") == row["governance_identity"]
        check(f"I{index+3:03d}_ROW_{index}_EXACT", exact and row.get("historical_artifact_valid") is True and row.get("v24_logical_identity_to_record_type_mapping_valid") is False)
    registry = load(PACKAGE / "TYPED_HISTORICAL_DECISION_REGISTRY.json")
    mappings = registry.get("mappings", [])
    check("I009_TYPED_REGISTRY", len(mappings) == 5 and all(independent_typed_verdict(row) for row in mappings))
    adjudication = load(PACKAGE / "V24_DEFECT_ADJUDICATION.json")
    check("I010_DEFECT", adjudication.get("HISTORICAL_DECISION_REGISTRY_LOGICAL_IDENTITY_TO_RECORD_TYPE_BINDING_DEFECT") == "YES")
    check("I011_ARTIFACTS_NOT_DEFECTIVE", adjudication.get("FROZEN_HISTORICAL_DECISION_ARTIFACT_DEFECT") == "NO")
    check("I012_FIXTURES_NOT_RUNTIME", adjudication.get("fixture_results_are_not_runtime_success") is True and adjudication.get("runtime", {}).get("security_worker") == "NOT_ESTABLISHED")
    decision = load(PACKAGE / "V24_TERMINAL_AND_V25_SUCCESSOR_DECISION.json")
    check("I013_DECISION", decision.get("decision") == "TERMINALIZE_V24_AND_AUTHORIZE_DISTINCT_V25_CONDITIONALLY" and decision.get("v24_continuation") == "PROHIBITED")
    check("I014_NO_V25", not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v25-20261101").exists())
    check("I015_NO_EXECUTION", not (V24 / "STATIC_EXECUTION_LOCK.json").exists() and not (V24 / "static-run-v24/ATTEMPT_MARKER.json").exists())
    for name in ("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"):
        check(f"I_{name}", load(PACKAGE / name).get("status") == "PASS")
    failures = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {"record_type": "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT", "governance_identity": GOVERNANCE_ID, "checks": checks, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "failure_ids": failures, "status": "PASS" if not failures else "FAIL_CLOSED"}
    write_once(PACKAGE / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(f"INDEPENDENT_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failures)}/{len(checks)}")
    if failures: raise SystemExit(1)


if __name__ == "__main__": main()
