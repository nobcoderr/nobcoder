#!/usr/bin/env python3
"""Deterministic governance checks; performs no provisioning or execution."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


HERE = Path(__file__).resolve().parent
HOME = Path("/home/nobcoder")
OLD = HOME / "codex-security-harness-eval/governance/v0.2-i4-b-benign-isolation-governance-decision-v1-20261009"
IDENTITY = "V0.2_I4_B_DEDICATED_ENVIRONMENT_READINESS_GOVERNANCE_V1"


def load(name: str):
    with (HERE / name).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


protocol = load("GOVERNANCE_GATE_PROTOCOL.json")
preflight = load("PREFLIGHT_RESULT.json")
decision = load("ENVIRONMENT_READINESS_DECISION.json")
candidates = load("HOST_CANDIDATE_MATRIX.json")
requirements = load("DEDICATED_VM_REQUIREMENTS.json")
evidence = load("CAPABILITY_EVIDENCE_MATRIX.json")
provisioning = load("PROVISIONING_REQUIREMENTS.json")
sequence = load("FUTURE_VALIDATION_SEQUENCE.json")
threats = load("ENVIRONMENT_THREAT_MODEL.json")
risks = load("RISK_REGISTER.json")

check("governance_identity", protocol["gate_id"] == IDENTITY)
check("governance_task_is_governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
check("preflight_pass", preflight["status"] == "PASS")
check("fresh_identity_no_collision", preflight["identity_collision"] is False)
check("historical_i4b_execution_not_authorized", preflight["authorization_state"]["existing_i4_b_execution_authorization"] is False)
check("historical_i4b_authorization_file_absent", not (OLD / "I4_B_AUTHORIZATION.json").exists())
check("historical_sandbox_execution_zero", preflight["authorization_state"]["historical_sandbox_executions"] == 0)
check("router_not_required", preflight["router_required"] is False)
check("router_paths_blocked", preflight["router_dependent_workflows"] == "BLOCKED")
check("writes_to_predecessors_zero", preflight["immutability"]["writes_to_previous_trees"] == 0)

expected_old = {
    "BENIGN_ISOLATION_TEST_CONTRACT.json": "4a5af1a49d1ddcf1deac26eb7004b886fb70125b2fb9302a44be73766c377649",
    "ISOLATION_EVIDENCE_REQUIREMENTS.json": "4625020fdf8dad1408a0d5838fc337ae404eb23b7f47f8e36c846c4f1e7db944",
    "HOST_SELECTION_REQUIREMENTS.json": "ca939500f2cee91daba805387b62abe5ae7a568dc29b5e14118e8e8a7580164d",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "317c96b2e7483727998d1cbb256219c7183d55258aec482c6f014263407ae4b5",
    "GOVERNANCE_LOCK.json": "9e8fdee36dbcbf27c3428653ba746c4ed77670b3d36d028cf624a69e0d23e442",
}
for name, digest in expected_old.items():
    check(f"historical_digest_{name}", (OLD / name).is_file() and sha(OLD / name) == digest)

old_lock = json.loads((OLD / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8"))
check("historical_root_digest", old_lock["artifact_root_sha256"] == "998e2c86caa8874fb1f0c79f42bdf7929d0a5960c109c244b83132759ab72274")
check("historical_decision_execution_blocked", old_lock["decision"] == "GOVERNANCE_REVIEW_PASS_EXECUTION_BLOCKED")
check("historical_current_host_blocked", old_lock["authorization_state"]["CURRENT_HOST"] == "BLOCKED_UNSUPPORTED_HOST_FOR_ACTUAL_EXECUTION")

manifest_specs = [
    (HOME / "v0.2-experimental-research-engine", "governance/i0/SOURCE_MANIFEST.json", "1a14d9c6dca921016acb79831e531308480fa9876e62ded6e1976b51ccbc311c", "i0"),
    (HOME / "v0.2-experimental-research-engine-i1", "governance/i1/SOURCE_MANIFEST.json", "be1c40bb8c499672afe8e411dbb235060f1d0666931cdd3282d9a2ae4e3c651b", "i1"),
    (HOME / "v0.2-experimental-research-engine-i2", "governance/i2/SOURCE_MANIFEST.json", "bb4abb8d766987a65a96205acca6c74ff2200551d8c925086431e0f27d0ee129", "i2"),
    (HOME / "v0.2-experimental-research-engine-i3", "governance/i3/SOURCE_MANIFEST.json", "711d9b026870ff55135c5534f88bfc394d7734ee9943a8063baa189ac270c83e", "i3"),
    (HOME / "v0.2-experimental-research-engine-i4", "governance/i4a/SOURCE_MANIFEST.json", "138fd2e59526a663486f54b263b8167283e1736a54fbceb777c7a73dbe02ac34", "i4a"),
]
for root, rel_manifest, expected_root, label in manifest_specs:
    manifest = json.loads((root / rel_manifest).read_text(encoding="utf-8"))
    records = []
    valid = True
    for item in manifest["files"]:
        path = root / item["path"]
        actual = sha(path) if path.is_file() else "MISSING"
        valid = valid and actual == item["sha256"]
        records.append(f'{item["sha256"]}  {item["path"]}')
    computed = hashlib.sha256(("\n".join(sorted(records, key=lambda record: record.split("  ", 1)[1])) + "\n").encode()).hexdigest()
    check(f"{label}_manifest_files", valid)
    check(f"{label}_canonical_root", manifest["source_tree_sha256"] == expected_root and computed == expected_root)
    no_writable = all(not (p.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)) for p in root.rglob("*") if p.is_file() or p.is_dir())
    no_symlinks = not any(p.is_symlink() for p in root.rglob("*"))
    check(f"{label}_read_only_no_symlinks", no_writable and no_symlinks)

snapshot = HOME / "codex-security-harness-eval/governance/v0.1-foundation-freeze-snapshot-20261009/SNAPSHOT_LOCK.json"
check("v0_1_snapshot_lock", sha(snapshot) == "66ef07d8fa5336ccba83a4d41db42c788e01d455ed4cdc492f4365d51387dbaa")

check("decision_pass_locked", decision["status"] == "PASS_LOCKED")
check("reference_architecture_selected", decision["reference_environment_architecture"] == "DEDICATED_DISPOSABLE_LINUX_VM")
check("reference_architecture_only", decision["reference_architecture_status"] == "SUFFICIENT_FOR_FUTURE_PROVISIONING_PROPOSAL")
check("actual_host_not_selected", decision["actual_candidate_host"] == "NOT_SELECTED_NOT_AUTHORIZED" and candidates["selected_actual_host"] is None)
check("current_host_rejected", decision["current_host"] == "REJECTED_FOR_I4_B_EXECUTION")
check("vm_not_provisioned", decision["dedicated_vm"] == "NOT_PROVISIONED_NOT_VERIFIED")
check("runtime_readiness_not_established", decision["host_runtime_readiness"] == "NOT_ESTABLISHED")
check("runtime_isolation_not_evaluated", decision["actual_runtime_isolation"] == "NOT_EVALUATED")
check("provisioning_not_authorized", decision["provisioning_authorization"] == "NOT_GRANTED" and provisioning["current_authorization"] == "NONE")
check("configuration_not_authorized", decision["host_configuration_authorization"] == "NOT_GRANTED")
check("i4b_execution_not_authorized", decision["i4_b_execution_authorization"] == "NOT_GRANTED")
check("i5_not_authorized", decision["i5"] == "NOT_AUTHORIZED")
check("v0_3_not_open", decision["v0_3"] == "NOT_OPENED")
check("no_operational_scope", decision["approved_operational_scope"] == "NONE")
check("no_auto_successor", decision["automatic_successor_authorization"] is False)

ids = [item["id"] for item in requirements["requirements"]]
check("requirements_h1_h24", ids == [f"H{i}" for i in range(1, 25)])
check("requirements_count", requirements["requirement_count"] == len(requirements["requirements"]) == 24)
check("requirements_definition_complete", requirements["definition_completeness"] == "PASS")
check("requirements_zero_satisfied", requirements["evidence_satisfaction"] == "0_OF_24_FOR_ANY_DEDICATED_HOST")
check("requirements_all_fail_closed", all(bool(item.get("fail_closed")) for item in requirements["requirements"]))

check("capability_matrix_count", evidence["row_count"] == len(evidence["rows"]) == 20)
check("capability_status_no_eligible_host", evidence["status"] == "COMPLETE_MATRIX_NO_ELIGIBLE_HOST")
check("no_runtime_observations", evidence["dedicated_host_runtime_observations"] == 0)
check("no_supported_dedicated_capabilities", evidence["dedicated_host_supported_capabilities"] == 0)
check("classification_vocabulary_exact", set(evidence["classification_vocabulary"]) == {"STATIC_EVIDENCE", "RUNTIME_OBSERVATION", "NOT_ESTABLISHED", "UNSUPPORTED"})
check("cgroup_current_host_unsupported", any(row["capability"] == "cgroup_v2_delegation" and row["actual_evidence_type"] == "UNSUPPORTED" for row in evidence["rows"]))
check("landlock_not_established", any(row["capability"] == "landlock_abi_and_rights" and row["actual_evidence_type"] == "NOT_ESTABLISHED" for row in evidence["rows"]))
check("network_not_established", any(row["capability"] == "network_egress_denial" and row["actual_evidence_type"] == "NOT_ESTABLISHED" for row in evidence["rows"]))

check("future_gate_count", len(sequence["gates"]) == 9)
check("future_gates_not_auto_authorized", all(gate["successor_auto_authorized"] is False for gate in sequence["gates"]))
check("next_gate_is_provisioning_authorization", sequence["current_next_gate"] == "DEDICATED_ENVIRONMENT_PROVISIONING_AUTHORIZATION")
check("gate_merge_forbidden", sequence["merge_or_skip_gates"] == "FORBIDDEN")
check("threat_model_count", threats["threat_count"] == len(threats["threats"]) == 27)
check("threat_model_runtime_not_evaluated", threats["result"] == "REFERENCE_ARCHITECTURE_THREAT_MODEL_COMPLETE_RUNTIME_RISK_NOT_EVALUATED")
required_threat_fields = {"id", "boundary", "condition", "impact", "mitigation", "independent_validation", "fail_closed"}
check("threat_records_complete", all(required_threat_fields <= set(item) for item in threats["threats"]))
check("risk_count", risks["risk_count"] == len(risks["risks"]) == 14)
check("router_mismatch_open", risks["router"]["status"] == "OPEN" and risks["router"]["router_dependent_paths"] == "BLOCKED")

for forbidden_name in ("I4_B_AUTHORIZATION.json", "PROVISIONING_AUTHORIZATION.json", "EXECUTION_SEAL.json"):
    check(f"forbidden_artifact_absent_{forbidden_name}", not (HERE / forbidden_name).exists())

passed = sum(1 for item in checks if item["pass"])
failed = len(checks) - passed
print(json.dumps({
    "identity": IDENTITY,
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
    "product_activity": {
        "vm_provisioning": 0,
        "host_configuration": 0,
        "sandbox_executions": 0,
        "workload_child_processes": 0,
        "network_probes": 0,
        "fixture_executions": 0,
        "research_worker_model_invocations": 0,
        "scoring_runs": 0,
        "writes_to_predecessor_trees": 0,
    },
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
