#!/usr/bin/env python3
"""Independent structural validator for the dedicated-environment decision."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OLD = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.2-i4-b-benign-isolation-governance-decision-v1-20261009")
EXPECTED_ID = "V0.2_I4_B_DEDICATED_ENVIRONMENT_READINESS_GOVERNANCE_V1"


def read(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


results = []


def assert_check(label: str, value: bool):
    results.append({"check": label, "pass": bool(value)})


p = read("GOVERNANCE_GATE_PROTOCOL.json")
d = read("ENVIRONMENT_READINESS_DECISION.json")
c = read("HOST_CANDIDATE_MATRIX.json")
r = read("DEDICATED_VM_REQUIREMENTS.json")
e = read("CAPABILITY_EVIDENCE_MATRIX.json")
v = read("PROVISIONING_REQUIREMENTS.json")
q = read("FUTURE_VALIDATION_SEQUENCE.json")
t = read("ENVIRONMENT_THREAT_MODEL.json")
k = read("RISK_REGISTER.json")

assert_check("identity_consistent", p["gate_id"] == d["gate_id"] == EXPECTED_ID)
assert_check("historical_lock_bytes", digest(OLD / "GOVERNANCE_LOCK.json") == p["predecessors"]["i4_b_governance_lock_sha256"])
assert_check("historical_manifest_bytes", digest(OLD / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "317c96b2e7483727998d1cbb256219c7183d55258aec482c6f014263407ae4b5")
old_lock = json.loads((OLD / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8"))
root_records = []
for path in sorted(path for path in OLD.iterdir() if path.is_file() and path.name != "GOVERNANCE_LOCK.json"):
    root_records.append(f"{digest(path)}  {path.name}")
old_root = hashlib.sha256(("\n".join(root_records) + "\n").encode()).hexdigest()
assert_check("historical_artifact_root_recomputed", old_root == old_lock["artifact_root_sha256"] == p["predecessors"]["i4_b_artifact_root_sha256"])
assert_check("historical_scope_blocked", old_lock["authorization_state"]["APPROVED_EXECUTION_SCOPE"] == "NONE")
assert_check("no_historical_authorization_artifact", not (OLD / "I4_B_AUTHORIZATION.json").exists())

assert_check("decision_is_reference_only", d["decision"] == "REFERENCE_ARCHITECTURE_ACCEPTED_HOST_NOT_SELECTED")
assert_check("reference_vm_selected", c["selected_reference"] == "B_DEDICATED_DISPOSABLE_LINUX_VM_REFERENCE")
assert_check("no_concrete_host_selected", c["selected_actual_host"] is None and d["actual_candidate_host"] == "NOT_SELECTED_NOT_AUTHORIZED")
assert_check("current_host_rejected", c["candidates"][0]["selection_status"] == "REJECTED_FOR_I4_B_EXECUTION")
assert_check("reference_vm_not_ready", c["candidates"][1]["evidence_status"] == "NOT_ESTABLISHED")
assert_check("alternative_runner_not_invented", c["candidates"][2]["selection_status"] == "NO_CANONICAL_EVIDENCE_NO_HOST_IDENTIFIED")
assert_check("runtime_readiness_not_established", d["host_runtime_readiness"] == "NOT_ESTABLISHED")
assert_check("runtime_isolation_not_evaluated", d["actual_runtime_isolation"] == "NOT_EVALUATED")

assert_check("all_authorizations_denied", all(d[field] == "NOT_GRANTED" for field in ("provisioning_authorization", "host_configuration_authorization", "i4_b_execution_authorization")))
assert_check("later_milestones_closed", d["i5"] == "NOT_AUTHORIZED" and d["v0_3"] == "NOT_OPENED")
assert_check("zero_scope", d["approved_operational_scope"] == "NONE")
assert_check("no_automatic_authority", d["automatic_successor_authorization"] is False)

expected_ids = {f"H{i}" for i in range(1, 25)}
actual_ids = {item["id"] for item in r["requirements"]}
assert_check("h1_h24_complete", actual_ids == expected_ids and r["requirement_count"] == 24)
assert_check("every_requirement_maps_evidence", all(item.get("expected_evidence") and item.get("current_evidence") for item in r["requirements"]))
assert_check("every_requirement_fail_closed", all(item.get("fail_closed") for item in r["requirements"]))
assert_check("no_host_requirement_claimed_satisfied", r["evidence_satisfaction"] == "0_OF_24_FOR_ANY_DEDICATED_HOST")

assert_check("capability_rows_match_count", e["row_count"] == len(e["rows"]) == 20)
assert_check("capability_types_allowed", all(item["actual_evidence_type"] in e["classification_vocabulary"] for item in e["rows"]))
assert_check("runtime_observation_count_zero", e["dedicated_host_runtime_observations"] == 0)
assert_check("eligible_capability_count_zero", e["dedicated_host_supported_capabilities"] == 0)
assert_check("mandatory_current_host_controls_unsupported", {item["capability"] for item in e["rows"] if item["actual_evidence_type"] == "UNSUPPORTED"} >= {"cgroup_v2_delegation", "cpu_memory_pid_controllers"})
assert_check("landlock_not_promoted", next(item for item in e["rows"] if item["capability"] == "landlock_abi_and_rights")["actual_evidence_type"] == "NOT_ESTABLISHED")

assert_check("provisioning_spec_no_authority", v["current_authorization"] == "NONE")
assert_check("sensitive_operations_separately_authorized", len(v["operations_requiring_separate_authorization"]) >= 8)
assert_check("network_families_covered", all(term in json.dumps(v["network_and_ipc"]) for term in ("IPv4", "IPv6", "DNS", "AF_VSOCK")))
assert_check("credential_exclusion_present", "credential" in json.dumps(v["credentials"]).lower())
assert_check("cgroup_delegation_required", "cgroup" in json.dumps(v["resources_and_delegation"]).lower())

assert_check("nine_future_gates", len(q["gates"]) == 9)
assert_check("no_future_gate_auto_authorized", not any(item["successor_auto_authorized"] for item in q["gates"]))
assert_check("provisioning_authorization_is_next", q["gates"][1]["name"] == "DEDICATED_ENVIRONMENT_PROVISIONING_AUTHORIZATION")
assert_check("i4b_execution_is_separate_gate", q["gates"][5]["name"] == "BENIGN_ISOLATION_EXECUTION")
assert_check("i5_last_and_closed", q["gates"][-1]["name"] == "NEW_I5_GOVERNANCE_DECISION" and q["gates"][-1]["state"] == "NOT_AUTHORIZED")

required_threat_topics = ("hypervisor", "credential", "IPv6", "AF_VSOCK", "cgroup", "Landlock", "seccomp", "orphan", "router")
serialized_threats = json.dumps(t["threats"])
assert_check("threat_count_consistent", t["threat_count"] == len(t["threats"]) == 27)
assert_check("threat_topics_covered", all(topic.lower() in serialized_threats.lower() for topic in required_threat_topics))
assert_check("threats_have_dispositions", all(item.get("fail_closed") for item in t["threats"]))
assert_check("risk_count_consistent", k["risk_count"] == len(k["risks"]) == 14)
assert_check("router_open_and_blocked", k["router"]["status"] == "OPEN" and k["router"]["router_dependent_paths"] == "BLOCKED")

assert_check("authorization_artifacts_absent", not any((ROOT / name).exists() for name in ("I4_B_AUTHORIZATION.json", "PROVISIONING_AUTHORIZATION.json", "EXECUTION_SEAL.json")))
assert_check("next_event_exact", d["required_next_event"] == "NEW_I4_B_DEDICATED_ENVIRONMENT_PROVISIONING_AUTHORIZATION_DECISION")

ok = sum(item["pass"] for item in results)
bad = len(results) - ok
print(json.dumps({
    "identity": EXPECTED_ID,
    "validator": "independent_structural_validator_v1",
    "status": "PASS" if bad == 0 else "FAIL",
    "passed": ok,
    "failed": bad,
    "total": len(results),
    "checks": results,
}, indent=2, sort_keys=True))
raise SystemExit(0 if bad == 0 else 1)
