#!/usr/bin/env python3
"""Freeze and lock SecurityWorkerRuntime V1 implementation authorization."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
FUTURE = Path("/home/nobcoder/v0.3-security-worker-runtime-v1-20261020")
IDENTITY = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_MINIMAL_CONTRACT_AND_IMPLEMENTATION"
NEXT = "IMPLEMENT_STATICALLY_VALIDATE_AND_FREEZE_V0_3_SECURITY_WORKER_RUNTIME_V1_NO_WORKER_INVOCATION"
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_LOCK_BINDINGS.json",
    "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION.json", "MINIMAL_TOPOLOGY_CONTRACT.json",
    "WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json", "STRUCTURED_IO_AND_STATE_REQUIREMENTS.json",
    "WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json", "EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json",
    "WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json", "CAPABILITY_SUPPORT_AND_AUTHORITY_MATRIX.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json"}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"])).encode()).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"finalizer input set mismatch: {sorted(actual)}")
    if FUTURE.exists() or FUTURE.is_symlink():
        raise SystemExit("future implementation exists before authorization freeze")
    checks: list[dict[str, Any]] = []
    def check(name: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": name, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SCRIPT_" + script, valid)
    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative_historical = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    independent = read(ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F001_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("F002_NEGATIVE_HISTORY", negative_historical.get("status") == "FAIL_CLOSED" and negative_historical.get("tests_passed") == 29 and negative_historical.get("tests_total") == 30)
    check("F003_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_total") == 30 and negative.get("tests_failed") == 0)
    check("F004_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_failed") == 0)
    check("F005_RESULT_IDENTITIES", all(doc.get("governance_identity") == IDENTITY for doc in (primary, negative_historical, negative, independent)))
    decision = read(ROOT / "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION.json")
    topology = read(ROOT / "MINIMAL_TOPOLOGY_CONTRACT.json")
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    worker = read(ROOT / "WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json")
    evidence = read(ROOT / "EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json")
    check("F005_DECISION", decision.get("decision") == DECISION and decision.get("state") == "IMPLEMENTATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F006_FUTURE_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    check("F007_TOPOLOGY", (topology.get("maximum_campaigns"), topology.get("maximum_lanes_per_campaign"), topology.get("maximum_worker_identities"), topology.get("maximum_active_workers")) == (1, 1, 1, 0))
    check("F008_RUNTIME", topology.get("runtime_identity") == "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED")
    check("F009_PROPOSAL_QUARANTINE", worker.get("worker_role") == "PROPOSAL_ONLY" and worker.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED")
    check("F010_NO_SELF_AUTH_PROMOTION", worker.get("worker_self_authorization") == "PERMANENTLY_PROHIBITED" and worker.get("worker_self_promotion") == "PERMANENTLY_PROHIBITED")
    check("F011_PROVENANCE", evidence.get("digest_required") is True and evidence.get("append_only_invocation_ledger_required") is True and evidence.get("worker_may_mutate_evidence_history") is False)
    escalations = {key: value for key, value in authority.items() if key.endswith("_authorized") and key != "implementation_authorized" and value is not False}
    check("F012_IMPLEMENTATION_ONLY", authority.get("implementation_authorized") is True and not escalations, escalations)
    check("F013_COUNTERS_ZERO", len(authority.get("operation_counters", {})) == 12 and all(value == 0 for value in authority.get("operation_counters", {}).values()))
    failed = [row for row in checks if row["status"] == "FAIL"]
    if failed:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failed))
    write(FREEZE, {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_FINAL_FREEZE_VERIFICATION_RESULT", "schema_version": "1.0",
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001", "status": "PASS", "checks": checks,
        "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "future_runtime_absent": True, "worker_invoked": False, "codex_invoked": False, "network_used": False,
    })
    names = sorted(expected | {FREEZE})
    rows = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in names]
    artifact_root = canonical(rows)
    write(MANIFEST, {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0",
        "member_count": len(rows), "members": rows, "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    write(LOCK, {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_GOVERNANCE_LOCK", "schema_version": "1.0",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "security_worker_runtime_v1": "IMPLEMENTATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "topology": "1_CAMPAIGN_1_LANE_1_WORKER_IDENTITY_CODEX_0_163_0_SERIAL_CONTROLLED_LOCAL_FIXTURE",
        "runtime_identity": "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED",
        "implementation_authorized": True, "worker_execution_authorized": False, "codex_worker_invocation_authorized": False,
        "subagent_execution_authorized": False, "credential_injection_authorized": False,
        "target_access_authorized": False, "external_network_authorized": False, "daybreak_invocation_authorized": False,
        "exploit_replay_authorized": False, "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "validation": {
            "primary": {"status": primary["status"], "passed": primary["checks_passed"], "total": primary["checks_total"]},
            "negative": {"status": negative["status"], "passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent": {"status": independent["status"], "passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        },
        "governance_manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root,
        "operation_counters": authority["operation_counters"], "next_legal_milestone": NEXT,
        "authority_ceiling": "IMPLEMENTATION_AND_STATIC_FIXTURE_VALIDATION_ONLY_NO_WORKER_OR_CODEX_WORKER_INVOCATION_SUBAGENT_CREDENTIAL_TARGET_NETWORK_DAYBREAK_EXPLOIT_PARALLEL_CAPABILITY_PROMOTION_OR_SUBMISSION",
    })
    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION, "manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root, "files": len(rows)+2}, sort_keys=True))


if __name__ == "__main__":
    main()
