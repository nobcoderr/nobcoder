#!/usr/bin/env python3
"""Primary and negative validation for SecurityWorkerRuntime V1 authorization."""

from __future__ import annotations

import ast
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
FUTURE = Path("/home/nobcoder/v0.3-security-worker-runtime-v1-20261020")
IDENTITY = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_MINIMAL_CONTRACT_AND_IMPLEMENTATION"
CODEX_RUNTIME = "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED"
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_LOCK_BINDINGS.json",
    "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION.json", "MINIMAL_TOPOLOGY_CONTRACT.json",
    "WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json", "STRUCTURED_IO_AND_STATE_REQUIREMENTS.json",
    "WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json", "EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json",
    "WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json", "CAPABILITY_SUPPORT_AND_AUTHORITY_MATRIX.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def admissible(docs: dict[str, dict[str, Any]]) -> bool:
    decision = docs["SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION.json"]
    topology = docs["MINIMAL_TOPOLOGY_CONTRACT.json"]
    bindings = docs["WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json"]
    io = docs["STRUCTURED_IO_AND_STATE_REQUIREMENTS.json"]
    isolation = docs["WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json"]
    evidence = docs["EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json"]
    worker = docs["WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json"]
    authority = docs["AUTHORITY_NON_ESCALATION_DECISION.json"]
    predecessor = docs["PREDECESSOR_LOCK_BINDINGS.json"]
    return all([
        decision.get("decision") == DECISION and decision.get("state") == "IMPLEMENTATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        decision.get("worker_invocation_authorized") is False and decision.get("codex_worker_invocation_authorized") is False,
        topology.get("maximum_campaigns") == 1 and topology.get("maximum_lanes_per_campaign") == 1 and topology.get("maximum_worker_identities") == 1,
        topology.get("maximum_active_workers") == 0 and topology.get("scheduling") == "SERIAL_ONLY",
        topology.get("runtime_identity") == CODEX_RUNTIME and topology.get("workspace") == "CONTROLLED_LOCAL_OR_FIXTURE_ONLY",
        bindings.get("campaign_binding", {}).get("required") is True and bindings.get("lane_binding", {}).get("required") is True,
        bindings.get("runtime_binding", {}).get("identity") == CODEX_RUNTIME and bindings.get("authorization_binding", {}).get("required") is True,
        io.get("structured_worker_input_required") is True and io.get("structured_worker_output_required") is True and io.get("free_form_prose_authoritative") is False,
        io.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED" and io.get("worker_can_set_validated_or_strong") is False,
        isolation.get("workspace_isolation_required") is True and isolation.get("unbounded_budget_allowed") is False,
        bool(isolation.get("timeout_semantics")) and bool(isolation.get("cancellation_semantics")),
        evidence.get("digest_required") is True and evidence.get("worker_may_mutate_evidence_history") is False,
        worker.get("worker_role") == "PROPOSAL_ONLY" and worker.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED",
        worker.get("worker_self_authorization") == "PERMANENTLY_PROHIBITED" and worker.get("worker_self_promotion") == "PERMANENTLY_PROHIBITED",
        predecessor.get("all_bindings_verified") is True and predecessor.get("binding_count") == 5,
        predecessor.get("codex_runtime_state") == CODEX_RUNTIME and predecessor.get("worker_execution_state") == "NOT_AUTHORIZED",
        authority.get("implementation_authorized") is True,
        not any(value for key, value in authority.items() if key.endswith("_authorized") and key != "implementation_authorized"),
        len(authority.get("operation_counters", {})) == 12 and all(value == 0 for value in authority.get("operation_counters", {}).values()),
    ])


def main() -> None:
    expected = SCRIPTS | BASE
    preserved_prior_results = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"}
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual not in (expected, expected | preserved_prior_results) or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"primary input set mismatch: {sorted(actual)}")
    if FUTURE.exists() or FUTURE.is_symlink():
        raise SystemExit("future implementation exists during governance authorization")
    docs = {name: read(ROOT / name) for name in BASE}
    checks: list[dict[str, Any]] = []
    def check(name: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": name, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("SCRIPT_SYNTAX_" + script, valid)
    check("P001_IDENTITY", all(doc.get("governance_identity") == IDENTITY for doc in docs.values()))
    check("P002_FUTURE_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    check("P003_ADMISSIBLE", admissible(docs))
    check("P004_PREDECESSORS", docs["PREDECESSOR_LOCK_BINDINGS.json"].get("binding_count") == 5 and docs["PREDECESSOR_LOCK_BINDINGS.json"].get("all_bindings_verified") is True)
    topology = docs["MINIMAL_TOPOLOGY_CONTRACT.json"]
    check("P005_CAMPAIGN_ONE", topology.get("maximum_campaigns") == 1)
    check("P006_LANE_ONE", topology.get("maximum_lanes_per_campaign") == 1)
    check("P007_WORKER_IDENTITY_ONE", topology.get("maximum_worker_identities") == 1)
    check("P008_ACTIVE_WORKER_ZERO", topology.get("maximum_active_workers") == 0)
    check("P009_SERIAL_ONLY", topology.get("scheduling") == "SERIAL_ONLY")
    check("P010_CONTROLLED_WORKSPACE", topology.get("workspace") == "CONTROLLED_LOCAL_OR_FIXTURE_ONLY")
    bindings = docs["WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json"]
    check("P011_FIVE_BINDINGS", set(bindings.get("required_first_class_objects", [])) == {"WorkerIdentity", "CampaignBinding", "LaneBinding", "RuntimeIdentity", "AuthorizationBinding"})
    check("P012_RUNTIME_PIN", bindings.get("runtime_binding", {}).get("identity") == CODEX_RUNTIME and bindings.get("runtime_binding", {}).get("version") == "0.163.0")
    io = docs["STRUCTURED_IO_AND_STATE_REQUIREMENTS.json"]
    check("P013_STRUCTURED_IO", io.get("structured_worker_input_required") is True and io.get("structured_worker_output_required") is True)
    check("P014_QUARANTINE_FIRST", io.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED")
    isolation = docs["WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json"]
    check("P015_ISOLATION", isolation.get("workspace_isolation_required") is True and isolation.get("unsandboxed_fallback") == "PROHIBITED")
    check("P016_BUDGET_TIMEOUT_CANCEL", isolation.get("resource_budget_required") is True and isolation.get("unbounded_budget_allowed") is False and bool(isolation.get("timeout_semantics")) and bool(isolation.get("cancellation_semantics")))
    evidence = docs["EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json"]
    check("P017_PROVENANCE", all(evidence.get(key) is True for key in ("evidence_ref_required", "digest_required", "producer_binding_required", "campaign_binding_required", "lane_binding_required", "worker_binding_required", "runtime_binding_required", "authorization_binding_required")))
    worker = docs["WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json"]
    check("P018_PROPOSAL_ONLY", worker.get("worker_role") == "PROPOSAL_ONLY")
    check("P019_NO_SELF_AUTH", worker.get("worker_self_authorization") == "PERMANENTLY_PROHIBITED")
    check("P020_NO_SELF_PROMOTION", worker.get("worker_self_promotion") == "PERMANENTLY_PROHIBITED")
    authority = docs["AUTHORITY_NON_ESCALATION_DECISION.json"]
    escalations = {key: value for key, value in authority.items() if key.endswith("_authorized") and key != "implementation_authorized" and value is not False}
    check("P021_IMPLEMENT_ONLY", authority.get("implementation_authorized") is True and not escalations, escalations)
    check("P022_SEPARATION_RULE", authority.get("normative_rule") == "IMPLEMENTATION_AUTHORIZED_NE_WORKER_INVOCATION_AUTHORIZED_NE_TARGET_ACCESS_AUTHORIZED")
    capability = docs["CAPABILITY_SUPPORT_AND_AUTHORITY_MATRIX.json"]
    check("P023_FUTURE_CAPABILITIES_DEFERRED", len(capability.get("rows", [])) == 12 and all(row.get("support_state") == "SUPPORTED_BY_ARCHITECTURE" and row.get("authority_state") == "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION" for row in capability.get("rows", [])))
    operations = docs["OPERATION_AUTHORIZATION_MATRIX.json"]
    check("P024_OPERATION_COUNTERS_ZERO", len(operations.get("operation_counters", {})) == 12 and all(value == 0 for value in operations.get("operation_counters", {}).values()))
    check("P025_NEXT_NO_INVOCATION", docs["NEXT_LEGAL_MILESTONE.json"].get("worker_invocation_during_next_milestone") == "PROHIBITED")
    failed = [row for row in checks if row["status"] == "FAIL"]
    primary_payload = {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_PRIMARY_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "GOVERNANCE_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed),
        "worker_invoked": False, "codex_invoked": False, "network_used": False,
    }
    primary_path = ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"
    if primary_path.exists():
        existing_primary = read(primary_path)
        if existing_primary.get("status") != "PASS" or existing_primary.get("checks_failed") != 0:
            raise SystemExit("existing primary validation is not admissible")
    else:
        write("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", primary_payload)
    if failed:
        raise SystemExit("primary governance validation failed")

    tests = []
    for row in docs["NEGATIVE_GOVERNANCE_TEST_MATRIX.json"]["tests"]:
        mutation = row["mutation"]
        mutated = deepcopy(docs)
        if mutation == "PREDECESSOR_LOCK_MISMATCH": mutated["PREDECESSOR_LOCK_BINDINGS.json"]["all_bindings_verified"] = False
        elif mutation == "CODEX_COMPATIBILITY_NOT_PASS_LOCKED": mutated["PREDECESSOR_LOCK_BINDINGS.json"]["codex_runtime_state"] = "NOT_ESTABLISHED"
        elif mutation == "CAMPAIGN_COUNT_GT_ONE": mutated["MINIMAL_TOPOLOGY_CONTRACT.json"]["maximum_campaigns"] = 2
        elif mutation == "LANE_COUNT_GT_ONE": mutated["MINIMAL_TOPOLOGY_CONTRACT.json"]["maximum_lanes_per_campaign"] = 2
        elif mutation == "WORKER_IDENTITY_COUNT_GT_ONE": mutated["MINIMAL_TOPOLOGY_CONTRACT.json"]["maximum_worker_identities"] = 2
        elif mutation == "ACTIVE_WORKER_NONZERO": mutated["MINIMAL_TOPOLOGY_CONTRACT.json"]["maximum_active_workers"] = 1
        elif mutation == "NON_SERIAL_SCHEDULING": mutated["MINIMAL_TOPOLOGY_CONTRACT.json"]["scheduling"] = "PARALLEL"
        elif mutation == "RUNTIME_IDENTITY_DRIFT": mutated["WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json"]["runtime_binding"]["identity"] = "CODEX_LATEST"
        elif mutation == "UNCONTROLLED_WORKSPACE": mutated["MINIMAL_TOPOLOGY_CONTRACT.json"]["workspace"] = "ARBITRARY_HOST"
        elif mutation == "UNSTRUCTURED_INPUT": mutated["STRUCTURED_IO_AND_STATE_REQUIREMENTS.json"]["structured_worker_input_required"] = False
        elif mutation == "UNSTRUCTURED_OUTPUT": mutated["STRUCTURED_IO_AND_STATE_REQUIREMENTS.json"]["structured_worker_output_required"] = False
        elif mutation == "FREE_FORM_PROSE_AUTHORITATIVE": mutated["STRUCTURED_IO_AND_STATE_REQUIREMENTS.json"]["free_form_prose_authoritative"] = True
        elif mutation == "CANDIDATE_INITIAL_STATE_NOT_QUARANTINED": mutated["STRUCTURED_IO_AND_STATE_REQUIREMENTS.json"]["candidate_initial_state"] = "VALIDATED"
        elif mutation == "WORKER_SELF_AUTHORIZATION": mutated["WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json"]["worker_self_authorization"] = "ALLOWED"
        elif mutation == "WORKER_SELF_PROMOTION": mutated["WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json"]["worker_self_promotion"] = "ALLOWED"
        elif mutation == "MISSING_CAMPAIGN_BINDING": mutated["WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json"]["campaign_binding"]["required"] = False
        elif mutation == "MISSING_LANE_BINDING": mutated["WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json"]["lane_binding"]["required"] = False
        elif mutation == "MISSING_RUNTIME_BINDING": mutated["WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json"]["runtime_binding"]["identity"] = None
        elif mutation == "MISSING_AUTHORIZATION_BINDING": mutated["WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json"]["authorization_binding"]["required"] = False
        elif mutation == "MISSING_EVIDENCE_DIGEST": mutated["EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json"]["digest_required"] = False
        elif mutation == "WORKER_CAN_MUTATE_EVIDENCE_HISTORY": mutated["EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json"]["worker_may_mutate_evidence_history"] = True
        elif mutation == "UNBOUNDED_BUDGET": mutated["WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json"]["unbounded_budget_allowed"] = True
        elif mutation == "MISSING_TIMEOUT_SEMANTICS": mutated["WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json"]["timeout_semantics"] = ""
        elif mutation == "MISSING_CANCELLATION_SEMANTICS": mutated["WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json"]["cancellation_semantics"] = ""
        elif mutation == "CREDENTIAL_AUTHORITY_LEAK": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["credential_injection_authorized"] = True
        elif mutation == "TARGET_OR_NETWORK_AUTHORITY_LEAK": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["target_access_authorized"] = True
        elif mutation == "DAYBREAK_OR_EXPLOIT_AUTHORITY_LEAK": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["exploit_replay_authorized"] = True
        elif mutation == "SUBAGENT_OR_PARALLEL_AUTHORITY_LEAK": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["parallelism_authorized"] = True
        elif mutation == "CAPABILITY_PROMOTION_OR_SUBMISSION_AUTHORITY_LEAK": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["candidate_promotion_authorized"] = True
        elif mutation == "IMPLEMENTATION_IMPLIES_WORKER_INVOCATION": mutated["SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION.json"]["worker_invocation_authorized"] = True
        rejected = not admissible(mutated)
        tests.append({"test_id": row["test_id"], "mutation": mutation, "expected": row["expected"], "observed": "REJECTED" if rejected else "ACCEPTED", "status": "PASS" if rejected else "FAIL"})
    negative_failed = [row for row in tests if row["status"] == "FAIL"]
    write("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_NEGATIVE_TEST_RESULT", "schema_version": "1.0",
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0002", "status": "PASS" if not negative_failed else "FAIL_CLOSED",
        "tests": tests, "tests_total": len(tests), "tests_passed": len(tests)-len(negative_failed), "tests_failed": len(negative_failed),
        "worker_invoked": False, "codex_invoked": False, "network_used": False,
    })
    print(json.dumps({"primary": f"{len(checks)-len(failed)}/{len(checks)}", "negative": f"{len(tests)-len(negative_failed)}/{len(tests)}", "status": "PASS" if not negative_failed else "FAIL_CLOSED"}, sort_keys=True))
    if negative_failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
