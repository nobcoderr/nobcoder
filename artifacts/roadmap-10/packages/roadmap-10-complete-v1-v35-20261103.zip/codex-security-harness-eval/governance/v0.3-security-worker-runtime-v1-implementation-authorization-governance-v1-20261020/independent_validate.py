#!/usr/bin/env python3
"""Independent validation for SecurityWorkerRuntime V1 authorization."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
FUTURE = Path("/home/nobcoder/v0.3-security-worker-runtime-v1-20261020")
IDENTITY = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_MINIMAL_CONTRACT_AND_IMPLEMENTATION"
BINDINGS = {
    "v0_3_a_contract": ("/home/nobcoder/codex-security-harness-eval/governance/v0.3-a-research-campaign-contract-v1-governance-only-20261015", "8397fa6715de10975b80d0c9237f40ae472da91f22fc9e631e5d998ce0f8bb2e", "9ca59ce4599f2bde01b45ba80fc8ed341e42a0808fe23cf9cad6c3fbbb4e3beb"),
    "control_plane_v2": ("/home/nobcoder/codex-security-harness-eval/governance/v0.3-a-minimal-serial-campaign-control-plane-v2-freeze-acceptance-and-final-pass-locked-decision-governance-v2-20261015", "54e61cc5186ee5620a9d5116e4fa2650affef6e7919ca594ecd3921ff9671e2f", "26f4b18b6b6060de1ce20d8c6162e0307ad363f23848e55958cfffeedaae3c9f"),
    "runtime_substrate_v5": ("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v5-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261017", "8383ec457c0838fba668693ae9c837edf1a8c50222c524176dc60b9afda9191e", "4eb6624c1ff98d36f358caa62181c7fa5a0c654335dc583753cd0946e1490e1c"),
    "compatibility_contract_v2": ("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-contract-v2-20261017", "f083b7bc2756d9052c8c66bc6fb8ed3f3b42aacf54ac1b914d3e2e1270b3a363", "6234ab0c6e31c81551394bce8a110a9145656cec6d10bb3c0aca660a331e2e31"),
    "codex_0_163_0_compatibility": ("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v7-frozen-evidence-acceptance-and-codex-0-163-0-pass-locked-decision-governance-v1-20261020", "3aedf0a656fd12680311f07fcf01e911e7a6a62f0b81871af347a55bc1ba7fef", "916f32ae710ee9a1721a151b4a1d0d16a05b268c2ef1ff2985e4235f4a64d1ae"),
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write(payload: dict[str, Any]) -> None:
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(name: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": name, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    check("I001_FUTURE_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    for name, (path_text, lock_sha, manifest_sha) in BINDINGS.items():
        path = Path(path_text)
        check(f"I_BIND_{name}_LOCK", sha(path / "GOVERNANCE_LOCK.json") == lock_sha)
        check(f"I_BIND_{name}_MANIFEST", sha(path / "GOVERNANCE_ARTIFACT_MANIFEST.json") == manifest_sha)
    codex_lock = read(Path(BINDINGS["codex_0_163_0_compatibility"][0]) / "GOVERNANCE_LOCK.json")
    check("I012_CODEX_PASS_LOCKED", codex_lock.get("codex_runtime_0_163_0") == "COMPATIBILITY_PASS_LOCKED")
    check("I013_PREDECESSOR_WORKER_CLOSED", codex_lock.get("worker_execution_authorized") is False and codex_lock.get("additional_codex_invocation_authorized") is False)
    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative_historical = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    check("I014_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I015_NEGATIVE_HISTORY", negative_historical.get("status") == "FAIL_CLOSED" and negative_historical.get("tests_passed") == 29 and negative_historical.get("tests_total") == 30)
    check("I016_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == 30 and negative.get("tests_failed") == 0)
    decision = read(ROOT / "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION.json")
    topology = read(ROOT / "MINIMAL_TOPOLOGY_CONTRACT.json")
    bindings = read(ROOT / "WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json")
    io = read(ROOT / "STRUCTURED_IO_AND_STATE_REQUIREMENTS.json")
    isolation = read(ROOT / "WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json")
    evidence = read(ROOT / "EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json")
    worker = read(ROOT / "WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json")
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    capability = read(ROOT / "CAPABILITY_SUPPORT_AND_AUTHORITY_MATRIX.json")
    check("I016_DECISION", decision.get("decision") == DECISION and decision.get("state") == "IMPLEMENTATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I017_NO_INVOCATION_AUTH", decision.get("worker_invocation_authorized") is False and decision.get("codex_worker_invocation_authorized") is False)
    check("I018_TOPOLOGY_ONE_ONE_ONE", (topology.get("maximum_campaigns"), topology.get("maximum_lanes_per_campaign"), topology.get("maximum_worker_identities")) == (1, 1, 1))
    check("I019_NO_ACTIVE_WORKER", topology.get("maximum_active_workers") == 0)
    check("I020_SERIAL_FIXTURE", topology.get("scheduling") == "SERIAL_ONLY" and topology.get("workspace") == "CONTROLLED_LOCAL_OR_FIXTURE_ONLY")
    check("I021_EXACT_RUNTIME", topology.get("runtime_identity") == "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED" and bindings.get("runtime_binding", {}).get("version") == "0.163.0")
    check("I022_BINDINGS_REQUIRED", all(item in bindings.get("required_first_class_objects", []) for item in ["WorkerIdentity", "CampaignBinding", "LaneBinding", "RuntimeIdentity", "AuthorizationBinding"]))
    check("I023_STRUCTURED_IO", io.get("structured_worker_input_required") is True and io.get("structured_worker_output_required") is True and io.get("free_form_prose_authoritative") is False)
    check("I024_QUARANTINE", io.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED" and worker.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED")
    check("I025_PROPOSAL_ONLY", worker.get("worker_role") == "PROPOSAL_ONLY")
    check("I026_NO_SELF_AUTH_PROMOTION", worker.get("worker_self_authorization") == "PERMANENTLY_PROHIBITED" and worker.get("worker_self_promotion") == "PERMANENTLY_PROHIBITED")
    check("I027_ISOLATION", isolation.get("workspace_isolation_required") is True and isolation.get("network_default") == "DENY_ALL" and isolation.get("credential_default") == "DENY_ALL")
    check("I028_RESOURCE_SEMANTICS", isolation.get("resource_budget_required") is True and isolation.get("unbounded_budget_allowed") is False and bool(isolation.get("timeout_semantics")) and bool(isolation.get("cancellation_semantics")))
    check("I029_EVIDENCE_BINDING", all(evidence.get(key) is True for key in ["digest_required", "producer_binding_required", "campaign_binding_required", "lane_binding_required", "worker_binding_required", "runtime_binding_required", "authorization_binding_required"]))
    check("I030_APPEND_ONLY", evidence.get("append_only_invocation_ledger_required") is True and evidence.get("worker_may_mutate_evidence_history") is False)
    escalations = {key: value for key, value in authority.items() if key.endswith("_authorized") and key != "implementation_authorized" and value is not False}
    check("I031_IMPLEMENTATION_ONLY", authority.get("implementation_authorized") is True and not escalations, escalations)
    check("I032_COUNTERS_ZERO", len(authority.get("operation_counters", {})) == 12 and all(value == 0 for value in authority.get("operation_counters", {}).values()))
    check("I033_CAPABILITIES_DEFERRED", len(capability.get("rows", [])) == 12 and all(row.get("authority_state") == "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION" for row in capability.get("rows", [])))
    check("I034_SEPARATION_RULE", authority.get("normative_rule") == "IMPLEMENTATION_AUTHORIZED_NE_WORKER_INVOCATION_AUTHORIZED_NE_TARGET_ACCESS_AUTHORIZED")
    failed = [row for row in checks if row["status"] == "FAIL"]
    write({
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_INDEPENDENT_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "INDEPENDENT_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed),
        "worker_invoked": False, "codex_invoked": False, "network_used": False,
    })
    print(json.dumps({"status": "PASS" if not failed else "FAIL_CLOSED", "passed": len(checks)-len(failed), "total": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
