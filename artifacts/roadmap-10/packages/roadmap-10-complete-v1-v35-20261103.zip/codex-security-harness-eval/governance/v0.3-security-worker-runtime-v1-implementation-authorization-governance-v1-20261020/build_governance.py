#!/usr/bin/env python3
"""Build SecurityWorkerRuntime V1 implementation authorization; execute nothing."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
FUTURE = Path("/home/nobcoder/v0.3-security-worker-runtime-v1-20261020")
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")

IDENTITY = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_V0_3_SECURITY_WORKER_RUNTIME_V1_MINIMAL_CONTRACT_AND_IMPLEMENTATION"
FUTURE_IDENTITY = "V0_3_SECURITY_WORKER_RUNTIME_V1"
CODEX_RUNTIME = "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED"
NEXT = "IMPLEMENT_STATICALLY_VALIDATE_AND_FREEZE_V0_3_SECURITY_WORKER_RUNTIME_V1_NO_WORKER_INVOCATION"

BINDINGS = {
    "v0_3_a_contract": {
        "path": "/home/nobcoder/codex-security-harness-eval/governance/v0.3-a-research-campaign-contract-v1-governance-only-20261015",
        "lock_sha256": "8397fa6715de10975b80d0c9237f40ae472da91f22fc9e631e5d998ce0f8bb2e",
        "manifest_sha256": "9ca59ce4599f2bde01b45ba80fc8ed341e42a0808fe23cf9cad6c3fbbb4e3beb",
        "root": "5521f4afa2f273164f750a5da37e25ec80382949ee1d280c7c97297198a61f9d",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
    },
    "control_plane_v2": {
        "path": "/home/nobcoder/codex-security-harness-eval/governance/v0.3-a-minimal-serial-campaign-control-plane-v2-freeze-acceptance-and-final-pass-locked-decision-governance-v2-20261015",
        "lock_sha256": "54e61cc5186ee5620a9d5116e4fa2650affef6e7919ca594ecd3921ff9671e2f",
        "manifest_sha256": "26f4b18b6b6060de1ce20d8c6162e0307ad363f23848e55958cfffeedaae3c9f",
        "root": "024d6a2cdf44ed23572c48720ada1428cc71f785cfd42ef2b3050ec9b28591a9",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": "ISSUE_CONTROL_PLANE_V2_PASS_LOCKED",
    },
    "runtime_substrate_v5": {
        "path": "/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v5-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261017",
        "lock_sha256": "8383ec457c0838fba668693ae9c837edf1a8c50222c524176dc60b9afda9191e",
        "manifest_sha256": "4eb6624c1ff98d36f358caa62181c7fa5a0c654335dc583753cd0946e1490e1c",
        "root": "19586d5dc41bd7068fe191db62d8f3b0b4b4007eacb437257728c0356bf62f99",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": "A_ACCEPT_AND_PROMOTE_RUNTIME_SUBSTRATE_V5_TO_PASS_LOCKED",
    },
    "compatibility_contract_v2": {
        "path": "/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-contract-v2-20261017",
        "lock_sha256": "f083b7bc2756d9052c8c66bc6fb8ed3f3b42aacf54ac1b914d3e2e1270b3a363",
        "manifest_sha256": "6234ab0c6e31c81551394bce8a110a9145656cec6d10bb3c0aca660a331e2e31",
        "root": "e4cbefd952cac927b8c63e5d9f601b953caefbccabc9412a43ebabc793ecc95d",
        "status": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
        "decision": "ESTABLISH_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_CONTRACT_V2_PASS_LOCKED",
    },
    "codex_0_163_0_compatibility": {
        "path": "/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v7-frozen-evidence-acceptance-and-codex-0-163-0-pass-locked-decision-governance-v1-20261020",
        "lock_sha256": "3aedf0a656fd12680311f07fcf01e911e7a6a62f0b81871af347a55bc1ba7fef",
        "manifest_sha256": "916f32ae710ee9a1721a151b4a1d0d16a05b268c2ef1ff2985e4235f4a64d1ae",
        "root": "5885e0fab599d69f390d0705c215946b230dfdfb908111012d4da0e74da0e708",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": "A_ACCEPT_AND_PROMOTE_CODEX_0_163_0_COMPATIBILITY_TO_PASS_LOCKED",
    },
}

OPERATION_KEYS = [
    "worker_invocations", "codex_worker_invocations", "subagent_invocations",
    "credential_operations", "target_operations", "external_network_operations",
    "daybreak_invocations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
]
ZERO_COUNTERS = {key: 0 for key in OPERATION_KEYS}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_binding(name: str, binding: dict[str, Any]) -> dict[str, Any]:
    path = Path(binding["path"])
    if sha(path / "GOVERNANCE_LOCK.json") != binding["lock_sha256"]:
        raise SystemExit(f"{name} lock drift")
    if sha(path / "GOVERNANCE_ARTIFACT_MANIFEST.json") != binding["manifest_sha256"]:
        raise SystemExit(f"{name} manifest drift")
    lock = read(path / "GOVERNANCE_LOCK.json")
    if lock.get("status") != binding["status"] or lock.get("canonical_artifact_root_sha256") != binding["root"]:
        raise SystemExit(f"{name} status/root mismatch")
    if binding.get("decision") and lock.get("decision") != binding["decision"]:
        raise SystemExit(f"{name} decision mismatch")
    return lock


def main() -> None:
    expected_sources = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected_sources or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected initial package set: {sorted(actual)}")
    if FUTURE.exists() or FUTURE.is_symlink():
        raise SystemExit("SecurityWorkerRuntime V1 must not exist in authorization milestone")
    if sha(ROUTER_MAP) != "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250":
        raise SystemExit("router map drift")
    verified = {name: verify_binding(name, binding) for name, binding in BINDINGS.items()}
    codex_lock = verified["codex_0_163_0_compatibility"]
    if codex_lock.get("codex_runtime_0_163_0") != "COMPATIBILITY_PASS_LOCKED" or codex_lock.get("worker_execution_authorized") is not False:
        raise SystemExit("Codex compatibility predecessor does not preserve worker boundary")

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_ROUTING_AND_SCOPE_DECISION", "schema_version": "1.0",
        "scope": "GOVERNANCE_ONLY_AUTHORIZATION_OF_MINIMAL_CONTRACT_AND_NON_EXECUTING_IMPLEMENTATION",
        "authorized_actions": ["READ_LOCKED_PREDECESSORS", "DEFINE_MINIMAL_WORKER_RUNTIME_AUTHORITY_CEILING", "ISSUE_IMPLEMENTATION_AUTHORIZATION", "RUN_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE"],
        "forbidden_actions": ["CREATE_SECURITY_WORKER_RUNTIME_V1_THIS_MILESTONE", "INVOKE_CODEX_AS_WORKER", "INVOKE_WORKER_OR_SUBAGENT", "USE_CREDENTIALS", "ACCESS_TARGET_OR_NETWORK", "INVOKE_DAYBREAK", "REPLAY_EXPLOIT", "ENABLE_PARALLELISM", "CREATE_CAPABILITY_EDGE", "PROMOTE_CANDIDATE", "SUBMIT_REPORT"],
        "worker_or_runtime_invocation_authority": False,
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_ROUTING_LEDGER", "schema_version": "1.0",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "agentic-security-research-harness", "external-ai-security-tool-governor", "codex-security-harness"],
        "deferred": ["worker execution", "subagent execution", "credential broker", "target access gateway", "Daybreak", "exploit replay", "parallelism", "capability graph", "candidate promotion", "submission automation"],
        "not_applicable": ["live vulnerability discovery", "target recon", "program prior-art screening", "exploit validation"],
        "installed_skill_count_evaluated": 74, "unmapped_installed_skill_count": 0,
        "subagents_used": False, "codex_invoked": False, "worker_invoked": False, "network_used": False,
        "router_map_sha256": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
    })
    write("PREDECESSOR_LOCK_BINDINGS.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_PREDECESSOR_LOCK_BINDINGS", "schema_version": "1.0",
        "bindings": BINDINGS, "binding_count": len(BINDINGS), "all_bindings_verified": True,
        "codex_runtime_state": CODEX_RUNTIME, "worker_execution_state": "NOT_AUTHORIZED",
    })
    write("SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": DECISION, "future_identity": FUTURE_IDENTITY, "future_path": str(FUTURE),
        "state": "IMPLEMENTATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "authorized_implementation_actions": ["CREATE_CONTRACT_AND_SCHEMAS", "CREATE_NON_EXECUTING_SOURCE", "CREATE_CODEX_CLI_ADAPTER_SOURCE", "CREATE_PURE_IN_PROCESS_FIXTURE_TESTS", "PRIMARY_STATIC_VALIDATION", "INDEPENDENT_STATIC_VALIDATION", "STATIC_FREEZE_AND_LOCK"],
        "worker_invocation_authorized": False, "codex_worker_invocation_authorized": False,
        "implementation_authorized_does_not_imply_worker_execution": True,
        "implementation_authorized_does_not_imply_target_access": True,
    })
    write("MINIMAL_TOPOLOGY_CONTRACT.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_MINIMAL_TOPOLOGY_CONTRACT", "schema_version": "1.0",
        "maximum_campaigns": 1, "maximum_lanes_per_campaign": 1, "maximum_worker_identities": 1,
        "maximum_active_workers": 0, "runtime_identity": CODEX_RUNTIME, "scheduling": "SERIAL_ONLY",
        "workspace": "CONTROLLED_LOCAL_OR_FIXTURE_ONLY", "target_bound": False, "network_bound": False,
        "campaign_activation": "NOT_AUTHORIZED", "worker_process_activation": "NOT_AUTHORIZED",
    })
    write("WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_WORKER_IDENTITY_AND_BINDINGS_REQUIREMENTS", "schema_version": "1.0",
        "required_first_class_objects": ["WorkerIdentity", "CampaignBinding", "LaneBinding", "RuntimeIdentity", "AuthorizationBinding"],
        "worker_identity": {"count": 1, "immutable": True, "proposal_only": True, "may_delegate": False},
        "campaign_binding": {"required": True, "exactly_one": True, "automatic_target_switch": False},
        "lane_binding": {"required": True, "exactly_one": True, "falsifiable_question_required": True},
        "runtime_binding": {"required": True, "identity": CODEX_RUNTIME, "version": "0.163.0", "compatibility_state": "PASS_LOCKED", "adapter": "CodexCliAdapter", "invocation_authority": "ABSENT"},
        "authorization_binding": {"required": True, "implementation_authority_only": True, "per_invocation_authority_required_later": True},
    })
    write("STRUCTURED_IO_AND_STATE_REQUIREMENTS.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_STRUCTURED_IO_AND_STATE_REQUIREMENTS", "schema_version": "1.0",
        "structured_worker_input_required": True, "structured_worker_output_required": True,
        "free_form_prose_authoritative": False, "unknown_fields_fail_closed": True,
        "required_input_fields": ["campaign_id", "lane_id", "worker_id", "runtime_identity", "authorization_id", "workspace_id", "objective", "scope", "budget", "termination_conditions", "required_output_schema"],
        "required_output_fields": ["status", "worker_id", "runtime_identity", "proposals", "evidence_refs", "commands_requested", "files_changed", "budget_used", "termination_reason", "unresolved_questions"],
        "candidate_initial_state": "HYPOTHESIS_QUARANTINED", "worker_can_set_validated_or_strong": False,
        "state_updates": "CONTROLLER_VALIDATED_APPEND_ONLY_EVENTS_ONLY",
    })
    write("WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_WORKSPACE_ISOLATION_AND_RESOURCE_SEMANTICS", "schema_version": "1.0",
        "workspace_isolation_required": True, "workspace_kind": "CONTROLLED_LOCAL_FIXTURE", "host_control_plane_write": "DENIED",
        "evidence_store_write": "BROKERED_APPEND_ONLY_ONLY", "network_default": "DENY_ALL", "credential_default": "DENY_ALL",
        "resource_budget_required": True, "budget_dimensions": ["wall_time", "model_tokens", "processes", "cpu", "memory", "disk", "output_bytes"],
        "unbounded_budget_allowed": False, "timeout_semantics": "TERMINATE_PROCESS_TREE_RECORD_TIMEOUT_NO_AUTOMATIC_RETRY",
        "cancellation_semantics": "HOST_CONTROLLED_IDEMPOTENT_APPEND_ONLY_EVENT_AND_PROCESS_TREE_TERMINATION",
        "revocation_recheck": "REQUIRED_BEFORE_ANY_FUTURE_INVOCATION", "unsandboxed_fallback": "PROHIBITED",
    })
    write("EVIDENCE_AND_PROVENANCE_REQUIREMENTS.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_EVIDENCE_AND_PROVENANCE_REQUIREMENTS", "schema_version": "1.0",
        "evidence_ref_required": True, "digest_required": True, "producer_binding_required": True,
        "campaign_binding_required": True, "lane_binding_required": True, "worker_binding_required": True,
        "runtime_binding_required": True, "authorization_binding_required": True, "repository_revision_binding_required": True,
        "workspace_binding_required": True, "timestamps_required": True, "append_only_invocation_ledger_required": True,
        "stdout_stderr_or_structured_equivalent_required": True, "exit_timeout_cancel_state_required": True,
        "missing_or_mismatched_provenance": "FAIL_CLOSED", "worker_may_mutate_evidence_history": False,
    })
    write("WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_WORKER_AUTHORITY_AND_CANDIDATE_STATE_POLICY", "schema_version": "1.0",
        "worker_role": "PROPOSAL_ONLY", "candidate_initial_state": "HYPOTHESIS_QUARANTINED",
        "worker_self_authorization": "PERMANENTLY_PROHIBITED", "worker_self_promotion": "PERMANENTLY_PROHIBITED",
        "worker_severity_lock": "PROHIBITED", "worker_report_ready_decision": "PROHIBITED",
        "promotion_authority": "DEFERRED_SEPARATE_CONTROLLER_VALIDATOR_HUMAN_GATE_CONTRACT",
        "human_gate_before_future_activation": True, "human_gate_before_final_acceptance": True,
    })
    deferred = ["WORKER_INVOCATION", "CODEX_WORKER_INVOCATION", "SUBAGENT_INVOCATION", "CREDENTIAL_INJECTION", "TARGET_ACCESS", "EXTERNAL_NETWORK", "DAYBREAK_INVOCATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION"]
    write("CAPABILITY_SUPPORT_AND_AUTHORITY_MATRIX.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_CAPABILITY_SUPPORT_AND_AUTHORITY_MATRIX", "schema_version": "1.0",
        "rows": [{"capability": name, "support_state": "SUPPORTED_BY_ARCHITECTURE", "authority_state": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION"} for name in deferred],
        "permanent_prohibitions": ["WORKER_SELF_AUTHORIZATION", "WORKER_SELF_PROMOTION", "RAW_SECRET_IN_PROMPT_REPOSITORY_OR_EVIDENCE", "UNSANDBOXED_FALLBACK", "GENERIC_UNRESTRICTED_COMMAND_ENDPOINT", "OUT_OF_SCOPE_THIRD_PARTY_TARGETING", "GOVERNANCE_BYPASS"],
        "supported_does_not_imply_authorized": True,
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "currently_authorized": ["CONTRACT_AND_SOURCE_PUBLICATION", "PURE_IN_PROCESS_FIXTURE_UNIT_TESTS", "PRIMARY_AND_INDEPENDENT_STATIC_VALIDATION", "STATIC_FREEZE"],
        "currently_unauthorized": deferred,
        "operation_counters": ZERO_COUNTERS, "deny_by_default": True,
    })
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "implementation_authorized": True, "worker_execution_authorized": False, "codex_worker_invocation_authorized": False,
        "subagent_execution_authorized": False, "credential_injection_authorized": False, "target_access_authorized": False,
        "external_network_authorized": False, "daybreak_invocation_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False, "candidate_promotion_authorized": False,
        "submission_automation_authorized": False, "operation_counters": ZERO_COUNTERS,
        "normative_rule": "IMPLEMENTATION_AUTHORIZED_NE_WORKER_INVOCATION_AUTHORIZED_NE_TARGET_ACCESS_AUTHORIZED",
    })
    cases = [
        "PREDECESSOR_LOCK_MISMATCH", "CODEX_COMPATIBILITY_NOT_PASS_LOCKED", "CAMPAIGN_COUNT_GT_ONE",
        "LANE_COUNT_GT_ONE", "WORKER_IDENTITY_COUNT_GT_ONE", "ACTIVE_WORKER_NONZERO", "NON_SERIAL_SCHEDULING",
        "RUNTIME_IDENTITY_DRIFT", "UNCONTROLLED_WORKSPACE", "UNSTRUCTURED_INPUT", "UNSTRUCTURED_OUTPUT",
        "FREE_FORM_PROSE_AUTHORITATIVE", "CANDIDATE_INITIAL_STATE_NOT_QUARANTINED", "WORKER_SELF_AUTHORIZATION",
        "WORKER_SELF_PROMOTION", "MISSING_CAMPAIGN_BINDING", "MISSING_LANE_BINDING", "MISSING_RUNTIME_BINDING",
        "MISSING_AUTHORIZATION_BINDING", "MISSING_EVIDENCE_DIGEST", "WORKER_CAN_MUTATE_EVIDENCE_HISTORY",
        "UNBOUNDED_BUDGET", "MISSING_TIMEOUT_SEMANTICS", "MISSING_CANCELLATION_SEMANTICS",
        "CREDENTIAL_AUTHORITY_LEAK", "TARGET_OR_NETWORK_AUTHORITY_LEAK", "DAYBREAK_OR_EXPLOIT_AUTHORITY_LEAK",
        "SUBAGENT_OR_PARALLEL_AUTHORITY_LEAK", "CAPABILITY_PROMOTION_OR_SUBMISSION_AUTHORITY_LEAK",
        "IMPLEMENTATION_IMPLIES_WORKER_INVOCATION",
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0",
        "tests": [{"test_id": f"N{index:03d}", "mutation": case, "expected": "REJECT_OR_HOLD_FAIL_CLOSED"} for index, case in enumerate(cases, 1)],
        "test_count": len(cases),
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "decision": DECISION, "future_identity": FUTURE_IDENTITY, "state": "IMPLEMENTATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "topology": "1_CAMPAIGN_1_LANE_1_WORKER_IDENTITY_CODEX_0_163_0_SERIAL_CONTROLLED_LOCAL_FIXTURE",
        "worker_execution": "NOT_AUTHORIZED", "codex_worker_invocation": "NOT_AUTHORIZED", "authority_expansion": "IMPLEMENTATION_ONLY",
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "SECURITY_WORKER_RUNTIME_V1_AUTHORIZATION_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_legal_milestone": NEXT, "worker_invocation_during_next_milestone": "PROHIBITED",
        "required_terminal_state": "SOURCE_AND_CONTRACT_STATICALLY_VALIDATED_AND_FROZEN_AWAITING_SEPARATE_EXECUTION_AUTHORIZATION",
    })


if __name__ == "__main__":
    main()
