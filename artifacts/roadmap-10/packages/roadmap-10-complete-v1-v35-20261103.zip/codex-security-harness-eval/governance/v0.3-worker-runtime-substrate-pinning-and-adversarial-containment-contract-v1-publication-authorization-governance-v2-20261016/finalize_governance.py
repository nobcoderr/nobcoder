#!/usr/bin/env python3
"""Finalize and freeze effective successor V2 authorization."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
FUTURE = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016")
IDENTITY = "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1_PUBLICATION_AUTHORIZATION_GOVERNANCE_V2"
FALSE_FIELDS = ("contract_execution_authorized", "runtime_validation_authorized", "containment_fixture_execution_authorized", "worker_or_subagent_execution_authorized", "codex_cli_invocation_authorized", "target_or_network_authorized", "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized", "submission_automation_authorized", "v0_3_b0_authorized")
PREFINAL = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_CHAIN_BINDING.json", "FAILED_GOVERNANCE_V1_DISPOSITION.json",
    "FREEZE_VERIFIER_FIELD_MISMATCH_ROOT_CAUSE.json", "TYPED_AUTHORITY_FIELD_SCHEMA.json",
    "CONTRACT_PUBLICATION_AUTHORIZATION_DECISION.json", "CONTRACT_IDENTITY_AND_PATH_BINDING.json",
    "CONTRACT_PUBLICATION_SCOPE.json", "RUNTIME_SUBSTRATE_PINNING_SCOPE.json", "ADVERSARIAL_CONTAINMENT_SCOPE.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "GOVERNANCE_TEST_RESULT.json", "INDEPENDENT_VALIDATION_RESULT.json",
}
FINAL = {"CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json", "NEXT_LEGAL_MILESTONE.json"}


def sha(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise TypeError(path)
    return value
def write_once(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True); handle.write("\n")
def rows_root(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{x['sha256']}  {x['path']}\n" for x in sorted(rows, key=lambda y: y["path"])).encode()).hexdigest()
def zeros() -> dict[str, int]:
    return {key: 0 for key in ("contract_publications", "worker_processes", "subagents", "codex_invocations", "target_operations", "network_operations", "parallel_operations", "capability_edges", "candidate_promotions", "submissions")}


def main() -> None:
    actual = {p.name for p in ROOT.iterdir() if p.is_file()}
    if actual != PREFINAL: raise RuntimeError(f"unexpected pre-final set: extra={sorted(actual-PREFINAL)} missing={sorted(PREFINAL-actual)}")
    primary = load(ROOT / "GOVERNANCE_TEST_RESULT.json"); negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json"); independent = load(ROOT / "INDEPENDENT_VALIDATION_RESULT.json")
    if any(x.get("status") != "PASS" for x in (primary, negative, independent)): raise RuntimeError("mandatory validation failed")
    if FUTURE.exists() or FUTURE.is_symlink(): raise RuntimeError("future contract collision")
    authorization = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_PUBLICATION_AUTHORIZATION_LOCK_V2", "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": "AUTHORIZE_CONTRACT_PUBLICATION_ONLY",
        "authorized_milestone": "ESTABLISH_V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1",
        "future_contract_identity": "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1",
        "future_contract_path": str(FUTURE), "future_contract_state": "AUTHORIZED_NOT_CREATED",
        "publication_ceiling": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY", "contract_publication_authorized": True,
        **{field: False for field in FALSE_FIELDS}, "operations_this_milestone": zeros(),
    }
    next_legal = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_NEXT_LEGAL_MILESTONE", "schema_version": "1.0", "governance_identity": IDENTITY,
        "milestone": authorization["authorized_milestone"], "status": "AUTHORIZED_CONTRACT_PUBLICATION_ONLY_NOT_STARTED",
        "exact_identity": authorization["future_contract_identity"], "exact_path": str(FUTURE),
        "allowed_end_state": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY_OR_FAIL_CLOSED",
        "next_after_contract": "SEPARATE_RUNTIME_SUBSTRATE_VALIDATION_AUTHORIZATION_GOVERNANCE_REQUIRED", "execution_authority": "NONE",
    }
    write_once("CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json", authorization); write_once("NEXT_LEGAL_MILESTONE.json", next_legal)
    members = PREFINAL | FINAL
    entries = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in sorted(members)]
    member_root = rows_root(entries)
    manifest = {"record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0", "governance_identity": IDENTITY, "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE", "member_count": len(entries), "members": entries, "canonical_member_root_sha256": member_root, "self_referential_hashes": False}
    write_once("GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    artifact_root = rows_root(entries + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    lock = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_GOVERNANCE_LOCK", "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": "AUTHORIZE_CONTRACT_PUBLICATION_ONLY",
        "failed_governance_v1": "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY",
        "authorized_milestone": authorization["authorized_milestone"], "future_contract_state": "AUTHORIZED_NOT_CREATED",
        "governance_manifest_sha256": manifest_sha, "canonical_member_root_sha256": member_root,
        "canonical_artifact_root_sha256": artifact_root, "root_member_count": len(entries)+1,
        "structural_counts": {"manifest_members": len(entries), "root_members": len(entries)+1},
        "validation_counts": {"governance": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]}, "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]}, "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]}},
        "contract_publication_authorized": True, **{field: False for field in FALSE_FIELDS}, "operations_this_milestone": zeros(),
    }
    write_once("GOVERNANCE_LOCK.json", lock)
    for p in ROOT.iterdir():
        if p.is_file(): os.chmod(p, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": lock["status"], "decision": lock["decision"], "members": len(entries), "manifest_sha256": manifest_sha, "canonical_artifact_root": artifact_root}, sort_keys=True))


if __name__ == "__main__": main()
