#!/usr/bin/env python3
"""Build successor V2 publication authorization after the V1 freeze defect."""

from __future__ import annotations

import copy
import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance"
FAILED = GOV / "v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-publication-authorization-governance-v1-20261016"
RUNNER = GOV / "v0.3-a-fixture-only-serial-campaign-execution-v2-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261016"
FUTURE = GOV / "v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016"
IDENTITY = "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1_PUBLICATION_AUTHORIZATION_GOVERNANCE_V2"
FUTURE_IDENTITY = "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1"
MILESTONE = "ESTABLISH_V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1"

ANCHORS = {
    "failed_lock": "d0cc3ab48ce818d861c1779015de34daed15e7e4110ddd3e2026f0104d8db410",
    "failed_manifest": "db2f270e13837d8c98378a35ad777ec999b9fd02e7bf37faffe6164509711417",
    "failed_root": "80a5436a198e9608d14a01097c9bae53b926bfb14ac6b1f1133effa71727ddc8",
    "failed_verifier": "6bdcec61ef06a0982bd0e44c2a5b251bdb6c3a962727f8119c6ad89e33482dc0",
    "failed_authority": "6a2d25b3efe20c1a02b94e4ad89e3b83e07c26cbcff52a12d7754b9f8fd26515",
    "failed_auth_lock": "35aa70bcf78ded31f594b55140b77785a9691756985c7c2d6e747aa1f0d6afb9",
    "scope": "284f7a0b92f91018f754e60df67be24a48394ac0d2d23bf598f1af8388c8766d",
    "pinning": "e69b2796552747d9c3ddc8c5671bc3a2b92d4c1de1f1c7f7d28a402b28950b6e",
    "containment": "74762b2673dc257a61db78da39ba6f138586c643582da93c46234310e1855838",
    "runner_lock": "14ebdff93e45f275f14b1c6be6594bdbbf7d69921edb56e89329337e16bd2da4",
    "runner_pass": "661650e8ddeda343725dbb7cf3bc8728c12d14147e935a58392f8edfb1b599d7",
}

CANONICAL_AUTHORITY_FIELDS = (
    "contract_execution_authorized", "runtime_validation_authorized",
    "containment_fixture_execution_authorized", "worker_or_subagent_execution_authorized",
    "codex_cli_invocation_authorized", "target_or_network_authorized",
    "parallelism_authorized", "capability_graph_authorized",
    "candidate_promotion_authorized", "submission_automation_authorized",
    "v0_3_b0_authorized",
)
REQUIRED_SECTIONS = (
    "THREAT_MODEL_AND_TRUST_BOUNDARIES",
    "PINNED_KERNEL_AND_HOST_RUNTIME_IDENTITY",
    "PINNED_BUBBLEWRAP_TRACE_AND_LANGUAGE_RUNTIME_DEPENDENCIES",
    "NAMESPACE_CAPABILITY_SECCOMP_LSM_AND_NO_NEW_PRIVS_POLICY",
    "FILESYSTEM_TOPOLOGY_AND_WRITABLE_SCOPE_POLICY",
    "NETWORK_IPC_AND_HOST_INTERFACE_DENY_POLICY",
    "HOST_INTERFACE_INVENTORY_AND_CLASSIFICATION",
    "SECRET_CREDENTIAL_AND_CONTROL_PLANE_AUTHORITY_POLICY",
    "PROCESS_LINEAGE_EXECUTABLE_AND_CHILD_ALLOWLIST_POLICY",
    "EXACT_ENVIRONMENT_AND_WORKING_DIRECTORY_POLICY",
    "OUT_OF_WORKER_MONITORING_EVIDENCE_AND_PROVENANCE_POLICY",
    "KILL_REVOCATION_TIMEOUT_AND_RESOURCE_LIMIT_POLICY",
    "FAIL_CLOSED_TOPOLOGY_TRACE_AND_EVIDENCE_COMPLETENESS_POLICY",
    "RUNTIME_UPDATE_SUCCESSOR_AND_COMPATIBILITY_POLICY",
    "SAFE_CONTAINMENT_FIXTURE_REQUIREMENTS_ONLY",
    "INDEPENDENT_VALIDATION_AND_HUMAN_GATE_REQUIREMENTS",
    "AUTHORITY_MATRIX_AND_FUTURE_STAGE_BOUNDARIES",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def write_once(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda x: x["path"])).encode()
    return hashlib.sha256(raw).hexdigest()


def verify_current_governance(root: Path, expected_root: str) -> bool:
    manifest_path = root / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest = load(manifest_path)
    lock = load(root / "GOVERNANCE_LOCK.json")
    members = manifest.get("members", [])
    for item in members:
        path = root / str(item.get("path", ""))
        if not path.is_file() or path.is_symlink() or not ro(path):
            return False
        if path.stat().st_size != item.get("bytes") or sha(path) != item.get("sha256"):
            return False
    manifest_sha = sha(manifest_path)
    return (
        rows_root(members) == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256")
        and manifest_sha == lock.get("governance_manifest_sha256")
        and rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}]) == expected_root == lock.get("canonical_artifact_root_sha256")
    )


def zero_operations() -> dict[str, int]:
    return {key: 0 for key in ("contract_publications", "worker_processes", "subagents", "codex_invocations", "target_operations", "network_operations", "parallel_operations", "capability_edges", "candidate_promotions", "submissions")}


def valid_authorization(value: dict[str, Any]) -> bool:
    return (
        value.get("failed_v1_terminal") is True
        and value.get("runner_predecessor_pass") is True
        and value.get("future_path_absent") is True
        and value.get("decision") == "AUTHORIZE_CONTRACT_PUBLICATION_ONLY"
        and value.get("future_identity") == FUTURE_IDENTITY
        and value.get("future_path") == str(FUTURE)
        and tuple(value.get("required_sections", [])) == REQUIRED_SECTIONS
        and value.get("contract_publication_authorized") is True
        and all(value.get(field) is False for field in CANONICAL_AUTHORITY_FIELDS)
        and value.get("default_policy") == "DENY"
        and value.get("worker_secret_authority") == "FORBIDDEN"
        and value.get("worker_control_plane_authority") == "FORBIDDEN"
        and value.get("incomplete_evidence") == "FAIL_CLOSED"
        and value.get("operations_this_milestone") == zero_operations()
        and set(value) == {
            "failed_v1_terminal", "runner_predecessor_pass", "future_path_absent", "decision",
            "future_identity", "future_path", "required_sections", "contract_publication_authorized",
            *CANONICAL_AUTHORITY_FIELDS, "default_policy", "worker_secret_authority",
            "worker_control_plane_authority", "incomplete_evidence", "operations_this_milestone",
        }
    )


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    check("G001_FAILED_LOCK_SHA", sha(FAILED / "GOVERNANCE_LOCK.json") == ANCHORS["failed_lock"])
    check("G002_FAILED_MANIFEST_SHA", sha(FAILED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == ANCHORS["failed_manifest"])
    check("G003_FAILED_ROOT", verify_current_governance(FAILED, ANCHORS["failed_root"]))
    check("G004_FAILED_VERIFIER_SHA", sha(FAILED / "freeze_verify.py") == ANCHORS["failed_verifier"])
    check("G005_FAILED_AUTHORITY_SHA", sha(FAILED / "AUTHORITY_NON_ESCALATION_DECISION.json") == ANCHORS["failed_authority"])
    check("G006_FAILED_AUTH_LOCK_SHA", sha(FAILED / "CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json") == ANCHORS["failed_auth_lock"])
    check("G007_FAILED_SCOPE_SHA", sha(FAILED / "CONTRACT_PUBLICATION_SCOPE.json") == ANCHORS["scope"])
    check("G008_FAILED_PINNING_SHA", sha(FAILED / "RUNTIME_SUBSTRATE_PINNING_SCOPE.json") == ANCHORS["pinning"])
    check("G009_FAILED_CONTAINMENT_SHA", sha(FAILED / "ADVERSARIAL_CONTAINMENT_SCOPE.json") == ANCHORS["containment"])
    check("G010_FAILED_TREE_READ_ONLY", all(ro(p) for p in FAILED.iterdir() if p.is_file()))
    old_authority = load(FAILED / "AUTHORITY_NON_ESCALATION_DECISION.json")
    check("G011_OLD_FIELD_PRESENT", old_authority.get("contract_runtime_authorized") is False)
    check("G012_CANONICAL_FIELD_ABSENT", "contract_execution_authorized" not in old_authority)
    verifier_text = (FAILED / "freeze_verify.py").read_text(encoding="utf-8")
    check("G013_VERIFIER_EXPECTS_CANONICAL_FIELD", '"contract_execution_authorized"' in verifier_text)
    check("G014_EXACT_ROOT_CAUSE", old_authority.get("contract_runtime_authorized") is False and "contract_execution_authorized" not in old_authority and '"contract_execution_authorized"' in verifier_text)
    check("G015_FAILED_V1_NO_AUTHORITY", True)

    check("G016_RUNNER_LOCK", sha(RUNNER / "GOVERNANCE_LOCK.json") == ANCHORS["runner_lock"])
    check("G017_RUNNER_PASS", sha(RUNNER / "FIXTURE_RUNNER_V2_PASS_LOCKED.json") == ANCHORS["runner_pass"])
    runner_pass = load(RUNNER / "FIXTURE_RUNNER_V2_PASS_LOCKED.json")
    check("G018_RUNNER_STATE", runner_pass.get("status") == "PASS_LOCKED" and runner_pass.get("attempt_state") == "CONSUMED_NO_RETRY")
    check("G019_RUNNER_NO_REPLAY", runner_pass.get("attempt_count") == 1)
    check("G020_FUTURE_PATH_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    check("G021_AUTHORITY_FIELD_COUNT", len(CANONICAL_AUTHORITY_FIELDS) == len(set(CANONICAL_AUTHORITY_FIELDS)) == 11)
    check("G022_REQUIRED_SECTION_COUNT", len(REQUIRED_SECTIONS) == len(set(REQUIRED_SECTIONS)) == 17)

    snapshot: dict[str, Any] = {
        "failed_v1_terminal": True,
        "runner_predecessor_pass": True,
        "future_path_absent": True,
        "decision": "AUTHORIZE_CONTRACT_PUBLICATION_ONLY",
        "future_identity": FUTURE_IDENTITY,
        "future_path": str(FUTURE),
        "required_sections": list(REQUIRED_SECTIONS),
        "contract_publication_authorized": True,
        **{field: False for field in CANONICAL_AUTHORITY_FIELDS},
        "default_policy": "DENY",
        "worker_secret_authority": "FORBIDDEN",
        "worker_control_plane_authority": "FORBIDDEN",
        "incomplete_evidence": "FAIL_CLOSED",
        "operations_this_milestone": zero_operations(),
    }
    check("G023_CANONICAL_SNAPSHOT", valid_authorization(snapshot))
    check("G024_TYPED_EXACT_FIELDS", set(snapshot).issuperset(CANONICAL_AUTHORITY_FIELDS) and "contract_runtime_authorized" not in snapshot)
    check("G025_PUBLICATION_ONLY", snapshot["contract_publication_authorized"] and not snapshot["contract_execution_authorized"])
    check("G026_NO_RUNTIME", snapshot["runtime_validation_authorized"] is False)
    check("G027_NO_FIXTURE", snapshot["containment_fixture_execution_authorized"] is False)
    check("G028_NO_WORKER", snapshot["worker_or_subagent_execution_authorized"] is False)
    check("G029_NO_CODEX", snapshot["codex_cli_invocation_authorized"] is False)
    check("G030_NO_TARGET_NETWORK", snapshot["target_or_network_authorized"] is False)
    check("G031_NO_PARALLEL", snapshot["parallelism_authorized"] is False)
    check("G032_NO_CAPABILITY", snapshot["capability_graph_authorized"] is False)
    check("G033_NO_PROMOTION", snapshot["candidate_promotion_authorized"] is False)
    check("G034_NO_SUBMISSION", snapshot["submission_automation_authorized"] is False)
    check("G035_NO_B0", snapshot["v0_3_b0_authorized"] is False)
    check("G036_DENY_DEFAULT", snapshot["default_policy"] == "DENY")
    check("G037_NO_SECRET", snapshot["worker_secret_authority"] == "FORBIDDEN")
    check("G038_NO_CONTROL", snapshot["worker_control_plane_authority"] == "FORBIDDEN")
    check("G039_FAIL_CLOSED", snapshot["incomplete_evidence"] == "FAIL_CLOSED")
    check("G040_ZERO_OPERATIONS", snapshot["operations_this_milestone"] == zero_operations())

    failed = [item for item in checks if item["status"] != "PASS"]
    if failed:
        raise RuntimeError(f"successor authorization preflight failed: {failed}")

    routing = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "scope": "SUCCESSOR_GOVERNANCE_ONLY_PUBLICATION_AUTHORIZATION",
        "active_skills": ["mandatory-auto-router", "authorized-security-autopilot", "agentic-security-research-harness", "codex-security-harness"],
        "subagents": "NOT_USED_NOT_AUTHORIZED", "external_execution": "NONE",
        "operations_performed": zero_operations(),
    }
    predecessor = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_PREDECESSOR_CHAIN_BINDING",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "failed_governance_v1": {"path": str(FAILED), "lock_sha256": ANCHORS["failed_lock"], "manifest_sha256": ANCHORS["failed_manifest"], "canonical_root_sha256": ANCHORS["failed_root"], "status": "FAIL_CLOSED_FREEZE_VERIFICATION_44_OF_45_REFERENCE_ONLY"},
        "runner_v2": {"path": str(RUNNER), "lock_sha256": ANCHORS["runner_lock"], "pass_lock_sha256": ANCHORS["runner_pass"], "status": "PASS_LOCKED_NO_REPLAY"},
    }
    failed_disposition = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_GOVERNANCE_V1_TERMINAL_DISPOSITION",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY",
        "reported_lock_status": "PASS_LOCKED_GOVERNANCE_ONLY_WITHOUT_EFFECTIVE_AUTHORITY",
        "freeze_verification": {"total": 45, "passed": 44, "failed": 1, "failed_check": "F028_DECISION_AUTHORITY_CEILING"},
        "patch_relock_or_reissue_same_identity": "PROHIBITED",
        "effective_contract_publication_authority": False,
    }
    root_cause = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V1_FREEZE_FIELD_MISMATCH_ROOT_CAUSE",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "classification": "POST_FREEZE_VERIFIER_TYPED_AUTHORITY_FIELD_NAME_MISMATCH",
        "decision_artifact_field": "contract_runtime_authorized",
        "freeze_verifier_expected_field": "contract_execution_authorized",
        "observed_value_from_expected_lookup": None,
        "expected_value": False,
        "contract_or_runtime_defect": False,
        "authority_granted_by_failed_v1": False,
    }
    field_schema = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_TYPED_AUTHORITY_FIELD_SCHEMA",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "publication_allow_field": "contract_publication_authorized",
        "exact_false_fields": list(CANONICAL_AUTHORITY_FIELDS),
        "unknown_field_policy": "FAIL_CLOSED",
        "alias_policy": "NO_ALIASES",
        "suffix_heuristics": "PROHIBITED",
        "all_authority_artifacts_must_use_exact_schema": True,
    }
    decision = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_PUBLICATION_AUTHORIZATION_DECISION_V2",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "decision": "AUTHORIZE_CONTRACT_PUBLICATION_ONLY",
        "milestone": MILESTONE,
        "future_contract_identity": FUTURE_IDENTITY,
        "future_contract_path": str(FUTURE),
        "status": "AUTHORIZED_NOT_CREATED",
        "contract_publication_authorized": True,
        **{field: False for field in CANONICAL_AUTHORITY_FIELDS},
    }
    binding = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_IDENTITY_AND_PATH_BINDING_V2",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "identity": FUTURE_IDENTITY, "path": str(FUTURE), "path_state": "ABSENT",
        "collision_policy": "FAIL_CLOSED_NO_OVERWRITE", "artifact_class": "GOVERNANCE_CONTRACT_ONLY",
    }
    publication_scope = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_PUBLICATION_SCOPE_V2",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "required_sections": list(REQUIRED_SECTIONS),
        "publication_ceiling": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
        "required_properties": ["typed_deny_by_default", "adversarial_worker_threat_model", "OS_enforced_boundary_not_environment_only", "worker_no_secret_control_or_promotion_authority", "out_of_worker_monitoring_and_kill", "fail_closed_incomplete_evidence", "separate_authorization_for_every_runtime_stage"],
    }
    pinning = {
        "record_type": "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_SCOPE_V2",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "must_pin": ["kernel_and_security_configuration", "bubblewrap_and_dependency_closure", "trace_collector_and_trace_contract", "language_runtime_and_native_dependencies", "seccomp_and_LSM_identity_if_relied_upon", "namespace_runtime", "external_monitor_and_kill_controller", "runtime_adapter_without_invocation", "configuration_and_environment"],
        "read_only_identity_collection_only": True,
        "binary_execution_for_identification": False,
        "automatic_update": False,
        "unverifiable_dependency": "BLOCK",
        "runtime_change": "NEW_CANDIDATE_SUCCESSOR_AND_SEPARATE_COMPATIBILITY_GOVERNANCE",
    }
    containment = {
        "record_type": "V0_3_WORKER_ADVERSARIAL_CONTAINMENT_SCOPE_V2",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "worker_assumption": "POTENTIALLY_ADVERSARIAL_ARBITRARY_CODE",
        "required_OS_controls": ["read_only_host_root", "isolated_namespaces", "one_exact_writable_workspace", "no_unsandboxed_fallback", "no_new_privileges", "capability_drop", "seccomp_LSM_explicit_decision", "FD_socket_allowlist", "process_lineage_allowlist", "resource_limits", "canonical_path_and_symlink_rejection"],
        "host_interfaces": "INVENTORY_CLASSIFY_AND_DENY_BY_DEFAULT",
        "network_and_IPC": "DENY_BY_DEFAULT",
        "secrets_and_control_plane_authority": "NEVER_DIRECTLY_AVAILABLE_TO_WORKER",
        "monitor_and_kill": "OUTSIDE_WORKER_CONTROL",
        "topology_trace_or_evidence_incomplete": "FAIL_CLOSED",
        "containment_fixture_execution": "REQUIRES_SEPARATE_AUTHORIZATION",
        "external_references": "REFERENCE_ONLY_NO_POC_EXECUTION",
        "codex_runtime_candidate": "NOT_AUTHORIZED_NOT_INVOKED",
    }
    authority = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORITY_NON_ESCALATION_DECISION_V2",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "contract_publication_authorized": True,
        **{field: False for field in CANONICAL_AUTHORITY_FIELDS},
    }
    matrix = {
        "record_type": "V0_3_WORKER_RUNTIME_CONTRACT_OPERATION_AUTHORIZATION_MATRIX_V2",
        "schema_version": "1.0", "governance_identity": IDENTITY, "default": "DENY",
        "operations": {
            "CREATE_VALIDATE_AND_FREEZE_EXACT_CONTRACT": "AUTHORIZED_FUTURE_MILESTONE_ONLY",
            "READ_FROZEN_PREDECESSORS_AND_HASH_APPROVED_LOCAL_ARTIFACTS": "AUTHORIZED_FUTURE_MILESTONE_NO_BINARY_EXECUTION",
            "EXECUTE_CONTRACT_OR_RUNTIME": "NOT_AUTHORIZED", "RUN_CONTAINMENT_FIXTURES": "NOT_AUTHORIZED",
            "INVOKE_CODEX": "NOT_AUTHORIZED", "EXECUTE_WORKER_OR_SUBAGENT": "NOT_AUTHORIZED",
            "TARGET_OR_NETWORK": "NOT_AUTHORIZED", "PARALLELISM": "NOT_AUTHORIZED",
            "CAPABILITY_GRAPH": "NOT_AUTHORIZED", "CANDIDATE_PROMOTION": "NOT_AUTHORIZED",
            "SUBMISSION_AUTOMATION": "NOT_AUTHORIZED", "V0_3_B0": "NOT_AUTHORIZED",
            "REPLAY_RUNNER_V2": "NOT_AUTHORIZED",
        },
    }

    cases: list[dict[str, Any]] = []
    base_mutations = [
        ("N001_FAILED_V1_NOT_TERMINAL", "failed_v1_terminal", False),
        ("N002_RUNNER_NOT_PASS", "runner_predecessor_pass", False),
        ("N003_PATH_COLLISION", "future_path_absent", False),
        ("N004_WRONG_DECISION", "decision", "AUTHORIZE_RUNTIME"),
        ("N005_WRONG_IDENTITY", "future_identity", "WRONG"),
        ("N006_WRONG_PATH", "future_path", "/tmp/wrong"),
        ("N007_MISSING_SECTION", "required_sections", list(REQUIRED_SECTIONS[:-1])),
        ("N008_PUBLICATION_DENIED", "contract_publication_authorized", False),
        ("N009_DEFAULT_ALLOW", "default_policy", "ALLOW"),
        ("N010_SECRET_ALLOWED", "worker_secret_authority", "ALLOWED"),
        ("N011_CONTROL_ALLOWED", "worker_control_plane_authority", "ALLOWED"),
        ("N012_INCOMPLETE_PASS", "incomplete_evidence", "PASS"),
    ]
    for case_id, key, value in base_mutations:
        test = copy.deepcopy(snapshot); test[key] = value
        cases.append({"case_id": case_id, "mutation": {key: value}, "expected": "REJECT", "actual": "REJECT" if not valid_authorization(test) else "ACCEPT"})
    for index, field in enumerate(CANONICAL_AUTHORITY_FIELDS, 13):
        test = copy.deepcopy(snapshot); test[field] = True
        cases.append({"case_id": f"N{index:03d}_{field.upper()}", "mutation": {field: True}, "expected": "REJECT", "actual": "REJECT" if not valid_authorization(test) else "ACCEPT"})
    alias_test = copy.deepcopy(snapshot); alias_test["contract_runtime_authorized"] = False
    cases.append({"case_id": "N024_ALIAS_FIELD", "mutation": {"contract_runtime_authorized": False}, "expected": "REJECT", "actual": "REJECT" if not valid_authorization(alias_test) else "ACCEPT"})
    missing_test = copy.deepcopy(snapshot); del missing_test["contract_execution_authorized"]
    cases.append({"case_id": "N025_MISSING_CANONICAL_FIELD", "mutation": {"remove": "contract_execution_authorized"}, "expected": "REJECT", "actual": "REJECT" if not valid_authorization(missing_test) else "ACCEPT"})
    for index, key in enumerate(zero_operations(), 26):
        test = copy.deepcopy(snapshot); test["operations_this_milestone"][key] = 1
        cases.append({"case_id": f"N{index:03d}_{key.upper()}", "mutation": {f"operations_this_milestone.{key}": 1}, "expected": "REJECT", "actual": "REJECT" if not valid_authorization(test) else "ACCEPT"})
    negative_failed = [case for case in cases if case["actual"] != case["expected"]]
    negative_matrix = {"record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_NEGATIVE_TEST_MATRIX", "schema_version": "1.0", "governance_identity": IDENTITY, "method": "IN_MEMORY_TYPED_SCHEMA_MUTATION_NO_EXECUTION", "cases": cases}
    negative_result = {"record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_NEGATIVE_TEST_RESULT", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS" if not negative_failed else "FAIL_CLOSED", "tests_total": len(cases), "tests_passed": len(cases)-len(negative_failed), "tests_failed": len(negative_failed), "failed": negative_failed, "operations_this_milestone": zero_operations()}
    result = {"record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_GOVERNANCE_TEST_RESULT", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS", "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0, "failed": [], "checks": checks, "operations_this_milestone": zero_operations()}

    documents = {
        "ROUTING_AND_SCOPE_DECISION.json": routing,
        "PREDECESSOR_CHAIN_BINDING.json": predecessor,
        "FAILED_GOVERNANCE_V1_DISPOSITION.json": failed_disposition,
        "FREEZE_VERIFIER_FIELD_MISMATCH_ROOT_CAUSE.json": root_cause,
        "TYPED_AUTHORITY_FIELD_SCHEMA.json": field_schema,
        "CONTRACT_PUBLICATION_AUTHORIZATION_DECISION.json": decision,
        "CONTRACT_IDENTITY_AND_PATH_BINDING.json": binding,
        "CONTRACT_PUBLICATION_SCOPE.json": publication_scope,
        "RUNTIME_SUBSTRATE_PINNING_SCOPE.json": pinning,
        "ADVERSARIAL_CONTAINMENT_SCOPE.json": containment,
        "AUTHORITY_NON_ESCALATION_DECISION.json": authority,
        "OPERATION_AUTHORIZATION_MATRIX.json": matrix,
        "NEGATIVE_GOVERNANCE_TEST_MATRIX.json": negative_matrix,
        "NEGATIVE_GOVERNANCE_TEST_RESULT.json": negative_result,
        "GOVERNANCE_TEST_RESULT.json": result,
    }
    for name, value in documents.items():
        write_once(name, value)
    print(json.dumps({"status": "PASS", "checks": len(checks), "negative_tests": len(cases), "documents": len(documents)}, sort_keys=True))


if __name__ == "__main__":
    main()
