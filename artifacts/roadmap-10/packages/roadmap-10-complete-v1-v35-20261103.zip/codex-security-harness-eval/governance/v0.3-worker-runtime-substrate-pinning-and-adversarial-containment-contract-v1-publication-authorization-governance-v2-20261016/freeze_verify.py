#!/usr/bin/env python3
"""Read-only freeze verification for effective authorization governance V2."""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
FAILED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-publication-authorization-governance-v1-20261016")
FUTURE = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016")
IDENTITY = "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1_PUBLICATION_AUTHORIZATION_GOVERNANCE_V2"
FALSE_FIELDS = ("contract_execution_authorized", "runtime_validation_authorized", "containment_fixture_execution_authorized", "worker_or_subagent_execution_authorized", "codex_cli_invocation_authorized", "target_or_network_authorized", "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized", "submission_automation_authorized", "v0_3_b0_authorized")
FILES = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_CHAIN_BINDING.json", "FAILED_GOVERNANCE_V1_DISPOSITION.json",
    "FREEZE_VERIFIER_FIELD_MISMATCH_ROOT_CAUSE.json", "TYPED_AUTHORITY_FIELD_SCHEMA.json",
    "CONTRACT_PUBLICATION_AUTHORIZATION_DECISION.json", "CONTRACT_IDENTITY_AND_PATH_BINDING.json",
    "CONTRACT_PUBLICATION_SCOPE.json", "RUNTIME_SUBSTRATE_PINNING_SCOPE.json", "ADVERSARIAL_CONTAINMENT_SCOPE.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "GOVERNANCE_TEST_RESULT.json", "INDEPENDENT_VALIDATION_RESULT.json",
    "CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json", "NEXT_LEGAL_MILESTONE.json",
    "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json",
}


def sha(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise TypeError(path)
    return value
def ro(path: Path) -> bool: return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0
def rows_root(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{x['sha256']}  {x['path']}\n" for x in sorted(rows, key=lambda y: y["path"])).encode()).hexdigest()
def zeros(value: Any) -> bool: return isinstance(value, dict) and len(value) == 10 and all(type(v) is int and v == 0 for v in value.values())


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(cid: str, passed: bool, detail: Any = None) -> None: checks.append({"check_id": cid, "status": "PASS" if passed else "FAIL", "detail": detail})
    actual = {p.name for p in ROOT.iterdir() if p.is_file()}
    check("F001_FILE_SET", actual == FILES, {"extra": sorted(actual-FILES), "missing": sorted(FILES-actual)})
    check("F002_NO_DIRS", not any(p.is_dir() for p in ROOT.iterdir()))
    check("F003_ROOT_RO", ro(ROOT))
    check("F004_FILES_RO", all(p.is_file() and not p.is_symlink() and ro(p) for p in ROOT.iterdir()))
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"; lock_path = ROOT / "GOVERNANCE_LOCK.json"
    manifest = load(manifest_path); lock = load(lock_path); members = manifest.get("members", [])
    check("F005_IDENTITY", manifest.get("governance_identity") == lock.get("governance_identity") == IDENTITY)
    check("F006_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F007_DECISION", lock.get("decision") == "AUTHORIZE_CONTRACT_PUBLICATION_ONLY")
    check("F008_MEMBER_COUNT", manifest.get("member_count") == len(members) == 22)
    check("F009_ROOT_COUNT", lock.get("root_member_count") == 23)
    check("F010_EXCLUDES", {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}.isdisjoint({x.get("path") for x in members}))
    member_ok = all((ROOT / x["path"]).is_file() and not (ROOT / x["path"]).is_symlink() and ro(ROOT / x["path"]) and (ROOT / x["path"]).stat().st_size == x["bytes"] and sha(ROOT / x["path"]) == x["sha256"] for x in members)
    check("F011_MEMBERS", member_ok)
    member_root = rows_root(members)
    check("F012_MEMBER_ROOT", member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256"))
    manifest_sha = sha(manifest_path)
    check("F013_MANIFEST_SHA", manifest_sha == lock.get("governance_manifest_sha256"))
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}])
    check("F014_ARTIFACT_ROOT", artifact_root == lock.get("canonical_artifact_root_sha256"))
    check("F015_STRUCTURAL", lock.get("structural_counts") == {"manifest_members": 22, "root_members": 23})
    primary = load(ROOT / "GOVERNANCE_TEST_RESULT.json"); negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json"); independent = load(ROOT / "INDEPENDENT_VALIDATION_RESULT.json")
    disposition = load(ROOT / "FAILED_GOVERNANCE_V1_DISPOSITION.json"); schema = load(ROOT / "TYPED_AUTHORITY_FIELD_SCHEMA.json"); decision = load(ROOT / "CONTRACT_PUBLICATION_AUTHORIZATION_DECISION.json"); authority = load(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json"); authorization = load(ROOT / "CONTRACT_PUBLICATION_AUTHORIZATION_LOCK.json"); next_legal = load(ROOT / "NEXT_LEGAL_MILESTONE.json")
    check("F016_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_total") == primary.get("checks_passed") == 40)
    check("F017_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 35)
    check("F018_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_total") == independent.get("checks_passed") == 50)
    check("F019_OLD_TERMINAL", disposition.get("status") == "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY")
    check("F020_OLD_UNCHANGED", sha(FAILED / "GOVERNANCE_LOCK.json") == "d0cc3ab48ce818d861c1779015de34daed15e7e4110ddd3e2026f0104d8db410")
    check("F021_SCHEMA_FIELDS", tuple(schema.get("exact_false_fields", [])) == FALSE_FIELDS)
    check("F022_SCHEMA_NO_ALIAS", schema.get("alias_policy") == "NO_ALIASES" and schema.get("unknown_field_policy") == "FAIL_CLOSED")
    check("F023_DECISION_PUBLICATION", decision.get("contract_publication_authorized") is True)
    check("F024_DECISION_FALSE", all(decision.get(field) is False for field in FALSE_FIELDS))
    check("F025_DECISION_NO_ALIAS", "contract_runtime_authorized" not in decision)
    check("F026_AUTHORITY_PUBLICATION", authority.get("contract_publication_authorized") is True)
    check("F027_AUTHORITY_FALSE", all(authority.get(field) is False for field in FALSE_FIELDS))
    check("F028_AUTHORITY_NO_ALIAS", "contract_runtime_authorized" not in authority)
    check("F029_AUTH_LOCK", authorization.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY" and authorization.get("contract_publication_authorized") is True)
    check("F030_AUTH_LOCK_FALSE", all(authorization.get(field) is False for field in FALSE_FIELDS))
    check("F031_GOV_LOCK_PUBLICATION", lock.get("contract_publication_authorized") is True)
    check("F032_GOV_LOCK_FALSE", all(lock.get(field) is False for field in FALSE_FIELDS))
    check("F033_FUTURE_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    check("F034_FUTURE_STATE", authorization.get("future_contract_state") == lock.get("future_contract_state") == "AUTHORIZED_NOT_CREATED")
    check("F035_NEXT", next_legal.get("status") == "AUTHORIZED_CONTRACT_PUBLICATION_ONLY_NOT_STARTED" and next_legal.get("execution_authority") == "NONE")
    check("F036_ZERO_PRIMARY", zeros(primary.get("operations_this_milestone")))
    check("F037_ZERO_NEGATIVE", zeros(negative.get("operations_this_milestone")))
    check("F038_ZERO_INDEPENDENT", zeros(independent.get("operations_this_milestone")))
    check("F039_ZERO_AUTH", zeros(authorization.get("operations_this_milestone")))
    check("F040_ZERO_LOCK", zeros(lock.get("operations_this_milestone")))
    check("F041_VALIDATION_COUNTS", all(v.get("total") == v.get("passed") and v.get("failed") == 0 for v in lock.get("validation_counts", {}).values()))
    failed = [x for x in checks if x["status"] != "PASS"]
    result = {"status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed), "failed": failed, "governance_lock_sha256": sha(lock_path), "governance_manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root, "decision": lock.get("decision"), "future_contract_state": lock.get("future_contract_state"), "operations_this_milestone": lock.get("operations_this_milestone")}
    print(json.dumps(result, sort_keys=True))
    if failed: raise SystemExit(1)


if __name__ == "__main__": main()
