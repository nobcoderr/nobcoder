#!/usr/bin/env python3
"""Independent validation for publication authorization governance V2."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
FAILED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-publication-authorization-governance-v1-20261016")
FUTURE = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-worker-runtime-substrate-pinning-and-adversarial-containment-contract-v1-20261016")
IDENTITY = "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1_PUBLICATION_AUTHORIZATION_GOVERNANCE_V2"
FALSE_FIELDS = ("contract_execution_authorized", "runtime_validation_authorized", "containment_fixture_execution_authorized", "worker_or_subagent_execution_authorized", "codex_cli_invocation_authorized", "target_or_network_authorized", "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized", "submission_automation_authorized", "v0_3_b0_authorized")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise TypeError(path)
    return value


def zeros(value: Any) -> bool:
    return isinstance(value, dict) and len(value) == 10 and all(type(v) is int and v == 0 for v in value.values())


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, detail: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "detail": detail})

    disposition = load(ROOT / "FAILED_GOVERNANCE_V1_DISPOSITION.json")
    cause = load(ROOT / "FREEZE_VERIFIER_FIELD_MISMATCH_ROOT_CAUSE.json")
    schema = load(ROOT / "TYPED_AUTHORITY_FIELD_SCHEMA.json")
    decision = load(ROOT / "CONTRACT_PUBLICATION_AUTHORIZATION_DECISION.json")
    binding = load(ROOT / "CONTRACT_IDENTITY_AND_PATH_BINDING.json")
    scope = load(ROOT / "CONTRACT_PUBLICATION_SCOPE.json")
    pinning = load(ROOT / "RUNTIME_SUBSTRATE_PINNING_SCOPE.json")
    containment = load(ROOT / "ADVERSARIAL_CONTAINMENT_SCOPE.json")
    authority = load(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    primary = load(ROOT / "GOVERNANCE_TEST_RESULT.json")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")

    check("I001_FAILED_LOCK", sha(FAILED / "GOVERNANCE_LOCK.json") == "d0cc3ab48ce818d861c1779015de34daed15e7e4110ddd3e2026f0104d8db410")
    check("I002_FAILED_MANIFEST", sha(FAILED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "db2f270e13837d8c98378a35ad777ec999b9fd02e7bf37faffe6164509711417")
    check("I003_FAILED_VERIFIER", sha(FAILED / "freeze_verify.py") == "6bdcec61ef06a0982bd0e44c2a5b251bdb6c3a962727f8119c6ad89e33482dc0")
    check("I004_FAILED_TERMINAL", disposition.get("status") == "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY")
    check("I005_FAILED_COUNTS", disposition.get("freeze_verification") == {"total": 45, "passed": 44, "failed": 1, "failed_check": "F028_DECISION_AUTHORITY_CEILING"})
    check("I006_NO_OLD_AUTHORITY", disposition.get("effective_contract_publication_authority") is False)
    check("I007_NO_OLD_PATCH", disposition.get("patch_relock_or_reissue_same_identity") == "PROHIBITED")
    check("I008_CAUSE_CLASS", cause.get("classification") == "POST_FREEZE_VERIFIER_TYPED_AUTHORITY_FIELD_NAME_MISMATCH")
    check("I009_CAUSE_FIELDS", cause.get("decision_artifact_field") == "contract_runtime_authorized" and cause.get("freeze_verifier_expected_field") == "contract_execution_authorized")
    check("I010_NO_PRODUCT_DEFECT", cause.get("contract_or_runtime_defect") is False)
    check("I011_SCHEMA_FIELDS", tuple(schema.get("exact_false_fields", [])) == FALSE_FIELDS)
    check("I012_NO_ALIASES", schema.get("alias_policy") == "NO_ALIASES" and schema.get("unknown_field_policy") == "FAIL_CLOSED")
    check("I013_NO_HEURISTICS", schema.get("suffix_heuristics") == "PROHIBITED")
    check("I014_DECISION", decision.get("decision") == "AUTHORIZE_CONTRACT_PUBLICATION_ONLY")
    check("I015_DECISION_STATUS", decision.get("status") == "AUTHORIZED_NOT_CREATED")
    check("I016_PUBLICATION_TRUE", decision.get("contract_publication_authorized") is True)
    check("I017_DECISION_FALSE_FIELDS", all(decision.get(field) is False for field in FALSE_FIELDS))
    check("I018_DECISION_EXACT_AUTH_FIELDS", "contract_runtime_authorized" not in decision)
    check("I019_IDENTITY", decision.get("future_contract_identity") == binding.get("identity") == "V0_3_WORKER_RUNTIME_SUBSTRATE_PINNING_AND_ADVERSARIAL_CONTAINMENT_CONTRACT_V1")
    check("I020_PATH", decision.get("future_contract_path") == binding.get("path") == str(FUTURE))
    check("I021_PATH_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink() and binding.get("path_state") == "ABSENT")
    check("I022_NO_OVERWRITE", binding.get("collision_policy") == "FAIL_CLOSED_NO_OVERWRITE")
    sections = scope.get("required_sections", [])
    check("I023_SECTIONS", len(sections) == len(set(sections)) == 17)
    check("I024_PINNING_SECTIONS", "PINNED_KERNEL_AND_HOST_RUNTIME_IDENTITY" in sections and "PINNED_BUBBLEWRAP_TRACE_AND_LANGUAGE_RUNTIME_DEPENDENCIES" in sections)
    check("I025_CONTAINMENT_SECTIONS", "NAMESPACE_CAPABILITY_SECCOMP_LSM_AND_NO_NEW_PRIVS_POLICY" in sections and "FILESYSTEM_TOPOLOGY_AND_WRITABLE_SCOPE_POLICY" in sections)
    check("I026_HOST_SECRET_SECTIONS", "HOST_INTERFACE_INVENTORY_AND_CLASSIFICATION" in sections and "SECRET_CREDENTIAL_AND_CONTROL_PLANE_AUTHORITY_POLICY" in sections)
    check("I027_MONITOR_FAIL_SECTIONS", "OUT_OF_WORKER_MONITORING_EVIDENCE_AND_PROVENANCE_POLICY" in sections and "FAIL_CLOSED_TOPOLOGY_TRACE_AND_EVIDENCE_COMPLETENESS_POLICY" in sections)
    check("I028_FIXTURE_REQUIREMENTS_ONLY", "SAFE_CONTAINMENT_FIXTURE_REQUIREMENTS_ONLY" in sections)
    check("I029_PUBLICATION_CEILING", scope.get("publication_ceiling") == "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY")
    check("I030_PIN_READ_ONLY", pinning.get("read_only_identity_collection_only") is True and pinning.get("binary_execution_for_identification") is False)
    check("I031_NO_AUTO_UPDATE", pinning.get("automatic_update") is False and pinning.get("unverifiable_dependency") == "BLOCK")
    check("I032_ADVERSARIAL", containment.get("worker_assumption") == "POTENTIALLY_ADVERSARIAL_ARBITRARY_CODE")
    check("I033_OS_CONTROLS", {"read_only_host_root", "isolated_namespaces", "one_exact_writable_workspace", "no_unsandboxed_fallback", "no_new_privileges", "capability_drop"}.issubset(set(containment.get("required_OS_controls", []))))
    check("I034_HOST_DENY", containment.get("host_interfaces") == "INVENTORY_CLASSIFY_AND_DENY_BY_DEFAULT" and containment.get("network_and_IPC") == "DENY_BY_DEFAULT")
    check("I035_NO_SECRETS", containment.get("secrets_and_control_plane_authority") == "NEVER_DIRECTLY_AVAILABLE_TO_WORKER")
    check("I036_MONITOR_OUTSIDE", containment.get("monitor_and_kill") == "OUTSIDE_WORKER_CONTROL")
    check("I037_FAIL_CLOSED", containment.get("topology_trace_or_evidence_incomplete") == "FAIL_CLOSED")
    check("I038_FIXTURE_SEPARATE", containment.get("containment_fixture_execution") == "REQUIRES_SEPARATE_AUTHORIZATION")
    check("I039_REFERENCE_ONLY", containment.get("external_references") == "REFERENCE_ONLY_NO_POC_EXECUTION")
    check("I040_CODEX_DENIED", containment.get("codex_runtime_candidate") == "NOT_AUTHORIZED_NOT_INVOKED")
    check("I041_AUTHORITY_PUBLICATION", authority.get("contract_publication_authorized") is True)
    check("I042_AUTHORITY_FALSE_FIELDS", all(authority.get(field) is False for field in FALSE_FIELDS))
    check("I043_AUTHORITY_EXACT", "contract_runtime_authorized" not in authority)
    check("I044_MATRIX_DEFAULT", matrix.get("default") == "DENY")
    check("I045_MATRIX_EXEC_DENIED", all(value == "NOT_AUTHORIZED" for key, value in matrix.get("operations", {}).items() if key not in {"CREATE_VALIDATE_AND_FREEZE_EXACT_CONTRACT", "READ_FROZEN_PREDECESSORS_AND_HASH_APPROVED_LOCAL_ARTIFACTS"}))
    check("I046_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I047_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 35 and negative.get("tests_failed") == 0)
    check("I048_ZERO_PRIMARY", zeros(primary.get("operations_this_milestone")))
    check("I049_ZERO_NEGATIVE", zeros(negative.get("operations_this_milestone")))
    check("I050_IDENTITY_UNIFORM", all(load(ROOT / name).get("governance_identity") == IDENTITY for name in ("ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_CHAIN_BINDING.json", "FAILED_GOVERNANCE_V1_DISPOSITION.json", "CONTRACT_PUBLICATION_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json")))

    failed = [item for item in checks if item["status"] != "PASS"]
    result = {"record_type": "V0_3_WORKER_RUNTIME_CONTRACT_AUTHORIZATION_V2_INDEPENDENT_VALIDATION_RESULT", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed), "failed": failed, "operations_this_milestone": {key: 0 for key in ("contract_publications", "worker_processes", "subagents", "codex_invocations", "target_operations", "network_operations", "parallel_operations", "capability_edges", "candidate_promotions", "submissions")}}
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True); handle.write("\n")
    print(json.dumps({"status": result["status"], "checks": len(checks)}, sort_keys=True))
    if failed: raise SystemExit(1)


if __name__ == "__main__": main()
