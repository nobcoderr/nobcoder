#!/usr/bin/env python3
"""Independent validator; deliberately does not import the product self-test."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PREDECESSOR = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.2-i4-b-prospective-recovery-successor-authorization-and-pre-side-effect-durable-attempt-ledger-governance-v1-20261013")
TERMINAL = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v1-20261013")
SUCCESSOR = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v2-20261014")
PFX = Path("/home/nobcoder/.dotnet/corefx/cryptography/x509stores/my/6C1DA3DE00985BC59141C2F29474051A5FBD85EB.pfx")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def root_digest(path: Path, excluded: set[str]) -> str:
    records = []
    for file_path in sorted((p for p in path.rglob("*") if p.is_file() and not p.is_symlink()), key=lambda p: p.relative_to(path).as_posix()):
        relative = file_path.relative_to(path).as_posix()
        if relative in excluded:
            continue
        records.append((digest(file_path) + "  " + relative + "\n").encode("utf-8"))
    return hashlib.sha256(b"".join(records)).hexdigest()


results: list[tuple[str, bool]] = []


def assert_fact(label: str, condition: bool) -> None:
    results.append((label, bool(condition)))


prelock = read_json("PRE_DECISION_LOCK.json")
decision = read_json("SUCCESSOR_AUTHORIZATION_DECISION.json")
terminal = read_json("TERMINAL_IMPLEMENTATION_DISPOSITION.json")
incident = read_json("INCIDENT_EVIDENCE.json")
sensitive = read_json("SENSITIVE_MATERIAL_HANDLING_DECISION.json")
dependency = read_json("DEPENDENCY_AND_NETWORK_POLICY.json")
paths = read_json("SUCCESSOR_PATH_BINDING.json")
confinement = read_json("FILESYSTEM_CONFINEMENT_CONTRACT.json")
repair = read_json("TEST_REPAIR_SCOPE.json")
operations = read_json("OPERATION_AUTHORIZATION_MATRIX.json")
history = read_json("HISTORICAL_IMMUTABILITY_RESULT.json")
negative = read_json("NEGATIVE_GOVERNANCE_CASES.json")

for filename, expected in prelock["locked_artifacts"].items():
    assert_fact("predecision_digest_" + filename, digest(ROOT / filename) == expected)
assert_fact("predecision_count", prelock["locked_artifact_count"] == len(prelock["locked_artifacts"]))

assert_fact("predecessor_lock", digest(PREDECESSOR / "GOVERNANCE_LOCK.json") == "cd3ad1a4577ae7e41f1a534389db9d091dcc665e535869c59f754bde66453bb5")
assert_fact("predecessor_manifest", digest(PREDECESSOR / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "c582beb6de64aaad88e00d981f4c3531b6453dbab0c6aadf1a5c5b0a3a877fcb")
assert_fact("predecessor_root", root_digest(PREDECESSOR, {"GOVERNANCE_LOCK.json"}) == "ad0f9c52c62ead3e543c00fb1f001898bf02d7d487c4639aec74494c9d4d8440")

assert_fact("terminal_root", root_digest(TERMINAL, set()) == "e24dfad19b7e8e53c480fb7ea599c63bf391d77d3504814d5aa6a522a5dbbfb3")
for relative, expected in history["five_partial_source_hashes"].items():
    assert_fact("source_" + relative, digest(TERMINAL / relative) == expected)
assert_fact("terminal_fail", terminal["status"].startswith("FAIL_CLOSED_TERMINAL"))
assert_fact("terminal_101_103", (terminal["offline_test_result"]["passed"], terminal["offline_test_result"]["total"]) == (101, 103))
assert_fact("terminal_no_freeze", terminal["provisional_manifest"] == terminal["provisional_freeze"] == "NOT_ISSUED")

pfx_metadata = PFX.stat()
assert_fact("pfx_present", PFX.is_file())
assert_fact("pfx_metadata", pfx_metadata.st_size == 2383 and stat.S_IMODE(pfx_metadata.st_mode) == 0o600)
assert_fact("pfx_no_digest", sensitive["content_digest"].startswith("NOT_RECOMPUTED"))
assert_fact("pfx_denied", any("Do not open" in item for item in sensitive["required_handling"]))
assert_fact("incident_scope", incident["out_of_scope_roots"] == ["/home/nobcoder/.dotnet", "/home/nobcoder/.nuget"])
assert_fact("incident_counts", incident["observed"]["dotnet_files"] == 4 and incident["observed"]["nuget_files"] == 594)

assert_fact("network_unknown", dependency["historical_assessment"]["network_activity_decision"].startswith("UNDETERMINED"))
assert_fact("dependency_three", len(dependency["quarantined_local_package_seeds"]) == 3)
assert_fact("dependency_no_auto", dependency["automatic_dependency_download"] is False)
assert_fact("external_source_cleared_future", any("clear all external sources" in line for line in dependency["future_policy"]))

assert_fact("successor_absent", not SUCCESSOR.exists() and not SUCCESSOR.is_symlink())
assert_fact("successor_exact", paths["linux_successor_root"] == str(SUCCESSOR))
assert_fact("successor_distinct", paths["linux_successor_root"] != paths["terminal_predecessor_root"])
assert_fact("successor_create_once", paths["creation_semantics"].startswith("CREATE_EXACT_ROOT_ONCE"))
assert_fact("decision_governance_only", decision["status"] == "PASS_LOCKED_GOVERNANCE_ONLY" and decision["operational_authorization"] == "NOT_ISSUED")
assert_fact("decision_new_impl", decision["new_implementation_identity"].endswith("OFFLINE_IMPLEMENTATION_V2"))

env = confinement["required_environment"]
for variable in ["HOME", "DOTNET_CLI_HOME", "NUGET_PACKAGES", "NUGET_HTTP_CACHE_PATH", "NUGET_PLUGINS_CACHE_PATH", "NUGET_SCRATCH", "TMPDIR", "TMP", "TEMP", "XDG_CACHE_HOME", "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_STATE_HOME", "MSBuildUserExtensionsPath"]:
    assert_fact("env_" + variable, env[variable].startswith("$SUCCESSOR/"))
assert_fact("host_root_ro", confinement["enforcement"]["host_root"] == "READ_ONLY_BIND")
assert_fact("single_rw_bind", confinement["enforcement"]["only_host_backed_writable_bind"] == str(SUCCESSOR))
assert_fact("no_network", confinement["enforcement"]["network_namespace"].startswith("UNSHARED"))
assert_fact("no_fallback", confinement["enforcement"]["fallback"] == "NONE_FAIL_CLOSED")
assert_fact("trace_independent", "independently" in confinement["independent_write_audit"]["verifier_independence"])
assert_fact("empirical_not_run", confinement["status"].endswith("NOT_EMPIRICALLY_VALIDATED"))

assert_fact("repair_not_product", repair["status"] == "AUTHORIZED_MINIMAL_TEST_ONLY_REPAIR")
assert_fact("repair_record_serializer", any("AttemptRecord" in item for item in repair["authorized_repair"]))
assert_fact("repair_negative_control", any("negative control" in item for item in repair["authorized_repair"]))
assert_fact("repair_slot_schema_unchanged", any("Do not add HostIdentity" in item for item in repair["forbidden_repair"]))
assert_fact("repair_exact_total", repair["successor_expected_result"].startswith("103_OF_103"))

op_map = {item["id"]: item["decision"] for item in operations["operations"]}
for index in range(1, 20):
    assert_fact(f"deny_X{index:02d}", op_map.get(f"X{index:02d}") == "DENIED")
assert_fact("zero_toolchain_now", operations["currently_executable_dotnet_operations"] == 0)
assert_fact("zero_windows_now", operations["currently_executable_windows_operations"] == 0)
assert_fact("zero_recovery_now", operations["currently_executable_recovery_operations"] == 0)

unsafe_samples = {
    "/home/nobcoder/.dotnet/new": False,
    "/home/nobcoder/.nuget/new": False,
    "/tmp/new": False,
    str(TERMINAL / "new"): False,
    str(SUCCESSOR / "build/bin/new"): True,
    str(SUCCESSOR / ".sandbox/tmp/new"): True,
}
for candidate, expected in unsafe_samples.items():
    permitted = candidate == str(SUCCESSOR) or candidate.startswith(str(SUCCESSOR) + os.sep)
    assert_fact("synthetic_path_policy_" + hashlib.sha256(candidate.encode()).hexdigest()[:8], permitted is expected)

assert_fact("negative_count", negative["case_count"] == len(negative["cases"]) == 39)
assert_fact("negative_all_rejected", negative["expected_disposition"] == "ALL_REJECTED_FAIL_CLOSED")
assert_fact("history_no_mutation", history["historical_mutations"] == 0)
assert_fact("recovery_v2_unknown", history["recovery_v2"] == "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY")

failed = [label for label, ok in results if not ok]
document = {
    "schema_version": 1,
    "validator": "independent_recovery_v3_toolchain_erratum_governance_validator_v1",
    "status": "PASS" if not failed else "FAIL",
    "passed": len(results) - len(failed),
    "failed": len(failed),
    "total": len(results),
    "failed_checks": failed,
    "independence": "Separate implementation; does not import governance_self_test.py, independently recomputes predecessor and terminal roots, uses PFX metadata only, and evaluates a separate synthetic path policy.",
    "conclusions": {
        "terminal_v1": "FAIL_CLOSED_NO_RETRY_NO_CLEANUP",
        "successor_v2": "AUTHORIZED_OFFLINE_ONLY_PENDING_EMPIRICAL_CONFINEMENT_PREFLIGHT",
        "filesystem_boundary": "DESIGN_VALIDATION_ONLY_NOT_YET_EMPIRICALLY_PROVEN",
        "network_history": "UNDETERMINED",
        "operational_authorization": "NOT_ISSUED",
    },
}
print(json.dumps(document, indent=2, sort_keys=True))
raise SystemExit(1 if failed else 0)
