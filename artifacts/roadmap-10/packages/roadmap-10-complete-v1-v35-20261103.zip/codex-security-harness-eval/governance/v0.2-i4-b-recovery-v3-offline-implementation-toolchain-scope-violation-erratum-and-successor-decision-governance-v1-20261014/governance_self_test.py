#!/usr/bin/env python3
"""Deterministic governance self-test for the Recovery V3 toolchain erratum."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PREDECESSOR = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.2-i4-b-prospective-recovery-successor-authorization-and-pre-side-effect-durable-attempt-ledger-governance-v1-20261013")
TERMINAL = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v1-20261013")
SUCCESSOR = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v2-20261014")
PFX = Path("/home/nobcoder/.dotnet/corefx/cryptography/x509stores/my/6C1DA3DE00985BC59141C2F29474051A5FBD85EB.pfx")


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_root(path: Path, exclude: set[str]) -> str:
    rows = []
    for item in sorted(path.rglob("*"), key=lambda value: value.relative_to(path).as_posix()):
        if not item.is_file() or item.is_symlink():
            continue
        rel = item.relative_to(path).as_posix()
        if rel in exclude:
            continue
        rows.append(f"{sha(item)}  {rel}\n".encode("utf-8"))
    return hashlib.sha256(b"".join(rows)).hexdigest()


checks: list[tuple[str, bool]] = []


def check(name: str, value: bool) -> None:
    checks.append((name, bool(value)))


protocol = load("GOVERNANCE_GATE_PROTOCOL.json")
preflight = load("PREFLIGHT_RESULT.json")
terminal = load("TERMINAL_IMPLEMENTATION_DISPOSITION.json")
incident = load("INCIDENT_EVIDENCE.json")
sensitive = load("SENSITIVE_MATERIAL_HANDLING_DECISION.json")
surfaces = load("TOOLCHAIN_WRITE_SURFACE_ASSESSMENT.json")
dependency = load("DEPENDENCY_AND_NETWORK_POLICY.json")
decision = load("SUCCESSOR_AUTHORIZATION_DECISION.json")
identity = load("SUCCESSOR_IDENTITY_BINDING.json")
paths = load("SUCCESSOR_PATH_BINDING.json")
confinement = load("FILESYSTEM_CONFINEMENT_CONTRACT.json")
repair = load("TEST_REPAIR_SCOPE.json")
operations = load("OPERATION_AUTHORIZATION_MATRIX.json")
gates = load("FUTURE_STAGE_GATES.json")
history = load("HISTORICAL_IMMUTABILITY_RESULT.json")
risks = load("RISK_REGISTER.json")
negative = load("NEGATIVE_GOVERNANCE_CASES.json")
prelock = load("PRE_DECISION_LOCK.json")

gid = "V0.2_I4_B_RECOVERY_V3_OFFLINE_IMPLEMENTATION_TOOLCHAIN_SCOPE_VIOLATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
check("protocol_identity", protocol["governance_identity"] == gid)
check("protocol_governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
check("protocol_fail_closed", protocol["fail_closed"] is True)
check("protocol_no_dotnet", protocol["scope"]["dotnet_or_nuget_execution"] is False)
check("protocol_no_pfx_access", protocol["scope"]["pfx_content_access_export_or_copy"] is False)
check("preflight_complete", preflight["checks_total"] == preflight["checks_passed"] == 40)
check("preflight_no_failure", preflight["checks_failed"] == 0)
check("preflight_no_write", preflight["writes_before_preflight_pass"] == 0)

check("predecessor_lock", sha(PREDECESSOR / "GOVERNANCE_LOCK.json") == "cd3ad1a4577ae7e41f1a534389db9d091dcc665e535869c59f754bde66453bb5")
check("predecessor_manifest", sha(PREDECESSOR / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "c582beb6de64aaad88e00d981f4c3531b6453dbab0c6aadf1a5c5b0a3a877fcb")
check("predecessor_root", canonical_root(PREDECESSOR, {"GOVERNANCE_LOCK.json"}) == "ad0f9c52c62ead3e543c00fb1f001898bf02d7d487c4639aec74494c9d4d8440")
check("predecessor_status", json.loads((PREDECESSOR / "GOVERNANCE_LOCK.json").read_text())["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")

expected_sources = history["five_partial_source_hashes"]
for rel, digest in expected_sources.items():
    check("terminal_source_" + rel.replace("/", "_"), sha(TERMINAL / rel) == digest)
check("terminal_root", canonical_root(TERMINAL, set()) == terminal["content_root_sha256"])
terminal_files = [item for item in TERMINAL.rglob("*") if item.is_file() and not item.is_symlink()]
check("terminal_file_count", len(terminal_files) == 34)
check("terminal_no_symlinks", not any(item.is_symlink() for item in TERMINAL.rglob("*")))
check("terminal_writable_limitation", sum(os.access(item, os.W_OK) for item in terminal_files) == 34)
check("terminal_status", terminal["status"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_CLEANUP_NO_PROMOTION")
check("terminal_tests", terminal["offline_test_result"]["passed"] == 101 and terminal["offline_test_result"]["failed"] == 2 and terminal["offline_test_result"]["total"] == 103)
check("terminal_failures_exact", terminal["offline_test_result"]["failed_assertions"] == ["json_quote_escape", "json_slash_escape"])
check("terminal_no_freeze", terminal["provisional_freeze"] == "NOT_ISSUED")

check("incident_confirmed", incident["status"] == "CONFIRMED_OUT_OF_SCOPE_PERSISTENT_FILESYSTEM_WRITES")
check("incident_dotnet_count", incident["observed"]["dotnet_files"] == 4)
check("incident_nuget_count", incident["observed"]["nuget_files"] == 594)
check("incident_preserve", incident["preservation"] == "NO_DELETE_NO_CLEANUP_NO_CHMOD_NO_EXPORT_NO_COPY_OF_PFX")
check("pfx_exists_metadata_only", PFX.is_file())
pfx_stat = PFX.stat()
check("pfx_size", pfx_stat.st_size == 2383)
check("pfx_mode", stat.S_IMODE(pfx_stat.st_mode) == 0o600)
check("pfx_decision", sensitive["status"] == "SENSITIVE_PFX_QUARANTINED_METADATA_ONLY_NO_CONTENT_ACCESS")
check("pfx_no_digest", sensitive["content_digest"] == "NOT_RECOMPUTED_CONTENT_ACCESS_FORBIDDEN")
check("pfx_no_operational_use", sensitive["operational_use"] == "FORBIDDEN")

check("write_surface_status", surfaces["status"] == "WRITE_SURFACES_IDENTIFIED_CONFINEMENT_REQUIRED")
check("bwrap_hash_bound", surfaces["tool_observations"]["bubblewrap_sha256"] == "042763bc80c8a895a497e6f801af003d585ea5588a580f7a4349d9ab2aa22980")
check("strace_hash_bound", surfaces["tool_observations"]["strace_sha256"] == "705e89a26e9f6a48f2908760d78801cbaa263f9b8c6738e392fb95902479cddf")
check("sandbox_not_run", surfaces["tool_observations"]["execution_validation"] == "NOT_RUN_IN_GOVERNANCE")
check("environment_not_enforcement", "not sufficient" in surfaces["conclusion"])

check("network_unknown", dependency["historical_assessment"]["network_activity_decision"] == "UNDETERMINED_NOT_PROVEN_FROM_CONFIGURATION_AND_FILESYSTEM_EFFECTS_ALONE")
check("external_source_recorded", dependency["historical_assessment"]["configured_source"] == "https://api.nuget.org/v3/index.json")
check("seed_count", len(dependency["quarantined_local_package_seeds"]) == 3)
for seed in dependency["quarantined_local_package_seeds"]:
    check("seed_hash_" + Path(seed["path"]).name, sha(Path(seed["path"])) == seed["sha256"])
check("automatic_download_false", dependency["automatic_dependency_download"] is False)
check("policy_external_clear", any("clear all external sources" in item for item in dependency["future_policy"]))

check("decision_pass_governance", decision["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
check("decision_terminalizes_v1", decision["decisions"]["D1_old_implementation"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_CLEANUP")
check("decision_successor_v2", decision["new_implementation_identity"].endswith("OFFLINE_IMPLEMENTATION_V2"))
check("decision_operational_denied", decision["operational_authorization"] == "NOT_ISSUED")
check("identity_terminal_v1", identity["terminal_predecessor_implementation"]["status"] == "TERMINAL_FAIL_CLOSED_NO_RETRY")
check("identity_v2_offline", identity["successor_implementation"]["status"] == "OFFLINE_IMPLEMENTATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTABLE")
check("recovery_identity_preserved", identity["recovery_identity"]["authorization_identity"] == "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_AUTHORIZATION_V3")
check("successor_absent", not SUCCESSOR.exists() and not SUCCESSOR.is_symlink())
check("successor_path_exact", paths["linux_successor_root"] == str(SUCCESSOR))
check("terminal_path_forbidden", str(TERMINAL) in paths["forbidden_paths"])
check("required_writable_scoped", all(item.startswith((".sandbox/", "build/", "artifacts/")) for item in paths["required_writable_subtrees"]))

check("confinement_not_empirical", confinement["status"] == "MANDATORY_DESIGN_BOUND_NOT_EMPIRICALLY_VALIDATED")
check("confinement_host_ro", confinement["enforcement"]["host_root"] == "READ_ONLY_BIND")
check("confinement_one_rw", confinement["enforcement"]["only_host_backed_writable_bind"] == str(SUCCESSOR))
check("confinement_network", confinement["enforcement"]["network_namespace"] == "UNSHARED_NO_HOST_OR_EXTERNAL_NETWORK")
check("confinement_no_fallback", confinement["enforcement"]["fallback"] == "NONE_FAIL_CLOSED")
check("confinement_env_count", len(confinement["required_environment"]) >= 15)
check("confinement_probe_count", len(confinement["mandatory_pre_toolchain_probes"]) == 8)
check("confinement_stop_count", len(confinement["stop_conditions"]) == 8)
check("independent_trace_required", confinement["independent_write_audit"]["verifier_independence"].startswith("The verifier"))

check("repair_test_only", repair["status"] == "AUTHORIZED_MINIMAL_TEST_ONLY_REPAIR")
check("repair_root_cause", "excludes HostIdentity" in repair["root_cause"])
check("repair_exact_failures", repair["failed_assertions"] == ["json_quote_escape", "json_slash_escape"])
check("repair_no_slot_change", any("Do not add HostIdentity" in item for item in repair["forbidden_repair"]))
check("repair_103", repair["successor_expected_result"].startswith("103_OF_103_PASS"))

ops = {item["id"]: item["decision"] for item in operations["operations"]}
check("operation_count", operations["operation_count"] == len(operations["operations"]) == 29)
check("governance_ops_two", operations["authorized_this_milestone"] == 2)
check("future_ops_eight", operations["authorized_future_offline"] == 8)
check("denied_ops_nineteen", operations["denied"] == 19)
for op_id in [f"X{n:02d}" for n in range(1, 20)]:
    check("denied_" + op_id, ops.get(op_id) == "DENIED")
check("no_dotnet_now", operations["currently_executable_dotnet_operations"] == 0)
check("no_windows_now", operations["currently_executable_windows_operations"] == 0)
check("no_guard_now", operations["currently_executable_guard_operations"] == 0)
check("no_recovery_now", operations["currently_executable_recovery_operations"] == 0)

check("future_gate_order", [item["order"] for item in gates["gates"]] == list(range(1, 12)))
check("future_no_operational", gates["gates"][-1]["current"] == "NOT_AUTHORIZED")
check("history_status", history["status"] == "PASS_WITH_TERMINAL_TREE_PERMISSION_LIMITATION")
check("history_no_mutation", history["historical_mutations"] == 0)
check("v2_unknown", history["recovery_v2"] == "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY")
check("risk_count", risks["risk_count"] == len(risks["risks"]) == 20)
check("risks_fail_closed", risks["all_fail_closed"] and all(item["failure"] == "BLOCK" for item in risks["risks"]))
check("negative_count", negative["case_count"] == len(negative["cases"]) == 39)
check("negative_disposition", negative["expected_disposition"] == "ALL_REJECTED_FAIL_CLOSED")

locked = prelock["locked_artifacts"]
check("prelock_status", prelock["status"] == "PRE_DECISION_ARTIFACTS_LOCKED_FOR_VALIDATION")
check("prelock_count", prelock["locked_artifact_count"] == len(locked))
for name, digest in locked.items():
    check("prelock_" + name, sha(ROOT / name) == digest)

failed = [name for name, result in checks if not result]
negative_total = len(negative["cases"])
output = {
    "schema_version": 1,
    "validator": "recovery_v3_toolchain_erratum_governance_self_test_v1",
    "status": "PASS" if not failed else "FAIL",
    "passed": len(checks) - len(failed),
    "failed": len(failed),
    "total": len(checks),
    "negative_tests_passed": negative_total if not failed else 0,
    "negative_tests_failed": 0 if not failed else negative_total,
    "negative_tests_total": negative_total,
    "failed_checks": failed,
    "operational_counts": {
        "dotnet_nuget_build_restore_or_tests": 0,
        "pfx_content_reads": 0,
        "cleanup_operations": 0,
        "windows_actions": 0,
        "vboxmanage_invocations": 0,
        "guard_executions": 0,
        "recovery_executions": 0,
    },
}
print(json.dumps(output, indent=2, sort_keys=True))
raise SystemExit(1 if failed else 0)
