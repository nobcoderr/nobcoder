#!/usr/bin/env python3
"""Verify the immutable governance-only freeze without opening PFX content."""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"
SUCCESSOR = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v2-20261014")
PFX = Path("/home/nobcoder/.dotnet/corefx/cryptography/x509stores/my/6C1DA3DE00985BC59141C2F29474051A5FBD85EB.pfx")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


manifest = load(MANIFEST)
lock = load(LOCK)
members = sorted(item.name for item in ROOT.iterdir() if item.is_file() and not item.is_symlink() and item.name != LOCK.name)
ledger = b"".join(f"{sha(ROOT / name)}  {name}\n".encode("utf-8") for name in members)
root_digest = hashlib.sha256(ledger).hexdigest()
listed = manifest["files"]
pfx_stat = PFX.stat()
checks = {
    "root_real_directory": ROOT.is_dir() and not ROOT.is_symlink(),
    "manifest_hash": sha(MANIFEST) == lock["artifact_manifest_sha256"],
    "manifest_coverage": set(listed) == {name for name in members if name != MANIFEST.name},
    "manifest_count": manifest["file_count"] == len(listed),
    "manifest_member_hashes": all(sha(ROOT / name) == digest for name, digest in listed.items()),
    "canonical_root": root_digest == lock["artifact_root_sha256"],
    "lock_status": lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY",
    "terminal_disposition_hash": sha(ROOT / "TERMINAL_IMPLEMENTATION_DISPOSITION.json") == lock["terminal_implementation_disposition_sha256"],
    "incident_hash": sha(ROOT / "INCIDENT_EVIDENCE.json") == lock["incident_evidence_sha256"],
    "sensitive_decision_hash": sha(ROOT / "SENSITIVE_MATERIAL_HANDLING_DECISION.json") == lock["sensitive_material_handling_decision_sha256"],
    "successor_decision_hash": sha(ROOT / "SUCCESSOR_AUTHORIZATION_DECISION.json") == lock["successor_authorization_decision_sha256"],
    "successor_identity_hash": sha(ROOT / "SUCCESSOR_IDENTITY_BINDING.json") == lock["successor_identity_binding_sha256"],
    "successor_path_hash": sha(ROOT / "SUCCESSOR_PATH_BINDING.json") == lock["successor_path_binding_sha256"],
    "confinement_hash": sha(ROOT / "FILESYSTEM_CONFINEMENT_CONTRACT.json") == lock["filesystem_confinement_contract_sha256"],
    "dependency_hash": sha(ROOT / "DEPENDENCY_AND_NETWORK_POLICY.json") == lock["dependency_and_network_policy_sha256"],
    "repair_hash": sha(ROOT / "TEST_REPAIR_SCOPE.json") == lock["test_repair_scope_sha256"],
    "self_test_hash": sha(ROOT / "GOVERNANCE_TEST_RESULT.json") == lock["governance_test_result_sha256"],
    "negative_test_hash": sha(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json") == lock["negative_governance_test_result_sha256"],
    "independent_hash": sha(ROOT / "INDEPENDENT_VALIDATION_RESULT.json") == lock["independent_validation_result_sha256"],
    "files_read_only": all(not item.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH) for item in ROOT.iterdir() if item.is_file()),
    "directory_read_only": not ROOT.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH),
    "no_symlinks": not any(item.is_symlink() for item in ROOT.iterdir()),
    "successor_not_created": not SUCCESSOR.exists() and not SUCCESSOR.is_symlink(),
    "pfx_metadata_only_still_present": PFX.is_file() and pfx_stat.st_size == 2383 and stat.S_IMODE(pfx_stat.st_mode) == 0o600,
    "no_operational_authorization": not (ROOT / "RECOVERY_V3_OPERATIONAL_AUTHORIZATION.json").exists(),
    "no_broker_deployment_authorization": not (ROOT / "BROKER_DEPLOYMENT_AUTHORIZATION.json").exists(),
    "no_guard_v3_authorization": not (ROOT / "GUARD_V3_IMPLEMENTATION_AUTHORIZATION.json").exists(),
    "no_windows_authorization": not (ROOT / "WINDOWS_TRANSFER_AUTHORIZATION.json").exists(),
}
failed = [name for name, value in checks.items() if not value]
print(json.dumps({
    "schema_version": 1,
    "validator": "recovery_v3_toolchain_erratum_governance_freeze_verifier_v1",
    "status": "PASS" if not failed else "FAIL",
    "checks_total": len(checks),
    "checks_passed": len(checks) - len(failed),
    "checks_failed": len(failed),
    "artifact_manifest_sha256": sha(MANIFEST),
    "canonical_root_sha256": root_digest,
    "governance_lock_sha256": sha(LOCK),
    "failed_checks": failed,
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(1 if failed else 0)
