#!/usr/bin/env python3
"""Issue and freeze compatibility-execution authorization after all gates pass."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
FUTURE = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v1-20261017")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_AUTHORIZATION_GOVERNANCE_V1"
MILESTONE = "AUTHORIZE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_ONLY"
FUTURE_IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1"
FUTURE_MILESTONE = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V1_ONCE_IF_ALL_GATES_PASS"
CODEX_RUNTIME_ID = "CODEX_RUNTIME_V1_CANDIDATE_0_162_1_LINUX_X86_64_MUSL"
OPERATION_KEYS = (
    "compatibility_suite_executions", "runtime_invocations", "codex_cli_invocations",
    "daybreak_invocations", "future_runtime_invocations", "worker_processes",
    "subagent_processes", "credential_operations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
)
FALSE_FIELDS = (
    "daybreak_invocation_authorized", "future_runtime_invocation_authorized",
    "worker_execution_authorized", "subagent_execution_authorized",
    "credential_use_authorized", "target_access_authorized",
    "external_network_authorized", "exploit_replay_authorized",
    "parallelism_authorized", "capability_graph_authorized",
    "candidate_promotion_authorized", "submission_automation_authorized",
)
PREFINAL = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "EXECUTION_IDENTITY_AND_PATH_BINDING.json", "COMPATIBILITY_EXECUTION_AUTHORIZATION_SCOPE.json",
    "RUNTIME_IDENTITY_ALLOWLIST.json", "CODEX_CLI_0_162_1_COMPATIBILITY_ADMISSION.json",
    "DAYBREAK_AND_FUTURE_RUNTIME_ADMISSION_POLICY.json", "COMPATIBILITY_SUITE_BINDING.json",
    "RUNTIME_INVOCATION_BOUNDARY.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "ATTEMPT_AND_RETRY_POLICY.json",
    "EVIDENCE_AND_FREEZE_REQUIREMENTS.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "PRIMARY_GOVERNANCE_VALIDATION_RESULT.json",
    "INDEPENDENT_VALIDATION_RESULT.json",
}
FINAL_RECORDS = {"COMPATIBILITY_EXECUTION_AUTHORIZATION_LOCK.json", "NEXT_LEGAL_MILESTONE.json"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def write_once(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def rows_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda item: str(item["path"]))
    ).encode()
    return hashlib.sha256(material).hexdigest()


def zeros() -> dict[str, int]:
    return {key: 0 for key in OPERATION_KEYS}


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != PREFINAL:
        raise SystemExit(f"unexpected prefinal set extra={sorted(actual-PREFINAL)} missing={sorted(PREFINAL-actual)}")
    primary = load("PRIMARY_GOVERNANCE_VALIDATION_RESULT.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT.json")
    if any(result.get("status") != "PASS" for result in (primary, negative, independent)):
        raise SystemExit("mandatory validation did not pass")
    if primary.get("checks_failed") != 0 or negative.get("tests_failed") != 0 or independent.get("checks_failed") != 0:
        raise SystemExit("validation failure count nonzero")
    if FUTURE.exists() or FUTURE.is_symlink():
        raise SystemExit("future execution path collision")
    scope = load("COMPATIBILITY_EXECUTION_AUTHORIZATION_SCOPE.json")
    snapshot = scope.get("authorization_snapshot", {})
    if snapshot.get("operations_this_governance_milestone") != zeros():
        raise SystemExit("governance operation counters are not zero")
    if any(snapshot.get(field) is not False for field in FALSE_FIELDS):
        raise SystemExit("forbidden authority present")
    if not all(snapshot.get(field) is True for field in (
        "compatibility_execution_authorized", "compatibility_suite_execution_authorized",
        "identity_bound_runtime_invocation_authorized", "codex_cli_compatibility_invocation_authorized",
    )):
        raise SystemExit("narrow compatibility authority missing")
    if snapshot.get("runtime_invocation_scope") != "COMPATIBILITY_VALIDATION_ONLY":
        raise SystemExit("runtime scope mismatch")
    if snapshot.get("codex_runtime_id") != CODEX_RUNTIME_ID or snapshot.get("codex_version") != "0.162.1":
        raise SystemExit("Codex identity mismatch")
    if snapshot.get("daybreak_availability") != "NOT_DISCOVERED" or snapshot.get("daybreak_invocation_authorized") is not False:
        raise SystemExit("Daybreak state mismatch")
    if snapshot.get("future_attempt_count") != 0:
        raise SystemExit("future attempt already consumed")

    authorization = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_EXECUTION_AUTHORIZATION_LOCK",
        "schema_version": "1.0", "governance_identity": IDENTITY, "milestone": MILESTONE,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": "AUTHORIZE_IDENTITY_BOUND_COMPATIBILITY_EXECUTION_ONLY",
        "authorized_milestone": FUTURE_MILESTONE,
        "future_execution_identity": FUTURE_IDENTITY,
        "future_execution_path": str(FUTURE),
        "future_execution_state": "AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "authority_ceiling": "COMPATIBILITY_VALIDATION_ONLY",
        "compatibility_execution_authorized": True,
        "compatibility_suite_execution_authorized": True,
        "identity_bound_runtime_invocation_authorized": True,
        "runtime_invocation_scope": "COMPATIBILITY_VALIDATION_ONLY",
        "codex_cli_compatibility_invocation_authorized": True,
        "codex_runtime_id": CODEX_RUNTIME_ID,
        "codex_version": "0.162.1",
        "codex_binary_sha256": snapshot["codex_binary_sha256"],
        "codex_configuration_sha256": snapshot["codex_configuration_sha256"],
        "codex_compatibility_state": "NOT_ESTABLISHED",
        "codex_invocation_count": 0,
        "suite_identity": snapshot["suite_identity"],
        "suite_case_count": snapshot["suite_case_count"],
        "suite_execution_count": 0,
        "attempt_limit_per_admitted_runtime_identity": 1,
        "automatic_retry": False,
        "daybreak_availability": "NOT_DISCOVERED",
        "daybreak_compatibility": "NOT_ESTABLISHED",
        "daybreak_invocation_count": 0,
        "provider_transport_authorized": False,
        "external_network_policy": "DENY_ALL",
        **{field: False for field in FALSE_FIELDS},
        "operations_this_governance_milestone": zeros(),
        "future_attempt_count": 0,
    }
    next_legal = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_EXECUTION_NEXT_LEGAL_MILESTONE",
        "schema_version": "1.0", "governance_identity": IDENTITY, "milestone": MILESTONE,
        "next_legal_milestone": FUTURE_MILESTONE,
        "future_execution_identity": FUTURE_IDENTITY,
        "future_execution_path": str(FUTURE),
        "status": "AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "required_sequence": [
            "CREATE_FRESH_EXECUTION_WORKSPACE", "IMPLEMENT_EXACT_SUITE_RUNNER", "PRIMARY_STATIC_VALIDATION",
            "INDEPENDENT_STATIC_VALIDATION", "FRESH_PREFLIGHT", "EXACT_RUNTIME_ARGV_ENVIRONMENT_BINDING",
            "STATIC_LOCK", "LOCK_VERIFICATION", "ATTEMPT_MARKER_AFTER_ALL_GATES",
            "ONE_IDENTITY_BOUND_COMPATIBILITY_EXECUTION", "INDEPENDENT_POST_VALIDATION",
            "EVIDENCE_FREEZE", "STOP_FOR_SEPARATE_ACCEPTANCE_ADJUDICATION",
        ],
        "worker_subagent_target_credential_network_authority": "NONE",
        "daybreak_authority": "NONE_UNTIL_SEPARATE_AVAILABILITY_AND_IDENTITY_BINDING",
    }
    write_once("COMPATIBILITY_EXECUTION_AUTHORIZATION_LOCK.json", authorization)
    write_once("NEXT_LEGAL_MILESTONE.json", next_legal)

    member_names = PREFINAL | FINAL_RECORDS
    members = [
        {"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size}
        for name in sorted(member_names)
    ]
    member_root = rows_root(members)
    manifest = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "member_count": len(members), "members": members,
        "canonical_member_root_sha256": member_root,
        "self_referential_hashes": False,
    }
    write_once("GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest_sha = sha(manifest_path)
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}])
    lock = {
        "record_type": "V0_3_RUNTIME_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_LOCK",
        "schema_version": "1.0", "governance_identity": IDENTITY, "milestone": MILESTONE,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": "AUTHORIZE_IDENTITY_BOUND_COMPATIBILITY_EXECUTION_ONLY",
        "authorized_milestone": FUTURE_MILESTONE,
        "future_execution_identity": FUTURE_IDENTITY,
        "future_execution_path": str(FUTURE),
        "future_execution_state": "AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "authority_ceiling": "COMPATIBILITY_VALIDATION_ONLY",
        "governance_manifest_sha256": manifest_sha,
        "canonical_member_root_sha256": member_root,
        "canonical_artifact_root_sha256": artifact_root,
        "root_member_count": len(members) + 1,
        "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 1},
        "validation_counts": {
            "primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
            "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
            "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
        },
        "compatibility_execution_authorized": True,
        "compatibility_suite_execution_authorized": True,
        "identity_bound_runtime_invocation_authorized": True,
        "codex_cli_compatibility_invocation_authorized": True,
        "codex_runtime_id": CODEX_RUNTIME_ID,
        "codex_compatibility_state": "NOT_ESTABLISHED",
        "daybreak_availability": "NOT_DISCOVERED",
        "daybreak_invocation_authorized": False,
        "provider_transport_authorized": False,
        **{field: False for field in FALSE_FIELDS if field != "daybreak_invocation_authorized"},
        "operations_this_governance_milestone": zeros(),
        "future_attempt_count": 0,
        "final_freeze_verification_required": True,
    }
    write_once("GOVERNANCE_LOCK.json", lock)
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": lock["status"], "decision": lock["decision"],
        "manifest_members": len(members), "root_members": len(members) + 1,
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"),
    }, sort_keys=True))


if __name__ == "__main__":
    main()
