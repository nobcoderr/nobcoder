#!/usr/bin/env python3
"""Independent validation of compatibility-execution authorization."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
CONTRACT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-contract-v2-20261017")
SUBSTRATE = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v5-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261017")
FUTURE = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v1-20261017")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_AUTHORIZATION_GOVERNANCE_V1"
MILESTONE = "AUTHORIZE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_ONLY"
FUTURE_IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1"
SUITE_IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V2"
CODEX_RUNTIME_ID = "CODEX_RUNTIME_V1_CANDIDATE_0_162_1_LINUX_X86_64_MUSL"
OPERATION_KEYS = {
    "compatibility_suite_executions", "runtime_invocations", "codex_cli_invocations",
    "daybreak_invocations", "future_runtime_invocations", "worker_processes",
    "subagent_processes", "credential_operations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
}
FORBIDDEN_FIELDS = {
    "worker_execution_authorized", "subagent_execution_authorized", "credential_use_authorized",
    "target_access_authorized", "external_network_authorized", "exploit_replay_authorized",
    "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized", "daybreak_invocation_authorized",
    "future_runtime_invocation_authorized",
}
EXPECTED_INPUTS = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "EXECUTION_IDENTITY_AND_PATH_BINDING.json", "COMPATIBILITY_EXECUTION_AUTHORIZATION_SCOPE.json",
    "RUNTIME_IDENTITY_ALLOWLIST.json", "CODEX_CLI_0_162_1_COMPATIBILITY_ADMISSION.json",
    "DAYBREAK_AND_FUTURE_RUNTIME_ADMISSION_POLICY.json", "COMPATIBILITY_SUITE_BINDING.json",
    "RUNTIME_INVOCATION_BOUNDARY.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "ATTEMPT_AND_RETRY_POLICY.json",
    "EVIDENCE_AND_FREEZE_REQUIREMENTS.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "PRIMARY_GOVERNANCE_VALIDATION_RESULT.json",
}


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def zero(value: Any) -> bool:
    return isinstance(value, dict) and set(value) == OPERATION_KEYS and all(value[key] == 0 for key in OPERATION_KEYS)


def main() -> None:
    if (ROOT / "INDEPENDENT_VALIDATION_RESULT.json").exists():
        raise SystemExit("independent result already exists")
    actual = {path.name for path in ROOT.glob("*.json")}
    if actual != EXPECTED_INPUTS:
        raise SystemExit(f"unexpected inputs extra={sorted(actual-EXPECTED_INPUTS)} missing={sorted(EXPECTED_INPUTS-actual)}")
    records = {name: load(name) for name in EXPECTED_INPUTS}
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in ("build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py"):
        try:
            okay = ast.parse((ROOT / script).read_text(encoding="utf-8")) is not None
        except Exception:
            okay = False
        check(f"I_SYNTAX_{script}", okay, sha(ROOT / script))
    check("I005_IDENTITY_UNIFORM", all(value.get("governance_identity") == IDENTITY for value in records.values()))
    check("I006_FUTURE_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    primary = records["PRIMARY_GOVERNANCE_VALIDATION_RESULT.json"]
    negative = records["NEGATIVE_GOVERNANCE_TEST_RESULT.json"]
    check("I007_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0 and primary.get("checks_total") == primary.get("checks_passed"))
    check("I008_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 60 and negative.get("tests_failed") == 0)
    check("I009_NEGATIVE_REJECT", all(row.get("actual") == "REJECT" and row.get("status") == "PASS" for row in negative.get("results", [])))
    scope = records["COMPATIBILITY_EXECUTION_AUTHORIZATION_SCOPE.json"]
    snap = scope.get("authorization_snapshot", {})
    check("I010_DECISION", scope.get("decision") == "AUTHORIZE_IDENTITY_BOUND_COMPATIBILITY_EXECUTION_ONLY")
    check("I011_AUTH_CEILING", scope.get("authority_ceiling") == "COMPATIBILITY_VALIDATION_ONLY")
    check("I012_COMPAT_AUTH", snap.get("compatibility_execution_authorized") is True and snap.get("compatibility_suite_execution_authorized") is True)
    check("I013_IDENTITY_BOUND_AUTH", snap.get("identity_bound_runtime_invocation_authorized") is True)
    check("I014_RUNTIME_SCOPE", snap.get("runtime_invocation_scope") == "COMPATIBILITY_VALIDATION_ONLY")
    check("I015_CODEX_AUTH", snap.get("codex_cli_compatibility_invocation_authorized") is True)
    check("I016_CODEX_RUNTIME_ID", snap.get("codex_runtime_id") == CODEX_RUNTIME_ID)
    check("I017_CODEX_VERSION", snap.get("codex_version") == "0.162.1")
    check("I018_CODEX_DIGESTS", isinstance(snap.get("codex_binary_sha256"), str) and len(snap["codex_binary_sha256"]) == 64 and isinstance(snap.get("codex_configuration_sha256"), str) and len(snap["codex_configuration_sha256"]) == 64)
    check("I019_CODEX_NOT_ESTABLISHED", snap.get("codex_compatibility_state_before_execution") == "NOT_ESTABLISHED")
    check("I020_SUITE_IDENTITY", snap.get("suite_identity") == SUITE_IDENTITY and snap.get("suite_case_count") == 24)
    check("I021_ONE_ATTEMPT", snap.get("suite_attempt_limit_per_admitted_runtime_identity") == 1 and snap.get("automatic_retry") is False)
    check("I022_DAYBREAK_NOT_DISCOVERED", snap.get("daybreak_availability") == "NOT_DISCOVERED" and snap.get("daybreak_compatibility") == "NOT_ESTABLISHED")
    check("I023_DAYBREAK_NOT_AUTH", snap.get("daybreak_invocation_authorized") is False)
    check("I024_FUTURE_RUNTIME_NOT_AUTH", snap.get("future_runtime_invocation_authorized") is False)
    check("I025_PROVIDER_TRANSPORT_NOT_AUTH", snap.get("provider_transport_authorized") is False)
    check("I026_NO_UNSANDBOXED", snap.get("unsandboxed_fallback") is False)
    check("I027_FORBIDDEN_FIELDS_FALSE", all(snap.get(field) is False for field in FORBIDDEN_FIELDS))
    check("I028_GOVERNANCE_COUNTERS_ZERO", zero(snap.get("operations_this_governance_milestone")))
    check("I029_FUTURE_ATTEMPT_ZERO", snap.get("future_attempt_count") == 0)

    allowlist = records["RUNTIME_IDENTITY_ALLOWLIST.json"]
    admitted = allowlist.get("admitted_runtimes", [])
    check("I030_ALLOWLIST_DEFAULT_DENY", allowlist.get("default") == "DENY" and allowlist.get("unknown_runtime") == "REJECT")
    check("I031_ALLOWLIST_ONE", allowlist.get("admitted_runtime_count") == len(admitted) == 1)
    check("I032_ALLOWLIST_CODEX", admitted[0].get("runtime_id") == CODEX_RUNTIME_ID and admitted[0].get("version") == "0.162.1")
    check("I033_ALLOWLIST_SCOPE", admitted[0].get("invocation_scope") == "COMPATIBILITY_VALIDATION_ONLY" and admitted[0].get("attempt_limit") == 1)
    check("I034_DAYBREAK_NOT_ADMITTED", allowlist.get("daybreak") == "NOT_ADMITTED_NOT_DISCOVERED")
    check("I035_FUTURE_NOT_ADMITTED", allowlist.get("future_runtime") == "NOT_ADMITTED")
    codex = records["CODEX_CLI_0_162_1_COMPATIBILITY_ADMISSION.json"]
    check("I036_CODEX_CANDIDATE", codex.get("candidate_status") == "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED" and codex.get("compatibility_state") == "NOT_ESTABLISHED")
    check("I037_CODEX_COUNTER_ZERO", codex.get("invocation_count_before_future_execution") == 0)
    check("I038_CODEX_WORKER_FALSE", codex.get("worker_or_target_use_authorized") is False)
    check("I039_CODEX_TRANSPORT_FALSE", codex.get("provider_transport_authorized") is False)
    unbound = records["DAYBREAK_AND_FUTURE_RUNTIME_ADMISSION_POLICY.json"]
    check("I040_DAYBREAK_POLICY", unbound.get("daybreak", {}).get("availability_state") == "NOT_DISCOVERED" and unbound.get("daybreak", {}).get("invocation_authorized") is False)
    check("I041_FUTURE_POLICY", unbound.get("future_runtime", {}).get("availability_state") == "NOT_DISCOVERED" and unbound.get("future_runtime", {}).get("invocation_authorized") is False)
    check("I042_NO_AVAILABILITY_INFERENCE", unbound.get("availability_may_be_inferred") is False)

    suite = records["COMPATIBILITY_SUITE_BINDING.json"]
    check("I043_SUITE_BINDING", suite.get("suite_identity") == SUITE_IDENTITY and suite.get("case_count") == 24)
    check("I044_SUITE_NOT_RUN_NOW", suite.get("execution_this_governance_milestone") is False)
    boundary = records["RUNTIME_INVOCATION_BOUNDARY.json"]
    check("I045_NOT_WORKER_AUTH", boundary.get("runtime_invocation_is_general_worker_authority") is False)
    check("I046_NOT_TARGET_AUTH", boundary.get("runtime_invocation_is_target_authority") is False)
    check("I047_NETWORK_DENY", boundary.get("external_network_policy") == "DENY_ALL")
    check("I048_SANDBOX_REQUIRED", boundary.get("sandbox") == "RUNTIME_SUBSTRATE_V5_PASS_LOCKED_REQUIRED")
    check("I049_UNSANDBOXED_PROHIBITED", boundary.get("unsandboxed_fallback") == "PROHIBITED")
    check("I050_STRUCTURED_ONLY", boundary.get("structured_input_only") is True)
    check("I051_OUTPUT_NOT_FINDING", boundary.get("structured_output_is_authoritative_finding") is False)

    authority = records["AUTHORITY_NON_ESCALATION_DECISION.json"]
    check("I052_AUTH_SNAPSHOT_MATCH", authority.get("authorization_snapshot") == snap)
    check("I053_PASS_NOT_WORKER", authority.get("compatibility_pass_effect") == "RUNTIME_MAY_BECOME_ELIGIBLE_FOR_SEPARATE_ACCEPTANCE_ONLY")
    check("I054_NO_WORKER_EFFECT", authority.get("worker_execution_effect") == "NONE")
    check("I055_NO_TARGET_EFFECT", authority.get("target_or_credential_effect") == "NONE")
    matrix = records["OPERATION_AUTHORIZATION_MATRIX.json"]
    check("I056_MATRIX_ONLY_TWO", matrix.get("future_authorized") == {"compatibility_suite_execution": True, "identity_bound_codex_runtime_invocation": True})
    check("I057_MATRIX_GOV_ZERO", zero(matrix.get("current_governance_operations")))
    check("I058_MATRIX_DEFERRED_FALSE", set(matrix.get("forbidden_or_deferred", {})) == FORBIDDEN_FIELDS and all(value is False for value in matrix.get("forbidden_or_deferred", {}).values()))
    attempt = records["ATTEMPT_AND_RETRY_POLICY.json"]
    check("I059_ATTEMPT_ZERO", attempt.get("future_attempt_count") == 0)
    check("I060_ATTEMPT_LIMIT", attempt.get("attempt_limit_per_admitted_runtime_identity") == 1)
    check("I061_NO_RETRY", attempt.get("automatic_retry") is False and attempt.get("terminal_attempt_replay") == "PROHIBITED")
    evidence = records["EVIDENCE_AND_FREEZE_REQUIREMENTS.json"]
    check("I062_EVIDENCE_REQUIRED", len(evidence.get("required", [])) == 12)
    check("I063_NO_SELF_CERTIFY", evidence.get("runtime_output_can_self_certify") is False)
    check("I064_SEPARATE_ACCEPTANCE", evidence.get("separate_acceptance_after_execution") is True)
    binding = records["EXECUTION_IDENTITY_AND_PATH_BINDING.json"]
    check("I065_FUTURE_BINDING", binding.get("future_execution_identity") == FUTURE_IDENTITY and binding.get("future_execution_path") == str(FUTURE))
    check("I066_FUTURE_ABSENT_STATE", binding.get("future_execution_path_state") == "ABSENT_AUTHORIZED_NOT_CREATED")
    predecessor = records["PREDECESSOR_CHAIN_BINDING.json"]
    check("I067_PREDECESSORS_IMMUTABLE", predecessor.get("predecessors_immutable") is True)
    check("I068_CONTRACT_ANCHOR", predecessor.get("compatibility_contract_v2", {}).get("governance_lock_sha256") == sha(CONTRACT / "GOVERNANCE_LOCK.json"))
    check("I069_SUBSTRATE_ANCHOR", predecessor.get("runtime_substrate_v5", {}).get("governance_lock_sha256") == sha(SUBSTRATE / "GOVERNANCE_LOCK.json"))
    routing = records["ROUTING_AND_SCOPE_DECISION.json"]
    check("I070_NO_RUNTIME_NOW", routing.get("runtime_execution") == "NONE")
    check("I071_NO_NETWORK_NOW", routing.get("network_access") == "NONE")
    check("I072_NO_SUBAGENTS", routing.get("subagents") == "NOT_USED")
    check("I073_AUTH_FALSE_ROUTE", routing.get("authentication_hunter_route") == "NOT_APPLICABLE_SCHEMA_AUTHORIZATION_NOT_AUTH_TARGET")
    check("I074_WEB3_FALSE_ROUTE", routing.get("web3_route") == "NOT_APPLICABLE_FALSE_KEYWORD_MATCH_NO_WEB3_TARGET_EVIDENCE")

    # Independent drift challenges; no reuse of the primary validator.
    challenge = copy = dict(snap)
    copy["worker_execution_authorized"] = True
    check("I075_WORKER_DRIFT_DETECTED", copy != snap and copy["worker_execution_authorized"] is True)
    copy2 = dict(snap)
    copy2["codex_runtime_id"] = "UNPINNED"
    check("I076_IDENTITY_DRIFT_DETECTED", copy2 != snap and copy2["codex_runtime_id"] != CODEX_RUNTIME_ID)
    copy3 = dict(snap)
    copy3["daybreak_invocation_authorized"] = True
    check("I077_DAYBREAK_DRIFT_DETECTED", copy3 != snap and copy3["daybreak_availability"] == "NOT_DISCOVERED")
    check("I078_OPERATION_KEYS_EXACT", set(snap.get("operations_this_governance_milestone", {})) == OPERATION_KEYS)
    check("I079_CONTRACT_LOCK_HASH", sha(CONTRACT / "GOVERNANCE_LOCK.json") == "f083b7bc2756d9052c8c66bc6fb8ed3f3b42aacf54ac1b914d3e2e1270b3a363")
    check("I080_SUBSTRATE_LOCK_HASH", sha(SUBSTRATE / "GOVERNANCE_LOCK.json") == "8383ec457c0838fba668693ae9c837edf1a8c50222c524176dc60b9afda9191e")

    failed = [row for row in checks if row["status"] != "PASS"]
    result = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0", "governance_identity": IDENTITY, "milestone": MILESTONE,
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "checks": checks,
        "validator_independence": "SEPARATE_IMPLEMENTATION_NO_IMPORT_FROM_PRIMARY",
        "operations_this_governance_milestone": snap.get("operations_this_governance_milestone", {}),
    }
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"status": result["status"], "checks_total": len(checks), "checks_failed": len(failed)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
