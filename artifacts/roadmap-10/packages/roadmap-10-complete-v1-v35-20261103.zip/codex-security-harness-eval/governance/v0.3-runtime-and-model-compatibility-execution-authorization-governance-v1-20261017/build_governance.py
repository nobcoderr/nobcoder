#!/usr/bin/env python3
"""Build governance-only compatibility-execution authorization.

This script reads frozen predecessors and writes only governance records in its
own directory.  It does not invoke Codex, Daybreak, any runtime, compatibility
suite, worker, target, credential, or network operation.
"""

from __future__ import annotations

import ast
import copy
import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder/codex-security-harness-eval/governance")
CONTRACT = BASE / "v0.3-runtime-and-model-compatibility-contract-v2-20261017"
SUBSTRATE = BASE / "v0.3-runtime-substrate-validation-v5-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261017"
FUTURE = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v1-20261017")

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_AUTHORIZATION_GOVERNANCE_V1"
MILESTONE = "AUTHORIZE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_ONLY"
FUTURE_IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1"
FUTURE_MILESTONE = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V1_ONCE_IF_ALL_GATES_PASS"
SUITE_IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V2"
CODEX_RUNTIME_ID = "CODEX_RUNTIME_V1_CANDIDATE_0_162_1_LINUX_X86_64_MUSL"

ANCHORS = {
    "contract_lock": "f083b7bc2756d9052c8c66bc6fb8ed3f3b42aacf54ac1b914d3e2e1270b3a363",
    "contract_manifest": "6234ab0c6e31c81551394bce8a110a9145656cec6d10bb3c0aca660a331e2e31",
    "contract_artifact_root": "e4cbefd952cac927b8c63e5d9f601b953caefbccabc9412a43ebabc793ecc95d",
    "contract_contract_lock": "d803d51bda01efed556105f8ec7aa413c4aa73d11976ab14428c2b431fbd7522",
    "contract_contract_manifest": "0681d0aecd263f846d08b07fa3ccf89d7daf309d1dd62be5cee0f8383d597f14",
    "substrate_lock": "8383ec457c0838fba668693ae9c837edf1a8c50222c524176dc60b9afda9191e",
    "substrate_manifest": "4eb6624c1ff98d36f358caa62181c7fa5a0c654335dc583753cd0946e1490e1c",
    "substrate_artifact_root": "19586d5dc41bd7068fe191db62d8f3b0b4b4007eacb437257728c0356bf62f99",
}

OPERATION_KEYS = (
    "compatibility_suite_executions", "runtime_invocations", "codex_cli_invocations",
    "daybreak_invocations", "future_runtime_invocations", "worker_processes",
    "subagent_processes", "credential_operations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
)

FORBIDDEN_AUTHORITY_FIELDS = (
    "worker_execution_authorized", "subagent_execution_authorized",
    "credential_use_authorized", "target_access_authorized",
    "external_network_authorized", "exploit_replay_authorized",
    "parallelism_authorized", "capability_graph_authorized",
    "candidate_promotion_authorized", "submission_automation_authorized",
    "daybreak_invocation_authorized", "future_runtime_invocation_authorized",
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def rows_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda item: str(item["path"]))
    ).encode()
    return hashlib.sha256(material).hexdigest()


def verify_governance(root: Path, lock_sha: str, manifest_sha: str, artifact_root: str) -> dict[str, Any]:
    if not root.is_dir() or root.is_symlink() or not ro(root):
        raise SystemExit(f"invalid frozen predecessor root: {root}")
    lock_path = root / "GOVERNANCE_LOCK.json"
    manifest_path = root / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    if sha(lock_path) != lock_sha or sha(manifest_path) != manifest_sha:
        raise SystemExit(f"predecessor anchor mismatch: {root}")
    lock = load(lock_path)
    manifest = load(manifest_path)
    rows = manifest.get("members")
    if not isinstance(rows, list) or not rows:
        raise SystemExit(f"invalid predecessor manifest: {root}")
    for row in rows:
        path = root / str(row.get("path", ""))
        if not path.is_file() or path.is_symlink() or not ro(path):
            raise SystemExit(f"invalid predecessor member: {path}")
        if path.stat().st_size != row.get("bytes") or sha(path) != row.get("sha256"):
            raise SystemExit(f"predecessor member mismatch: {path}")
    if rows_root(rows) != manifest.get("canonical_member_root_sha256"):
        raise SystemExit(f"predecessor member root mismatch: {root}")
    artifact_rows = rows + [{"path": manifest_path.name, "sha256": sha(manifest_path), "bytes": manifest_path.stat().st_size}]
    if rows_root(artifact_rows) != artifact_root or lock.get("canonical_artifact_root_sha256") != artifact_root:
        raise SystemExit(f"predecessor artifact root mismatch: {root}")
    return lock


def zeros() -> dict[str, int]:
    return {key: 0 for key in OPERATION_KEYS}


def write_once(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def authorization_snapshot(codex: dict[str, Any], suite: dict[str, Any]) -> dict[str, Any]:
    return {
        "governance_identity": IDENTITY,
        "milestone": MILESTONE,
        "decision": "AUTHORIZE_IDENTITY_BOUND_COMPATIBILITY_EXECUTION_ONLY",
        "future_execution_identity": FUTURE_IDENTITY,
        "future_execution_path": str(FUTURE),
        "future_execution_state": "AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "future_execution_milestone": FUTURE_MILESTONE,
        "compatibility_execution_authorized": True,
        "compatibility_suite_execution_authorized": True,
        "identity_bound_runtime_invocation_authorized": True,
        "runtime_invocation_scope": "COMPATIBILITY_VALIDATION_ONLY",
        "codex_cli_compatibility_invocation_authorized": True,
        "codex_runtime_id": CODEX_RUNTIME_ID,
        "codex_version": "0.162.1",
        "codex_binary_sha256": codex["declared_binary_sha256"],
        "codex_configuration_sha256": codex["declared_configuration_sha256"],
        "codex_compatibility_state_before_execution": "NOT_ESTABLISHED",
        "suite_identity": SUITE_IDENTITY,
        "suite_case_count": suite["case_count"],
        "suite_attempt_limit_per_admitted_runtime_identity": 1,
        "automatic_retry": False,
        "daybreak_availability": "NOT_DISCOVERED",
        "daybreak_compatibility": "NOT_ESTABLISHED",
        "daybreak_invocation_authorized": False,
        "daybreak_admission": "REQUIRES_SEPARATE_AVAILABILITY_PROOF_IDENTITY_PIN_AND_GOVERNANCE_BINDING",
        "future_runtime_invocation_authorized": False,
        "provider_transport_authorized": False,
        "unsandboxed_fallback": False,
        "unknown_runtime_or_identity": "REJECT",
        "operations_this_governance_milestone": zeros(),
        "future_attempt_count": 0,
        **{field: False for field in FORBIDDEN_AUTHORITY_FIELDS if field not in {"daybreak_invocation_authorized", "future_runtime_invocation_authorized"}},
    }


def valid_authorization(value: dict[str, Any], expected: dict[str, Any]) -> bool:
    if value != expected:
        return False
    if value.get("compatibility_execution_authorized") is not True:
        return False
    if value.get("compatibility_suite_execution_authorized") is not True:
        return False
    if value.get("identity_bound_runtime_invocation_authorized") is not True:
        return False
    if value.get("runtime_invocation_scope") != "COMPATIBILITY_VALIDATION_ONLY":
        return False
    if value.get("codex_cli_compatibility_invocation_authorized") is not True:
        return False
    if value.get("codex_runtime_id") != CODEX_RUNTIME_ID or value.get("codex_version") != "0.162.1":
        return False
    if value.get("codex_compatibility_state_before_execution") != "NOT_ESTABLISHED":
        return False
    if value.get("suite_identity") != SUITE_IDENTITY or value.get("suite_case_count") != 24:
        return False
    if value.get("suite_attempt_limit_per_admitted_runtime_identity") != 1 or value.get("automatic_retry") is not False:
        return False
    if value.get("daybreak_availability") != "NOT_DISCOVERED" or value.get("daybreak_invocation_authorized") is not False:
        return False
    if value.get("future_runtime_invocation_authorized") is not False:
        return False
    if value.get("provider_transport_authorized") is not False or value.get("unsandboxed_fallback") is not False:
        return False
    if any(value.get(field) is not False for field in FORBIDDEN_AUTHORITY_FIELDS):
        return False
    operations = value.get("operations_this_governance_milestone")
    return isinstance(operations, dict) and operations == zeros() and value.get("future_attempt_count") == 0


def set_path(value: dict[str, Any], path: str, replacement: Any) -> None:
    value[path] = replacement


def negative_cases() -> list[tuple[str, str, Any]]:
    cases = [
        ("N001", "governance_identity", "WRONG"),
        ("N002", "milestone", "WRONG"),
        ("N003", "decision", "AUTHORIZE_GENERAL_RUNTIME"),
        ("N004", "future_execution_identity", "WRONG"),
        ("N005", "future_execution_path", "/tmp/execution"),
        ("N006", "future_execution_state", "EXECUTED"),
        ("N007", "future_execution_milestone", "RUN_WORKER"),
        ("N008", "compatibility_execution_authorized", False),
        ("N009", "compatibility_suite_execution_authorized", False),
        ("N010", "identity_bound_runtime_invocation_authorized", False),
        ("N011", "runtime_invocation_scope", "GENERAL_RUNTIME"),
        ("N012", "codex_cli_compatibility_invocation_authorized", False),
        ("N013", "codex_runtime_id", "UNPINNED_CODEX"),
        ("N014", "codex_version", "latest"),
        ("N015", "codex_binary_sha256", "0" * 64),
        ("N016", "codex_configuration_sha256", "0" * 64),
        ("N017", "codex_compatibility_state_before_execution", "PASS_LOCKED"),
        ("N018", "suite_identity", "WRONG_SUITE"),
        ("N019", "suite_case_count", 23),
        ("N020", "suite_attempt_limit_per_admitted_runtime_identity", 2),
        ("N021", "automatic_retry", True),
        ("N022", "daybreak_availability", "DISCOVERED"),
        ("N023", "daybreak_compatibility", "TESTED"),
        ("N024", "daybreak_invocation_authorized", True),
        ("N025", "daybreak_admission", "ASSUMED_AVAILABLE"),
        ("N026", "future_runtime_invocation_authorized", True),
        ("N027", "provider_transport_authorized", True),
        ("N028", "unsandboxed_fallback", True),
        ("N029", "unknown_runtime_or_identity", "ALLOW"),
        ("N030", "future_attempt_count", 1),
        ("N031", "worker_execution_authorized", True),
        ("N032", "subagent_execution_authorized", True),
        ("N033", "credential_use_authorized", True),
        ("N034", "target_access_authorized", True),
        ("N035", "external_network_authorized", True),
        ("N036", "exploit_replay_authorized", True),
        ("N037", "parallelism_authorized", True),
        ("N038", "capability_graph_authorized", True),
        ("N039", "candidate_promotion_authorized", True),
        ("N040", "submission_automation_authorized", True),
    ]
    for index, key in enumerate(OPERATION_KEYS, start=41):
        mutated = zeros()
        mutated[key] = 1
        cases.append((f"N{index:03d}", "operations_this_governance_milestone", mutated))
    cases.extend([
        ("N056", "codex_binary_sha256", "not-a-digest"),
        ("N057", "codex_configuration_sha256", "ABSENT"),
        ("N058", "suite_case_count", 25),
        ("N059", "runtime_invocation_scope", "WORKER_EXECUTION"),
        ("N060", "provider_transport_authorized", "IMPLICIT"),
    ])
    return cases


def main() -> None:
    allowed_initial = {"build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py"}
    actual_initial = {path.name for path in ROOT.iterdir()}
    if actual_initial != allowed_initial:
        raise SystemExit(f"unexpected initial set extra={sorted(actual_initial-allowed_initial)} missing={sorted(allowed_initial-actual_initial)}")
    contract_lock = verify_governance(
        CONTRACT, ANCHORS["contract_lock"], ANCHORS["contract_manifest"], ANCHORS["contract_artifact_root"]
    )
    substrate_lock = verify_governance(
        SUBSTRATE, ANCHORS["substrate_lock"], ANCHORS["substrate_manifest"], ANCHORS["substrate_artifact_root"]
    )
    if contract_lock.get("status") != "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY":
        raise SystemExit("Contract V2 not PASS_LOCKED")
    if contract_lock.get("next_legal_milestone") != MILESTONE:
        raise SystemExit("Contract V2 next milestone mismatch")
    if substrate_lock.get("decision") != "A_ACCEPT_AND_PROMOTE_RUNTIME_SUBSTRATE_V5_TO_PASS_LOCKED":
        raise SystemExit("Runtime Substrate V5 not accepted")
    if sha(CONTRACT / "CONTRACT_LOCK.json") != ANCHORS["contract_contract_lock"]:
        raise SystemExit("Contract V2 contract lock mismatch")
    if sha(CONTRACT / "CONTRACT_ARTIFACT_MANIFEST.json") != ANCHORS["contract_contract_manifest"]:
        raise SystemExit("Contract V2 contract manifest mismatch")
    if FUTURE.exists() or FUTURE.is_symlink():
        raise SystemExit("future execution path collision")

    codex = load(CONTRACT / "CODEX_CLI_0_162_1_CANDIDATE_BINDING.json")
    suite = load(CONTRACT / "COMPATIBILITY_SUITE_DEFINITION.json")
    authority_v2 = load(CONTRACT / "AUTHORITY_STATE.json")
    if codex.get("version") != "0.162.1" or codex.get("status") != "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED":
        raise SystemExit("Codex candidate binding mismatch")
    if codex.get("compatibility_state") != "NOT_ESTABLISHED" or codex.get("invocation_count") != 0:
        raise SystemExit("Codex candidate state mismatch")
    if suite.get("suite_identity") != SUITE_IDENTITY or suite.get("case_count") != 24 or suite.get("execution_count") != 0:
        raise SystemExit("compatibility suite binding mismatch")
    if any(authority_v2.get("operation_counters", {}).values()):
        raise SystemExit("Contract V2 operation counter nonzero")

    common = {"schema_version": "1.0", "governance_identity": IDENTITY, "milestone": MILESTONE}
    snapshot = authorization_snapshot(codex, suite)
    records: dict[str, dict[str, Any]] = {
        "ROUTING_AND_SCOPE_DECISION.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_AUTH_ROUTING_AND_SCOPE_DECISION",
            "allowed_this_milestone": ["GOVERNANCE_RECORDS", "PRIMARY_VALIDATION", "NEGATIVE_FIXTURES", "INDEPENDENT_VALIDATION", "FINAL_FREEZE"],
            "executed_this_milestone": [],
            "runtime_execution": "NONE",
            "network_access": "NONE",
            "credentials": "NONE",
            "subagents": "NOT_USED",
            "web3_route": "NOT_APPLICABLE_FALSE_KEYWORD_MATCH_NO_WEB3_TARGET_EVIDENCE",
            "authentication_hunter_route": "NOT_APPLICABLE_SCHEMA_AUTHORIZATION_NOT_AUTH_TARGET",
        },
        "ROUTING_LEDGER.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_AUTH_ROUTING_LEDGER",
            "active": ["mandatory-auto-router", "authorized-security-autopilot", "agentic-security-research-harness", "external-ai-security-tool-governor"],
            "deferred": ["compatibility-runtime-execution", "worker-execution", "target-access"],
            "not_applicable": ["web3-smart-contract-auditor", "expert-authentication-authorization-hunter"],
            "operational_automation_executed": False,
        },
        "PREDECESSOR_CHAIN_BINDING.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_AUTH_PREDECESSOR_CHAIN_BINDING",
            "compatibility_contract_v2": {
                "path": str(CONTRACT), "status": contract_lock["status"],
                "governance_lock_sha256": ANCHORS["contract_lock"],
                "governance_manifest_sha256": ANCHORS["contract_manifest"],
                "contract_lock_sha256": ANCHORS["contract_contract_lock"],
                "contract_manifest_sha256": ANCHORS["contract_contract_manifest"],
                "canonical_artifact_root_sha256": ANCHORS["contract_artifact_root"],
            },
            "runtime_substrate_v5": {
                "path": str(SUBSTRATE), "status": substrate_lock["status"],
                "governance_lock_sha256": ANCHORS["substrate_lock"],
                "governance_manifest_sha256": ANCHORS["substrate_manifest"],
                "canonical_artifact_root_sha256": ANCHORS["substrate_artifact_root"],
            },
            "predecessors_immutable": True,
        },
        "EXECUTION_IDENTITY_AND_PATH_BINDING.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_IDENTITY_AND_PATH_BINDING",
            "future_execution_identity": FUTURE_IDENTITY,
            "future_execution_path": str(FUTURE),
            "future_execution_path_state": "ABSENT_AUTHORIZED_NOT_CREATED",
            "future_execution_milestone": FUTURE_MILESTONE,
            "identity_reuse_or_alias": "PROHIBITED",
        },
        "COMPATIBILITY_EXECUTION_AUTHORIZATION_SCOPE.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_AUTHORIZATION_SCOPE",
            "decision": snapshot["decision"],
            "authorized_future_actions": [
                "CREATE_FRESH_EXECUTION_SOURCE_AND_EVIDENCE_WORKSPACE",
                "STATICALLY_VALIDATE_AND_LOCK_EXECUTION_CONTRACT",
                "EXECUTE_EXACT_COMPATIBILITY_SUITE",
                "INVOKE_ONLY_AN_ADMITTED_IDENTITY_BOUND_RUNTIME_FOR_COMPATIBILITY_VALIDATION",
                "CAPTURE_APPEND_ONLY_EVIDENCE",
                "INDEPENDENT_POST_VALIDATION_AND_EVIDENCE_FREEZE",
            ],
            "authority_ceiling": "COMPATIBILITY_VALIDATION_ONLY",
            "authorization_snapshot": snapshot,
        },
        "RUNTIME_IDENTITY_ALLOWLIST.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_RUNTIME_IDENTITY_ALLOWLIST",
            "default": "DENY",
            "admitted_runtime_count": 1,
            "admitted_runtimes": [{
                "runtime_id": CODEX_RUNTIME_ID,
                "provider_kind": "CODEX_CLI",
                "version": "0.162.1",
                "binary_sha256": codex["declared_binary_sha256"],
                "configuration_sha256": codex["declared_configuration_sha256"],
                "compatibility_state": "NOT_ESTABLISHED",
                "invocation_scope": "COMPATIBILITY_VALIDATION_ONLY",
                "attempt_limit": 1,
            }],
            "daybreak": "NOT_ADMITTED_NOT_DISCOVERED",
            "future_runtime": "NOT_ADMITTED",
            "unknown_runtime": "REJECT",
        },
        "CODEX_CLI_0_162_1_COMPATIBILITY_ADMISSION.json": {
            **common,
            "record_type": "V0_3_CODEX_CLI_0_162_1_COMPATIBILITY_ADMISSION",
            "runtime_id": CODEX_RUNTIME_ID,
            "version": "0.162.1",
            "binary_sha256": codex["declared_binary_sha256"],
            "configuration_sha256": codex["declared_configuration_sha256"],
            "candidate_status": "CANDIDATE_IDENTITY_MATCH_NOT_AUTHORIZED",
            "compatibility_state": "NOT_ESTABLISHED",
            "invocation_count_before_future_execution": 0,
            "future_compatibility_invocation_authorized": True,
            "worker_or_target_use_authorized": False,
            "provider_transport_authorized": False,
        },
        "DAYBREAK_AND_FUTURE_RUNTIME_ADMISSION_POLICY.json": {
            **common,
            "record_type": "V0_3_DAYBREAK_AND_FUTURE_RUNTIME_ADMISSION_POLICY",
            "daybreak": {
                "availability_state": "NOT_DISCOVERED", "compatibility_state": "NOT_ESTABLISHED",
                "invocation_count": 0, "invocation_authorized": False,
                "admission_requirement": "SEPARATE_AVAILABILITY_PROOF_IDENTITY_PIN_AND_GOVERNANCE_BINDING",
            },
            "future_runtime": {
                "availability_state": "NOT_DISCOVERED", "compatibility_state": "NOT_ESTABLISHED",
                "invocation_count": 0, "invocation_authorized": False,
                "admission_requirement": "FRESH_GOVERNANCE_SUCCESSOR_OR_EXPLICIT_AMENDMENT",
            },
            "availability_may_be_inferred": False,
        },
        "COMPATIBILITY_SUITE_BINDING.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_SUITE_BINDING",
            "suite_identity": SUITE_IDENTITY,
            "suite_definition_sha256": sha(CONTRACT / "COMPATIBILITY_SUITE_DEFINITION.json"),
            "case_count": suite["case_count"],
            "predecessor_state": "DEFINED_NOT_AUTHORIZED_NOT_EXECUTED",
            "future_execution_authorized": True,
            "execution_this_governance_milestone": False,
            "required_result": "NO_IMPLICIT_RUNTIME_OR_WORKER_PROMOTION",
        },
        "RUNTIME_INVOCATION_BOUNDARY.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_RUNTIME_INVOCATION_BOUNDARY",
            "runtime_invocation_is_general_worker_authority": False,
            "runtime_invocation_is_target_authority": False,
            "provider_transport_is_external_target_network": "DISTINCT_BUT_NOT_AUTHORIZED_HERE",
            "external_network_policy": "DENY_ALL",
            "sandbox": "RUNTIME_SUBSTRATE_V5_PASS_LOCKED_REQUIRED",
            "unsandboxed_fallback": "PROHIBITED",
            "allowed_invocation_purpose": "COMPATIBILITY_VALIDATION_ONLY",
            "structured_input_only": True,
            "structured_output_is_authoritative_finding": False,
        },
        "AUTHORITY_NON_ESCALATION_DECISION.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_AUTHORITY_NON_ESCALATION_DECISION",
            "decision": snapshot["decision"],
            "authorization_snapshot": snapshot,
            "compatibility_pass_effect": "RUNTIME_MAY_BECOME_ELIGIBLE_FOR_SEPARATE_ACCEPTANCE_ONLY",
            "worker_execution_effect": "NONE",
            "target_or_credential_effect": "NONE",
            "candidate_promotion_effect": "NONE",
        },
        "OPERATION_AUTHORIZATION_MATRIX.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_OPERATION_AUTHORIZATION_MATRIX",
            "future_authorized": {
                "compatibility_suite_execution": True,
                "identity_bound_codex_runtime_invocation": True,
            },
            "current_governance_operations": zeros(),
            "forbidden_or_deferred": {field: False for field in FORBIDDEN_AUTHORITY_FIELDS},
            "unknown_operation": "REJECT",
        },
        "ATTEMPT_AND_RETRY_POLICY.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_ATTEMPT_AND_RETRY_POLICY",
            "future_attempt_count": 0,
            "attempt_limit_per_admitted_runtime_identity": 1,
            "attempt_marker_created_only_after_all_preflight_and_lock_gates_pass": True,
            "automatic_retry": False,
            "terminal_attempt_replay": "PROHIBITED",
            "failure_requires": "SEPARATE_GOVERNANCE_ADJUDICATION",
        },
        "EVIDENCE_AND_FREEZE_REQUIREMENTS.json": {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_EVIDENCE_AND_FREEZE_REQUIREMENTS",
            "required": [
                "EXACT_RUNTIME_IDENTITY_AND_DIGEST", "EXACT_CONFIG_DIGEST", "EXACT_SUITE_IDENTITY",
                "EXACT_ARGV_AND_ENVIRONMENT", "RUNTIME_SUBSTRATE_V5_BINDING", "PROCESS_LINEAGE",
                "STRUCTURED_INPUT_AND_OUTPUT", "EXIT_TIMEOUT_INTERRUPT_SEMANTICS", "FILESYSTEM_AND_NETWORK_EFFECTS",
                "APPEND_ONLY_RESULTS", "PRIMARY_AND_INDEPENDENT_POST_VALIDATION", "FINAL_EVIDENCE_FREEZE",
            ],
            "missing_evidence": "FAIL_CLOSED_OR_BLOCKED_NO_PASS",
            "runtime_output_can_self_certify": False,
            "separate_acceptance_after_execution": True,
        },
    }

    for name, value in records.items():
        write_once(name, value)

    matrix = {
        **common,
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "test_count": len(negative_cases()),
        "tests": [{"test_id": test_id, "field": field, "replacement": replacement, "expected": "REJECT"} for test_id, field, replacement in negative_cases()],
    }
    write_once("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", matrix)
    negative_results = []
    for test_id, field, replacement in negative_cases():
        candidate = copy.deepcopy(snapshot)
        set_path(candidate, field, replacement)
        actual = "ACCEPT" if valid_authorization(candidate, snapshot) else "REJECT"
        negative_results.append({"test_id": test_id, "field": field, "expected": "REJECT", "actual": actual, "status": "PASS" if actual == "REJECT" else "FAIL"})
    negative_failed = [row for row in negative_results if row["status"] != "PASS"]
    write_once("NEGATIVE_GOVERNANCE_TEST_RESULT.json", {
        **common,
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "status": "PASS" if not negative_failed else "FAIL_CLOSED",
        "tests_total": len(negative_results), "tests_passed": len(negative_results) - len(negative_failed), "tests_failed": len(negative_failed),
        "results": negative_results,
        "operations_this_governance_milestone": zeros(),
    })

    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(allowed_initial):
        check(f"G_SYNTAX_{script}", ast.parse((ROOT / script).read_text(encoding="utf-8")) is not None)
    check("G005_CONTRACT_STATUS", contract_lock.get("status") == "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY")
    check("G006_CONTRACT_NEXT", contract_lock.get("next_legal_milestone") == MILESTONE)
    check("G007_SUBSTRATE_ACCEPTED", substrate_lock.get("decision") == "A_ACCEPT_AND_PROMOTE_RUNTIME_SUBSTRATE_V5_TO_PASS_LOCKED")
    check("G008_FUTURE_PATH_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    check("G009_SNAPSHOT_VALID", valid_authorization(snapshot, snapshot))
    check("G010_COMPAT_AUTH", snapshot["compatibility_execution_authorized"] is True and snapshot["compatibility_suite_execution_authorized"] is True)
    check("G011_IDENTITY_BOUND_RUNTIME_AUTH", snapshot["identity_bound_runtime_invocation_authorized"] is True)
    check("G012_CODEX_EXACT", snapshot["codex_runtime_id"] == CODEX_RUNTIME_ID and snapshot["codex_version"] == "0.162.1")
    check("G013_CODEX_NOT_ESTABLISHED", snapshot["codex_compatibility_state_before_execution"] == "NOT_ESTABLISHED")
    check("G014_SUITE_EXACT", snapshot["suite_identity"] == SUITE_IDENTITY and snapshot["suite_case_count"] == 24)
    check("G015_SINGLE_ATTEMPT", snapshot["suite_attempt_limit_per_admitted_runtime_identity"] == 1 and snapshot["automatic_retry"] is False)
    check("G016_DAYBREAK_NOT_DISCOVERED", snapshot["daybreak_availability"] == "NOT_DISCOVERED" and snapshot["daybreak_invocation_authorized"] is False)
    check("G017_FUTURE_RUNTIME_FALSE", snapshot["future_runtime_invocation_authorized"] is False)
    check("G018_PROVIDER_TRANSPORT_FALSE", snapshot["provider_transport_authorized"] is False)
    check("G019_NO_FORBIDDEN_AUTHORITY", all(snapshot[field] is False for field in FORBIDDEN_AUTHORITY_FIELDS))
    check("G020_GOVERNANCE_OPERATIONS_ZERO", snapshot["operations_this_governance_milestone"] == zeros())
    check("G021_FUTURE_ATTEMPT_ZERO", snapshot["future_attempt_count"] == 0)
    check("G022_ALLOWLIST_ONE", records["RUNTIME_IDENTITY_ALLOWLIST.json"]["admitted_runtime_count"] == 1)
    check("G023_DAYBREAK_NOT_ADMITTED", records["RUNTIME_IDENTITY_ALLOWLIST.json"]["daybreak"] == "NOT_ADMITTED_NOT_DISCOVERED")
    check("G024_EXTERNAL_NETWORK_DENY", records["RUNTIME_INVOCATION_BOUNDARY.json"]["external_network_policy"] == "DENY_ALL")
    check("G025_UNSANDBOXED_PROHIBITED", records["RUNTIME_INVOCATION_BOUNDARY.json"]["unsandboxed_fallback"] == "PROHIBITED")
    check("G026_RUNTIME_NOT_WORKER", records["RUNTIME_INVOCATION_BOUNDARY.json"]["runtime_invocation_is_general_worker_authority"] is False)
    check("G027_RUNTIME_NOT_TARGET", records["RUNTIME_INVOCATION_BOUNDARY.json"]["runtime_invocation_is_target_authority"] is False)
    check("G028_EVIDENCE_NOT_SELF_CERTIFY", records["EVIDENCE_AND_FREEZE_REQUIREMENTS.json"]["runtime_output_can_self_certify"] is False)
    check("G029_SEPARATE_ACCEPTANCE", records["EVIDENCE_AND_FREEZE_REQUIREMENTS.json"]["separate_acceptance_after_execution"] is True)
    check("G030_NEGATIVE_COUNT", matrix["test_count"] == len(negative_results) == 60)
    check("G031_NEGATIVE_PASS", not negative_failed)
    check("G032_NEGATIVE_ALL_REJECT", all(row["actual"] == "REJECT" for row in negative_results))
    check("G033_PREDECESSOR_IMMUTABLE", records["PREDECESSOR_CHAIN_BINDING.json"]["predecessors_immutable"] is True)
    check("G034_ROUTER_NO_EXEC", records["ROUTING_AND_SCOPE_DECISION.json"]["executed_this_milestone"] == [])
    check("G035_NO_SUBAGENTS", records["ROUTING_AND_SCOPE_DECISION.json"]["subagents"] == "NOT_USED")
    check("G036_AUTH_ROUTE_NA", records["ROUTING_AND_SCOPE_DECISION.json"]["authentication_hunter_route"].startswith("NOT_APPLICABLE"))
    check("G037_WEB3_ROUTE_NA", records["ROUTING_AND_SCOPE_DECISION.json"]["web3_route"].startswith("NOT_APPLICABLE"))
    check("G038_OPERATION_KEYS_EXACT", set(snapshot["operations_this_governance_milestone"]) == set(OPERATION_KEYS))
    check("G039_CODEX_COUNTER_ZERO", codex["invocation_count"] == 0)
    check("G040_SUITE_COUNTER_ZERO", suite["execution_count"] == 0)
    failed = [row for row in checks if row["status"] != "PASS"]
    write_once("PRIMARY_GOVERNANCE_VALIDATION_RESULT.json", {
        **common,
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_PRIMARY_GOVERNANCE_VALIDATION_RESULT",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "checks": checks,
        "operations_this_governance_milestone": zeros(),
    })
    print(json.dumps({"status": "PASS" if not failed and not negative_failed else "FAIL_CLOSED", "primary_total": len(checks), "primary_failed": len(failed), "negative_total": len(negative_results), "negative_failed": len(negative_failed)}, sort_keys=True))
    if failed or negative_failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
