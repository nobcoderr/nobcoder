#!/usr/bin/env python3
"""Read-only final freeze verification for compatibility execution governance."""

from __future__ import annotations

import ast
import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
CONTRACT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-contract-v2-20261017")
SUBSTRATE = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v5-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261017")
FUTURE = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v1-20261017")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_AUTHORIZATION_GOVERNANCE_V1"
MILESTONE = "AUTHORIZE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_GOVERNANCE_ONLY"
CODEX_RUNTIME_ID = "CODEX_RUNTIME_V1_CANDIDATE_0_162_1_LINUX_X86_64_MUSL"
FALSE_FIELDS = (
    "daybreak_invocation_authorized", "future_runtime_invocation_authorized",
    "worker_execution_authorized", "subagent_execution_authorized", "credential_use_authorized",
    "target_access_authorized", "external_network_authorized", "exploit_replay_authorized",
    "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized",
    "submission_automation_authorized",
)
OPERATION_KEYS = {
    "compatibility_suite_executions", "runtime_invocations", "codex_cli_invocations",
    "daybreak_invocations", "future_runtime_invocations", "worker_processes",
    "subagent_processes", "credential_operations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def rows_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda item: str(item["path"]))
    ).encode()
    return hashlib.sha256(material).hexdigest()


def zero(value: Any) -> bool:
    return isinstance(value, dict) and set(value) == OPERATION_KEYS and all(value[key] == 0 for key in OPERATION_KEYS)


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("F001_ROOT", ROOT.is_dir() and not ROOT.is_symlink())
    check("F002_ROOT_READ_ONLY", ro(ROOT), oct(stat.S_IMODE(ROOT.stat().st_mode)))
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    lock_path = ROOT / "GOVERNANCE_LOCK.json"
    manifest = load(manifest_path)
    lock = load(lock_path)
    members = manifest.get("members", [])
    check("F003_LOCK_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F004_LOCK_DECISION", lock.get("decision") == "AUTHORIZE_IDENTITY_BOUND_COMPATIBILITY_EXECUTION_ONLY")
    check("F005_IDENTITY", lock.get("governance_identity") == IDENTITY and lock.get("milestone") == MILESTONE)
    check("F006_MANIFEST_IDENTITY", manifest.get("governance_identity") == IDENTITY)
    check("F007_MEMBER_COUNT", isinstance(members, list) and manifest.get("member_count") == len(members) and lock.get("root_member_count") == len(members) + 1)
    actual_files = {path.name for path in ROOT.iterdir() if path.is_file()}
    expected_files = {str(row.get("path")) for row in members} | {manifest_path.name, lock_path.name}
    check("F008_EXACT_FILE_SET", actual_files == expected_files, {"actual": len(actual_files), "expected": len(expected_files)})
    check("F009_REGULAR_NO_SYMLINKS", all(path.is_file() and not path.is_symlink() for path in ROOT.iterdir()))
    check("F010_ALL_READ_ONLY", all(ro(path) for path in ROOT.iterdir()))
    member_ok = True
    for row in members:
        path = ROOT / str(row.get("path", ""))
        if not path.is_file() or path.is_symlink() or path.stat().st_size != row.get("bytes") or sha(path) != row.get("sha256"):
            member_ok = False
    check("F011_MEMBER_HASHES", member_ok)
    member_root = rows_root(members)
    check("F012_MEMBER_ROOT", member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256"))
    manifest_sha = sha(manifest_path)
    check("F013_MANIFEST_HASH", manifest_sha == lock.get("governance_manifest_sha256"))
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}])
    check("F014_ARTIFACT_ROOT", artifact_root == lock.get("canonical_artifact_root_sha256"))
    check("F015_LOCK_SELF_EXCLUDED", lock_path.name not in {row.get("path") for row in members})
    for script in ("build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py"):
        try:
            okay = ast.parse((ROOT / script).read_text(encoding="utf-8")) is not None
        except Exception:
            okay = False
        check(f"F_SYNTAX_{script}", okay)
    primary = load(ROOT / "PRIMARY_GOVERNANCE_VALIDATION_RESULT.json")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    independent = load(ROOT / "INDEPENDENT_VALIDATION_RESULT.json")
    check("F020_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0 and primary.get("checks_total") == primary.get("checks_passed"))
    check("F021_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") == 60 and negative.get("tests_failed") == 0)
    check("F022_INDEPENDENT_PASS", independent.get("status") == "PASS" and independent.get("checks_failed") == 0 and independent.get("checks_total") == independent.get("checks_passed"))
    check("F023_VALIDATION_COUNTS", lock.get("validation_counts") == {
        "primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
        "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
        "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
    })
    auth = load(ROOT / "COMPATIBILITY_EXECUTION_AUTHORIZATION_LOCK.json")
    check("F024_COMPAT_AUTH", lock.get("compatibility_execution_authorized") is True and auth.get("compatibility_execution_authorized") is True)
    check("F025_SUITE_AUTH", lock.get("compatibility_suite_execution_authorized") is True and auth.get("compatibility_suite_execution_authorized") is True)
    check("F026_IDENTITY_BOUND_AUTH", lock.get("identity_bound_runtime_invocation_authorized") is True and auth.get("identity_bound_runtime_invocation_authorized") is True)
    check("F027_CODEX_AUTH", lock.get("codex_cli_compatibility_invocation_authorized") is True and auth.get("codex_cli_compatibility_invocation_authorized") is True)
    check("F028_CODEX_IDENTITY", lock.get("codex_runtime_id") == CODEX_RUNTIME_ID and auth.get("codex_runtime_id") == CODEX_RUNTIME_ID)
    check("F029_CODEX_STATE", lock.get("codex_compatibility_state") == "NOT_ESTABLISHED" and auth.get("codex_compatibility_state") == "NOT_ESTABLISHED")
    check("F030_CODEX_COUNT_ZERO", auth.get("codex_invocation_count") == 0 and auth.get("suite_execution_count") == 0)
    check("F031_DAYBREAK_STATE", lock.get("daybreak_availability") == "NOT_DISCOVERED" and auth.get("daybreak_availability") == "NOT_DISCOVERED")
    check("F032_DAYBREAK_NOT_AUTH", lock.get("daybreak_invocation_authorized") is False and auth.get("daybreak_invocation_authorized") is False)
    for index, field in enumerate(FALSE_FIELDS[1:], start=33):
        check(f"F{index:03d}_{field.upper()}_FALSE", lock.get(field) is False and auth.get(field) is False)
    check("F044_PROVIDER_TRANSPORT_FALSE", lock.get("provider_transport_authorized") is False and auth.get("provider_transport_authorized") is False)
    check("F045_GOV_COUNTERS_ZERO", zero(lock.get("operations_this_governance_milestone")) and zero(auth.get("operations_this_governance_milestone")))
    check("F046_FUTURE_ATTEMPT_ZERO", lock.get("future_attempt_count") == 0 and auth.get("future_attempt_count") == 0)
    check("F047_FUTURE_PATH_ABSENT", not FUTURE.exists() and not FUTURE.is_symlink())
    next_legal = load(ROOT / "NEXT_LEGAL_MILESTONE.json")
    check("F048_NEXT_STATUS", next_legal.get("status") == "AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F049_NEXT_NO_WORKER", next_legal.get("worker_subagent_target_credential_network_authority") == "NONE")
    check("F050_DAYBREAK_NEXT_NONE", next_legal.get("daybreak_authority") == "NONE_UNTIL_SEPARATE_AVAILABILITY_AND_IDENTITY_BINDING")
    check("F051_CONTRACT_PREDECESSOR", sha(CONTRACT / "GOVERNANCE_LOCK.json") == "f083b7bc2756d9052c8c66bc6fb8ed3f3b42aacf54ac1b914d3e2e1270b3a363")
    check("F052_SUBSTRATE_PREDECESSOR", sha(SUBSTRATE / "GOVERNANCE_LOCK.json") == "8383ec457c0838fba668693ae9c837edf1a8c50222c524176dc60b9afda9191e")
    check("F053_NEGATIVE_ALL_REJECT", all(row.get("actual") == "REJECT" and row.get("status") == "PASS" for row in negative.get("results", [])))
    check("F054_FINAL_FREEZE_REQUIRED", lock.get("final_freeze_verification_required") is True)
    failed = [row for row in checks if row["status"] != "PASS"]
    result = {
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "governance_lock_sha256": sha(lock_path),
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "checks": checks,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
