#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V3 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v3-20261017")
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3_NON_PATH_PIPE_PAYLOAD_MISCLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    data = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(data.encode()).hexdigest()


def require_pass(name: str, total: str, passed: str, failed: str) -> dict[str, Any]:
    value = load(name)
    if value["status"] != "PASS" or value[failed] != 0 or value[total] != value[passed]:
        raise SystemExit(f"not PASS: {name}")
    return value


def main() -> None:
    if (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").exists() or (ROOT / "GOVERNANCE_LOCK.json").exists():
        raise SystemExit("final artifacts already exist")
    if V4.exists() or V4.is_symlink():
        raise SystemExit("V4 must remain absent at governance freeze")
    anchors = {
        V3 / "STATIC_SOURCE_MANIFEST.json": "28b02da30f5c724d8dfa72d1996887e7ee9e54dadc5209751c5ed5f8bb003ec4",
        V3 / "STATIC_EXECUTION_LOCK.json": "74276275026a38d7d157cca874539abd2c6a5240ea2b9549498061321b1e3a3b",
        V3 / "static-run-v1/independent-post-validation-0001.json": "b7eea278da6684c578f53872b39b87e49c7f1fab0f2be929238ef6a891262561",
        V3 / "static-run-v1/runtime-result-0001.json": "4e22c3e1f4a8f4af7d4cc021d233f90b5d5a4bb116d33c1d434ba7761891cad1",
        V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json": "ab7354be2600e7d67116ca8bae81bdb3f43c468eaab979f488273f991c0499d1",
        V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json": "5d0b332abdd3960d43a76b4c82c124bf2f3578657c867c41077650da29fa5e4f",
    }
    if any(not path.is_file() or sha(path) != digest for path, digest in anchors.items()):
        raise SystemExit("V3 frozen anchor changed")
    primary = require_pass("GOVERNANCE_VALIDATION_RESULT_RUN-0002.json", "checks_total", "checks_passed", "checks_failed")
    negative = require_pass("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json", "tests_total", "tests_passed", "tests_failed")
    independent = require_pass("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json", "checks_total", "checks_passed", "checks_failed")
    freeze = require_pass("FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json", "checks_total", "checks_passed", "checks_failed")
    historical_primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    historical_negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    if historical_primary["status"] != "PASS" or historical_negative["status"] != "FAIL_CLOSED" or historical_negative["tests_failed"] != 1:
        raise SystemExit("pre-freeze result lineage missing")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    if any(value != 0 for value in authority["governance_operation_counters"].values()):
        raise SystemExit("governance operation counter is nonzero")
    if authority["runtime_invoked_this_milestone"] or authority["codex_invoked_this_milestone"]:
        raise SystemExit("runtime invocation recorded in governance milestone")
    terminal = load("V3_TERMINAL_DISPOSITION.json")
    if terminal["disposition"] != "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY":
        raise SystemExit("V3 terminal disposition changed")
    pipe = load("PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION.json")
    fs = load("FILESYSTEM_ACTIVITY_ADJUDICATION.json")
    successor = load("SUCCESSOR_V4_AUTHORIZATION_DECISION.json")
    if pipe["classifier_defect"] is not True or fs["actual_out_of_scope_filesystem_activity_proven"] is not False:
        raise SystemExit("adjudication not final")
    if successor["decision"] != "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V4_CONDITIONALLY":
        raise SystemExit("successor decision not authorized")

    members: list[dict[str, Any]] = []
    for path in sorted(path for path in ROOT.iterdir() if path.is_file() and path.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}):
        if path.is_symlink():
            raise SystemExit("symlink member")
        members.append({"path": path.name, "sha256": sha(path), "bytes": path.stat().st_size})
    member_root = canonical_root(members)
    manifest = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "canonical_member_root_sha256": member_root, "member_count": len(members),
        "members": members, "self_referential_hashes": False,
    }
    with (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True); handle.write("\n")
    manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    artifact_root = canonical_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    lock = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": successor["decision"],
        "v3_disposition": terminal["disposition"], "v3_attempt": terminal["attempt"],
        "v3_codex_invocation_count": terminal["codex_cli_invocation_count"], "v3_runtime_exit_code": terminal["runtime_exit_code"],
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN", "pass_locked_compatibility_issued": False,
        "pipe_payload_path_classifier_defect": "YES",
        "actual_out_of_scope_filesystem_activity_proven": "NO_IN_FROZEN_CAPTURE",
        "actual_out_of_scope_claim_scope": fs["scope_of_claim"],
        "confinement_bypass": ownership["confinement_bypass"],
        "ownership_defects": ownership["ownership_defects"],
        "typed_evidence_classes": sorted(load("TYPED_TRACE_EVIDENCE_MODEL.json")["classes"]),
        "free_text_or_regex_path_inference_prohibited": True,
        "semantic_syscall_path_classification_required": True,
        "v4_execution_identity": successor["successor_execution_identity"],
        "v4_suite_identity": successor["successor_suite_identity"], "v4_path": successor["successor_path"],
        "v4_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_AT_FREEZE",
        "v4_attempt_count": 0, "v4_attempt_limit": 1, "v4_codex_invocation_count": 0, "v4_codex_invocation_limit": 1,
        "separate_acceptance_after_v4_execution": True,
        "worker_execution_authorized": False, "subagent_execution_authorized": False,
        "credential_use_authorized": False, "target_access_authorized": False,
        "external_network_authorized": False, "daybreak_invocation_authorized": False,
        "exploit_replay_authorized": False, "parallelism_authorized": False,
        "capability_graph_authorized": False, "candidate_promotion_authorized": False,
        "submission_automation_authorized": False,
        "operation_counters": authority["governance_operation_counters"],
        "validation_counts": {
            "historical_primary_run_0001": {"total": historical_primary["checks_total"], "passed": historical_primary["checks_passed"], "failed": historical_primary["checks_failed"]},
            "historical_negative_run_0001": {"total": historical_negative["tests_total"], "passed": historical_negative["tests_passed"], "failed": historical_negative["tests_failed"]},
            "primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
            "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
            "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
            "final_freeze_candidate": {"total": freeze["checks_total"], "passed": freeze["checks_passed"], "failed": freeze["checks_failed"]},
        },
        "canonical_member_root_sha256": member_root,
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 2},
        "next_legal_milestone": load("NEXT_LEGAL_MILESTONE.json")["next_if_pass_locked"],
    }
    with (ROOT / "GOVERNANCE_LOCK.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(lock, handle, indent=2, sort_keys=True); handle.write("\n")
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": lock["status"], "decision": lock["decision"], "member_count": len(members),
        "governance_manifest_sha256": manifest_sha, "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"),
        "canonical_artifact_root_sha256": artifact_root,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
