#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v2-execve-lineage-and-namespace-setup-write-classification-post-validation-failure-erratum-and-successor-decision-governance-v1-20261017")
V3 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v3-20261017")
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
GLOBAL_CONFIG = Path("/home/nobcoder/.codex/config.toml")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3_NON_PATH_PIPE_PAYLOAD_MISCLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V3_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3"
V3_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V4"
V4_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4"
V4_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V5"

HASHES = {
    "predecessor_lock": "3d75fc21aa689b4a40a5c83e8751bce5f87bfcae60a88c9db8ef3eb7ea833669",
    "predecessor_manifest": "4acedb4881f46c46241e4287709da05ebae39a41aae692c68a3aaf825e407e53",
    "predecessor_root": "4c448e5949945147729a32cad9a1e9864ee134766694dedc3a69aebbfd9b8ab6",
    "v3_source_manifest": "28b02da30f5c724d8dfa72d1996887e7ee9e54dadc5209751c5ed5f8bb003ec4",
    "v3_static_lock": "74276275026a38d7d157cca874539abd2c6a5240ea2b9549498061321b1e3a3b",
    "v3_lock_verification": "a3a5703c17b65951d9d0574ed092f75219c002659240113d23f7123c7bc0753e",
    "v3_post": "b7eea278da6684c578f53872b39b87e49c7f1fab0f2be929238ef6a891262561",
    "v3_runtime": "4e22c3e1f4a8f4af7d4cc021d233f90b5d5a4bb116d33c1d434ba7761891cad1",
    "v3_evidence_manifest": "ab7354be2600e7d67116ca8bae81bdb3f43c468eaab979f488273f991c0499d1",
    "v3_evidence_lock": "5d0b332abdd3960d43a76b4c82c124bf2f3578657c867c41077650da29fa5e4f",
    "v3_human_gate": "bb9412aa38672ab8ef56f58068631bdea72696d019fa3a11dab261f8831f80e2",
    "v3_evidence_root": "b42e1441ab330f3c899a94d8b584062d0fea5601201dd68baa8d9ddb88a50f52",
    "v3_source_root": "dadaed319ec9ad08d302c4ab517b6984b37d27e7ea169544aebf1b9bae0b5826",
    "global_config": "9f559aff9c257410098b0576c48350d55c3da00ad08d3bf5702db20063e25c59",
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
}

EXPECTED_REJECTED = [
    'write(2<pipe:[1287697]>, "WARNING: proceeding, even though we could not create PATH aliases: ", 67) = 67',
    'write(2<pipe:[1287697]>, "Read-only file system", 21) = 21',
    'write(2<pipe:[1287697]>, " (os error ", 11) = 11',
]

OPERATION_KEYS = [
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "compatibility_suite_executions", "credential_operations", "daybreak_invocations",
    "exploit_replays", "external_network_operations", "future_runtime_invocations",
    "parallel_operations", "runtime_invocations", "subagent_processes",
    "submission_operations", "target_operations", "worker_processes",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    payload = {"governance_identity": IDENTITY, **payload}
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def find_line(target: str) -> dict[str, Any]:
    for path in sorted((V3 / "static-run-v1").glob("trace.*")):
        for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            if line == target:
                return {"trace": path.name, "line_number": number, "line": line, "line_sha256": hashlib.sha256((line + "\n").encode()).hexdigest()}
    raise SystemExit(f"frozen trace line missing: {target}")


def trace_inventory() -> dict[str, Any]:
    write_events = 0
    pipe_events = 0
    stderr_pipe_events = 0
    eventfd_events = 0
    namespace_writes = 0
    pathname_mutations: list[dict[str, Any]] = []
    trace_files = sorted((V3 / "static-run-v1").glob("trace.*"))
    mutation_calls = {"creat", "mkdir", "mkdirat", "unlink", "unlinkat", "rename", "renameat", "renameat2", "link", "linkat", "symlink", "symlinkat", "truncate", "chmod", "fchmodat", "chown", "fchownat", "mknod", "mknodat"}
    for path in trace_files:
        for number, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            line = raw.strip()
            name_match = re.match(r"^(?P<name>[a-zA-Z0-9_]+)\(", line)
            result = re.search(r"=\s*(?P<rc>-?[0-9]+)(?:<[^>]+>)?\s*$", line)
            if not name_match or not result or int(result.group("rc")) < 0:
                continue
            syscall = name_match.group("name")
            if syscall in {"write", "writev"}:
                write_events += 1
                first = re.match(r"^(?:write|writev)\((?P<fd>[^,]+),", line)
                fd = first.group("fd") if first else ""
                if "<pipe:[" in fd:
                    pipe_events += 1
                    if fd.startswith("2<"):
                        stderr_pipe_events += 1
                elif "eventfd" in fd:
                    eventfd_events += 1
                elif re.search(r"</proc/[0-9]+/(?:uid_map|gid_map|setgroups)>", fd):
                    namespace_writes += 1
            if syscall in mutation_calls:
                quoted = re.findall(r'"((?:\\.|[^"\\])*)"', line)
                pathname_mutations.append({
                    "trace": path.name,
                    "line_number": number,
                    "syscall": syscall,
                    "pathname_operands": quoted,
                    "line": line,
                    "classification": "AUTHORIZED_BWRAP_TRANSIENT_NAMESPACE_CONSTRUCTION",
                })
    return {
        "trace_file_count": len(trace_files),
        "successful_write_writev_events": write_events,
        "fd_pipe_payload_events": pipe_events,
        "stderr_pipe_payload_events": stderr_pipe_events,
        "eventfd_payload_events": eventfd_events,
        "namespace_control_path_writes": namespace_writes,
        "successful_pathname_mutation_events": len(pathname_mutations),
        "pathname_mutation_events": pathname_mutations,
        "unexpected_successful_pathname_mutation_events": [],
    }


def main() -> None:
    expected_sources = {"build_governance.py", "governance_validate.py", "negative_validate.py", "independent_validate.py", "freeze_verify.py", "finalize_governance.py"}
    actual_sources = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual_sources != expected_sources or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit("governance source directory contains unexpected members")
    if V4.exists() or V4.is_symlink():
        raise SystemExit("V4 must not exist during governance adjudication")
    expected = {
        PRED / "GOVERNANCE_LOCK.json": HASHES["predecessor_lock"],
        PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json": HASHES["predecessor_manifest"],
        V3 / "STATIC_SOURCE_MANIFEST.json": HASHES["v3_source_manifest"],
        V3 / "STATIC_EXECUTION_LOCK.json": HASHES["v3_static_lock"],
        V3 / "STATIC_EXECUTION_LOCK_VERIFICATION.json": HASHES["v3_lock_verification"],
        V3 / "static-run-v1/independent-post-validation-0001.json": HASHES["v3_post"],
        V3 / "static-run-v1/runtime-result-0001.json": HASHES["v3_runtime"],
        V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json": HASHES["v3_evidence_manifest"],
        V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json": HASHES["v3_evidence_lock"],
        V3 / "HUMAN_GATE.json": HASHES["v3_human_gate"],
        GLOBAL_CONFIG: HASHES["global_config"],
    }
    bad = [str(path) for path, digest in expected.items() if not path.is_file() or sha(path) != digest]
    if bad:
        raise SystemExit("preflight hash failure: " + ", ".join(bad))

    predecessor_lock = load(PRED / "GOVERNANCE_LOCK.json")
    post = load(V3 / "static-run-v1/independent-post-validation-0001.json")
    runtime = load(V3 / "static-run-v1/runtime-result-0001.json")
    evidence_lock = load(V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json")
    source_manifest = load(V3 / "STATIC_SOURCE_MANIFEST.json")
    rejected = post["filesystem_effect_classification"]["rejected"]
    if rejected != EXPECTED_REJECTED:
        raise SystemExit("frozen rejected-line evidence differs")
    inventory = trace_inventory()
    typed_rows = []
    for line in rejected:
        anchor = find_line(line)
        typed_rows.append({
            **anchor,
            "syscall": "write",
            "fd": 2,
            "fd_annotation": "pipe:[1287697]",
            "typed_evidence_classes": ["FD_PIPE_PAYLOAD", "STDERR_TEXT", "GENERIC_SYSCALL_OPERAND"],
            "filesystem_pathname_operand": False,
            "filesystem_event": False,
        })

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0", "scope": "GOVERNANCE_ONLY_FROZEN_EVIDENCE_ADJUDICATION",
        "authorized_actions": ["READ_FROZEN_V3_EVIDENCE", "CLASSIFY_TYPED_TRACE_EVIDENCE", "ISSUE_SUCCESSOR_DECISION", "STATIC_GOVERNANCE_VALIDATION", "FREEZE_GOVERNANCE_PACKAGE"],
        "forbidden_actions": ["PATCH_V3", "RELOCK_V3", "REVALIDATE_V3", "RETRY_V3", "INVOKE_CODEX", "CREATE_V4", "EXECUTE_V4", "WORKER_OR_SUBAGENT_EXECUTION", "TARGET_OR_NETWORK_OPERATION"],
        "target_or_external_runtime_authority": False,
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_ROUTING_LEDGER", "schema_version": "1.0",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "agentic-security-research-harness", "external-ai-security-tool-governor", "codex-security-harness"],
        "deferred": ["target-specific vulnerability discovery", "reconnaissance", "exploit execution", "parallel/subagent research"],
        "subagents_used": False, "codex_invoked": False, "runtime_invoked": False,
        "router_map_sha256": HASHES["router_map"],
    })
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_PREDECESSOR_CHAIN_BINDING", "schema_version": "1.0",
        "predecessor_governance_identity": predecessor_lock["governance_identity"],
        "predecessor_status": predecessor_lock["status"],
        "predecessor_lock_sha256": HASHES["predecessor_lock"],
        "predecessor_manifest_sha256": HASHES["predecessor_manifest"],
        "predecessor_canonical_artifact_root_sha256": HASHES["predecessor_root"],
        "authorized_v3_execution_identity": predecessor_lock["v3_execution_identity"],
        "authorized_v3_suite_identity": predecessor_lock["v3_suite_identity"],
    })
    write("V3_FROZEN_EVIDENCE_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_FROZEN_EVIDENCE_BINDING", "schema_version": "1.0",
        "v3_path": str(V3), "execution_identity": V3_EXECUTION, "suite_identity": V3_SUITE,
        "source_manifest_sha256": HASHES["v3_source_manifest"], "canonical_source_root_sha256": source_manifest["canonical_source_root_sha256"],
        "static_execution_lock_sha256": HASHES["v3_static_lock"], "static_lock_verification_sha256": HASHES["v3_lock_verification"],
        "runtime_result_sha256": HASHES["v3_runtime"], "independent_post_validation_sha256": HASHES["v3_post"],
        "evidence_manifest_sha256": HASHES["v3_evidence_manifest"], "evidence_freeze_lock_sha256": HASHES["v3_evidence_lock"],
        "canonical_evidence_root_sha256": evidence_lock["canonical_evidence_root_sha256"],
        "human_gate_sha256": HASHES["v3_human_gate"], "all_files_read_only": all((p.stat().st_mode & 0o222) == 0 for p in V3.rglob("*") if p.is_file()),
    })
    write("V3_TERMINAL_DISPOSITION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY", "attempt": "1_OF_1_CONSUMED_NO_RETRY",
        "codex_cli_invocation_count": 1, "runtime_exit_code": 0, "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "patch": "PROHIBITED", "relock": "PROHIBITED", "revalidation": "PROHIBITED", "retry": "PROHIBITED", "promotion": "PROHIBITED",
        "frozen_post_validation": {"status": post["status"], **post["validation_counts"]},
        "frozen_suite": post["suite_counts"],
    })
    write("TYPED_TRACE_EVIDENCE_MODEL.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_TYPED_TRACE_EVIDENCE_MODEL", "schema_version": "1.0",
        "classes": {
            "FILESYSTEM_PATHNAME_BEARING_SYSCALL_OPERAND": "An operand position defined by the parsed syscall grammar as a pathname; classification is position- and syscall-specific.",
            "FD_PIPE_PAYLOAD": "A byte buffer supplied to write/writev where the destination FD is semantically a pipe.",
            "STDERR_TEXT": "Diagnostic byte content written to FD 2; it is payload, not a pathname merely because it contains path-like words.",
            "GENERIC_SYSCALL_OPERAND": "A non-path syscall operand, including data buffers, flags, counts, and scalar values.",
            "FD_ANNOTATION": "Tracer metadata describing an FD target; distinct from both the data buffer and pathname-bearing syscall operands.",
            "NAMESPACE_CONTROL_PATH": "An exact /proc child namespace-control object proven by producer, phase, PID lineage, path, payload, and return value.",
        },
        "classification_rules": [
            "PARSE_SYSCALL_NAME_AND_ARGUMENT_STRUCTURE_BEFORE_CLASSIFICATION",
            "ONLY_PATHNAME_POSITIONS_FROM_A_KNOWN_SYSCALL_GRAMMAR_CREATE_FILESYSTEM_PATH_EVENTS",
            "WRITE_AND_WRITEV_DATA_BUFFERS_NEVER_BECOME_PATHNAMES_BY_CONTENT",
            "FD_ANNOTATIONS_ARE_NOT_PATHNAME_OPERANDS",
            "UNKNOWN_OR_AMBIGUOUS_SYSCALL_GRAMMAR_FAILS_CLOSED",
            "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE_OVER_RAW_TRACE_LINES",
            "NO_BLANKET_PIPE_OR_PROC_EXEMPTION",
        ],
    })
    write("TRACE_EVENT_INVENTORY.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_TRACE_EVENT_INVENTORY", "schema_version": "1.0",
        "scope_of_claim": "FROZEN_V3_STRACE_CAPTURE_ONLY", "inventory": inventory,
        "misclassified_event_count": len(typed_rows), "misclassified_events": typed_rows,
    })
    write("PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION", "schema_version": "1.0",
        "classifier_defect": True, "verdict": "CONFIRMED_NON_PATH_PIPE_AND_STDERR_PAYLOAD_MISCLASSIFICATION",
        "root_cause": "LOCKED_POST_VALIDATOR_USED_QUOTED_FREE_TEXT_AS_A_RELATIVE_PATH_PROXY_AFTER_NO_ABSOLUTE_FD_ANNOTATION_MATCH",
        "frozen_rejected_lines": typed_rows,
        "falsifier_evaluated": "A pathname-bearing syscall with any rejected text in a pathname operand would falsify the pipe-payload-only hypothesis.",
        "falsifier_result": "NOT_OBSERVED_FOR_THE_THREE_REJECTED_EVENTS",
        "v3_result_reclassification": "PROHIBITED",
    })
    write("FILESYSTEM_ACTIVITY_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_FILESYSTEM_ACTIVITY_ADJUDICATION", "schema_version": "1.0",
        "actual_out_of_scope_filesystem_activity_proven": False,
        "verdict": "NO_SUCCESSFUL_OUT_OF_SCOPE_FILESYSTEM_MUTATION_OBSERVED_IN_COMPLETE_FROZEN_TRACE",
        "scope_of_claim": "FROZEN_V3_TRACE_SET_AND_CAPTURED_SYSCALL_CLASSES_ONLY",
        "authorized_observed_classes": ["BWRAP_TRANSIENT_NAMESPACE_CONSTRUCTION", "EXACT_NAMESPACE_CONTROL_PATH_WRITES", "PIPE_STDOUT_STDERR_PAYLOAD", "EVENTFD_PAYLOAD"],
        "unexpected_successful_pathname_mutation_count": len(inventory["unexpected_successful_pathname_mutation_events"]),
        "qualification": "This finding does not retroactively establish V3 confinement PASS and is not a claim about activity absent from the frozen capture boundary.",
    })
    write("CAUSAL_OWNERSHIP_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_CAUSAL_OWNERSHIP_ADJUDICATION", "schema_version": "1.0",
        "product_or_runtime_defect": "NO_EVIDENCE_FROM_THIS_FAILURE",
        "codex_binary_defect": "NO",
        "config_consumption_defect": "NO",
        "execution_launcher_defect": "NO_EVIDENCE_FROM_THIS_FAILURE",
        "post_validation_classifier_defect": "YES",
        "ownership_defects": ["POST_VALIDATION_UNTYPED_TRACE_TOKEN_CLASSIFIER", "POST_VALIDATION_FREE_TEXT_PATH_INFERENCE"],
        "confinement_bypass": "NO_EVIDENCE",
    })
    write("POST_VALIDATION_INCOMPLETENESS_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_POST_VALIDATION_INCOMPLETENESS_DECISION", "schema_version": "1.0",
        "frozen_primary_result": "53_OF_56_FAIL_CLOSED", "frozen_suite_result": "22_OF_24_FAIL_CLOSED",
        "failed_checks": ["filesystem_effects_confined", "suite_case:sandbox_expectation", "suite_case:filesystem_boundary"],
        "confinement": "NOT_PROVEN", "compatibility": "NOT_ESTABLISHED", "pass_locked_issued": False,
        "governance_effect": "ROOT_CAUSE_AND_SUCCESSOR_AUTHORIZATION_ONLY_NO_RETROACTIVE_PASS",
    })
    requirements = [
        "FRESH_EXECUTION_AND_SUITE_IDENTITIES", "FRESH_SOURCE_TESTS_MANIFEST_AND_STATIC_LOCK", "STATIC_LOCK_BEFORE_ATTEMPT",
        "SEMANTIC_SYSCALL_PATH_CLASSIFICATION", "TYPED_TRACE_EVIDENCE_CLASSES", "PATHNAME_BEARING_SYSCALL_ALLOWLIST_AND_ARGUMENT_ARITY",
        "WRITE_WRITEV_BUFFER_CLASSIFIED_AS_PAYLOAD_NOT_PATH", "FD_ANNOTATION_SEPARATE_FROM_SYSCALL_OPERANDS",
        "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE", "UNKNOWN_OR_AMBIGUOUS_SYSCALL_FAIL_CLOSED", "NO_BLANKET_PIPE_EXEMPTION",
        "NO_BLANKET_PROC_EXEMPTION", "SEMANTIC_EXECVE_LINEAGE_CLASSIFICATION", "EXACT_NAMESPACE_SETUP_WRITE_PROOF",
        "DEDICATED_CONFIG_EXISTS_SELECTED_AND_CONSUMED_PROOF", "EXACT_BINARY_CONFIG_ARGV_ENV_CWD_BINDING",
        "ONE_SHOT_ATTEMPT_NO_RETRY", "INDEPENDENT_POST_VALIDATION", "EVIDENCE_FREEZE", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    write("SUCCESSOR_V4_REQUIREMENTS.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_SUCCESSOR_V4_REQUIREMENTS", "schema_version": "1.0",
        "mandatory_requirements": requirements,
        "required_regressions": [
            "V3_WARNING_PIPE_PAYLOAD_NOT_PATH", "V3_EROFS_STDERR_TEXT_NOT_PATH", "V3_OS_ERROR_STDERR_FRAGMENT_NOT_PATH",
            "REAL_ABSOLUTE_PATHNAME_MUTATION_DETECTED", "REAL_RELATIVE_PATHNAME_MUTATION_DETECTED",
            "WRITE_BUFFER_CONTAINING_ABSOLUTE_PATH_NOT_PATH", "FD_PATH_ANNOTATION_NOT_PATHNAME_OPERAND",
            "UNKNOWN_SYSCALL_GRAMMAR_FAILS_CLOSED", "UNEXPECTED_PROC_WRITE_REJECTED",
        ],
        "prohibited_implementation_patterns": ["REGEX_SCAN_ALL_QUOTED_TRACE_TEXT", "SUBSTRING_PATH_INFERENCE", "BLANKET_PIPE_EXEMPTION", "BLANKET_PROC_EXEMPTION"],
    })
    write("SUCCESSOR_V4_AUTHORIZATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_SUCCESSOR_V4_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V4_CONDITIONALLY",
        "successor_execution_identity": V4_EXECUTION, "successor_suite_identity": V4_SUITE, "successor_path": str(V4),
        "state_at_governance_freeze": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt_count": 0, "attempt_limit": 1, "codex_invocation_count": 0, "codex_invocation_limit": 1,
        "authorization_scope": "ENGINEER_STATICALLY_VALIDATE_LOCK_AND_RUN_ONE_BOUNDED_COMPATIBILITY_ATTEMPT_ONLY_IF_ALL_GATES_PASS",
        "separate_acceptance_required": True, "requirements_reference": "SUCCESSOR_V4_REQUIREMENTS.json",
    })
    zero = {key: 0 for key in OPERATION_KEYS}
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "governance_only": True, "runtime_invoked_this_milestone": False, "codex_invoked_this_milestone": False,
        "v3_runtime_counters_preserved": runtime["operation_counters"], "governance_operation_counters": zero,
        "authority_not_opened": ["WORKER", "SUBAGENT", "CREDENTIAL", "TARGET", "EXTERNAL_NETWORK", "DAYBREAK", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION"],
    })
    matrix = {
        "GOVERNANCE_FROZEN_EVIDENCE_REVIEW": "CURRENTLY_AUTHORIZED",
        "V4_ENGINEERING_STATIC_VALIDATION_AND_LOCK": "CONDITIONALLY_AUTHORIZED_AFTER_THIS_PACKAGE_PASS_LOCKED",
        "V4_SINGLE_COMPATIBILITY_ATTEMPT": "CONDITIONALLY_AUTHORIZED_ONLY_AFTER_ALL_V4_PREATTEMPT_GATES_PASS",
        "V3_PATCH_RELOCK_REVALIDATE_RETRY": "PERMANENTLY_PROHIBITED_FOR_V3_IDENTITY",
        "WORKER_SUBAGENT_CREDENTIAL_TARGET_NETWORK_DAYBREAK_EXPLOIT_PARALLEL_CAPABILITY_PROMOTION_SUBMISSION": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
    }
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0", "matrix": matrix,
    })
    fixtures = [
        ["N001", "write stderr warning payload is not pathname", "PASS"],
        ["N002", "write stderr EROFS text is not pathname", "PASS"],
        ["N003", "write stderr os-error fragment is not pathname", "PASS"],
        ["N004", "write buffer containing /etc/passwd is still payload", "PASS"],
        ["N005", "pipe FD annotation is not pathname operand", "PASS"],
        ["N006", "filesystem FD annotation is not itself a pathname operand", "PASS"],
        ["N007", "mkdir absolute pathname is detected", "PASS"],
        ["N008", "mkdir relative pathname is detected", "PASS"],
        ["N009", "unlink pathname is detected", "PASS"],
        ["N010", "rename source and destination are detected", "PASS"],
        ["N011", "openat pathname position is detected", "PASS"],
        ["N012", "unknown syscall grammar fails closed", "PASS"],
        ["N013", "malformed trace fails closed", "PASS"],
        ["N014", "blanket pipe exemption rejected", "PASS"],
        ["N015", "blanket proc exemption rejected", "PASS"],
        ["N016", "unexpected proc mapping target rejected", "PASS"],
        ["N017", "V3 promotion rejected", "PASS"],
        ["N018", "V3 retry rejected", "PASS"],
        ["N019", "V3 patch rejected", "PASS"],
        ["N020", "V3 relock rejected", "PASS"],
        ["N021", "V3 revalidation rejected", "PASS"],
        ["N022", "V4 attempt before static lock rejected", "PASS"],
        ["N023", "V4 automatic retry rejected", "PASS"],
        ["N024", "V4 second invocation rejected", "PASS"],
        ["N025", "governance Codex invocation rejected", "PASS"],
        ["N026", "worker authority inference rejected", "PASS"],
        ["N027", "target authority inference rejected", "PASS"],
        ["N028", "network authority inference rejected", "PASS"],
        ["N029", "free-text regex path inference rejected", "PASS"],
        ["N030", "V4 success cannot bypass separate acceptance", "PASS"],
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0",
        "fixture_count": len(fixtures), "fixtures": [{"id": i, "case": c, "expected": e} for i, c, e in fixtures],
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_if_pass_locked": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4_ONCE_IF_ALL_GATES_PASS",
        "next_if_hold_or_fail": "HOLD_COMPATIBILITY_EXECUTION_BLOCKED",
        "successor_execution_identity": V4_EXECUTION, "successor_suite_identity": V4_SUITE,
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "v3_disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "pipe_payload_classifier_defect": "YES", "actual_out_of_scope_filesystem_activity_proven": "NO",
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "successor_decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V4_CONDITIONALLY",
        "no_retroactive_v3_promotion": True,
    })
    print(json.dumps({"status": "GOVERNANCE_SOURCE_ARTIFACTS_CREATED", "artifact_count": 18, "v4_created": V4.exists(), "codex_invocations": 0}, sort_keys=True))


if __name__ == "__main__":
    main()
