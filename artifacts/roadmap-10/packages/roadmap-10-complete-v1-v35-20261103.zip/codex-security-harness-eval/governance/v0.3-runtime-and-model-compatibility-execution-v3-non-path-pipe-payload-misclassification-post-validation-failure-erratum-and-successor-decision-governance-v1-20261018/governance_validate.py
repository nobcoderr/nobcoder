#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v2-execve-lineage-and-namespace-setup-write-classification-post-validation-failure-erratum-and-successor-decision-governance-v1-20261017")
V3 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v3-20261017")
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3_NON_PATH_PIPE_PAYLOAD_MISCLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"

HASHES = {
    "predecessor_lock": "3d75fc21aa689b4a40a5c83e8751bce5f87bfcae60a88c9db8ef3eb7ea833669",
    "predecessor_manifest": "4acedb4881f46c46241e4287709da05ebae39a41aae692c68a3aaf825e407e53",
    "v3_source_manifest": "28b02da30f5c724d8dfa72d1996887e7ee9e54dadc5209751c5ed5f8bb003ec4",
    "v3_static_lock": "74276275026a38d7d157cca874539abd2c6a5240ea2b9549498061321b1e3a3b",
    "v3_lock_verification": "a3a5703c17b65951d9d0574ed092f75219c002659240113d23f7123c7bc0753e",
    "v3_post": "b7eea278da6684c578f53872b39b87e49c7f1fab0f2be929238ef6a891262561",
    "v3_runtime": "4e22c3e1f4a8f4af7d4cc021d233f90b5d5a4bb116d33c1d434ba7761891cad1",
    "v3_evidence_manifest": "ab7354be2600e7d67116ca8bae81bdb3f43c468eaab979f488273f991c0499d1",
    "v3_evidence_lock": "5d0b332abdd3960d43a76b4c82c124bf2f3578657c867c41077650da29fa5e4f",
    "v3_human_gate": "bb9412aa38672ab8ef56f58068631bdea72696d019fa3a11dab261f8831f80e2",
    "global_config": "9f559aff9c257410098b0576c48350d55c3da00ad08d3bf5702db20063e25c59",
}

BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V3_FROZEN_EVIDENCE_BINDING.json", "V3_TERMINAL_DISPOSITION.json", "TYPED_TRACE_EVIDENCE_MODEL.json",
    "TRACE_EVENT_INVENTORY.json", "PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION.json", "FILESYSTEM_ACTIVITY_ADJUDICATION.json",
    "CAUSAL_OWNERSHIP_ADJUDICATION.json", "POST_VALIDATION_INCOMPLETENESS_DECISION.json",
    "SUCCESSOR_V4_REQUIREMENTS.json", "SUCCESSOR_V4_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEXT_LEGAL_MILESTONE.json", "GOVERNANCE_DECISION_SUMMARY.json",
}
SCRIPTS = {"build_governance.py", "governance_validate.py", "negative_validate.py", "independent_validate.py", "freeze_verify.py", "finalize_governance.py"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    data = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(data.encode()).hexdigest()


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, ok: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if ok else "FAIL", "evidence": evidence})

    check("G001_ROOT", ROOT.is_dir() and not ROOT.is_symlink())
    check("G002_V3_EXISTS", V3.is_dir() and not V3.is_symlink())
    check("G003_V4_ABSENT", not V4.exists() and not V4.is_symlink())
    historical_results = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"}
    check("G004_FILE_SET", {p.name for p in ROOT.iterdir() if p.is_file()} == BASE | SCRIPTS | historical_results)
    check("G005_NO_SYMLINKS", all(not p.is_symlink() for p in ROOT.iterdir()))
    for name in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / name).read_text(encoding="utf-8"))
            parsed = True
        except Exception:
            parsed = False
        check(f"G_SYNTAX_{name}", parsed)
    for name in sorted(BASE):
        try:
            value = load(name)
            parsed = isinstance(value, dict)
        except Exception:
            parsed = False
            value = {}
        check(f"G_JSON_{name}", parsed)
        check(f"G_ID_{name}", value.get("governance_identity") == IDENTITY)

    pred_manifest = json.loads((PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json").read_text())
    pred_lock = json.loads((PRED / "GOVERNANCE_LOCK.json").read_text())
    check("G006_PRED_LOCK_HASH", sha(PRED / "GOVERNANCE_LOCK.json") == HASHES["predecessor_lock"])
    check("G007_PRED_MANIFEST_HASH", sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == HASHES["predecessor_manifest"])
    check("G008_PRED_MEMBER_HASHES", all(sha(PRED / row["path"]) == row["sha256"] for row in pred_manifest["members"]))
    pred_artifact_root = canonical_root(pred_manifest["members"] + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": HASHES["predecessor_manifest"], "bytes": (PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    check("G009_PRED_ROOT", pred_artifact_root == pred_lock["canonical_artifact_root_sha256"] == "4c448e5949945147729a32cad9a1e9864ee134766694dedc3a69aebbfd9b8ab6")
    expected_v3 = {
        "STATIC_SOURCE_MANIFEST.json": "v3_source_manifest",
        "STATIC_EXECUTION_LOCK.json": "v3_static_lock",
        "STATIC_EXECUTION_LOCK_VERIFICATION.json": "v3_lock_verification",
        "static-run-v1/independent-post-validation-0001.json": "v3_post",
        "static-run-v1/runtime-result-0001.json": "v3_runtime",
        "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json": "v3_evidence_manifest",
        "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json": "v3_evidence_lock",
        "HUMAN_GATE.json": "v3_human_gate",
    }
    for rel, key in expected_v3.items():
        check(f"G_V3_HASH_{key}", sha(V3 / rel) == HASHES[key])
    check("G010_GLOBAL_CONFIG", sha(Path("/home/nobcoder/.codex/config.toml")) == HASHES["global_config"])
    check("G011_V3_READ_ONLY", all((p.stat().st_mode & 0o222) == 0 for p in V3.rglob("*") if p.is_file()))

    em = json.loads((V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json").read_text())
    el = json.loads((V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json").read_text())
    check("G012_V3_EVIDENCE_MEMBERS", all(sha(V3 / "static-run-v1" / row["path"]) == row["sha256"] for row in em["members"]))
    check("G013_V3_EVIDENCE_ROOT", canonical_root(em["members"]) == em["canonical_evidence_root_sha256"] == el["canonical_evidence_root_sha256"] == "b42e1441ab330f3c899a94d8b584062d0fea5601201dd68baa8d9ddb88a50f52")
    post = json.loads((V3 / "static-run-v1/independent-post-validation-0001.json").read_text())
    runtime = json.loads((V3 / "static-run-v1/runtime-result-0001.json").read_text())
    check("G014_POST_FAIL", post["status"] == "FAIL_CLOSED" and post["validation_counts"] == {"total": 56, "passed": 53, "failed": 3})
    check("G015_SUITE_FAIL", post["suite_counts"] == {"total": 24, "passed": 22, "failed": 2})
    failed_names = [row["name"] for row in post["checks"] if row["status"] != "PASS"]
    check("G016_FAILED_CHECKS", failed_names == ["filesystem_effects_confined", "suite_case:sandbox_expectation", "suite_case:filesystem_boundary"], failed_names)
    check("G017_RUNTIME_COUNTS", runtime["attempt_count"] == runtime["codex_cli_invocation_count"] == runtime["runtime_invocation_count"] == 1)
    check("G018_RUNTIME_EXIT", runtime["exit_code"] == 0)

    terminal = load("V3_TERMINAL_DISPOSITION.json")
    check("G019_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("G020_NO_V3_CONTINUATION", all(terminal[key] == "PROHIBITED" for key in ("patch", "relock", "revalidation", "retry", "promotion")))
    check("G021_NO_RETRO_PASS", terminal["compatibility"] == "NOT_ESTABLISHED" and terminal["confinement"] == "NOT_PROVEN")
    model = load("TYPED_TRACE_EVIDENCE_MODEL.json")
    required_classes = {"FILESYSTEM_PATHNAME_BEARING_SYSCALL_OPERAND", "FD_PIPE_PAYLOAD", "STDERR_TEXT", "GENERIC_SYSCALL_OPERAND", "FD_ANNOTATION", "NAMESPACE_CONTROL_PATH"}
    check("G022_TYPED_CLASSES", set(model["classes"]) == required_classes)
    check("G023_NO_FREE_TEXT_RULE", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE_OVER_RAW_TRACE_LINES" in model["classification_rules"])
    check("G024_UNKNOWN_FAIL_CLOSED", "UNKNOWN_OR_AMBIGUOUS_SYSCALL_GRAMMAR_FAILS_CLOSED" in model["classification_rules"])

    pipe = load("PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION.json")
    check("G025_CLASSIFIER_DEFECT", pipe["classifier_defect"] is True)
    check("G026_CLASSIFIER_VERDICT", pipe["verdict"] == "CONFIRMED_NON_PATH_PIPE_AND_STDERR_PAYLOAD_MISCLASSIFICATION")
    check("G027_EXACT_THREE", len(pipe["frozen_rejected_lines"]) == 3)
    check("G028_TYPED_THREE", all(row["filesystem_pathname_operand"] is False and row["filesystem_event"] is False and row["fd"] == 2 and "FD_PIPE_PAYLOAD" in row["typed_evidence_classes"] and "STDERR_TEXT" in row["typed_evidence_classes"] for row in pipe["frozen_rejected_lines"]))
    trace_combined = "\n".join(p.read_text(encoding="utf-8", errors="replace") for p in sorted((V3 / "static-run-v1").glob("trace.*")))
    check("G029_LINES_EXIST", all(row["line"] in trace_combined for row in pipe["frozen_rejected_lines"]))
    source = (V3 / "validators/post_validate.py").read_text(encoding="utf-8")
    check("G030_SOURCE_FREE_TEXT_SCAN", "QUOTED_PATH_RE.finditer(line)" in source)
    check("G031_SOURCE_REJECTION_BRANCH", "else:\n                    rejected.append(line)" in source)

    inventory = load("TRACE_EVENT_INVENTORY.json")["inventory"]
    check("G032_TRACE_FILES", inventory["trace_file_count"] == 22)
    check("G033_WRITE_COUNT", inventory["successful_write_writev_events"] == 182)
    check("G034_PIPE_COUNT", inventory["fd_pipe_payload_events"] == 173)
    check("G035_STDERR_COUNT", inventory["stderr_pipe_payload_events"] == 6)
    check("G036_EVENTFD_COUNT", inventory["eventfd_payload_events"] == 4)
    check("G037_NAMESPACE_COUNT", inventory["namespace_control_path_writes"] == 5)
    check("G038_PATH_MUTATION_COUNT", inventory["successful_pathname_mutation_events"] == 17)
    check("G039_PATH_MUTATION_LINEAGE", all(row["trace"] == "trace.378989" and row["classification"] == "AUTHORIZED_BWRAP_TRANSIENT_NAMESPACE_CONSTRUCTION" for row in inventory["pathname_mutation_events"]))
    check("G040_NO_UNEXPECTED_PATH_MUTATION", inventory["unexpected_successful_pathname_mutation_events"] == [])

    fs = load("FILESYSTEM_ACTIVITY_ADJUDICATION.json")
    check("G041_NO_OOS_PROVEN", fs["actual_out_of_scope_filesystem_activity_proven"] is False)
    check("G042_QUALIFIED_SCOPE", fs["scope_of_claim"] == "FROZEN_V3_TRACE_SET_AND_CAPTURED_SYSCALL_CLASSES_ONLY")
    check("G043_NO_RETRO_CONFINEMENT", "does not retroactively establish V3 confinement PASS" in fs["qualification"])
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    check("G044_OWNERSHIP", ownership["post_validation_classifier_defect"] == "YES" and set(ownership["ownership_defects"]) == {"POST_VALIDATION_UNTYPED_TRACE_TOKEN_CLASSIFIER", "POST_VALIDATION_FREE_TEXT_PATH_INFERENCE"})
    check("G045_NO_RUNTIME_DEFECT", ownership["codex_binary_defect"] == "NO" and ownership["config_consumption_defect"] == "NO")
    check("G046_NO_BYPASS", ownership["confinement_bypass"] == "NO_EVIDENCE")

    successor = load("SUCCESSOR_V4_AUTHORIZATION_DECISION.json")
    requirements = load("SUCCESSOR_V4_REQUIREMENTS.json")
    check("G047_SUCCESSOR", successor["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V4_CONDITIONALLY")
    check("G048_V4_IDENTITIES", successor["successor_execution_identity"] == "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4" and successor["successor_suite_identity"] == "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V5")
    check("G049_V4_ZERO", successor["attempt_count"] == successor["codex_invocation_count"] == 0)
    check("G050_V4_ONE", successor["attempt_limit"] == successor["codex_invocation_limit"] == 1)
    check("G051_SEPARATE_ACCEPTANCE", successor["separate_acceptance_required"] is True)
    required = set(requirements["mandatory_requirements"])
    check("G052_SEMANTIC_REQUIRED", {"SEMANTIC_SYSCALL_PATH_CLASSIFICATION", "TYPED_TRACE_EVIDENCE_CLASSES", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE", "UNKNOWN_OR_AMBIGUOUS_SYSCALL_FAIL_CLOSED"}.issubset(required))
    check("G053_PRIOR_LESSONS", {"SEMANTIC_EXECVE_LINEAGE_CLASSIFICATION", "EXACT_NAMESPACE_SETUP_WRITE_PROOF", "DEDICATED_CONFIG_EXISTS_SELECTED_AND_CONSUMED_PROOF"}.issubset(required))
    check("G054_REGRESSIONS", len(requirements["required_regressions"]) == 9)
    check("G055_PROHIBITED_PATTERNS", "REGEX_SCAN_ALL_QUOTED_TRACE_TEXT" in requirements["prohibited_implementation_patterns"])

    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    check("G056_GOVERNANCE_ONLY", authority["governance_only"] is True and authority["runtime_invoked_this_milestone"] is False and authority["codex_invoked_this_milestone"] is False)
    check("G057_ZERO_OPS", all(value == 0 for value in authority["governance_operation_counters"].values()))
    check("G058_RUNTIME_HISTORY", authority["v3_runtime_counters_preserved"] == runtime["operation_counters"])
    check("G059_NO_AUTHORITY_ESCALATION", len(authority["authority_not_opened"]) == 11)
    negative = load("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    check("G060_NEGATIVE_MATRIX", negative["fixture_count"] == len(negative["fixtures"]) == 30)
    check("G061_NEGATIVE_EXPECTED", all(row["expected"] == "PASS" for row in negative["fixtures"]))
    summary = load("GOVERNANCE_DECISION_SUMMARY.json")
    check("G062_SUMMARY", summary["pipe_payload_classifier_defect"] == "YES" and summary["actual_out_of_scope_filesystem_activity_proven"] == "NO" and summary["confinement"] == "NOT_PROVEN")
    check("G063_NEXT", load("NEXT_LEGAL_MILESTONE.json")["next_if_pass_locked"] == "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4_ONCE_IF_ALL_GATES_PASS")

    failed = [row for row in checks if row["status"] == "FAIL"]
    payload = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0", "governance_identity": IDENTITY, "run_id": "GOVERNANCE_VALIDATION_RUN-0002",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed), "checks_failed": len(failed), "checks": checks,
    }
    with (ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0002.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True); handle.write("\n")
    print(json.dumps({key: payload[key] for key in ("status", "checks_total", "checks_passed", "checks_failed")}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
