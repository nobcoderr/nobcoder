#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3_NON_PATH_PIPE_PAYLOAD_MISCLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"

PATH_POSITIONS = {
    "open": (0,), "openat": (1,), "creat": (0,), "mkdir": (0,), "mkdirat": (1,),
    "unlink": (0,), "unlinkat": (1,), "rename": (0, 1), "renameat": (1, 3),
    "renameat2": (1, 3), "link": (0, 1), "linkat": (1, 3), "symlink": (1,),
    "symlinkat": (2,), "truncate": (0,), "chmod": (0,), "fchmodat": (1,),
    "chown": (0,), "fchownat": (1,), "mknod": (0,), "mknodat": (1,),
}


def split_args(text: str) -> list[str]:
    args: list[str] = []
    start = 0
    depth = 0
    quoted = False
    escaped = False
    for index, char in enumerate(text):
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in "([{":
            depth += 1
        elif char in ")]}":
            depth -= 1
        elif char == "," and depth == 0:
            args.append(text[start:index].strip())
            start = index + 1
    args.append(text[start:].strip())
    return args


def parse(line: str) -> dict[str, Any]:
    match = re.match(r"^(?P<name>[a-zA-Z0-9_]+)\((?P<args>.*)\)\s+=\s+(?P<rc>-?[0-9]+)(?:<[^>]+>)?\s*$", line)
    if not match:
        return {"status": "FAIL_CLOSED_MALFORMED", "pathname_operands": []}
    name = match.group("name")
    args = split_args(match.group("args"))
    if name in {"write", "writev"}:
        if len(args) < 3:
            return {"status": "FAIL_CLOSED_MALFORMED", "syscall": name, "pathname_operands": []}
        if name == "write" and re.fullmatch(r'"(?:\\.|[^"\\])*"', args[1]) is None:
            return {"status": "FAIL_CLOSED_MALFORMED", "syscall": name, "pathname_operands": []}
        if name == "writev" and not args[1].startswith("["):
            return {"status": "FAIL_CLOSED_MALFORMED", "syscall": name, "pathname_operands": []}
        fd = args[0] if args else ""
        classes = ["GENERIC_SYSCALL_OPERAND"]
        if "<pipe:[" in fd:
            classes.append("FD_PIPE_PAYLOAD")
            if fd.startswith("2<"):
                classes.append("STDERR_TEXT")
        if "</" in fd:
            classes.append("FD_ANNOTATION")
        return {"status": "TYPED_NON_PATH", "syscall": name, "classes": classes, "pathname_operands": [], "authorization": "REQUIRES_SEPARATE_POLICY_CHECK"}
    if name not in PATH_POSITIONS:
        return {"status": "FAIL_CLOSED_UNKNOWN_GRAMMAR", "syscall": name, "pathname_operands": []}
    positions = PATH_POSITIONS[name]
    if any(position >= len(args) for position in positions):
        return {"status": "FAIL_CLOSED_MALFORMED", "syscall": name, "pathname_operands": []}
    paths = []
    for position in positions:
        token = args[position]
        quoted = re.fullmatch(r'"((?:\\.|[^"\\])*)"', token)
        if not quoted:
            return {"status": "FAIL_CLOSED_MALFORMED", "syscall": name, "pathname_operands": []}
        paths.append(quoted.group(1))
    return {"status": "TYPED_PATHNAME", "syscall": name, "pathname_operands": paths}


def main() -> None:
    terminal = json.loads((ROOT / "V3_TERMINAL_DISPOSITION.json").read_text())
    successor = json.loads((ROOT / "SUCCESSOR_V4_AUTHORIZATION_DECISION.json").read_text())
    requirements = json.loads((ROOT / "SUCCESSOR_V4_REQUIREMENTS.json").read_text())
    authority = json.loads((ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json").read_text())
    tests: list[dict[str, Any]] = []

    def test(test_id: str, condition: bool, evidence: Any = None) -> None:
        tests.append({"test_id": test_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    cases = [
        'write(2<pipe:[1287697]>, "WARNING: proceeding, even though we could not create PATH aliases: ", 67) = 67',
        'write(2<pipe:[1287697]>, "Read-only file system", 21) = 21',
        'write(2<pipe:[1287697]>, " (os error ", 11) = 11',
    ]
    for index, line in enumerate(cases, 1):
        result = parse(line)
        test(f"N{index:03d}_V3_PAYLOAD", result["status"] == "TYPED_NON_PATH" and result["pathname_operands"] == [] and "STDERR_TEXT" in result["classes"], result)
    r = parse('write(2<pipe:[7]>, "/etc/passwd", 11) = 11')
    test("N004_ABSOLUTE_TEXT_PAYLOAD", r["status"] == "TYPED_NON_PATH" and r["pathname_operands"] == [], r)
    r = parse('write(1<pipe:[8]>, "tmp/output", 10) = 10')
    test("N005_RELATIVE_TEXT_PAYLOAD", r["status"] == "TYPED_NON_PATH" and "FD_PIPE_PAYLOAD" in r["classes"], r)
    r = parse('write(4</tmp/file>, "data", 4) = 4')
    test("N006_FD_ANNOTATION_DISTINCT", r["status"] == "TYPED_NON_PATH" and "FD_ANNOTATION" in r["classes"] and r["pathname_operands"] == [], r)
    r = parse('mkdir("/tmp/escape", 0700) = 0')
    test("N007_ABSOLUTE_MKDIR", r["pathname_operands"] == ["/tmp/escape"], r)
    r = parse('mkdir("relative", 0700) = 0')
    test("N008_RELATIVE_MKDIR", r["pathname_operands"] == ["relative"], r)
    r = parse('unlink("/tmp/escape") = 0')
    test("N009_UNLINK", r["pathname_operands"] == ["/tmp/escape"], r)
    r = parse('rename("/tmp/a", "/tmp/b") = 0')
    test("N010_RENAME", r["pathname_operands"] == ["/tmp/a", "/tmp/b"], r)
    r = parse('openat(AT_FDCWD, "/tmp/a", O_WRONLY|O_CREAT, 0600) = 3</tmp/a>')
    test("N011_OPENAT", r["pathname_operands"] == ["/tmp/a"], r)
    r = parse('future_path_call("/tmp/a") = 0')
    test("N012_UNKNOWN_FAIL_CLOSED", r["status"] == "FAIL_CLOSED_UNKNOWN_GRAMMAR", r)
    r = parse('write(2<pipe:[7]>, "unterminated, 4) = 4')
    test("N013_MALFORMED_FAIL_CLOSED", r["status"] == "FAIL_CLOSED_MALFORMED", r)
    r = parse('write(2<pipe:[7]>, "ok", 2) = 2')
    test("N014_NO_BLANKET_PIPE_AUTH", r["authorization"] == "REQUIRES_SEPARATE_POLICY_CHECK", r)
    test("N015_NO_BLANKET_PROC", "NO_BLANKET_PROC_EXEMPTION" in requirements["mandatory_requirements"])
    test("N016_UNEXPECTED_PROC_REJECTED", "/proc/999/status" not in {"/proc/378989/uid_map", "/proc/378989/gid_map", "/proc/378989/setgroups"})
    test("N017_V3_NO_PROMOTION", terminal["promotion"] == "PROHIBITED")
    test("N018_V3_NO_RETRY", terminal["retry"] == "PROHIBITED")
    test("N019_V3_NO_PATCH", terminal["patch"] == "PROHIBITED")
    test("N020_V3_NO_RELOCK", terminal["relock"] == "PROHIBITED")
    test("N021_V3_NO_REVALIDATE", terminal["revalidation"] == "PROHIBITED")
    test("N022_V4_NOT_CREATED", not V4.exists() and not V4.is_symlink())
    test("N023_V4_ONE_SHOT", successor["attempt_limit"] == 1)
    test("N024_V4_ONE_CODEX", successor["codex_invocation_limit"] == 1)
    test("N025_NO_CODEX_GOVERNANCE", authority["codex_invoked_this_milestone"] is False and authority["governance_operation_counters"]["codex_cli_invocations"] == 0)
    test("N026_NO_WORKER", authority["governance_operation_counters"]["worker_processes"] == 0)
    test("N027_NO_TARGET", authority["governance_operation_counters"]["target_operations"] == 0)
    test("N028_NO_NETWORK", authority["governance_operation_counters"]["external_network_operations"] == 0)
    test("N029_NO_REGEX_INFERENCE", "REGEX_SCAN_ALL_QUOTED_TRACE_TEXT" in requirements["prohibited_implementation_patterns"])
    test("N030_SEPARATE_ACCEPTANCE", successor["separate_acceptance_required"] is True)

    failed = [row for row in tests if row["status"] == "FAIL"]
    payload = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "schema_version": "1.0", "governance_identity": IDENTITY, "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0002",
        "status": "PASS" if not failed else "FAIL_CLOSED", "tests_total": len(tests),
        "tests_passed": len(tests) - len(failed), "tests_failed": len(failed), "tests": tests,
        "operation_counters": authority["governance_operation_counters"],
    }
    with (ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True); handle.write("\n")
    print(json.dumps({key: payload[key] for key in ("status", "tests_total", "tests_passed", "tests_failed")}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
