#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V3 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v3-20261017")
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3_NON_PATH_PIPE_PAYLOAD_MISCLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    post_path = V3 / "static-run-v1/independent-post-validation-0001.json"
    runtime_path = V3 / "static-run-v1/runtime-result-0001.json"
    source_path = V3 / "validators/post_validate.py"
    post = json.loads(post_path.read_text())
    runtime = json.loads(runtime_path.read_text())
    frozen_rejected = post["filesystem_effect_classification"]["rejected"]
    traces: list[tuple[str, int, str]] = []
    for path in sorted((V3 / "static-run-v1").glob("trace.*")):
        for number, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            traces.append((path.name, number, line.strip()))

    check("I001_V3_POST_HASH", sha(post_path) == "b7eea278da6684c578f53872b39b87e49c7f1fab0f2be929238ef6a891262561")
    check("I002_V3_RUNTIME_HASH", sha(runtime_path) == "4e22c3e1f4a8f4af7d4cc021d233f90b5d5a4bb116d33c1d434ba7761891cad1")
    check("I003_V3_FREEZE_HASH", sha(V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json") == "5d0b332abdd3960d43a76b4c82c124bf2f3578657c867c41077650da29fa5e4f")
    check("I004_V3_TERMINAL", load("V3_TERMINAL_DISPOSITION.json")["disposition"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("I005_V4_ABSENT", not V4.exists() and not V4.is_symlink())
    check("I006_POST_STILL_FAIL", post["status"] == "FAIL_CLOSED" and post["validation_counts"]["failed"] == 3)
    check("I007_COMPAT_NOT_ESTABLISHED", load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")["compatibility"] == "NOT_ESTABLISHED")
    check("I008_CONFINEMENT_NOT_PROVEN", load("POST_VALIDATION_INCOMPLETENESS_DECISION.json")["confinement"] == "NOT_PROVEN")

    exact_events = []
    for rejected in frozen_rejected:
        matches = [(name, number, line) for name, number, line in traces if line == rejected]
        exact_events.append(matches)
    check("I009_THREE_REJECTED", len(frozen_rejected) == 3)
    check("I010_EACH_REJECTED_ONCE", all(len(matches) == 1 for matches in exact_events), [len(matches) for matches in exact_events])
    flat = [matches[0] for matches in exact_events]
    parsed = []
    pattern = re.compile(r'^write\((?P<fd>[0-9]+)<(?P<kind>pipe:\[[0-9]+\])>,\s+"(?P<payload>(?:\\.|[^"\\])*)",\s+(?P<count>[0-9]+)\)\s+=\s+(?P<rc>[0-9]+)$')
    for trace, number, line in flat:
        match = pattern.match(line)
        parsed.append({"trace": trace, "line": number, **(match.groupdict() if match else {})})
    check("I011_TYPED_PARSE", all(set(row) >= {"fd", "kind", "payload", "count", "rc"} for row in parsed), parsed)
    check("I012_FD2", all(row.get("fd") == "2" for row in parsed), parsed)
    check("I013_PIPE", all(row.get("kind", "").startswith("pipe:") for row in parsed), parsed)
    check("I014_LENGTHS", all(int(row["count"]) == int(row["rc"]) for row in parsed), parsed)
    check("I015_NO_PATHNAME_POSITION", all(row.get("payload") is not None for row in parsed) and all("pathname" not in row for row in parsed))

    source = source_path.read_text(encoding="utf-8")
    check("I016_LOCKED_REGEX_EXISTS", 'QUOTED_PATH_RE = re.compile' in source)
    check("I017_LOCKED_FALLBACK_EXISTS", 'quoted = [match.group("path") for match in QUOTED_PATH_RE.finditer(line)]' in source)
    check("I018_LOCKED_REJECTS_QUOTED", 'elif not quoted:' in source and 'else:\n                    rejected.append(line)' in source)
    adjudication = load("PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION.json")
    check("I019_DEFECT_DECISION", adjudication["classifier_defect"] is True)
    check("I020_ROOT_CAUSE_MATCH", adjudication["root_cause"] == "LOCKED_POST_VALIDATOR_USED_QUOTED_FREE_TEXT_AS_A_RELATIVE_PATH_PROXY_AFTER_NO_ABSOLUTE_FD_ANNOTATION_MATCH")
    check("I021_NO_V3_RECLASSIFICATION", adjudication["v3_result_reclassification"] == "PROHIBITED")

    successful_writes: list[str] = []
    unexpected_write_targets: list[str] = []
    namespace_targets: list[str] = []
    pipe_count = 0
    eventfd_count = 0
    for _trace, _number, line in traces:
        if not line.startswith(("write(", "writev(")) or re.search(r"=\s+-1(?:\D|$)", line):
            continue
        if not re.search(r"=\s+[0-9]+\s*$", line):
            continue
        successful_writes.append(line)
        fd = line.split(",", 1)[0]
        if "<pipe:[" in fd:
            pipe_count += 1
        elif "eventfd" in fd:
            eventfd_count += 1
        else:
            match = re.search(r"<(/proc/[0-9]+/(?:uid_map|gid_map|setgroups))>", fd)
            if match:
                namespace_targets.append(match.group(1))
            else:
                unexpected_write_targets.append(fd)
    check("I022_SUCCESSFUL_WRITES", len(successful_writes) == 182, len(successful_writes))
    check("I023_PIPE_WRITES", pipe_count == 173, pipe_count)
    check("I024_EVENTFD_WRITES", eventfd_count == 4, eventfd_count)
    check("I025_NAMESPACE_WRITES", len(namespace_targets) == 5, namespace_targets)
    check("I026_NO_UNKNOWN_WRITE_TARGET", unexpected_write_targets == [], unexpected_write_targets)
    check("I027_NAMESPACE_TARGET_SET", set(namespace_targets) == {"/proc/378989/uid_map", "/proc/378989/gid_map", "/proc/378989/setgroups"})

    target_positions = {
        "creat": (0,), "mkdir": (0,), "mkdirat": (1,), "unlink": (0,), "unlinkat": (1,),
        "rename": (0, 1), "renameat": (1, 3), "renameat2": (1, 3), "link": (0, 1),
        "linkat": (1, 3), "symlink": (1,), "symlinkat": (2,), "truncate": (0,),
        "chmod": (0,), "fchmodat": (1,), "chown": (0,), "fchownat": (1,), "mknod": (0,), "mknodat": (1,),
    }
    mutation_events: list[dict[str, Any]] = []
    unexpected_mutations: list[dict[str, Any]] = []
    for trace, number, line in traces:
        syscall_match = re.match(r"^(?P<name>[a-z0-9_]+)\(", line)
        if not syscall_match or syscall_match.group("name") not in target_positions or re.search(r"=\s+-1(?:\D|$)", line):
            continue
        if not re.search(r"=\s+(?:0|[1-9][0-9]*)(?:<[^>]+>)?\s*$", line):
            continue
        name = syscall_match.group("name")
        quoted = re.findall(r'"((?:\\.|[^"\\])*)"', line)
        # All observed successful V3 mutation calls are simple forms; for symlink,
        # the destination is the second quoted operand.
        targets = quoted[1:2] if name == "symlink" else quoted[:1]
        event = {"trace": trace, "line_number": number, "syscall": name, "targets": targets, "raw": line}
        mutation_events.append(event)
        allowed = trace == "trace.378989" and all(target in {"newroot", "oldroot"} or target.startswith("/newroot/") for target in targets)
        if not allowed:
            unexpected_mutations.append(event)
    check("I028_MUTATION_COUNT", len(mutation_events) == 17, len(mutation_events))
    check("I029_MUTATION_SUPERVISOR", all(row["trace"] == "trace.378989" for row in mutation_events))
    check("I030_MUTATION_TOPOLOGY", unexpected_mutations == [], unexpected_mutations)
    codex_ero_fs = [line for trace, _number, line in traces if trace == "trace.379003" and line.startswith('mkdir("/home/nobcoder/') and "EROFS" in line]
    check("I031_CODEX_WRITE_DENIED", len(codex_ero_fs) == 1, codex_ero_fs)

    fs = load("FILESYSTEM_ACTIVITY_ADJUDICATION.json")
    check("I032_OOS_NOT_PROVEN", fs["actual_out_of_scope_filesystem_activity_proven"] is False)
    check("I033_CLAIM_BOUNDED", fs["scope_of_claim"] == "FROZEN_V3_TRACE_SET_AND_CAPTURED_SYSCALL_CLASSES_ONLY")
    check("I034_NO_RETRO_PASS", "does not retroactively establish V3 confinement PASS" in fs["qualification"])
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    check("I035_CLASSIFIER_OWNERSHIP", ownership["post_validation_classifier_defect"] == "YES")
    check("I036_NO_PRODUCT_CLAIM", ownership["product_or_runtime_defect"] == "NO_EVIDENCE_FROM_THIS_FAILURE")
    check("I037_NO_BYPASS_CLAIM", ownership["confinement_bypass"] == "NO_EVIDENCE")

    model = load("TYPED_TRACE_EVIDENCE_MODEL.json")
    check("I038_TYPED_SEPARATION", all(key in model["classes"] for key in ("FILESYSTEM_PATHNAME_BEARING_SYSCALL_OPERAND", "FD_PIPE_PAYLOAD", "STDERR_TEXT", "GENERIC_SYSCALL_OPERAND")))
    check("I039_FD_DISTINCT", "FD_ANNOTATION" in model["classes"])
    check("I040_NO_REGEX_RULE", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE_OVER_RAW_TRACE_LINES" in model["classification_rules"])
    check("I041_FAIL_CLOSED_RULE", "UNKNOWN_OR_AMBIGUOUS_SYSCALL_GRAMMAR_FAILS_CLOSED" in model["classification_rules"])

    successor = load("SUCCESSOR_V4_AUTHORIZATION_DECISION.json")
    requirements = load("SUCCESSOR_V4_REQUIREMENTS.json")
    check("I042_SUCCESSOR_AUTH", successor["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V4_CONDITIONALLY")
    check("I043_SUCCESSOR_ZERO", successor["attempt_count"] == successor["codex_invocation_count"] == 0)
    check("I044_SUCCESSOR_FRESH", "FRESH_EXECUTION_AND_SUITE_IDENTITIES" in requirements["mandatory_requirements"] and "FRESH_SOURCE_TESTS_MANIFEST_AND_STATIC_LOCK" in requirements["mandatory_requirements"])
    check("I045_SUCCESSOR_SEMANTIC", "SEMANTIC_SYSCALL_PATH_CLASSIFICATION" in requirements["mandatory_requirements"])
    check("I046_SUCCESSOR_NO_FREE_TEXT", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE" in requirements["mandatory_requirements"])
    check("I047_SUCCESSOR_NO_RETRY", "ONE_SHOT_ATTEMPT_NO_RETRY" in requirements["mandatory_requirements"])
    check("I048_SEPARATE_ACCEPTANCE", successor["separate_acceptance_required"] is True)

    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    check("I049_ZERO_GOV_OPS", all(value == 0 for value in authority["governance_operation_counters"].values()))
    check("I050_NO_RUNTIME_THIS_MILESTONE", authority["runtime_invoked_this_milestone"] is False and authority["codex_invoked_this_milestone"] is False)
    check("I051_NO_OTHER_AUTHORITY", len(authority["authority_not_opened"]) == 11)
    check("I052_ROUTING_NO_SUBAGENTS", load("ROUTING_LEDGER.json")["subagents_used"] is False)

    failed = [row for row in checks if row["status"] == "FAIL"]
    payload = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0", "governance_identity": IDENTITY, "run_id": "INDEPENDENT_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed), "checks_failed": len(failed), "checks": checks,
        "independent_trace_summary": {
            "successful_write_writev_events": len(successful_writes), "pipe_payload_events": pipe_count,
            "eventfd_events": eventfd_count, "namespace_control_writes": len(namespace_targets),
            "successful_pathname_mutation_events": len(mutation_events), "unexpected_pathname_mutations": len(unexpected_mutations),
        },
    }
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True); handle.write("\n")
    print(json.dumps({key: payload[key] for key in ("status", "checks_total", "checks_passed", "checks_failed")}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
