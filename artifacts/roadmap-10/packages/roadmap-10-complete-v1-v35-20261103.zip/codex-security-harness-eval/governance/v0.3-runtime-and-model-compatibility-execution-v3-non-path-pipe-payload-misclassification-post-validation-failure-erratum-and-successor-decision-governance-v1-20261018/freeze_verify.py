#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v2-execve-lineage-and-namespace-setup-write-classification-post-validation-failure-erratum-and-successor-decision-governance-v1-20261017")
V3 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v3-20261017")
V4 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v4-20261018")
GLOBAL_CONFIG = Path("/home/nobcoder/.codex/config.toml")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3_NON_PATH_PIPE_PAYLOAD_MISCLASSIFICATION_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"

SCRIPTS = {"build_governance.py", "governance_validate.py", "negative_validate.py", "independent_validate.py", "freeze_verify.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V3_FROZEN_EVIDENCE_BINDING.json", "V3_TERMINAL_DISPOSITION.json", "TYPED_TRACE_EVIDENCE_MODEL.json",
    "TRACE_EVENT_INVENTORY.json", "PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION.json", "FILESYSTEM_ACTIVITY_ADJUDICATION.json",
    "CAUSAL_OWNERSHIP_ADJUDICATION.json", "POST_VALIDATION_INCOMPLETENESS_DECISION.json",
    "SUCCESSOR_V4_REQUIREMENTS.json", "SUCCESSOR_V4_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEXT_LEGAL_MILESTONE.json", "GOVERNANCE_DECISION_SUMMARY.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "GOVERNANCE_VALIDATION_RESULT_RUN-0002.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json",
    "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"])).encode()).hexdigest()


def verify(final: bool) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    candidate = SCRIPTS | BASE | RESULTS
    check("F001_ROOT", ROOT.is_dir() and not ROOT.is_symlink())
    check("F002_V3_EXISTS", V3.is_dir() and not V3.is_symlink())
    check("F003_V4_ABSENT", not V4.exists() and not V4.is_symlink())
    check("F004_NO_SYMLINKS", all(not path.is_symlink() for path in ROOT.iterdir()))
    if final:
        check("F005_FINAL_FILES_PRESENT", {FREEZE, "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}.issubset(actual))
    else:
        check("F005_CANDIDATE_FILE_SET", actual == candidate, {"actual": len(actual), "expected": len(candidate)})
    check("F006_PRED_LOCK", sha(PRED / "GOVERNANCE_LOCK.json") == "3d75fc21aa689b4a40a5c83e8751bce5f87bfcae60a88c9db8ef3eb7ea833669")
    check("F007_PRED_MANIFEST", sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "4acedb4881f46c46241e4287709da05ebae39a41aae692c68a3aaf825e407e53")
    check("F008_V3_SOURCE", sha(V3 / "STATIC_SOURCE_MANIFEST.json") == "28b02da30f5c724d8dfa72d1996887e7ee9e54dadc5209751c5ed5f8bb003ec4")
    check("F009_V3_LOCK", sha(V3 / "STATIC_EXECUTION_LOCK.json") == "74276275026a38d7d157cca874539abd2c6a5240ea2b9549498061321b1e3a3b")
    check("F010_V3_LOCK_VERIFY", sha(V3 / "STATIC_EXECUTION_LOCK_VERIFICATION.json") == "a3a5703c17b65951d9d0574ed092f75219c002659240113d23f7123c7bc0753e")
    check("F011_V3_POST", sha(V3 / "static-run-v1/independent-post-validation-0001.json") == "b7eea278da6684c578f53872b39b87e49c7f1fab0f2be929238ef6a891262561")
    check("F012_V3_RUNTIME", sha(V3 / "static-run-v1/runtime-result-0001.json") == "4e22c3e1f4a8f4af7d4cc021d233f90b5d5a4bb116d33c1d434ba7761891cad1")
    check("F013_V3_EVIDENCE_MANIFEST", sha(V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_MANIFEST.json") == "ab7354be2600e7d67116ca8bae81bdb3f43c468eaab979f488273f991c0499d1")
    check("F014_V3_EVIDENCE_LOCK", sha(V3 / "static-run-v1/FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json") == "5d0b332abdd3960d43a76b4c82c124bf2f3578657c867c41077650da29fa5e4f")
    check("F015_V3_READ_ONLY", all((path.stat().st_mode & 0o222) == 0 for path in V3.rglob("*") if path.is_file()))
    check("F016_GLOBAL_CONFIG", sha(GLOBAL_CONFIG) == "9f559aff9c257410098b0576c48350d55c3da00ad08d3bf5702db20063e25c59")
    for name in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / name).read_text(encoding="utf-8"))
            okay = True
        except Exception:
            okay = False
        check(f"F_SYNTAX_{name}", okay)
    parse_names = BASE | RESULTS
    if final:
        parse_names |= {FREEZE, "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    check("F017_JSON_PARSE", all(isinstance(load(name), dict) for name in parse_names))
    check("F018_IDENTITIES", all(load(name).get("governance_identity") == IDENTITY for name in BASE | RESULTS))
    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0002.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0002.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F019_PRIMARY", primary["status"] == "PASS" and primary["checks_failed"] == 0 and primary["checks_total"] == primary["checks_passed"])
    check("F020_NEGATIVE", negative["status"] == "PASS" and negative["tests_failed"] == 0 and negative["tests_total"] == negative["tests_passed"] == 30)
    check("F021_INDEPENDENT", independent["status"] == "PASS" and independent["checks_failed"] == 0 and independent["checks_total"] == independent["checks_passed"])
    historical_primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    historical_negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("F021A_HISTORICAL_PRIMARY", historical_primary["status"] == "PASS" and historical_primary["checks_failed"] == 0)
    check("F021B_HISTORICAL_NEGATIVE_PRESERVED", historical_negative["status"] == "FAIL_CLOSED" and historical_negative["tests_failed"] == 1)
    terminal = load("V3_TERMINAL_DISPOSITION.json")
    check("F022_V3_TERMINAL", terminal["disposition"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("F023_V3_NO_CONTINUATION", all(terminal[key] == "PROHIBITED" for key in ("patch", "relock", "revalidation", "retry", "promotion")))
    check("F024_NO_COMPAT", terminal["compatibility"] == "NOT_ESTABLISHED")
    check("F025_NO_CONFINEMENT", terminal["confinement"] == "NOT_PROVEN")
    pipe = load("PIPE_PAYLOAD_CLASSIFIER_ADJUDICATION.json")
    check("F026_DEFECT", pipe["classifier_defect"] is True and pipe["verdict"] == "CONFIRMED_NON_PATH_PIPE_AND_STDERR_PAYLOAD_MISCLASSIFICATION")
    check("F027_TYPED_REJECTED", len(pipe["frozen_rejected_lines"]) == 3 and all(row["filesystem_event"] is False for row in pipe["frozen_rejected_lines"]))
    fs = load("FILESYSTEM_ACTIVITY_ADJUDICATION.json")
    check("F028_NO_OOS_PROVEN", fs["actual_out_of_scope_filesystem_activity_proven"] is False)
    check("F029_CLAIM_SCOPE", fs["scope_of_claim"] == "FROZEN_V3_TRACE_SET_AND_CAPTURED_SYSCALL_CLASSES_ONLY")
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    check("F030_OWNERSHIP", ownership["post_validation_classifier_defect"] == "YES")
    model = load("TYPED_TRACE_EVIDENCE_MODEL.json")
    check("F031_SEMANTIC_MODEL", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE_OVER_RAW_TRACE_LINES" in model["classification_rules"])
    successor = load("SUCCESSOR_V4_AUTHORIZATION_DECISION.json")
    requirements = load("SUCCESSOR_V4_REQUIREMENTS.json")
    check("F032_SUCCESSOR", successor["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V4_CONDITIONALLY")
    check("F033_V4_ZERO", successor["attempt_count"] == successor["codex_invocation_count"] == 0)
    check("F034_V4_LIMIT", successor["attempt_limit"] == successor["codex_invocation_limit"] == 1)
    check("F035_REQUIREMENT", "SEMANTIC_SYSCALL_PATH_CLASSIFICATION" in requirements["mandatory_requirements"] and "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE" in requirements["mandatory_requirements"])
    check("F036_SEPARATE_ACCEPTANCE", successor["separate_acceptance_required"] is True)
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    check("F037_GOVERNANCE_ONLY", authority["governance_only"] is True and authority["runtime_invoked_this_milestone"] is False and authority["codex_invoked_this_milestone"] is False)
    check("F038_ZERO_OPS", all(value == 0 for value in authority["governance_operation_counters"].values()))
    check("F039_NO_SUBAGENTS", load("ROUTING_LEDGER.json")["subagents_used"] is False)
    check("F040_NEXT", load("NEXT_LEGAL_MILESTONE.json")["successor_execution_identity"] == "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V4")
    if final:
        manifest = load("GOVERNANCE_ARTIFACT_MANIFEST.json")
        lock = load("GOVERNANCE_LOCK.json")
        freeze = load(FREEZE)
        members = manifest["members"]
        expected_files = {row["path"] for row in members} | {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
        check("F041_FREEZE_PASS", freeze["status"] == "PASS" and freeze["checks_failed"] == 0 and freeze["checks_total"] == freeze["checks_passed"])
        check("F042_FINAL_FILE_SET", actual == expected_files, {"actual": len(actual), "expected": len(expected_files)})
        check("F043_MEMBER_COUNT", manifest["member_count"] == len(members))
        check("F044_MEMBER_HASHES", all((ROOT / row["path"]).is_file() and sha(ROOT / row["path"]) == row["sha256"] and (ROOT / row["path"]).stat().st_size == row["bytes"] for row in members))
        member_root = canonical_root(members)
        check("F045_MEMBER_ROOT", member_root == manifest["canonical_member_root_sha256"] == lock["canonical_member_root_sha256"])
        manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
        check("F046_MANIFEST_SHA", manifest_sha == lock["governance_manifest_sha256"])
        artifact_root = canonical_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
        check("F047_ARTIFACT_ROOT", artifact_root == lock["canonical_artifact_root_sha256"])
        check("F048_LOCK_IDENTITY", lock["governance_identity"] == IDENTITY)
        check("F049_LOCK_STATUS", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
        check("F050_LOCK_DECISION", lock["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V4_CONDITIONALLY")
        check("F051_LOCK_TERMINAL", lock["v3_disposition"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
        check("F052_LOCK_DEFECT", lock["pipe_payload_path_classifier_defect"] == "YES")
        check("F053_LOCK_NO_OOS", lock["actual_out_of_scope_filesystem_activity_proven"] == "NO_IN_FROZEN_CAPTURE")
        check("F054_LOCK_NO_CONFINEMENT", lock["confinement"] == "NOT_PROVEN")
        check("F055_LOCK_V4", lock["v4_state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_AT_FREEZE")
        check("F056_LOCK_ZERO", all(value == 0 for value in lock["operation_counters"].values()))
        check("F057_READ_ONLY_FILES", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()))
        check("F058_READ_ONLY_ROOT", stat.S_IMODE(ROOT.stat().st_mode) == 0o555)
    failed = [row for row in checks if row["status"] == "FAIL"]
    return checks, failed


def main() -> None:
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--write-candidate", action="store_true")
    modes.add_argument("--verify-final", action="store_true")
    args = parser.parse_args()
    checks, failed = verify(args.verify_final)
    payload = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V3_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001" if args.write_candidate else "FINAL_READ_ONLY_FREEZE_VERIFICATION",
        "phase": "FINAL_FREEZE_CANDIDATE" if args.write_candidate else "FINAL_READ_ONLY",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed), "checks_failed": len(failed), "checks": checks,
        "operation_counters": load("AUTHORITY_NON_ESCALATION_DECISION.json")["governance_operation_counters"],
    }
    if args.write_candidate:
        with (ROOT / FREEZE).open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True); handle.write("\n")
    summary = {key: payload[key] for key in ("phase", "status", "checks_total", "checks_passed", "checks_failed")}
    if args.verify_final and not failed:
        lock = load("GOVERNANCE_LOCK.json")
        summary.update(governance_lock_sha256=sha(ROOT / "GOVERNANCE_LOCK.json"), governance_manifest_sha256=sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"), canonical_artifact_root_sha256=lock["canonical_artifact_root_sha256"])
    print(json.dumps(summary, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
