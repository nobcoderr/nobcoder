#!/usr/bin/env python3
"""Independent structural validator for provisioning authorization V3."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
V2 = BASE / "v0.2-i4-b-dedicated-environment-provisioning-governance-v2-20261010"
OWNER = BASE / "v0.2-i4-b-provisioning-specific-owner-authorization-evidence-decision-v1-20261010"
IDENTITY = "V0.2_I4_B_DEDICATED_ENVIRONMENT_PROVISIONING_GOVERNANCE_V3"
BASELINES = [
    (Path("/home/nobcoder/v0.2-experimental-research-engine"), "governance/i0/SOURCE_MANIFEST.json", "1a14d9c6dca921016acb79831e531308480fa9876e62ded6e1976b51ccbc311c"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i1"), "governance/i1/SOURCE_MANIFEST.json", "be1c40bb8c499672afe8e411dbb235060f1d0666931cdd3282d9a2ae4e3c651b"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i2"), "governance/i2/SOURCE_MANIFEST.json", "bb4abb8d766987a65a96205acca6c74ff2200551d8c925086431e0f27d0ee129"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i3"), "governance/i3/SOURCE_MANIFEST.json", "711d9b026870ff55135c5534f88bfc394d7734ee9943a8063baa189ac270c83e"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i4"), "governance/i4a/SOURCE_MANIFEST.json", "138fd2e59526a663486f54b263b8167283e1736a54fbceb777c7a73dbe02ac34"),
]


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_ok(root: Path, manifest_relative: str, expected: str) -> bool:
    manifest = json.loads((root / manifest_relative).read_text(encoding="utf-8"))
    ledger = bytearray()
    for row in sorted(manifest["files"], key=lambda value: value["path"]):
        path = root / row["path"]
        if not path.is_file() or path.is_symlink() or sha(path) != row["sha256"]:
            return False
        ledger.extend(f"{row['sha256']}  {row['path']}\n".encode())
    return hashlib.sha256(bytes(ledger)).hexdigest() == manifest["source_tree_sha256"] == expected


def governance_root(path: Path) -> str:
    records = [f"{sha(item)}  {item.name}" for item in sorted(path.iterdir(), key=lambda value: value.name) if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json"]
    return hashlib.sha256(("\n".join(records) + "\n").encode()).hexdigest()


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


p = load("GOVERNANCE_GATE_PROTOCOL.json")
f = load("PREFLIGHT_RESULT.json")
o = load("OWNER_EVIDENCE_BINDING.json")
h = load("HOST_VM_BINDING.json")
i = load("IMAGE_ACQUISITION_POLICY.json")
a = load("PROVISIONING_AUTHORIZATION.json")
d = load("PROVISIONING_DECISION.json")
c = load("CAPABILITY_GATE_MATRIX.json")
m = load("OPERATION_AUTHORIZATION_MATRIX.json")
s = load("VM_SECURITY_CONFIGURATION.json")
q = load("PRE_PROVISION_READINESS.json")
g = load("PRE_START_GUARDS.json")
v = load("POST_PROVISION_VALIDATION_CONTRACT.json")
t = load("PROVISIONING_THREAT_MODEL.json")
r = load("RISK_REGISTER.json")

check("identity_chain", p["gate_id"] == d["gate_id"] == IDENTITY)
check("preflight_pass", f["status"] == "PASS")
check("v2_lock_bytes", sha(V2 / "GOVERNANCE_LOCK.json") == "d75c54e9c349b643d5cfec3b7f0704e8a2149092df10b3b3fdb37943779b12e1")
check("v2_root_recomputed", governance_root(V2) == "c2620594d370ee7448d7e2ab9699ed48a80e61af975a0dfb4c62c14dc975e408")
check("owner_lock_bytes", sha(OWNER / "GOVERNANCE_LOCK.json") == "75c268830be4d3949a6869e763e4fc8096bbdaec647260f2ff57c93f186381fa")
check("owner_root_recomputed", governance_root(OWNER) == "ff05d8068126265a98fa633f72381d133402abc256a6e7c13ad30d2311eef98b")
check("source_roots_recomputed", all(source_ok(*entry) for entry in BASELINES))

owner_evidence = json.loads((OWNER / "OWNER_AUTHORIZATION_EVIDENCE.json").read_text(encoding="utf-8"))
check("owner_digest_binding", o["owner_evidence_sha256"] == sha(OWNER / "OWNER_AUTHORIZATION_EVIDENCE.json"))
check("owner_scope_matches", set(o["accepted_scope"]) == {"exact pinned ISO acquisition and integrity verification", "one named VM definition and bounded virtual disk", "approved powered-off VM configuration"})
check("owner_claim_not_overstated", o["source_type"] == "USER_ATTESTATION" and o["identity_assurance"].startswith("CONVERSATIONAL_"))
check("owner_all_intent_true", all(owner_evidence["declared_owner_consent"].values()))

check("host_exact", h["host"]["alias"] == "lab-host-01" and h["hypervisor"]["version"] == "7.2.16.174877")
check("vm_exact", h["vm"]["id"] == "v02-i4b-benign-isolation-lab-01" and h["vm"]["topology"] == "SIBLING_VM_NOT_NESTED_IN_KALI")
check("resource_exact", (h["vm"]["vcpus"], h["vm"]["memory_bytes"], h["vm"]["disk_bytes_maximum"]) == (4, 6442450944, 68719476736))
check("path_confinement", all(value.startswith("D:\\v02-i4b-benign-isolation-lab-01") for key, value in h["vm"].items() if key.endswith("_path") or key == "provisioning_root"))
check("hard_absence_guard", h["operation_time_guards"]["existing_vm_identity"] == "MUST_BE_ABSENT" and h["operation_time_guards"]["minimum_d_free_gib"] == 72)

img = i["image"]
check("image_exact", img["filename"] == "ubuntu-24.04.5-live-server-amd64.iso" and img["expected_byte_length"] == 4080486400 and img["expected_sha256"] == "97f3d7ffb032c3eb3b23d2c8be9cc76e60c2c1f2c0146ba5ba9fe01cafae0fd8")
check("image_source_narrow", i["authorized_network_scope"]["origins"] == ["releases.ubuntu.com"] and len(i["authorized_network_scope"]["paths"]) == 2 and i["authorized_network_scope"]["arbitrary_urls"] == "FORBIDDEN")
check("image_not_falsely_verified", i["current_local_state"] == "BYTES_NOT_ACQUIRED_NOT_VERIFIED")
check("image_mount_denied", i["failure_disposition"]["mount_attach_import_extract_execute"] == "NOT_AUTHORIZED")

grant_ids = [row["id"] for row in a["granted_operations"]]
check("authorization_exactly_a1_a5", grant_ids == a["mandatory_order"] == ["A1", "A2", "A3", "A4", "A5"])
check("authorization_single_use", a["authorization_class"].startswith("SINGLE_USE_") and a["validity"]["replay"] == "FORBIDDEN")
check("authorization_exact_actor", a["actor"] == "HOST_OWNER_OPERATOR_ON_LAB_HOST_01" and a["host_alias"] == "lab-host-01")
check("authorization_stops_on_drift", "BINDING_DRIFT" in a["validity"]["ends"])
check("authorization_no_auto_execution", not a["automatic_execution"])

check("decision_grant_consistent", d["provisioning_authorization"] == "GRANTED_NOT_EXECUTED" and d["granted_operation_ids"] == grant_ids and d["granted_operation_count"] == len(grant_ids) == 5)
check("decision_runtime_denied", d["vm_startup"] == "NOT_AUTHORIZED" and d["guest_installation"] == "NOT_AUTHORIZED" and d["i4_b_execution"] == "NOT_GRANTED")
check("decision_host_change_denied", d["host_configuration_change"] == "NOT_AUTHORIZED")
check("decision_later_denied", d["fixture_or_exploit_execution"] == "NOT_AUTHORIZED" and d["i5"] == "NOT_AUTHORIZED" and d["v0_3"] == "NOT_OPENED")
check("decision_runtime_truthful", d["actual_runtime_isolation"] == "NOT_EVALUATED")

check("capability_counts_derived", c["gate_count"] == len(c["gates"]) == 8 and c["granted_gate_count"] == sum(row["v3_decision"].startswith("GRANTED") for row in c["gates"]) == 2 and c["denied_gate_count"] == 6)
check("operation_counts_derived", m["operation_count"] == len(m["operations"]) == 13 and m["authorized_count"] == sum(row["decision"].startswith("AUTHORIZED") for row in m["operations"]) == 5 and m["not_authorized_count"] == 8)
check("operation_runtime_denials", all(row["decision"] == "NOT_AUTHORIZED" for row in m["operations"][5:]))

check("security_zero_nic", s["network"]["adapter_count"] == 0 and all(value == "FORBIDDEN" for key, value in s["network"].items() if key not in {"adapter_count", "vrde", "serial_tcp"}))
check("security_integrations_closed", s["host_integrations"]["shared_folders"] == "NONE" and s["host_integrations"]["shared_clipboard"] == "DISABLED" and s["host_integrations"]["guest_additions"] == "NOT_INSTALLED")
check("security_media_not_attached", s["media"]["verified_iso_attachment"] == "NOT_AUTHORIZED_BY_V3")
check("security_powered_off", s["readback"]["machine_state"] == "POWERED_OFF")

check("preprovision_18_pass", q["summary"]["passed"] == len(q["checks"]) == 18 and q["summary"]["blocked"] == 0)
check("preprovision_not_runtime", not q["summary"]["runtime_ready"] and not q["summary"]["i4_b_ready"])
check("prestart_all_unsatisfied_or_future", g["startup_authorized"] is False and g["guard_count"] == len(g["guards"]) == 8)
check("post_requirements_24", len(v["requirements"]) == 24 and {row["id"] for row in v["requirements"]} == {f"H{x}" for x in range(1, 25)})
check("post_not_execution_authority", v["decision_semantics"]["vm_startup"] == "NOT_AUTHORIZED_BY_V3" and v["decision_semantics"]["i4_b_execution"] == "NOT_AUTHORIZED_BY_V3")

check("threats_complete", t["threat_count"] == len(t["threats"]) == 27 and all({"id", "boundary", "mitigation", "evidence", "validation", "fail_closed"} <= set(row) for row in t["threats"]))
check("all_threats_fail_closed", all(row["fail_closed"] for row in t["threats"]))
check("risks_complete", r["risk_count"] == len(r["risks"]) == 15)
check("runtime_risk_blocks", any(row["id"] == "R12" and row["blocks_i4_b_security_acceptance"] for row in r["risks"]))
check("router_open", r["router"]["status"] == "OPEN" and r["router"]["router_dependent_paths"] == "BLOCKED")

for forbidden in ("VM_BOOT_AUTHORIZATION.json", "HOST_CONFIGURATION_AUTHORIZATION.json", "I4_B_AUTHORIZATION.json", "I5_AUTHORIZATION.json", "V0_3_AUTHORIZATION.json", "RUNTIME_RESULT.json"):
    check(f"absent_{forbidden}", not (ROOT / forbidden).exists())

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": IDENTITY,
    "validator": "independent_provisioning_v3_structural_validator_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
