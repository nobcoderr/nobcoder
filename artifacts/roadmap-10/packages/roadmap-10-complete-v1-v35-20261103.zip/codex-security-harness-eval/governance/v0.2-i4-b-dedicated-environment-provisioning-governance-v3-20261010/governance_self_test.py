#!/usr/bin/env python3
"""Deterministic governance tests for scoped provisioning authorization V3."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
BASE = HERE.parent
V2 = BASE / "v0.2-i4-b-dedicated-environment-provisioning-governance-v2-20261010"
OWNER = BASE / "v0.2-i4-b-provisioning-specific-owner-authorization-evidence-decision-v1-20261010"
IDENTITY = "V0.2_I4_B_DEDICATED_ENVIRONMENT_PROVISIONING_GOVERNANCE_V3"


def load(name: str):
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def governance_root(path: Path) -> str:
    records = [
        f"{sha(item)}  {item.name}"
        for item in sorted(path.iterdir(), key=lambda value: value.name)
        if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json"
    ]
    return hashlib.sha256(("\n".join(records) + "\n").encode()).hexdigest()


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


protocol = load("GOVERNANCE_GATE_PROTOCOL.json")
preflight = load("PREFLIGHT_RESULT.json")
owner = load("OWNER_EVIDENCE_BINDING.json")
host = load("HOST_VM_BINDING.json")
image = load("IMAGE_ACQUISITION_POLICY.json")
authorization = load("PROVISIONING_AUTHORIZATION.json")
decision = load("PROVISIONING_DECISION.json")
capabilities = load("CAPABILITY_GATE_MATRIX.json")
operations = load("OPERATION_AUTHORIZATION_MATRIX.json")
security = load("VM_SECURITY_CONFIGURATION.json")
readiness = load("PRE_PROVISION_READINESS.json")
start = load("PRE_START_GUARDS.json")
post = load("POST_PROVISION_VALIDATION_CONTRACT.json")
threats = load("PROVISIONING_THREAT_MODEL.json")
risks = load("RISK_REGISTER.json")

check("identity_protocol", protocol["gate_id"] == IDENTITY)
check("identity_decision", decision["gate_id"] == IDENTITY)
check("governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
check("preflight_pass", preflight["status"] == "PASS")
check("preflight_scope", preflight["result"] == "SAFE_TO_CREATE_V3_GOVERNANCE_AND_SCOPED_AUTHORIZATION_ARTIFACTS_ONLY")
check("preflight_no_collision", preflight["identity_state"]["v3_collision"] is False)
check("preflight_no_prior_operation", preflight["identity_state"]["current_operational_authorization_before_v3"] == "NONE")
check("preflight_no_vm", preflight["identity_state"]["vm_exists_under_program"] is False)
check("preflight_no_iso", preflight["identity_state"]["iso_local_bytes_exist_under_program"] is False)
check("router_not_required", protocol["router_integrity"]["router_required_for_this_direct_local_gate"] is False)

check("v2_lock", sha(V2 / "GOVERNANCE_LOCK.json") == "d75c54e9c349b643d5cfec3b7f0704e8a2149092df10b3b3fdb37943779b12e1")
check("v2_root", governance_root(V2) == "c2620594d370ee7448d7e2ab9699ed48a80e61af975a0dfb4c62c14dc975e408")
check("owner_lock", sha(OWNER / "GOVERNANCE_LOCK.json") == "75c268830be4d3949a6869e763e4fc8096bbdaec647260f2ff57c93f186381fa")
check("owner_manifest", sha(OWNER / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "054cd09e3a2ae3f337d1eb6e9c09b405422a247be02420293be5518136111a1b")
check("owner_root", governance_root(OWNER) == "ff05d8068126265a98fa633f72381d133402abc256a6e7c13ad30d2311eef98b")
owner_lock = json.loads((OWNER / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8"))
check("owner_event_chain", owner_lock["required_next_event"] == "NEW_I4_B_DEDICATED_ENVIRONMENT_PROVISIONING_AUTHORIZATION_DECISION_V3")
check("owner_p5", owner_lock["pre_provision_reassessment"]["p5"] == "PASS_BY_NEW_USER_ATTESTATION")
check("owner_18_pass", owner_lock["pre_provision_reassessment"]["passed"] == 18)

check("owner_binding_status", owner["status"] == "BOUND")
check("owner_binding_host", owner["host_alias"] == "lab-host-01")
check("owner_binding_source", owner["source_type"] == "USER_ATTESTATION")
check("owner_binding_digest", owner["owner_evidence_sha256"] == sha(OWNER / "OWNER_AUTHORIZATION_EVIDENCE.json"))
check("owner_governance_digest", owner["owner_governance_lock_sha256"] == sha(OWNER / "GOVERNANCE_LOCK.json"))
check("owner_scope_count", len(owner["accepted_scope"]) == 3 and len(owner["consent_present_but_not_granted_by_v3"]) == 5)
check("owner_not_crypto", owner["identity_assurance"].startswith("CONVERSATIONAL_"))
check("owner_no_readiness_effect", owner["technical_readiness_effect"] == owner["runtime_readiness_effect"] == "NONE")

check("host_alias", host["host"]["alias"] == "lab-host-01")
check("host_os_arch", host["host"]["operating_system"].startswith("Microsoft Windows 11") and host["host"]["architecture"] == "64-bit")
check("host_cpu", "i7-12650H" in host["host"]["processor"])
check("host_resources", host["host"]["logical_processors"] == 16 and host["host"]["total_ram_gib"] == 15.69)
check("hypervisor_exact", host["hypervisor"]["product"] == "Oracle VM VirtualBox" and host["hypervisor"]["version"] == "7.2.16.174877")
check("host_wide_change_denied", host["hypervisor"]["host_wide_configuration_change"] == "NOT_AUTHORIZED")
vm = host["vm"]
check("vm_id", vm["id"] == "v02-i4b-benign-isolation-lab-01")
check("vm_sibling", vm["topology"] == "SIBLING_VM_NOT_NESTED_IN_KALI")
check("vm_powered_off", vm["state_during_authorized_operations"] == "POWERED_OFF")
check("vm_resources", (vm["vcpus"], vm["memory_bytes"], vm["disk_bytes_maximum"]) == (4, 6 * 1024**3, 64 * 1024**3))
check("vm_d_paths", all(value.startswith("D:\\v02-i4b-benign-isolation-lab-01") for key, value in vm.items() if key.endswith("_path") or key == "provisioning_root"))
check("vm_disk_exact", vm["virtual_disk_path"].endswith("v02-i4b-benign-isolation-lab-01.vdi"))
check("storage_guard", host["operation_time_guards"]["minimum_d_free_gib"] == 72)
check("absence_guards", host["operation_time_guards"]["existing_vm_identity"] == "MUST_BE_ABSENT" and "ABSENT_OR_EMPTY" in host["operation_time_guards"]["provisioning_root"])
check("no_overwrite", host["operation_time_guards"]["unexpected_existing_state"] == "STOP_QUARANTINE_NO_OVERWRITE")

img = image["image"]
check("image_identity", (img["distribution"], img["release"], img["architecture"], img["filename"]) == ("Ubuntu Server", "24.04.5 LTS", "amd64", "ubuntu-24.04.5-live-server-amd64.iso"))
check("image_origin", img["exact_url"] == "https://releases.ubuntu.com/24.04/ubuntu-24.04.5-live-server-amd64.iso")
check("image_checksum_origin", img["checksum_url"] == "https://releases.ubuntu.com/24.04/SHA256SUMS")
check("image_expected_length", img["expected_byte_length"] == 4080486400)
check("image_expected_sha", img["expected_sha256"] == "97f3d7ffb032c3eb3b23d2c8be9cc76e60c2c1f2c0146ba5ba9fe01cafae0fd8")
check("image_destination", img["destination"] == vm["media_path"])
check("network_scope_origin", image["authorized_network_scope"]["origins"] == ["releases.ubuntu.com"])
check("network_scope_paths", len(image["authorized_network_scope"]["paths"]) == 2)
check("arbitrary_urls_forbidden", image["authorized_network_scope"]["arbitrary_urls"] == "FORBIDDEN")
check("guest_network_denied", image["authorized_network_scope"]["guest_network"] == "NOT_AUTHORIZED")
check("image_sequence", len(image["acquisition_sequence"]) == 6)
check("image_mount_denied", image["failure_disposition"]["mount_attach_import_extract_execute"] == "NOT_AUTHORIZED")
check("image_state_truthful", image["current_local_state"] == "BYTES_NOT_ACQUIRED_NOT_VERIFIED")

check("authorization_granted_not_executed", authorization["status"] == "GRANTED_NOT_EXECUTED")
check("authorization_single_use", authorization["authorization_class"] == "SINGLE_USE_EXACT_BINDING_POWERED_OFF_PROVISIONING_ONLY")
grants = authorization["granted_operations"]
check("authorization_five_ops", len(grants) == 5 and [row["id"] for row in grants] == [f"A{x}" for x in range(1, 6)])
check("authorization_order", authorization["mandatory_order"] == [f"A{x}" for x in range(1, 6)])
check("authorization_actor", authorization["actor"] == "HOST_OWNER_OPERATOR_ON_LAB_HOST_01")
check("authorization_exact_vm", authorization["vm_id"] == vm["id"])
check("authorization_prerequisites", len(authorization["prerequisites"]) == 7)
check("authorization_denials", len(authorization["denied_operations"]) == 7)
check("authorization_no_auto_execution", authorization["automatic_execution"] is False)
check("authorization_no_replay", authorization["validity"]["replay"] == "FORBIDDEN")
check("authorization_partial_fail_closed", authorization["validity"]["partial_failure"].startswith("STOP_QUARANTINE"))

check("decision_pass_locked", decision["status"] == "PASS_LOCKED")
check("decision_granted", decision["decision"] == "GOVERNANCE_REVIEW_PASS_SCOPED_PROVISIONING_AUTHORIZATION_GRANTED")
check("decision_disposition", decision["disposition"] == "PASS_LOCKED_AUTHORIZE_FIVE_POWERED_OFF_PROVISIONING_OPERATIONS_ONLY")
check("decision_five", decision["granted_operation_count"] == 5 and decision["granted_operation_ids"] == [f"A{x}" for x in range(1, 6)])
check("decision_no_boot", decision["vm_startup"] == "NOT_AUTHORIZED")
check("decision_no_install", decision["guest_installation"] == decision["guest_bootstrap"] == "NOT_AUTHORIZED")
check("decision_no_host_change", decision["host_configuration_change"] == "NOT_AUTHORIZED")
check("decision_no_runtime", decision["i4_b_execution"] == "NOT_GRANTED" and decision["actual_runtime_isolation"] == "NOT_EVALUATED")
check("decision_later_closed", decision["fixture_or_exploit_execution"] == "NOT_AUTHORIZED" and decision["i5"] == "NOT_AUTHORIZED" and decision["v0_3"] == "NOT_OPENED")
check("decision_no_automatic", decision["automatic_execution"] is False and decision["automatic_successor_authorization"] is False)

gates = capabilities["gates"]
check("capability_eight", capabilities["gate_count"] == len(gates) == 8 and [row["id"] for row in gates] == [f"C{x}" for x in range(1, 9)])
check("capability_counts", capabilities["granted_gate_count"] == 2 and capabilities["denied_gate_count"] == 6 and capabilities["granted_operation_count"] == 5)
check("capability_owner_consent", all(row["owner_consent"] == "PRESENT" for row in gates))
check("capability_c1_c2_only", gates[0]["v3_decision"].startswith("GRANTED") and gates[1]["v3_decision"].startswith("GRANTED") and all(row["v3_decision"].startswith("DENIED") for row in gates[2:]))

ops = operations["operations"]
check("operation_thirteen", operations["operation_count"] == len(ops) == 13)
check("operation_counts", operations["authorized_count"] == 5 and operations["not_authorized_count"] == 8)
check("operation_first_five", [row["decision"] for row in ops[:5]] == [f"AUTHORIZED_AS_A{x}" for x in range(1, 6)])
check("operation_last_eight_denied", all(row["decision"] == "NOT_AUTHORIZED" for row in ops[5:]))
check("operation_no_execution", operations["execution_in_this_governance_task"] == 0)

check("security_status", security["status"] == "AUTHORIZED_FOR_POWERED_OFF_APPLICATION_NOT_APPLIED")
check("security_resources", security["resources"]["vcpus"] == 4 and security["resources"]["memory_bytes"] == 6 * 1024**3 and security["resources"]["disk_bytes_maximum"] == 64 * 1024**3)
check("security_zero_nic", security["network"]["adapter_count"] == 0)
check("security_all_network_forbidden", all(value == "FORBIDDEN" for key, value in security["network"].items() if key not in {"adapter_count", "vrde", "serial_tcp"}))
check("security_no_shares", security["host_integrations"]["shared_folders"] == "NONE" and security["host_integrations"]["host_path_mounts"] == "NONE")
check("security_no_clipboard_dnd", security["host_integrations"]["shared_clipboard"] == "DISABLED" and security["host_integrations"]["drag_and_drop"] == "DISABLED")
check("security_no_guest_additions", security["host_integrations"]["guest_additions"] == "NOT_INSTALLED")
check("security_no_devices", security["host_integrations"]["usb_controllers"] == "DISABLED" and security["host_integrations"]["device_passthrough"] == "NONE")
check("security_no_credentials", all(value == "FORBIDDEN" for value in security["credentials"].values()))
check("security_no_iso_attach", security["media"]["verified_iso_attachment"] == "NOT_AUTHORIZED_BY_V3")
check("security_powered_off_readback", security["readback"]["machine_state"] == "POWERED_OFF" and security["readback"]["approved_vs_observed_diff"] == "MUST_BE_EMPTY")
check("security_host_change_denied", security["host_wide_changes"] == "FORBIDDEN")

check("readiness_18", readiness["summary"]["total"] == len(readiness["checks"]) == readiness["summary"]["passed"] == 18)
check("readiness_no_blocks", readiness["summary"]["blocked"] == 0 and all(row["result"] == "PASS" for row in readiness["checks"]))
check("readiness_ops", readiness["summary"]["eligible_operation_ids"] == [f"A{x}" for x in range(1, 6)])
check("readiness_not_runtime", readiness["summary"]["runtime_ready"] is False and readiness["summary"]["i4_b_ready"] is False)
check("revalidation_count", len(readiness["operation_time_revalidation"]) == 5)
check("start_guard_count", start["guard_count"] == len(start["guards"]) == 8)
check("start_not_authorized", start["startup_authorized"] is False and start["failure_disposition"] == "DO_NOT_START")
check("start_ram_guard", any(row["id"] == "S3" and "2_GIB" in row["current"] for row in start["guards"]))
check("post_24", len(post["requirements"]) == 24 and [row["id"] for row in post["requirements"]] == [f"H{x}" for x in range(1, 25)])
check("post_no_boot_or_i4b", post["decision_semantics"]["vm_startup"] == "NOT_AUTHORIZED_BY_V3" and post["decision_semantics"]["i4_b_execution"] == "NOT_AUTHORIZED_BY_V3")

threat_fields = {"id", "threat", "boundary", "mitigation", "evidence", "validation", "fail_closed"}
check("threat_count", threats["threat_count"] == len(threats["threats"]) == 27)
check("threat_unique", len({row["id"] for row in threats["threats"]}) == 27)
check("threat_complete", all(threat_fields <= set(row) for row in threats["threats"]))
check("threat_fail_closed", all(row["fail_closed"] for row in threats["threats"]))
threat_text = json.dumps(threats["threats"]).lower()
for term in ("owner evidence", "scope escalation", "physical host", "vm identity", "hypervisor", "d storage", "ram", "kali", "image", "nic", "nat", "credential", "hyper-v", "vbs", "boot", "cgroup", "landlock", "seccomp", "sandbox", "audit", "rollback", "router"):
    check(f"threat_covers_{term}", term in threat_text)
check("risk_count", risks["risk_count"] == len(risks["risks"]) == 15)
check("risk_unique", len({row["id"] for row in risks["risks"]}) == 15)
check("risk_runtime_open", any(row["id"] == "R12" and row["state"] == "NOT_EVALUATED" for row in risks["risks"]))
check("risk_host_change_prohibited", any(row["id"] == "R13" and row["state"] == "PROHIBITED" for row in risks["risks"]))
check("router_open", risks["router"]["status"] == "OPEN" and risks["router"]["router_dependent_paths"] == "BLOCKED")


def grantable(record: dict[str, object]) -> bool:
    return (
        record.get("owner_evidence") == "VALID"
        and record.get("owner_provenance") == "LOCKED_USER_ATTESTATION"
        and record.get("host") == "lab-host-01"
        and record.get("vm") == "v02-i4b-benign-isolation-lab-01"
        and record.get("hypervisor") == "7.2.16.174877"
        and record.get("vcpus") == 4
        and record.get("memory_gib") == 6
        and record.get("disk_gib") == 64
        and record.get("d_free_gib", 0) >= 72
        and record.get("future_ram_guard_gib") == 8
        and record.get("future_kali_off") is True
        and record.get("image_url") == img["exact_url"]
        and record.get("image_sha") == img["expected_sha256"]
        and record.get("local_bytes_verified") is False
        and record.get("network") == "ZERO_NIC"
        and record.get("integrations") == "DISABLED"
        and record.get("operation_ids") == [f"A{x}" for x in range(1, 6)]
        and record.get("boot") is False
        and record.get("install") is False
        and record.get("host_change") is False
        and record.get("i4b") is False
        and record.get("later") is False
        and record.get("router") is False
    )


synthetic = {
    "owner_evidence": "VALID",
    "owner_provenance": "LOCKED_USER_ATTESTATION",
    "host": "lab-host-01",
    "vm": "v02-i4b-benign-isolation-lab-01",
    "hypervisor": "7.2.16.174877",
    "vcpus": 4,
    "memory_gib": 6,
    "disk_gib": 64,
    "d_free_gib": 119.14,
    "future_ram_guard_gib": 8,
    "future_kali_off": True,
    "image_url": img["exact_url"],
    "image_sha": img["expected_sha256"],
    "local_bytes_verified": False,
    "network": "ZERO_NIC",
    "integrations": "DISABLED",
    "operation_ids": [f"A{x}" for x in range(1, 6)],
    "boot": False,
    "install": False,
    "host_change": False,
    "i4b": False,
    "later": False,
    "router": False,
}
check("synthetic_valid_grant", grantable(synthetic))
mutations = {
    "missing_owner_evidence": ("owner_evidence", None),
    "forged_consent_provenance": ("owner_provenance", "UNLOCKED_TEXT"),
    "host_mismatch": ("host", "other-host"),
    "vm_mismatch": ("vm", "other-vm"),
    "hypervisor_mismatch": ("hypervisor", "different"),
    "modified_vcpus": ("vcpus", 6),
    "modified_memory": ("memory_gib", 4),
    "modified_disk": ("disk_gib", 80),
    "insufficient_d": ("d_free_gib", 71.99),
    "wrong_ram_guard": ("future_ram_guard_gib", 7),
    "kali_shutdown_missing": ("future_kali_off", False),
    "missing_iso_provenance": ("image_url", None),
    "arbitrary_image_url": ("image_url", "https://example.invalid/image.iso"),
    "wrong_image_hash": ("image_sha", "0" * 64),
    "image_bytes_false_verified": ("local_bytes_verified", True),
    "network_enabled": ("network", "NAT"),
    "shared_folder_enabled": ("integrations", "SHARED_FOLDER"),
    "clipboard_enabled": ("integrations", "CLIPBOARD"),
    "guest_agent_enabled": ("integrations", "GUEST_AGENT"),
    "incomplete_capability_matrix": ("operation_ids", ["A1", "A2"]),
    "unsafe_blanket_authorization": ("operation_ids", ["ALL"]),
    "unauthorized_boot": ("boot", True),
    "unauthorized_install": ("install", True),
    "unauthorized_host_change": ("host_change", True),
    "unauthorized_i4b": ("i4b", True),
    "unauthorized_i5_v03": ("later", True),
    "router_dependency": ("router", True),
}
for label, (field, value) in mutations.items():
    candidate = copy.deepcopy(synthetic)
    candidate[field] = value
    check(f"reject_{label}", not grantable(candidate))

for forbidden in ("VM_BOOT_AUTHORIZATION.json", "HOST_CONFIGURATION_AUTHORIZATION.json", "I4_B_AUTHORIZATION.json", "I5_AUTHORIZATION.json", "V0_3_AUTHORIZATION.json", "RUNTIME_RESULT.json"):
    check(f"forbidden_artifact_absent_{forbidden}", not (HERE / forbidden).exists())

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": IDENTITY,
    "validator": "provisioning_v3_governance_self_test_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
