#!/usr/bin/env python3
"""Primary governance validation."""

from governance_common import ROOT, SYMBOL_PATH, V32, load, verify_v31_frozen, write_once


def main() -> int:
    adj = load(ROOT / "V31_ARTIFACT_FINALIZATION_ORDER_ADJUDICATION.json")
    prompt = load(ROOT / "V31_PROMPT_FAILURE_DERIVATION_ADJUDICATION.json")
    comparison = load(ROOT / "V31_ARTIFACT_FINALIZATION_ORDER_EVIDENCE_COMPARISON.json")
    contract = load(ROOT / "SUCCESSOR_V32_AUTHORITATIVE_ARTIFACT_FINALIZATION_LIFECYCLE_CONTRACT.json")
    matrix = load(ROOT / "V31_FAILURE_AND_V32_REGRESSION_MATRIX.json")
    decision = load(ROOT / "V31_TERMINAL_AND_V32_SUCCESSOR_DECISION.json")
    checks = {
        "G001_V31_FROZEN": verify_v31_frozen()["status"] == "PASS",
        "G002_ORDER_DEFECT": adj["AUTHORITATIVE_ARTIFACT_FINALIZATION_ORDER_DEFECT"] == "YES",
        "G003_LATE_MANIFEST_DEFECT": adj["LATE_SYMBOL_BINDING_MANIFEST_MATERIALIZATION_DEFECT"] == "YES",
        "G004_MEMBER_SET_INCOMPLETE": adj["AUTHORITATIVE_BOUND_MEMBER_SET_INCOMPLETENESS"] == "YES",
        "G005_MODE_DEFECT": adj["AUTHORITATIVE_ARTIFACT_IMMUTABILITY_MODE_DEFECT"] == "YES",
        "G006_FAILURE_MODE_DISTINCT_FROM_FREEZE": adj["current_mode_after_failure_freeze"] == "0444_PRESERVATION_ONLY_NOT_RETROACTIVE_PASS",
        "G007_SYMBOL_ABSENT_FROM_BOUND_SET": comparison["authoritative_binding"]["symbol_manifest_member_present"] is False and comparison["late_symbol_binding_manifest"]["absent_from_bound_member_set"] is True,
        "G008_SYMBOL_PATH_EXACT": comparison["late_symbol_binding_manifest"]["path"].endswith(SYMBOL_PATH),
        "G009_PROMPT_DERIVED": prompt["U027_V7_PROMPT_IDENTITY"] == "DERIVED_FROM_INCOMPLETE_AUTHORITATIVE_ARTIFACT_IDENTITY",
        "G010_PROMPT_BYTES_NO_DEFECT": prompt["INDEPENDENT_PROMPT_BYTES_OR_DIGEST_DEFECT"] == "NO" and comparison["prompt"]["all_equal_expected"] is True,
        "G011_CREATION_CLOSURE": contract["required_order"][1] == "RECORD_EXPLICIT_AUTHORITATIVE_ARTIFACT_CREATION_CLOSURE",
        "G012_POST_CLOSURE_MUTATION_PROHIBITED": "CREATED_REMOVED_RENAMED_SUBSTITUTED" in contract["creation_closure_semantics"],
        "G013_LATE_MEMBER_FAILS": contract["late_authoritative_member"] == "FAIL_CLOSED_BEFORE_VALIDATION",
        "G014_MODE_0444": contract["required_authoritative_file_mode"] == "0444",
        "G015_COMPLETE_ORDER": len(contract["required_order"]) == 10 and contract["required_order"][-1] == "BEGIN_UNIT_AND_STATIC_VALIDATION",
        "G016_REGRESSIONS": matrix["count"] == 9 and len(set(matrix["required_regressions"])) == 9,
        "G017_V31_TERMINAL": decision["v31_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY",
        "G018_V32_CONDITIONAL": decision["v32_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "G019_RUNTIME_NOT_ESTABLISHED": decision["securityworker_runtime"] == decision["codex_worker_runtime"] == decision["temporal_runtime"] == "NOT_ESTABLISHED",
        "G020_V32_ABSENT": not V32.exists(),
    }
    result = {"record_type": "PRIMARY_GOVERNANCE_VALIDATION", "checks": [{"id": key, "status": "PASS" if value else "FAIL"} for key, value in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "PRIMARY_GOVERNANCE_VALIDATION.json", result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
