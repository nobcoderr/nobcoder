#!/usr/bin/env python3
"""Freeze the validated governance-only package append-only."""

import hashlib
import os

from governance_common import IDENTITY, ROOT, V31, V32, load, sha256, verify_v31_frozen, write_once


def main() -> int:
    validations = ["PRIMARY_GOVERNANCE_VALIDATION.json", "NEGATIVE_GOVERNANCE_FIXTURES.json", "INDEPENDENT_GOVERNANCE_VALIDATION.json", "READ_ONLY_INTEGRITY_VERIFICATION.json"]
    if verify_v31_frozen()["status"] != "PASS" or not all(load(ROOT / name)["status"] == "PASS" for name in validations):
        raise SystemExit("governance readiness failed")
    if V32.exists() or (V31 / "STATIC_EXECUTION_LOCK.json").exists() or (V31 / "static-run-v31/attempt-marker-0001.json").exists():
        raise SystemExit("authority ceiling violated")
    reserved = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION.json"}
    members = [{"path": path.name, "sha256": sha256(path), "bytes": path.stat().st_size} for path in sorted((path for path in ROOT.iterdir() if path.is_file() and path.name not in reserved), key=lambda path: path.name.encode())]
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    root_sha = hashlib.sha256(rows.encode()).hexdigest()
    write_once(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", {"record_type": "GOVERNANCE_ARTIFACT_MANIFEST", "governance_identity": IDENTITY, "members": members, "member_count": len(members), "canonical_governance_root_sha256": root_sha, "status": "PASS"})
    lock = {
        "record_type": "V31_ARTIFACT_FINALIZATION_ORDER_ERRATUM_AND_V32_SUCCESSOR_DECISION_GOVERNANCE_LOCK",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "canonical_governance_root_sha256": root_sha,
        "governance_artifact_manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "AUTHORITATIVE_ARTIFACT_FINALIZATION_ORDER_DEFECT": "YES",
        "LATE_SYMBOL_BINDING_MANIFEST_MATERIALIZATION_DEFECT": "YES",
        "AUTHORITATIVE_BOUND_MEMBER_SET_INCOMPLETENESS": "YES",
        "AUTHORITATIVE_ARTIFACT_IMMUTABILITY_MODE_DEFECT": "YES",
        "U027_V7_PROMPT_IDENTITY": "DERIVED_FROM_INCOMPLETE_AUTHORITATIVE_ARTIFACT_IDENTITY",
        "INDEPENDENT_PROMPT_BYTES_OR_DIGEST_DEFECT": "NO",
        "v31_disposition": "TERMINAL_IMMUTABLE_NO_RETRY",
        "v32_disposition": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt": "0/1", "worker_invocation": "0/1", "codex_as_worker_invocation": "0/1",
        "securityworker_runtime": "NOT_ESTABLISHED", "temporal_runtime": "NOT_ESTABLISHED",
        "process_lineage": "NOT_PROVEN", "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN",
        "next_legal_milestone": "IMPLEMENT_FRESH_V32_ONLY_UNDER_SEPARATE_ENGINEERING_REQUEST",
    }
    write_once(ROOT / "GOVERNANCE_LOCK.json", lock)
    write_once(ROOT / "FINAL_FREEZE_VERIFICATION.json", {"record_type": "FINAL_FREEZE_VERIFICATION", "manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"), "governance_lock_sha256": sha256(ROOT / "GOVERNANCE_LOCK.json"), "member_count": len(members), "canonical_governance_root_sha256": root_sha, "v31_reverified": True, "v32_absent": True, "status": "PASS"})
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(f"GOVERNANCE_FREEZE=PASS ROOT={root_sha} LOCK_SHA256={sha256(ROOT / 'GOVERNANCE_LOCK.json')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
