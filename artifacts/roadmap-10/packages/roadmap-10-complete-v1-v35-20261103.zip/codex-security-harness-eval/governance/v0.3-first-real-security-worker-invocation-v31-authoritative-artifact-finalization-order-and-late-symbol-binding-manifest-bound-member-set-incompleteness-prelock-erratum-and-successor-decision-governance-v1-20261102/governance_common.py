"""Shared read-only evidence helpers for the V31 governance erratum."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parent
V31 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v31-20261102")
V32 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v32-20261102")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V31_AUTHORITATIVE_ARTIFACT_"
    "FINALIZATION_ORDER_AND_LATE_SYMBOL_BINDING_MANIFEST_BOUND_MEMBER_SET_"
    "INCOMPLETENESS_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
V31_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V31"
V32_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V32"
V31_STATUS = "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE"
V31_ROOT_SHA = "9f7f6467842286121e68459476eb02abe1b8a4a9bbb924ec464d156e969486e7"
V31_TERMINAL_SHA = "a628af182a47211a8f34c981ede5031230180b876ed517dc12df6dba1d33def9"
V31_MANIFEST_SHA = "6b265210a11db69f53379334331509004bbf0fcbbd9a1f0c1cac57134e7a3ada"
V31_FREEZE_SHA = "c3db51e04f8c1594016c0015b288c0bbdebeebf6a63df12271a487a5125d0a59"
V31_UNIT_SHA = "c81a678c81576084fb056b136e9ae24dcc150ae09b61b5d974b77663ff095c46"
V31_DIAGNOSTIC_SHA = "46980cb5e43fc054ed758f3c312ba7ad569de5d4cd4a4033771d04205068353d"
V31_AUTH_LOCK = "064b468f18fccc745529a3887fab27748027c00a95be9edefcc71ef48f2677fb"
PROMPT_SHA = "a30407b791f0790304fa4e7f8eae76a3a2699e141c710f5054af8871d5c22fc1"
SYMBOL_PATH = "contracts/LOCKED_ENTRYPOINT_SYMBOL_BINDING_MANIFEST.json"
FAILURES = {"U027_V7_PROMPT_IDENTITY", "U029_V9_DIGEST_BINDING"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_once(path: Path, value: Any) -> None:
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"append-only output exists: {path}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def paths() -> dict[str, Path]:
    pre = V31 / "results/prelock"
    return {
        "terminal": pre / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
        "manifest": pre / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
        "freeze": pre / "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
        "unit": pre / "unit-fixtures-run-0001.json",
        "diagnostic": pre / "UNIT_FAILURE_DIAGNOSTIC.json",
        "binding": V31 / "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json",
        "symbol": V31 / SYMBOL_PATH,
        "prompt": V31 / "fixture/worker-prompt.txt",
        "prompt_binding": V31 / "contracts/PROMPT_IDENTITY_BINDING.json",
        "request": V31 / "contracts/WORKER_REQUEST.json",
    }


def verify_v31_frozen() -> dict[str, Any]:
    p = paths()
    terminal = load(p["terminal"])
    manifest = load(p["manifest"])
    unit = load(p["unit"])
    members = manifest.get("members", [])
    exact = []
    for row in members:
        member = V31 / row.get("path", "")
        exact.append(
            member.is_file()
            and not member.is_symlink()
            and sha256(member) == row.get("sha256")
            and member.stat().st_size == row.get("bytes")
            and stat.S_IMODE(member.stat().st_mode) == 0o444
        )
    root_rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    computed_root = hashlib.sha256(root_rows.encode()).hexdigest()
    failed = {row.get("id") for row in unit.get("checks", []) if row.get("status") != "PASS"}
    checks = {
        "terminal_digest": sha256(p["terminal"]) == V31_TERMINAL_SHA,
        "manifest_digest": sha256(p["manifest"]) == V31_MANIFEST_SHA,
        "freeze_digest": sha256(p["freeze"]) == V31_FREEZE_SHA,
        "unit_digest": sha256(p["unit"]) == V31_UNIT_SHA,
        "diagnostic_digest": sha256(p["diagnostic"]) == V31_DIAGNOSTIC_SHA,
        "root_exact": computed_root == manifest.get("canonical_evidence_root_sha256") == V31_ROOT_SHA,
        "members_exact": len(members) == manifest.get("member_count") == 301 and all(exact),
        "workspace_read_only": stat.S_IMODE(V31.stat().st_mode) == 0o555,
        "results_read_only": stat.S_IMODE(p["manifest"].parent.stat().st_mode) == 0o555,
        "terminal_state": terminal.get("status") == V31_STATUS,
        "unit_counts": unit.get("validation_counts") == {"failed": 2, "passed": 359, "total": 361},
        "failure_set": failed == FAILURES,
        "later_gates_not_started": terminal.get("primary") == terminal.get("independent") == terminal.get("fresh_preflight") == "NOT_STARTED",
        "static_lock_absent": terminal.get("static_lock") == "NOT_ISSUED" and not (V31 / "STATIC_EXECUTION_LOCK.json").exists(),
        "attempt_absent": not (V31 / "static-run-v31/attempt-marker-0001.json").exists(),
        "runtime_absent": not (V31 / "static-run-v31/runtime-result-0001.json").exists(),
        "counts_zero": terminal.get("attempt_count") == terminal.get("worker_invocation_count") == terminal.get("codex_as_worker_invocation_count") == 0,
        "no_bytecode": not any(V31.rglob("*.pyc")) and not any(q.name == "__pycache__" for q in V31.rglob("*")),
    }
    return {
        "record_type": "V31_FROZEN_FAILURE_EVIDENCE_VERDICT",
        "checks": checks,
        "member_count": len(members),
        "canonical_evidence_root_sha256": computed_root,
        "status": "PASS" if all(checks.values()) else "FAIL_CLOSED",
    }


def finalization_verdict(candidate: Mapping[str, Any]) -> bool:
    """Pure model for the successor's ordered creation-closure lifecycle."""
    return bool(
        candidate.get("all_authoritative_members_materialized")
        and candidate.get("symbol_manifest_materialized_before_closure")
        and candidate.get("creation_closure_recorded")
        and candidate.get("no_members_added_removed_renamed_or_substituted_after_closure")
        and candidate.get("all_bytes_finalized_after_closure")
        and candidate.get("all_modes") == "0444"
        and candidate.get("ownership_exact")
        and candidate.get("symbol_manifest_in_bound_member_set")
        and candidate.get("all_member_digests_exact")
        and candidate.get("logical_owner_generation_bindings_exact")
        and candidate.get("reread_rehash_exact")
        and candidate.get("member_set_unchanged_after_binding")
        and candidate.get("validation_started_only_after_verification")
    )
