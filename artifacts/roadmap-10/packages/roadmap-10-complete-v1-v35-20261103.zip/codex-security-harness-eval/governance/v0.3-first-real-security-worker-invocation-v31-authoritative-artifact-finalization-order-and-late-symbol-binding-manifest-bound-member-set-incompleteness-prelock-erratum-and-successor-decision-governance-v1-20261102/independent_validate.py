#!/usr/bin/env python3
"""Independent reconstruction of the frozen V31 construction-order failure."""

import hashlib
import json
import stat
from pathlib import Path

from governance_common import ROOT, SYMBOL_PATH, V31, V32, write_once


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    pre = V31 / "results/prelock"
    terminal_path = pre / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json"
    manifest_path = pre / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json"
    freeze_path = pre / "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json"
    unit_path = pre / "unit-fixtures-run-0001.json"
    diagnostic_path = pre / "UNIT_FAILURE_DIAGNOSTIC.json"
    terminal, manifest, unit, diagnostic = map(read, (terminal_path, manifest_path, unit_path, diagnostic_path))
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in manifest["members"])
    root_sha = hashlib.sha256(rows.encode()).hexdigest()
    members_exact = all(
        (V31 / row["path"]).is_file()
        and not (V31 / row["path"]).is_symlink()
        and digest(V31 / row["path"]) == row["sha256"]
        and (V31 / row["path"]).stat().st_size == row["bytes"]
        and stat.S_IMODE((V31 / row["path"]).stat().st_mode) == 0o444
        for row in manifest["members"]
    )
    failed = {row["id"] for row in unit["checks"] if row["status"] != "PASS"}
    artifact_binding = read(V31 / "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json")
    bound_paths = {row["path"] for row in artifact_binding["members"]}
    prompt_binding = read(V31 / "contracts/PROMPT_IDENTITY_BINDING.json")
    request = read(V31 / "contracts/WORKER_REQUEST.json")
    prompt_path = V31 / "fixture/worker-prompt.txt"
    decision = read(ROOT / "V31_TERMINAL_AND_V32_SUCCESSOR_DECISION.json")
    adjudication = read(ROOT / "V31_ARTIFACT_FINALIZATION_ORDER_ADJUDICATION.json")
    checks = {
        "I001_TERMINAL_SHA": digest(terminal_path) == "a628af182a47211a8f34c981ede5031230180b876ed517dc12df6dba1d33def9",
        "I002_MANIFEST_SHA": digest(manifest_path) == "6b265210a11db69f53379334331509004bbf0fcbbd9a1f0c1cac57134e7a3ada",
        "I003_FREEZE_SHA": digest(freeze_path) == "c3db51e04f8c1594016c0015b288c0bbdebeebf6a63df12271a487a5125d0a59",
        "I004_DIAGNOSTIC_SHA": digest(diagnostic_path) == "46980cb5e43fc054ed758f3c312ba7ad569de5d4cd4a4033771d04205068353d",
        "I005_ROOT": root_sha == manifest["canonical_evidence_root_sha256"] == "9f7f6467842286121e68459476eb02abe1b8a4a9bbb924ec464d156e969486e7",
        "I006_MEMBERS": len(manifest["members"]) == 301 and members_exact,
        "I007_FAILURE_SET": failed == {"U027_V7_PROMPT_IDENTITY", "U029_V9_DIGEST_BINDING"},
        "I008_COUNTS": unit["validation_counts"] == {"failed": 2, "passed": 359, "total": 361},
        "I009_LATE_ORDER": diagnostic["facts"]["authoritative_artifact_binding_created_before_symbol_manifest"] is True,
        "I010_SYMBOL_OMITTED": SYMBOL_PATH not in bound_paths and diagnostic["facts"]["symbol_manifest_absent_from_authoritative_member_set"] is True,
        "I011_FAILURE_MODE": diagnostic["facts"]["symbol_manifest_mode_at_failure"] == "0664" and diagnostic["facts"]["required_symbol_manifest_mode"] == "0444",
        "I012_PROMPT_DIGESTS_EXACT": digest(prompt_path) == prompt_binding["first_prompt_sha256"] == prompt_binding["reread_prompt_sha256"] == request["prompt"]["sha256"] == "a30407b791f0790304fa4e7f8eae76a3a2699e141c710f5054af8871d5c22fc1",
        "I013_PROMPT_DERIVED": diagnostic["facts"]["prompt_failure_derived_from_authoritative_artifact_identity_failure"] is True,
        "I014_ADJUDICATION": all(adjudication[key] == "YES" for key in ("AUTHORITATIVE_ARTIFACT_FINALIZATION_ORDER_DEFECT", "LATE_SYMBOL_BINDING_MANIFEST_MATERIALIZATION_DEFECT", "AUTHORITATIVE_BOUND_MEMBER_SET_INCOMPLETENESS", "AUTHORITATIVE_ARTIFACT_IMMUTABILITY_MODE_DEFECT")),
        "I015_PRIMARY_PASS": read(ROOT / "PRIMARY_GOVERNANCE_VALIDATION.json")["status"] == "PASS",
        "I016_NEGATIVES_PASS": read(ROOT / "NEGATIVE_GOVERNANCE_FIXTURES.json")["status"] == "PASS",
        "I017_V31_TERMINAL": decision["v31_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY",
        "I018_V32_CONDITIONAL": decision["v32_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "I019_NO_EXECUTION": terminal["static_lock"] == "NOT_ISSUED" and not (V31 / "STATIC_EXECUTION_LOCK.json").exists() and not (V31 / "static-run-v31/attempt-marker-0001.json").exists(),
        "I020_V32_ABSENT": not V32.exists(),
    }
    result = {"record_type": "INDEPENDENT_GOVERNANCE_VALIDATION", "checks": [{"id": key, "status": "PASS" if value else "FAIL"} for key, value in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION.json", result)
    print(f"INDEPENDENT_GOVERNANCE_VALIDATION={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
