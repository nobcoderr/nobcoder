#!/usr/bin/env python3
"""Build the governance-only V31 erratum without mutating V31."""

from __future__ import annotations

import stat

from governance_common import (
    FAILURES, IDENTITY, PROMPT_SHA, ROOT, SYMBOL_PATH, V31, V31_AUTH_LOCK,
    V31_DIAGNOSTIC_SHA, V31_FREEZE_SHA, V31_IDENTITY, V31_MANIFEST_SHA,
    V31_ROOT_SHA, V31_TERMINAL_SHA, V32, V32_IDENTITY, load, paths, sha256,
    verify_v31_frozen, write_once,
)


def emit(name: str, value: dict) -> None:
    write_once(ROOT / name, value)


def main() -> int:
    frozen = verify_v31_frozen()
    if frozen["status"] != "PASS":
        raise SystemExit("V31 frozen evidence verification failed")
    if V32.exists():
        raise SystemExit("governance-only milestone forbids V32 creation")
    p = paths()
    diagnostic = load(p["diagnostic"])
    binding = load(p["binding"])
    prompt_binding = load(p["prompt_binding"])
    request = load(p["request"])
    bound_paths = {row["path"] for row in binding["members"]}
    symbol_manifest = load(p["symbol"])
    comparison = {
        "record_type": "V31_ARTIFACT_FINALIZATION_ORDER_EVIDENCE_COMPARISON",
        "authoritative_binding": {
            "path": str(p["binding"]),
            "sha256": sha256(p["binding"]),
            "member_count": binding["member_count"],
            "reread_and_rehash_claim": binding["reread_and_rehash"],
            "symbol_manifest_member_present": SYMBOL_PATH in bound_paths,
        },
        "late_symbol_binding_manifest": {
            "logical_identity": symbol_manifest["record_type"],
            "path": str(p["symbol"]),
            "sha256": sha256(p["symbol"]),
            "bytes": p["symbol"].stat().st_size,
            "mode_at_failure_from_frozen_diagnostic": diagnostic["facts"]["symbol_manifest_mode_at_failure"],
            "required_mode": diagnostic["facts"]["required_symbol_manifest_mode"],
            "current_preservation_mode_after_failure_freeze": f"{stat.S_IMODE(p['symbol'].stat().st_mode):04o}",
            "created_after_authoritative_binding": diagnostic["facts"]["authoritative_artifact_binding_created_before_symbol_manifest"],
            "absent_from_bound_member_set": diagnostic["facts"]["symbol_manifest_absent_from_authoritative_member_set"],
        },
        "prompt": {
            "path": str(p["prompt"]),
            "actual_sha256": sha256(p["prompt"]),
            "prompt_binding_first_sha256": prompt_binding["first_prompt_sha256"],
            "prompt_binding_reread_sha256": prompt_binding["reread_prompt_sha256"],
            "worker_request_bound_sha256": request["prompt"]["sha256"],
            "all_equal_expected": sha256(p["prompt"]) == prompt_binding["first_prompt_sha256"] == prompt_binding["reread_prompt_sha256"] == request["prompt"]["sha256"] == PROMPT_SHA,
            "failure_derivation": "AUTHORITATIVE_DEPENDENCY_MEMBER_SET_INCOMPLETE",
        },
        "status": "PASS",
    }
    lifecycle = {
        "record_type": "SUCCESSOR_V32_AUTHORITATIVE_ARTIFACT_FINALIZATION_LIFECYCLE_CONTRACT",
        "contract_identity": "V32_AUTHORITATIVE_ARTIFACT_CREATION_CLOSURE_FREEZE_AND_BINDING_CONTRACT_V1",
        "successor_identity": V32_IDENTITY,
        "authorizing_governance_identity": IDENTITY,
        "authorizing_governance_lock": "EXACT_SHA256_OF_THIS_PACKAGE_GOVERNANCE_LOCK_JSON",
        "authoritative_artifacts_include": ["COMPLETE_LOCKED_ENTRYPOINT_SYMBOL_BINDING_MANIFEST", "FINAL_WORKER_PROMPT", "ALL_CONTRACTS_SCHEMAS_REQUESTS_CONFIGS_AND_EXECUTION_INPUTS"],
        "required_order": [
            "MATERIALIZE_ALL_AUTHORITATIVE_ARTIFACTS",
            "RECORD_EXPLICIT_AUTHORITATIVE_ARTIFACT_CREATION_CLOSURE",
            "FINALIZE_EXACT_ARTIFACT_BYTES",
            "APPLY_REQUIRED_IMMUTABLE_MODES",
            "VERIFY_EXACT_MODES_AND_OWNERSHIP",
            "COMPUTE_EXACT_ARTIFACT_DIGESTS",
            "BIND_LOGICAL_IDENTITIES_OWNERS_AND_BINDING_GENERATION",
            "REREAD_AND_REHASH_EVERY_MEMBER",
            "VERIFY_MEMBER_SET_UNCHANGED_SINCE_CLOSURE",
            "BEGIN_UNIT_AND_STATIC_VALIDATION",
        ],
        "creation_closure_semantics": "NO_AUTHORITATIVE_MEMBER_MAY_BE_CREATED_REMOVED_RENAMED_SUBSTITUTED_OR_RECLASSIFIED_AFTER_CLOSURE",
        "late_authoritative_member": "FAIL_CLOSED_BEFORE_VALIDATION",
        "required_authoritative_file_mode": "0444",
        "digest_binding_before_complete_member_set": "PROHIBITED",
        "validation_before_final_reread_rehash": "PROHIBITED",
        "status": "NORMATIVE_FOR_CONDITIONALLY_AUTHORIZED_SUCCESSOR_ONLY",
    }
    regressions = [
        "SYMBOL_MANIFEST_BEFORE_CLOSURE_INCLUDED_IMMUTABLE_0444_AND_DIGESTED_PASSES",
        "SYMBOL_MANIFEST_CREATED_AFTER_DIGEST_BINDING_FAILS_CLOSED",
        "SYMBOL_MANIFEST_OMITTED_FROM_BOUND_MEMBER_SET_FAILS_CLOSED",
        "CORRECT_SYMBOL_MANIFEST_BYTES_WITH_MODE_0664_FAILS_CLOSED",
        "NEW_AUTHORITATIVE_MEMBER_ADDED_AFTER_CLOSURE_FAILS_CLOSED",
        "AUTHORITATIVE_MEMBER_REMOVED_OR_RENAMED_AFTER_CLOSURE_FAILS_CLOSED",
        "AUTHORITATIVE_MEMBER_DIGEST_MUTATED_AFTER_BINDING_FAILS_CLOSED",
        "PROMPT_BYTES_AND_DIGEST_CORRECT_BUT_DEPENDENCY_MEMBER_SET_INCOMPLETE_FAILS_CLOSED",
        "EXACT_COMPLETE_CLOSURE_IMMUTABLE_FREEZE_DIGEST_BINDING_REREAD_REHASH_PASSES",
    ]

    emit("GOVERNANCE_CHARTER.json", {"record_type": "GOVERNANCE_CHARTER", "governance_identity": IDENTITY, "scope": "GOVERNANCE_ONLY", "prohibited": ["PATCH_V31", "RERUN_V31", "CHMOD_V31_ARTIFACTS", "REGENERATE_V31_BINDINGS", "RUN_PRIMARY_OR_INDEPENDENT_V31", "RUN_FRESH_PREFLIGHT_V31", "ISSUE_STATIC_LOCK", "INVOKE_SECURITY_WORKER", "INVOKE_CODEX", "CREATE_OR_EXECUTE_V32"], "status": "ACTIVE"})
    emit("ROUTING_LEDGER.json", {"record_type": "ROUTING_LEDGER", "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "expert-python-engineer"], "deferred": [], "not_applicable": ["target-recon", "prior-art-web-search", "exploit-execution", "paid-tools", "subagents", "parallelism"], "reason": "LOCAL_GOVERNANCE_ONLY_FROZEN_EVIDENCE_ADJUDICATION", "status": "PASS"})
    emit("V31_FROZEN_FAILURE_EVIDENCE_BINDING.json", {"record_type": "V31_FROZEN_FAILURE_EVIDENCE_BINDING", "execution_identity": V31_IDENTITY, "terminal_sha256": V31_TERMINAL_SHA, "failure_manifest_sha256": V31_MANIFEST_SHA, "freeze_verification_sha256": V31_FREEZE_SHA, "unit_failure_diagnostic_sha256": V31_DIAGNOSTIC_SHA, "canonical_evidence_root_sha256": V31_ROOT_SHA, "verification": frozen, "status": "PASS"})
    emit("V31_FAILURE_FACTS.json", {"record_type": "V31_FAILURE_FACTS", "unit": "359/361 PASS", "failed_gates": sorted(FAILURES), "primary": "NOT_STARTED", "independent": "NOT_STARTED", "preflight": "NOT_STARTED", "static_lock": "NOT_ISSUED", "attempt": "0/1", "worker": "0/1", "codex": "0/1", "attempt_marker": "ABSENT", "runtime_evidence": "ABSENT", "status": "PASS"})
    emit("V31_ARTIFACT_FINALIZATION_ORDER_EVIDENCE_COMPARISON.json", comparison)
    emit("V31_ARTIFACT_FINALIZATION_ORDER_ADJUDICATION.json", {"record_type": "V31_ARTIFACT_FINALIZATION_ORDER_ADJUDICATION", "AUTHORITATIVE_ARTIFACT_FINALIZATION_ORDER_DEFECT": "YES", "LATE_SYMBOL_BINDING_MANIFEST_MATERIALIZATION_DEFECT": "YES", "AUTHORITATIVE_BOUND_MEMBER_SET_INCOMPLETENESS": "YES", "AUTHORITATIVE_ARTIFACT_IMMUTABILITY_MODE_DEFECT": "YES", "cause": "SYMBOL_BINDING_MANIFEST_MATERIALIZED_AFTER_AUTHORITATIVE_DIGEST_BINDING_AND_THEREFORE_OMITTED_FROM_BOUND_MEMBER_SET_AND_LEFT_MODE_0664_AT_FAILURE", "current_mode_after_failure_freeze": "0444_PRESERVATION_ONLY_NOT_RETROACTIVE_PASS", "simple_late_digest_addition_authorized": False, "status": "PASS"})
    emit("V31_PROMPT_FAILURE_DERIVATION_ADJUDICATION.json", {"record_type": "V31_PROMPT_FAILURE_DERIVATION_ADJUDICATION", "U027_V7_PROMPT_IDENTITY": "DERIVED_FROM_INCOMPLETE_AUTHORITATIVE_ARTIFACT_IDENTITY", "INDEPENDENT_PROMPT_BYTES_OR_DIGEST_DEFECT": "NO", "actual_prompt_sha256": PROMPT_SHA, "bound_prompt_sha256": PROMPT_SHA, "reread_prompt_sha256": PROMPT_SHA, "worker_request_prompt_sha256": PROMPT_SHA, "authoritative_dependency_member_set_complete": False, "status": "PASS"})
    emit("SUCCESSOR_V32_AUTHORITATIVE_ARTIFACT_FINALIZATION_LIFECYCLE_CONTRACT.json", lifecycle)
    emit("V31_FAILURE_AND_V32_REGRESSION_MATRIX.json", {"record_type": "V31_FAILURE_AND_V32_REGRESSION_MATRIX", "required_regressions": regressions, "count": len(regressions), "carry_forward": "ALL_APPLICABLE_V1_THROUGH_V31_CONTROLS_NOT_IMPLICATED_BY_FROZEN_EVIDENCE", "preserved_controls": ["EXACT_CODEX_0_166_0_RUNTIME_AUTHORITY", "BIND_SOURCE_LIFECYCLE", "GOVERNANCE_BOUND_MOUNT_OUTPUT_IDENTITY", "TYPED_PREFLIGHT_FRAMEWORK", "TYPED_HISTORICAL_REGISTRY", "PREDECESSOR_AND_TRANSITIVE_BINDINGS", "MODULE_RESOLUTION", "SYMBOL_GRAPH_SEMANTICS", "PYTHON_CACHE_POLICY", "WORKSPACE_BOUNDARY", "TRANSACTIONAL_TELEMETRY", "STRICT_TEMPORAL_N_OF_N_CONTRACTS"], "status": "PASS"})
    emit("V31_TERMINAL_AND_V32_SUCCESSOR_DECISION.json", {"record_type": "V31_TERMINAL_AND_V32_SUCCESSOR_DECISION", "decision": "TERMINALIZE_V31_AND_AUTHORIZE_DISTINCT_V32_CONDITIONALLY", "v31_disposition": "TERMINAL_IMMUTABLE_NO_RETRY", "v32_disposition": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED", "attempt": "0/1", "worker_invocation": "0/1", "codex_as_worker_invocation": "0/1", "securityworker_runtime": "NOT_ESTABLISHED", "codex_worker_runtime": "NOT_ESTABLISHED", "temporal_runtime": "NOT_ESTABLISHED", "process_lineage": "NOT_PROVEN", "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN", "status": "PASS"})
    emit("V31_IMMUTABILITY_AND_AUTHORITY_CEILING.json", {"record_type": "V31_IMMUTABILITY_AND_AUTHORITY_CEILING", "v31": "READ_ONLY_FROZEN", "v32_created": False, "target": 0, "credential": 0, "target_network": 0, "subagent": 0, "parallelism": 0, "promotion": 0, "submission": 0, "worker": 0, "codex": 0, "status": "PASS"})
    emit("NEXT_LEGAL_MILESTONE.json", {"record_type": "NEXT_LEGAL_MILESTONE", "milestone": "IMPLEMENT_FRESH_V32_ONLY_UNDER_SEPARATE_ENGINEERING_REQUEST", "v32_created": False, "v32_executed": False, "status": "PASS"})
    print("GOVERNANCE_BUILD=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
