#!/usr/bin/env python3
"""Pure non-mutating fixtures for the V32 artifact-finalization model."""

from copy import deepcopy

from governance_common import ROOT, finalization_verdict, write_once


def main() -> int:
    exact = {
        "all_authoritative_members_materialized": True,
        "symbol_manifest_materialized_before_closure": True,
        "creation_closure_recorded": True,
        "no_members_added_removed_renamed_or_substituted_after_closure": True,
        "all_bytes_finalized_after_closure": True,
        "all_modes": "0444",
        "ownership_exact": True,
        "symbol_manifest_in_bound_member_set": True,
        "all_member_digests_exact": True,
        "logical_owner_generation_bindings_exact": True,
        "reread_rehash_exact": True,
        "member_set_unchanged_after_binding": True,
        "validation_started_only_after_verification": True,
    }

    def changed(key, value):
        candidate = deepcopy(exact)
        candidate[key] = value
        return candidate

    fixtures = [
        ("N001_SYMBOL_BEFORE_CLOSURE_EXACT", finalization_verdict(exact)),
        ("N002_SYMBOL_AFTER_DIGEST_BINDING", not finalization_verdict(changed("symbol_manifest_materialized_before_closure", False))),
        ("N003_SYMBOL_OMITTED", not finalization_verdict(changed("symbol_manifest_in_bound_member_set", False))),
        ("N004_WRITABLE_0664", not finalization_verdict(changed("all_modes", "0664"))),
        ("N005_NEW_MEMBER_AFTER_CLOSURE", not finalization_verdict(changed("no_members_added_removed_renamed_or_substituted_after_closure", False))),
        ("N006_MEMBER_REMOVED_OR_RENAMED", not finalization_verdict(changed("member_set_unchanged_after_binding", False))),
        ("N007_DIGEST_MUTATION", not finalization_verdict(changed("all_member_digests_exact", False))),
        ("N008_PROMPT_EXACT_DEPENDENCY_SET_INCOMPLETE", not finalization_verdict(changed("all_authoritative_members_materialized", False))),
        ("N009_EXACT_COMPLETE_LIFECYCLE", finalization_verdict(exact)),
        ("N010_VALIDATION_BEFORE_FINAL_VERIFICATION", not finalization_verdict(changed("validation_started_only_after_verification", False))),
    ]
    result = {"record_type": "NEGATIVE_GOVERNANCE_FIXTURES", "fixtures": [{"id": item, "status": "PASS" if ok else "FAIL"} for item, ok in fixtures], "passed": sum(ok for _, ok in fixtures), "total": len(fixtures), "filesystem_mutations": 0, "status": "PASS" if all(ok for _, ok in fixtures) else "FAIL_CLOSED"}
    write_once(ROOT / "NEGATIVE_GOVERNANCE_FIXTURES.json", result)
    print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
