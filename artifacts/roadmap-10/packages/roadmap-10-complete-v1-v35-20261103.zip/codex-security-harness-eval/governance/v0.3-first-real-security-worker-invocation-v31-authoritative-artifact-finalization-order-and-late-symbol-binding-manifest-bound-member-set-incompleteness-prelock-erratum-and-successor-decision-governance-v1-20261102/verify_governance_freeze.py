#!/usr/bin/env python3
"""Read-only final verifier for the frozen governance package."""

import hashlib
import stat

from governance_common import ROOT, V31, V32, load, sha256, verify_v31_frozen


def main() -> int:
    manifest = load(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load(ROOT / "GOVERNANCE_LOCK.json")
    final = load(ROOT / "FINAL_FREEZE_VERIFICATION.json")
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in manifest["members"])
    root_sha = hashlib.sha256(rows.encode()).hexdigest()
    exact = all((ROOT / row["path"]).is_file() and not (ROOT / row["path"]).is_symlink() and sha256(ROOT / row["path"]) == row["sha256"] and (ROOT / row["path"]).stat().st_size == row["bytes"] and stat.S_IMODE((ROOT / row["path"]).stat().st_mode) == 0o444 for row in manifest["members"])
    checks = {
        "F001_ROOT": root_sha == manifest["canonical_governance_root_sha256"] == lock["canonical_governance_root_sha256"] == final["canonical_governance_root_sha256"],
        "F002_MANIFEST": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock["governance_artifact_manifest_sha256"] == final["manifest_sha256"],
        "F003_LOCK": sha256(ROOT / "GOVERNANCE_LOCK.json") == final["governance_lock_sha256"],
        "F004_MEMBERS": exact and len(manifest["members"]) == manifest["member_count"] == final["member_count"],
        "F005_READ_ONLY": stat.S_IMODE(ROOT.stat().st_mode) == 0o555 and all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()),
        "F006_DEFECTS": all(lock[key] == "YES" for key in ("AUTHORITATIVE_ARTIFACT_FINALIZATION_ORDER_DEFECT", "LATE_SYMBOL_BINDING_MANIFEST_MATERIALIZATION_DEFECT", "AUTHORITATIVE_BOUND_MEMBER_SET_INCOMPLETENESS", "AUTHORITATIVE_ARTIFACT_IMMUTABILITY_MODE_DEFECT")),
        "F007_PROMPT_DERIVED": lock["U027_V7_PROMPT_IDENTITY"] == "DERIVED_FROM_INCOMPLETE_AUTHORITATIVE_ARTIFACT_IDENTITY" and lock["INDEPENDENT_PROMPT_BYTES_OR_DIGEST_DEFECT"] == "NO",
        "F008_DECISION": lock["v31_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY" and lock["v32_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "F009_V31_FROZEN": verify_v31_frozen()["status"] == "PASS",
        "F010_NO_V31_EXECUTION": not (V31 / "STATIC_EXECUTION_LOCK.json").exists() and not (V31 / "static-run-v31/attempt-marker-0001.json").exists() and not (V31 / "static-run-v31/runtime-result-0001.json").exists(),
        "F011_V32_ABSENT": not V32.exists(),
        "F012_FINAL": final["status"] == "PASS",
    }
    passed = sum(checks.values())
    status = "PASS" if all(checks.values()) else "FAIL_CLOSED"
    print(f"FINAL_FREEZE_VERIFICATION={passed}/{len(checks)} {status}")
    print(f"GOVERNANCE_ROOT_SHA256={root_sha}")
    print(f"GOVERNANCE_LOCK_SHA256={sha256(ROOT / 'GOVERNANCE_LOCK.json')}")
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
