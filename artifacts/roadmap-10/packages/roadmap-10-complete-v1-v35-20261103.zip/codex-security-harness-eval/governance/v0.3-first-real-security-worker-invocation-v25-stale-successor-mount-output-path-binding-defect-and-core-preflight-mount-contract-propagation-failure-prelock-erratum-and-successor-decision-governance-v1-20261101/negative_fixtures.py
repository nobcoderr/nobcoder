#!/usr/bin/env python3
from copy import deepcopy
from governance_common import *


def canonical_fixture() -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    host = "/home/nobcoder/v0.3-first-real-security-worker-invocation-v26-20261101/static-run-v26"
    namespace = "/run/nobcoder-first-worker-v26/output"
    generation = "V26_GOVERNANCE_BOUND_MOUNT_OUTPUT_BINDING_GENERATION_0001"
    binding = {
        "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V26",
        "workspace_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V26_WORKSPACE",
        "logical_runtime_output_identity": "V26_RUNTIME_OUTPUT_ROOT",
        "canonical_workspace_root": "/home/nobcoder/v0.3-first-real-security-worker-invocation-v26-20261101",
        "host_output_path": host,
        "namespace_output_path": namespace,
        "mount_source_path": host,
        "mount_destination_path": namespace,
        "mount_mode": "READ_WRITE_EXACT_DECLARED_OUTPUT_BIND_ONLY",
        "governance_identity": GOVERNANCE_ID,
        "governance_lock_sha256": "PENDING_FINAL_GOVERNANCE_LOCK_DIGEST_BOUND_AT_V26_CREATION",
        "binding_generation_identity": generation,
        "selection_rule": "EXACT_GOVERNANCE_SUCCESSOR_DECISION_NO_VERSION_INFERENCE",
    }
    names = ("runner", "primary_validator", "independent_validator", "fresh_preflight", "dependency_closure", "static_lock", "runtime_namespace", "post_validator")
    consumers = {name: {"host_output_path": host, "namespace_output_path": namespace, "binding_generation_identity": generation, "stale_literal_detected": False} for name in names}
    return binding, consumers


def main() -> None:
    base, consumers = canonical_fixture()
    cases: list[tuple[str, dict[str, Any], dict[str, dict[str, Any]], str]] = []
    def add(identity: str, mutate, expected: str = "FAIL_CLOSED") -> None:
        binding = deepcopy(base); rows = deepcopy(consumers); mutate(binding, rows); cases.append((identity, binding, rows, expected))
    add("V26_RUNNER_WITH_V23_MOUNT_BINDING", lambda b,c: c["runner"].update(namespace_output_path="/run/nobcoder-first-worker-v23/output", stale_literal_detected=True))
    add("V26_RUNNER_WITH_V25_STALE_BINDING", lambda b,c: c["runner"].update(namespace_output_path="/run/nobcoder-first-worker-v25/output", stale_literal_detected=True))
    add("VERSION_NUMBER_DERIVED_OUTPUT_PATH", lambda b,c: b.update(selection_rule="VERSION_NUMBER_ARITHMETIC"))
    add("RUNNER_PREFLIGHT_PATH_MISMATCH", lambda b,c: c["fresh_preflight"].update(namespace_output_path="/run/mismatch/output"))
    add("PREFLIGHT_STATIC_LOCK_MISMATCH", lambda b,c: c["static_lock"].update(binding_generation_identity="STALE_GENERATION"))
    add("CORRECT_HOST_WRONG_NAMESPACE_DESTINATION", lambda b,c: b.update(mount_destination_path="/run/wrong/output"))
    add("STALE_HARDCODED_PATH_IN_CONTRACT_SCHEMA_OR_VALIDATOR", lambda b,c: c["independent_validator"].update(stale_literal_detected=True))
    cases.append(("EXACT_GOVERNANCE_BOUND_SUCCESSOR_MOUNT_OUTPUT_BINDING", deepcopy(base), deepcopy(consumers), "PASS"))
    add("MIXED_BINDING_GENERATION", lambda b,c: c["dependency_closure"].update(binding_generation_identity="GENERATION_0000"))
    add("WRONG_GOVERNANCE_AUTHORITY", lambda b,c: b.update(governance_identity="UNAUTHORIZED"))
    results = []
    for identity, binding, rows, expected in cases:
        verdict = mount_binding_verdict(binding, rows)
        results.append({"id": identity, "expected": expected, "actual": verdict["status"], "status": "PASS" if verdict["status"] == expected else "FAIL", "verdict": verdict})
    failures = [row["id"] for row in results if row["status"] != "PASS"]
    result = {"record_type": "NEGATIVE_GOVERNANCE_TEST_RESULT", "governance_identity": GOVERNANCE_ID, "cases": results, "validation_counts": {"total": len(results), "passed": len(results)-len(failures), "failed": len(failures)}, "failure_ids": failures, "status": "PASS" if not failures else "FAIL_CLOSED"}
    write_json_once(PACKAGE / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", result)
    print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['status']} {len(results)-len(failures)}/{len(results)}")
    if failures: raise SystemExit(1)


if __name__ == "__main__": main()
