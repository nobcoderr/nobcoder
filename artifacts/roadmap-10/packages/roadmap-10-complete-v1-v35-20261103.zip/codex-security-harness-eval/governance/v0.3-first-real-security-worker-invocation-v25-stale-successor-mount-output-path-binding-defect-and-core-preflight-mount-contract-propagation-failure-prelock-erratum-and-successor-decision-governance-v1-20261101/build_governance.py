#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    assert_v25_frozen(); assert_v24_authority()
    contract = load_json(V25_PATHS["mount_contract"])
    primary = load_json(V25_PATHS["primary"])
    successor = load_json(V25_PATHS["successor_requirements"])
    checks = {row["id"]: row for row in primary["checks"]}
    mount_evidence = checks["S_MOUNT"]["evidence"]
    core_failures = checks["S064_CORE_PREFLIGHT"]["evidence"]
    source = V25_PATHS["invocation"].read_text(encoding="utf-8")
    stale_path = contract["authorized_host_output_bind"]["sandbox_mount_point"]
    runner_path = "/run/nobcoder-first-worker-v25/output"
    old_tokens = {
        "TRANSACTIONAL_OR_COMMIT_MARKED_SELFTEST_TELEMETRY_PUBLICATION",
        "CONSUMER_REQUIRES_COMPLETION_PROOF_BEFORE_PARSE",
    }
    requirements = set(successor.get("requirements", []))

    artifacts = {
        "GOVERNANCE_CHARTER.json": {
            "record_type": "V25_MOUNT_OUTPUT_BINDING_GOVERNANCE_CHARTER",
            "governance_identity": GOVERNANCE_ID,
            "milestone_type": "GOVERNANCE_ONLY",
            "prohibitions": ["PATCH_V25", "RERUN_V25", "DUPLICATE_V25", "RUN_V25_INDEPENDENT", "RUN_V25_PREFLIGHT", "ISSUE_V25_STATIC_LOCK", "INVOKE_SECURITY_WORKER_OR_CODEX", "CREATE_OR_EXECUTE_V26"],
            "frozen_state": {"v25": V25_STATE, "static_lock": "NOT_ISSUED", "attempt": "0/1", "worker": "0/1", "codex": "0/1"},
        },
        "V25_FROZEN_FAILURE_EVIDENCE_BINDING.json": {
            "record_type": "V25_FROZEN_FAILURE_EVIDENCE_BINDING",
            "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V25",
            "status": V25_STATE,
            "canonical_evidence_root_sha256": V25_EVIDENCE_ROOT,
            "member_count": 102,
            "hashes": {k: V25_HASHES[k] for k in ("terminal", "manifest", "freeze", "unit", "primary")},
            "validation": {"unit": "292/292 PASS", "primary": "80/82 FAIL_CLOSED", "independent": "NOT_STARTED", "fresh_preflight": "NOT_STARTED"},
            "failed_gates": ["S_MOUNT", "S064_CORE_PREFLIGHT"],
            "execution": {"static_lock": "NOT_ISSUED", "attempt": "0/1", "worker": "0/1", "codex": "0/1", "attempt_marker": "ABSENT", "runtime_evidence": "ABSENT"},
        },
        "MOUNT_OUTPUT_BINDING_COMPONENT_COMPARISON.json": {
            "record_type": "V25_MOUNT_OUTPUT_BINDING_COMPONENT_COMPARISON",
            "governance_authorized_successor_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V25",
            "governance_authority": {"lock": str(V24_GOV_PATHS["lock"]), "lock_sha256": V24_GOV_HASHES["lock"], "decision": str(V24_GOV_PATHS["decision"]), "decision_sha256": V24_GOV_HASHES["decision"]},
            "components": [
                {"component": "runner_output_path", "resolved_host": str(V25 / "static-run-v25"), "resolved_namespace": runner_path, "basis": "src/invocation_v25.py:47,147-148; bwrap bind construction", "status": "V25_EXACT"},
                {"component": "mount_contract_source_destination", "resolved_host": contract["authorized_host_output_bind"]["host_source"], "resolved_namespace": stale_path, "basis": "contracts/MOUNT_PROVENANCE_WRITE_CONTRACT.json", "status": "STALE_V23_NAMESPACE_DESTINATION"},
                {"component": "primary_validator_expected_path", "resolved_host": str(V25 / "static-run-v25"), "resolved_namespace": runner_path, "basis": "S_MOUNT -> mount_provenance_policy_precheck -> SANDBOX_RUN", "status": "DETECTED_MISMATCH"},
                {"component": "independent_validator_expected_path", "resolved_host": "BOUND_BY_ARTIFACT_DIGEST_ONLY", "resolved_namespace": "NO_DIRECT_SEMANTIC_PATH_GATE", "basis": "independent not started; I014/I015 bind contract bytes, no independent mount destination comparison", "status": "NOT_EXECUTED_PROPAGATION_COVERAGE_GAP"},
                {"component": "preflight_expected_path", "resolved_host": str(V25 / "static-run-v25"), "resolved_namespace": runner_path, "basis": "fresh_preflight -> mount_provenance_policy_precheck", "status": "DERIVED_MOUNT_FAILURE_NOT_SEPARATE_MOUNT_ROOT"},
                {"component": "dependency_closure_binding", "resolved_host": str(V25 / "static-run-v25"), "resolved_namespace": stale_path, "basis": "exact bytes of source plus MOUNT_PROVENANCE_WRITE_CONTRACT are both closure members", "status": "CONFLICTING_IDENTITIES_WOULD_BE_BOUND"},
                {"component": "static_lock_expected_path", "resolved_host": str(V25 / "static-run-v25"), "resolved_namespace": runner_path, "basis": "prepare_static_lock binds canonical_json_sha256(mount_provenance_policy_precheck())", "status": "NOT_REACHED_WOULD_FAIL_BEFORE_LOCK"},
                {"component": "runtime_namespace_destination", "resolved_host": str(V25 / "static-run-v25"), "resolved_namespace": runner_path, "basis": "bwrap_argv one writable host bind", "status": "STATIC_ONLY_RUNTIME_NOT_EXECUTED"},
                {"component": "post_validation_output_root", "resolved_host": str(V25 / "static-run-v25"), "resolved_namespace": runner_path, "basis": "validators/post_validate.py RUN and V25 Codex path", "status": "STATIC_ONLY_POST_VALIDATION_NOT_EXECUTED"},
            ],
            "stale_successor_specific_bindings": [{"path": "contracts/MOUNT_PROVENANCE_WRITE_CONTRACT.json", "field": "authorized_host_output_bind.sandbox_mount_point", "actual": stale_path, "required_for_v25": runner_path}],
        },
        "V25_DEFECT_ADJUDICATION.json": {
            "record_type": "V25_MOUNT_OUTPUT_BINDING_DEFECT_ADJUDICATION",
            "STALE_SUCCESSOR_MOUNT_OUTPUT_PATH_BINDING_DEFECT": "YES",
            "MOUNT_CONTRACT_SUCCESSOR_IDENTITY_PROPAGATION_DEFECT": "YES",
            "S064_CORE_PREFLIGHT_EXCLUSIVELY_DERIVED_FROM_STALE_MOUNT_BINDING": "NO",
            "S064_CORE_PREFLIGHT_MOUNT_FAILURE_COMPONENT": "DERIVED_FROM_SAME_STALE_MOUNT_BINDING",
            "S064_CORE_PREFLIGHT_INDEPENDENT_AGGREGATION_DEFECT": "NO",
            "CORE_PREFLIGHT_CARRIED_FORWARD_COVERAGE_REQUIREMENT_PREDICATE_STALENESS": "YES",
            "evidence": {
                "runtime_namespace_output": runner_path,
                "contract_namespace_output": stale_path,
                "mount_check_output_bind_exact_destination": mount_evidence["checks"]["output_bind_exact_destination"],
                "core_preflight_failure_ids": core_failures,
                "coverage_predicate_tokens_absent_from_v25_contract": sorted(old_tokens - requirements),
                "v25_contract_carry_forward_token_present": "TRANSACTIONAL_ATOMIC_SELFTEST_TELEMETRY_PIPELINE_CARRIED_FORWARD" in requirements,
            },
            "actual_runtime_mount_behavior": "NOT_ESTABLISHED",
            "security_worker_runtime": "NOT_ESTABLISHED",
            "codex_runtime": "NOT_ESTABLISHED",
            "temporal_runtime": "NOT_ESTABLISHED",
            "process_lineage": "NOT_PROVEN",
            "producer_authorization": "NOT_PROVEN",
            "confinement": "NOT_PROVEN",
            "v25_disposition": "TERMINAL_IMMUTABLE_NO_RETRY_REFERENCE_ONLY",
            "v26": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        },
        "SUCCESSOR_V26_GOVERNANCE_BOUND_MOUNT_OUTPUT_IDENTITY_CONTRACT.json": {
            "record_type": "V26_GOVERNANCE_BOUND_MOUNT_OUTPUT_IDENTITY_CONTRACT",
            "contract_identity": "V26_GOVERNANCE_BOUND_MOUNT_OUTPUT_IDENTITY_CONTRACT_V1",
            "selection_rule": "EXACT_GOVERNANCE_SUCCESSOR_DECISION_NO_VERSION_INFERENCE",
            "required_joint_fields": ["execution_identity", "workspace_identity", "logical_runtime_output_identity", "canonical_workspace_root", "host_output_path", "namespace_output_path", "mount_source_path", "mount_destination_path", "mount_mode", "governance_identity", "governance_lock_sha256", "binding_generation_identity"],
            "required_consumers": ["runner", "primary_validator", "independent_validator", "fresh_preflight", "dependency_closure", "static_lock", "runtime_namespace", "post_validator"],
            "invariants": ["HOST_OUTPUT_EQUALS_MOUNT_SOURCE", "NAMESPACE_OUTPUT_EQUALS_MOUNT_DESTINATION", "ALL_CONSUMERS_SAME_EXACT_GENERATION", "ALL_CONSUMERS_VERIFY_IDENTITY_AUTHORITY_AND_DIGEST_INDEPENDENTLY", "NO_STALE_VERSION_SPECIFIC_LITERAL", "FAIL_BEFORE_LOCK_AND_ATTEMPT_ON_MISMATCH"],
            "prohibited": ["HARDCODED_STRING_REPLACEMENT_AS_COMPLETE_FIX", "VERSION_NUMBER_ARITHMETIC", "DIRECTORY_NAME_INFERENCE", "LATEST_FILE_SELECTION", "FALLBACK_SEARCH", "MIXED_BINDING_GENERATIONS"],
            "governance_identity": GOVERNANCE_ID,
        },
        "SUCCESSOR_V26_REQUIREMENTS.json": {
            "record_type": "SUCCESSOR_V26_REQUIREMENTS",
            "v26": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
            "requirements": ["FRESH_WORKSPACE_AND_EXECUTION_IDENTITY", "GOVERNANCE_BOUND_MOUNT_OUTPUT_BINDING_GENERATION", "ALL_MOUNT_OUTPUT_CONSUMERS_RESOLVE_EXACT_SAME_BINDING", "INDEPENDENT_SEMANTIC_MOUNT_DESTINATION_GATE", "CORE_PREFLIGHT_PREDICATES_DERIVED_FROM_NORMATIVE_V26_CONTRACT", "ALL_APPLICABLE_V1_TO_V25_CONTROLS"],
            "pre_attempt_sequence": ["UNIT", "PRIMARY", "INDEPENDENT", "FRESH_PREFLIGHT", "DEPENDENCY_CLOSURE", "STATIC_LOCK", "LOCK_VERIFICATION", "POST_LOCK_PREFLIGHT", "LOCKED_PRE_ATTEMPT_WALK"],
            "prohibited": ["CREATE_OR_EXECUTE_V26_DURING_THIS_GOVERNANCE", "REUSE_V25_IDENTITY", "PATCH_OR_RERUN_V25", "VERSION_DERIVED_OUTPUT_PATH", "WEAKEN_MOUNT_OR_PRODUCER_AUTHORIZATION_SEPARATION"],
        },
        "V25_FAILURE_AND_V26_REGRESSION_MATRIX.json": {
            "record_type": "V25_FAILURE_AND_V26_REGRESSION_MATRIX",
            "required_cases": [
                {"id": "V26_RUNNER_WITH_V23_MOUNT_BINDING", "expected": "FAIL_CLOSED"},
                {"id": "V26_RUNNER_WITH_V25_STALE_BINDING", "expected": "FAIL_CLOSED"},
                {"id": "VERSION_NUMBER_DERIVED_OUTPUT_PATH", "expected": "FAIL_CLOSED"},
                {"id": "RUNNER_PREFLIGHT_PATH_MISMATCH", "expected": "FAIL_CLOSED"},
                {"id": "PREFLIGHT_STATIC_LOCK_MISMATCH", "expected": "FAIL_CLOSED"},
                {"id": "CORRECT_HOST_WRONG_NAMESPACE_DESTINATION", "expected": "FAIL_CLOSED"},
                {"id": "STALE_HARDCODED_PATH_IN_CONTRACT_SCHEMA_OR_VALIDATOR", "expected": "FAIL_CLOSED"},
                {"id": "EXACT_GOVERNANCE_BOUND_SUCCESSOR_MOUNT_OUTPUT_BINDING", "expected": "PASS"},
            ],
        },
        "V25_TERMINAL_AND_V26_SUCCESSOR_DECISION.json": {
            "record_type": "V25_TERMINAL_AND_V26_SUCCESSOR_DECISION",
            "decision": DECISION,
            "v25": "FAIL_CLOSED_PRELOCK_TERMINAL_IMMUTABLE_NO_RETRY_REFERENCE_ONLY",
            "v26": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
            "authority": GOVERNANCE_ID,
        },
        "NEXT_LEGAL_MILESTONE.json": {
            "record_type": "NEXT_LEGAL_MILESTONE",
            "milestone": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V26_ONCE_IF_ALL_GATES_PASS",
            "current_authority": "CONDITIONAL_ONLY",
            "not_performed": ["V26_CREATION", "V26_EXECUTION", "SECURITY_WORKER_INVOCATION", "CODEX_INVOCATION"],
        },
        "ROUTING_LEDGER.json": {
            "record_type": "GOVERNANCE_ROUTING_LEDGER",
            "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness"],
            "not_applicable": ["live_target", "network", "credentials", "external_paid_tools", "subagents", "parallelism", "exploit_replay", "promotion", "submission"],
        },
    }
    for name, payload in artifacts.items():
        write_json_once(PACKAGE / name, payload)
    print(f"GOVERNANCE_BUILD=PASS ARTIFACTS={len(artifacts)}")


if __name__ == "__main__": main()
