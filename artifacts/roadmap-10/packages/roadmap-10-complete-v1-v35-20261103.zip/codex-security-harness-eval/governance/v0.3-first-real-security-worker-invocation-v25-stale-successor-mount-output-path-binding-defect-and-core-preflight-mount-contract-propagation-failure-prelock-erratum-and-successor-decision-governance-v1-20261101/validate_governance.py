#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(identity: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    try: assert_v25_frozen(); frozen = True
    except Exception as exc: frozen = False; frozen_error = str(exc)
    check("G001_V25_FROZEN", frozen, None if frozen else frozen_error)
    try: assert_v24_authority(); authority = True
    except Exception as exc: authority = False; authority_error = str(exc)
    check("G002_V24_SUCCESSOR_AUTHORITY", authority, None if authority else authority_error)
    binding = load_json(PACKAGE / "V25_FROZEN_FAILURE_EVIDENCE_BINDING.json")
    check("G003_EVIDENCE_ROOT", binding.get("canonical_evidence_root_sha256") == V25_EVIDENCE_ROOT and binding.get("member_count") == 102)
    adjudication = load_json(PACKAGE / "V25_DEFECT_ADJUDICATION.json")
    check("G004_STALE_MOUNT_DEFECT", adjudication.get("STALE_SUCCESSOR_MOUNT_OUTPUT_PATH_BINDING_DEFECT") == "YES")
    check("G005_PROPAGATION_DEFECT", adjudication.get("MOUNT_CONTRACT_SUCCESSOR_IDENTITY_PROPAGATION_DEFECT") == "YES")
    check("G006_S064_NOT_FALSELY_COLLAPSED", adjudication.get("S064_CORE_PREFLIGHT_EXCLUSIVELY_DERIVED_FROM_STALE_MOUNT_BINDING") == "NO" and adjudication.get("S064_CORE_PREFLIGHT_MOUNT_FAILURE_COMPONENT") == "DERIVED_FROM_SAME_STALE_MOUNT_BINDING")
    evidence = adjudication.get("evidence", {})
    check("G007_CORE_PREFLIGHT_FROZEN_FAILURES", evidence.get("core_preflight_failure_ids") == ["mount_provenance_write_policy_precheck", "v25_complete_temporal_identity_coverage_contract"])
    check("G008_SECOND_PREDICATE_STALE", adjudication.get("CORE_PREFLIGHT_CARRIED_FORWARD_COVERAGE_REQUIREMENT_PREDICATE_STALENESS") == "YES" and len(evidence.get("coverage_predicate_tokens_absent_from_v25_contract", [])) == 2)
    check("G009_RUNTIME_NOT_INFERRED", all(adjudication.get(key) in {"NOT_ESTABLISHED", "NOT_PROVEN"} for key in ("actual_runtime_mount_behavior", "security_worker_runtime", "codex_runtime", "temporal_runtime", "process_lineage", "producer_authorization", "confinement")))
    comparison = load_json(PACKAGE / "MOUNT_OUTPUT_BINDING_COMPONENT_COMPARISON.json")
    components = {row["component"]: row for row in comparison.get("components", [])}
    expected_components = {"runner_output_path", "mount_contract_source_destination", "primary_validator_expected_path", "independent_validator_expected_path", "preflight_expected_path", "dependency_closure_binding", "static_lock_expected_path", "runtime_namespace_destination", "post_validation_output_root"}
    check("G010_COMPLETE_COMPONENT_COMPARISON", set(components) == expected_components)
    check("G011_EXACT_STALE_BINDING", comparison.get("stale_successor_specific_bindings") == [{"path": "contracts/MOUNT_PROVENANCE_WRITE_CONTRACT.json", "field": "authorized_host_output_bind.sandbox_mount_point", "actual": "/run/nobcoder-first-worker-v23/output", "required_for_v25": "/run/nobcoder-first-worker-v25/output"}])
    contract = load_json(PACKAGE / "SUCCESSOR_V26_GOVERNANCE_BOUND_MOUNT_OUTPUT_IDENTITY_CONTRACT.json")
    check("G012_JOINT_BINDING_FIELDS", set(contract.get("required_joint_fields", [])) == {"execution_identity", "workspace_identity", "logical_runtime_output_identity", "canonical_workspace_root", "host_output_path", "namespace_output_path", "mount_source_path", "mount_destination_path", "mount_mode", "governance_identity", "governance_lock_sha256", "binding_generation_identity"})
    check("G013_ALL_CONSUMERS", set(contract.get("required_consumers", [])) == {"runner", "primary_validator", "independent_validator", "fresh_preflight", "dependency_closure", "static_lock", "runtime_namespace", "post_validator"})
    check("G014_NO_HARDCODE_FIX", "HARDCODED_STRING_REPLACEMENT_AS_COMPLETE_FIX" in contract.get("prohibited", []) and "VERSION_NUMBER_ARITHMETIC" in contract.get("prohibited", []))
    requirements = load_json(PACKAGE / "SUCCESSOR_V26_REQUIREMENTS.json")
    check("G015_V26_CONDITIONAL_ONLY", requirements.get("v26") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    decision = load_json(PACKAGE / "V25_TERMINAL_AND_V26_SUCCESSOR_DECISION.json")
    check("G016_TERMINAL_SUCCESSOR_DECISION", decision.get("decision") == DECISION and decision.get("v25") == "FAIL_CLOSED_PRELOCK_TERMINAL_IMMUTABLE_NO_RETRY_REFERENCE_ONLY")
    failures = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {"record_type": "PRIMARY_GOVERNANCE_VALIDATION_RESULT", "governance_identity": GOVERNANCE_ID, "checks": checks, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "failure_ids": failures, "status": "PASS" if not failures else "FAIL_CLOSED"}
    write_json_once(PACKAGE / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failures)}/{len(checks)}")
    if failures: raise SystemExit(1)


if __name__ == "__main__": main()
