#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any


PACKAGE = Path(__file__).resolve().parent
V25 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v25-20261101")
V24_GOV = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-v24-historical-decision-registry-logical-identity-to-record-type-binding-defect-prelock-erratum-and-successor-decision-governance-v1-20261101")
GOVERNANCE_ID = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V25_STALE_SUCCESSOR_MOUNT_OUTPUT_PATH_"
    "BINDING_DEFECT_AND_CORE_PREFLIGHT_MOUNT_CONTRACT_PROPAGATION_FAILURE_PRELOCK_"
    "ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "TERMINALIZE_V25_AND_AUTHORIZE_DISTINCT_V26_CONDITIONALLY"
V25_STATE = "FAIL_CLOSED_DURING_PRIMARY_STATIC_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE"
V25_EVIDENCE_ROOT = "f47e8cc6f846b6ee819f0852930e8e6d60374cb2bc30aa1710fe27dc907dc2e4"
V25_HASHES = {
    "terminal": "9b64e8ef00ee52ff5ed9112aaccf058f853b5e06f497bbef2624b4ac7643acee",
    "manifest": "aa6616228a54994d45c0474d58a61aac3e86f82ff17c5d825c5c63743161a22e",
    "freeze": "0137331458b2d1b405164bf72b6cce8c1712a2e36844907ad67821d27114160a",
    "unit": "3e6bb32c42b55026d84be1d22117ff41daeb228c7bbd1acd13b02143be72e6fd",
    "primary": "3beb26a2d8fb410e85b140c46c21189fa44439a16c48365a2c8db4b42cf7f188",
    "mount_contract": "a5d5b5b61062ff63e2eb8b843475418bc6f639715b96216d8b1b5363dbeec42d",
    "invocation": "c2db9005da597f3c01d02403b1c2ea7c8bcad0f7a01247dddecc84ea86690e66",
    "runner": "4fae4cfeb94910d7c85030adf61a5fb410d41e900072bf5061f08a884ef12faa",
    "primary_source": "f19e357f461af9a353ad6fc7b12f5b95e4df34bffab8dd3945e532da0b720495",
    "independent_source": "457aca7ac02709dff247d5fd73c5bcb82d023613bc84c202f508f790234577c0",
    "preflight_source": "44b0bf0d08a7985c3fbf17a7679fc46e161816e9f2beb288c5a583079c2688b4",
    "lock_source": "9492e248713141226a81b8e842d717844de3b72a75a66f1f18a36d4813982152",
    "post_source": "00a8c8406b6c96c738b34cfdb5939ed410bc9c986fbdaca6e319f4f7cce6b0d4",
    "successor_requirements": "0a6f319df03211ce16a22e58708519f8cf182f0b1cb3da8b5c36c8366653f03c",
}
V25_PATHS = {
    "terminal": V25 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "manifest": V25 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
    "freeze": V25 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
    "unit": V25 / "results/prelock/unit-fixtures-run-0001.json",
    "primary": V25 / "results/prelock/primary-static-validation-run-0001.json",
    "mount_contract": V25 / "contracts/MOUNT_PROVENANCE_WRITE_CONTRACT.json",
    "invocation": V25 / "src/invocation_v25.py",
    "runner": V25 / "src/runner_v25.py",
    "primary_source": V25 / "validators/primary_static_validate.py",
    "independent_source": V25 / "validators/independent_static_validate.py",
    "preflight_source": V25 / "preflight.py",
    "lock_source": V25 / "prepare_static_lock.py",
    "post_source": V25 / "validators/post_validate.py",
    "successor_requirements": V25 / "contracts/SUCCESSOR_V25_REQUIREMENTS.json",
}
V24_GOV_HASHES = {
    "lock": "43d1b0ab3973b200e04f93fb37d2ce12ad642f42b739c571fb41c83a74c06ee9",
    "decision": "6a620e5c6587390745f4a1ced484fef563a6b4611d37720e6471f34fd37bc483",
}
V24_GOV_PATHS = {
    "lock": V24_GOV / "GOVERNANCE_LOCK.json",
    "decision": V24_GOV / "V24_TERMINAL_AND_V25_SUCCESSOR_DECISION.json",
}
VALIDATION_FILES = (
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
)


def canonical_json(value: object) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path}")
    return value


def write_json_once(path: Path, value: object) -> None:
    data = canonical_json(value)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        os.close(fd)


def is_read_only(path: Path) -> bool:
    return path.is_file() and not path.is_symlink() and stat.S_IMODE(path.stat().st_mode) == 0o444


def set_read_only(path: Path) -> None:
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"unsafe freeze member: {path}")
    os.chmod(path, 0o444)


def assert_v25_frozen() -> None:
    for identity, path in V25_PATHS.items():
        if not path.is_file() or path.is_symlink() or sha256_file(path) != V25_HASHES[identity]:
            raise RuntimeError(f"V25 frozen member mismatch: {identity}")
    terminal = load_json(V25_PATHS["terminal"])
    if terminal.get("status") != V25_STATE:
        raise RuntimeError("V25 terminal state mismatch")
    if not (
        terminal.get("static_lock") == "NOT_ISSUED"
        and terminal.get("attempt_count") == terminal.get("worker_invocation_count") == terminal.get("codex_as_worker_invocation_count") == 0
        and terminal.get("attempt_limit") == 1
        and terminal.get("attempt_marker") == terminal.get("runtime_evidence") == "ABSENT"
    ):
        raise RuntimeError("V25 execution state mismatch")
    manifest = load_json(V25_PATHS["manifest"])
    if manifest.get("canonical_evidence_root_sha256") != V25_EVIDENCE_ROOT or manifest.get("member_count") != 102:
        raise RuntimeError("V25 evidence root mismatch")
    unit = load_json(V25_PATHS["unit"])
    primary = load_json(V25_PATHS["primary"])
    if unit.get("validation_counts") != {"total": 292, "passed": 292, "failed": 0} or unit.get("status") != "PASS":
        raise RuntimeError("V25 unit evidence mismatch")
    if primary.get("validation_counts") != {"total": 82, "passed": 80, "failed": 2} or primary.get("status") != "FAIL_CLOSED":
        raise RuntimeError("V25 primary evidence mismatch")
    if primary.get("failure_ids") != ["S_MOUNT", "S064_CORE_PREFLIGHT"]:
        raise RuntimeError("V25 primary failure ids mismatch")
    if (V25 / "results/prelock/independent-static-validation-run-0001.json").exists():
        raise RuntimeError("V25 independent validation unexpectedly exists")
    if (V25 / "results/prelock/fresh-preflight-run-0001.json").exists() or (V25 / "STATIC_EXECUTION_LOCK.json").exists():
        raise RuntimeError("V25 advanced beyond authorized frozen state")
    if (V25 / "static-run-v25/ATTEMPT_MARKER.json").exists() or (V25 / "static-run-v25/runtime-result-0001.json").exists():
        raise RuntimeError("V25 attempt/runtime unexpectedly exists")


def assert_v24_authority() -> None:
    for identity, path in V24_GOV_PATHS.items():
        if not path.is_file() or path.is_symlink() or sha256_file(path) != V24_GOV_HASHES[identity]:
            raise RuntimeError(f"V24 governance authority mismatch: {identity}")
    lock = load_json(V24_GOV_PATHS["lock"])
    decision = load_json(V24_GOV_PATHS["decision"])
    if lock.get("status") != "PASS_LOCKED_GOVERNANCE_ONLY" or lock.get("decision") != "TERMINALIZE_V24_AND_AUTHORIZE_DISTINCT_V25_CONDITIONALLY":
        raise RuntimeError("V24 governance lock state mismatch")
    if decision.get("decision") != "TERMINALIZE_V24_AND_AUTHORIZE_DISTINCT_V25_CONDITIONALLY":
        raise RuntimeError("V24 successor decision mismatch")


def mount_binding_verdict(binding: dict[str, Any], consumers: dict[str, dict[str, Any]]) -> dict[str, Any]:
    required = {
        "execution_identity", "workspace_identity", "logical_runtime_output_identity",
        "canonical_workspace_root", "host_output_path", "namespace_output_path",
        "mount_source_path", "mount_destination_path", "mount_mode",
        "governance_identity", "governance_lock_sha256", "binding_generation_identity",
    }
    checks = {
        "required_fields_exact": required <= set(binding),
        "execution_identity_exact": binding.get("execution_identity") == "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V26",
        "workspace_identity_exact": binding.get("workspace_identity") == "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V26_WORKSPACE",
        "logical_output_exact": binding.get("logical_runtime_output_identity") == "V26_RUNTIME_OUTPUT_ROOT",
        "host_source_exact": binding.get("host_output_path") == binding.get("mount_source_path"),
        "namespace_destination_exact": binding.get("namespace_output_path") == binding.get("mount_destination_path"),
        "mount_mode_exact": binding.get("mount_mode") == "READ_WRITE_EXACT_DECLARED_OUTPUT_BIND_ONLY",
        "governance_exact": binding.get("governance_identity") == GOVERNANCE_ID,
        "generation_explicit": binding.get("binding_generation_identity") == "V26_GOVERNANCE_BOUND_MOUNT_OUTPUT_BINDING_GENERATION_0001",
        "no_version_inference": binding.get("selection_rule") == "EXACT_GOVERNANCE_SUCCESSOR_DECISION_NO_VERSION_INFERENCE",
        "all_consumers_present": set(consumers) == {
            "runner", "primary_validator", "independent_validator", "fresh_preflight",
            "dependency_closure", "static_lock", "runtime_namespace", "post_validator",
        },
        "all_consumers_same_generation": all(row.get("binding_generation_identity") == binding.get("binding_generation_identity") for row in consumers.values()),
        "all_consumers_same_host": all(row.get("host_output_path") == binding.get("host_output_path") for row in consumers.values()),
        "all_consumers_same_namespace": all(row.get("namespace_output_path") == binding.get("namespace_output_path") for row in consumers.values()),
        "no_stale_literal": all(not row.get("stale_literal_detected", False) for row in consumers.values()),
    }
    return {"status": "PASS" if all(checks.values()) else "FAIL_CLOSED", "checks": checks}


def package_member_paths(exclude: tuple[str, ...] = ()) -> list[Path]:
    excluded = set(exclude)
    return sorted(path for path in PACKAGE.iterdir() if path.is_file() and path.name not in excluded)


def package_root(paths: list[Path]) -> str:
    stream = b"".join(path.name.encode() + b"\0" + sha256_file(path).encode() + b"\n" for path in sorted(paths, key=lambda p: p.name))
    return hashlib.sha256(stream).hexdigest()
