#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    checks=[]
    def check(identity, condition, evidence=None): checks.append({"id":identity,"status":"PASS" if condition else "FAIL","evidence":evidence})
    for identity,path in V25_PATHS.items():
        check(f"R_V25_{identity}",path.is_file() and not path.is_symlink() and sha256_file(path)==V25_HASHES[identity],str(path))
    for identity,path in V24_GOV_PATHS.items():
        check(f"R_V24_GOV_{identity}",path.is_file() and not path.is_symlink() and sha256_file(path)==V24_GOV_HASHES[identity],str(path))
    check("R_FAILURE_EVIDENCE_READ_ONLY",all(is_read_only(V25_PATHS[name]) for name in ("terminal","manifest","freeze","unit","primary")))
    check("R_NO_INDEPENDENT_PREFLIGHT",not (V25/"results/prelock/independent-static-validation-run-0001.json").exists() and not (V25/"results/prelock/fresh-preflight-run-0001.json").exists())
    check("R_NO_LOCK_ATTEMPT_RUNTIME",not (V25/"STATIC_EXECUTION_LOCK.json").exists() and not (V25/"static-run-v25/ATTEMPT_MARKER.json").exists() and not (V25/"static-run-v25/runtime-result-0001.json").exists())
    check("R_V26_NOT_CREATED",not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v26-20261101").exists())
    failures=[r["id"] for r in checks if r["status"]!="PASS"]
    result={"record_type":"READ_ONLY_INTEGRITY_RESULT","governance_identity":GOVERNANCE_ID,"checks":checks,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failures),"failed":len(failures)},"failure_ids":failures,"status":"PASS" if not failures else "FAIL_CLOSED"}
    write_json_once(PACKAGE/"READ_ONLY_INTEGRITY_RESULT_RUN-0001.json",result)
    print(f"READ_ONLY_INTEGRITY={result['status']} {len(checks)-len(failures)}/{len(checks)}")
    if failures: raise SystemExit(1)


if __name__=="__main__": main()
