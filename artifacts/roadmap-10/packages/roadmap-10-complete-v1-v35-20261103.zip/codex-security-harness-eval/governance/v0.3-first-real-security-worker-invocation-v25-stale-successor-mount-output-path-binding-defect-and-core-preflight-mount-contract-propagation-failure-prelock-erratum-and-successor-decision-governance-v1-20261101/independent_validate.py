#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
from governance_common import PACKAGE, V25, GOVERNANCE_ID, V25_EVIDENCE_ROOT, V25_STATE, write_json_once


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    value = json.loads(path.read_text())
    if not isinstance(value, dict): raise ValueError(path)
    return value


def main() -> None:
    checks = []
    def check(identity, condition, evidence=None): checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    terminal = V25 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json"
    manifest = V25 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json"
    primary_path = V25 / "results/prelock/primary-static-validation-run-0001.json"
    contract_path = V25 / "contracts/MOUNT_PROVENANCE_WRITE_CONTRACT.json"
    invocation_path = V25 / "src/invocation_v25.py"
    expected = {
        terminal: "9b64e8ef00ee52ff5ed9112aaccf058f853b5e06f497bbef2624b4ac7643acee",
        manifest: "aa6616228a54994d45c0474d58a61aac3e86f82ff17c5d825c5c63743161a22e",
        primary_path: "3beb26a2d8fb410e85b140c46c21189fa44439a16c48365a2c8db4b42cf7f188",
        contract_path: "a5d5b5b61062ff63e2eb8b843475418bc6f639715b96216d8b1b5363dbeec42d",
        invocation_path: "c2db9005da597f3c01d02403b1c2ea7c8bcad0f7a01247dddecc84ea86690e66",
    }
    check("I001_FROZEN_HASHES", all(p.is_file() and not p.is_symlink() and digest(p) == h for p,h in expected.items()))
    check("I002_TERMINAL", load(terminal).get("status") == V25_STATE)
    check("I003_EVIDENCE_ROOT", load(manifest).get("canonical_evidence_root_sha256") == V25_EVIDENCE_ROOT and load(manifest).get("member_count") == 102)
    primary = load(primary_path)
    rows = {row["id"]: row for row in primary["checks"]}
    mount = rows["S_MOUNT"]["evidence"]
    check("I004_PRIMARY_STATE", primary.get("validation_counts") == {"total":82,"passed":80,"failed":2} and primary.get("failure_ids") == ["S_MOUNT","S064_CORE_PREFLIGHT"])
    check("I005_MOUNT_EXACT_DESTINATION_ONLY_FAILURE", mount.get("status") == "FAIL_CLOSED" and mount["checks"].get("output_bind_exact_destination") is False and sum(value is False for value in mount["checks"].values()) == 1)
    contract = load(contract_path); source = invocation_path.read_text()
    host = contract.get("authorized_host_output_bind", {}).get("host_source")
    namespace = contract.get("authorized_host_output_bind", {}).get("sandbox_mount_point")
    check("I006_HOST_SOURCE_V25", host == str(V25 / "static-run-v25"))
    check("I007_NAMESPACE_STALE_V23", namespace == "/run/nobcoder-first-worker-v23/output")
    check("I008_RUNNER_NAMESPACE_V25", 'SANDBOX_BASE = Path("/run/nobcoder-first-worker-v25")' in source and 'SANDBOX_RUN = SANDBOX_BASE / "output"' in source)
    check("I009_CORE_PREFLIGHT_COMPOSITE", rows["S064_CORE_PREFLIGHT"]["evidence"] == ["mount_provenance_write_policy_precheck", "v25_complete_temporal_identity_coverage_contract"])
    successor = load(V25 / "contracts/SUCCESSOR_V25_REQUIREMENTS.json")
    requirements = set(successor.get("requirements", []))
    check("I010_COVERAGE_TOKEN_MODEL", "TRANSACTIONAL_ATOMIC_SELFTEST_TELEMETRY_PIPELINE_CARRIED_FORWARD" in requirements and "TRANSACTIONAL_OR_COMMIT_MARKED_SELFTEST_TELEMETRY_PUBLICATION" not in requirements and "CONSUMER_REQUIRES_COMPLETION_PROOF_BEFORE_PARSE" not in requirements)
    adjudication = load(PACKAGE / "V25_DEFECT_ADJUDICATION.json")
    check("I011_ADJUDICATION_NOT_COLLAPSED", adjudication.get("S064_CORE_PREFLIGHT_EXCLUSIVELY_DERIVED_FROM_STALE_MOUNT_BINDING") == "NO")
    comparison = load(PACKAGE / "MOUNT_OUTPUT_BINDING_COMPONENT_COMPARISON.json")
    check("I012_COMPONENTS", len(comparison.get("components", [])) == 9 and len(comparison.get("stale_successor_specific_bindings", [])) == 1)
    contract26 = load(PACKAGE / "SUCCESSOR_V26_GOVERNANCE_BOUND_MOUNT_OUTPUT_IDENTITY_CONTRACT.json")
    check("I013_NO_VERSION_INFERENCE", contract26.get("selection_rule") == "EXACT_GOVERNANCE_SUCCESSOR_DECISION_NO_VERSION_INFERENCE" and "VERSION_NUMBER_ARITHMETIC" in contract26.get("prohibited", []))
    matrix = load(PACKAGE / "V25_FAILURE_AND_V26_REGRESSION_MATRIX.json")
    check("I014_REGRESSION_SET", {row["id"] for row in matrix.get("required_cases", [])} == {"V26_RUNNER_WITH_V23_MOUNT_BINDING","V26_RUNNER_WITH_V25_STALE_BINDING","VERSION_NUMBER_DERIVED_OUTPUT_PATH","RUNNER_PREFLIGHT_PATH_MISMATCH","PREFLIGHT_STATIC_LOCK_MISMATCH","CORRECT_HOST_WRONG_NAMESPACE_DESTINATION","STALE_HARDCODED_PATH_IN_CONTRACT_SCHEMA_OR_VALIDATOR","EXACT_GOVERNANCE_BOUND_SUCCESSOR_MOUNT_OUTPUT_BINDING"})
    decision = load(PACKAGE / "V25_TERMINAL_AND_V26_SUCCESSOR_DECISION.json")
    check("I015_DECISION", decision.get("decision") == "TERMINALIZE_V25_AND_AUTHORIZE_DISTINCT_V26_CONDITIONALLY")
    check("I016_NO_V26", not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v26-20261101").exists())
    failures=[r["id"] for r in checks if r["status"]!="PASS"]
    result={"record_type":"INDEPENDENT_GOVERNANCE_VALIDATION_RESULT","governance_identity":GOVERNANCE_ID,"checks":checks,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failures),"failed":len(failures)},"failure_ids":failures,"status":"PASS" if not failures else "FAIL_CLOSED"}
    write_json_once(PACKAGE/"INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",result)
    print(f"INDEPENDENT_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failures)}/{len(checks)}")
    if failures: raise SystemExit(1)


if __name__ == "__main__": main()
