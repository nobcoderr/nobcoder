#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    manifest=load_json(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json"); lock=load_json(PACKAGE/"GOVERNANCE_LOCK.json")
    checks=[]
    def check(identity,condition,evidence=None): checks.append({"id":identity,"status":"PASS" if condition else "FAIL","evidence":evidence})
    listed=[]
    for item in manifest["members"]:
        path=PACKAGE/item["path"];listed.append(path)
        check(f"F_MEMBER_{item['path']}",path.is_file() and not path.is_symlink() and sha256_file(path)==item["sha256"] and path.stat().st_size==item["bytes"] and is_read_only(path))
    check("F001_COUNT",len(listed)==manifest["member_count"])
    check("F002_ROOT",package_root(listed)==manifest["canonical_root_sha256"])
    check("F003_LOCK_BINDING",lock.get("manifest_sha256")==sha256_file(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json") and lock.get("canonical_root_sha256")==manifest["canonical_root_sha256"])
    check("F004_STATUS",lock.get("status")=="PASS_LOCKED_GOVERNANCE_ONLY" and lock.get("decision")==DECISION)
    check("F005_LOCK_READ_ONLY",is_read_only(PACKAGE/"GOVERNANCE_LOCK.json") and is_read_only(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json"))
    try: assert_v25_frozen(); v25_ok=True
    except Exception as exc: v25_ok=False
    check("F006_V25_UNCHANGED",v25_ok)
    try: assert_v24_authority(); authority_ok=True
    except Exception as exc: authority_ok=False
    check("F007_AUTHORITY_UNCHANGED",authority_ok)
    check("F008_NO_V25_EXECUTION",not (V25/"STATIC_EXECUTION_LOCK.json").exists() and not (V25/"static-run-v25/ATTEMPT_MARKER.json").exists())
    check("F009_V26_ABSENT",not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v26-20261101").exists())
    check("F010_VALIDATIONS",all(load_json(PACKAGE/name).get("status")=="PASS" for name in VALIDATION_FILES))
    check("F011_READ_ONLY",load_json(PACKAGE/"READ_ONLY_INTEGRITY_RESULT_RUN-0001.json").get("status")=="PASS")
    adjudication=load_json(PACKAGE/"V25_DEFECT_ADJUDICATION.json")
    check("F012_ADJUDICATION",adjudication.get("STALE_SUCCESSOR_MOUNT_OUTPUT_PATH_BINDING_DEFECT")=="YES" and adjudication.get("MOUNT_CONTRACT_SUCCESSOR_IDENTITY_PROPAGATION_DEFECT")=="YES" and adjudication.get("S064_CORE_PREFLIGHT_EXCLUSIVELY_DERIVED_FROM_STALE_MOUNT_BINDING")=="NO")
    failures=[r["id"] for r in checks if r["status"]!="PASS"]
    result={"record_type":"FINAL_GOVERNANCE_FREEZE_VERIFICATION","governance_identity":GOVERNANCE_ID,"checks":checks,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failures),"failed":len(failures)},"failure_ids":failures,"status":"PASS" if not failures else "FAIL_CLOSED","governance_lock_sha256":sha256_file(PACKAGE/"GOVERNANCE_LOCK.json")}
    write_json_once(PACKAGE/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",result);set_read_only(PACKAGE/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json");os.chmod(PACKAGE,0o555)
    print(f"FINAL_FREEZE_VERIFICATION={result['status']} {len(checks)-len(failures)}/{len(checks)} LOCK_SHA256={result['governance_lock_sha256']}")
    if failures: raise SystemExit(1)


if __name__=="__main__": main()
