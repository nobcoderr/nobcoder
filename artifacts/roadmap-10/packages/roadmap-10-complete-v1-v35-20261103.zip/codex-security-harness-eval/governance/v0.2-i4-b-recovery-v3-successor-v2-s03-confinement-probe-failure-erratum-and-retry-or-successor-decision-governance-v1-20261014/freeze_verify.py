#!/usr/bin/env python3
"""Read-only post-freeze verifier for the S03 governance artifact tree."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OLD = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v2-20261014")
NEW = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014")


def sha(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        while data := stream.read(131072):
            result.update(data)
    return result.hexdigest()


def canonical_root(files: list[dict]) -> str:
    ledger = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(files, key=lambda row: row["path"]))
    return hashlib.sha256(ledger.encode("utf-8")).hexdigest()


def main() -> None:
    checks = []
    def add(name: str, value: bool) -> None:
        checks.append({"id": f"F{len(checks) + 1:02d}", "name": name, "pass": bool(value)})

    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    lock_path = ROOT / "GOVERNANCE_LOCK.json"
    add("manifest exists", manifest_path.is_file())
    add("lock exists", lock_path.is_file())
    if manifest_path.is_file() and lock_path.is_file():
        manifest = json.loads(manifest_path.read_text())
        lock = json.loads(lock_path.read_text())
        members = manifest["artifacts"]
        add("manifest count", manifest["artifact_count"] == len(members))
        expected_names = sorted(path.name for path in ROOT.iterdir() if path.is_file() and not path.is_symlink() and path.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"})
        add("manifest complete", sorted(row["path"] for row in members) == expected_names)
        add("member hashes", all((ROOT / row["path"]).is_file() and sha(ROOT / row["path"]) == row["sha256"] for row in members))
        add("manifest digest bound", sha(manifest_path) == lock["governance_manifest_sha256"])
        root_rows = members + [{"path": manifest_path.name, "sha256": sha(manifest_path)}]
        add("canonical root", canonical_root(root_rows) == lock["canonical_artifact_root_sha256"])
        add("lock status", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
        add("terminal evidence bound", lock["terminal_failure_sha256"] == "e333253db68e43aca1d0d081b3951cc8c6653697a45e3dff1148de0c8728d411" and lock["terminal_strace_sha256"] == "1ff0c37e16bce2529d28e15786b5d2db7428343dd8b4a389761eb54de25d39e5")
    else:
        manifest = {"artifacts": []}
        lock = {}

    regular = [path for path in ROOT.iterdir() if path.is_file() and not path.is_symlink()]
    add("no symlinks", not any(path.is_symlink() for path in ROOT.iterdir()))
    add("all files readonly", bool(regular) and all(stat.S_IMODE(path.stat().st_mode) & 0o222 == 0 for path in regular))
    add("governance directory readonly", stat.S_IMODE(ROOT.stat().st_mode) & 0o222 == 0)
    add("new successor absent", not NEW.exists() and not NEW.is_symlink())
    add("failure digest preserved", sha(OLD / "artifacts/test-results/CONFINEMENT_PROBE_TERMINAL_FAILURE.json") == "e333253db68e43aca1d0d081b3951cc8c6653697a45e3dff1148de0c8728d411")
    add("trace digest preserved", sha(OLD / "artifacts/logs/probe.strace.4") == "1ff0c37e16bce2529d28e15786b5d2db7428343dd8b4a389761eb54de25d39e5")
    add("old probe preserved", sha(OLD / "tooling/inert-confinement-probe.py") == "2644dfc8eccc9b69b7198cad8f3c05dd784ccb3c863d8dd2c63053ff544e00c8")
    add("old runner preserved", sha(OLD / "tooling/run-confined-dotnet.sh") == "9d33f03ea1e6fef7611a2c32f4cca1a53a10591ba9feebb0c3e94c7a1a9a663b")
    add("old verifier preserved", sha(OLD / "tooling/verify-write-confinement.py") == "ec5fe86e57d86c1ef2db75d30e89af3bd59e1e887fbb7718d7ba0e1dc93e6cd9")
    add("old file count preserved", len([p for p in OLD.rglob("*") if p.is_file() and not p.is_symlink()]) == 5)
    failures = [row["id"] for row in checks if not row["pass"]]
    print(json.dumps({
        "identity": "V0.2_I4_B_RECOVERY_V3_S03_ERRATUM_FREEZE_VERIFICATION_V1",
        "status": "PASS" if not failures else "FAIL",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failures), "checks_failed": len(failures),
        "failed_ids": failures, "checks": checks,
        "operational_actions": 0,
    }, indent=2, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
