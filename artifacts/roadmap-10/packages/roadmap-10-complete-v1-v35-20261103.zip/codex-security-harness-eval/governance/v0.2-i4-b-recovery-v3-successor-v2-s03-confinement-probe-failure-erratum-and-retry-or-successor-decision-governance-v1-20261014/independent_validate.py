#!/usr/bin/env python3
"""Independent, read-only validator for the S03 governance decision."""

from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent
HOME = Path("/home/nobcoder")
PREVIOUS = HOME / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v2-20261014"
NEXT = HOME / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014"
PREVIOUS_GOV = HOME / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-offline-implementation-toolchain-scope-violation-erratum-and-successor-decision-governance-v1-20261014"
SROOT = str(NEXT)


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(65536):
            value.update(chunk)
    return value.hexdigest()


def unescape(token: str) -> str:
    replacements = {"040": " ", "011": "\t", "012": "\n", "134": "\\"}
    return re.sub(r"\\([0-7]{3})", lambda match: replacements.get(match.group(1), match.group(0)), token)


def reject(code: str) -> tuple[str, str]:
    return "REJECT", code


def parse(lines: list[str]) -> tuple[list[dict] | None, tuple[str, str] | None]:
    if not lines:
        return None, reject("EMPTY_OR_TRUNCATED_MOUNTINFO")
    parsed = []
    for line in lines:
        sections = line.split(" - ")
        if len(sections) != 2:
            return None, reject("MALFORMED_MOUNTINFO_SEPARATOR")
        before, after = sections[0].split(), sections[1].split()
        if len(before) < 6 or len(after) < 3 or not before[0].isdigit() or not before[1].isdigit():
            return None, reject("MALFORMED_MOUNTINFO_SEPARATOR")
        parsed.append({
            "mid": int(before[0]), "pid": int(before[1]), "device": before[2],
            "root": unescape(before[3]), "target": unescape(before[4]),
            "mount_options": frozenset(before[5].split(",")), "optional": tuple(before[6:]),
            "type": after[0], "source": unescape(after[1]), "super_options": frozenset(after[2].split(",")),
        })
    ids = [entry["mid"] for entry in parsed]
    if len(set(ids)) != len(ids):
        return None, reject("DUPLICATE_MOUNT_ID")
    table = {entry["mid"]: entry for entry in parsed}
    for entry in parsed:
        if entry["pid"] != entry["mid"] and entry["pid"] not in table:
            return None, reject("BROKEN_PARENT_RELATIONSHIP")
        visited = set()
        walk = entry
        while walk["pid"] != walk["mid"] and walk["pid"] in table:
            if walk["mid"] in visited:
                return None, reject("UNRESOLVABLE_STACK_GRAPH")
            visited.add(walk["mid"])
            walk = table[walk["pid"]]
    return parsed, None


def top_for(records: list[dict], target: str) -> tuple[dict | None, list[dict], tuple[str, str] | None]:
    members = [item for item in records if item["target"] == target]
    if not members:
        return None, members, reject("UNRESOLVABLE_STACK_GRAPH")
    hidden_ids = {item["pid"] for item in members if item["pid"] != item["mid"]}
    visible = [item for item in members if item["mid"] not in hidden_ids]
    if len(visible) != 1:
        code = "UNRESOLVABLE_STACK_GRAPH" if len(members) > 2 else "AMBIGUOUS_EFFECTIVE_MOUNT"
        return None, members, reject(code)
    index = {item["mid"]: item for item in members}
    covered = set()
    cursor = visible[0]
    while True:
        if cursor["mid"] in covered:
            return None, members, reject("UNRESOLVABLE_STACK_GRAPH")
        covered.add(cursor["mid"])
        if cursor["pid"] == cursor["mid"] or cursor["pid"] not in index:
            break
        cursor = index[cursor["pid"]]
    if covered != set(index):
        return None, members, reject("UNRESOLVABLE_STACK_GRAPH")
    return visible[0], members, None


def ancestor(candidate: str, descendant: str) -> bool:
    return candidate == "/" or descendant == candidate or descendant.startswith(candidate.rstrip("/") + "/")


def assess(case: dict) -> tuple[str, str | None]:
    if not case["namespace_matches"]:
        return reject("NAMESPACE_PROVENANCE_MISMATCH")
    records, error = parse(case["mountinfo_lines"])
    if error:
        return error
    assert records is not None
    selected = {}
    stacks = {}
    for target in ("/", SROOT, "/tmp", "/var/tmp"):
        top, members, error = top_for(records, target)
        if error:
            return error
        selected[target], stacks[target] = top, members
    if "ro" not in selected["/"]["mount_options"] or "rw" in selected["/"]["mount_options"]:
        return reject("ROOT_NOT_READ_ONLY")
    if "rw" not in selected[SROOT]["mount_options"]:
        return reject("SUCCESSOR_NOT_WRITABLE")
    for lower in stacks["/tmp"]:
        if lower["mid"] != selected["/tmp"]["mid"] and "rw" in lower["mount_options"]:
            return reject("SHADOWED_UNAUTHORIZED_RW_MOUNT")
    expected_roots = {"/tmp": SROOT + "/.sandbox/tmp", "/var/tmp": SROOT + "/.sandbox/var-tmp"}
    for target in ("/tmp", "/var/tmp"):
        item, backing = selected[target], selected[SROOT]
        if item["type"] != backing["type"]:
            return reject("TMP_BACKING_TYPE_MISMATCH")
        if item["device"] != backing["device"] or item["source"] != backing["source"]:
            return reject("WRONG_TMP_BACKING" if target == "/tmp" else "WRONG_VAR_TMP_BACKING")
        if item["root"] != expected_roots[target]:
            return reject("TMP_SOURCE_ROOT_MISMATCH")
        if "rw" not in item["mount_options"]:
            return reject("TMP_NOT_WRITABLE")
    if any(item["target"].startswith("/tmp/") or item["target"].startswith("/var/tmp/") for item in records):
        return reject("UNEXPECTED_TMP_SUBMOUNT")

    grouped = defaultdict(list)
    for item in records:
        grouped[item["target"]].append(item)
    for target, members in grouped.items():
        if len(members) < 2:
            continue
        visible, _, error = top_for(records, target)
        if error:
            return error
        if any(item["mid"] != visible["mid"] and "rw" in item["mount_options"] for item in members) and ancestor(target, SROOT):
            return reject("SHADOWED_UNAUTHORIZED_RW_ANCESTOR")

    ephemeral = {("/run", "tmpfs"), ("/proc", "proc"), ("/dev", "tmpfs"), ("/dev", "devtmpfs")}
    for item in records:
        if "rw" not in item["mount_options"]:
            continue
        target = item["target"]
        if target == SROOT or target.startswith(SROOT + "/") or target in {"/tmp", "/var/tmp"}:
            continue
        if (target, item["type"]) in ephemeral:
            continue
        return reject("UNAUTHORIZED_RW_ANCESTOR" if ancestor(target, SROOT) else "UNAUTHORIZED_RW_BIND")
    return "PASS", None


def check(name: str, condition: bool, checks: list[dict]) -> None:
    checks.append({"id": f"I{len(checks) + 1:03d}", "name": name, "pass": bool(condition)})


def main() -> None:
    checks: list[dict] = []
    fixed = {
        PREVIOUS_GOV / "GOVERNANCE_LOCK.json": "c3afb5afb99e764a95e2aaab59b7b8c605e708423e59ad1626cdc23ca9793494",
        PREVIOUS_GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json": "34af19b27dc6201f6d81d8a8202d5e15b8eca80b3b6ba632664094bfdb8a6ce2",
        PREVIOUS / "artifacts/test-results/CONFINEMENT_PROBE_TERMINAL_FAILURE.json": "e333253db68e43aca1d0d081b3951cc8c6653697a45e3dff1148de0c8728d411",
        PREVIOUS / "artifacts/logs/probe.strace.4": "1ff0c37e16bce2529d28e15786b5d2db7428343dd8b4a389761eb54de25d39e5",
        PREVIOUS / "tooling/inert-confinement-probe.py": "2644dfc8eccc9b69b7198cad8f3c05dd784ccb3c863d8dd2c63053ff544e00c8",
        PREVIOUS / "tooling/run-confined-dotnet.sh": "9d33f03ea1e6fef7611a2c32f4cca1a53a10591ba9feebb0c3e94c7a1a9a663b",
        PREVIOUS / "tooling/verify-write-confinement.py": "ec5fe86e57d86c1ef2db75d30e89af3bd59e1e887fbb7718d7ba0e1dc93e6cd9",
    }
    for path, expected in fixed.items():
        check("immutable digest " + path.name, path.is_file() and sha256(path) == expected, checks)
    old_files = sorted(path for path in PREVIOUS.rglob("*") if path.is_file() and not path.is_symlink())
    check("terminal successor has exactly five regular files", len(old_files) == 5, checks)
    check("new successor remains absent", not NEXT.exists() and not NEXT.is_symlink(), checks)

    fixtures = json.loads((HERE / "SYNTHETIC_TOPOLOGY_CASES.json").read_text())
    check("fixture identity", fixtures["identity"] == "V0.2_I4_B_RECOVERY_V3_MOUNTINFO_SYNTHETIC_TOPOLOGY_CASES_V1", checks)
    check("fixture case count", len(fixtures["cases"]) == 22, checks)
    for case in fixtures["cases"]:
        actual, code = assess(case)
        check(f"{case['id']} outcome", actual == case["expected"], checks)
        check(f"{case['id']} classification", code == case["failure_classification"], checks)

    decision = json.loads((HERE / "RETRY_OR_SUCCESSOR_DECISION.json").read_text())
    binding = json.loads((HERE / "NEW_PROBE_IDENTITY_BINDING.json").read_text())
    terminal = json.loads((HERE / "S03_TERMINAL_DISPOSITION.json").read_text())
    root_cause = json.loads((HERE / "MOUNT_CARDINALITY_ROOT_CAUSE_REVIEW.json").read_text())
    capture = json.loads((HERE / "MOUNT_EVIDENCE_CAPTURE_CONTRACT.json").read_text())
    operations = json.loads((HERE / "OPERATION_AUTHORIZATION_MATRIX.json").read_text())
    guard_delta = json.loads((HERE / "FILESYSTEM_CONFINEMENT_GUARD_DELTA.json").read_text())
    negative = json.loads((HERE / "NEGATIVE_TEST_MATRIX.json").read_text())
    check("Option B selected", decision["selected_option"] == "B_DISTINCT_SUCCESSOR", checks)
    check("same-successor retry denied", decision["options"]["A_fresh_probe_same_successor"]["decision"] == "DENIED", checks)
    check("new path exact", decision["new_successor_root"] == SROOT == binding["successor"]["linux_root"], checks)
    check("identity reuse denied", binding["identity_reuse"] == "DENIED", checks)
    check("path reuse denied", binding["path_reuse"] == "DENIED", checks)
    check("automatic execution false", decision["automatic_execution"] is False and binding["automatic_execution"] is False, checks)
    check("S03 terminal", terminal["status"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_PATCH_NO_PROMOTION", checks)
    check("raw historical bytes not established", any("raw bytes" in item for item in terminal["not_established"]), checks)
    check("historical topology unresolved", root_cause["status"] == "CONFIRMED_ASSERTION_FAILURE_HISTORICAL_TOPOLOGY_UNRESOLVED", checks)
    check("confinement not established", root_cause["classifications"]["filesystem_confinement_verdict"] == "NOT_ESTABLISHED", checks)
    check("cardinality was not frozen invariant", root_cause["contract_analysis"]["requires_exactly_one_tmp_record"] is False, checks)
    check("raw capture precedes parser", capture["capture_order"].index("only then may the semantic parser run") > capture["capture_order"].index("child writes a capture-complete record and flushes/readbacks it"), checks)
    check("fresh evidence cannot replace history", "cannot reconstruct or replace" in capture["claim_boundary"], checks)
    check("full mountinfo escape repair required", any("all documented" in item for item in guard_delta["required_changes_from_terminal_v2"]), checks)
    check("effective graph repair required", any("graph-based" in item for item in guard_delta["required_changes_from_terminal_v2"]), checks)
    check("negative matrix count", len(negative["cases"]) == 26 and all(item["expected"] == "REJECT" for item in negative["cases"]), checks)
    check("operation matrix count", operations["operation_count"] == len(operations["operations"]) == 19, checks)
    check("no currently executable dotnet", operations["currently_executable_dotnet_operations"] == 0, checks)
    check("no currently executable Windows", operations["currently_executable_windows_operations"] == 0, checks)
    check("no currently executable recovery", operations["currently_executable_recovery_operations"] == 0, checks)
    op = {row["id"]: row["decision"] for row in operations["operations"]}
    check("probe replay denied", op["X01"] == "DENIED", checks)
    check("governance task execution denied", op["X03"] == "DENIED", checks)
    check("dotnet remains denied", op["X04"].startswith("DENIED"), checks)
    check("provisional freeze denied", op["X06"] == "DENIED", checks)
    check("historical cleanup denied", op["X07"] == "DENIED", checks)
    check("PFX content access denied", op["X08"] == "DENIED", checks)
    check("operational actions denied", op["X09"] == "DENIED", checks)

    failures = [row["id"] for row in checks if not row["pass"]]
    report = {
        "schema_version": 1,
        "identity": "V0.2_I4_B_RECOVERY_V3_S03_ERRATUM_INDEPENDENT_VALIDATION_RESULT_V1",
        "status": "PASS" if not failures else "FAIL",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failures),
        "checks_failed": len(failures),
        "failed_ids": failures,
        "checks": checks,
        "historical_mount_verdict": "UNRESOLVED_MISSING_RAW_MOUNTINFO",
        "successor_decision": "B_DISTINCT_SUCCESSOR",
        "confinement_claim": "NOT_ESTABLISHED",
        "executions": {"bubblewrap": 0, "strace": 0, "probe": 0, "negative_write": 0, "dotnet": 0, "nuget": 0, "windows": 0, "vboxmanage": 0, "recovery": 0},
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
