#!/usr/bin/env python3
"""Pure governance self-tests for the S03 erratum. No sandbox or product execution."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
OLD_GOV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-offline-implementation-toolchain-scope-violation-erratum-and-successor-decision-governance-v1-20261014"
OLD = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v2-20261014"
NEW = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014"
SUCCESSOR = str(NEW)
TMP_ROOT = SUCCESSOR + "/.sandbox/tmp"
VAR_TMP_ROOT = SUCCESSOR + "/.sandbox/var-tmp"

EXPECTED_HASHES = {
    OLD_GOV / "GOVERNANCE_LOCK.json": "c3afb5afb99e764a95e2aaab59b7b8c605e708423e59ad1626cdc23ca9793494",
    OLD_GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json": "34af19b27dc6201f6d81d8a8202d5e15b8eca80b3b6ba632664094bfdb8a6ce2",
    OLD / "artifacts/test-results/CONFINEMENT_PROBE_TERMINAL_FAILURE.json": "e333253db68e43aca1d0d081b3951cc8c6653697a45e3dff1148de0c8728d411",
    OLD / "artifacts/logs/probe.strace.4": "1ff0c37e16bce2529d28e15786b5d2db7428343dd8b4a389761eb54de25d39e5",
    OLD / "tooling/inert-confinement-probe.py": "2644dfc8eccc9b69b7198cad8f3c05dd784ccb3c863d8dd2c63053ff544e00c8",
    OLD / "tooling/run-confined-dotnet.sh": "9d33f03ea1e6fef7611a2c32f4cca1a53a10591ba9feebb0c3e94c7a1a9a663b",
    OLD / "tooling/verify-write-confinement.py": "ec5fe86e57d86c1ef2db75d30e89af3bd59e1e887fbb7718d7ba0e1dc93e6cd9",
}

ESCAPES = {"040": " ", "011": "\t", "012": "\n", "134": "\\"}


class Rejection(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(131072), b""):
            h.update(block)
    return h.hexdigest()


def decode_field(value: str) -> str:
    return re.sub(r"\\(040|011|012|134)", lambda m: ESCAPES[m.group(1)], value)


def parse_line(line: str) -> dict:
    if " - " not in line:
        raise Rejection("MALFORMED_MOUNTINFO_SEPARATOR")
    left, right = line.split(" - ", 1)
    a, b = left.split(), right.split()
    if len(a) < 6 or len(b) < 3:
        raise Rejection("MALFORMED_MOUNTINFO_SEPARATOR")
    try:
        mount_id, parent_id = int(a[0]), int(a[1])
    except ValueError as exc:
        raise Rejection("MALFORMED_MOUNTINFO_SEPARATOR") from exc
    return {
        "id": mount_id,
        "parent": parent_id,
        "dev": a[2],
        "root": decode_field(a[3]),
        "point": decode_field(a[4]),
        "options": set(a[5].split(",")),
        "optional": a[6:],
        "fstype": b[0],
        "source": decode_field(b[1]),
        "super": set(b[2].split(",")),
    }


def parse_snapshot(lines: list[str]) -> list[dict]:
    if not lines:
        raise Rejection("EMPTY_OR_TRUNCATED_MOUNTINFO")
    records = [parse_line(line) for line in lines]
    ids = [record["id"] for record in records]
    if len(ids) != len(set(ids)):
        raise Rejection("DUPLICATE_MOUNT_ID")
    by_id = {record["id"]: record for record in records}
    for record in records:
        if record["parent"] != record["id"] and record["parent"] not in by_id:
            raise Rejection("BROKEN_PARENT_RELATIONSHIP")
        seen: set[int] = set()
        current = record
        while current["parent"] != current["id"] and current["parent"] in by_id:
            if current["id"] in seen:
                raise Rejection("UNRESOLVABLE_STACK_GRAPH")
            seen.add(current["id"])
            current = by_id[current["parent"]]
    return records


def effective(records: list[dict], point: str) -> tuple[dict, list[dict]]:
    group = [record for record in records if record["point"] == point]
    if not group:
        raise Rejection("UNRESOLVABLE_STACK_GRAPH")
    parent_ids = {record["parent"] for record in group if record["parent"] != record["id"]}
    tops = [record for record in group if record["id"] not in parent_ids]
    if len(tops) != 1:
        if len(group) > 2:
            raise Rejection("UNRESOLVABLE_STACK_GRAPH")
        raise Rejection("AMBIGUOUS_EFFECTIVE_MOUNT")
    top = tops[0]
    reached = {top["id"]}
    cursor = top
    group_ids = {record["id"] for record in group}
    by_id = {record["id"]: record for record in group}
    while cursor["parent"] != cursor["id"] and cursor["parent"] in group_ids:
        cursor = by_id[cursor["parent"]]
        if cursor["id"] in reached:
            raise Rejection("UNRESOLVABLE_STACK_GRAPH")
        reached.add(cursor["id"])
    if reached != group_ids:
        raise Rejection("UNRESOLVABLE_STACK_GRAPH")
    return top, group


def is_ancestor(candidate: str, path: str) -> bool:
    return candidate == "/" or path == candidate or path.startswith(candidate.rstrip("/") + "/")


def verify_topology(lines: list[str], namespace_matches: bool) -> tuple[str, str | None]:
    try:
        if not namespace_matches:
            raise Rejection("NAMESPACE_PROVENANCE_MISMATCH")
        records = parse_snapshot(lines)
        root, _ = effective(records, "/")
        if "ro" not in root["options"] or "rw" in root["options"]:
            raise Rejection("ROOT_NOT_READ_ONLY")

        successor, _ = effective(records, SUCCESSOR)
        if "rw" not in successor["options"]:
            raise Rejection("SUCCESSOR_NOT_WRITABLE")

        tmp, tmp_group = effective(records, "/tmp")
        var_tmp, _ = effective(records, "/var/tmp")

        for member in tmp_group:
            if member["id"] != tmp["id"] and "rw" in member["options"]:
                raise Rejection("SHADOWED_UNAUTHORIZED_RW_MOUNT")

        for point, record, expected_root in (
            ("/tmp", tmp, TMP_ROOT),
            ("/var/tmp", var_tmp, VAR_TMP_ROOT),
        ):
            if record["fstype"] != successor["fstype"]:
                raise Rejection("TMP_BACKING_TYPE_MISMATCH")
            if record["dev"] != successor["dev"] or record["source"] != successor["source"]:
                if point == "/tmp":
                    raise Rejection("WRONG_TMP_BACKING")
                raise Rejection("WRONG_VAR_TMP_BACKING")
            if record["root"] != expected_root:
                raise Rejection("TMP_SOURCE_ROOT_MISMATCH")
            if "rw" not in record["options"]:
                raise Rejection("TMP_NOT_WRITABLE")

        for record in records:
            point = record["point"]
            if point.startswith("/tmp/") or point.startswith("/var/tmp/"):
                raise Rejection("UNEXPECTED_TMP_SUBMOUNT")

        groups: dict[str, list[dict]] = {}
        for record in records:
            groups.setdefault(record["point"], []).append(record)
        for point, group in groups.items():
            if len(group) < 2:
                continue
            top, members = effective(records, point)
            for member in members:
                if member["id"] == top["id"] or "rw" not in member["options"]:
                    continue
                if is_ancestor(point, SUCCESSOR):
                    raise Rejection("SHADOWED_UNAUTHORIZED_RW_ANCESTOR")

        allowed_ephemeral = {"/run": {"tmpfs"}, "/proc": {"proc"}, "/dev": {"tmpfs", "devtmpfs"}}
        for record in records:
            if "rw" not in record["options"]:
                continue
            point = record["point"]
            if point == SUCCESSOR or point.startswith(SUCCESSOR + "/") or point in {"/tmp", "/var/tmp"}:
                continue
            if point in allowed_ephemeral and record["fstype"] in allowed_ephemeral[point]:
                continue
            if is_ancestor(point, SUCCESSOR):
                raise Rejection("UNAUTHORIZED_RW_ANCESTOR")
            raise Rejection("UNAUTHORIZED_RW_BIND")
        return "PASS", None
    except Rejection as exc:
        return "REJECT", exc.code


def governance_checks() -> list[dict]:
    checks: list[tuple[str, bool]] = []
    for path, expected in EXPECTED_HASHES.items():
        checks.append(("hash:" + path.name, path.is_file() and digest(path) == expected))
    retry = json.loads((ROOT / "RETRY_OR_SUCCESSOR_DECISION.json").read_text())
    terminal = json.loads((ROOT / "S03_TERMINAL_DISPOSITION.json").read_text())
    capture = json.loads((ROOT / "MOUNT_EVIDENCE_CAPTURE_CONTRACT.json").read_text())
    matrix = json.loads((ROOT / "OPERATION_AUTHORIZATION_MATRIX.json").read_text())
    root_cause = json.loads((ROOT / "MOUNT_CARDINALITY_ROOT_CAUSE_REVIEW.json").read_text())
    checks.extend([
        ("terminal_no_retry", terminal["retry"] == "DENIED_UNDER_TERMINAL_IDENTITY"),
        ("terminal_no_patch", terminal["source_patch"] == "DENIED_IN_TERMINAL_SUCCESSOR"),
        ("raw_historical_absent", "raw bytes" in terminal["not_established"][0]),
        ("option_b", retry["selected_option"] == "B_DISTINCT_SUCCESSOR"),
        ("new_root_exact", retry["new_successor_root"] == SUCCESSOR),
        ("new_root_absent", not NEW.exists() and not NEW.is_symlink()),
        ("historical_unresolved", retry["historical_mount_verdict"] == "UNRESOLVED_MISSING_RAW_MOUNTINFO"),
        ("capture_before_parse", capture["capture_order"].index("only then may the semantic parser run") > capture["capture_order"].index("child writes a capture-complete record and flushes/readbacks it")),
        ("no_overwrite", capture["no_overwrite"] is True),
        ("no_retry", capture["no_retry"] is True),
        ("cardinality_not_contract", root_cause["contract_analysis"]["requires_exactly_one_tmp_record"] is False),
        ("confinement_not_established", root_cause["classifications"]["filesystem_confinement_verdict"] == "NOT_ESTABLISHED"),
        ("dotnet_zero", matrix["currently_executable_dotnet_operations"] == 0),
        ("windows_zero", matrix["currently_executable_windows_operations"] == 0),
        ("recovery_zero", matrix["currently_executable_recovery_operations"] == 0),
        ("operation_count", matrix["operation_count"] == len(matrix["operations"])),
    ])
    return [{"id": f"G{index:02d}", "name": name, "pass": passed} for index, (name, passed) in enumerate(checks, 1)]


def negative_checks(topology_results: dict[str, tuple[str, str | None]]) -> list[dict]:
    matrix = json.loads((ROOT / "NEGATIVE_TEST_MATRIX.json").read_text())
    decision = json.loads((ROOT / "RETRY_OR_SUCCESSOR_DECISION.json").read_text())
    operation = json.loads((ROOT / "OPERATION_AUTHORIZATION_MATRIX.json").read_text())
    evidence = json.loads((ROOT / "MOUNT_EVIDENCE_CAPTURE_CONTRACT.json").read_text())
    op = {item["id"]: item["decision"] for item in operation["operations"]}
    proof = {
        "N01": topology_results["T03"][0] == "REJECT",
        "N02": topology_results["T02"][0] == "PASS",
        "N03": topology_results["T22"][0] == "PASS",
        "N04": topology_results["T09"][0] == "REJECT",
        "N05": topology_results["T21"][0] == "REJECT",
        "N06": topology_results["T18"][0] == "REJECT",
        "N07": "cannot reconstruct" in evidence["claim_boundary"],
        "N08": "runner source" in json.loads((ROOT / "NEW_PROBE_IDENTITY_BINDING.json").read_text())["required_new_digests"],
        "N09": op["X01"] == "DENIED",
        "N10": decision["options"]["A_fresh_probe_same_successor"]["decision"] == "DENIED",
        "N11": op["X04"].startswith("DENIED"),
        "N12": op["X06"] == "DENIED",
        "N13": op["X09"] == "DENIED",
        "N14": op["X07"] == "DENIED",
        "N15": op["X07"] == "DENIED",
        "N16": op["X06"] == "DENIED",
        "N17": any("NAMESPACE_FACTS" in x for x in evidence["required_outputs"]),
        "N18": op["X07"] == "DENIED",
        "N19": op["X08"] == "DENIED",
        "N20": topology_results["T06"][0] == "REJECT",
        "N21": "namespace" in json.dumps(json.loads((ROOT / "FILESYSTEM_CONFINEMENT_GUARD_DELTA.json").read_text())).lower(),
        "N22": "fresh probe namespace" in evidence["claim_boundary"],
        "N23": topology_results["T17"][0] == "REJECT",
        "N24": evidence["capture_order"].index("only then may the semantic parser run") > evidence["capture_order"].index("child writes a capture-complete record and flushes/readbacks it"),
        "N25": decision["selected_option"] == "B_DISTINCT_SUCCESSOR",
        "N26": decision["automatic_execution"] is False,
    }
    return [{"id": item["id"], "pass": bool(proof[item["id"]])} for item in matrix["cases"]]


def main() -> None:
    fixtures = json.loads((ROOT / "SYNTHETIC_TOPOLOGY_CASES.json").read_text())
    topology_checks = []
    outcomes: dict[str, tuple[str, str | None]] = {}
    for case in fixtures["cases"]:
        actual, classification = verify_topology(case["mountinfo_lines"], case["namespace_matches"])
        outcomes[case["id"]] = (actual, classification)
        passed = actual == case["expected"] and classification == case["failure_classification"]
        topology_checks.append({"id": case["id"], "expected": case["expected"], "actual": actual, "classification": classification, "pass": passed})
    gov = governance_checks()
    neg = negative_checks(outcomes)
    all_checks = topology_checks + gov + neg
    failed = [item["id"] for item in all_checks if not item["pass"]]
    report = {
        "schema_version": 1,
        "identity": "V0.2_I4_B_RECOVERY_V3_S03_ERRATUM_GOVERNANCE_SELF_TEST_RESULT_V1",
        "status": "PASS" if not failed else "FAIL",
        "topology_tests": {"passed": sum(x["pass"] for x in topology_checks), "total": len(topology_checks), "results": topology_checks},
        "governance_checks": {"passed": sum(x["pass"] for x in gov), "total": len(gov), "results": gov},
        "negative_tests": {"passed": sum(x["pass"] for x in neg), "total": len(neg), "results": neg},
        "total_passed": sum(x["pass"] for x in all_checks),
        "total_checks": len(all_checks),
        "failed_ids": failed,
        "executions": {"bubblewrap": 0, "strace": 0, "negative_write": 0, "dotnet": 0, "nuget": 0, "windows": 0, "vboxmanage": 0, "recovery": 0},
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
