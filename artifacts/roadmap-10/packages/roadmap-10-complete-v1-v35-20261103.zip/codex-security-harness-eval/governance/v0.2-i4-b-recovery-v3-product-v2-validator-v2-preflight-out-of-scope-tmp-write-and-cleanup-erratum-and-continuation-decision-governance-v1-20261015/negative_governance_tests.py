#!/usr/bin/env python3
"""Network-free negative governance fixtures for the incident decision."""

from __future__ import annotations

import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def write_json(name: str, value) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite: {name}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def decide(case: dict) -> str:
    if case.get("host_tmp_write"):
        return "REJECT"
    if case.get("cleanup_after_unexpected_write"):
        return "REJECT"
    if case.get("invented_deleted_digest") or case.get("reconstruct_deleted_bytes"):
        return "REJECT"
    if case.get("promote_old_attempt") or case.get("modify_product"):
        return "REJECT"
    if case.get("validator_before_preflight") or case.get("old_p1_rerun"):
        return "REJECT"
    if case.get("automatic_consumption") or case.get("authorize_p3") or case.get("authorize_p6"):
        return "REJECT"
    if case.get("create_v03") or case.get("host_temp_fallback") or case.get("external_pycache"):
        return "REJECT"
    if case.get("missing_independent_validation") or case.get("source_drift"):
        return "REJECT"
    if case.get("absence_proves_contents") or case.get("reuse_incident_path"):
        return "REJECT"
    if case.get("unsandboxed_static_run"):
        return "REJECT"
    if case.get("static_attempt_count", 0) != 0:
        return "REJECT"
    if case.get("valid_continuation"):
        return "ACCEPT"
    return "REJECT"


cases = [
    ("host_tmp_redirection", {"host_tmp_write": True}, "REJECT"),
    ("scratch_cleanup_excuse", {"cleanup_after_unexpected_write": True}, "REJECT"),
    ("invent_deleted_digest", {"invented_deleted_digest": True}, "REJECT"),
    ("reconstruct_deleted_bytes", {"reconstruct_deleted_bytes": True}, "REJECT"),
    ("promote_old_attempt", {"promote_old_attempt": True}, "REJECT"),
    ("modify_product", {"modify_product": True}, "REJECT"),
    ("validator_before_preflight", {"validator_before_preflight": True}, "REJECT"),
    ("rerun_old_p1", {"old_p1_rerun": True}, "REJECT"),
    ("automatic_consumption", {"automatic_consumption": True}, "REJECT"),
    ("authorize_p3", {"authorize_p3": True}, "REJECT"),
    ("authorize_p6", {"authorize_p6": True}, "REJECT"),
    ("create_v03", {"create_v03": True}, "REJECT"),
    ("host_temp_fallback", {"host_temp_fallback": True}, "REJECT"),
    ("external_pycache", {"external_pycache": True}, "REJECT"),
    ("missing_independent", {"missing_independent_validation": True}, "REJECT"),
    ("source_drift", {"source_drift": True}, "REJECT"),
    ("absence_as_content_proof", {"absence_proves_contents": True}, "REJECT"),
    ("reuse_incident_path", {"reuse_incident_path": True}, "REJECT"),
    ("cleanup_unexpected", {"cleanup_after_unexpected_write": True}, "REJECT"),
    ("unsandboxed_static", {"unsandboxed_static_run": True}, "REJECT"),
    ("consumed_identity", {"static_attempt_count": 1, "valid_continuation": True}, "REJECT"),
    ("valid_zero_attempt_continuation", {"static_attempt_count": 0, "valid_continuation": True}, "ACCEPT"),
]

results = []
for index, (name, case, expected) in enumerate(cases, 1):
    actual = decide(case)
    results.append({"id": f"N{index:03d}", "name": name, "expected": expected, "actual": actual, "pass": actual == expected})

result = {
    "schema_version": 1,
    "status": "PASS" if all(item["pass"] for item in results) else "FAIL_CLOSED",
    "tests_total": len(results),
    "tests_passed": sum(item["pass"] for item in results),
    "tests": results,
}
write_json("NEGATIVE_GOVERNANCE_TEST_RESULT.json", result)
print(json.dumps({"status": result["status"], "tests": f"{result['tests_passed']}/{result['tests_total']}"}, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
