#!/usr/bin/env python3
"""Issue the immutable manifest and governance-only continuation lock."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_VALIDATOR_V2_PREFLIGHT_OUT_OF_SCOPE_TMP_WRITE_AND_CLEANUP_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_V1"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


for name in ["PREFLIGHT_RESULT.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "GOVERNANCE_TEST_RESULT.json", "INDEPENDENT_VALIDATION_RESULT.json", "HISTORICAL_IMMUTABILITY_RESULT.json"]:
    if load(name)["status"] != "PASS":
        raise SystemExit(f"mandatory result not PASS: {name}")

if MANIFEST.exists() or LOCK.exists():
    raise SystemExit("manifest or lock already exists")

members = []
for path in sorted(ROOT.iterdir(), key=lambda item: item.name):
    if path.name in {MANIFEST.name, LOCK.name}:
        continue
    if path.is_symlink() or not path.is_file():
        raise SystemExit(f"non-regular governance member: {path.name}")
    members.append({"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path)})

manifest = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_COMPLETE_PENDING_FINAL_LOCK",
    "member_count": len(members),
    "files": members,
    "coverage": "Every regular governance artifact except this manifest and GOVERNANCE_LOCK.json; the lock is excluded to avoid circularity.",
}
MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
manifest_sha = sha(MANIFEST)
rows = b"".join(
    f"{item['sha256']}  {item['path']}\n".encode("utf-8")
    for item in sorted(members, key=lambda item: item["path"])
)
rows += f"{manifest_sha}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("utf-8")
canonical_root = hashlib.sha256(rows).hexdigest()

preflight = load("PREFLIGHT_RESULT.json")
negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
self_test = load("GOVERNANCE_TEST_RESULT.json")
independent = load("INDEPENDENT_VALIDATION_RESULT.json")
incident = load("OUT_OF_SCOPE_TMP_WRITE_AND_CLEANUP_RECORD.json")
availability = load("DELETED_SCRATCH_EVIDENCE_AVAILABILITY.json")
decision = load("CONTINUATION_OR_SUCCESSOR_DECISION.json")
contract = load("READ_ONLY_PREFLIGHT_CONTRACT.json")
eligibility = load("STATIC_VALIDATION_IDENTITY_ELIGIBILITY_DECISION.json")
matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
next_step = load("NEXT_LEGAL_MILESTONE.json")

lock = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_LOCKED_GOVERNANCE_ONLY",
    "disposition": "INCIDENT_CONFIRMED_TERMINAL_BYTES_UNAVAILABLE_CONTINUATION_REAUTHORIZED_EXISTING_PRODUCT_V2_STATIC_V2_CONDITIONAL_P3_V03_BLOCKED",
    "governance_manifest_sha256": manifest_sha,
    "canonical_artifact_root_sha256": canonical_root,
    "canonical_root_member_count": len(members) + 1,
    "canonical_root_algorithm": "SHA256 of member-path-sorted UTF-8 rows '<sha256>  <relative-path>\\n', followed by the GOVERNANCE_ARTIFACT_MANIFEST.json row; GOVERNANCE_LOCK.json excluded",
    "predecessor_governance_lock_sha256": "571b26baeeb26ed6a55dae64ad8aa6cd30f74992811cfe4b553260f08429474f",
    "predecessor_governance_manifest_sha256": "0101415de8d11ab73cf736a019a3da096153463b529f932c7ee9f0606204b945",
    "predecessor_canonical_root_sha256": "4310731028eef99beb895033030580bdd715c53d63d7c38f4052f28208852653",
    "canonical_preflight": f"{preflight['checks_passed']}_OF_{preflight['checks_total']}_PASS",
    "negative_governance_tests": f"{negative['tests_passed']}_OF_{negative['tests_total']}_PASS",
    "governance_self_tests": f"{self_test['checks_passed']}_OF_{self_test['checks_total']}_PASS",
    "independent_validation": f"{independent['checks_passed']}_OF_{independent['checks_total']}_PASS",
    "freeze_verification_expected": "34_OF_34_PASS",
    "incident_path": incident["path"],
    "incident_status": incident["status"],
    "incident_write_authorized": incident["write_authorized"],
    "incident_cleanup_authorized": incident["cleanup_authorized"],
    "incident_current_path_state": incident["current_path_state"],
    "incident_historical_sha256": availability["historical_sha256"],
    "incident_historical_size": availability["historical_size"],
    "incident_reconstruction": incident["reconstruction"],
    "old_engineering_attempt": "FAIL_CLOSED_TERMINAL_BEFORE_VALIDATOR_IMPLEMENTATION_NO_RETRY_NO_PROMOTION",
    "product_v2_identity": "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V3_OFFLINE_PRODUCT_IMPLEMENTATION_V4",
    "product_v2_root": "/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2",
    "product_v2_disposition": decision["decision"],
    "product_v2_existing_inventory": "24_OF_24_FILES_DIGEST_BOUND_UNCHANGED",
    "fresh_preflight_identity": contract["identity"],
    "fresh_preflight_host_tmp_policy": contract["host_tmp_policy"],
    "continuation_authorization_identity": eligibility["continuation_authorization_identity"],
    "validator_identity": eligibility["validator_identity"],
    "validator_path": eligibility["validator_path"],
    "validation_identity": eligibility["validation_identity"],
    "validation_operation": eligibility["operation_identity"],
    "validation_output_path": eligibility["writable_output_path"],
    "validation_status": eligibility["status"],
    "validation_attempt_count": eligibility["attempt_count"],
    "validation_maximum_attempts": eligibility["maximum_attempts"],
    "P3_V2": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE",
    "P6": "NOT_ELIGIBLE_NOT_AUTHORIZED",
    "V0_3": "DRAFT_NON_AUTHORITATIVE_NO_ARTIFACT_CREATION",
    "Recovery_V2": "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY",
    "execution_counts": matrix["execution_counts"],
    "next_legal_milestone": next_step["milestone"],
    "claim_boundary": "Governance-only incident adjudication. It does not reconstruct deleted scratch bytes, modify Product V2, implement validator V2, execute static validation, authorize P3/P6, create V0.3 artifacts, or authorize operational recovery.",
}
LOCK.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({
    "status": lock["status"],
    "member_count": len(members) + 1,
    "manifest_sha256": manifest_sha,
    "lock_sha256": sha(LOCK),
    "canonical_artifact_root_sha256": canonical_root,
}, indent=2))
