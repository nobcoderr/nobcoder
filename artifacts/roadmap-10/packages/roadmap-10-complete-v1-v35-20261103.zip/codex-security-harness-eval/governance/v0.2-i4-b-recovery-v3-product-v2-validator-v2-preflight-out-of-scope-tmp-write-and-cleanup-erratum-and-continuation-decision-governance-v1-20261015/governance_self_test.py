#!/usr/bin/env python3
"""Deterministic governance consistency checks."""

from __future__ import annotations

import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write_json(name: str, value) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite: {name}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


checks = []


def add(name: str, condition) -> None:
    checks.append({"id": f"G{len(checks) + 1:03d}", "name": name, "pass": bool(condition)})


pre = load("PREFLIGHT_RESULT.json")
incident = load("OUT_OF_SCOPE_TMP_WRITE_AND_CLEANUP_RECORD.json")
availability = load("DELETED_SCRATCH_EVIDENCE_AVAILABILITY.json")
terminal = load("PREFLIGHT_INCIDENT_TERMINAL_DISPOSITION.json")
root_cause = load("INCIDENT_ROOT_CAUSE_REVIEW.json")
product = load("PRODUCT_V2_IMMUTABILITY_REVIEW.json")
decision = load("CONTINUATION_OR_SUCCESSOR_DECISION.json")
contract = load("READ_ONLY_PREFLIGHT_CONTRACT.json")
delta = load("WRITE_BOUNDARY_CONTROL_DELTA.json")
eligibility = load("STATIC_VALIDATION_IDENTITY_ELIGIBILITY_DECISION.json")
matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
history = load("HISTORICAL_IMMUTABILITY_RESULT.json")
next_step = load("NEXT_LEGAL_MILESTONE.json")

add("preflight pass", pre["status"] == "PASS" and pre["checks_passed"] == pre["checks_total"])
add("incident confirmed", incident["status"] == "CONFIRMED_SCOPE_VIOLATION")
add("write unauthorized", incident["write_authorized"] is False)
add("cleanup unauthorized", incident["cleanup_authorized"] is False)
add("incident path exact", incident["path"] == "/tmp/codex-freeze-check.json")
add("incident currently absent", incident["current_path_state"] == "ABSENT")
add("no reconstruction", incident["reconstruction"] == "PROHIBITED")
add("bytes unavailable", availability["status"] == "HISTORICAL_BYTES_UNAVAILABLE")
add("digest unknown", availability["historical_sha256"] == "UNKNOWN_NOT_CAPTURED")
add("size unknown", availability["historical_size"] == "UNKNOWN_NOT_CAPTURED")
add("terminal preserved", terminal["status"] == "FAIL_CLOSED_TERMINAL_PRESERVED")
add("old engineering attempt terminal", terminal["old_engineering_attempt"].startswith("TERMINAL"))
add("static attempt zero", terminal["static_validation_V2_attempt_count"] == 0)
add("static identity unconsumed", terminal["static_validation_V2_consumed"] is False)
add("root cause confirmed", root_cause["status"] == "ROOT_CAUSE_CONFIRMED")
add("root cause excludes product", "Product V2 source" in root_cause["not_caused_by"])
add("Product V2 immutable", product["status"] == "PASS_PRODUCT_V2_UNCHANGED")
add("Product V2 inventory 24", product["inventory_count"] == 24)
add("validator absent", product["validator_v2"] == "ABSENT")
add("run absent", product["static_run_v2"] == "ABSENT")
add("lock absent", product["static_lock"] == "ABSENT")
add("continuation decision", decision["decision"] == "CONTINUE_EXISTING_PRODUCT_V2_WITH_FRESH_CONTINUATION_PREFLIGHT_AUTHORITY")
add("no new product successor", decision["new_product_successor_required"] is False)
add("old attempt no retry", decision["old_engineering_attempt"] == "TERMINAL_NO_RETRY")
add("incident path reuse prohibited", decision["historical_incident_path_reuse"] == "PROHIBITED")
add("preflight identity fresh", contract["identity"].endswith("CONTINUATION_PREFLIGHT_V2"))
add("host tmp denied", contract["host_tmp_policy"] == "NO_HOST_TMP_WRITE")
add("two allowed future roots", len(contract["allowed_persistent_write_roots_after_preflight"]) == 2)
add("control delta required", delta["status"] == "REQUIRED_FOR_CONTINUATION")
add("OS boundary required", delta["os_enforced_static_run_confinement_required"] is True)
add("env not boundary", delta["environment_variables_are_not_security_boundary"] is True)
add("eligibility conditional", eligibility["status"] == "CONDITIONAL_SINGLE_USE_REAUTHORIZED_NOT_EXECUTABLE_YET")
add("eligibility zero attempts", eligibility["attempt_count"] == 0)
add("eligibility max one", eligibility["maximum_attempts"] == 1)
add("not replay", eligibility["identity_replay"] is False)
add("validator path exact", eligibility["validator_path"].endswith("/product-v2/validator-v2"))
add("run path exact", eligibility["writable_output_path"].endswith("/product-v2/static-run-v2"))
add("operation exact", eligibility["operation_identity"] == "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V2")
add("matrix staged", matrix["status"] == "STAGED_FAIL_CLOSED_AUTHORIZATION")
add("operation counts zero", all(value == 0 for value in matrix["execution_counts"].values()))
add("P3 blocked", any(item["stage"] == "P3 V2" and item["decision"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE" for item in matrix["decisions"]))
add("P6 blocked", any(item["stage"] == "P6" and item["decision"] == "NOT_ELIGIBLE_NOT_AUTHORIZED" for item in matrix["decisions"]))
add("V0.3 blocked", any(item["stage"] == "V0.3" and item["decision"] == "DRAFT_NON_AUTHORITATIVE_NO_ARTIFACT_CREATION" for item in matrix["decisions"]))
add("negative suite pass", negative["status"] == "PASS" and negative["tests_passed"] == negative["tests_total"] == 22)
add("historical pass", history["status"] == "PASS" and history["historical_mutations"] == 0)
add("Recovery V2 unchanged", history["Recovery_V2"] == "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY")
add("next milestone exact", next_step["milestone"] == "IMPLEMENT_TEST_AND_STATICALLY_LOCK_RECOVERY_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2_THEN_EXECUTE_CONFINED_STATIC_VALIDATION_V2_ONCE_IF_ALL_GATES_PASS")
add("next milestone blocks V0.3", "V0.3 artifacts" in next_step["still_blocked"])

result = {
    "schema_version": 1,
    "status": "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED",
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "checks": checks,
}
write_json("GOVERNANCE_TEST_RESULT.json", result)
print(json.dumps({"status": result["status"], "checks": f"{result['checks_passed']}/{result['checks_total']}"}, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
