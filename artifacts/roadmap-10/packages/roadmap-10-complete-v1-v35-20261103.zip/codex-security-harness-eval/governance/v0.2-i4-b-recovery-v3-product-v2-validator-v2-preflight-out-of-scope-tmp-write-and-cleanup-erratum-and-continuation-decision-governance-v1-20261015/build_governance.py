#!/usr/bin/env python3
"""Build governance-only adjudication records for the host-/tmp preflight incident."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import stat
from datetime import datetime, timezone


ROOT = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path("/home/nobcoder")
PREV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v2-p1-exact-argv-cardinality-false-positive-erratum-and-continuation-or-successor-decision-governance-v1-20261015"
PRODUCT = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2"
TMP_INCIDENT = pathlib.Path("/tmp/codex-freeze-check.json")
VALIDATOR = PRODUCT / "validator-v2"
RUN = PRODUCT / "static-run-v2"
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_VALIDATOR_V2_PREFLIGHT_OUT_OF_SCOPE_TMP_WRITE_AND_CLEANUP_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_V1"
PREV_LOCK_SHA = "571b26baeeb26ed6a55dae64ad8aa6cd30f74992811cfe4b553260f08429474f"
PREV_MANIFEST_SHA = "0101415de8d11ab73cf736a019a3da096153463b529f932c7ee9f0606204b945"
PREV_ROOT_SHA = "4310731028eef99beb895033030580bdd715c53d63d7c38f4052f28208852653"
P1_SHA = "b66303ce5f908b55f48eae335e8b421a1b6b5bbcbc636b358a32f99d8d3d2b5d"
P1I_SHA = "52fbf8f92f3a3e4bb87dc3e50d194871e305d1e877a097fe5173343f9fe8fd30"


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_root(directory: pathlib.Path) -> str:
    manifest_path = directory / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest = load(manifest_path)
    rows = b"".join(
        f"{item['sha256']}  {item['path']}\n".encode("utf-8")
        for item in sorted(manifest["files"], key=lambda item: item["path"])
    )
    rows += f"{sha(manifest_path)}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("utf-8")
    return hashlib.sha256(rows).hexdigest()


def inventory(directory: pathlib.Path) -> list[dict]:
    return sorted(
        (
            {"path": path.relative_to(directory).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}
            for path in directory.rglob("*") if path.is_file()
        ),
        key=lambda item: item["path"],
    )


def write_json(name: str, value) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite governance artifact: {name}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    checks = []

    def check(name: str, condition, evidence=None) -> None:
        row = {"id": f"C{len(checks) + 1:03d}", "name": name, "pass": bool(condition)}
        if evidence is not None:
            row["evidence"] = evidence
        checks.append(row)

    prev_lock_path = PREV / "GOVERNANCE_LOCK.json"
    prev_manifest_path = PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    prev_lock = load(prev_lock_path)
    prev_manifest = load(prev_manifest_path)
    product_binding = load(PREV / "PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json")
    p1_path = PRODUCT / "prelock-results/PRE_EXECUTION_STATIC_VALIDATION_RESULT.json"
    p1i_path = PRODUCT / "prelock-results/PRE_EXECUTION_INDEPENDENT_STATIC_VALIDATION_RESULT.json"
    p1 = load(p1_path)
    p1i = load(p1i_path)
    fresh = load(PREV / "FRESH_VALIDATION_AUTHORIZATION_DECISION.json")
    exact_argv = load(PREV / "EXACT_ARGV_INTEGRITY_REVIEW.json")
    binds = load(PREV / "SEMANTIC_WRITABLE_BIND_INVENTORY.json")
    previous_members = sorted(item["path"] for item in prev_manifest["files"])
    actual_previous_members = sorted(
        path.name for path in PREV.iterdir()
        if path.is_file() and path.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    )
    current_product = inventory(PRODUCT)
    expected_product = sorted(product_binding["files"], key=lambda item: item["path"])

    check("predecessor lock digest", sha(prev_lock_path) == PREV_LOCK_SHA)
    check("predecessor manifest digest", sha(prev_manifest_path) == PREV_MANIFEST_SHA)
    check("predecessor canonical root", canonical_root(PREV) == prev_lock["canonical_artifact_root_sha256"] == PREV_ROOT_SHA)
    check("predecessor status", prev_lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("predecessor manifest coverage", previous_members == actual_previous_members)
    check("predecessor manifest count", prev_manifest["member_count"] == len(prev_manifest["files"]) == 25)
    check("predecessor member hashes", all((PREV / item["path"]).stat().st_size == item["bytes"] and sha(PREV / item["path"]) == item["sha256"] for item in prev_manifest["files"]))
    check("predecessor frozen files", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in PREV.iterdir() if path.is_file()))
    check("predecessor frozen directory", stat.S_IMODE(PREV.stat().st_mode) == 0o555)
    check("original P1 product digest", sha(p1_path) == P1_SHA)
    check("original P1 independent digest", sha(p1i_path) == P1I_SHA)
    check("original P1 product terminal", p1["status"] == "FAIL_CLOSED" and p1["checks_passed"] == 55 and p1["checks_total"] == 56)
    check("original P1 independent terminal", p1i["status"] == "FAIL_CLOSED" and p1i["checks_passed"] == 47 and p1i["checks_total"] == 48)
    check("Product V2 inventory exact", current_product == expected_product)
    check("Product V2 inventory count", len(current_product) == product_binding["inventory_count"] == 24)
    check("Product V2 files are regular", all(not path.is_symlink() for path in PRODUCT.rglob("*") if path.is_file()))
    check("old static-run V1 empty", not any(path.is_file() for path in (PRODUCT / "static-run-v1").rglob("*")))
    check("validator V2 absent", not os.path.lexists(VALIDATOR))
    check("static-run V2 absent", not os.path.lexists(RUN))
    check("Product V2 static lock absent", not os.path.lexists(PRODUCT / "STATIC_EXECUTION_LOCK.json"))
    check("incident scratch absent", not os.path.lexists(TMP_INCIDENT))
    check("incident bytes unavailable", not TMP_INCIDENT.exists())
    check("previous fresh validation attempt zero", fresh["attempt_count"] == 0)
    check("previous validation conditional only", fresh["status"] == "CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_EXECUTABLE_YET")
    check("validator identity exact", fresh["validator_identity"] == "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2")
    check("validation identity exact", fresh["validation_identity"] == "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V2")
    check("validation operation exact", fresh["operation_identity"] == "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V2")
    check("validator path exact", pathlib.Path(fresh["validator_path"]) == VALIDATOR)
    check("run path exact", pathlib.Path(fresh["writable_output_path"]) == RUN)
    check("argv digest preserved", exact_argv["canonical_argv_sha256"] == "6c91cfaec676e5910ecb3339d4d1e0361384f96cfa67855bd795faa91489439a")
    check("bind semantics preserved", binds["total_bind_operations"] == 3 and binds["primary_root_bind_operations"] == 1 and binds["nested_authorized_projection_operations"] == 2 and len(binds["distinct_persistent_backing_authority_roots"]) == 1)
    check("P3 V2 prohibited", prev_lock["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
    check("P6 prohibited", prev_lock["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
    check("Recovery V2 remains UNKNOWN", prev_lock["Recovery_V2"] == "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY")
    check("original S03 preserved", prev_lock["original_S03"] == "FAIL_CLOSED_NO_RETRY_SEPARATE_EVIDENCE_ADMISSIBLE")
    check("all predecessor execution counters zero", all(value == 0 for value in prev_lock["execution_counts"].values()))
    check("no conflicting governance lock", not (ROOT / "GOVERNANCE_LOCK.json").exists())
    check("governance output boundary exact", ROOT.parent == PREV.parent and ROOT.name.endswith("governance-v1-20261015"))
    check("no V0.3 authorization", prev_lock["claim_boundary"].endswith("authorize operational Recovery V3."))
    check("preflight all pass", all(row["pass"] for row in checks))

    if not all(row["pass"] for row in checks):
        print(json.dumps({"status": "FAIL_CLOSED", "failed": [row for row in checks if not row["pass"]]}, indent=2))
        return 1

    observed = datetime.now(timezone.utc).isoformat()
    write_json("PREFLIGHT_RESULT.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS",
        "checks_total": len(checks),
        "checks_passed": len(checks),
        "checks": checks,
        "observed_utc": observed,
        "write_boundary": str(ROOT),
    })
    write_json("ROUTING_AND_SCOPE_DECISION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS",
        "authorization": "GOVERNANCE_ONLY_INCIDENT_ADJUDICATION_AND_CONTINUATION_DECISION",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "agentic-security-research-harness", "codex-security-harness", "HARNESS_FALSIFICATION_METHOD", "STATE_MACHINE_SECURITY_METHOD"],
        "deferred": ["validator V2 implementation", "confined static validation V2", "V0.2 schema/execution freeze", "V0.3-A campaign contract"],
        "not_applicable": ["subagents", "parallel workers", "live target testing", "dotnet", "NuGet", "P3", "P6", "Windows", "VBoxManage", "Recovery V3"],
        "claim_boundary": "Governance-only; no Product V2 edits, validator creation, static-run, P3, V0.3 artifact, or operational action.",
    })
    write_json("PREFLIGHT_INCIDENT_TERMINAL_DISPOSITION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "FAIL_CLOSED_TERMINAL_PRESERVED",
        "incident": "OUT_OF_SCOPE_HOST_TMP_WRITE_FOLLOWED_BY_UNAUTHORIZED_CLEANUP",
        "historical_action": "The predecessor read-only preflight invocation redirected verifier stdout to /tmp/codex-freeze-check.json and subsequently unlinked that path.",
        "old_engineering_attempt": "TERMINAL_BEFORE_VALIDATOR_IMPLEMENTATION_NO_PROMOTION",
        "static_validation_V2_attempt_count": 0,
        "static_validation_V2_consumed": False,
        "original_P1": "FAIL_CLOSED_TERMINAL_NO_RERUN_NO_PROMOTION",
    })
    write_json("OUT_OF_SCOPE_TMP_WRITE_AND_CLEANUP_RECORD.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "CONFIRMED_SCOPE_VIOLATION",
        "path": str(TMP_INCIDENT),
        "write_mechanism": "host shell output redirection",
        "cleanup_mechanism": "unlink",
        "write_authorized": False,
        "cleanup_authorized": False,
        "source_of_incident_fact": "operator self-report and recorded command provenance in the controlling conversation",
        "current_path_state": "ABSENT",
        "reconstruction": "PROHIBITED",
    })
    write_json("DELETED_SCRATCH_EVIDENCE_AVAILABILITY.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "HISTORICAL_BYTES_UNAVAILABLE",
        "path": str(TMP_INCIDENT),
        "historical_sha256": "UNKNOWN_NOT_CAPTURED",
        "historical_size": "UNKNOWN_NOT_CAPTURED",
        "historical_exact_bytes": "UNAVAILABLE_AFTER_CLEANUP",
        "current_absence_verified": True,
        "limitations": [
            "No digest or byte count was recorded before unlink.",
            "Current absence cannot prove historical contents.",
            "No disk-forensic recovery or reconstruction is authorized.",
        ],
    })
    write_json("INCIDENT_ROOT_CAUSE_REVIEW.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "ROOT_CAUSE_CONFIRMED",
        "direct_cause": "A shell redirection persisted read-only verifier stdout to host /tmp despite an output scope limited to validator-v2 and static-run-v2.",
        "contributing_cause": "The preflight procedure lacked an explicit no-redirection/no-host-scratch assertion and then performed cleanup instead of preserving the unexpected state.",
        "not_caused_by": ["Product V2 source", "bubblewrap", "strace", ".NET", "NuGet", "static validation execution"],
        "falsifier": "Evidence that the path was an authorized bind or that no filesystem creation occurred; neither is present.",
    })
    write_json("PRODUCT_V2_IMMUTABILITY_REVIEW.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS_PRODUCT_V2_UNCHANGED",
        "product_root": str(PRODUCT),
        "inventory_count": len(current_product),
        "files": current_product,
        "validator_v2": "ABSENT",
        "static_run_v2": "ABSENT",
        "static_lock": "ABSENT",
        "static_validation_attempt_count": 0,
    })
    write_json("CONTINUATION_OR_SUCCESSOR_DECISION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS_DECISION_ISSUED",
        "decision": "CONTINUE_EXISTING_PRODUCT_V2_WITH_FRESH_CONTINUATION_PREFLIGHT_AUTHORITY",
        "new_product_successor_required": False,
        "basis": [
            "Product V2 inventory remains byte-identical.",
            "validator-v2 and static-run-v2 were never created.",
            "static validation V2 attempt count is zero.",
            "the incident originated in orchestration scratch handling rather than Product V2 source.",
        ],
        "old_engineering_attempt": "TERMINAL_NO_RETRY",
        "permitted_existing_paths": [str(VALIDATOR), str(RUN)],
        "historical_incident_path_reuse": "PROHIBITED",
    })
    write_json("READ_ONLY_PREFLIGHT_CONTRACT.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "MANDATORY",
        "identity": "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_VALIDATOR_V2_CONTINUATION_PREFLIGHT_V2",
        "requirements": [
            "All read-only verifier output goes directly to the controlling output channel.",
            "No shell redirection to host /tmp, /var/tmp, HOME, XDG, or any unapproved path.",
            "No temporary file, here-document backing file, Python bytecode, cache, or report outside the exact authorized roots.",
            "Any persistent evidence must have an explicit pre-authorized destination and collision check.",
            "Unexpected write or cleanup stops the milestone terminally.",
        ],
        "allowed_persistent_write_roots_after_preflight": [str(VALIDATOR), str(RUN)],
        "host_tmp_policy": "NO_HOST_TMP_WRITE",
    })
    write_json("WRITE_BOUNDARY_CONTROL_DELTA.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "REQUIRED_FOR_CONTINUATION",
        "controls": [
            "Preflight commands must be output-only and may not redirect to filesystem paths.",
            "Implementation writes are confined to validator-v2.",
            "Static validation writes are confined by bubblewrap to static-run-v2.",
            "Sandbox /tmp and /var/tmp must be backed beneath static-run-v2, never host /tmp.",
            "PYTHONDONTWRITEBYTECODE=1 and explicit cache paths are mandatory.",
            "Before and after snapshots must verify Product V2 historical inventory and absence of unauthorized new paths.",
            "No cleanup follows an unexpected write without separate governance.",
        ],
        "environment_variables_are_not_security_boundary": True,
        "os_enforced_static_run_confinement_required": True,
    })
    write_json("STATIC_VALIDATION_IDENTITY_ELIGIBILITY_DECISION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "CONDITIONAL_SINGLE_USE_REAUTHORIZED_NOT_EXECUTABLE_YET",
        "continuation_authorization_identity": "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2_CONTINUATION_V2",
        "validator_identity": fresh["validator_identity"],
        "validator_path": str(VALIDATOR),
        "validation_identity": fresh["validation_identity"],
        "operation_identity": fresh["operation_identity"],
        "writable_output_path": str(RUN),
        "attempt_count": 0,
        "maximum_attempts": 1,
        "identity_replay": False,
        "reason_not_replay": "The static validation identity was never launched or consumed; this governance re-establishes eligibility after terminating the separate orchestration preflight attempt.",
        "execution_preconditions": [
            "fresh continuation preflight V2 passes",
            "validator-v2 implemented only in its authorized path",
            "semantic fixtures and independent review pass",
            "exact future argv and source digests are statically locked",
            "runtime confinement gates pass before tests",
        ],
    })
    write_json("OPERATION_AUTHORIZATION_MATRIX.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "STAGED_FAIL_CLOSED_AUTHORIZATION",
        "decisions": [
            {"stage": "incident preflight", "decision": "TERMINAL_NO_RETRY_NO_RECONSTRUCTION"},
            {"stage": "Product V2 existing source", "decision": "READ_ONLY_PRESERVE"},
            {"stage": "fresh continuation preflight V2", "decision": "AUTHORIZED_OUTPUT_ONLY_NO_HOST_SCRATCH"},
            {"stage": "validator V2 implementation and inert tests", "decision": "AUTHORIZED_NEW_VALIDATOR_PATH_ONLY_AFTER_PREFLIGHT"},
            {"stage": "static validation V2", "decision": "CONDITIONAL_SINGLE_USE_NOT_EXECUTABLE_UNTIL_NEW_STATIC_LOCK"},
            {"stage": "P3 V2", "decision": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE"},
            {"stage": "P6", "decision": "NOT_ELIGIBLE_NOT_AUTHORIZED"},
            {"stage": "V0.3", "decision": "DRAFT_NON_AUTHORITATIVE_NO_ARTIFACT_CREATION"},
            {"stage": "operational recovery", "decision": "NOT_AUTHORIZED"},
        ],
        "execution_counts": {
            "validator_v2_implementation": 0,
            "static_run_v2": 0,
            "bubblewrap": 0,
            "strace": 0,
            "dotnet": 0,
            "nuget": 0,
            "P3": 0,
            "P6": 0,
            "windows": 0,
            "vboxmanage": 0,
            "recovery": 0,
            "V0_3_artifacts": 0,
        },
    })
    write_json("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "DEFINED",
        "required_cases": [
            "accept host /tmp redirection", "accept cleanup because file was scratch", "invent deleted file digest",
            "reconstruct deleted bytes", "promote old engineering attempt", "modify Product V2 source",
            "create validator before preflight", "run old P1 identity", "consume static identity automatically",
            "issue P3 authorization", "issue P6", "create V0.3 artifact", "allow host tempfile fallback",
            "allow Python bytecode outside scope", "ignore missing independent validation", "ignore source drift",
            "treat current absence as historical-content proof", "reuse incident path", "cleanup unexpected writes",
            "allow unsandboxed static validation", "accept same static identity when attempt count nonzero",
            "allow unchanged Product V2 continuation with zero static attempts and fresh governance",
        ],
    })
    write_json("HISTORICAL_IMMUTABILITY_RESULT.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS",
        "predecessor_governance": "UNCHANGED_AND_FROZEN",
        "Product_V2": "24_OF_24_FILES_MATCH_PREDECESSOR_BINDING",
        "Product_V1": "TERMINAL_UNCHANGED_BY_THIS_GOVERNANCE",
        "original_P1": "TERMINAL_UNCHANGED",
        "original_S03": "TERMINAL_WITH_SEPARATE_ADMISSIBILITY_UNCHANGED",
        "Recovery_V2": "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY",
        "historical_mutations": 0,
    })
    write_json("NEXT_LEGAL_MILESTONE.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "AUTHORIZED_NEXT",
        "milestone": "IMPLEMENT_TEST_AND_STATICALLY_LOCK_RECOVERY_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2_THEN_EXECUTE_CONFINED_STATIC_VALIDATION_V2_ONCE_IF_ALL_GATES_PASS",
        "scope": "Reuse the unchanged Product V2 source; create only validator-v2 and static-run-v2; use output-only host preflight; never write host /tmp; execute the static validation identity at most once after static lock.",
        "still_blocked": ["P3 V2", "P6", ".NET", "NuGet", "V0.3 artifacts", "Guard V3", "Recovery V3", "Windows", "VBoxManage", "VM provisioning", "I5"],
    })

    print(json.dumps({"status": "PASS", "preflight": f"{len(checks)}/{len(checks)}", "incident": "CONFIRMED", "continuation": "CONDITIONAL"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
