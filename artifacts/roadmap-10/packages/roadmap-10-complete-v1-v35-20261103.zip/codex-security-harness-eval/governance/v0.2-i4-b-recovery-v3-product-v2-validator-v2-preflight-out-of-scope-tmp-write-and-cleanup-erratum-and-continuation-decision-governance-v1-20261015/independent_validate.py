#!/usr/bin/env python3
"""Independent verifier using raw predecessor bytes and policy decisions."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
PREV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v2-p1-exact-argv-cardinality-false-positive-erratum-and-continuation-or-successor-decision-governance-v1-20261015"
PRODUCT = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(name: str, value) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite: {name}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


checks = []


def verify(name: str, condition) -> None:
    checks.append({"id": f"I{len(checks) + 1:03d}", "name": name, "pass": bool(condition)})


prev_lock = load(PREV / "GOVERNANCE_LOCK.json")
prev_manifest = load(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json")
binding = load(PREV / "PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json")
incident = load(ROOT / "OUT_OF_SCOPE_TMP_WRITE_AND_CLEANUP_RECORD.json")
availability = load(ROOT / "DELETED_SCRATCH_EVIDENCE_AVAILABILITY.json")
product = load(ROOT / "PRODUCT_V2_IMMUTABILITY_REVIEW.json")
decision = load(ROOT / "CONTINUATION_OR_SUCCESSOR_DECISION.json")
contract = load(ROOT / "READ_ONLY_PREFLIGHT_CONTRACT.json")
eligibility = load(ROOT / "STATIC_VALIDATION_IDENTITY_ELIGIBILITY_DECISION.json")
matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")
self_test = load(ROOT / "GOVERNANCE_TEST_RESULT.json")

verify("predecessor lock hash", sha(PREV / "GOVERNANCE_LOCK.json") == "571b26baeeb26ed6a55dae64ad8aa6cd30f74992811cfe4b553260f08429474f")
verify("predecessor manifest hash", sha(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "0101415de8d11ab73cf736a019a3da096153463b529f932c7ee9f0606204b945")
verify("predecessor locked", prev_lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
verify("predecessor manifest count", prev_manifest["member_count"] == 25)
verify("original P1 product", sha(PRODUCT / "prelock-results/PRE_EXECUTION_STATIC_VALIDATION_RESULT.json") == "b66303ce5f908b55f48eae335e8b421a1b6b5bbcbc636b358a32f99d8d3d2b5d")
verify("original P1 independent", sha(PRODUCT / "prelock-results/PRE_EXECUTION_INDEPENDENT_STATIC_VALIDATION_RESULT.json") == "52fbf8f92f3a3e4bb87dc3e50d194871e305d1e877a097fe5173343f9fe8fd30")
actual = sorted(
    (
        {"path": path.relative_to(PRODUCT).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}
        for path in PRODUCT.rglob("*") if path.is_file()
    ), key=lambda item: item["path"]
)
verify("Product V2 inventory exact", actual == sorted(binding["files"], key=lambda item: item["path"]))
verify("Product V2 count", len(actual) == 24)
verify("validator absent", not os.path.lexists(PRODUCT / "validator-v2"))
verify("run absent", not os.path.lexists(PRODUCT / "static-run-v2"))
verify("static lock absent", not os.path.lexists(PRODUCT / "STATIC_EXECUTION_LOCK.json"))
verify("incident path absent", not os.path.lexists("/tmp/codex-freeze-check.json"))
verify("incident write classified unauthorized", incident["write_authorized"] is False)
verify("incident cleanup classified unauthorized", incident["cleanup_authorized"] is False)
verify("incident source is admission", "operator self-report" in incident["source_of_incident_fact"])
verify("no invented digest", availability["historical_sha256"] == "UNKNOWN_NOT_CAPTURED")
verify("no invented size", availability["historical_size"] == "UNKNOWN_NOT_CAPTURED")
verify("recovery prohibited", incident["reconstruction"] == "PROHIBITED")
verify("Product evidence says unchanged", product["status"] == "PASS_PRODUCT_V2_UNCHANGED")
verify("continuation uses Product V2", decision["decision"] == "CONTINUE_EXISTING_PRODUCT_V2_WITH_FRESH_CONTINUATION_PREFLIGHT_AUTHORITY")
verify("no product successor", decision["new_product_successor_required"] is False)
verify("old attempt terminal", decision["old_engineering_attempt"] == "TERMINAL_NO_RETRY")
verify("host tmp policy exact", contract["host_tmp_policy"] == "NO_HOST_TMP_WRITE")
verify("only validator and run roots", contract["allowed_persistent_write_roots_after_preflight"] == [str(PRODUCT / "validator-v2"), str(PRODUCT / "static-run-v2")])
verify("continuation identity distinct", eligibility["continuation_authorization_identity"].endswith("CONTINUATION_V2"))
verify("static attempt zero", eligibility["attempt_count"] == 0)
verify("static max one", eligibility["maximum_attempts"] == 1)
verify("not replay", eligibility["identity_replay"] is False)
verify("static still gated", eligibility["status"] == "CONDITIONAL_SINGLE_USE_REAUTHORIZED_NOT_EXECUTABLE_YET")
verify("P3 blocked", any(item["stage"] == "P3 V2" and item["decision"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE" for item in matrix["decisions"]))
verify("P6 blocked", any(item["stage"] == "P6" and item["decision"] == "NOT_ELIGIBLE_NOT_AUTHORIZED" for item in matrix["decisions"]))
verify("V0.3 blocked", any(item["stage"] == "V0.3" and item["decision"] == "DRAFT_NON_AUTHORITATIVE_NO_ARTIFACT_CREATION" for item in matrix["decisions"]))
verify("operation counters zero", all(value == 0 for value in matrix["execution_counts"].values()))
verify("negative tests pass", negative["status"] == "PASS" and negative["tests_passed"] == 22)
verify("self tests pass", self_test["status"] == "PASS" and self_test["checks_passed"] == self_test["checks_total"])

result = {
    "schema_version": 1,
    "status": "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED",
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "checks": checks,
    "independence": "Raw predecessor bytes and current filesystem state were checked independently from the governance self-test predicates.",
}
write_json("INDEPENDENT_VALIDATION_RESULT.json", result)
print(json.dumps({"status": result["status"], "checks": f"{result['checks_passed']}/{result['checks_total']}"}, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
