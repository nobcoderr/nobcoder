#!/usr/bin/env python3
"""Read-only verifier for the final incident-governance freeze."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"
PREV = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v2-p1-exact-argv-cardinality-false-positive-erratum-and-continuation-or-successor-decision-governance-v1-20261015")
PRODUCT = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2")


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


checks = []


def add(name: str, condition) -> None:
    checks.append({"id": f"F{len(checks) + 1:02d}", "name": name, "pass": bool(condition)})


add("manifest regular", MANIFEST.is_file() and not MANIFEST.is_symlink())
add("lock regular", LOCK.is_file() and not LOCK.is_symlink())
manifest = load(MANIFEST)
lock = load(LOCK)
listed = sorted(item["path"] for item in manifest["files"])
actual = sorted(path.name for path in ROOT.iterdir() if path.is_file() and path.name not in {MANIFEST.name, LOCK.name})
add("manifest count", manifest["member_count"] == len(manifest["files"]))
add("manifest complete", listed == actual)
add("manifest unique", len(set(listed)) == len(listed))
add("members regular", all((ROOT / item["path"]).is_file() and not (ROOT / item["path"]).is_symlink() for item in manifest["files"]))
add("member bytes and hashes", all((ROOT / item["path"]).stat().st_size == item["bytes"] and sha(ROOT / item["path"]) == item["sha256"] for item in manifest["files"]))
add("manifest digest", sha(MANIFEST) == lock["governance_manifest_sha256"])
rows = b"".join(
    f"{item['sha256']}  {item['path']}\n".encode("utf-8")
    for item in sorted(manifest["files"], key=lambda item: item["path"])
)
rows += f"{sha(MANIFEST)}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("utf-8")
add("canonical root", hashlib.sha256(rows).hexdigest() == lock["canonical_artifact_root_sha256"])
add("canonical count", len(manifest["files"]) + 1 == lock["canonical_root_member_count"])
add("governance status", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
add("disposition exact", lock["disposition"] == "INCIDENT_CONFIRMED_TERMINAL_BYTES_UNAVAILABLE_CONTINUATION_REAUTHORIZED_EXISTING_PRODUCT_V2_STATIC_V2_CONDITIONAL_P3_V03_BLOCKED")
add("predecessor lock hash", sha(PREV / "GOVERNANCE_LOCK.json") == lock["predecessor_governance_lock_sha256"])
add("predecessor manifest hash", sha(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock["predecessor_governance_manifest_sha256"])
add("original P1 product hash", sha(PRODUCT / "prelock-results/PRE_EXECUTION_STATIC_VALIDATION_RESULT.json") == "b66303ce5f908b55f48eae335e8b421a1b6b5bbcbc636b358a32f99d8d3d2b5d")
add("original P1 independent hash", sha(PRODUCT / "prelock-results/PRE_EXECUTION_INDEPENDENT_STATIC_VALIDATION_RESULT.json") == "52fbf8f92f3a3e4bb87dc3e50d194871e305d1e877a097fe5173343f9fe8fd30")
add("incident path absent", not os.path.lexists("/tmp/codex-freeze-check.json"))
add("incident digest unknown", lock["incident_historical_sha256"] == "UNKNOWN_NOT_CAPTURED")
add("incident cleanup unauthorized", lock["incident_cleanup_authorized"] is False)
product_review = load(ROOT / "PRODUCT_V2_IMMUTABILITY_REVIEW.json")
add("Product V2 inventory count", product_review["inventory_count"] == 24)
current_inventory = sorted(
    (
        {"path": path.relative_to(PRODUCT).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}
        for path in PRODUCT.rglob("*") if path.is_file()
    ), key=lambda item: item["path"]
)
add("Product V2 inventory unchanged", current_inventory == product_review["files"])
add("validator V2 absent", not os.path.lexists(PRODUCT / "validator-v2"))
add("static-run V2 absent", not os.path.lexists(PRODUCT / "static-run-v2"))
add("static lock absent", not os.path.lexists(PRODUCT / "STATIC_EXECUTION_LOCK.json"))
add("static attempt zero", lock["validation_attempt_count"] == 0)
add("static validation conditional", lock["validation_status"] == "CONDITIONAL_SINGLE_USE_REAUTHORIZED_NOT_EXECUTABLE_YET")
add("P3 blocked", lock["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
add("P6 blocked", lock["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
add("V0.3 blocked", lock["V0_3"] == "DRAFT_NON_AUTHORITATIVE_NO_ARTIFACT_CREATION")
add("operation counters zero", all(value == 0 for value in lock["execution_counts"].values()))
history = load(ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json")
add("historical mutation zero", history["historical_mutations"] == 0)
add("all governance files read-only", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()))
add("governance directory read-only", stat.S_IMODE(ROOT.stat().st_mode) == 0o555)
add("no governance symlinks", not any(path.is_symlink() for path in ROOT.iterdir()))

result = {
    "status": "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED",
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "failed_ids": [item["id"] for item in checks if not item["pass"]],
    "checks": checks,
}
print(json.dumps(result, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
