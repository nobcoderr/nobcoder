#!/usr/bin/env python3
"""Build the governance-only V2 bind-destination failure adjudication."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
V3 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v3-20261020")
V2_AUTH = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-v1-independent-validator-prompt-literal-normalization-failure-prelock-erratum-and-successor-decision-governance-v1-20261020")
WORKER_ACCEPT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-security-worker-runtime-v1-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261020")
CODEX_ACCEPT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v7-frozen-evidence-acceptance-and-codex-0-163-0-pass-locked-decision-governance-v1-20261020")
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")

IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_RUNTIME_BIND_DESTINATION_CONSTRUCTION_FAILURE_AND_INCOMPLETE_POST_VALIDATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V2_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2"
V3_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3_ONCE_IF_ALL_GATES_PASS"

HASHES = {
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
    "v2_tree_root": "f581655b70b77785d8b24c00b33af19ea8f24736f014bfe29ca2b36d4f1783be",
    "static_lock": "746fc4399107e1f13f04338135e01455b11b223991b6bbbc5bbb0dfd5fc86b1f",
    "static_manifest": "4b29b0077430116c2be22b5e4eebc3040b8c929a886c64fe4b4c4158282aeb07",
    "lock_verification": "5aaad7177679340a08e8f8e3f4ab9f6a266a0d98b2e3c3ddd41c88a6e3c8d05c",
    "attempt_marker": "0564e06c89ba291626c3bede7e2d6f55ede45bcd86e69bef65ef97b27f59ff19",
    "runtime_result": "4368d028a3da0bde2477be0198c60884da8e405439f8bc399ae7ed6ab7bfff5d",
    "stderr": "5edeca2d0f00194e982cea027e4c81549fd8bf1175c7e9269c0746ffea249b41",
    "trace_parent": "183de959f2544da6ae04411cfaa19d46d2e338e5ed8929d0fdf3e7b0fbea6d5f",
    "trace_child": "5e424d66ffc93c7b50e2d758765cc31071ea004ad2e5ceeb43844fbca29acbfa",
    "pre_attempt": "cafc1a33fa4081c1ad87ea9fd1e67f70bd3f5a49ac1f236d6faea523fbb6d904",
    "v2_authorization_lock": "7da72ec7a9f7d328a9127d90a0ecb129f31f13577293710f4e82f033aa1483f3",
    "v2_authorization_manifest": "2d271cf0873e5cd86d29ceda5336fb45d4529aeb5b5b278a1759a6aa2a92ef29",
    "worker_runtime_lock": "cc7928e67b9d5c74f04a750d8faae5bbdf97f2dd7fd4337885ddf10f85d6e8f7",
    "worker_runtime_manifest": "82aadd2c610409915cfc687ee9449eec4a9141b1aac99b654505a6b61db3dbad",
    "codex_lock": "3aedf0a656fd12680311f07fcf01e911e7a6a62f0b81871af347a55bc1ba7fef",
    "codex_manifest": "916f32ae710ee9a1721a151b4a1d0d16a05b268c2ef1ff2985e4235f4a64d1ae",
}

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
OPERATION_KEYS = [
    "worker_invocations", "codex_as_worker_invocations", "subagent_invocations",
    "credential_operations", "target_operations", "external_network_operations",
    "daybreak_invocations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def tree(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = [
        {"path": item.relative_to(path).as_posix(), "sha256": sha(item), "bytes": item.stat().st_size}
        for item in sorted(member for member in path.rglob("*") if member.is_file())
    ]
    return canonical_root(rows), rows


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_fixed_inputs() -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any], dict[str, Any]]:
    if sha(ROUTER_MAP) != HASHES["router_map"]:
        raise SystemExit("router map drift")
    for path, lock_key, manifest_key in [
        (V2_AUTH, "v2_authorization_lock", "v2_authorization_manifest"),
        (WORKER_ACCEPT, "worker_runtime_lock", "worker_runtime_manifest"),
        (CODEX_ACCEPT, "codex_lock", "codex_manifest"),
    ]:
        if sha(path / "GOVERNANCE_LOCK.json") != HASHES[lock_key]:
            raise SystemExit(f"predecessor lock drift: {path}")
        if sha(path / "GOVERNANCE_ARTIFACT_MANIFEST.json") != HASHES[manifest_key]:
            raise SystemExit(f"predecessor manifest drift: {path}")
    root, rows = tree(V2)
    if root != HASHES["v2_tree_root"] or len(rows) != 42:
        raise SystemExit(f"V2 tree drift: {root} members={len(rows)}")
    fixed = {
        "STATIC_EXECUTION_LOCK.json": "static_lock",
        "STATIC_SOURCE_MANIFEST.json": "static_manifest",
        "STATIC_EXECUTION_LOCK_VERIFICATION.json": "lock_verification",
        "static-run-v2/ATTEMPT_MARKER.json": "attempt_marker",
        "static-run-v2/runtime-result-0001.json": "runtime_result",
        "static-run-v2/stderr.txt": "stderr",
        "static-run-v2/trace.190880": "trace_parent",
        "static-run-v2/trace.190881": "trace_child",
        "static-run-v2/pre-attempt-gates-run-0001.json": "pre_attempt",
    }
    for relative, key in fixed.items():
        if sha(V2 / relative) != HASHES[key]:
            raise SystemExit(f"V2 evidence drift: {relative}")
    lock = load(V2 / "STATIC_EXECUTION_LOCK.json")
    marker = load(V2 / "static-run-v2/ATTEMPT_MARKER.json")
    runtime = load(V2 / "static-run-v2/runtime-result-0001.json")
    return rows, lock, marker, runtime


def routing_decisions() -> list[dict[str, str]]:
    routing = load(ROUTER_MAP)
    active_conditional = {"agentic-security-research-harness", "external-ai-security-tool-governor"}
    decisions = []
    for name, route in sorted(routing["skill_routes"].items()):
        if route.get("mode") == "always":
            state, reason = "ACTIVE", "MANDATORY_CORE_POLICY"
        elif name in active_conditional:
            state, reason = "ACTIVE", "LOCAL_WORKER_HARNESS_AND_EXTERNAL_CODEX_RUNTIME_GOVERNANCE"
        else:
            state, reason = "NOT_APPLICABLE", "GOVERNANCE_ONLY_NO_TARGET_DISCOVERY_OR_EXECUTION"
        decisions.append({"module": name, "state": state, "reason": reason})
    decisions.append({"module": "codex-security-harness", "state": "ACTIVE", "reason": "LOCAL_HARNESS_GOVERNANCE_IDENTITY"})
    return decisions


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != SCRIPTS or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    if V3.exists() or V3.is_symlink():
        raise SystemExit("V3 must not exist during governance adjudication")
    v2_rows, static_lock, marker, runtime = verify_fixed_inputs()
    trace = (V2 / "static-run-v2/trace.190881").read_text(encoding="utf-8", errors="replace")
    stderr = (V2 / "static-run-v2/stderr.txt").read_text(encoding="utf-8", errors="replace")

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0",
        "scope": "GOVERNANCE_ONLY_TERMINAL_V2_EVIDENCE_ADJUDICATION",
        "scope_evidence_card": {
            "asset": str(V2), "asset_kind": "LOCAL_TERMINAL_WORKER_INVOCATION_WORKSPACE",
            "allowed_mode": "READ_ONLY_EVIDENCE_ADJUDICATION_LOCAL_GOVERNANCE_VALIDATION_AND_FREEZE",
            "target": "NONE", "credential": "NONE", "network": "NONE",
            "codex_invocation": "NONE", "worker_or_subagent": "NONE", "candidate_or_finding": "NONE",
        },
        "authorized_actions": [
            "READ_TERMINAL_V2_EVIDENCE", "ADJUDICATE_BIND_DESTINATION_AND_VALIDATOR_DEFECT",
            "DEFINE_SUCCESSOR_FEASIBILITY_REQUIREMENTS", "ISSUE_CONDITIONAL_V3_DECISION",
            "RUN_LOCAL_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE",
        ],
        "forbidden_actions": [
            "PATCH_RELOCK_REVALIDATE_RETRY_OR_CONTINUE_V2", "CREATE_OR_EXECUTE_V3",
            "CODEX_WORKER_OR_SUBAGENT_INVOCATION", "CREDENTIAL_TARGET_OR_NETWORK_OPERATION",
            "DAYBREAK_INVOCATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH",
            "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION",
        ],
    })
    decisions = routing_decisions()
    write("ROUTING_LEDGER.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_ROUTING_LEDGER", "schema_version": "1.0",
        "router_map_sha256": HASHES["router_map"], "module_decisions": decisions,
        "active_count": sum(row["state"] == "ACTIVE" for row in decisions),
        "deferred_count": 0, "not_applicable_count": sum(row["state"] == "NOT_APPLICABLE" for row in decisions),
        "subagents_used": False, "codex_invoked_during_governance": False,
        "worker_invoked_during_governance": False, "network_used": False,
    })
    auth_lock = load(V2_AUTH / "GOVERNANCE_LOCK.json")
    worker_lock = load(WORKER_ACCEPT / "GOVERNANCE_LOCK.json")
    codex_lock = load(CODEX_ACCEPT / "GOVERNANCE_LOCK.json")
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_PREDECESSOR_CHAIN_BINDING", "schema_version": "1.0",
        "v2_successor_authorization": {
            "identity": auth_lock["governance_identity"], "status": auth_lock["status"],
            "decision": auth_lock["decision"], "lock_sha256": HASHES["v2_authorization_lock"],
            "manifest_sha256": HASHES["v2_authorization_manifest"],
            "canonical_root_sha256": auth_lock["canonical_artifact_root_sha256"],
        },
        "security_worker_runtime_v1": {
            "status": worker_lock["security_worker_runtime_v1"], "lock_sha256": HASHES["worker_runtime_lock"],
            "manifest_sha256": HASHES["worker_runtime_manifest"],
        },
        "codex_runtime": {
            "status": codex_lock["codex_runtime_0_163_0"], "lock_sha256": HASHES["codex_lock"],
            "manifest_sha256": HASHES["codex_manifest"],
        },
    })
    write("V2_TERMINAL_EVIDENCE_BINDING.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_TERMINAL_EVIDENCE_BINDING", "schema_version": "1.0",
        "execution_identity": V2_IDENTITY, "workspace": str(V2), "member_count": len(v2_rows),
        "canonical_tree_root_sha256": HASHES["v2_tree_root"], "members": v2_rows,
        "source_lock": {
            "canonical_source_root_sha256": static_lock["canonical_source_root_sha256"],
            "member_count": 32, "lock_sha256": HASHES["static_lock"],
            "manifest_sha256": HASHES["static_manifest"], "verification_sha256": HASHES["lock_verification"],
        },
        "runtime_evidence": {
            "attempt_marker_sha256": HASHES["attempt_marker"], "runtime_result_sha256": HASHES["runtime_result"],
            "stderr_sha256": HASHES["stderr"], "parent_trace_sha256": HASHES["trace_parent"],
            "child_trace_sha256": HASHES["trace_child"], "pre_attempt_gates_sha256": HASHES["pre_attempt"],
        },
        "evidence_freeze_status": "NOT_ISSUED", "binding_semantics": "GOVERNANCE_BINDS_OBSERVED_TERMINAL_BYTES_WITHOUT_RECLASSIFYING_THEM_AS_A_SUCCESSFUL_EVIDENCE_FREEZE",
        "content_mutation_during_governance": "PROHIBITED",
    })
    write("V2_TERMINAL_DISPOSITION.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "execution_identity": V2_IDENTITY, "disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY", "immutable": True,
        "attempt": "1_OF_1_CONSUMED", "worker_invocation_attempt": 1,
        "semantic_codex_execution": 0, "worker_result": "NOT_CREATED", "candidate": "NOT_CREATED",
        "runtime_result": "FAIL_CLOSED", "post_validation": "INCOMPLETE", "evidence_freeze": "NOT_ISSUED",
        "confinement": "NOT_PROVEN", "pass_locked": "NOT_ISSUED",
        "patch": "PROHIBITED", "relock": "PROHIBITED", "revalidation": "PROHIBITED",
        "retry": "PROHIBITED", "continuation": "PROHIBITED", "promotion": "PROHIBITED",
    })
    write("FAILURE_ROOT_CAUSE_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_ROOT_CAUSE_ADJUDICATION", "schema_version": "1.0",
        "root_cause": "RUNTIME_BIND_DESTINATION_CONSTRUCTION_DEFECT",
        "semantic_argv_validator_coverage_gap": "YES",
        "failure_stage": "BUBBLEWRAP_NAMESPACE_CONSTRUCTION_BEFORE_CODEX_EXECVE",
        "locked_destination": "/opt/codex-runtime-0.163.0",
        "causal_chain": [
            "ROOT_RO_BIND_APPLIED", "DESTINATION_ABSENT", "PARENT_OPT_NOT_WRITABLE",
            "BUBBLEWRAP_ATTEMPTED_DESTINATION_MKDIR", "MKDIR_RETURNED_EROFS", "LAUNCH_ABORTED_BEFORE_CODEX_EXECVE",
        ],
        "syscall_evidence": {
            "destination_absent": 'newfstatat(AT_FDCWD</>, "/newroot/opt/codex-runtime-0.163.0", ...) = -1 ENOENT',
            "creation_denied": 'mkdir("/newroot/opt/codex-runtime-0.163.0", 0755) = -1 EROFS',
            "stderr": stderr.strip(),
            "trace_contains_exact_enoent": '"/newroot/opt/codex-runtime-0.163.0"' in trace and "ENOENT" in trace,
            "trace_contains_exact_erofs": 'mkdir("/newroot/opt/codex-runtime-0.163.0", 0755) = -1 EROFS' in trace,
        },
        "actual_codex_execve_observed": False, "worker_behavior_observed": False,
    })
    write("DEFECT_OWNERSHIP_DECISION.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_DEFECT_OWNERSHIP_DECISION", "schema_version": "1.0",
        "security_worker_runtime_v1_defect": "NO", "prompt_normalization_defect": "NO",
        "runtime_bind_destination_construction_defect": "YES", "semantic_argv_validator_coverage_gap": "YES",
        "codex_runtime_compatibility_defect": "NOT_ESTABLISHED", "worker_behavior": "NOT_OBSERVED",
        "owned_by": ["WORKER_INVOCATION_V2_EXECUTION_TOPOLOGY", "WORKER_INVOCATION_V2_SEMANTIC_ARGV_VALIDATOR"],
        "not_owned_by": ["SECURITY_WORKER_RUNTIME_V1", "PROMPT_POLICY_NORMALIZATION", "CODEX_RUNTIME_0_163_0_BEHAVIOR", "WORKER_MODEL_BEHAVIOR"],
    })
    write("POST_VALIDATION_AND_CONFINEMENT_DECISION.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_POST_VALIDATION_AND_CONFINEMENT_DECISION", "schema_version": "1.0",
        "post_validation": "INCOMPLETE", "post_validation_result_artifact": "NOT_CREATED",
        "reason": "REQUIRED_LAST_MESSAGE_AND_CONTROLLER_RESULT_WERE_NOT_EMITTED_BECAUSE_CODEX_NEVER_EXECUTED",
        "evidence_freeze": "NOT_ISSUED", "confinement": "NOT_PROVEN", "compatibility": "NOT_AT_ISSUE_ALREADY_PASS_LOCKED_PREDECESSOR",
        "runtime_result_may_be_promoted_to_pass": False, "partial_prelaunch_evidence_is_historical_only": True,
    })
    write("BIND_DESTINATION_FEASIBILITY_CONTRACT.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_BIND_DESTINATION_FEASIBILITY_CONTRACT", "schema_version": "1.0",
        "gate": "BIND_DESTINATION_FEASIBILITY_PRECHECK", "timing": "BEFORE_ATTEMPT_MARKER",
        "semantic_model": {
            "source_operand": "MUST_EXIST_IN_CALLER_SOURCE_RESOLUTION_NAMESPACE_BEFORE_BIND",
            "destination_operand": "MUST_BE_EVALUATED_AT_ITS_ORDERED_POINT_IN_THE_EVOLVING_SANDBOX_TOPOLOGY",
            "existing_destination": "MUST_HAVE_EXPECTED_CANONICAL_PATH_AND_TYPE",
            "constructed_destination": "MUST_BE_CREATED_BY_AN_EARLIER_AUTHORIZED_OPERATION_UNDER_A_WRITABLE_TOPOLOGY_PROVIDER",
            "read_only_parent": "CANNOT_CREATE_MISSING_DESCENDANT",
        },
        "required_proofs": [
            "SEMANTIC_ARGV_PARSE_WITH_TYPED_OPERANDS", "ORDERED_TOPOLOGY_SIMULATION",
            "CANONICAL_DESTINATION_PATH", "DESTINATION_TYPE", "DESTINATION_EXISTS_BEFORE_BIND",
            "CREATION_OPERATION_PRECEDES_BIND_WHEN_CREATION_IS_REQUIRED", "CREATION_PARENT_WRITABLE_AT_OPERATION_POINT",
            "SOURCE_EXISTS_IN_CALLER_NAMESPACE", "EXACT_LOCKED_SOURCE_AND_DESTINATION",
        ],
        "prohibited_shortcuts": [
            "RAW_STRING_OCCURRENCE_COUNTING", "HARDCODED_ARGV_INDEX_ONLY", "HOST_PATH_EXISTS_ONLY",
            "BLIND_PATH_SUBSTITUTION", "POST_ATTEMPT_DISCOVERY_AS_PRECHECK", "GENERAL_ALLOWLIST_EXEMPTION",
        ],
        "failure_semantics": "STOP_FAIL_CLOSED_ATTEMPT_REMAINS_0_OF_1_WORKER_AND_CODEX_COUNTS_REMAIN_0",
    })
    regression_cases = [
        {
            "case_id": "R001_V2_EXACT_RO_ROOT_MISSING_DESTINATION", "expected": "FAIL_CLOSED",
            "preexisting": {"/": "directory", "/opt": "directory"}, "writable_roots": [],
            "operations": [
                {"op": "ro_root"},
                {"op": "dir", "destination": "/opt/codex-runtime-0.163.0"},
                {"op": "ro_bind", "source": "/host/codex-0.163.0", "source_namespace": "CALLER", "source_exists": True, "destination": "/opt/codex-runtime-0.163.0", "locked_destination": "/opt/codex-runtime-0.163.0"},
            ],
        },
        {
            "case_id": "R002_V3_WRITABLE_OVERLAY_THEN_DIR_THEN_BIND", "expected": "PASS",
            "preexisting": {"/": "directory", "/opt": "directory"}, "writable_roots": [],
            "operations": [
                {"op": "ro_root"}, {"op": "tmpfs", "destination": "/opt"},
                {"op": "dir", "destination": "/opt/codex-runtime-0.163.0"},
                {"op": "ro_bind", "source": "/host/codex-0.163.0", "source_namespace": "CALLER", "source_exists": True, "destination": "/opt/codex-runtime-0.163.0", "locked_destination": "/opt/codex-runtime-0.163.0"},
            ],
        },
        {
            "case_id": "R003_PREEXISTING_CANONICAL_DIRECTORY", "expected": "PASS",
            "preexisting": {"/": "directory", "/opt": "directory", "/opt/codex-runtime-0.163.0": "directory"}, "writable_roots": [],
            "operations": [
                {"op": "ro_root"},
                {"op": "ro_bind", "source": "/host/codex-0.163.0", "source_namespace": "CALLER", "source_exists": True, "destination": "/opt/codex-runtime-0.163.0", "locked_destination": "/opt/codex-runtime-0.163.0"},
            ],
        },
        {
            "case_id": "R004_MISSING_DESTINATION_UNDER_RO_PARENT", "expected": "FAIL_CLOSED",
            "preexisting": {"/": "directory", "/opt": "directory"}, "writable_roots": [],
            "operations": [{"op": "ro_root"}, {"op": "ro_bind", "source": "/host/codex-0.163.0", "source_namespace": "CALLER", "source_exists": True, "destination": "/opt/missing", "locked_destination": "/opt/missing"}],
        },
        {
            "case_id": "R005_DESTINATION_WRONG_TYPE", "expected": "FAIL_CLOSED",
            "preexisting": {"/": "directory", "/opt": "directory", "/opt/codex-runtime-0.163.0": "file"}, "writable_roots": [],
            "operations": [{"op": "ro_root"}, {"op": "ro_bind", "source": "/host/codex-0.163.0", "source_namespace": "CALLER", "source_exists": True, "destination": "/opt/codex-runtime-0.163.0", "locked_destination": "/opt/codex-runtime-0.163.0"}],
        },
        {
            "case_id": "R006_FUTURE_SANDBOX_PATH_USED_AS_SOURCE", "expected": "FAIL_CLOSED",
            "preexisting": {"/": "directory", "/opt": "directory", "/opt/codex-runtime-0.163.0": "directory"}, "writable_roots": [],
            "operations": [{"op": "ro_root"}, {"op": "ro_bind", "source": "/run/future/source", "source_namespace": "SANDBOX_FUTURE", "source_exists": False, "destination": "/opt/codex-runtime-0.163.0", "locked_destination": "/opt/codex-runtime-0.163.0"}],
        },
        {
            "case_id": "R007_NONCANONICAL_DESTINATION_ALIAS", "expected": "FAIL_CLOSED",
            "preexisting": {"/": "directory", "/opt": "directory", "/opt/codex-runtime-0.163.0": "directory"}, "writable_roots": [],
            "operations": [{"op": "ro_root"}, {"op": "ro_bind", "source": "/host/codex-0.163.0", "source_namespace": "CALLER", "source_exists": True, "destination": "/opt/../opt/codex-runtime-0.163.0", "locked_destination": "/opt/codex-runtime-0.163.0"}],
        },
        {
            "case_id": "R008_SOURCE_DESTINATION_SWAPPED", "expected": "FAIL_CLOSED",
            "preexisting": {"/": "directory", "/opt": "directory", "/opt/codex-runtime-0.163.0": "directory"}, "writable_roots": [],
            "operations": [{"op": "ro_root"}, {"op": "ro_bind", "source": "/opt/codex-runtime-0.163.0", "source_namespace": "SANDBOX", "source_exists": True, "destination": "/host/codex-0.163.0", "locked_destination": "/opt/codex-runtime-0.163.0"}],
        },
    ]
    write("V2_FAILURE_AND_V3_SUCCESSOR_REGRESSION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_REGRESSION_MATRIX", "schema_version": "1.0",
        "case_count": len(regression_cases), "cases": regression_cases,
    })
    requirements = [
        "FRESH_V3_EXECUTION_IDENTITY_AND_WORKSPACE", "V2_IMMUTABLE_TERMINAL_REFERENCE_ONLY",
        "CARRY_FORWARD_V1_AND_V2_REGRESSIONS", "BIND_DESTINATION_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT_MARKER",
        "SEMANTIC_TYPED_ARGV_SOURCE_AND_DESTINATION_OPERANDS", "ORDERED_SANDBOX_TOPOLOGY_SIMULATION",
        "EXACT_DESTINATION_CANONICAL_PATH_AND_TYPE", "DESTINATION_EXISTS_BEFORE_BIND",
        "AUTHORIZED_WRITABLE_TOPOLOGY_PREPARES_DESTINATION_WHEN_REQUIRED",
        "V2_EROFS_TOPOLOGY_REJECTED_BEFORE_ATTEMPT", "V3_VALID_TOPOLOGY_POSITIVE_REGRESSION",
        "NO_BLIND_PATH_SUBSTITUTION", "FAIL_CLOSED_INVALID_DESTINATION_ATTEMPT_REMAINS_ZERO",
        "PROMPT_NORMALIZATION_REGRESSIONS_RETAINED", "EXACT_CAMPAIGN_LANE_WORKER_SECURITY_WORKER_RUNTIME_AND_CODEX_BINDINGS",
        "FIXTURE_LOCAL_ONLY", "COMPLETE_DEPENDENCY_CLOSURE", "PRIMARY_AND_INDEPENDENT_VALIDATION",
        "FRESH_PREFLIGHT", "STATIC_LOCK_AND_LOCK_VERIFICATION_BEFORE_ATTEMPT", "HUMAN_GATE",
        "EXACTLY_ONE_WORKER_INVOCATION_ATTEMPT", "EXACTLY_ONE_SEMANTIC_CODEX_EXECUTION_REQUIRED_FOR_TECHNICAL_PASS",
        "STRUCTURED_WORKER_RESULT", "HYPOTHESIS_QUARANTINED_INITIAL_STATE", "INDEPENDENT_POST_VALIDATION",
        "EVIDENCE_FREEZE", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    write("SUCCESSOR_V3_REQUIREMENTS.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_SUCCESSOR_V3_REQUIREMENTS", "schema_version": "1.0",
        "successor_execution_identity": V3_IDENTITY, "successor_path": str(V3), "mandatory_requirements": requirements,
        "authority_ceiling": "ONE_LOCAL_FIXTURE_WORKER_INVOCATION_ONLY_NO_TARGET_CREDENTIAL_SUBAGENT_PARALLEL_OR_OFFENSIVE_OPERATION",
        "pre_attempt_failure_semantics": "STOP_WITH_ATTEMPT_0_WORKER_INVOCATION_0_CODEX_AS_WORKER_INVOCATION_0",
    })
    write("SUCCESSOR_V3_AUTHORIZATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_SUCCESSOR_V3_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": DECISION, "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "successor_execution_identity": V3_IDENTITY, "successor_path": str(V3),
        "attempt_count": 0, "attempt_limit": 1, "worker_invocation_count": 0, "worker_invocation_limit": 1,
        "semantic_codex_execution_count": 0, "semantic_codex_execution_limit": 1,
        "runtime_binding": "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED",
        "security_worker_runtime_binding": "SECURITY_WORKER_RUNTIME_V1_PASS_LOCKED",
        "creation_or_execution_this_milestone": False, "separate_acceptance_required": True,
    })
    zero = {key: 0 for key in OPERATION_KEYS}
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "current_governance_operation_counters": zero,
        "historical_v2": {"attempt_count": 1, "worker_invocation_attempt_count": 1, "semantic_codex_execution_count": 0},
        "v3_created": False, "v3_executed": False, "codex_invoked_during_governance": False,
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "current_milestone": {"read_v2_evidence": "AUTHORIZED", "governance_validation": "AUTHORIZED", "governance_freeze": "AUTHORIZED"},
        "conditionally_authorized_after_pass_locked": {"create_validate_lock_and_execute_v3_once": "AUTHORIZED_ONLY_UNDER_SUCCESSOR_V3_REQUIREMENTS"},
        "not_authorized_now": [
            "PATCH_RELOCK_REVALIDATE_RETRY_OR_CONTINUE_V2", "CREATE_OR_EXECUTE_V3_BEFORE_GOVERNANCE_LOCK",
            "CODEX_INVOCATION", "WORKER_OR_SUBAGENT_INVOCATION", "CREDENTIAL_USE", "TARGET_OR_NETWORK_ACCESS",
            "DAYBREAK", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION",
        ],
    })
    negative_cases = [
        "V2_NOT_TERMINAL", "V2_ATTEMPT_RESET_TO_ZERO", "V2_RETRY_ALLOWED", "V2_PATCH_ALLOWED",
        "V2_RELOCK_ALLOWED", "SEMANTIC_CODEX_EXECUTION_CLAIMED_ONE", "WORKER_RESULT_CLAIMED_CREATED",
        "CANDIDATE_CLAIMED_CREATED", "SECURITY_WORKER_RUNTIME_DEFECT_CLAIMED", "PROMPT_DEFECT_CLAIMED",
        "BIND_DESTINATION_DEFECT_DENIED", "SEMANTIC_VALIDATOR_GAP_DENIED", "CONFINEMENT_PROMOTED_PASS",
        "POST_VALIDATION_PROMOTED_PASS", "EVIDENCE_FREEZE_PROMOTED_PASS", "V3_CREATED_DURING_GOVERNANCE",
        "CODEX_INVOCATION_DURING_GOVERNANCE", "MISSING_DESTINATION_PRECHECK", "BLIND_PATH_SUBSTITUTION_ACCEPTED",
        "V2_FAILURE_REGRESSION_OMITTED", "V3_POSITIVE_REGRESSION_OMITTED", "INVALID_TOPOLOGY_FAIL_OPEN",
        "TARGET_OR_CREDENTIAL_AUTHORITY_OPENED", "PARALLEL_OR_SUBMISSION_AUTHORITY_OPENED",
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0",
        "case_count": len(negative_cases), "cases": [{"case_id": f"N{index:03d}", "mutation": name, "expected": "REJECT"} for index, name in enumerate(negative_cases, 1)],
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "v2_disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY", "attempt": "1_OF_1_CONSUMED",
        "semantic_codex_execution": 0, "worker_result": "NOT_CREATED", "candidate": "NOT_CREATED",
        "security_worker_runtime_v1_defect": "NO", "prompt_normalization_defect": "NO",
        "runtime_bind_destination_construction_defect": "YES", "semantic_argv_validator_coverage_gap": "YES",
        "confinement": "NOT_PROVEN", "post_validation": "INCOMPLETE", "evidence_freeze": "NOT_ISSUED",
        "successor_decision": DECISION, "governance_status_before_freeze": "VALIDATION_REQUIRED",
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_if_pass_locked": NEXT, "next_if_any_validation_fails": "STOP_FAIL_CLOSED_NO_V3_AUTHORITY_EFFECTIVE",
        "v3_may_be_created_during_this_governance_milestone": False,
    })
    print(json.dumps({"status": "BUILT_NOT_VALIDATED", "artifacts": 17, "v2_root": HASHES["v2_tree_root"], "decision": DECISION}, sort_keys=True))


if __name__ == "__main__":
    main()
