#!/usr/bin/env python3
"""Final verification, evidence freeze, manifest, and governance lock."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
V3 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v3-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_RUNTIME_BIND_DESTINATION_CONSTRUCTION_FAILURE_AND_INCOMPLETE_POST_VALIDATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3_ONCE_IF_ALL_GATES_PASS"
V2_ROOT = "f581655b70b77785d8b24c00b33af19ea8f24736f014bfe29ca2b36d4f1783be"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V2_TERMINAL_EVIDENCE_BINDING.json", "V2_TERMINAL_DISPOSITION.json",
    "FAILURE_ROOT_CAUSE_ADJUDICATION.json", "DEFECT_OWNERSHIP_DECISION.json",
    "POST_VALIDATION_AND_CONFINEMENT_DECISION.json", "BIND_DESTINATION_FEASIBILITY_CONTRACT.json",
    "V2_FAILURE_AND_V3_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V3_REQUIREMENTS.json",
    "SUCCESSOR_V3_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "BIND_DESTINATION_REGRESSION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree(path: Path) -> tuple[str, int]:
    records = [
        f"{sha(item)}  {item.relative_to(path).as_posix()}\n"
        for item in sorted(node for node in path.rglob("*") if node.is_file())
    ]
    return hashlib.sha256("".join(records).encode()).hexdigest(), len(records)


def canonical(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"finalizer input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SCRIPT_" + script, valid)
    v2_root, v2_members = tree(V2)
    check("F001_V2_UNCHANGED", v2_root == V2_ROOT and v2_members == 42, {"root": v2_root, "members": v2_members})
    check("F002_V3_ABSENT", not V3.exists() and not V3.is_symlink())

    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    regression = read(ROOT / "BIND_DESTINATION_REGRESSION_RESULT_RUN-0001.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = read(ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F003_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("F004_REGRESSION_PASS", regression.get("status") == "PASS" and regression.get("tests_passed") == 8 and regression.get("tests_failed") == 0)
    check("F005_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_passed") == 24 and negative.get("tests_failed") == 0)
    check("F006_INDEPENDENT_PASS", independent.get("status") == "PASS" and independent.get("checks_failed") == 0)
    check("F007_RESULT_IDENTITIES", all(document.get("governance_identity") == IDENTITY for document in [primary, regression, negative, independent]))

    terminal = read(ROOT / "V2_TERMINAL_DISPOSITION.json")
    root_cause = read(ROOT / "FAILURE_ROOT_CAUSE_ADJUDICATION.json")
    ownership = read(ROOT / "DEFECT_OWNERSHIP_DECISION.json")
    post = read(ROOT / "POST_VALIDATION_AND_CONFINEMENT_DECISION.json")
    contract = read(ROOT / "BIND_DESTINATION_FEASIBILITY_CONTRACT.json")
    successor = read(ROOT / "SUCCESSOR_V3_AUTHORIZATION_DECISION.json")
    requirements = read(ROOT / "SUCCESSOR_V3_REQUIREMENTS.json")
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    summary = read(ROOT / "GOVERNANCE_DECISION_SUMMARY.json")
    next_step = read(ROOT / "NEXT_LEGAL_MILESTONE.json")
    check("F008_V2_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY" and terminal.get("immutable") is True)
    check("F009_V2_CONSUMED", terminal.get("attempt") == "1_OF_1_CONSUMED" and terminal.get("worker_invocation_attempt") == 1)
    check("F010_SEMANTIC_CODEX_ZERO", terminal.get("semantic_codex_execution") == 0)
    check("F011_NO_RESULT_OR_CANDIDATE", terminal.get("worker_result") == "NOT_CREATED" and terminal.get("candidate") == "NOT_CREATED")
    check("F012_NO_V2_CONTINUATION", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "promotion"]))
    check("F013_ROOT_CAUSE", root_cause.get("root_cause") == "RUNTIME_BIND_DESTINATION_CONSTRUCTION_DEFECT" and root_cause.get("actual_codex_execve_observed") is False)
    check("F014_DEFECTS", ownership.get("runtime_bind_destination_construction_defect") == "YES" and ownership.get("semantic_argv_validator_coverage_gap") == "YES")
    check("F015_NON_DEFECTS", ownership.get("security_worker_runtime_v1_defect") == "NO" and ownership.get("prompt_normalization_defect") == "NO")
    check("F016_POST_AND_CONFINEMENT", post.get("post_validation") == "INCOMPLETE" and post.get("confinement") == "NOT_PROVEN" and post.get("runtime_result_may_be_promoted_to_pass") is False)
    check("F017_PRECHECK_BEFORE_MARKER", contract.get("gate") == "BIND_DESTINATION_FEASIBILITY_PRECHECK" and contract.get("timing") == "BEFORE_ATTEMPT_MARKER")
    check("F018_FAIL_CLOSED_PRECHECK", contract.get("failure_semantics") == "STOP_FAIL_CLOSED_ATTEMPT_REMAINS_0_OF_1_WORKER_AND_CODEX_COUNTS_REMAIN_0")
    check("F019_SUCCESSOR_DECISION", successor.get("decision") == DECISION and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F020_SUCCESSOR_ZERO", successor.get("attempt_count") == 0 and successor.get("worker_invocation_count") == 0 and successor.get("semantic_codex_execution_count") == 0)
    check("F021_SUCCESSOR_NOT_CREATED", successor.get("creation_or_execution_this_milestone") is False and not V3.exists())
    required = set(requirements.get("mandatory_requirements", []))
    check("F022_REQUIREMENTS", {
        "BIND_DESTINATION_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT_MARKER", "ORDERED_SANDBOX_TOPOLOGY_SIMULATION",
        "V2_EROFS_TOPOLOGY_REJECTED_BEFORE_ATTEMPT", "V3_VALID_TOPOLOGY_POSITIVE_REGRESSION",
        "NO_BLIND_PATH_SUBSTITUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    }.issubset(required))
    counters = authority.get("current_governance_operation_counters", {})
    check("F023_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {
        key: value for key, value in authority.items()
        if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False
    }
    check("F024_NO_CURRENT_ESCALATION", not escalations, escalations)
    check("F025_SUMMARY", summary.get("successor_decision") == DECISION and summary.get("governance_status_before_freeze") == "VALIDATION_REQUIRED")
    check("F026_NEXT", next_step.get("next_if_pass_locked") == NEXT and next_step.get("v3_may_be_created_during_this_governance_milestone") is False)
    failed = [row for row in checks if row["status"] == "FAIL"]
    if failed:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failed))

    write(FREEZE, {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT", "schema_version": "1.0",
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001", "status": "PASS",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "v2_tree_root_sha256": V2_ROOT, "v2_member_count": 42, "v3_absent": True,
        "current_governance_operation_counters": counters,
    })
    names = sorted(expected | {FREEZE})
    rows = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in names]
    artifact_root = canonical(rows)
    write(MANIFEST, {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0",
        "member_count": len(rows), "members": rows, "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    write(LOCK, {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_GOVERNANCE_LOCK", "schema_version": "1.0",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "v2_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2",
        "v2_disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY", "v2_immutable": True,
        "v2_attempt_count": 1, "v2_attempt_limit": 1, "v2_worker_invocation_attempt_count": 1,
        "v2_semantic_codex_execution_count": 0, "v2_worker_result": "NOT_CREATED", "v2_candidate": "NOT_CREATED",
        "security_worker_runtime_v1_defect": "NO", "prompt_normalization_defect": "NO",
        "runtime_bind_destination_construction_defect": "YES", "semantic_argv_validator_coverage_gap": "YES",
        "worker_behavior": "NOT_OBSERVED", "codex_runtime_compatibility_defect": "NOT_ESTABLISHED",
        "confinement": "NOT_PROVEN", "post_validation": "INCOMPLETE", "v2_evidence_freeze": "NOT_ISSUED",
        "v3_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3",
        "v3_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v3_attempt_count": 0, "v3_attempt_limit": 1, "v3_worker_invocation_count": 0,
        "v3_worker_invocation_limit": 1, "v3_semantic_codex_execution_count": 0, "v3_semantic_codex_execution_limit": 1,
        "bind_destination_feasibility_precheck": "REQUIRED_BEFORE_ATTEMPT_MARKER",
        "v2_failure_regression": "REQUIRED", "v3_valid_topology_positive_regression": "REQUIRED",
        "invalid_destination_topology": "STOP_FAIL_CLOSED_ATTEMPT_REMAINS_ZERO",
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "validation": {
            "primary": {"status": primary["status"], "passed": primary["checks_passed"], "total": primary["checks_total"]},
            "bind_destination_regression": {"status": regression["status"], "passed": regression["tests_passed"], "total": regression["tests_total"]},
            "negative": {"status": negative["status"], "passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent": {"status": independent["status"], "passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        },
        "operation_counters": counters, "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root, "next_legal_milestone": NEXT,
        "authority_ceiling": "V3_ENGINEERING_AND_ONE_LOCAL_FIXTURE_WORKER_INVOCATION_CONDITIONALLY_AUTHORIZED_ONLY_AFTER_THIS_LOCK_NO_CURRENT_RUNTIME_TARGET_OR_CREDENTIAL_AUTHORITY",
    })
    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root,
        "files": len(rows) + 2,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
