#!/usr/bin/env python3
"""Independent validation for the Worker Invocation V2 bind erratum."""

from __future__ import annotations

import hashlib
import json
import posixpath
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
V3 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v3-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_RUNTIME_BIND_DESTINATION_CONSTRUCTION_FAILURE_AND_INCOMPLETE_POST_VALIDATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3_CONDITIONALLY"
V2_ROOT = "f581655b70b77785d8b24c00b33af19ea8f24736f014bfe29ca2b36d4f1783be"
HASHES = {
    "STATIC_EXECUTION_LOCK.json": "746fc4399107e1f13f04338135e01455b11b223991b6bbbc5bbb0dfd5fc86b1f",
    "STATIC_SOURCE_MANIFEST.json": "4b29b0077430116c2be22b5e4eebc3040b8c929a886c64fe4b4c4158282aeb07",
    "STATIC_EXECUTION_LOCK_VERIFICATION.json": "5aaad7177679340a08e8f8e3f4ab9f6a266a0d98b2e3c3ddd41c88a6e3c8d05c",
    "static-run-v2/ATTEMPT_MARKER.json": "0564e06c89ba291626c3bede7e2d6f55ede45bcd86e69bef65ef97b27f59ff19",
    "static-run-v2/runtime-result-0001.json": "4368d028a3da0bde2477be0198c60884da8e405439f8bc399ae7ed6ab7bfff5d",
    "static-run-v2/stderr.txt": "5edeca2d0f00194e982cea027e4c81549fd8bf1175c7e9269c0746ffea249b41",
    "static-run-v2/trace.190881": "5e424d66ffc93c7b50e2d758765cc31071ea004ad2e5ceeb43844fbca29acbfa",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree(path: Path) -> tuple[str, int]:
    records = [
        f"{sha(item)}  {item.relative_to(path).as_posix()}\n"
        for item in sorted(node for node in path.rglob("*") if node.is_file())
    ]
    return hashlib.sha256("".join(records).encode()).hexdigest(), len(records)


def is_canonical(path: str) -> bool:
    return isinstance(path, str) and path.startswith("/") and path != "/" and posixpath.normpath(path) == path


def is_within(path: str, root: str) -> bool:
    return path == root or path.startswith(root.rstrip("/") + "/")


def independent_topology_verdict(case: dict[str, Any]) -> str:
    nodes = dict(case.get("preexisting", {}))
    writable_providers = list(case.get("writable_roots", []))
    root_ro = False
    completed_bind = False
    for step in case.get("operations", []):
        opcode = step.get("op")
        if opcode == "ro_root":
            root_ro = True
            continue
        target = step.get("destination")
        if not is_canonical(target):
            return "FAIL_CLOSED"
        if opcode == "tmpfs":
            nodes[target] = "directory"
            writable_providers.append(target)
        elif opcode == "dir":
            if target in nodes:
                if nodes[target] != "directory":
                    return "FAIL_CLOSED"
            elif any(is_within(target, provider) for provider in writable_providers):
                nodes[target] = "directory"
            else:
                _ = root_ro
                return "FAIL_CLOSED"
        elif opcode == "ro_bind":
            if step.get("source_namespace") != "CALLER" or step.get("source_exists") is not True:
                return "FAIL_CLOSED"
            if target != step.get("locked_destination") or nodes.get(target) != "directory":
                return "FAIL_CLOSED"
            completed_bind = True
        else:
            return "FAIL_CLOSED"
    return "PASS" if completed_bind else "FAIL_CLOSED"


def write(payload: dict[str, Any]) -> None:
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    v2_root, v2_members = tree(V2)
    check("I001_V2_TREE_UNCHANGED", v2_root == V2_ROOT and v2_members == 42, {"root": v2_root, "members": v2_members})
    check("I002_V3_ABSENT", not V3.exists() and not V3.is_symlink())
    for relative, digest in HASHES.items():
        check("I_HASH_" + relative, sha(V2 / relative) == digest, sha(V2 / relative))

    trace = (V2 / "static-run-v2/trace.190881").read_text(encoding="utf-8", errors="replace")
    stderr = (V2 / "static-run-v2/stderr.txt").read_text(encoding="utf-8", errors="replace")
    check("I010_DESTINATION_ABSENT", 'newfstatat(AT_FDCWD</>, "/newroot/opt/codex-runtime-0.163.0"' in trace and "ENOENT" in trace)
    check("I011_MKDIR_EROFS", 'mkdir("/newroot/opt/codex-runtime-0.163.0", 0755) = -1 EROFS' in trace)
    check("I012_STDERR_CAUSAL", "Can't mkdir /opt/codex-runtime-0.163.0: Read-only file system" in stderr)
    actual_codex_execve = [
        line for line in trace.splitlines()
        if line.startswith('execve("/opt/codex-runtime-0.163.0/bin/codex"')
    ]
    check("I013_NO_CODEX_EXECVE", not actual_codex_execve, actual_codex_execve)

    runtime = read(V2 / "static-run-v2/runtime-result-0001.json")
    marker = read(V2 / "static-run-v2/ATTEMPT_MARKER.json")
    check("I014_ATTEMPT_CONSUMED", marker.get("attempt_count") == 1 or marker.get("attempt") in {1, "1_OF_1"}, marker)
    check(
        "I015_RUNTIME_FAIL_CLOSED",
        runtime.get("status") == "FAIL_CLOSED" and runtime.get("exit_status") == 1,
        {"status": runtime.get("status"), "exit_status": runtime.get("exit_status")},
    )
    check("I016_SEMANTIC_CODEX_ZERO", runtime.get("semantic_codex_exec_count") == 0, runtime.get("semantic_codex_exec_count"))

    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    regression_result = read(ROOT / "BIND_DESTINATION_REGRESSION_RESULT_RUN-0001.json")
    negative_result = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I017_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I018_REGRESSION_PASS", regression_result.get("status") == "PASS" and regression_result.get("tests_passed") == 8 and regression_result.get("tests_failed") == 0)
    check("I019_NEGATIVE_PASS", negative_result.get("status") == "PASS" and negative_result.get("tests_passed") == 24 and negative_result.get("tests_failed") == 0)

    terminal = read(ROOT / "V2_TERMINAL_DISPOSITION.json")
    root_cause = read(ROOT / "FAILURE_ROOT_CAUSE_ADJUDICATION.json")
    ownership = read(ROOT / "DEFECT_OWNERSHIP_DECISION.json")
    post = read(ROOT / "POST_VALIDATION_AND_CONFINEMENT_DECISION.json")
    contract = read(ROOT / "BIND_DESTINATION_FEASIBILITY_CONTRACT.json")
    successor = read(ROOT / "SUCCESSOR_V3_AUTHORIZATION_DECISION.json")
    requirements = read(ROOT / "SUCCESSOR_V3_REQUIREMENTS.json")
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    routing = read(ROOT / "ROUTING_LEDGER.json")
    operation_matrix = read(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    check("I020_V2_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY" and terminal.get("immutable") is True)
    check("I021_V2_COUNTS", terminal.get("attempt") == "1_OF_1_CONSUMED" and terminal.get("worker_invocation_attempt") == 1 and terminal.get("semantic_codex_execution") == 0)
    check("I022_V2_NO_CONTINUATION", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "promotion"]))
    check("I023_NO_RESULT_OR_CANDIDATE", terminal.get("worker_result") == "NOT_CREATED" and terminal.get("candidate") == "NOT_CREATED")
    check("I024_CAUSE_AND_STAGE", root_cause.get("root_cause") == "RUNTIME_BIND_DESTINATION_CONSTRUCTION_DEFECT" and root_cause.get("failure_stage") == "BUBBLEWRAP_NAMESPACE_CONSTRUCTION_BEFORE_CODEX_EXECVE")
    check("I025_DEFECT_OWNERSHIP", ownership.get("runtime_bind_destination_construction_defect") == "YES" and ownership.get("semantic_argv_validator_coverage_gap") == "YES")
    check("I026_NON_DEFECTS", ownership.get("security_worker_runtime_v1_defect") == "NO" and ownership.get("prompt_normalization_defect") == "NO")
    check("I027_WORKER_UNOBSERVED", ownership.get("worker_behavior") == "NOT_OBSERVED" and ownership.get("codex_runtime_compatibility_defect") == "NOT_ESTABLISHED")
    check("I028_INCOMPLETE_NO_PROMOTION", post.get("post_validation") == "INCOMPLETE" and post.get("confinement") == "NOT_PROVEN" and post.get("runtime_result_may_be_promoted_to_pass") is False)
    check("I029_PRECHECK_BEFORE_MARKER", contract.get("gate") == "BIND_DESTINATION_FEASIBILITY_PRECHECK" and contract.get("timing") == "BEFORE_ATTEMPT_MARKER")
    check("I030_NO_BLIND_PATH_FIX", "BLIND_PATH_SUBSTITUTION" in contract.get("prohibited_shortcuts", []))
    check("I031_SUCCESSOR_V3", successor.get("decision") == DECISION and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I032_V3_ZERO", successor.get("attempt_count") == 0 and successor.get("worker_invocation_count") == 0 and successor.get("semantic_codex_execution_count") == 0)
    check("I033_V3_NOT_CREATED", successor.get("creation_or_execution_this_milestone") is False and not V3.exists())
    required = set(requirements.get("mandatory_requirements", []))
    check("I034_SUCCESSOR_REQUIREMENTS", {
        "BIND_DESTINATION_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT_MARKER",
        "ORDERED_SANDBOX_TOPOLOGY_SIMULATION", "DESTINATION_EXISTS_BEFORE_BIND",
        "V2_EROFS_TOPOLOGY_REJECTED_BEFORE_ATTEMPT", "V3_VALID_TOPOLOGY_POSITIVE_REGRESSION",
        "NO_BLIND_PATH_SUBSTITUTION",
    }.issubset(required))
    counters = authority.get("current_governance_operation_counters", {})
    check("I035_GOVERNANCE_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    check("I036_HISTORICAL_COUNTS_SEPARATE", authority.get("historical_v2") == {"attempt_count": 1, "worker_invocation_attempt_count": 1, "semantic_codex_execution_count": 0})
    check("I037_NO_OPERATIONAL_ROUTING", routing.get("subagents_used") is False and routing.get("codex_invoked_during_governance") is False and routing.get("worker_invoked_during_governance") is False and routing.get("network_used") is False)
    check("I038_GOVERNANCE_ONLY_MATRIX", set(operation_matrix.get("current_milestone", {})) == {"read_v2_evidence", "governance_validation", "governance_freeze"})

    regression = read(ROOT / "V2_FAILURE_AND_V3_SUCCESSOR_REGRESSION_MATRIX.json")
    independent_results = []
    for case in regression.get("cases", []):
        observed = independent_topology_verdict(case)
        independent_results.append({
            "case_id": case.get("case_id"), "expected": case.get("expected"), "observed": observed,
            "status": "PASS" if observed == case.get("expected") else "FAIL",
        })
    independent_failures = [row for row in independent_results if row["status"] == "FAIL"]
    check("I039_INDEPENDENT_TOPOLOGY_8_8", len(independent_results) == 8 and not independent_failures, independent_results)

    failed = [row for row in checks if row["status"] == "FAIL"]
    write({
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_INDEPENDENT_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "INDEPENDENT_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "independent_topology_regression": independent_results,
        "governance_operation_counters": counters,
    })
    print(json.dumps({"status": "PASS" if not failed else "FAIL_CLOSED", "passed": len(checks) - len(failed), "total": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
