#!/usr/bin/env python3
"""Primary, topology-regression, and negative governance validation."""

from __future__ import annotations

import ast
import hashlib
import json
import posixpath
from copy import deepcopy
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
V3 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v3-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_RUNTIME_BIND_DESTINATION_CONSTRUCTION_FAILURE_AND_INCOMPLETE_POST_VALIDATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V3_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V3_ONCE_IF_ALL_GATES_PASS"
V2_ROOT = "f581655b70b77785d8b24c00b33af19ea8f24736f014bfe29ca2b36d4f1783be"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V2_TERMINAL_EVIDENCE_BINDING.json", "V2_TERMINAL_DISPOSITION.json",
    "FAILURE_ROOT_CAUSE_ADJUDICATION.json", "DEFECT_OWNERSHIP_DECISION.json",
    "POST_VALIDATION_AND_CONFINEMENT_DECISION.json", "BIND_DESTINATION_FEASIBILITY_CONTRACT.json",
    "V2_FAILURE_AND_V3_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V3_REQUIREMENTS.json",
    "SUCCESSOR_V3_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
OPERATION_KEYS = {
    "worker_invocations", "codex_as_worker_invocations", "subagent_invocations", "credential_operations",
    "target_operations", "external_network_operations", "daybreak_invocations", "exploit_replays",
    "parallel_operations", "capability_edges", "candidate_promotions", "submission_operations",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def tree_root(path: Path) -> tuple[str, int]:
    rows = [
        f"{sha(member)}  {member.relative_to(path).as_posix()}\n"
        for member in sorted(item for item in path.rglob("*") if item.is_file())
    ]
    return hashlib.sha256("".join(rows).encode()).hexdigest(), len(rows)


def canonical_absolute(path: str) -> bool:
    return path.startswith("/") and path != "/" and posixpath.normpath(path) == path


def under(path: str, root: str) -> bool:
    return path == root or path.startswith(root.rstrip("/") + "/")


def evaluate_topology(case: dict[str, Any]) -> tuple[str, list[str]]:
    """Interpret the ordered topology without launching anything."""
    objects = dict(case.get("preexisting", {}))
    writable = set(case.get("writable_roots", []))
    root_read_only = False
    bind_observed = False
    reasons: list[str] = []
    for operation in case.get("operations", []):
        kind = operation.get("op")
        if kind == "ro_root":
            root_read_only = True
            continue
        destination = operation.get("destination", "")
        if not canonical_absolute(destination):
            reasons.append("NONCANONICAL_DESTINATION")
            return "FAIL_CLOSED", reasons
        if kind == "tmpfs":
            objects[destination] = "directory"
            writable.add(destination)
            continue
        if kind == "dir":
            if destination in objects:
                if objects[destination] != "directory":
                    reasons.append("DESTINATION_WRONG_TYPE")
                    return "FAIL_CLOSED", reasons
                continue
            parent_writable = any(under(destination, root) for root in writable)
            if not parent_writable:
                reasons.append("MISSING_DESTINATION_UNDER_READ_ONLY_TOPOLOGY" if root_read_only else "NO_AUTHORIZED_WRITABLE_PARENT")
                return "FAIL_CLOSED", reasons
            objects[destination] = "directory"
            continue
        if kind == "ro_bind":
            bind_observed = True
            if operation.get("source_namespace") != "CALLER" or operation.get("source_exists") is not True:
                reasons.append("SOURCE_NOT_AVAILABLE_IN_CALLER_NAMESPACE")
                return "FAIL_CLOSED", reasons
            if destination != operation.get("locked_destination"):
                reasons.append("DESTINATION_DOES_NOT_MATCH_LOCK")
                return "FAIL_CLOSED", reasons
            if objects.get(destination) != "directory":
                reasons.append("DESTINATION_NOT_EXISTING_DIRECTORY_BEFORE_BIND")
                return "FAIL_CLOSED", reasons
            continue
        reasons.append("UNKNOWN_TOPOLOGY_OPERATION")
        return "FAIL_CLOSED", reasons
    if not bind_observed:
        reasons.append("NO_BIND_OPERATION")
        return "FAIL_CLOSED", reasons
    return "PASS", ["ORDERED_TOPOLOGY_SATISFIES_BIND_DESTINATION_INVARIANT"]


def canonical_policy() -> dict[str, Any]:
    return {
        "v2_disposition": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "v2_attempt": 1, "v2_attempt_limit": 1, "v2_retry": False, "v2_patch": False,
        "v2_relock": False, "v2_revalidate": False, "semantic_codex_execution": 0,
        "worker_result": "NOT_CREATED", "candidate": "NOT_CREATED",
        "security_worker_runtime_defect": "NO", "prompt_defect": "NO",
        "bind_destination_defect": "YES", "semantic_validator_gap": "YES",
        "confinement": "NOT_PROVEN", "post_validation": "INCOMPLETE", "evidence_freeze": "NOT_ISSUED",
        "v3_created": False, "governance_codex_invocations": 0,
        "destination_precheck_required": True, "blind_path_substitution": False,
        "v2_failure_regression": True, "v3_positive_regression": True,
        "invalid_topology_fail_closed": True, "target_authorized": False,
        "credential_authorized": False, "parallel_authorized": False, "submission_authorized": False,
    }


def mutations() -> dict[str, dict[str, Any]]:
    return {
        "V2_NOT_TERMINAL": {"v2_disposition": "ACTIVE"},
        "V2_ATTEMPT_RESET_TO_ZERO": {"v2_attempt": 0},
        "V2_RETRY_ALLOWED": {"v2_retry": True},
        "V2_PATCH_ALLOWED": {"v2_patch": True},
        "V2_RELOCK_ALLOWED": {"v2_relock": True},
        "SEMANTIC_CODEX_EXECUTION_CLAIMED_ONE": {"semantic_codex_execution": 1},
        "WORKER_RESULT_CLAIMED_CREATED": {"worker_result": "CREATED"},
        "CANDIDATE_CLAIMED_CREATED": {"candidate": "HYPOTHESIS_QUARANTINED"},
        "SECURITY_WORKER_RUNTIME_DEFECT_CLAIMED": {"security_worker_runtime_defect": "YES"},
        "PROMPT_DEFECT_CLAIMED": {"prompt_defect": "YES"},
        "BIND_DESTINATION_DEFECT_DENIED": {"bind_destination_defect": "NO"},
        "SEMANTIC_VALIDATOR_GAP_DENIED": {"semantic_validator_gap": "NO"},
        "CONFINEMENT_PROMOTED_PASS": {"confinement": "PASS"},
        "POST_VALIDATION_PROMOTED_PASS": {"post_validation": "PASS"},
        "EVIDENCE_FREEZE_PROMOTED_PASS": {"evidence_freeze": "PASS"},
        "V3_CREATED_DURING_GOVERNANCE": {"v3_created": True},
        "CODEX_INVOCATION_DURING_GOVERNANCE": {"governance_codex_invocations": 1},
        "MISSING_DESTINATION_PRECHECK": {"destination_precheck_required": False},
        "BLIND_PATH_SUBSTITUTION_ACCEPTED": {"blind_path_substitution": True},
        "V2_FAILURE_REGRESSION_OMITTED": {"v2_failure_regression": False},
        "V3_POSITIVE_REGRESSION_OMITTED": {"v3_positive_regression": False},
        "INVALID_TOPOLOGY_FAIL_OPEN": {"invalid_topology_fail_closed": False},
        "TARGET_OR_CREDENTIAL_AUTHORITY_OPENED": {"target_authorized": True, "credential_authorized": True},
        "PARALLEL_OR_SUBMISSION_AUTHORITY_OPENED": {"parallel_authorized": True, "submission_authorized": True},
    }


def main() -> None:
    expected = SCRIPTS | BASE
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("P001_EXACT_INPUT_SET", actual == expected, {"actual": sorted(actual), "expected": sorted(expected)})
    check("P002_NO_SUBDIRECTORY_OR_SYMLINK", not any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()))
    check("P003_V3_ABSENT", not V3.exists() and not V3.is_symlink())
    v2_root, v2_members = tree_root(V2)
    check("P004_V2_TREE_ROOT", v2_root == V2_ROOT and v2_members == 42, {"root": v2_root, "members": v2_members})
    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("P_SCRIPT_" + script, valid)

    docs: dict[str, dict[str, Any]] = {}
    for name in sorted(BASE):
        try:
            payload = load(name)
            docs[name] = payload
            valid = payload.get("governance_identity") == IDENTITY
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            valid = False
        check("P_JSON_" + name, valid)

    terminal = docs.get("V2_TERMINAL_DISPOSITION.json", {})
    root_cause = docs.get("FAILURE_ROOT_CAUSE_ADJUDICATION.json", {})
    ownership = docs.get("DEFECT_OWNERSHIP_DECISION.json", {})
    post = docs.get("POST_VALIDATION_AND_CONFINEMENT_DECISION.json", {})
    contract = docs.get("BIND_DESTINATION_FEASIBILITY_CONTRACT.json", {})
    successor = docs.get("SUCCESSOR_V3_AUTHORIZATION_DECISION.json", {})
    requirements = docs.get("SUCCESSOR_V3_REQUIREMENTS.json", {})
    authority = docs.get("AUTHORITY_NON_ESCALATION_DECISION.json", {})
    summary = docs.get("GOVERNANCE_DECISION_SUMMARY.json", {})
    next_step = docs.get("NEXT_LEGAL_MILESTONE.json", {})
    regression = docs.get("V2_FAILURE_AND_V3_SUCCESSOR_REGRESSION_MATRIX.json", {})
    negative = docs.get("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {})

    check("P030_V2_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("P031_V2_IMMUTABLE", terminal.get("immutable") is True)
    check("P032_ATTEMPT_CONSUMED", terminal.get("attempt") == "1_OF_1_CONSUMED")
    check("P033_WORKER_ATTEMPT_ONE", terminal.get("worker_invocation_attempt") == 1)
    check("P034_SEMANTIC_CODEX_ZERO", terminal.get("semantic_codex_execution") == 0)
    check("P035_NO_RESULT_OR_CANDIDATE", terminal.get("worker_result") == "NOT_CREATED" and terminal.get("candidate") == "NOT_CREATED")
    check("P036_NO_V2_CONTINUATION", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "promotion"]))
    check("P037_ROOT_CAUSE", root_cause.get("root_cause") == "RUNTIME_BIND_DESTINATION_CONSTRUCTION_DEFECT")
    check("P038_FAILURE_STAGE", root_cause.get("failure_stage") == "BUBBLEWRAP_NAMESPACE_CONSTRUCTION_BEFORE_CODEX_EXECVE")
    syscall = root_cause.get("syscall_evidence", {})
    check("P039_SYSCALL_ENOENT", syscall.get("trace_contains_exact_enoent") is True)
    check("P040_SYSCALL_EROFS", syscall.get("trace_contains_exact_erofs") is True)
    check("P041_NO_CODEX_OR_WORKER_BEHAVIOR", root_cause.get("actual_codex_execve_observed") is False and root_cause.get("worker_behavior_observed") is False)
    check("P042_OWNERSHIP_POSITIVE", ownership.get("runtime_bind_destination_construction_defect") == "YES" and ownership.get("semantic_argv_validator_coverage_gap") == "YES")
    check("P043_OWNERSHIP_NEGATIVE", ownership.get("security_worker_runtime_v1_defect") == "NO" and ownership.get("prompt_normalization_defect") == "NO")
    check("P044_CODEX_DEFECT_NOT_ESTABLISHED", ownership.get("codex_runtime_compatibility_defect") == "NOT_ESTABLISHED")
    check("P045_POST_INCOMPLETE", post.get("post_validation") == "INCOMPLETE" and post.get("evidence_freeze") == "NOT_ISSUED")
    check("P046_CONFINEMENT_NOT_PROVEN", post.get("confinement") == "NOT_PROVEN" and post.get("runtime_result_may_be_promoted_to_pass") is False)
    check("P047_PRECHECK_TIMING", contract.get("gate") == "BIND_DESTINATION_FEASIBILITY_PRECHECK" and contract.get("timing") == "BEFORE_ATTEMPT_MARKER")
    proofs = set(contract.get("required_proofs", []))
    check("P048_PRECHECK_PROOFS", {"SEMANTIC_ARGV_PARSE_WITH_TYPED_OPERANDS", "ORDERED_TOPOLOGY_SIMULATION", "DESTINATION_EXISTS_BEFORE_BIND", "CREATION_PARENT_WRITABLE_AT_OPERATION_POINT", "EXACT_LOCKED_SOURCE_AND_DESTINATION"}.issubset(proofs))
    shortcuts = set(contract.get("prohibited_shortcuts", []))
    check("P049_SHORTCUTS_PROHIBITED", {"RAW_STRING_OCCURRENCE_COUNTING", "HARDCODED_ARGV_INDEX_ONLY", "BLIND_PATH_SUBSTITUTION"}.issubset(shortcuts))
    check("P050_PRECHECK_FAIL_CLOSED", contract.get("failure_semantics") == "STOP_FAIL_CLOSED_ATTEMPT_REMAINS_0_OF_1_WORKER_AND_CODEX_COUNTS_REMAIN_0")
    check("P051_SUCCESSOR_DECISION", successor.get("decision") == DECISION and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("P052_SUCCESSOR_IDENTITY", successor.get("successor_execution_identity") == V3_IDENTITY and successor.get("successor_path") == str(V3))
    check("P053_V3_ONE_SHOT_ZERO", successor.get("attempt_count") == 0 and successor.get("attempt_limit") == 1 and successor.get("worker_invocation_count") == 0 and successor.get("worker_invocation_limit") == 1)
    check("P054_V3_CODEX_ZERO_ONE", successor.get("semantic_codex_execution_count") == 0 and successor.get("semantic_codex_execution_limit") == 1)
    check("P055_V3_NOT_CREATED", successor.get("creation_or_execution_this_milestone") is False and not V3.exists())
    required = set(requirements.get("mandatory_requirements", []))
    check("P056_REQUIRED_PRECHECK", "BIND_DESTINATION_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT_MARKER" in required)
    check("P057_REQUIRED_V2_REGRESSION", "V2_EROFS_TOPOLOGY_REJECTED_BEFORE_ATTEMPT" in required)
    check("P058_REQUIRED_V3_POSITIVE", "V3_VALID_TOPOLOGY_POSITIVE_REGRESSION" in required)
    check("P059_REQUIRED_NO_PATH_SWAP", "NO_BLIND_PATH_SUBSTITUTION" in required)
    counters = authority.get("current_governance_operation_counters", {})
    check("P060_COUNTERS_ZERO", set(counters) == OPERATION_KEYS and all(value == 0 for value in counters.values()), counters)
    historical = authority.get("historical_v2", {})
    check("P061_HISTORICAL_COUNTS_TYPED", historical == {"attempt_count": 1, "worker_invocation_attempt_count": 1, "semantic_codex_execution_count": 0})
    escalations = {key: value for key, value in authority.items() if key.endswith("_authorized") or key.endswith("_authorized_now") if value is not False}
    check("P062_NO_CURRENT_ESCALATION", not escalations, escalations)
    check("P063_SUMMARY", summary.get("v2_disposition") == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY" and summary.get("successor_decision") == DECISION)
    check("P064_NEXT", next_step.get("next_if_pass_locked") == NEXT and next_step.get("v3_may_be_created_during_this_governance_milestone") is False)
    check("P065_REGRESSION_MATRIX", regression.get("case_count") == 8 and len(regression.get("cases", [])) == 8)
    check("P066_NEGATIVE_MATRIX", negative.get("case_count") == 24 and len(negative.get("cases", [])) == 24)

    regression_results = []
    for case in regression.get("cases", []):
        observed, reasons = evaluate_topology(case)
        regression_results.append({
            "case_id": case.get("case_id"), "expected": case.get("expected"), "observed": observed,
            "reasons": reasons, "status": "PASS" if observed == case.get("expected") else "FAIL",
        })
    regression_failed = [row for row in regression_results if row["status"] == "FAIL"]
    write("BIND_DESTINATION_REGRESSION_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_REGRESSION_RESULT", "schema_version": "1.0",
        "run_id": "BIND_DESTINATION_REGRESSION_RUN-0001",
        "status": "PASS" if not regression_failed and len(regression_results) == 8 else "FAIL_CLOSED",
        "tests": regression_results, "tests_total": len(regression_results),
        "tests_passed": len(regression_results) - len(regression_failed), "tests_failed": len(regression_failed),
        "execution_mode": "PURE_IN_MEMORY_ORDERED_TOPOLOGY_MODEL_NO_RUNTIME_INVOCATION",
    })

    canonical = canonical_policy()
    mutation_map = mutations()
    negative_results = []
    for case in negative.get("cases", []):
        name = case.get("mutation", "")
        candidate = deepcopy(canonical)
        candidate.update(mutation_map.get(name, {}))
        observed = "REJECT" if name in mutation_map and candidate != canonical else "ACCEPT"
        negative_results.append({
            "case_id": case.get("case_id"), "mutation": name, "expected": case.get("expected"),
            "observed": observed, "status": "PASS" if observed == case.get("expected") else "FAIL",
        })
    negative_failed = [row for row in negative_results if row["status"] == "FAIL"]
    write("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_NEGATIVE_TEST_RESULT", "schema_version": "1.0",
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if not negative_failed and len(negative_results) == 24 else "FAIL_CLOSED",
        "tests": negative_results, "tests_total": len(negative_results),
        "tests_passed": len(negative_results) - len(negative_failed), "tests_failed": len(negative_failed),
        "positive_control": {"canonical_policy_accepted": canonical_policy() == canonical},
    })

    failed = [row for row in checks if row["status"] == "FAIL"]
    write("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V2_BIND_DESTINATION_ERRATUM_GOVERNANCE_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "GOVERNANCE_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": counters,
    })
    print(json.dumps({
        "primary": [len(checks) - len(failed), len(checks)],
        "regression": [len(regression_results) - len(regression_failed), len(regression_results)],
        "negative": [len(negative_results) - len(negative_failed), len(negative_results)],
    }, sort_keys=True))
    if failed or regression_failed or negative_failed or len(regression_results) != 8 or len(negative_results) != 24:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
