#!/usr/bin/env python3
"""Read-only final verifier using typed exact enumerations, never count heuristics."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import stat
from typing import Any


BASE = Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-trace-erratum-governance-post-freeze-mandatory-rejection-cardinality-verifier-failure-and-v5-reissuance-decision-governance-v1-20261016"
FAILED = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-bwrap-supervisor-sigkill-trace-completeness-classification-and-post-validation-failure-erratum-and-successor-decision-governance-v1-20261016"
V4 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v4-20261016"
V5 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V4_TRACE_ERRATUM_GOVERNANCE_POST_FREEZE_MANDATORY_REJECTION_CARDINALITY_VERIFIER_FAILURE_AND_V5_REISSUANCE_DECISION_GOVERNANCE_V1"
V5_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
EXPECTED_REJECTIONS = {
    "APPLICATION_SIGKILL", "OUTER_BWRAP_SIGKILL", "SUPERVISOR_SIGKILL_WITHOUT_BOUND_DIE_WITH_PARENT",
    "SUPERVISOR_SIGKILL_BEFORE_CHILD_REAP", "NONZERO_OR_UNKNOWN_APPLICATION_STATUS",
    "MISSING_WAIT_OR_EVENTFD_EDGE", "MISSING_OR_TRUNCATED_TRACE", "UNMATCHED_UNFINISHED_SYSCALL",
    "UNKNOWN_SIGNAL_RECIPIENT", "EXTRA_DESCENDANT_OR_EXECUTABLE",
}
EXPECTED_PRECHECKS = {
    "RESOURCE_LIMIT_FEASIBILITY_PRECHECK", "BIND_SOURCE_RESOLUTION_PRECHECK",
    "SEMANTIC_MOUNT_TOPOLOGY_PRECHECK", "PRIVATE_DEV_CLASSIFICATION_PRECHECK",
    "LOOPBACK_ROUTE_CLASSIFICATION_PRECHECK", "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_PRECHECK",
}
COUNTER_KEYS = {
    "runtime_validation_attempts", "containment_fixture_attempts", "real_worker_processes",
    "subagent_processes", "codex_cli_invocations", "daybreak_invocations", "target_operations",
    "external_network_operations", "exploit_replays", "parallel_operations", "capability_edges",
    "candidate_promotions", "submission_operations",
}


def h(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest(path: Path) -> str:
    return h(path.read_bytes())


def read(name: str) -> Any:
    return json.loads((GOV / name).read_text(encoding="utf-8"))


def counters_zero(record: dict[str, Any]) -> bool:
    counters = record.get("operation_counters", {})
    return set(counters) == COUNTER_KEYS and all(value == 0 for value in counters.values())


def main() -> int:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, value: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if value else "FAIL", "evidence": evidence})

    manifest = read("GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = read("GOVERNANCE_LOCK.json")
    members = manifest.get("members", [])
    paths = [item["path"] for item in members]
    actual = {path.name for path in GOV.iterdir()}
    expected = set(paths) | {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    check("FV001_IDENTITY", manifest.get("governance_identity") == lock.get("governance_identity") == IDENTITY)
    check("FV002_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("FV003_DECISION", lock.get("decision") == "REISSUE_AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V5_CONDITIONALLY")
    check("FV004_FILE_SET", actual == expected, {"actual": len(actual), "expected": len(expected)})
    check("FV005_NO_SYMLINKS", not any(path.is_symlink() for path in GOV.iterdir()))
    check("FV006_REGULAR", all(path.is_file() for path in GOV.iterdir()))
    check("FV007_MODES", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in GOV.iterdir()))
    check("FV008_DIR_MODE", stat.S_IMODE(GOV.stat().st_mode) == 0o555)
    check("FV009_MEMBER_COUNT", manifest.get("member_count") == len(members) == len(paths))
    check("FV010_UNIQUE_SORTED", len(paths) == len(set(paths)) and paths == sorted(paths))
    lines = []
    member_ok = True
    for item in members:
        path = GOV / item["path"]
        payload = path.read_bytes() if path.is_file() and not path.is_symlink() else b""
        member_ok = member_ok and len(payload) == item["bytes"] and h(payload) == item["sha256"]
        lines.append(f"{item['sha256']}  {item['path']}\n")
    member_root = h("".join(lines).encode())
    check("FV011_MEMBER_BYTES", member_ok)
    check("FV012_MEMBER_ROOT", member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256"), member_root)
    manifest_sha = digest(GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    check("FV013_MANIFEST_SHA", manifest_sha == lock.get("governance_artifact_manifest_sha256"), manifest_sha)
    roots = members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "bytes": (GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size, "sha256": manifest_sha}]
    artifact_root = h("".join(f"{item['sha256']}  {item['path']}\n" for item in sorted(roots, key=lambda item: item["path"])).encode())
    check("FV014_ARTIFACT_ROOT", artifact_root == lock.get("canonical_artifact_root_sha256"), artifact_root)
    check("FV015_ROOT_COUNT", lock.get("artifact_root_member_count") == len(roots))
    check("FV016_JSON_PARSE", all(isinstance(json.loads(path.read_text()), dict) for path in GOV.glob("*.json")))

    primary_first = read("GOVERNANCE_TEST_RESULT.json")
    primary = read("GOVERNANCE_TEST_RESULT_RUN_0002.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    independent = read("INDEPENDENT_VALIDATION_RESULT.json")
    freeze = read("FREEZE_VERIFICATION_RESULT.json")
    failed = read("FAILED_GOVERNANCE_TERMINAL_DISPOSITION.json")
    root = read("FREEZE_VERIFIER_CARDINALITY_ROOT_CAUSE.json")
    v4 = read("RUNTIME_VALIDATION_V4_ADJUDICATION_RECONFIRMATION.json")
    contract = read("PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT_REISSUED.json")
    prechecks = read("PRESERVED_PRECHECKS_DECISION.json")
    successor = read("RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_REISSUANCE_DECISION.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    validation = lock.get("validation", {})
    expected_validation = {
        "primary": {"passed": primary.get("checks_passed"), "total": primary.get("checks_total")},
        "negative": {"passed": negative.get("tests_passed"), "total": negative.get("tests_total")},
        "independent": {"passed": independent.get("checks_passed"), "total": independent.get("checks_total")},
        "final_freeze": {"passed": freeze.get("checks_passed"), "total": freeze.get("checks_total")},
    }
    check("FV017_PRIMARY_AND_FIRST_FAILURE_PRESERVED", primary.get("status") == "PASS" and primary.get("checks_passed") == primary.get("checks_total") and primary_first.get("status") == "FAIL_CLOSED" and primary_first.get("checks_passed") == 41)
    check("FV018_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_passed") == negative.get("tests_total"))
    check("FV019_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_passed") == independent.get("checks_total"))
    check("FV020_FREEZE", freeze.get("status") == "PASS" and freeze.get("checks_passed") == freeze.get("checks_total"))
    check("FV021_VALIDATION_TOTALS", validation == expected_validation, {"actual": validation, "expected": expected_validation})
    check("FV022_COUNTERS", all(counters_zero(item) for item in (primary, negative, independent, freeze, lock)))
    check("FV023_FAILED_PACKAGE_TERMINAL", failed.get("status") == "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY")
    check("FV024_FAILED_AUTHORITY_NONE", failed.get("effective_authority") == "NONE")
    check("FV025_FAILED_LOCK_IMMUTABLE", digest(FAILED / "GOVERNANCE_LOCK.json") == "a07be1bfa02551365c58ad83827944b06e5898ff5a815bb3013aff904bb503dc")
    check("FV026_ROOT_CAUSE", root.get("root_cause") == "POST_FREEZE_VERIFIER_HARDCODED_STALE_STRUCTURAL_CARDINALITY")
    check("FV027_EXACT_REJECTION_SET", set(contract.get("mandatory_rejections", [])) == EXPECTED_REJECTIONS)
    check("FV028_REJECTION_UNIQUE", len(contract.get("mandatory_rejections", [])) == len(set(contract.get("mandatory_rejections", []))))
    check("FV029_EXACT_PRECHECK_SET", set(prechecks.get("required", [])) == EXPECTED_PRECHECKS)
    check("FV030_PRECHECK_UNIQUE", len(prechecks.get("required", [])) == len(set(prechecks.get("required", []))))
    check("FV031_V4_TERMINAL", v4.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY" and v4.get("attempt_count") == 1)
    check("FV032_V4_NOT_PROVEN", v4.get("confinement") == "NOT_PROVEN" and v4.get("retroactive_promotion") == "PROHIBITED")
    check("FV033_V4_IMMUTABLE", digest(V4 / "evidence-v4/EVIDENCE_FREEZE_LOCK.json") == "8e8961ca998f486eb1c275bc28f3a0cf50c79fc0bba127f24f8dc979fb40507f")
    check("FV034_V5_REISSUED", successor.get("decision") == "REISSUE_AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V5_CONDITIONALLY")
    check("FV035_V5_IDENTITY", successor.get("execution_identity") == V5_IDENTITY)
    check("FV036_V5_ZERO", successor.get("attempt_count") == 0 and successor.get("maximum_attempts") == 1)
    check("FV037_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    check("FV038_NO_EXECUTION_NOW", authority.get("v5_create_or_execute_now") is False)
    check("FV039_NO_WORKER_TARGET", authority.get("worker_codex_daybreak_subagent") is False and authority.get("target_or_external_network") is False)
    check("FV040_NO_EXPLOIT_GRAPH", authority.get("exploit_replay") is False and authority.get("parallelism_capability_graph_promotion_submission") is False)

    failures = [item for item in checks if item["status"] != "PASS"]
    result = {
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failures),
        "checks_failed": len(failures), "failed": failures,
        "governance_lock_sha256": digest(GOV / "GOVERNANCE_LOCK.json"),
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
