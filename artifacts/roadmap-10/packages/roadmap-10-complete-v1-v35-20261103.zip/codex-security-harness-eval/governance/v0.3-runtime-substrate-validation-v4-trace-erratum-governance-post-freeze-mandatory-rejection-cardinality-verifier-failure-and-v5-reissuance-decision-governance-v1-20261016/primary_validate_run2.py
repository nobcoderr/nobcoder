#!/usr/bin/env python3
"""Versioned correction of the pre-freeze application-trace predicate."""

from __future__ import annotations

import json
from pathlib import Path


BASE = Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-trace-erratum-governance-post-freeze-mandatory-rejection-cardinality-verifier-failure-and-v5-reissuance-decision-governance-v1-20261016"
V4 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v4-20261016"
OUTPUT = GOV / "GOVERNANCE_TEST_RESULT_RUN_0002.json"


def main() -> int:
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise RuntimeError("refusing overwrite")
    first = json.loads((GOV / "GOVERNANCE_TEST_RESULT.json").read_text(encoding="utf-8"))
    if first.get("status") != "FAIL_CLOSED" or [item.get("check_id") for item in first.get("failed", [])] != ["G021_APP_LIFECYCLE"]:
        raise RuntimeError("unexpected first-run lineage")
    app = (V4 / "evidence-v4/traces/runtime.strace.104061").read_text(encoding="utf-8")
    corrected = 'execve("/usr/bin/python3.14"' in app and app.rstrip().endswith("exit_group(0)                           = ?")
    checks = []
    for item in first["checks"]:
        current = dict(item)
        if current["check_id"] == "G021_APP_LIFECYCLE":
            current["status"] = "PASS" if corrected else "FAIL"
            current["evidence"] = {
                "predicate": "EXECVE_PRESENT_ANYWHERE_AND_TERMINAL_EXIT_GROUP_ZERO",
                "prior_predicate": "TRACE_STARTS_WITH_EXECVE_AND_TERMINAL_EXIT_GROUP_ZERO",
            }
        checks.append(current)
    checks.append({
        "check_id": "G043_FIRST_PRIMARY_FAILURE_PRESERVED",
        "status": "PASS",
        "evidence": "GOVERNANCE_TEST_RESULT.json:FAIL_CLOSED_41_OF_42_G021",
    })
    failed = [item for item in checks if item["status"] != "PASS"]
    result = {
        "schema_version": "1.0", "record_type": "GOVERNANCE_TEST_RESULT_RUN_0002",
        "governance_identity": first["governance_identity"],
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed), "failed": failed, "checks": checks,
        "operation_counters": first["operation_counters"],
        "lineage": {
            "run": 2, "prior_result": "GOVERNANCE_TEST_RESULT.json",
            "prior_status": "FAIL_CLOSED_41_OF_42_PRESERVED_NOT_OVERWRITTEN",
            "change": "CORRECT_APPLICATION_EXECVE_POSITION_PREDICATE",
        },
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("status", "checks_total", "checks_passed", "checks_failed")}, indent=2, sort_keys=True))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
