#!/usr/bin/env python3
"""Independent validation of the fresh freeze-failure successor governance."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


BASE = Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-trace-erratum-governance-post-freeze-mandatory-rejection-cardinality-verifier-failure-and-v5-reissuance-decision-governance-v1-20261016"
FAILED = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-bwrap-supervisor-sigkill-trace-completeness-classification-and-post-validation-failure-erratum-and-successor-decision-governance-v1-20261016"
V4 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v4-20261016"
V5 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V4_TRACE_ERRATUM_GOVERNANCE_POST_FREEZE_MANDATORY_REJECTION_CARDINALITY_VERIFIER_FAILURE_AND_V5_REISSUANCE_DECISION_GOVERNANCE_V1"
V5_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
OUTPUT = GOV / "INDEPENDENT_VALIDATION_RESULT.json"

EXPECTED_REJECTIONS = {
    "APPLICATION_SIGKILL", "OUTER_BWRAP_SIGKILL",
    "SUPERVISOR_SIGKILL_WITHOUT_BOUND_DIE_WITH_PARENT",
    "SUPERVISOR_SIGKILL_BEFORE_CHILD_REAP",
    "NONZERO_OR_UNKNOWN_APPLICATION_STATUS", "MISSING_WAIT_OR_EVENTFD_EDGE",
    "MISSING_OR_TRUNCATED_TRACE", "UNMATCHED_UNFINISHED_SYSCALL",
    "UNKNOWN_SIGNAL_RECIPIENT", "EXTRA_DESCENDANT_OR_EXECUTABLE",
}
EXPECTED_PRECHECKS = {
    "RESOURCE_LIMIT_FEASIBILITY_PRECHECK", "BIND_SOURCE_RESOLUTION_PRECHECK",
    "SEMANTIC_MOUNT_TOPOLOGY_PRECHECK", "PRIVATE_DEV_CLASSIFICATION_PRECHECK",
    "LOOPBACK_ROUTE_CLASSIFICATION_PRECHECK",
    "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_PRECHECK",
}
COUNTER_KEYS = {
    "runtime_validation_attempts", "containment_fixture_attempts", "real_worker_processes",
    "subagent_processes", "codex_cli_invocations", "daybreak_invocations",
    "target_operations", "external_network_operations", "exploit_replays",
    "parallel_operations", "capability_edges", "candidate_promotions", "submission_operations",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> Any:
    return json.loads((GOV / name).read_text(encoding="utf-8"))


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def counters_zero(record: dict[str, Any]) -> bool:
    counters = record.get("operation_counters", {})
    return set(counters) == COUNTER_KEYS and all(value == 0 for value in counters.values())


def main() -> int:
    if OUTPUT.exists() or OUTPUT.is_symlink():
        raise RuntimeError("refusing overwrite")
    checks: list[dict[str, Any]] = []
    def check(check_id: str, value: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if value else "FAIL", "evidence": evidence})

    expected = {
        "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
        "FAILED_GOVERNANCE_TERMINAL_DISPOSITION.json", "FREEZE_VERIFIER_CARDINALITY_ROOT_CAUSE.json",
        "V4_TRACE_ERRATUM_REISSUANCE_EVIDENCE_BINDING.json", "RUNTIME_VALIDATION_V4_ADJUDICATION_RECONFIRMATION.json",
        "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT_REISSUED.json", "PRESERVED_PRECHECKS_DECISION.json",
        "RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_REISSUANCE_DECISION.json",
        "V5_REGRESSION_REQUIREMENTS_REISSUED.json", "V5_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT_REISSUED.json",
        "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
        "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
        "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "GOVERNANCE_TEST_RESULT.json",
        "GOVERNANCE_TEST_RESULT_RUN_0002.json", "primary_validate_run2.py",
    }
    actual = {path.name for path in GOV.iterdir()}
    check("I001_EXACT_FILES", actual == expected, {"actual": sorted(actual), "expected": sorted(expected)})
    check("I002_NO_SYMLINKS", not any(path.is_symlink() for path in GOV.iterdir()))
    check("I003_REGULAR_FILES", all(path.is_file() for path in GOV.iterdir()))
    check("I004_FAILED_LOCK_HASH", digest(FAILED / "GOVERNANCE_LOCK.json") == "a07be1bfa02551365c58ad83827944b06e5898ff5a815bb3013aff904bb503dc")
    check("I005_FAILED_MANIFEST_HASH", digest(FAILED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "a773ea9765eb4f564ce2ff089c05042c64639c8b078f983cd2015de864972883")
    check("I006_FAILED_VERIFIER_HASH", digest(FAILED / "freeze_verify.py") == "2e89aae1d518a4538f86938fb0c0257be4b9fa4251052900a0669a5dadb9d21e")
    check("I007_CONTRACT_HASH", digest(FAILED / "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT.json") == "41220be34956b94f2ef89b3703ef7964d83a447db10b85a28eea0938a8de1c89")
    check("I008_V4_TERMINAL_HASH", digest(V4 / "evidence-v4/RUNTIME_VALIDATION_TERMINAL_RESULT.json") == "fb1c90f24d072d3a7114aa6a486ec7650f14684ce0d6cbfa982c743abbdf4cb8")
    check("I009_V4_POST_HASH", digest(V4 / "evidence-v4/validation/INDEPENDENT_POST_VALIDATION_RESULT.json") == "68c9e934162836362877373be4fe774459ed2d4f34e96ae4494ef0032a7dc8dd")
    check("I010_V5_ABSENT", not V5.exists() and not V5.is_symlink())

    failed_disposition = read("FAILED_GOVERNANCE_TERMINAL_DISPOSITION.json")
    root = read("FREEZE_VERIFIER_CARDINALITY_ROOT_CAUSE.json")
    binding = read("V4_TRACE_ERRATUM_REISSUANCE_EVIDENCE_BINDING.json")
    v4 = read("RUNTIME_VALIDATION_V4_ADJUDICATION_RECONFIRMATION.json")
    contract = read("PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT_REISSUED.json")
    prechecks = read("PRESERVED_PRECHECKS_DECISION.json")
    successor = read("RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_REISSUANCE_DECISION.json")
    regressions = read("V5_REGRESSION_REQUIREMENTS_REISSUED.json")
    gates = read("V5_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT_REISSUED.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    operations = read("OPERATION_AUTHORIZATION_MATRIX.json")
    next_legal = read("NEXT_LEGAL_MILESTONE.json")
    negative_matrix = read("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    primary_first = read("GOVERNANCE_TEST_RESULT.json")
    primary = read("GOVERNANCE_TEST_RESULT_RUN_0002.json")
    records = [failed_disposition, root, binding, v4, contract, prechecks, successor, regressions, gates, authority, operations, next_legal, negative_matrix, negative, primary]

    check("I011_IDENTITIES", all(item.get("governance_identity") == IDENTITY for item in records))
    check("I012_FAILED_TERMINAL", failed_disposition.get("status") == "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY")
    check("I013_FAILED_FINAL_39_40", failed_disposition.get("final_read_only_verification") == {"passed": 39, "total": 40, "failed_check": "FV033_ROLE_AWARE_CONTRACT"})
    check("I014_FAILED_AUTHORITY_NONE", failed_disposition.get("effective_authority") == "NONE")
    check("I015_FAILED_V5_NOT_EFFECTIVE", failed_disposition.get("v5_authorization_in_failed_package") == "NOT_EFFECTIVE")
    check("I016_NO_FAILED_PATCH", all(failed_disposition.get(key) == "PROHIBITED" for key in ("patch", "relock", "retry")))
    check("I017_ACTUAL_COUNT", root.get("contract_actual_cardinality") == len(EXPECTED_REJECTIONS))
    check("I018_STALE_COUNT", root.get("freeze_verifier_expected_cardinality") == 11)
    check("I019_EXACT_ROOT_VALUES", set(root.get("contract_exact_values", [])) == EXPECTED_REJECTIONS)
    check("I020_ROOT_CAUSE", root.get("root_cause") == "POST_FREEZE_VERIFIER_HARDCODED_STALE_STRUCTURAL_CARDINALITY")
    check("I021_CLASSIFIER_DEFECT", root.get("classifier_defect") is True)
    check("I022_NO_DECISION_DEFECT", root.get("governance_decision_defect") is False)
    check("I023_NO_V4_DEFECT", root.get("runtime_validation_v4_defect") is False)
    check("I024_TYPED_RULE", root.get("correct_rule", "").startswith("COMPARE_TYPED_EXACT_ENUMERATED_VALUES"))
    check("I025_BINDING_COUNT", len(binding.get("anchors", [])) == 17)
    check("I026_BINDING_INTEGRITY", all(binding.get(key) == "PASS" for key in ("failed_package_manifest_integrity", "v4_source_manifest_integrity", "v4_evidence_manifest_integrity")))
    check("I027_V4_TERMINAL", v4.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("I028_V4_ATTEMPT", v4.get("attempt_count") == v4.get("maximum_attempts") == 1)
    check("I029_V4_RUNTIME_BODY", v4.get("runtime_gate") == v4.get("fixture_body") == "PASS")
    check("I030_V4_POST", v4.get("independent_post_validation") == "75_OF_76_FAIL_CLOSED")
    check("I031_V4_CONFINEMENT", v4.get("confinement") == "NOT_PROVEN")
    check("I032_V4_NO_PROMOTION", v4.get("retroactive_promotion") == "PROHIBITED")
    check("I033_SIGKILL_CLASS", v4.get("sigkill_classification") == "EXPECTED_CONTRACTUAL_SUPERVISOR_TEARDOWN_PROVEN_FOR_THIS_FROZEN_TRACE")
    check("I034_OWNERSHIP", v4.get("ownership") == {"trace_completeness_classifier_defect": True, "supervisor_teardown_contract_gap": True, "actual_unexpected_termination": False, "containment_bypass": False})
    check("I035_CONTRACT_RULE", contract.get("rule", "").startswith("TERMINATION_IS_CLASSIFIED_BY_BOUND_ROLE"))
    check("I036_CONTRACT_ROLES", set(contract.get("required_roles", [])) == {"OUTER_BWRAP_SPAWNER", "SANDBOX_PID1_SUPERVISOR", "FIXTURE_APPLICATION_PID2"})
    check("I037_EXACT_REJECTIONS", set(contract.get("mandatory_rejections", [])) == EXPECTED_REJECTIONS)
    check("I038_NO_DUP_REJECTIONS", len(contract.get("mandatory_rejections", [])) == len(set(contract.get("mandatory_rejections", []))))
    check("I039_RAW_TRACE", contract.get("raw_trace_preservation_required") is True)
    check("I040_INDEPENDENT_IMPL", contract.get("independent_implementation_required") is True)
    check("I041_EXACT_PRECHECKS", set(prechecks.get("required", [])) == EXPECTED_PRECHECKS)
    check("I042_NO_DUP_PRECHECKS", len(prechecks.get("required", [])) == len(set(prechecks.get("required", []))))
    check("I043_PRECHECKS_BEFORE_MARKER", prechecks.get("all_must_pass_before_attempt_marker") is True)
    check("I044_V5_REISSUED", successor.get("decision") == "REISSUE_AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V5_CONDITIONALLY")
    check("I045_V5_IDENTITY", successor.get("execution_identity") == V5_IDENTITY)
    check("I046_V5_ZERO", successor.get("attempt_count") == 0 and successor.get("maximum_attempts") == 1)
    check("I047_V5_FRESH", successor.get("fresh_identity_source_tests_lock") == "REQUIRED")
    check("I048_V5_PRECHECK_PARITY", set(successor.get("required_prechecks", [])) == EXPECTED_PRECHECKS)
    check("I049_V5_AFTER_GATES", successor.get("attempt_marker_after_all_fresh_gates") is True)
    check("I050_V5_SEPARATE_ACCEPTANCE", successor.get("success_ceiling") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION")
    check("I051_REGRESSION_COVERAGE", {"V1_RESOURCE_LIMIT_FAILURE", "V2_BIND_SOURCE_FAILURE", "V3_CLASSIFIER_FAILURES", "V4_TRACE_KILLED_FALSE_FAILURE"}.issubset(regressions.get("required", [])))
    check("I052_GATE_PRECHECKS", EXPECTED_PRECHECKS.issubset(gates.get("required", [])))
    check("I053_GATE_FAILURE_ZERO", gates.get("failure_before_attempt_marker") == "STOP_ATTEMPT_REMAINS_ZERO")
    check("I054_NO_EXECUTION_NOW", authority.get("v5_create_or_execute_now") is False)
    check("I055_NO_V4_OR_FAILED_MUTATION", authority.get("v4_or_failed_governance_mutation") is False)
    check("I056_NO_WORKER_MODEL", authority.get("worker_codex_daybreak_subagent") is False)
    check("I057_NO_TARGET_NETWORK", authority.get("target_or_external_network") is False)
    check("I058_NO_EXPLOIT_GRAPH", authority.get("exploit_replay") is False and authority.get("parallelism_capability_graph_promotion_submission") is False)
    check("I059_OPERATION_MATRIX", operations.get("operations", {}).get("CREATE_OR_EXECUTE_V5_DURING_THIS_MILESTONE") == "PROHIBITED")
    check("I060_NEXT", next_legal.get("next_legal_milestone", "").endswith("V5_THEN_EXECUTE_RUNTIME_VALIDATION_V5_ONCE_IF_ALL_GATES_PASS"))
    check("I061_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_total") == primary.get("checks_passed"))
    check("I062_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed"))
    check("I063_NEGATIVE_PARITY", negative_matrix.get("test_ids") == [row["test_id"] for row in negative.get("tests", [])])
    check("I064_COUNTERS", counters_zero(primary) and counters_zero(negative))
    check("I065_FIRST_PRIMARY_FAILURE_PRESERVED", primary_first.get("status") == "FAIL_CLOSED" and primary_first.get("checks_total") == 42 and primary_first.get("checks_passed") == 41 and [item.get("check_id") for item in primary_first.get("failed", [])] == ["G021_APP_LIFECYCLE"])

    failed = [item for item in checks if item["status"] != "PASS"]
    result = {
        "schema_version": "1.0", "record_type": "INDEPENDENT_VALIDATION_RESULT",
        "governance_identity": IDENTITY, "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed), "failed": failed, "checks": checks,
        "operation_counters": {key: 0 for key in sorted(COUNTER_KEYS)},
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("status", "checks_total", "checks_passed", "checks_failed")}, indent=2, sort_keys=True))
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
