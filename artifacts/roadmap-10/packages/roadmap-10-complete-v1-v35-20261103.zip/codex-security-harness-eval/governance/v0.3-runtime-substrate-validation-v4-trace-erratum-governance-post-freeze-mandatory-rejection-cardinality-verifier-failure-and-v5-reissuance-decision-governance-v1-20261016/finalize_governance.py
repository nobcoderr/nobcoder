#!/usr/bin/env python3
"""Finalize the fresh governance package without cardinality heuristics."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


BASE = Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-trace-erratum-governance-post-freeze-mandatory-rejection-cardinality-verifier-failure-and-v5-reissuance-decision-governance-v1-20261016"
FAILED = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-bwrap-supervisor-sigkill-trace-completeness-classification-and-post-validation-failure-erratum-and-successor-decision-governance-v1-20261016"
V4 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v4-20261016"
V5 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V4_TRACE_ERRATUM_GOVERNANCE_POST_FREEZE_MANDATORY_REJECTION_CARDINALITY_VERIFIER_FAILURE_AND_V5_REISSUANCE_DECISION_GOVERNANCE_V1"
V5_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
NEXT_MILESTONE = "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V5_THEN_EXECUTE_RUNTIME_VALIDATION_V5_ONCE_IF_ALL_GATES_PASS"
EXPECTED_REJECTIONS = {
    "APPLICATION_SIGKILL", "OUTER_BWRAP_SIGKILL", "SUPERVISOR_SIGKILL_WITHOUT_BOUND_DIE_WITH_PARENT",
    "SUPERVISOR_SIGKILL_BEFORE_CHILD_REAP", "NONZERO_OR_UNKNOWN_APPLICATION_STATUS",
    "MISSING_WAIT_OR_EVENTFD_EDGE", "MISSING_OR_TRUNCATED_TRACE", "UNMATCHED_UNFINISHED_SYSCALL",
    "UNKNOWN_SIGNAL_RECIPIENT", "EXTRA_DESCENDANT_OR_EXECUTABLE",
}
EXPECTED_PRECHECKS = {
    "RESOURCE_LIMIT_FEASIBILITY_PRECHECK", "BIND_SOURCE_RESOLUTION_PRECHECK",
    "SEMANTIC_MOUNT_TOPOLOGY_PRECHECK", "PRIVATE_DEV_CLASSIFICATION_PRECHECK",
    "LOOPBACK_ROUTE_CLASSIFICATION_PRECHECK", "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_PRECHECK",
}
COUNTERS = {
    "runtime_validation_attempts": 0, "containment_fixture_attempts": 0,
    "real_worker_processes": 0, "subagent_processes": 0, "codex_cli_invocations": 0,
    "daybreak_invocations": 0, "target_operations": 0, "external_network_operations": 0,
    "exploit_replays": 0, "parallel_operations": 0, "capability_edges": 0,
    "candidate_promotions": 0, "submission_operations": 0,
}
PREFREEZE = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "FAILED_GOVERNANCE_TERMINAL_DISPOSITION.json", "FREEZE_VERIFIER_CARDINALITY_ROOT_CAUSE.json",
    "V4_TRACE_ERRATUM_REISSUANCE_EVIDENCE_BINDING.json", "RUNTIME_VALIDATION_V4_ADJUDICATION_RECONFIRMATION.json",
    "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT_REISSUED.json", "PRESERVED_PRECHECKS_DECISION.json",
    "RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_REISSUANCE_DECISION.json",
    "V5_REGRESSION_REQUIREMENTS_REISSUED.json", "V5_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT_REISSUED.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEXT_LEGAL_MILESTONE.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "GOVERNANCE_TEST_RESULT.json",
    "GOVERNANCE_TEST_RESULT_RUN_0002.json", "primary_validate_run2.py",
    "INDEPENDENT_VALIDATION_RESULT.json",
}


def h(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest(path: Path) -> str:
    return h(path.read_bytes())


def read(name: str) -> Any:
    return json.loads((GOV / name).read_text(encoding="utf-8"))


def write(name: str, value: Any) -> None:
    path = GOV / name
    if path.exists() or path.is_symlink():
        raise RuntimeError(f"refusing overwrite: {path}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def counters_zero(record: dict[str, Any]) -> bool:
    return record.get("operation_counters") == COUNTERS


def main() -> int:
    if (GOV / "GOVERNANCE_LOCK.json").exists() or (GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json").exists():
        raise RuntimeError("already finalized")
    actual = {path.name for path in GOV.iterdir()}
    if actual != PREFREEZE:
        raise RuntimeError(f"unexpected prefreeze set: {sorted(actual ^ PREFREEZE)}")
    checks: list[dict[str, Any]] = []
    def check(check_id: str, value: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if value else "FAIL", "evidence": evidence})

    primary_first = read("GOVERNANCE_TEST_RESULT.json")
    primary = read("GOVERNANCE_TEST_RESULT_RUN_0002.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    independent = read("INDEPENDENT_VALIDATION_RESULT.json")
    failed = read("FAILED_GOVERNANCE_TERMINAL_DISPOSITION.json")
    root = read("FREEZE_VERIFIER_CARDINALITY_ROOT_CAUSE.json")
    v4 = read("RUNTIME_VALIDATION_V4_ADJUDICATION_RECONFIRMATION.json")
    contract = read("PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT_REISSUED.json")
    prechecks = read("PRESERVED_PRECHECKS_DECISION.json")
    successor = read("RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_REISSUANCE_DECISION.json")
    gates = read("V5_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT_REISSUED.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    next_legal = read("NEXT_LEGAL_MILESTONE.json")

    check("F001_EXACT_SET", actual == PREFREEZE)
    check("F002_NO_SYMLINKS", not any(path.is_symlink() for path in GOV.iterdir()))
    check("F003_REGULAR_FILES", all(path.is_file() for path in GOV.iterdir()))
    check("F004_JSON_PARSE", all(isinstance(json.loads(path.read_text()), dict) for path in GOV.glob("*.json")))
    check("F005_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_total") == primary.get("checks_passed"))
    check("F006_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed"))
    check("F007_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_total") == independent.get("checks_passed"))
    check("F008_COUNTERS", counters_zero(primary) and counters_zero(negative) and counters_zero(independent))
    check("F009_FAILED_PACKAGE_TERMINAL", failed.get("status") == "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY")
    check("F010_FAILED_RESULT", failed.get("final_read_only_verification") == {"passed": 39, "total": 40, "failed_check": "FV033_ROLE_AWARE_CONTRACT"})
    check("F011_FAILED_AUTHORITY_NONE", failed.get("effective_authority") == "NONE")
    check("F012_ROOT_CAUSE", root.get("root_cause") == "POST_FREEZE_VERIFIER_HARDCODED_STALE_STRUCTURAL_CARDINALITY")
    check("F013_CARDINALITY_FACT", root.get("contract_actual_cardinality") == len(EXPECTED_REJECTIONS) and root.get("freeze_verifier_expected_cardinality") == 11)
    check("F014_EXACT_REJECTIONS", set(root.get("contract_exact_values", [])) == EXPECTED_REJECTIONS)
    check("F015_V4_TERMINAL", v4.get("status") == "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("F016_V4_ATTEMPT", v4.get("attempt_count") == v4.get("maximum_attempts") == 1)
    check("F017_V4_CONFINEMENT", v4.get("confinement") == "NOT_PROVEN")
    check("F018_V4_NO_PROMOTION", v4.get("retroactive_promotion") == "PROHIBITED")
    check("F019_V4_SIGKILL", v4.get("sigkill_classification") == "EXPECTED_CONTRACTUAL_SUPERVISOR_TEARDOWN_PROVEN_FOR_THIS_FROZEN_TRACE")
    check("F020_CONTRACT_REJECTIONS_EXACT", set(contract.get("mandatory_rejections", [])) == EXPECTED_REJECTIONS)
    check("F021_CONTRACT_NO_DUP", len(contract.get("mandatory_rejections", [])) == len(set(contract.get("mandatory_rejections", []))))
    check("F022_PRECHECKS_EXACT", set(prechecks.get("required", [])) == EXPECTED_PRECHECKS)
    check("F023_PRECHECKS_NO_DUP", len(prechecks.get("required", [])) == len(set(prechecks.get("required", []))))
    check("F024_V5_REISSUED", successor.get("decision") == "REISSUE_AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V5_CONDITIONALLY")
    check("F025_V5_IDENTITY", successor.get("execution_identity") == V5_IDENTITY)
    check("F026_V5_ZERO", successor.get("attempt_count") == 0 and successor.get("maximum_attempts") == 1)
    check("F027_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    check("F028_GATES_INCLUDE_PRECHECKS", EXPECTED_PRECHECKS.issubset(gates.get("required", [])))
    check("F029_ATTEMPT_AFTER_GATES", successor.get("attempt_marker_after_all_fresh_gates") is True)
    check("F030_SEPARATE_ACCEPTANCE", successor.get("success_ceiling") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION")
    check("F031_NO_EXECUTION_NOW", authority.get("v5_create_or_execute_now") is False)
    check("F032_NO_WORKER_TARGET", authority.get("worker_codex_daybreak_subagent") is False and authority.get("target_or_external_network") is False)
    check("F033_NO_EXPLOIT_GRAPH", authority.get("exploit_replay") is False and authority.get("parallelism_capability_graph_promotion_submission") is False)
    check("F034_NEXT", next_legal.get("next_legal_milestone") == NEXT_MILESTONE)
    check("F035_FAILED_PACKAGE_IMMUTABLE", digest(FAILED / "GOVERNANCE_LOCK.json") == "a07be1bfa02551365c58ad83827944b06e5898ff5a815bb3013aff904bb503dc")
    check("F036_V4_IMMUTABLE", digest(V4 / "evidence-v4/EVIDENCE_FREEZE_LOCK.json") == "8e8961ca998f486eb1c275bc28f3a0cf50c79fc0bba127f24f8dc979fb40507f")
    check("F037_FIRST_PRIMARY_FAILURE_PRESERVED", primary_first.get("status") == "FAIL_CLOSED" and primary_first.get("checks_total") == 42 and primary_first.get("checks_passed") == 41 and [item.get("check_id") for item in primary_first.get("failed", [])] == ["G021_APP_LIFECYCLE"])
    failures = [item for item in checks if item["status"] != "PASS"]
    freeze = {
        "schema_version": "1.0", "record_type": "FREEZE_VERIFICATION_RESULT",
        "governance_identity": IDENTITY, "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": len(checks) - len(failures),
        "checks_failed": len(failures), "failed": failures, "checks": checks,
        "operation_counters": COUNTERS,
    }
    write("FREEZE_VERIFICATION_RESULT.json", freeze)
    if failures:
        print(json.dumps(freeze, indent=2, sort_keys=True))
        return 1

    names = sorted(PREFREEZE | {"FREEZE_VERIFICATION_RESULT.json"})
    members = []
    lines = []
    for name in names:
        payload = (GOV / name).read_bytes()
        sha = h(payload)
        members.append({"path": name, "bytes": len(payload), "sha256": sha})
        lines.append(f"{sha}  {name}\n")
    member_root = h("".join(lines).encode())
    manifest = {
        "schema_version": "1.0", "record_type": "GOVERNANCE_ARTIFACT_MANIFEST",
        "governance_identity": IDENTITY,
        "canonical_serialization": "LEXICOGRAPHIC_UTF8_SHA256_TWO_SPACES_PATH_NEWLINE",
        "member_count": len(members), "members": members,
        "canonical_member_root_sha256": member_root,
    }
    write("GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    manifest_sha = digest(GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    roots = members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "bytes": (GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size, "sha256": manifest_sha}]
    artifact_root = h("".join(f"{item['sha256']}  {item['path']}\n" for item in sorted(roots, key=lambda item: item["path"])).encode())
    lock = {
        "schema_version": "1.0", "record_type": "GOVERNANCE_LOCK",
        "governance_identity": IDENTITY, "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": successor["decision"],
        "governance_artifact_manifest_sha256": manifest_sha,
        "canonical_member_root_sha256": member_root,
        "canonical_artifact_root_sha256": artifact_root,
        "manifest_member_count": len(members), "artifact_root_member_count": len(roots),
        "validation": {
            "primary": {"passed": primary["checks_passed"], "total": primary["checks_total"]},
            "negative": {"passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent": {"passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"passed": freeze["checks_passed"], "total": freeze["checks_total"]},
        },
        "failed_predecessor_governance": {"status": failed["status"], "effective_authority": "NONE", "final_verification": "39_OF_40_FAIL_CLOSED"},
        "runtime_validation_v4": {"status": v4["status"], "attempt_count": 1, "confinement": "NOT_PROVEN"},
        "runtime_validation_v5": {"status": successor["status"], "execution_identity": V5_IDENTITY, "operation": successor["operation"], "workspace": successor["workspace"], "attempt_count": 0, "maximum_attempts": 1},
        "required_v5_prechecks": prechecks["required"],
        "authority_ceiling": "FRESH_V5_ENGINEERING_AND_ONE_SHOT_VALIDATION_ONLY_AFTER_ALL_FRESH_GATES_NO_WORKER_MODEL_TARGET_NETWORK_OR_EXPLOIT_AUTHORITY",
        "next_legal_milestone": NEXT_MILESTONE,
        "operation_counters": COUNTERS,
    }
    write("GOVERNANCE_LOCK.json", lock)
    for path in GOV.iterdir():
        os.chmod(path, 0o444)
    os.chmod(GOV, 0o555)
    print(json.dumps({
        "status": lock["status"], "validation": lock["validation"],
        "manifest_member_count": len(members), "artifact_root_member_count": len(roots),
        "governance_artifact_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "governance_lock_sha256": digest(GOV / "GOVERNANCE_LOCK.json"),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
