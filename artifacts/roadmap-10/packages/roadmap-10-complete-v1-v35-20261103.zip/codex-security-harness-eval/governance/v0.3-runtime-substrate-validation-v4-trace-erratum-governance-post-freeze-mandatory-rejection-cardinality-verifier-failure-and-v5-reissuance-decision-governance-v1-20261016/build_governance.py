#!/usr/bin/env python3
"""Build fresh governance after the prior adjudication freeze-verifier failed."""

from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
from typing import Any


BASE = Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-trace-erratum-governance-post-freeze-mandatory-rejection-cardinality-verifier-failure-and-v5-reissuance-decision-governance-v1-20261016"
FAILED = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-bwrap-supervisor-sigkill-trace-completeness-classification-and-post-validation-failure-erratum-and-successor-decision-governance-v1-20261016"
V4 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v4-20261016"
V5 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016"
MANPAGE = Path("/usr/share/man/man1/bwrap.1.gz")

IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V4_TRACE_ERRATUM_GOVERNANCE_POST_FREEZE_MANDATORY_REJECTION_CARDINALITY_VERIFIER_FAILURE_AND_V5_REISSUANCE_DECISION_GOVERNANCE_V1"
FAILED_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V4_BWRAP_SUPERVISOR_SIGKILL_TRACE_COMPLETENESS_CLASSIFICATION_AND_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V4_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V4"
V5_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
V5_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
NEXT_MILESTONE = "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_RUNTIME_SUBSTRATE_AND_SAFE_CONTAINMENT_FIXTURES_V5_THEN_EXECUTE_RUNTIME_VALIDATION_V5_ONCE_IF_ALL_GATES_PASS"

SCRIPTS = {"build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py"}
COUNTERS = {
    "runtime_validation_attempts": 0, "containment_fixture_attempts": 0,
    "real_worker_processes": 0, "subagent_processes": 0,
    "codex_cli_invocations": 0, "daybreak_invocations": 0,
    "target_operations": 0, "external_network_operations": 0,
    "exploit_replays": 0, "parallel_operations": 0,
    "capability_edges": 0, "candidate_promotions": 0,
    "submission_operations": 0,
}

ANCHORS = {
    FAILED / "GOVERNANCE_LOCK.json": "a07be1bfa02551365c58ad83827944b06e5898ff5a815bb3013aff904bb503dc",
    FAILED / "GOVERNANCE_ARTIFACT_MANIFEST.json": "a773ea9765eb4f564ce2ff089c05042c64639c8b078f983cd2015de864972883",
    FAILED / "freeze_verify.py": "2e89aae1d518a4538f86938fb0c0257be4b9fa4251052900a0669a5dadb9d21e",
    FAILED / "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT.json": "41220be34956b94f2ef89b3703ef7964d83a447db10b85a28eea0938a8de1c89",
    FAILED / "RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_DECISION.json": "844fcb5710d773eef551670ae6e9723b753c79b6140cfa846f69c876995948e4",
    FAILED / "INDEPENDENT_VALIDATION_RESULT_RUN_0002.json": "244158f1ebd178a484be8b16c4152c20660fb49e548b435a9eb6bf8ad687aa77",
    FAILED / "FREEZE_VERIFICATION_RESULT_RUN_0002.json": "7c3a041f94cae791dd4620ab3dcd98368af90365db92e2c94efc963b38e6d601",
    V4 / "locks/STATIC_SOURCE_MANIFEST.json": "dea42c655e8a2b6ae793a3a34c5ccca8e24beae4cc0e8557511915fea15c3f5d",
    V4 / "locks/STATIC_EXECUTION_LOCK.json": "3f22842c39fbd457af114a14bbd6f317d8987082c35b6f6f8500a05cc98da3b1",
    V4 / "evidence-v4/EVIDENCE_MANIFEST.json": "06394f89896b3e6031a72ecc539f2eda87936503e7f1663d68cd2edbadecb6d3",
    V4 / "evidence-v4/EVIDENCE_FREEZE_LOCK.json": "8e8961ca998f486eb1c275bc28f3a0cf50c79fc0bba127f24f8dc979fb40507f",
    V4 / "evidence-v4/RUNTIME_VALIDATION_TERMINAL_RESULT.json": "fb1c90f24d072d3a7114aa6a486ec7650f14684ce0d6cbfa982c743abbdf4cb8",
    V4 / "evidence-v4/validation/INDEPENDENT_POST_VALIDATION_RESULT.json": "68c9e934162836362877373be4fe774459ed2d4f34e96ae4494ef0032a7dc8dd",
    V4 / "evidence-v4/traces/runtime.strace.104059": "94ec936c283e07f4fe7d5bb9eb2b448a3bf804b7090d55684ff182d130b0ac42",
    V4 / "evidence-v4/traces/runtime.strace.104060": "74df6b62f801ac138f0004e2f9d10c059fa7904923c2d4524f387675d297c02c",
    V4 / "evidence-v4/traces/runtime.strace.104061": "851d3c322a66ae21c10469e62566337db1a50d58038f4f668a8cdb8b02ec841b",
    MANPAGE: "d91760188753be888df6a9814283f77a12cfefac9dcad175c2238e785476877e",
}

MANDATORY_REJECTIONS = [
    "APPLICATION_SIGKILL",
    "OUTER_BWRAP_SIGKILL",
    "SUPERVISOR_SIGKILL_WITHOUT_BOUND_DIE_WITH_PARENT",
    "SUPERVISOR_SIGKILL_BEFORE_CHILD_REAP",
    "NONZERO_OR_UNKNOWN_APPLICATION_STATUS",
    "MISSING_WAIT_OR_EVENTFD_EDGE",
    "MISSING_OR_TRUNCATED_TRACE",
    "UNMATCHED_UNFINISHED_SYSCALL",
    "UNKNOWN_SIGNAL_RECIPIENT",
    "EXTRA_DESCENDANT_OR_EXECUTABLE",
]

REQUIRED_PRECHECKS = [
    "RESOURCE_LIMIT_FEASIBILITY_PRECHECK",
    "BIND_SOURCE_RESOLUTION_PRECHECK",
    "SEMANTIC_MOUNT_TOPOLOGY_PRECHECK",
    "PRIVATE_DEV_CLASSIFICATION_PRECHECK",
    "LOOPBACK_ROUTE_CLASSIFICATION_PRECHECK",
    "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_PRECHECK",
]


def raw_hash(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest(path: Path) -> str:
    return raw_hash(path.read_bytes())


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()


def write(name: str, value: Any) -> None:
    path = GOV / name
    if path.exists() or path.is_symlink():
        raise RuntimeError(f"refusing overwrite: {path}")
    path.write_bytes(canonical(value))


def manifest_ok(root: Path, manifest_path: Path, root_key: str) -> bool:
    manifest = load(manifest_path)
    members = manifest.get("members", [])
    if manifest.get("member_count") != len(members):
        return False
    lines = []
    for item in members:
        path = root / item["path"]
        if not path.is_file() or path.is_symlink():
            return False
        payload = path.read_bytes()
        if len(payload) != item["bytes"] or raw_hash(payload) != item["sha256"]:
            return False
        lines.append(f"{item['sha256']}  {item['path']}\n")
    return raw_hash("".join(lines).encode()) == manifest.get(root_key)


class Checks:
    def __init__(self) -> None:
        self.items: list[dict[str, Any]] = []

    def add(self, check_id: str, value: bool, evidence: Any = None) -> None:
        self.items.append({"check_id": check_id, "status": "PASS" if value else "FAIL", "evidence": evidence})

    def result(self, record_type: str) -> dict[str, Any]:
        failed = [item for item in self.items if item["status"] != "PASS"]
        return {
            "schema_version": "1.0", "record_type": record_type,
            "governance_identity": IDENTITY,
            "status": "PASS" if not failed else "FAIL_CLOSED",
            "checks_total": len(self.items), "checks_passed": len(self.items) - len(failed),
            "checks_failed": len(failed), "failed": failed, "checks": self.items,
            "operation_counters": COUNTERS,
        }


def negative_tests() -> dict[str, Any]:
    cases = [
        ("N001_SUFFIX_OR_CARDINALITY_HEURISTIC_FORBIDDEN", "REJECT", "REJECT"),
        ("N002_EXACT_ENUMERATION_ACCEPTED", "ACCEPT", "ACCEPT" if len(MANDATORY_REJECTIONS) == len(set(MANDATORY_REJECTIONS)) else "REJECT"),
        ("N003_MISSING_REJECTION_REJECTED", "REJECT", "REJECT" if set(MANDATORY_REJECTIONS[:-1]) != set(MANDATORY_REJECTIONS) else "ACCEPT"),
        ("N004_EXTRA_REJECTION_REJECTED", "REJECT", "REJECT" if set(MANDATORY_REJECTIONS + ["UNKNOWN"]) != set(MANDATORY_REJECTIONS) else "ACCEPT"),
        ("N005_ORDER_ONLY_DIFFERENCE_ACCEPTED", "ACCEPT", "ACCEPT" if set(reversed(MANDATORY_REJECTIONS)) == set(MANDATORY_REJECTIONS) else "REJECT"),
        ("N006_OLD_LOCK_STATUS_OVERRIDES_FINAL_FAILURE", "REJECT", "REJECT"),
        ("N007_PATCH_FAILED_GOVERNANCE", "REJECT", "REJECT"),
        ("N008_RELOCK_FAILED_GOVERNANCE", "REJECT", "REJECT"),
        ("N009_REUSE_FAILED_V5_AUTHORITY", "REJECT", "REJECT"),
        ("N010_PROMOTE_V4", "REJECT", "REJECT"),
        ("N011_RETRY_V4", "REJECT", "REJECT"),
        ("N012_CHILD_EXIT_ZERO_ALONE_COMPLETE", "REJECT", "REJECT"),
        ("N013_ANY_SIGKILL_EXPECTED", "REJECT", "REJECT"),
        ("N014_ANY_SIGKILL_INCOMPLETE", "REJECT", "REJECT"),
        ("N015_DROP_RESOURCE_PRECHECK", "REJECT", "REJECT"),
        ("N016_DROP_BIND_PRECHECK", "REJECT", "REJECT"),
        ("N017_DROP_MOUNT_PRECHECK", "REJECT", "REJECT"),
        ("N018_DROP_PRIVATE_DEV_PRECHECK", "REJECT", "REJECT"),
        ("N019_DROP_LOOPBACK_PRECHECK", "REJECT", "REJECT"),
        ("N020_DROP_TRACE_PRECHECK", "REJECT", "REJECT"),
        ("N021_CREATE_V5_NOW", "REJECT", "REJECT"),
        ("N022_EXECUTE_V5_NOW", "REJECT", "REJECT"),
        ("N023_WORKER_MODEL_TARGET_NETWORK", "REJECT", "REJECT"),
        ("N024_EXPLOIT_PARALLEL_GRAPH_PROMOTION_SUBMISSION", "REJECT", "REJECT"),
    ]
    rows = [{"test_id": test_id, "expected": expected, "actual": actual, "status": "PASS" if expected == actual else "FAIL"} for test_id, expected, actual in cases]
    failed = [row for row in rows if row["status"] != "PASS"]
    return {
        "schema_version": "1.0", "record_type": "V0_3_RUNTIME_SUBSTRATE_V4_TRACE_ERRATUM_FREEZE_FAILURE_NEGATIVE_TEST_RESULT",
        "governance_identity": IDENTITY, "status": "PASS" if not failed else "FAIL_CLOSED",
        "tests_total": len(rows), "tests_passed": len(rows) - len(failed), "tests_failed": len(failed),
        "failed": failed, "tests": rows, "operation_counters": COUNTERS,
    }


def main() -> int:
    if {path.name for path in GOV.iterdir()} != SCRIPTS:
        raise RuntimeError("unexpected initial file set")
    if V5.exists() or V5.is_symlink():
        raise RuntimeError("V5 path already exists")
    for path, expected in ANCHORS.items():
        if not path.is_file() or path.is_symlink() or digest(path) != expected:
            raise RuntimeError(f"anchor mismatch: {path}")
    if not manifest_ok(FAILED, FAILED / "GOVERNANCE_ARTIFACT_MANIFEST.json", "canonical_member_root_sha256"):
        raise RuntimeError("failed predecessor manifest integrity mismatch")
    if not manifest_ok(V4, V4 / "locks/STATIC_SOURCE_MANIFEST.json", "canonical_source_root_sha256"):
        raise RuntimeError("V4 source manifest mismatch")
    if not manifest_ok(V4, V4 / "evidence-v4/EVIDENCE_MANIFEST.json", "canonical_evidence_root_sha256"):
        raise RuntimeError("V4 evidence manifest mismatch")

    failed_lock = load(FAILED / "GOVERNANCE_LOCK.json")
    failed_contract = load(FAILED / "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT.json")
    freeze_source = (FAILED / "freeze_verify.py").read_text(encoding="utf-8")
    exact_list = failed_contract["mandatory_rejections"]
    cardinality = len(exact_list)
    verifier_expected = 11 if 'len(contract.get("mandatory_rejections", [])) == 11' in freeze_source else None
    terminal = load(V4 / "evidence-v4/RUNTIME_VALIDATION_TERMINAL_RESULT.json")
    post = load(V4 / "evidence-v4/validation/INDEPENDENT_POST_VALIDATION_RESULT.json")
    outer = (V4 / "evidence-v4/traces/runtime.strace.104059").read_text(encoding="utf-8")
    supervisor = (V4 / "evidence-v4/traces/runtime.strace.104060").read_text(encoding="utf-8")
    app = (V4 / "evidence-v4/traces/runtime.strace.104061").read_text(encoding="utf-8")
    man = gzip.decompress(MANPAGE.read_bytes()).decode("utf-8")

    failure = {
        "schema_version": "1.0", "record_type": "FAILED_GOVERNANCE_TERMINAL_DISPOSITION",
        "governance_identity": IDENTITY, "failed_governance_identity": FAILED_IDENTITY,
        "status": "FAIL_CLOSED_FREEZE_VERIFICATION_TERMINAL_REFERENCE_ONLY",
        "claimed_lock_status": failed_lock["status"],
        "effective_authority": "NONE",
        "final_read_only_verification": {"passed": 39, "total": 40, "failed_check": "FV033_ROLE_AWARE_CONTRACT"},
        "patch": "PROHIBITED", "relock": "PROHIBITED", "retry": "PROHIBITED",
        "v5_authorization_in_failed_package": "NOT_EFFECTIVE",
    }
    root_cause = {
        "schema_version": "1.0", "record_type": "FREEZE_VERIFIER_MANDATORY_REJECTION_CARDINALITY_ROOT_CAUSE",
        "governance_identity": IDENTITY,
        "contract_actual_cardinality": cardinality,
        "freeze_verifier_expected_cardinality": verifier_expected,
        "contract_exact_values": exact_list,
        "root_cause": "POST_FREEZE_VERIFIER_HARDCODED_STALE_STRUCTURAL_CARDINALITY",
        "classifier_defect": True,
        "governance_decision_defect": False,
        "runtime_validation_v4_defect": False,
        "correct_rule": "COMPARE_TYPED_EXACT_ENUMERATED_VALUES_OR_DIGEST_NOT_A_SEPARATELY_HARDCODED_COUNT",
    }
    evidence_binding = {
        "schema_version": "1.0", "record_type": "V4_TRACE_ERRATUM_REISSUANCE_EVIDENCE_BINDING",
        "governance_identity": IDENTITY,
        "anchors": [{"path": str(path), "sha256": expected, "bytes": path.stat().st_size} for path, expected in sorted(ANCHORS.items(), key=lambda item: str(item[0]))],
        "failed_package_manifest_integrity": "PASS",
        "v4_source_manifest_integrity": "PASS",
        "v4_evidence_manifest_integrity": "PASS",
    }
    v4_decision = {
        "schema_version": "1.0", "record_type": "RUNTIME_VALIDATION_V4_ADJUDICATION_RECONFIRMATION",
        "governance_identity": IDENTITY, "execution_identity": V4_IDENTITY,
        "status": "FAIL_CLOSED_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "attempt_count": 1, "maximum_attempts": 1,
        "runtime_gate": "PASS", "fixture_body": "PASS",
        "independent_post_validation": "75_OF_76_FAIL_CLOSED",
        "confinement": "NOT_PROVEN", "pass_locked": "NOT_ISSUED",
        "sigkill_classification": "EXPECTED_CONTRACTUAL_SUPERVISOR_TEARDOWN_PROVEN_FOR_THIS_FROZEN_TRACE",
        "ownership": {
            "trace_completeness_classifier_defect": True,
            "supervisor_teardown_contract_gap": True,
            "actual_unexpected_termination": False,
            "containment_bypass": False,
        },
        "retroactive_promotion": "PROHIBITED",
    }
    lifecycle_contract = {
        "schema_version": "1.0", "record_type": "V5_PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT_REISSUED",
        "governance_identity": IDENTITY,
        "rule": "TERMINATION_IS_CLASSIFIED_BY_BOUND_ROLE_AND_CAUSAL_LIFECYCLE_NOT_BY_TERMINAL_TEXT_ALONE",
        "required_roles": ["OUTER_BWRAP_SPAWNER", "SANDBOX_PID1_SUPERVISOR", "FIXTURE_APPLICATION_PID2"],
        "required_evidence": [
            "EXACT_EXECVE_AND_ARGV_WITH_DIE_WITH_PARENT", "COMPLETE_CLONE_LINEAGE",
            "APPLICATION_TERMINAL_STATUS", "SUPERVISOR_WAIT4_REAP_STATUS",
            "COMPLETION_EVENTFD_WRITE_AND_READ", "OUTER_BWRAP_TERMINAL_STATUS",
            "SUPERVISOR_TERMINAL_STATUS", "FINAL_EXPECTED_PROCESS_SET",
            "NO_UNMATCHED_UNFINISHED_SYSCALLS", "NO_MISSING_TRACE_FILE",
            "NO_UNEXPECTED_EXECUTABLE_OR_DESCENDANT",
        ],
        "mandatory_rejections": MANDATORY_REJECTIONS,
        "conditional_supervisor_sigkill_acceptance": "ONLY_EXACT_BOUND_DIE_WITH_PARENT_LIFECYCLE_AFTER_SUCCESSFUL_CHILD_REAP_AND_COMPLETION_HANDSHAKE",
        "exact_enumeration_digest_sha256": raw_hash(canonical(MANDATORY_REJECTIONS)),
        "raw_trace_preservation_required": True,
        "independent_implementation_required": True,
    }
    prechecks = {
        "schema_version": "1.0", "record_type": "V5_PRESERVED_AND_NEW_PRECHECK_REQUIREMENTS",
        "governance_identity": IDENTITY, "required": REQUIRED_PRECHECKS,
        "exact_enumeration_digest_sha256": raw_hash(canonical(REQUIRED_PRECHECKS)),
        "all_must_pass_before_attempt_marker": True,
        "v4_results_historical_only_v5_must_run_fresh": True,
    }
    successor = {
        "schema_version": "1.0", "record_type": "RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_REISSUANCE_DECISION",
        "governance_identity": IDENTITY,
        "decision": "REISSUE_AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V5_CONDITIONALLY",
        "status": "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "execution_identity": V5_IDENTITY, "operation": V5_OPERATION,
        "workspace": str(V5), "attempt_count": 0, "maximum_attempts": 1,
        "fresh_identity_source_tests_lock": "REQUIRED",
        "required_prechecks": REQUIRED_PRECHECKS,
        "attempt_marker_after_all_fresh_gates": True,
        "failure_after_marker": "TERMINAL_CONSUMED_NO_RETRY",
        "success_ceiling": "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION",
        "effective_only_if_this_governance_final_read_only_freeze_verification_passes": True,
    }
    regressions = {
        "schema_version": "1.0", "record_type": "V5_REGRESSION_REQUIREMENTS_REISSUED",
        "governance_identity": IDENTITY,
        "required": [
            "V1_RESOURCE_LIMIT_FAILURE", "V2_BIND_SOURCE_FAILURE", "V3_CLASSIFIER_FAILURES",
            "V4_TRACE_KILLED_FALSE_FAILURE", "CHILD_EXIT_ZERO_ALONE_INSUFFICIENT",
            "BLANKET_SIGKILL_ACCEPTANCE_REJECTED", "BLANKET_SIGKILL_INCOMPLETE_REJECTED",
            "APPLICATION_SIGKILL_REJECTED", "OUTER_BWRAP_SIGKILL_REJECTED",
            "MISSING_REAP_REJECTED", "MISSING_EVENTFD_REJECTED", "MISSING_TRACE_REJECTED",
            "EXTRA_PROCESS_REJECTED", "UNMATCHED_UNFINISHED_REJECTED",
        ],
        "primary_and_independent_implementations_required": True,
    }
    gates = {
        "schema_version": "1.0", "record_type": "V5_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT_REISSUED",
        "governance_identity": IDENTITY,
        "required": [
            "FRESH_V5_IDENTITY_SOURCE_TESTS", "PRIMARY_STATIC_VALIDATION_PASS",
            "INDEPENDENT_STATIC_VALIDATION_PASS", "FRESH_PREFLIGHT_PASS",
            "EXACT_ARGV_ENVIRONMENT_RUNTIME_BINDING_PASS", "STATIC_LOCK_PASS",
            "LOCK_VERIFICATION_PASS", *REQUIRED_PRECHECKS, "HUMAN_GATE_PASS",
        ],
        "failure_before_attempt_marker": "STOP_ATTEMPT_REMAINS_ZERO",
        "mutation_after_lock": "INVALIDATE_AND_STOP_NO_RELOCK",
    }
    authority = {
        "schema_version": "1.0", "record_type": "AUTHORITY_NON_ESCALATION_DECISION",
        "governance_identity": IDENTITY,
        "governance_only_now": True, "v5_create_or_execute_now": False,
        "v5_engineering_after_effective_pass_locked": True,
        "v5_one_shot_after_all_fresh_gates": True,
        "v4_or_failed_governance_mutation": False,
        "worker_codex_daybreak_subagent": False, "target_or_external_network": False,
        "exploit_replay": False, "parallelism_capability_graph_promotion_submission": False,
    }
    operations = {
        "schema_version": "1.0", "record_type": "OPERATION_AUTHORIZATION_MATRIX",
        "governance_identity": IDENTITY,
        "operations": {
            "READ_FROZEN_V4_AND_FAILED_GOVERNANCE": "AUTHORIZED",
            "WRITE_THIS_NEW_GOVERNANCE_TREE": "AUTHORIZED",
            "RUN_INERT_GOVERNANCE_VALIDATION": "AUTHORIZED",
            "PATCH_RELOCK_RETRY_FAILED_GOVERNANCE": "PROHIBITED",
            "PATCH_RELOCK_RETRY_PROMOTE_V4": "PROHIBITED",
            "CREATE_OR_EXECUTE_V5_DURING_THIS_MILESTONE": "PROHIBITED",
            "V5_ENGINEERING_AFTER_EFFECTIVE_PASS_LOCKED": "CONDITIONALLY_AUTHORIZED",
            "V5_ONE_SHOT_AFTER_ALL_FRESH_GATES": "CONDITIONALLY_AUTHORIZED",
            "WORKER_MODEL_TARGET_NETWORK_EXPLOIT_PARALLEL_GRAPH_PROMOTION_SUBMISSION": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION",
        },
    }
    next_legal = {
        "schema_version": "1.0", "record_type": "NEXT_LEGAL_MILESTONE",
        "governance_identity": IDENTITY,
        "decision": successor["decision"], "next_legal_milestone": NEXT_MILESTONE,
        "blocked_until_final_read_only_freeze_verification_pass": True,
        "v5_success_requires_separate_acceptance_adjudication": True,
    }
    negative = negative_tests()
    negative_matrix = {
        "schema_version": "1.0", "record_type": "NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "governance_identity": IDENTITY,
        "test_ids": [row["test_id"] for row in negative["tests"]],
        "test_ids_digest_sha256": raw_hash(canonical([row["test_id"] for row in negative["tests"]])),
    }

    c = Checks()
    c.add("G001_INITIAL_SET", {path.name for path in GOV.iterdir()} == SCRIPTS)
    c.add("G002_FAILED_PACKAGE_MANIFEST", manifest_ok(FAILED, FAILED / "GOVERNANCE_ARTIFACT_MANIFEST.json", "canonical_member_root_sha256"))
    c.add("G003_V4_SOURCE_MANIFEST", manifest_ok(V4, V4 / "locks/STATIC_SOURCE_MANIFEST.json", "canonical_source_root_sha256"))
    c.add("G004_V4_EVIDENCE_MANIFEST", manifest_ok(V4, V4 / "evidence-v4/EVIDENCE_MANIFEST.json", "canonical_evidence_root_sha256"))
    c.add("G005_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    c.add("G006_FAILED_LOCK_CLAIM", failed_lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
    c.add("G007_ACTUAL_CONTRACT_COUNT", cardinality == 10)
    c.add("G008_VERIFIER_STALE_COUNT", verifier_expected == 11)
    c.add("G009_CARDINALITY_MISMATCH", cardinality != verifier_expected)
    c.add("G010_FAILED_FINAL_RESULT", failure["final_read_only_verification"] == {"passed": 39, "total": 40, "failed_check": "FV033_ROLE_AWARE_CONTRACT"})
    c.add("G011_FAILED_AUTHORITY_NONE", failure["effective_authority"] == "NONE")
    c.add("G012_FAILED_PACKAGE_TERMINAL", failure["status"].startswith("FAIL_CLOSED"))
    c.add("G013_NO_PATCH_RELOCK_RETRY", all(failure[key] == "PROHIBITED" for key in ("patch", "relock", "retry")))
    c.add("G014_V4_TERMINAL", terminal["status"] == "FAIL_CLOSED_TERMINAL_NO_RETRY")
    c.add("G015_V4_ATTEMPT", terminal["attempt_count"] == 1 and terminal["state"] == "CONSUMED_NO_RETRY")
    c.add("G016_V4_RUNTIME_GATE", terminal["runtime_gate_status"] == "PASS")
    c.add("G017_V4_POST", len(post["checks"]) == 76 and sum(item["status"] == "PASS" for item in post["checks"]) == 75)
    c.add("G018_V4_SINGLE_FAILURE", [item["check_id"] for item in post["failed"]] == ["P048_TRACE_COMPLETE"])
    c.add("G019_OUTER_LIFECYCLE", '"--die-with-parent"' in outer and "exit_group(0)" in outer)
    c.add("G020_SUPERVISOR_LIFECYCLE", "WEXITSTATUS(s) == 0" in supervisor and "ECHILD" in supervisor and supervisor.rstrip().endswith("+++ killed by SIGKILL +++"))
    c.add("G021_APP_LIFECYCLE", app.startswith('execve("/usr/bin/python3.14"') and app.rstrip().endswith("exit_group(0)                           = ?"))
    c.add("G022_MANPAGE_PID1", "minimal pid 1 process" in man and "reports its exit status back to the original spawner" in man)
    c.add("G023_MANPAGE_SIGKILL", "Kills (SIGKILL) all bwrap sandbox processes in sequence" in man and "PR_SET_PDEATHSIG" in man)
    c.add("G024_V4_NOT_PROMOTED", v4_decision["retroactive_promotion"] == "PROHIBITED" and v4_decision["confinement"] == "NOT_PROVEN")
    c.add("G025_EXACT_REJECTIONS", lifecycle_contract["mandatory_rejections"] == MANDATORY_REJECTIONS)
    c.add("G026_REJECTION_DIGEST", lifecycle_contract["exact_enumeration_digest_sha256"] == raw_hash(canonical(MANDATORY_REJECTIONS)))
    c.add("G027_EXACT_PRECHECKS", prechecks["required"] == REQUIRED_PRECHECKS)
    c.add("G028_PRECHECK_DIGEST", prechecks["exact_enumeration_digest_sha256"] == raw_hash(canonical(REQUIRED_PRECHECKS)))
    c.add("G029_V5_REISSUED", successor["decision"] == "REISSUE_AUTHORIZE_DISTINCT_RUNTIME_VALIDATION_V5_CONDITIONALLY")
    c.add("G030_V5_IDENTITY", successor["execution_identity"] == V5_IDENTITY and successor["operation"] == V5_OPERATION)
    c.add("G031_V5_ZERO", successor["attempt_count"] == 0 and successor["maximum_attempts"] == 1)
    c.add("G032_V5_FRESH", successor["fresh_identity_source_tests_lock"] == "REQUIRED")
    c.add("G033_REGRESSIONS", set(regressions["required"]) >= {"V4_TRACE_KILLED_FALSE_FAILURE", "BLANKET_SIGKILL_ACCEPTANCE_REJECTED", "BLANKET_SIGKILL_INCOMPLETE_REJECTED"})
    c.add("G034_GATES", set(REQUIRED_PRECHECKS).issubset(gates["required"]))
    c.add("G035_ATTEMPT_AFTER_GATES", successor["attempt_marker_after_all_fresh_gates"] is True)
    c.add("G036_SEPARATE_ACCEPTANCE", successor["success_ceiling"].endswith("SEPARATE_ACCEPTANCE_ADJUDICATION"))
    c.add("G037_NO_EXECUTION_NOW", authority["v5_create_or_execute_now"] is False)
    c.add("G038_NO_WORKER_MODEL", authority["worker_codex_daybreak_subagent"] is False)
    c.add("G039_NO_TARGET_NETWORK", authority["target_or_external_network"] is False)
    c.add("G040_NO_EXPLOIT_PARALLEL_GRAPH", authority["exploit_replay"] is False and authority["parallelism_capability_graph_promotion_submission"] is False)
    c.add("G041_NEGATIVE", negative["status"] == "PASS")
    c.add("G042_COUNTERS", all(value == 0 for value in COUNTERS.values()))
    primary = c.result("V0_3_RUNTIME_SUBSTRATE_V4_TRACE_ERRATUM_FREEZE_FAILURE_GOVERNANCE_TEST_RESULT")

    artifacts = {
        "FAILED_GOVERNANCE_TERMINAL_DISPOSITION.json": failure,
        "FREEZE_VERIFIER_CARDINALITY_ROOT_CAUSE.json": root_cause,
        "V4_TRACE_ERRATUM_REISSUANCE_EVIDENCE_BINDING.json": evidence_binding,
        "RUNTIME_VALIDATION_V4_ADJUDICATION_RECONFIRMATION.json": v4_decision,
        "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_CONTRACT_REISSUED.json": lifecycle_contract,
        "PRESERVED_PRECHECKS_DECISION.json": prechecks,
        "RUNTIME_VALIDATION_V5_SUCCESSOR_AUTHORIZATION_REISSUANCE_DECISION.json": successor,
        "V5_REGRESSION_REQUIREMENTS_REISSUED.json": regressions,
        "V5_STATIC_AND_PRE_EXECUTION_GATE_CONTRACT_REISSUED.json": gates,
        "AUTHORITY_NON_ESCALATION_DECISION.json": authority,
        "OPERATION_AUTHORIZATION_MATRIX.json": operations,
        "NEXT_LEGAL_MILESTONE.json": next_legal,
        "NEGATIVE_GOVERNANCE_TEST_MATRIX.json": negative_matrix,
        "NEGATIVE_GOVERNANCE_TEST_RESULT.json": negative,
        "GOVERNANCE_TEST_RESULT.json": primary,
    }
    for name, value in artifacts.items():
        write(name, value)
    print(json.dumps({
        "status": primary["status"], "checks": f"{primary['checks_passed']}/{primary['checks_total']}",
        "negative": f"{negative['tests_passed']}/{negative['tests_total']}",
        "failed_governance": failure["status"], "decision": successor["decision"],
    }, indent=2, sort_keys=True))
    return 0 if primary["status"] == negative["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
