#!/usr/bin/env python3
"""Create the declarative V12 continuation-provenance governance package."""
from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONTINUATION_RUN_SLOT_AND_"
    "STATIC_LOCK_PROVENANCE_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_"
    "GOVERNANCE_ONLY"
)
DECISION = "CONTINUATION_V12_VALIDATION_AND_STATIC_LOCK_PROVENANCE_CORRECTION_AUTHORIZED"
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
I006_GOV = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v12-independent-validator-v11-tree-"
    "canonicalization-mismatch-prelock-erratum-and-continuation-or-successor-decision-"
    "governance-v1-20261023"
)

MUTABLE = [
    "bind_authoritative_artifact_digests.py",
    "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json",
    "contracts/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CONTRACT.json",
    "preflight.py",
    "prepare_static_lock.py",
    "schemas/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE.schema.json",
    "src/invocation_v12.py",
    "tests/run_unit_fixtures.py",
    "validators/independent_static_validate.py",
    "validators/primary_static_validate.py",
    "verify_static_lock.py",
]


def write(name: str, value: object) -> None:
    path = ROOT / name
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def common(record_type: str) -> dict[str, object]:
    return {
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "record_type": record_type,
    }


def main() -> int:
    charter = {
        **common("GOVERNANCE_CHARTER"),
        "milestone_type": "GOVERNANCE_ONLY_ADJUDICATION",
        "scope": "V12_CONTINUATION_RUN_SLOT_AND_STATIC_LOCK_PROVENANCE_ONLY",
        "v12_workspace": str(V12),
        "entry_state": "FAIL_CLOSED_PRELOCK_CONTINUATION_EVIDENCE_PROVENANCE_GAP",
        "static_lock": "NOT_ISSUED",
        "attempt": "0/1",
        "worker_invocation": "0/1",
        "codex_as_worker_invocation": "0/1",
        "current_milestone_authorizes_execution": False,
        "prohibited_during_governance": [
            "PATCH_V12_VALIDATION_OR_LOCK_PREPARATION_CODE",
            "RERUN_PRIMARY_OR_INDEPENDENT_VALIDATION",
            "FRESH_PREFLIGHT",
            "STATIC_LOCK_ISSUANCE",
            "SECURITY_WORKER_INVOCATION",
            "CODEX_INVOCATION",
            "TARGET_OR_NETWORK_ACCESS",
            "CREDENTIAL_USE",
            "SUBAGENT_OR_PARALLEL_EXECUTION",
        ],
        "freeze_gate": [
            "PRIMARY_GOVERNANCE_VALIDATION_PASS",
            "NEGATIVE_FIXTURES_PASS",
            "INDEPENDENT_GOVERNANCE_VALIDATION_PASS",
            "READ_ONLY_INTEGRITY_PASS",
            "FINAL_FREEZE_VERIFICATION_PASS",
        ],
    }
    evidence = {
        **common("V12_PRELOCK_EVIDENCE_BINDING"),
        "v12_tree_root_algorithm": "SHA256_OF_UTF8_ROWS_SHA256_TWO_SPACES_POSIX_PATH_LF_SORTED_BY_PATH_BYTES",
        "v12_tree_root_sha256": "7a2c2e39fe9c7cda6cc04f4d104e096737ceddf4d48a8548e8462587fced2392",
        "v12_member_count": 56,
        "i006_governance": {
            "lock_path": str(I006_GOV / "GOVERNANCE_LOCK.json"),
            "lock_sha256": "273dbf72a536eb2c66e56d3f3a5751660a6bd86f8b3ca2ddd9bf9f43d8fae30e",
            "decision": "CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AUTHORIZED",
            "source_mutation_allowlist": [
                "tests/run_unit_fixtures.py",
                "validators/independent_static_validate.py",
            ],
        },
        "historical_validation": {
            "unit_run_0001": {"status": "PASS_77_OF_77", "sha256": "b429af4eaff9403139ef41ba9145436ab4dac8778139d5b93f0e5ea632d3c36d"},
            "primary_run_0001": {"status": "PASS_95_OF_95", "sha256": "81f3f6a449cf11dbc4faba8a070638fac2406e461d15e9753e89ba821d9e41ac"},
            "independent_run_0001": {"status": "FAIL_CLOSED_56_OF_57_I006", "sha256": "56b1b6572dec7d83afbab91f427a336f7897db1fd5de94c2e3a14fee1a09346f"},
        },
        "partial_i006_continuation": {
            "unit_run_0002": {"status": "PASS_85_OF_85", "sha256": "ebd5ff3a8251f59ae617bf0acfaa09f29f043bfb5bd000ee97b603cd056d3838"},
            "primary_run_0002": "NOT_CREATED_FILE_EXISTS_ERROR_ON_RUN_0001",
            "independent_run_0002": "NOT_CREATED",
            "role": "IMMUTABLE_INCOMPLETE_CONTINUATION_HISTORY_NOT_CURRENT_READINESS",
        },
        "authorized_source_changes": {
            "tests/run_unit_fixtures.py": "801d08c032ecfd43d9e23f8d782839c97d74f560e5aa11ea34759c4df05afd39",
            "validators/independent_static_validate.py": "4279fc1dc7d44ae3d38226aff16188626f873d370ab9bcd858a9a549abd57fa0",
        },
        "protected_drift_count": 0,
        "static_lock": "NOT_ISSUED",
        "attempt_marker": "ABSENT",
        "runtime_result": "ABSENT",
    }
    ownership = {
        **common("DEFECT_OWNERSHIP_DECISION"),
        "PRIMARY_CONTINUATION_RUN_SLOT_DEFECT": "YES",
        "STATIC_LOCK_CONTINUATION_PROVENANCE_BINDING_GAP": "YES",
        "I006_CANONICALIZATION_CORRECTION_DEFECT": "NO_CURRENT_CORRECTION_IS_WITHIN_AUTHORIZED_SCOPE",
        "WORKER_DEFECT": "NOT_ESTABLISHED_NO_EXECUTION",
        "CODEX_DEFECT": "NOT_ESTABLISHED_NO_EXECUTION",
        "TEMPORAL_OBSERVER_RUNTIME": "NOT_ESTABLISHED",
        "CONFINEMENT": "NOT_PROVEN",
        "facts": [
            "PRIMARY_VALIDATOR_OUTPUT_IS_HARDCODED_TO_RUN_0001",
            "RUN_0001_ALREADY_EXISTS_AND_APPEND_ONLY_WRITER_USES_EXCLUSIVE_CREATION",
            "PREPARE_STATIC_LOCK_BINDS_RUN_0001_AS_CURRENT_READINESS",
            "HISTORICAL_INDEPENDENT_RUN_0001_IS_FAIL_CLOSED",
        ],
        "causal_history_beyond_frozen_evidence": "NOT_INFERRED",
    }
    model = {
        **common("NORMATIVE_CONTINUATION_EVIDENCE_MODEL"),
        "history_model": "APPEND_ONLY_VERSIONED_VALIDATION_EVIDENCE",
        "historical_run_0001": {
            "role": "IMMUTABLE_HISTORICAL_EVIDENCE",
            "overwrite_delete_rename_reclassify_or_retroactive_pass": "PROHIBITED",
        },
        "partial_run_0002": {
            "role": "IMMUTABLE_INCOMPLETE_I006_CONTINUATION_HISTORY",
            "current_readiness_eligible": False,
            "reason": "UNIT_EXISTS_BUT_PRIMARY_AND_INDEPENDENT_CHAIN_DID_NOT_COMPLETE",
        },
        "fresh_current_chain": {
            "selected_slot": "run-0003",
            "reason": "THE_CORRECTION_CHANGES_VALIDATION_AND_LOCK_PROVENANCE_CODE_AFTER_UNIT_RUN_0002; FULL_CHAIN_MUST_RERUN_WITHOUT_REUSING_EARLIER_PASS",
            "required": [
                "unit-fixtures-run-0003.json",
                "primary-static-validation-run-0003.json",
                "independent-static-validation-run-0003.json",
                "fresh-preflight-run-0003.json",
                "dependency-closure-run-0003.json",
            ],
            "supersedes_history_for": "CURRENT_EXECUTION_READINESS_ONLY",
            "historical_evidence_remains_admissible": True,
        },
        "selection": {
            "explicit": True,
            "governance_bound": True,
            "unique": True,
            "digest_verified": True,
            "highest_filename_or_newest_timestamp_inference": "PROHIBITED",
        },
    }
    chain = {
        **common("STATIC_LOCK_PROVENANCE_CHAIN_CONTRACT"),
        "ordered_chain": [
            "IMMUTABLE_V12_RUN_0001_VALIDATION_EVIDENCE",
            "I006_GOVERNANCE_AUTHORIZATION_LOCK",
            "EXACT_TWO_FILE_I006_CORRECTION",
            "IMMUTABLE_PARTIAL_RUN_0002_HISTORY",
            "THIS_CONTINUATION_PROVENANCE_GOVERNANCE_LOCK",
            "EXACT_MINIMAL_PROVENANCE_CORRECTION",
            "FULL_UNIT_PRIMARY_INDEPENDENT_RUN_0003_CHAIN",
            "FRESH_PREFLIGHT_RUN_0003",
            "DEPENDENCY_CLOSURE_RUN_0003",
            "ALL_APPLICABLE_GOVERNANCE_SCOPE_LOCKS",
            "STATIC_EXECUTION_LOCK",
        ],
        "fail_closed_conditions": [
            "HISTORICAL_EVIDENCE_MISSING_OR_MODIFIED",
            "CONTINUATION_EVIDENCE_WITHOUT_EXACT_GOVERNANCE_AUTHORITY",
            "EVIDENCE_PRODUCED_BEFORE_AUTHORIZATION",
            "AMBIGUOUS_CURRENT_EVIDENCE_SELECTION",
            "HISTORICAL_FAIL_SELECTED_AS_CURRENT_READINESS",
            "PARTIAL_RUN_0002_SELECTED_AS_COMPLETE_READINESS",
            "PROTECTED_MEMBER_DRIFT",
            "MUTATION_OUTSIDE_EXACT_ALLOWLIST",
            "CURRENT_EVIDENCE_DIGEST_MISMATCH",
        ],
    }
    scope = {
        **common("CONTINUATION_V12_EXACT_MUTATION_SCOPE_LOCK"),
        "status": "NORMATIVE_FOR_AUTHORIZED_CONTINUATION",
        "mutable_allowlist": MUTABLE,
        "new_file_allowlist": [
            "contracts/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CONTRACT.json",
            "schemas/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE.schema.json",
        ],
        "append_only_output_allowlist": [
            "results/prelock/unit-fixtures-run-0003.json",
            "results/prelock/primary-static-validation-run-0003.json",
            "results/prelock/independent-static-validation-run-0003.json",
            "results/prelock/fresh-preflight-run-0003.json",
            "results/prelock/dependency-closure-run-0003.json",
            "STATIC_SOURCE_MANIFEST.json",
            "STATIC_EXECUTION_LOCK.json",
            "STATIC_EXECUTION_LOCK_VERIFICATION.json",
        ],
        "allowed_change_classes": [
            "CONTINUATION_AWARE_RUN_SLOT_SELECTION",
            "EXPLICIT_GOVERNANCE_BOUND_CURRENT_READINESS_SELECTION",
            "HISTORICAL_PLUS_CURRENT_STATIC_LOCK_PROVENANCE",
            "EXACT_GOVERNANCE_DIGEST_BINDING",
            "PROVENANCE_REGRESSION_FIXTURES",
            "DEPENDENCY_CLOSURE_FOR_EXACT_NEW_CONTRACT_AND_SCHEMA",
        ],
        "must_not_change": [
            "src/runner_v12.py",
            "src/topology_observer_v12.py",
            "src/worker_launch_gate_v12.py",
            "src/short_lived_child_v12.py",
            "contracts/WORKER_REQUEST.json",
            "contracts/IDENTITY_BINDINGS.json",
            "contracts/EXECUTION_CONTRACT.json",
            "contracts/EXPECTED_EXECUTION_PLAN.json",
            "contracts/SELFTEST_LIFECYCLE_EVIDENCE_CONTRACT.json",
            "contracts/TEMPORAL_PROCESS_IDENTITY_OBSERVER_CONTRACT.json",
            "fixture/worker-prompt.txt",
            "runtime-config-candidate/config.toml",
            "HUMAN_GATE.json",
            "CODEX_RUNTIME_BINDING",
            "V11_PREDECESSOR_ARTIFACTS",
            "EXECUTION_SEMANTICS",
        ],
        "all_unlisted_mutations": "PROHIBITED",
        "scope_violation": "STOP_FAIL_CLOSED_REQUIRE_NEW_GOVERNANCE",
    }
    regressions = {
        **common("CONTINUATION_PROVENANCE_REGRESSION_MATRIX"),
        "cases": [
            {"id": "N001", "case": "IMMUTABLE_RUN_0001_PLUS_AUTHORIZED_COMPLETE_CURRENT_CHAIN", "expected": "PASS_SELECT_EXPLICIT_CURRENT_AND_PRESERVE_HISTORY"},
            {"id": "N002", "case": "UNAUTHORIZED_RUN_0002_OR_RUN_0003", "expected": "FAIL_CLOSED"},
            {"id": "N003", "case": "MISSING_HISTORICAL_EVIDENCE", "expected": "FAIL_CLOSED"},
            {"id": "N004", "case": "ATTEMPTED_OVERWRITE_DELETE_RENAME_OR_RECLASSIFY_RUN_0001", "expected": "FAIL_CLOSED"},
            {"id": "N005", "case": "AMBIGUOUS_CURRENT_CONTINUATION_EVIDENCE", "expected": "FAIL_CLOSED"},
            {"id": "N006", "case": "CURRENT_PASS_WITHOUT_EXACT_GOVERNANCE_LINEAGE", "expected": "FAIL_CLOSED"},
            {"id": "N007", "case": "STATIC_LOCK_SELECTS_HISTORICAL_FAIL_INSTEAD_OF_AUTHORIZED_CURRENT_PASS", "expected": "FAIL_CLOSED"},
            {"id": "N008", "case": "EXACT_APPEND_ONLY_PROVENANCE_PRESERVATION", "expected": "PASS"},
            {"id": "N009", "case": "PARTIAL_RUN_0002_SELECTED_AS_COMPLETE_CHAIN", "expected": "FAIL_CLOSED"},
            {"id": "N010", "case": "CURRENT_EVIDENCE_PREDATES_GOVERNANCE_AUTHORIZATION", "expected": "FAIL_CLOSED"},
            {"id": "N011", "case": "PROTECTED_MEMBER_DRIFT_OR_OUT_OF_SCOPE_MUTATION", "expected": "FAIL_CLOSED"},
            {"id": "N012", "case": "STATIC_LOCK_OMITS_ANY_ORDERED_PROVENANCE_EDGE", "expected": "FAIL_CLOSED"},
        ],
        "all_cases_required": True,
    }
    decision = {
        **common("CONTINUATION_DECISION"),
        "decision": DECISION,
        "reason": "PRELOCK_ATTEMPT_ZERO_AND_DEFECT_IS_NARROWLY_SCOPED_TO_APPEND_ONLY_VALIDATION_RUN_SLOTS_AND_STATIC_LOCK_PROVENANCE",
        "v12": "CONTINUATION_AUTHORIZED_NOT_CORRECTED_NOT_REVALIDATED_NOT_LOCKED_NOT_EXECUTED",
        "v13": "NOT_AUTHORIZED",
        "current_milestone_performs_correction": False,
        "current_milestone_performs_validation_rerun": False,
        "current_milestone_issues_static_lock": False,
        "current_milestone_performs_execution": False,
        "next_action_requires_exact_scope_lock": True,
    }
    authority = {
        **common("AUTHORITY_NON_ESCALATION_DECISION"),
        "implementation_authority": "ONLY_EXACT_CONTINUATION_PROVENANCE_CORRECTION_AFTER_GOVERNANCE_FREEZE",
        "worker_execution_authority": "NOT_GRANTED_BY_THIS_GOVERNANCE",
        "codex_invocation_authority": "NOT_GRANTED_BY_THIS_GOVERNANCE",
        "target_network_credential_subagent_parallelism_exploit_capability_promotion_submission": "NOT_AUTHORIZED",
        "attempt": "0/1",
    }
    routing = {
        **common("ROUTING_LEDGER"),
        "active": [
            "mandatory-auto-router",
            "authorized-security-autopilot",
            "codex-security-harness",
            "agentic-security-research-harness",
        ],
        "deferred": ["program-impact-boundary-gate", "counterfactual-methodology-synthesizer"],
        "not_applicable": [
            "external-ai-security-tool-governor",
            "awesome-bugbounty-tools-catalog",
            "webhacklist-2026-research-corpus",
            "live-target-specialists",
            "multi-agent-orchestrators",
        ],
        "operations": {"external_network": 0, "credential_use": 0, "target_access": 0, "subagents": 0, "codex_invocations": 0},
    }
    next_milestone = {
        **common("NEXT_LEGAL_MILESTONE"),
        "only_if_status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "milestone": "CONTINUE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_VALIDATION_AND_STATIC_LOCK_PROVENANCE_CORRECTION_ONLY",
        "ordered_actions": [
            "PATCH_EXACT_MUTATION_ALLOWLIST_ONLY",
            "CREATE_EXACT_NEW_CONTRACT_AND_SCHEMA",
            "RUN_FULL_UNIT_PRIMARY_INDEPENDENT_CHAIN_IN_FRESH_RUN_0003_SLOTS",
            "VERIFY_MUTATION_SCOPE_AND_IMMUTABLE_HISTORY",
            "RUN_FRESH_PREFLIGHT_RUN_0003",
            "RUN_DEPENDENCY_CLOSURE_RUN_0003",
            "PREPARE_AND_ISSUE_STATIC_LOCK",
            "VERIFY_STATIC_LOCK_AND_PROVENANCE_CHAIN",
            "POST_LOCK_VALIDATION",
        ],
        "execution_after_correction": "ONLY_IF_ALL_PREATTEMPT_GATES_PASS_UNDER_EXISTING_V12_ONE_SHOT_AUTHORITY",
    }

    for name, value in {
        "GOVERNANCE_CHARTER.json": charter,
        "V12_PRELOCK_EVIDENCE_BINDING.json": evidence,
        "DEFECT_OWNERSHIP_DECISION.json": ownership,
        "NORMATIVE_CONTINUATION_EVIDENCE_MODEL.json": model,
        "STATIC_LOCK_PROVENANCE_CHAIN_CONTRACT.json": chain,
        "CONTINUATION_V12_SCOPE_LOCK.json": scope,
        "CONTINUATION_REGRESSION_MATRIX.json": regressions,
        "CONTINUATION_DECISION.json": decision,
        "AUTHORITY_NON_ESCALATION_DECISION.json": authority,
        "ROUTING_LEDGER.json": routing,
        "NEXT_LEGAL_MILESTONE.json": next_milestone,
    }.items():
        write(name, value)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
