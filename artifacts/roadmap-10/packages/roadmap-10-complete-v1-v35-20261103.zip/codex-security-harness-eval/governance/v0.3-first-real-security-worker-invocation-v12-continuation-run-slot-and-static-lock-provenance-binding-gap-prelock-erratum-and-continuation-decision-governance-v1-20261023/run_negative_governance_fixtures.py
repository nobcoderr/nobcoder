#!/usr/bin/env python3
"""Model the fail-closed continuation evidence selector independently of V12 code."""
from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONTINUATION_RUN_SLOT_AND_STATIC_LOCK_PROVENANCE_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"


def verdict(*, history: bool = True, history_exact: bool = True, authority: bool = True,
            after_authority: bool = True, candidates: int = 1, selected_pass: bool = True,
            selected_complete: bool = True, selected_historical_fail: bool = False,
            scope: bool = True, chain_complete: bool = True) -> str:
    ok = all((history, history_exact, authority, after_authority, candidates == 1,
              selected_pass, selected_complete, not selected_historical_fail, scope, chain_complete))
    return "PASS" if ok else "FAIL_CLOSED"


def main() -> int:
    cases = [
        ("N001", {}, "PASS"),
        ("N002", {"authority": False}, "FAIL_CLOSED"),
        ("N003", {"history": False}, "FAIL_CLOSED"),
        ("N004", {"history_exact": False}, "FAIL_CLOSED"),
        ("N005", {"candidates": 2}, "FAIL_CLOSED"),
        ("N006", {"authority": False, "selected_pass": True}, "FAIL_CLOSED"),
        ("N007", {"selected_historical_fail": True}, "FAIL_CLOSED"),
        ("N008", {"history": True, "history_exact": True}, "PASS"),
        ("N009", {"selected_complete": False}, "FAIL_CLOSED"),
        ("N010", {"after_authority": False}, "FAIL_CLOSED"),
        ("N011", {"scope": False}, "FAIL_CLOSED"),
        ("N012", {"chain_complete": False}, "FAIL_CLOSED"),
    ]
    rows = []
    for case_id, changes, expected in cases:
        actual = verdict(**changes)
        rows.append({"id": case_id, "expected": expected, "actual": actual, "status": "PASS" if actual == expected else "FAIL"})
    failures = [row["id"] for row in rows if row["status"] == "FAIL"]
    result = {
        "record_type": "NEGATIVE_GOVERNANCE_TEST_RESULT",
        "governance_identity": IDENTITY,
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "cases": rows,
        "failure_ids": failures,
        "validation_counts": {"total": len(rows), "passed": len(rows) - len(failures), "failed": len(failures)},
    }
    with (ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
