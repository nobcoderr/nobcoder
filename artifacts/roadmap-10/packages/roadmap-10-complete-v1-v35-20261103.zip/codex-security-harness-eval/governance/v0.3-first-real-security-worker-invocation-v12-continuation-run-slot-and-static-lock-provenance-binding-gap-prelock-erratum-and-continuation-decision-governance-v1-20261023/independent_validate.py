#!/usr/bin/env python3
"""Independent governance validation using direct V12 and artifact inspection."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
I006 = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-v12-independent-validator-v11-tree-canonicalization-mismatch-prelock-erratum-and-continuation-or-successor-decision-governance-v1-20261023")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONTINUATION_RUN_SLOT_AND_STATIC_LOCK_PROVENANCE_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"


def read(name: str) -> dict:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_v12() -> tuple[str, int]:
    rows: list[tuple[bytes, str, str]] = []
    for path in V12.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"symlink: {path}")
        if path.is_file():
            relative = path.relative_to(V12).as_posix()
            rows.append((relative.encode("utf-8"), relative, digest(path)))
    rows.sort(key=lambda row: row[0])
    serialized = "".join(f"{member_digest}  {relative}\n" for _, relative, member_digest in rows).encode("utf-8")
    return hashlib.sha256(serialized).hexdigest(), len(rows)


def main() -> int:
    checks: list[dict[str, object]] = []
    def check(name: str, ok: bool, evidence: object = None) -> None:
        checks.append({"id": name, "status": "PASS" if ok else "FAIL", "evidence": evidence})

    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negatives = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    model = read("NORMATIVE_CONTINUATION_EVIDENCE_MODEL.json")
    chain = read("STATIC_LOCK_PROVENANCE_CHAIN_CONTRACT.json")
    scope = read("CONTINUATION_V12_SCOPE_LOCK.json")
    decision = read("CONTINUATION_DECISION.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    root_digest, count = canonical_v12()

    check("I001_PRIMARY_PASS", primary.get("status") == "PASS")
    check("I002_NEGATIVE_PASS", negatives.get("status") == "PASS" and negatives.get("validation_counts", {}).get("total") == 12)
    check("I003_TREE_RECOMPUTED", root_digest == "7a2c2e39fe9c7cda6cc04f4d104e096737ceddf4d48a8548e8462587fced2392" and count == 56, {"root": root_digest, "count": count})
    check("I004_I006_AUTHORITY_DIGEST", digest(I006 / "GOVERNANCE_LOCK.json") == "273dbf72a536eb2c66e56d3f3a5751660a6bd86f8b3ca2ddd9bf9f43d8fae30e")
    check("I005_HISTORY_UNIT", digest(V12 / "results/prelock/unit-fixtures-run-0001.json") == "b429af4eaff9403139ef41ba9145436ab4dac8778139d5b93f0e5ea632d3c36d")
    check("I006_HISTORY_PRIMARY", digest(V12 / "results/prelock/primary-static-validation-run-0001.json") == "81f3f6a449cf11dbc4faba8a070638fac2406e461d15e9753e89ba821d9e41ac")
    check("I007_HISTORY_INDEPENDENT", digest(V12 / "results/prelock/independent-static-validation-run-0001.json") == "56b1b6572dec7d83afbab91f427a336f7897db1fd5de94c2e3a14fee1a09346f")
    check("I008_PARTIAL_UNIT_0002", digest(V12 / "results/prelock/unit-fixtures-run-0002.json") == "ebd5ff3a8251f59ae617bf0acfaa09f29f043bfb5bd000ee97b603cd056d3838")
    history = json.loads((V12 / "results/prelock/independent-static-validation-run-0001.json").read_text())
    check("I009_HISTORY_FAIL_RETAINED", history.get("status") == "FAIL_CLOSED" and "I006_V11_TREE" in history.get("failure_ids", []))
    check("I010_RUN_0002_CHAIN_INCOMPLETE", not (V12 / "results/prelock/primary-static-validation-run-0002.json").exists() and not (V12 / "results/prelock/independent-static-validation-run-0002.json").exists())
    source = (V12 / "validators/primary_static_validate.py").read_text(encoding="utf-8")
    check("I011_PRIMARY_HARDCODED_0001", 'ROOT / "results/prelock/primary-static-validation-run-0001.json"' in source)
    check("I012_PRIMARY_APPEND_ONLY_EXCLUSIVE", "append_only_json" in source and (V12 / "results/prelock/primary-static-validation-run-0001.json").exists())
    lock_source = (V12 / "prepare_static_lock.py").read_text(encoding="utf-8")
    check("I013_LOCK_HISTORICAL_SELECTOR", all(name in lock_source for name in ("unit-fixtures-run-0001.json", "primary-static-validation-run-0001.json", "independent-static-validation-run-0001.json")))
    check("I014_DEFECT_OWNERSHIP", ownership.get("PRIMARY_CONTINUATION_RUN_SLOT_DEFECT") == "YES" and ownership.get("STATIC_LOCK_CONTINUATION_PROVENANCE_BINDING_GAP") == "YES")
    check("I015_NO_RUNTIME_CLASSIFICATION", ownership.get("TEMPORAL_OBSERVER_RUNTIME") == "NOT_ESTABLISHED" and ownership.get("CONFINEMENT") == "NOT_PROVEN")
    expected_allowlist = [
        "bind_authoritative_artifact_digests.py", "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json",
        "contracts/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CONTRACT.json", "preflight.py", "prepare_static_lock.py",
        "schemas/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE.schema.json", "src/invocation_v12.py", "tests/run_unit_fixtures.py",
        "validators/independent_static_validate.py", "validators/primary_static_validate.py", "verify_static_lock.py",
    ]
    check("I016_ALLOWLIST_EXACT", scope.get("mutable_allowlist") == expected_allowlist)
    check("I017_EXECUTION_PATH_PROTECTED", all(item in scope.get("must_not_change", []) for item in ("src/runner_v12.py", "src/topology_observer_v12.py", "contracts/WORKER_REQUEST.json", "fixture/worker-prompt.txt", "runtime-config-candidate/config.toml")))
    check("I018_HISTORY_POLICY", model.get("historical_run_0001", {}).get("overwrite_delete_rename_reclassify_or_retroactive_pass") == "PROHIBITED")
    check("I019_PARTIAL_NOT_CURRENT", model.get("partial_run_0002", {}).get("current_readiness_eligible") is False)
    check("I020_FRESH_SLOT_REQUIRED", model.get("fresh_current_chain", {}).get("selected_slot") == "run-0003")
    check("I021_SELECTION_NOT_FILENAME", model.get("selection", {}).get("highest_filename_or_newest_timestamp_inference") == "PROHIBITED")
    check("I022_CHAIN_INCLUDES_ALL_GOVERNANCE", "ALL_APPLICABLE_GOVERNANCE_SCOPE_LOCKS" in chain.get("ordered_chain", []))
    check("I023_CHAIN_START_END", chain.get("ordered_chain", [None])[0] == "IMMUTABLE_V12_RUN_0001_VALIDATION_EVIDENCE" and chain.get("ordered_chain", [None])[-1] == "STATIC_EXECUTION_LOCK")
    check("I024_DECISION", decision.get("decision") == "CONTINUATION_V12_VALIDATION_AND_STATIC_LOCK_PROVENANCE_CORRECTION_AUTHORIZED")
    check("I025_NO_GOVERNANCE_EXECUTION", decision.get("current_milestone_performs_execution") is False and authority.get("codex_invocation_authority") == "NOT_GRANTED_BY_THIS_GOVERNANCE")
    check("I026_STATIC_LOCK_ABSENT", not (V12 / "STATIC_EXECUTION_LOCK.json").exists())
    check("I027_ATTEMPT_ABSENT", not (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists())
    check("I028_RUNTIME_ABSENT", not (V12 / "static-run-v12/runtime-result-0001.json").exists())
    check("I029_NO_FRESH_PREFLIGHT", not list((V12 / "results/prelock").glob("fresh-preflight-run-*.json")))
    check("I030_IDENTITY", all(read(name).get("governance_identity") == IDENTITY for name in ("GOVERNANCE_CHARTER.json", "V12_PRELOCK_EVIDENCE_BINDING.json", "DEFECT_OWNERSHIP_DECISION.json", "NORMATIVE_CONTINUATION_EVIDENCE_MODEL.json", "STATIC_LOCK_PROVENANCE_CHAIN_CONTRACT.json", "CONTINUATION_V12_SCOPE_LOCK.json", "CONTINUATION_REGRESSION_MATRIX.json", "CONTINUATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json")))

    failures = [item["id"] for item in checks if item["status"] == "FAIL"]
    result = {
        "record_type": "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT",
        "governance_identity": IDENTITY,
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
    }
    with (ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
