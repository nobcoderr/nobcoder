#!/usr/bin/env python3
"""Final independent verification and read-only seal for the governance package."""
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONTINUATION_RUN_SLOT_AND_STATIC_LOCK_PROVENANCE_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    manifest = load(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load(ROOT / "GOVERNANCE_LOCK.json")
    checks: list[dict[str, object]] = []
    def check(name: str, ok: bool, evidence: object = None) -> None:
        checks.append({"id": name, "status": "PASS" if ok else "FAIL", "evidence": evidence})

    check("F001_LOCK_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F002_IDENTITY", lock.get("governance_identity") == IDENTITY == manifest.get("governance_identity"))
    check("F003_MANIFEST_DIGEST", lock.get("manifest_sha256") == digest(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"))
    rows = manifest.get("members", [])
    material = "".join(f"{row['path']}\0{row['sha256']}\n" for row in rows).encode("utf-8")
    root_digest = hashlib.sha256(material).hexdigest()
    check("F004_CANONICAL_ROOT", root_digest == manifest.get("canonical_artifact_root_sha256") == lock.get("canonical_artifact_root_sha256"))
    check("F005_MEMBER_COUNT", len(rows) == manifest.get("member_count") == lock.get("member_count"))
    for index, row in enumerate(rows, 6):
        path = ROOT / row["path"]
        ok = path.is_file() and not path.is_symlink() and digest(path) == row["sha256"] and path.stat().st_size == row["bytes"] and stat.S_IMODE(path.stat().st_mode) & 0o222 == 0
        check(f"F{index:03d}_MEMBER_{row['path']}", ok)
    for name in ("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "READ_ONLY_INTEGRITY_RESULT_RUN-0001.json"):
        check(f"GATE_{name}", load(ROOT / name).get("status") == "PASS")
    check("V12_STATIC_LOCK_ABSENT", not (V12 / "STATIC_EXECUTION_LOCK.json").exists())
    check("V12_ATTEMPT_ABSENT", not (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists())
    check("V12_RUNTIME_ABSENT", not (V12 / "static-run-v12/runtime-result-0001.json").exists())
    check("V12_PRIMARY_0002_ABSENT", not (V12 / "results/prelock/primary-static-validation-run-0002.json").exists())
    check("V12_INDEPENDENT_0002_ABSENT", not (V12 / "results/prelock/independent-static-validation-run-0002.json").exists())
    failures = [item["id"] for item in checks if item["status"] == "FAIL"]
    result = {
        "record_type": "FINAL_FREEZE_VERIFICATION_RESULT",
        "governance_identity": IDENTITY,
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
        "governance_lock_sha256": digest(ROOT / "GOVERNANCE_LOCK.json"),
        "manifest_sha256": digest(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "canonical_artifact_root_sha256": root_digest,
    }
    out = ROOT / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
    with out.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    os.chmod(out, 0o444)
    if not failures:
        os.chmod(ROOT, 0o555)
    print(json.dumps({"status": result["status"], "counts": result["validation_counts"], "governance_lock_sha256": result["governance_lock_sha256"]}, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
