#!/usr/bin/env python3
"""Prove governance construction did not mutate or execute V12."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONTINUATION_RUN_SLOT_AND_STATIC_LOCK_PROVENANCE_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree() -> tuple[str, int]:
    rows = []
    for path in V12.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(str(path))
        if path.is_file():
            rows.append((path.relative_to(V12).as_posix(), digest(path)))
    rows.sort(key=lambda row: row[0].encode())
    return hashlib.sha256("".join(f"{d}  {p}\n" for p, d in rows).encode()).hexdigest(), len(rows)


def main() -> int:
    root_digest, count = tree()
    facts = {
        "tree_exact": root_digest == "7a2c2e39fe9c7cda6cc04f4d104e096737ceddf4d48a8548e8462587fced2392" and count == 56,
        "static_lock_absent": not (V12 / "STATIC_EXECUTION_LOCK.json").exists(),
        "source_manifest_absent": not (V12 / "STATIC_SOURCE_MANIFEST.json").exists(),
        "attempt_absent": not (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists(),
        "runtime_result_absent": not (V12 / "static-run-v12/runtime-result-0001.json").exists(),
        "primary_0002_absent": not (V12 / "results/prelock/primary-static-validation-run-0002.json").exists(),
        "independent_0002_absent": not (V12 / "results/prelock/independent-static-validation-run-0002.json").exists(),
        "fresh_preflight_absent": not list((V12 / "results/prelock").glob("fresh-preflight-run-*.json")),
    }
    result = {
        "record_type": "READ_ONLY_INTEGRITY_RESULT",
        "governance_identity": IDENTITY,
        "status": "PASS" if all(facts.values()) else "FAIL_CLOSED",
        "checks": facts,
        "v12_tree_root_sha256": root_digest,
        "v12_member_count": count,
        "attempt_count": 0,
        "worker_invocation_count": 0,
        "codex_as_worker_invocation_count": 0,
    }
    with (ROOT / "READ_ONLY_INTEGRITY_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({"status": result["status"], "checks": len(facts)}, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
