#!/usr/bin/env python3
"""Freeze the V12 governance package after every required gate passes."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parent
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONTINUATION_RUN_SLOT_AND_STATIC_LOCK_PROVENANCE_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_GOVERNANCE_ONLY"
DECISION = "CONTINUATION_V12_VALIDATION_AND_STATIC_LOCK_PROVENANCE_CORRECTION_AUTHORIZED"
EXCLUDED = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"}


def load(name: str) -> dict:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_root(rows: list[dict[str, object]]) -> str:
    material = "".join(f"{row['path']}\0{row['sha256']}\n" for row in rows).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


def main() -> int:
    required = {
        "primary": "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
        "negative": "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
        "independent": "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
        "read_only": "READ_ONLY_INTEGRITY_RESULT_RUN-0001.json",
    }
    gates = {name: load(path) for name, path in required.items()}
    if not all(value.get("status") == "PASS" for value in gates.values()):
        raise RuntimeError("all governance gates must PASS before freeze")
    decision = load("CONTINUATION_DECISION.json")
    scope = load("CONTINUATION_V12_SCOPE_LOCK.json")
    if decision.get("decision") != DECISION:
        raise RuntimeError("decision mismatch")
    if (V12 / "STATIC_EXECUTION_LOCK.json").exists() or (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists():
        raise RuntimeError("V12 execution state changed before governance freeze")
    rows = []
    for path in sorted(ROOT.iterdir(), key=lambda item: item.name.encode("utf-8")):
        if path.is_file() and path.name not in EXCLUDED:
            rows.append({"path": path.name, "sha256": digest(path), "bytes": path.stat().st_size})
    artifact_root = canonical_root(rows)
    manifest = {
        "schema_version": "1.0",
        "record_type": "GOVERNANCE_ARTIFACT_MANIFEST",
        "governance_identity": IDENTITY,
        "status": "PASS_COMPLETE_GOVERNANCE_CLOSURE",
        "canonicalization": "SORT_PATH_BYTES_THEN_PATH_NUL_SHA256_LF",
        "member_count": len(rows),
        "members": rows,
        "canonical_artifact_root_sha256": artifact_root,
    }
    with (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True)
        handle.write("\n")
    lock = {
        "schema_version": "1.0",
        "record_type": "GOVERNANCE_LOCK",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": DECISION,
        "manifest_sha256": digest(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "canonical_artifact_root_sha256": artifact_root,
        "member_count": len(rows),
        "v12_status": "PRELOCK_CONTINUATION_AUTHORIZED_NOT_CORRECTED_NOT_EXECUTED",
        "v12_tree_root_sha256_at_freeze": gates["read_only"]["v12_tree_root_sha256"],
        "v12_member_count_at_freeze": gates["read_only"]["v12_member_count"],
        "static_lock": "NOT_ISSUED",
        "attempt": "0/1",
        "worker_invocation": "0/1",
        "codex_as_worker_invocation": "0/1",
        "continuation_mutable_allowlist": scope["mutable_allowlist"],
        "selected_current_readiness_slot_after_correction": "run-0003",
        "historical_run_0001": "IMMUTABLE_ADMISSIBLE_HISTORY",
        "partial_run_0002": "IMMUTABLE_INCOMPLETE_HISTORY_NOT_CURRENT_READINESS",
        "final_freeze_verification_required": True,
    }
    with (ROOT / "GOVERNANCE_LOCK.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(lock, handle, indent=2, sort_keys=True)
        handle.write("\n")
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    print(json.dumps({"status": lock["status"], "decision": DECISION, "member_count": len(rows), "root": artifact_root}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
