#!/usr/bin/env python3
"""Primary read-only validation for the V12 provenance adjudication."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
I006 = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v12-independent-validator-v11-tree-"
    "canonicalization-mismatch-prelock-erratum-and-continuation-or-successor-decision-"
    "governance-v1-20261023"
)
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONTINUATION_RUN_SLOT_AND_"
    "STATIC_LOCK_PROVENANCE_BINDING_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_DECISION_"
    "GOVERNANCE_ONLY"
)
DECISION = "CONTINUATION_V12_VALIDATION_AND_STATIC_LOCK_PROVENANCE_CORRECTION_AUTHORIZED"
EXPECTED_TREE = "7a2c2e39fe9c7cda6cc04f4d104e096737ceddf4d48a8548e8462587fced2392"
EXPECTED_RUNS = {
    "unit-fixtures-run-0001.json": "b429af4eaff9403139ef41ba9145436ab4dac8778139d5b93f0e5ea632d3c36d",
    "primary-static-validation-run-0001.json": "81f3f6a449cf11dbc4faba8a070638fac2406e461d15e9753e89ba821d9e41ac",
    "independent-static-validation-run-0001.json": "56b1b6572dec7d83afbab91f427a336f7897db1fd5de94c2e3a14fee1a09346f",
    "unit-fixtures-run-0002.json": "ebd5ff3a8251f59ae617bf0acfaa09f29f043bfb5bd000ee97b603cd056d3838",
}


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_root(root: Path) -> tuple[str, int]:
    rows = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"symlink not admissible: {path}")
        if path.is_file():
            rows.append((path.relative_to(root).as_posix(), digest(path)))
    rows.sort(key=lambda row: row[0].encode("utf-8"))
    material = "".join(f"{member_digest}  {relative}\n" for relative, member_digest in rows)
    return hashlib.sha256(material.encode("utf-8")).hexdigest(), len(rows)


def main() -> int:
    checks: list[dict[str, object]] = []

    def check(name: str, ok: bool, evidence: object = None) -> None:
        checks.append({"id": name, "status": "PASS" if ok else "FAIL", "evidence": evidence})

    charter = load(ROOT / "GOVERNANCE_CHARTER.json")
    binding = load(ROOT / "V12_PRELOCK_EVIDENCE_BINDING.json")
    ownership = load(ROOT / "DEFECT_OWNERSHIP_DECISION.json")
    model = load(ROOT / "NORMATIVE_CONTINUATION_EVIDENCE_MODEL.json")
    chain = load(ROOT / "STATIC_LOCK_PROVENANCE_CHAIN_CONTRACT.json")
    scope = load(ROOT / "CONTINUATION_V12_SCOPE_LOCK.json")
    matrix = load(ROOT / "CONTINUATION_REGRESSION_MATRIX.json")
    decision = load(ROOT / "CONTINUATION_DECISION.json")
    authority = load(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    route = load(ROOT / "ROUTING_LEDGER.json")
    root_digest, count = tree_root(V12)

    check("P001_IDENTITY", all(value.get("governance_identity") == IDENTITY for value in (charter, binding, ownership, model, chain, scope, matrix, decision, authority, route)))
    check("P002_V12_TREE", root_digest == EXPECTED_TREE and count == 56, {"root": root_digest, "count": count})
    check("P003_I006_LOCK", digest(I006 / "GOVERNANCE_LOCK.json") == "273dbf72a536eb2c66e56d3f3a5751660a6bd86f8b3ca2ddd9bf9f43d8fae30e")
    i006_lock = load(I006 / "GOVERNANCE_LOCK.json")
    check("P004_I006_AUTHORITY", i006_lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY" and i006_lock.get("decision") == "CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AUTHORIZED")
    for index, (name, expected) in enumerate(EXPECTED_RUNS.items(), 5):
        check(f"P{index:03d}_RUN_DIGEST_{name}", digest(V12 / "results/prelock" / name) == expected)
    run1_i = load(V12 / "results/prelock/independent-static-validation-run-0001.json")
    run2_u = load(V12 / "results/prelock/unit-fixtures-run-0002.json")
    check("P009_HISTORICAL_INDEPENDENT_FAIL", run1_i.get("status") == "FAIL_CLOSED" and run1_i.get("failure_ids") == ["I006_V11_TREE"])
    check("P010_UNIT_0002_PASS", run2_u.get("status") == "PASS" and run2_u.get("validation_counts") == {"failed": 0, "passed": 85, "total": 85})
    check("P011_PRIMARY_0002_ABSENT", not (V12 / "results/prelock/primary-static-validation-run-0002.json").exists())
    check("P012_INDEPENDENT_0002_ABSENT", not (V12 / "results/prelock/independent-static-validation-run-0002.json").exists())
    primary = (V12 / "validators/primary_static_validate.py").read_text(encoding="utf-8")
    prepare = (V12 / "prepare_static_lock.py").read_text(encoding="utf-8")
    check("P013_PRIMARY_SLOT_DEFECT_SOURCE", 'unit-fixtures-run-0001.json' in primary and 'primary-static-validation-run-0001.json' in primary and "append_only_json" in primary)
    check("P014_PRIMARY_COLLISION_PRECONDITION", (V12 / "results/prelock/primary-static-validation-run-0001.json").exists())
    check("P015_LOCK_BINDS_HISTORICAL_UNIT", 'unit-fixtures-run-0001.json' in prepare)
    check("P016_LOCK_BINDS_HISTORICAL_PRIMARY", 'primary-static-validation-run-0001.json' in prepare)
    check("P017_LOCK_BINDS_HISTORICAL_FAILED_INDEPENDENT", 'independent-static-validation-run-0001.json' in prepare and run1_i.get("status") == "FAIL_CLOSED")
    check("P018_DEFECTS_YES", ownership["PRIMARY_CONTINUATION_RUN_SLOT_DEFECT"] == "YES" and ownership["STATIC_LOCK_CONTINUATION_PROVENANCE_BINDING_GAP"] == "YES")
    check("P019_NO_RUNTIME_DEFECT_CLAIM", ownership["WORKER_DEFECT"].startswith("NOT_ESTABLISHED") and ownership["CODEX_DEFECT"].startswith("NOT_ESTABLISHED"))
    check("P020_ENTRY_COUNTERS", charter["static_lock"] == "NOT_ISSUED" and charter["attempt"] == "0/1" and charter["worker_invocation"] == "0/1" and charter["codex_as_worker_invocation"] == "0/1")
    check("P021_NO_EXECUTION_ARTIFACTS", not (V12 / "STATIC_EXECUTION_LOCK.json").exists() and not (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists() and not (V12 / "static-run-v12/runtime-result-0001.json").exists())
    required_allowlist = {
        "bind_authoritative_artifact_digests.py", "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json",
        "contracts/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE_CONTRACT.json", "preflight.py", "prepare_static_lock.py",
        "schemas/CONTINUATION_VALIDATION_EVIDENCE_PROVENANCE.schema.json", "src/invocation_v12.py", "tests/run_unit_fixtures.py",
        "validators/independent_static_validate.py", "validators/primary_static_validate.py", "verify_static_lock.py",
    }
    check("P022_EXACT_ALLOWLIST", set(scope["mutable_allowlist"]) == required_allowlist and len(scope["mutable_allowlist"]) == 11)
    check("P023_RUNNER_PROTECTED", "src/runner_v12.py" in scope["must_not_change"] and "src/runner_v12.py" not in scope["mutable_allowlist"])
    check("P024_RUNTIME_PROTECTED", "runtime-config-candidate/config.toml" in scope["must_not_change"] and "CODEX_RUNTIME_BINDING" in scope["must_not_change"])
    check("P025_HISTORY_IMMUTABLE", model["historical_run_0001"]["overwrite_delete_rename_reclassify_or_retroactive_pass"] == "PROHIBITED")
    check("P026_PARTIAL_0002_NOT_CURRENT", model["partial_run_0002"]["current_readiness_eligible"] is False)
    check("P027_FRESH_CHAIN_0003", model["fresh_current_chain"]["selected_slot"] == "run-0003" and len(model["fresh_current_chain"]["required"]) == 5)
    check("P028_EXPLICIT_SELECTION", model["selection"] == {"digest_verified": True, "explicit": True, "governance_bound": True, "highest_filename_or_newest_timestamp_inference": "PROHIBITED", "unique": True})
    check("P029_ORDERED_CHAIN", len(chain["ordered_chain"]) == 11 and chain["ordered_chain"][0] == "IMMUTABLE_V12_RUN_0001_VALIDATION_EVIDENCE" and chain["ordered_chain"][-1] == "STATIC_EXECUTION_LOCK")
    check("P030_FAIL_CLOSED_RULES", len(chain["fail_closed_conditions"]) >= 8)
    check("P031_REGRESSION_MATRIX", len(matrix["cases"]) == 12 and matrix["all_cases_required"] is True)
    check("P032_DECISION", decision["decision"] == DECISION and decision["v13"] == "NOT_AUTHORIZED")
    check("P033_GOVERNANCE_NO_ACTION", not any((decision["current_milestone_performs_correction"], decision["current_milestone_performs_validation_rerun"], decision["current_milestone_issues_static_lock"], decision["current_milestone_performs_execution"])))
    check("P034_AUTHORITY_CEILING", authority["worker_execution_authority"] == "NOT_GRANTED_BY_THIS_GOVERNANCE" and authority["codex_invocation_authority"] == "NOT_GRANTED_BY_THIS_GOVERNANCE")
    check("P035_ROUTING_NO_OPERATIONS", all(value == 0 for value in route["operations"].values()))

    snapshot = load(I006 / "V12_PRE_ERRATUM_PROTECTED_MEMBER_SNAPSHOT.json")
    old = {row["path"]: row["sha256"] for row in snapshot["members"]}
    allowed_old_changes = {"tests/run_unit_fixtures.py", "validators/independent_static_validate.py"}
    drift = []
    for relative, expected in old.items():
        path = V12 / relative
        if relative not in allowed_old_changes and (not path.is_file() or digest(path) != expected):
            drift.append(relative)
    check("P036_ZERO_PROTECTED_DRIFT", not drift, drift)
    check("P037_EXACT_TWO_CHANGED_SOURCES", digest(V12 / "tests/run_unit_fixtures.py") == "801d08c032ecfd43d9e23f8d782839c97d74f560e5aa11ea34759c4df05afd39" and digest(V12 / "validators/independent_static_validate.py") == "4279fc1dc7d44ae3d38226aff16188626f873d370ab9bcd858a9a549abd57fa0")
    check("P038_NO_PRIMARY_OR_INDEPENDENT_RERUN", not (V12 / "results/prelock/primary-static-validation-run-0002.json").exists() and not (V12 / "results/prelock/independent-static-validation-run-0002.json").exists())
    check("P039_NO_FRESH_PREFLIGHT", not any((V12 / "results/prelock").glob("fresh-preflight-run-*.json")))
    check("P040_NO_STATIC_LOCK", not (V12 / "STATIC_EXECUTION_LOCK.json").exists())

    failures = [item["id"] for item in checks if item["status"] == "FAIL"]
    result = {
        "record_type": "PRIMARY_GOVERNANCE_VALIDATION_RESULT",
        "governance_identity": IDENTITY,
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
        "v12_tree_root_sha256": root_digest,
        "v12_member_count": count,
        "attempt_count": 0,
        "worker_invocation_count": 0,
        "codex_as_worker_invocation_count": 0,
    }
    out = ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"
    with out.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
