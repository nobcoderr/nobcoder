#!/usr/bin/env python3
import hashlib
import json
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"
OLD = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v1")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


checks = []


def add(name, value):
    checks.append({"id": f"F{len(checks) + 1:02d}", "name": name, "pass": bool(value)})


add("manifest exists", MANIFEST.is_file() and not MANIFEST.is_symlink())
add("lock exists", LOCK.is_file() and not LOCK.is_symlink())
manifest = load(MANIFEST)
lock = load(LOCK)
listed = sorted(item["path"] for item in manifest["files"])
actual = sorted(path.name for path in ROOT.iterdir() if path.is_file() and path.name not in {MANIFEST.name, LOCK.name})
add("manifest count", manifest["member_count"] == len(manifest["files"]))
add("manifest complete", listed == actual)
add("manifest paths unique", len(set(listed)) == len(listed))
add("members regular", all((ROOT / item["path"]).is_file() and not (ROOT / item["path"]).is_symlink() for item in manifest["files"]))
add("member bytes and hashes", all((ROOT / item["path"]).stat().st_size == item["bytes"] and sha(ROOT / item["path"]) == item["sha256"] for item in manifest["files"]))
add("manifest digest", sha(MANIFEST) == lock["governance_manifest_sha256"])
rows = bytearray()
for item in sorted(manifest["files"], key=lambda value: value["path"]):
    rows.extend(f"{item['sha256']}  {item['path']}\n".encode())
rows.extend(f"{sha(MANIFEST)}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode())
add("canonical root", hashlib.sha256(rows).hexdigest() == lock["canonical_artifact_root_sha256"])
add("canonical member count", len(manifest["files"]) + 1 == lock["canonical_root_member_count"])
add("governance status", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
add("governance identity", lock["governance_identity"].endswith("ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"))
add("preflight pass", lock["canonical_preflight"].endswith("_PASS"))
add("self-test pass", lock["governance_self_tests"].endswith("_PASS"))
add("negative tests pass", lock["negative_governance_tests"] == "19_OF_19_PASS")
add("independent pass", lock["independent_validation"].endswith("_PASS"))
add("incident exact", lock["incident_sha256"] == "967f00ae0288db50ac2e884cf96fc638eac7fc6d334ffc0fcd843b070d42fc29" and lock["incident_bytes"] == 1696)
add("product-v1 terminal", lock["product_v1"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_CONTINUATION_NO_PROMOTION")
add("distinct product-v2", lock["successor_decision"] == "A_DISTINCT_PRODUCT_V2_SUBTREE_WITHIN_EXISTING_SUCCESSOR_V3")
add("product-v2 V4 identity", lock["product_v2_identity"].endswith("OFFLINE_PRODUCT_IMPLEMENTATION_V4"))
add("static operation conditional", lock["confined_static_operation_status"].startswith("CONDITIONAL_SINGLE_USE_AUTHORIZED"))
add("preservation not executed", lock["incident_preservation_status"] == "AUTHORIZED_FUTURE_SINGLE_USE_NOT_EXECUTED")
add("old P3 unused", lock["old_P3_attempt_count"] == 0)
add("old P3 ineligible", lock["old_P3_disposition"].startswith("UNUSED_BUT_INELIGIBLE"))
add("new P3 reserved only", lock["new_P3_status"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
add("P6 not eligible", lock["P6"] == "NOT_ELIGIBLE_NOT_ISSUED")
add("operations zero", all(value == 0 for value in lock["governance_execution_counts"].values()))
partial = load(ROOT / "PARTIAL_PRODUCT_ARTIFACT_DISPOSITION.json")
add("partial product inventory exact", all((OLD / item["path"]).is_file() and not (OLD / item["path"]).is_symlink() and (OLD / item["path"]).stat().st_size == item["bytes"] and sha(OLD / item["path"]) == item["sha256"] for item in partial["files"]))
add("all governance files read-only", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()))
add("no governance symlink", not any(path.is_symlink() for path in ROOT.iterdir()))

result = {"status": "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": sum(item["pass"] for item in checks), "failed_ids": [item["id"] for item in checks if not item["pass"]], "checks": checks}
print(json.dumps(result, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
