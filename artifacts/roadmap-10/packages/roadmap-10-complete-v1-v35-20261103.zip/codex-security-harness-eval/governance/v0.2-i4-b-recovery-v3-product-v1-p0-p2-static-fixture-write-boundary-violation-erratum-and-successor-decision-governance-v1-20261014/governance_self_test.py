#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V1_P0_P2_STATIC_FIXTURE_WRITE_BOUNDARY_VIOLATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
PRODUCT_V1 = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v1")
PRODUCT_V2 = PRODUCT_V1.parent / "product-v2"
INCIDENT = Path("/tmp/product-v1-trace-fixtures.json")


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


required = [
    "PREFLIGHT_RESULT.json",
    "P0_P2_TERMINAL_DISPOSITION.json",
    "STATIC_FIXTURE_WRITE_BOUNDARY_INCIDENT.json",
    "OUT_OF_SCOPE_FIXTURE_EVIDENCE_REVIEW.json",
    "STATIC_FIXTURE_ROOT_CAUSE.json",
    "PARTIAL_PRODUCT_ARTIFACT_DISPOSITION.json",
    "SUCCESSOR_OR_CONTINUATION_DECISION.json",
    "STATIC_TEST_WRITE_CONFINEMENT_CONTRACT.json",
    "TEMP_AND_FIXTURE_PATH_BINDING.json",
    "P3_IDENTITY_ELIGIBILITY_DECISION.json",
    "EVIDENCE_PRESERVATION_AUTHORIZATION.json",
    "SERIALIZATION_REGRESSION_DISPOSITION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_TEST_MATRIX.json",
    "HISTORICAL_IMMUTABILITY_RESULT.json",
    "RISK_REGISTER.json",
    "PRE_DECISION_LOCK.json",
]

checks = []


def check(name, value, detail=None):
    item = {"id": f"G{len(checks) + 1:03d}", "name": name, "pass": bool(value)}
    if detail is not None:
        item["detail"] = detail
    checks.append(item)


for name in required:
    check("required artifact " + name, (ROOT / name).is_file() and not (ROOT / name).is_symlink())

preflight = load("PREFLIGHT_RESULT.json")
terminal = load("P0_P2_TERMINAL_DISPOSITION.json")
incident = load("STATIC_FIXTURE_WRITE_BOUNDARY_INCIDENT.json")
evidence = load("OUT_OF_SCOPE_FIXTURE_EVIDENCE_REVIEW.json")
root_cause = load("STATIC_FIXTURE_ROOT_CAUSE.json")
partial = load("PARTIAL_PRODUCT_ARTIFACT_DISPOSITION.json")
decision = load("SUCCESSOR_OR_CONTINUATION_DECISION.json")
confinement = load("STATIC_TEST_WRITE_CONFINEMENT_CONTRACT.json")
paths = load("TEMP_AND_FIXTURE_PATH_BINDING.json")
p3 = load("P3_IDENTITY_ELIGIBILITY_DECISION.json")
preserve = load("EVIDENCE_PRESERVATION_AUTHORIZATION.json")
serialization = load("SERIALIZATION_REGRESSION_DISPOSITION.json")
matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
negative = load("NEGATIVE_TEST_MATRIX.json")
immutability = load("HISTORICAL_IMMUTABILITY_RESULT.json")
prelock = load("PRE_DECISION_LOCK.json")

check("all governance identities exact", all(load(name).get("governance_identity") == IDENTITY for name in required if name != "PREFLIGHT_RESULT.json") and preflight["governance_identity"] == IDENTITY)
check("preflight pass", preflight["status"] == "PASS" and preflight["checks_passed"] == preflight["checks_total"])
check("preflight substantial", preflight["checks_total"] >= 60, preflight["checks_total"])
check("product-v1 terminal", terminal["status"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_CONTINUATION_NO_PROMOTION")
check("P3 count zero", terminal["P3_attempt_count"] == 0)
check("old static lock not issued", terminal["static_execution_lock"] == "NOT_ISSUED")
check("old P6 not issued", terminal["P6_provisional_freeze"] == "NOT_ISSUED")
check("serializer runtime results not executed", set(terminal["runtime_serializer_tests"].values()) == {"NOT_EXECUTED"})
check("incident confirmed", incident["status"] == "CONFIRMED_WRITE_BOUNDARY_VIOLATION")
check("incident path exact", incident["path"] == str(INCIDENT))
check("incident digest exact", incident["sha256"] == "967f00ae0288db50ac2e884cf96fc638eac7fc6d334ffc0fcd843b070d42fc29")
check("incident bytes exact", incident["bytes"] == 1696)
check("incident not cleaned", incident["cleanup_performed"] is False)
check("incident still present and exact", INCIDENT.is_file() and not INCIDENT.is_symlink() and INCIDENT.stat().st_size == 1696 and sha(INCIDENT) == incident["sha256"])
check("evidence remains in place", evidence["preservation"] == "SOURCE_LEFT_UNCHANGED_NO_COPY_NO_MOVE_NO_DELETE")
check("evidence ephemerality explicit", "/tmp" in evidence["limitation"])
check("missing source never regenerated", "never regenerate" in evidence["absence_rule"])

check("root cause confirmed", root_cause["status"] == "ROOT_CAUSE_CONFIRMED")
check("root cause shell redirection", root_cause["writer_layer"] == "CALLING_SHELL_REDIRECTION")
check("explicit incident path in command", ">/tmp/product-v1-trace-fixtures.json" in root_cause["exact_recorded_command"])
check("not tempfile", root_cause["tempfile_or_default_directory_used"] is False)
check("not TMP fallback", root_cause["TMPDIR_TMP_TEMP_relevant_to_direct_cause"] is False)
check("OS confinement absent", root_cause["static_test_OS_confinement"] == "ABSENT")
check("side effect audit absent", root_cause["independent_static_side_effect_audit"] == "ABSENT")

check("partial terminal only", partial["status"] == "TERMINAL_PARTIAL_EVIDENCE_READ_ONLY_REFERENCE_ONLY")
check("partial inventory count", partial["file_count"] == len(partial["files"]) and partial["file_count"] >= 20)
check("partial inventory paths unique", len({item["path"] for item in partial["files"]}) == partial["file_count"])
check("partial inventory currently exact", all((PRODUCT_V1 / item["path"]).is_file() and (PRODUCT_V1 / item["path"]).stat().st_size == item["bytes"] and sha(PRODUCT_V1 / item["path"]) == item["sha256"] for item in partial["files"]))
check("partial no confinement promotion", "NOT_CONFINEMENT_PASS" in partial["partial_results_admissibility"])
check("partial source reference only", partial["source_reuse"].startswith("READ_ONLY_REFERENCE"))

check("distinct subtree decision", decision["decision"] == "A_DISTINCT_PRODUCT_V2_SUBTREE_WITHIN_EXISTING_SUCCESSOR_V3")
check("continuation denied", decision["continuation_of_product_v1"] == "DENIED")
check("product-v2 exact root", decision["new_product_root"] == str(PRODUCT_V2))
check("product-v2 absent", not PRODUCT_V2.exists() and not PRODUCT_V2.is_symlink())
check("product-v2 new identity", decision["new_product_identity"].endswith("OFFLINE_PRODUCT_IMPLEMENTATION_V4"))
check("creation preservation gated", "PRESERVATION_GATE" in decision["creation_authorization"])
check("product-v1 non-interference", str(PRODUCT_V1) in decision["non_interference"])

check("static one shot", confinement["maximum_attempts"] == 1)
check("static operation exact", confinement["operation_identity"] == "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V1")
check("static identity exact", confinement["static_identity"] == "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V1")
check("root read only", confinement["host_root"] == "READ_ONLY")
check("network unshared", confinement["network_namespace"] == "UNSHARED")
check("no fallback", confinement["no_unsandboxed_fallback"] is True)
check("only static run writable", confinement["sole_host_backed_writable_bind_during_static_execution"] == str(PRODUCT_V2 / "static-run-v1"))
check("source read only during test", str(PRODUCT_V2 / "source") in confinement["read_only_during_static_execution"])
check("old product read only during test", str(PRODUCT_V1) in confinement["read_only_during_static_execution"])
check("strace audit mandatory", any("strace -ff" in item for item in confinement["mandatory_controls"]))
check("no shell redirection mandatory", any("no shell redirection" in item for item in confinement["mandatory_controls"]))
check("OS enforcement mandatory", confinement["status"].startswith("FUTURE_CONDITIONAL_SINGLE_USE_CONFINED"))
check("dotnet prohibited in static operation", "No dotnet" in confinement["prohibition"])

static_root = str(PRODUCT_V2 / "static-run-v1")
check("static path root exact", paths["static_run_root"] == static_root)
check("all temp vars in scope", all(value.startswith(static_root + "/") for key, value in paths["environment"].items() if key not in {"PYTHONDONTWRITEBYTECODE"}))
check("bytecode disabled", paths["environment"]["PYTHONDONTWRITEBYTECODE"] == "1")
check("pycache in scope", paths["environment"]["PYTHONPYCACHEPREFIX"].startswith(static_root + "/"))
check("all deterministic outputs in scope", all(value.startswith(static_root + "/") for value in paths["deterministic_outputs"].values()))
check("no tmp fallback", "no implicit /tmp fallback" in paths["path_rules"])
check("symlink rejection", "reject symlink components" in paths["path_rules"])

check("old P3 blocked", p3["status"] == "P3_BLOCKED_NOT_EXECUTABLE")
check("old P3 unused", p3["old_attempt_count"] == 0)
check("old P3 ineligible", p3["old_identity_disposition"].startswith("UNUSED_BUT_INELIGIBLE"))
check("new P3 only reserved", p3["successor_identity_status"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
check("new P3 version distinct", p3["reserved_successor_execution_identity"].endswith("PRODUCT_TEST_V2"))
check("separate P3 governance", p3["future_authorization"].startswith("SEPARATE_GOVERNANCE_REQUIRED"))
check("P6 not eligible", p3["P6"] == "NOT_ELIGIBLE_NOT_ISSUED")

check("preservation future only", preserve["status"] == "AUTHORIZED_FUTURE_SINGLE_USE_NOT_EXECUTED" and preserve["execution_in_this_governance"] is False)
check("preservation exact source", preserve["source"] == str(INCIDENT))
check("preservation exact destination", preserve["destination"].endswith("/product-v1-trace-fixtures.json"))
check("preservation no cleanup", preserve["cleanup_authorization"] == "NONE")
check("preservation no recreation", any("do not recreate" in rule for rule in preserve["rules"]))

check("serialization remains not executed", set(serialization["tests"].values()) == {"NOT_EXECUTED"})
check("serialization schema preserved", "preserve slot schema" in serialization["product_v2_requirement"])
check("old 101/103 forbidden", "reuse old 101/103" in serialization["forbidden"])

decisions = {item["stage"]: item["decision"] for item in matrix["decisions"]}
check("old P3 matrix denied", decisions["old P3 V1"] == "NOT_ELIGIBLE_NOT_EXECUTABLE")
check("new P3 matrix reserved", decisions["new P3 V2"] == "RESERVED_NOT_AUTHORIZED")
check("P6 matrix denied", decisions["P6 provisional freeze"] == "NOT_AUTHORIZED_NOT_ELIGIBLE")
check("operations remain zero", all(value == 0 for value in matrix["governance_execution_counts"].values()))
check("operational stages denied", decisions["protected broker Guard V3 Recovery V3 Windows VM I5 V0.3"] == "NOT_AUTHORIZED")

check("historical mutation zero", immutability["historical_mutations"] == 0)
check("original S03 preserved", immutability["original_s03"] == "FAIL_CLOSED_NO_RETRY_NO_REWRITE_NO_PROMOTION")
check("Recovery V2 unknown", immutability["Recovery_V2"].startswith("CONSUMPTION_UNKNOWN"))
check("PFX content not accessed", immutability["PFX_content_accessed"] is False)
check("temporal verifier not promoted", immutability["temporal_predecessor_verifier"].startswith("23_OF_24_ONLY_F14"))
check("next milestone exact", prelock["next_legal_milestone"].startswith("PRESERVE_PRODUCT_V1_FIXTURE_INCIDENT_EVIDENCE_THEN_IMPLEMENT"))
check("claim governance only", "Governance only" in prelock["claim_boundary"])


def decision_for(case):
    reject = {
        "tmp_output_silently_accepted",
        "passing_test_count_overrides_write_violation",
        "missing_original_fixture_ignored",
        "stale_source_digest_accepted",
        "unauthorized_cleanup",
        "old_product_v1_modified",
        "old_p0_p2_promoted",
        "old_p3_automatically_reused",
        "unexpected_tempfile_fallback",
        "python_cache_outside_scope",
        "symlink_escape",
        "unapproved_output_directory",
        "failed_audit_marked_pass",
        "serialization_schema_weakened",
        "dotnet_before_p3_gate",
        "p6_without_product_tests",
        "historical_s03_promoted",
        "recovery_v2_unknown_rewritten",
        "unauthorized_guard_or_recovery",
    }
    return "REJECT" if case in reject else "UNKNOWN_FAIL_CLOSED"


negative_results = []
for item in negative["cases"]:
    actual = decision_for(item["scenario"])
    negative_results.append({"id": item["id"], "scenario": item["scenario"], "expected": item["expected"], "actual": actual, "pass": actual == item["expected"]})
check("negative matrix count", len(negative_results) == negative["tests_total"] == 19)
for item in negative_results:
    check("negative rejects " + item["scenario"], item["pass"])

status = "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED"
write_json("NEGATIVE_GOVERNANCE_TEST_RESULT.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS" if all(item["pass"] for item in negative_results) else "FAIL_CLOSED",
    "tests_total": len(negative_results),
    "tests_passed": sum(item["pass"] for item in negative_results),
    "results": negative_results,
    "execution": "INERT_GOVERNANCE_FIXTURES_ONLY",
})
write_json("GOVERNANCE_TEST_RESULT.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": status,
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "checks": checks,
    "execution_counts": matrix["governance_execution_counts"],
})
print(json.dumps({"status": status, "checks_passed": sum(item["pass"] for item in checks), "checks_total": len(checks), "negative_tests_passed": sum(item["pass"] for item in negative_results), "negative_tests_total": len(negative_results)}, indent=2))
if status != "PASS":
    raise SystemExit(1)
