#!/usr/bin/env python3
import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V1_P0_P2_STATIC_FIXTURE_WRITE_BOUNDARY_VIOLATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"

BASE = Path("/home/nobcoder")
PREV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-successor-v3-offline-product-implementation-and-confined-dotnet-test-authorization-governance-v1-20261014"
ADJ = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-successor-v3-s03-post-validation-trace-classifier-false-positive-erratum-and-evidence-adjudication-governance-v1-20261014"
S03_ERRATUM = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-successor-v2-s03-confinement-probe-failure-erratum-and-retry-or-successor-decision-governance-v1-20261014"
TOOLCHAIN_ERRATUM = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-offline-implementation-toolchain-scope-violation-erratum-and-successor-decision-governance-v1-20261014"
RECOVERY_V2_GOV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v2-consumption-provenance-and-authoritative-evidence-source-binding-governance-v1-20261013"
SUCCESSOR = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014"
PRODUCT_V1 = SUCCESSOR / "product-v1"
PRODUCT_V2 = SUCCESSOR / "product-v2"
S03_V2 = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v2-20261014"
IMPL_V1 = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v1-20261013"
GUARD_V2 = BASE / "v0.2-i4-b-v2-evidence-recovery-live-guard-v2-20261013"
INCIDENT = Path("/tmp/product-v1-trace-fixtures.json")
ARCHIVE_ROOT = BASE / "codex-security-harness-eval/evidence/v0.2-i4-b-recovery-v3-product-v1-p0-p2-write-boundary-incident-v1-20261014"
ARCHIVE_FILE = ARCHIVE_ROOT / "product-v1-trace-fixtures.json"

PRODUCT_V1_IDENTITY = "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V3_OFFLINE_PRODUCT_IMPLEMENTATION_V3"
PRODUCT_V2_IDENTITY = "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V3_OFFLINE_PRODUCT_IMPLEMENTATION_V4"
STATIC_IDENTITY = "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V1"
STATIC_OPERATION = "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V1"
OLD_P3_IDENTITY = "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_CONFINED_DOTNET_BUILD_AND_PRODUCT_TEST_V1"
OLD_P3_OPERATION = "P03_SUCCESSOR_V3_CONFINED_DOTNET_BUILD_AND_PRODUCT_TEST_V1"
NEW_P3_IDENTITY = "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_CONFINED_DOTNET_BUILD_AND_PRODUCT_TEST_V2"
NEW_P3_OPERATION = "P03_SUCCESSOR_V3_CONFINED_DOTNET_BUILD_AND_PRODUCT_TEST_V2"
PRESERVATION_OPERATION = "PRESERVE_RECOVERY_V3_PRODUCT_V1_STATIC_FIXTURE_INCIDENT_EVIDENCE_V1"

EXPECTED = {
    PREV / "GOVERNANCE_LOCK.json": "da6b4adfd9d9ff4e791b6fefc48dfff1b4a8f8b6f8c3aaf1d88cafe2a7f1b95d",
    PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json": "18cb5a56f1bf265958ab5079f75ce2fdbd07a4ce6cb899debd8afadb6ec89de0",
    INCIDENT: "967f00ae0288db50ac2e884cf96fc638eac7fc6d334ffc0fcd843b070d42fc29",
    PRODUCT_V1 / "source/Collect-V3PartialEvidenceRecoveryPackageV3.ps1": "0ae64638b63e77d2cab585a89c3de2cb4cb2aa7c576599786b6c241113210421",
    PRODUCT_V1 / "source/RecoveryV3AttemptLedgerClient.psm1": "2b418c2fd46b09c44c81dae423db05588956e3b0727b93cd095376fd65e8cbf7",
    PRODUCT_V1 / "source/broker/RecoveryAttemptLedgerBrokerV1.cs": "af6fed892baa61dac88e01b5ab23de1fc15fbddd158ea49d76e3a0859bb33910",
    PRODUCT_V1 / "source/broker/RecoveryAttemptLedgerBrokerV1.csproj": "6ea2ab175db687a797dd8c0c26c9ac06a7438b907170e1696e3c85fbcac991ec",
    PRODUCT_V1 / "source/tests/RecoveryV3OfflineTests.cs": "a1ef5c521a06f9f064f7b248dce6ae4211a6eb6bdb63444338005c506e61c3bb",
    PRODUCT_V1 / "source/tests/RecoveryV3OfflineTests.csproj": "e0b18d0727aab97b5684ae7acd5af9dd3f9eafcc261efb638a371f0901e201bf",
    PRODUCT_V1 / "contracts/TOOLCHAIN_CLOSURE_MANIFEST.json": "23477cb21b2f7d2d77a1d4a39a0a84a1f750713c68be5b2733760a3f3c1a75f7",
    PRODUCT_V1 / "contracts/OFFLINE_FEED_MANIFEST.json": "3c4ea49346c2334aa0b74d7ddd0f947a344d637f8b8701b4c91b8b99d8b8bef8",
    PRODUCT_V1 / "PRODUCT_MOUNT_TOPOLOGY_STATIC_TEST_RESULT.json": "44d7ae6aa54640e3ef2738691ea504fe284e89ef6e6c814ede8ea2ee2a5ea69f",
    PRODUCT_V1 / "PRODUCT_STATIC_VALIDATION_RESULT.json": "efcc7138c5397b1f7aac4b003f2412fe3942c9b44234bd6f805b77c93d0a3e8a",
    PRODUCT_V1 / "PRODUCT_INDEPENDENT_STATIC_VALIDATION_RESULT.json": "894616cbcb82a3bc62938d9f2847d48ea951def7cfbdf91ba8b4bcb2c63663d9",
    SUCCESSOR / "artifacts/runtime/S03_V3_RAW_MOUNTINFO.bin": "7b0aadc088593aace8b113b63e976bb74c04457ce14c6cbc593090c94c8d3bc0",
    SUCCESSOR / "artifacts/runtime/traces/s03.strace.4": "d13d47b7bf7b0f36e244359a178335701ab689e8e135a4c93d932d8cb5376f47",
    SUCCESSOR / "artifacts/runtime/S03_V3_INDEPENDENT_VALIDATION_RESULT.json": "224623ddd0f307e8542c2e7a3eeae8e502f215793828400c1fe776fa397dc594",
    S03_V2 / "artifacts/test-results/CONFINEMENT_PROBE_TERMINAL_FAILURE.json": "e333253db68e43aca1d0d081b3951cc8c6653697a45e3dff1148de0c8728d411",
    S03_V2 / "artifacts/logs/probe.strace.4": "1ff0c37e16bce2529d28e15786b5d2db7428343dd8b4a389761eb54de25d39e5",
    IMPL_V1 / "Collect-V3PartialEvidenceRecoveryPackageV3.ps1": "faefac6353e58d53477869b3c1bbd10ef5462722bfa2f77aa7ab69191bc55dd9",
    IMPL_V1 / "RecoveryV3AttemptLedgerClient.psm1": "7c9f850928ee835cdd580c33aed6b021634eb6f53423bd5984de248280a80c8e",
    IMPL_V1 / "broker/RecoveryAttemptLedgerBrokerV1.cs": "502a1d0473db7c9b083b082e1d337e19189e9a7debe9af5c50b4265e195626ab",
    IMPL_V1 / "broker/RecoveryAttemptLedgerBrokerV1.csproj": "6ea2ab175db687a797dd8c0c26c9ac06a7438b907170e1696e3c85fbcac991ec",
    IMPL_V1 / "tests/RecoveryV3OfflineTests.cs": "61579d13877d7d432473aeb88f581e9ac716da2db644eae9864a6bd74a063e58",
    GUARD_V2 / "LIVE_GUARD_V2_DIGEST_LOCK.json": "0bf6089ad569b36c8b7a8bb4ffc263ba0fcf320393dcaddce61aaa2b9b65f73c",
    GUARD_V2 / "LIVE_GUARD_V2_VALIDATION_LOCK.json": "f734c0a7a67c428588f886add6134e9534ca988864b16122d8fd67e7b8545a25",
    RECOVERY_V2_GOV / "GOVERNANCE_LOCK.json": "6177a721123cc54afaec622ef7164f0175153ebabf32f44f25cdcca3b73ecb21",
}


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(name: str, value) -> None:
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def canonical_root(root: Path):
    manifest_path = root / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest = load(manifest_path)
    rows = bytearray()
    for item in sorted(manifest["files"], key=lambda value: value["path"]):
        path = root / item["path"]
        if not path.is_file() or path.is_symlink() or path.stat().st_size != item["bytes"] or sha(path) != item["sha256"]:
            raise RuntimeError("manifest member mismatch: " + item["path"])
        rows.extend(f"{item['sha256']}  {item['path']}\n".encode())
    rows.extend(f"{sha(manifest_path)}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode())
    return hashlib.sha256(rows).hexdigest(), len(manifest["files"]) + 1


checks = []


def check(name: str, passed, detail=None) -> None:
    item = {"id": f"P{len(checks) + 1:03d}", "name": name, "pass": bool(passed)}
    if detail is not None:
        item["detail"] = detail
    checks.append(item)


for path, expected in EXPECTED.items():
    check("digest " + str(path), path.is_file() and not path.is_symlink() and sha(path) == expected)

prev_lock = load(PREV / "GOVERNANCE_LOCK.json")
prev_manifest = load(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json")
prev_root, prev_count = canonical_root(PREV)
check("predecessor status", prev_lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
check("predecessor manifest coverage", prev_manifest["member_count"] == len(prev_manifest["files"]) == 25)
check("predecessor canonical root", prev_root == "7aa89cf06d212c58df9909d2cc4096709b7b2b1b2e439315f9cd4a0b868fd036")
check("predecessor canonical member count", prev_count == 26)
check("S03 original terminal", prev_lock["original_s03_state"] == "FAIL_CLOSED_NO_RETRY_NO_REWRITE_NO_PROMOTION")
check("S03 evidence separately admissible", prev_lock["separate_evidence_admissibility"] == "PASS_ADMISSIBLE_AS_SEPARATE_CONFINEMENT_EVIDENCE")
check("historical temporal 18 of 19 preserved", prev_lock["historical_temporal_verifier"].startswith("18_OF_19"))

temporal = subprocess.run(["python3", str(PREV / "freeze_verify.py")], check=False, text=True, capture_output=True)
temporal_result = json.loads(temporal.stdout)
check("current predecessor verifier temporal result", temporal_result["checks_passed"] == 23 and temporal_result["checks_total"] == 24, {"checks_passed": temporal_result["checks_passed"], "checks_total": temporal_result["checks_total"]})
check("current temporal failure only product absence", temporal_result.get("failed_ids") == ["F14"])
f14 = [item for item in temporal_result["checks"] if item["id"] == "F14"]
check("F14 exact temporal predicate", len(f14) == 1 and f14[0]["name"] == "product root remains absent")

check("product-v1 exact real directory", PRODUCT_V1.is_dir() and not PRODUCT_V1.is_symlink() and PRODUCT_V1.resolve() == PRODUCT_V1)
check("product-v2 absent and no symlink", not PRODUCT_V2.exists() and not PRODUCT_V2.is_symlink())
check("incident is regular non-symlink", INCIDENT.is_file() and not INCIDENT.is_symlink() and stat.S_ISREG(INCIDENT.lstat().st_mode))
check("incident exact size", INCIDENT.stat().st_size == 1696, INCIDENT.stat().st_size)
incident_json = load(INCIDENT)
check("incident fixture result parses", incident_json["status"] == "PASS")
check("incident fixture result 10 of 10", incident_json["tests_passed"] == incident_json["tests_total"] == 10)

static_result = load(PRODUCT_V1 / "PRODUCT_STATIC_VALIDATION_RESULT.json")
independent_result = load(PRODUCT_V1 / "PRODUCT_INDEPENDENT_STATIC_VALIDATION_RESULT.json")
mount_result = load(PRODUCT_V1 / "PRODUCT_MOUNT_TOPOLOGY_STATIC_TEST_RESULT.json")
check("reported product static result 44 of 44", static_result["status"] == "PASS" and static_result["checks_passed"] == static_result["checks_total"] == 44)
check("reported independent static result 44 of 44", independent_result["status"] == "PASS" and independent_result["checks_passed"] == independent_result["checks_total"] == 44)
check("reported mount fixtures 22 of 22", mount_result["status"] == "PASS" and mount_result["tests_run"] == 22 and mount_result["failures"] == mount_result["errors"] == 0)
check("reported static phase tool counters zero", all(static_result[key] == 0 for key in ("dotnet_invocations", "nuget_invocations", "bwrap_invocations", "strace_invocations")))
check("reported independent static phase tool counters zero", all(independent_result[key] == 0 for key in ("dotnet_invocations", "nuget_invocations", "bwrap_invocations", "strace_invocations")))

for forbidden in [
    PRODUCT_V1 / "PRODUCT_STATIC_SOURCE_MANIFEST.json",
    PRODUCT_V1 / "PRODUCT_STATIC_EXECUTION_LOCK.json",
    PRODUCT_V1 / "run-v1/artifacts/runtime/P3_ONE_SHOT_ATTEMPT_STARTED.json",
    PRODUCT_V1 / "PRODUCT_V1_PROVISIONAL_ARTIFACT_MANIFEST.json",
    PRODUCT_V1 / "PRODUCT_V1_PROVISIONAL_LOCK.json",
]:
    check("not issued " + str(forbidden), not forbidden.exists() and not forbidden.is_symlink())

validator_source = (PRODUCT_V1 / "tooling/validate_phase_aware_trace.py").read_text(encoding="utf-8")
independent_source = (PRODUCT_V1 / "tooling/independent_static_validate.py").read_text(encoding="utf-8")
check("fixture validator prints stdout", "print(json.dumps(result" in validator_source)
check("fixture validator has no incident absolute path", "/tmp/product-v1-trace-fixtures.json" not in validator_source)
check("fixture validator has no tempfile use", "tempfile" not in validator_source)
check("independent static validator omits side-effect audit", "side_effect" not in independent_source and "write_surface" not in independent_source)

product_inventory = []
product_symlinks = []
for path in sorted(PRODUCT_V1.rglob("*")):
    if path.is_symlink():
        product_symlinks.append(str(path.relative_to(PRODUCT_V1)))
    elif path.is_file():
        product_inventory.append({"path": str(path.relative_to(PRODUCT_V1)), "bytes": path.stat().st_size, "sha256": sha(path)})
check("partial workspace contains no symlink", not product_symlinks, product_symlinks)
check("partial workspace inventory nonempty", len(product_inventory) >= 20, len(product_inventory))
check("toolchain closure 3557", load(PRODUCT_V1 / "contracts/TOOLCHAIN_CLOSURE_MANIFEST.json")["entry_count"] == 3557)
feed_manifest = load(PRODUCT_V1 / "contracts/OFFLINE_FEED_MANIFEST.json")
check("local feed exactly three packages", feed_manifest["package_count"] == 3 and len(feed_manifest["packages"]) == 3)

recovery_v2_lock = load(RECOVERY_V2_GOV / "GOVERNANCE_LOCK.json")
check("Recovery V2 remains unknown", recovery_v2_lock["decision"]["consumption_state"] == "CONSUMPTION_UNKNOWN" and recovery_v2_lock["recovery_v2"] == "BLOCKED_NOT_EXECUTABLE_NO_RETRY")
check("Guard V2 digest lock remains locked", load(GUARD_V2 / "LIVE_GUARD_V2_DIGEST_LOCK.json")["status"] == "PASS_LOCKED")
check("Guard V2 validation lock remains locked", load(GUARD_V2 / "LIVE_GUARD_V2_VALIDATION_LOCK.json")["status"] == "PASS_LOCKED")
check("toolchain incident governance retained", (TOOLCHAIN_ERRATUM / "GOVERNANCE_LOCK.json").is_file())
check("S03 erratum governance retained", (S03_ERRATUM / "GOVERNANCE_LOCK.json").is_file())
check("adjudication governance retained", (ADJ / "GOVERNANCE_LOCK.json").is_file())
check("historical .dotnet directory retained", (BASE / ".dotnet").is_dir() and not (BASE / ".dotnet").is_symlink())
check("historical .nuget directory retained", (BASE / ".nuget").is_dir() and not (BASE / ".nuget").is_symlink())

pfx = BASE / ".dotnet/corefx/cryptography/x509stores/my/6C1DA3DE00985BC59141C2F29474051A5FBD85EB.pfx"
pfx_stat = pfx.lstat()
pfx_meta = {"content_accessed": False, "size": pfx_stat.st_size, "mode": oct(stat.S_IMODE(pfx_stat.st_mode)), "mtime_ns": pfx_stat.st_mtime_ns}
check("PFX metadata-only preservation", pfx_meta == {"content_accessed": False, "size": 2383, "mode": "0o600", "mtime_ns": 1791882874439759161}, pfx_meta)

check("archive destination absent", not ARCHIVE_ROOT.exists() and not ARCHIVE_ROOT.is_symlink())
check("no conflicting finalized governance", not (ROOT / "GOVERNANCE_LOCK.json").exists() and not (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").exists())
bootstrap_allowed = {"build_governance.py", "governance_self_test.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py"}
check("governance bootstrap scope exact", {path.name for path in ROOT.iterdir()} <= bootstrap_allowed)

if any(not item["pass"] for item in checks):
    raise SystemExit(json.dumps({"status": "FAIL_CLOSED", "failed": [item for item in checks if not item["pass"]]}, indent=2))

incident_stat = INCIDENT.lstat()
preflight = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS",
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "checks": checks,
    "claim_boundary": "Read-only predecessor, incident, partial-product, and temporal checks; no product test, P3, bwrap, strace, dotnet, NuGet, Windows, VBoxManage, Guard, or Recovery execution.",
}
write_json("PREFLIGHT_RESULT.json", preflight)

write_json("P0_P2_TERMINAL_DISPOSITION.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "product_identity": PRODUCT_V1_IDENTITY,
    "product_root": str(PRODUCT_V1),
    "status": "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_CONTINUATION_NO_PROMOTION",
    "failed_boundary": "P0_P2_STATIC_WRITE_BOUNDARY",
    "confirmed_violation": str(INCIDENT),
    "static_results": {"product": "44_OF_44_RETAINED_AS_PARTIAL_EVIDENCE_ONLY", "independent": "44_OF_44_RETAINED_AS_PARTIAL_EVIDENCE_ONLY", "mount_topology": "22_OF_22_RETAINED_AS_PARTIAL_EVIDENCE_ONLY", "phase_aware_trace": "10_OF_10_RETAINED_AS_PARTIAL_EVIDENCE_ONLY"},
    "runtime_serializer_tests": {"json_quote_escape": "NOT_EXECUTED", "json_slash_escape": "NOT_EXECUTED"},
    "P3_attempt_count": 0,
    "static_execution_lock": "NOT_ISSUED",
    "P6_provisional_freeze": "NOT_ISSUED",
    "reason": "A successful out-of-scope persistent write occurred during P0-P2. Passing assertion counts do not satisfy the mandatory write boundary.",
})

write_json("STATIC_FIXTURE_WRITE_BOUNDARY_INCIDENT.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "CONFIRMED_WRITE_BOUNDARY_VIOLATION",
    "path": str(INCIDENT),
    "sha256": EXPECTED[INCIDENT],
    "bytes": 1696,
    "mode": oct(stat.S_IMODE(incident_stat.st_mode)),
    "uid": incident_stat.st_uid,
    "gid": incident_stat.st_gid,
    "inode": incident_stat.st_ino,
    "mtime_ns": incident_stat.st_mtime_ns,
    "is_symlink": False,
    "cleanup_performed": False,
    "content_class": "SYNTHETIC_PHASE_AWARE_TRACE_FIXTURE_RESULT",
    "test_status_inside_file": "PASS_10_OF_10",
    "security_disposition": "TEST_PASS_DOES_NOT_OVERRIDE_OUT_OF_SCOPE_WRITE",
})

write_json("OUT_OF_SCOPE_FIXTURE_EVIDENCE_REVIEW.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "BYTES_VERIFIED_IN_PLACE_EPHEMERAL_LOCATION_NOT_ARCHIVED",
    "source": str(INCIDENT),
    "sha256": EXPECTED[INCIDENT],
    "bytes": 1696,
    "availability_at_governance_preflight": "AVAILABLE_AND_VERIFIED",
    "preservation": "SOURCE_LEFT_UNCHANGED_NO_COPY_NO_MOVE_NO_DELETE",
    "limitation": "/tmp may be cleaned by the operating system; the hash, size, metadata, and classification are frozen here, but the bytes are not yet archived.",
    "absence_rule": "If source becomes unavailable, record SOURCE_UNAVAILABLE; never regenerate it as historical evidence.",
})

write_json("STATIC_FIXTURE_ROOT_CAUSE.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "ROOT_CAUSE_CONFIRMED",
    "writer_layer": "CALLING_SHELL_REDIRECTION",
    "exact_recorded_command": "python3 \"$P/tooling/validate_phase_aware_trace.py\" --fixtures >/tmp/product-v1-trace-fixtures.json",
    "command_provenance": "Current Codex task execution record; no separate immutable historical shell transcript artifact was present in product-v1.",
    "validator_behavior": "validate_phase_aware_trace.py serializes the fixture result to stdout and does not contain the incident absolute path.",
    "path_selection": "EXPLICIT_ABSOLUTE_PATH_IN_SHELL_REDIRECTION",
    "tmp_hardcoded_in_product_source": False,
    "tempfile_or_default_directory_used": False,
    "TMPDIR_TMP_TEMP_relevant_to_direct_cause": False,
    "application_path_validation_possible_for_shell_redirection": False,
    "static_test_OS_confinement": "ABSENT",
    "independent_static_side_effect_audit": "ABSENT",
    "other_path_review": "Source inspection found normal P3 /tmp bindings and in-scope product writers, but no proof that every future static tool is safe without OS-enforced confinement.",
    "confirmed_not_inferred": ["shell redirection selected /tmp", "write was outside product-v1", "file hash and size", "no P3 attempt marker", "old static lock absent"],
    "remaining_hypothesis": ["Whether an unreviewed future tool would attempt another out-of-scope write; this must be tested under denial-enforcing confinement."],
})

write_json("PARTIAL_PRODUCT_ARTIFACT_DISPOSITION.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "TERMINAL_PARTIAL_EVIDENCE_READ_ONLY_REFERENCE_ONLY",
    "product_root": str(PRODUCT_V1),
    "file_count": len(product_inventory),
    "files": product_inventory,
    "partial_results_admissibility": "FACTUAL_ASSERTION_OUTPUTS_AND_INVENTORY_ONLY_NOT_CONFINEMENT_PASS_NOT_PRODUCT_PASS_NOT_REUSABLE_LOCK",
    "source_reuse": "READ_ONLY_REFERENCE_PERMITTED_FOR_FUTURE_DISTINCT_IMPLEMENTATION; EVERY NEW BYTE MUST BE REBOUND_AND_REVALIDATED",
    "toolchain_manifest": "3557_ENTRY_PARTIAL_EVIDENCE_ONLY_REVERIFY_FOR_SUCCESSOR",
    "feed_manifest": "THREE_PACKAGE_PARTIAL_EVIDENCE_ONLY_REPOPULATE_AND_REVERIFY_IN_SUCCESSOR_SCOPE",
    "serializer_repairs": "STATICALLY_PRESENT_RUNTIME_NOT_EXECUTED",
    "forbidden": ["edit product-v1", "issue old static lock", "promote old results", "reuse old P3 binding", "cleanup incident evidence"],
})

write_json("SUCCESSOR_OR_CONTINUATION_DECISION.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_LOCKED_GOVERNANCE_ONLY",
    "decision": "A_DISTINCT_PRODUCT_V2_SUBTREE_WITHIN_EXISTING_SUCCESSOR_V3",
    "continuation_of_product_v1": "DENIED",
    "existing_successor_root": str(SUCCESSOR),
    "new_product_identity": PRODUCT_V2_IDENTITY,
    "new_product_root": str(PRODUCT_V2),
    "current_state": "AUTHORIZED_RESERVED_ABSENT_NOT_IMPLEMENTED",
    "creation_authorization": "OFFLINE_SOURCE_AND_STATIC_TOOLING_ONLY_AFTER_THIS_GOVERNANCE_LOCK_AND_INCIDENT_EVIDENCE_PRESERVATION_GATE",
    "reason": "A distinct subtree preserves admitted S03 evidence and the terminal product-v1 tree while preventing identity and output mixing. A wholly new S03 successor is unnecessary because S03 confinement evidence remains separately admissible.",
    "non_interference": [str(PRODUCT_V1), str(SUCCESSOR / "artifacts"), str(SUCCESSOR / "contracts"), str(SUCCESSOR / "tooling"), str(S03_V2), str(IMPL_V1), str(INCIDENT)],
})

static_run = PRODUCT_V2 / "static-run-v1"
write_json("STATIC_TEST_WRITE_CONFINEMENT_CONTRACT.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "FUTURE_CONDITIONAL_SINGLE_USE_CONFINED_STATIC_VALIDATION_AUTHORIZED_NOT_EXECUTABLE_UNTIL_STATIC_BINDINGS_LOCKED",
    "static_identity": STATIC_IDENTITY,
    "operation_identity": STATIC_OPERATION,
    "maximum_attempts": 1,
    "consumption_boundary": "The static operation is consumed when its exact future locked bubblewrap process is launched.",
    "host_root": "READ_ONLY",
    "network_namespace": "UNSHARED",
    "no_unsandboxed_fallback": True,
    "product_root": str(PRODUCT_V2),
    "sole_host_backed_writable_bind_during_static_execution": str(static_run),
    "read_only_during_static_execution": [str(PRODUCT_V2 / "source"), str(PRODUCT_V2 / "contracts"), str(PRODUCT_V2 / "tooling"), str(PRODUCT_V1), str(SUCCESSOR / "artifacts/runtime")],
    "mandatory_controls": [
        "exact source and static-run paths canonicalized before launch",
        "source, test, tooling, schemas and exact argv digest-bound before launch",
        "bubblewrap mandatory with host root ro-bind and network unshared",
        "only static-run-v1 persistently writable",
        "no inherited uncontrolled environment",
        "no shell redirection to an unbound absolute path",
        "all fixture writers receive an explicit in-scope output path",
        "strace -ff file/process/network observation stored inside static-run-v1",
        "pre/post snapshot of authorized and representative forbidden targets",
        "successful external write is terminal and never cleaned without separate authority",
        "complete evidence preserved before derived validation",
        "independent write-surface and process-lineage audit",
    ],
    "pre_execution_gates": ["incident evidence preservation completed or source unavailability formally recorded", "product-v2 source/tooling static lock issued", "exact bwrap argv and executable hashes locked", "write targets and result schemas locked", "product-v1 inventory unchanged"],
    "prohibition": "No dotnet, NuGet, P3, product runtime tests, Guard, Recovery, Windows, or VBoxManage in the static operation.",
})

write_json("TEMP_AND_FIXTURE_PATH_BINDING.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "EXACT_FUTURE_PATHS_BOUND",
    "static_run_root": str(static_run),
    "environment": {
        "HOME": str(static_run / "home"),
        "TMPDIR": str(static_run / "tmp"),
        "TMP": str(static_run / "tmp"),
        "TEMP": str(static_run / "tmp"),
        "XDG_CACHE_HOME": str(static_run / "xdg/cache"),
        "XDG_CONFIG_HOME": str(static_run / "xdg/config"),
        "XDG_DATA_HOME": str(static_run / "xdg/data"),
        "XDG_STATE_HOME": str(static_run / "xdg/state"),
        "PYTHONPYCACHEPREFIX": str(static_run / "python-cache"),
        "PYTHONDONTWRITEBYTECODE": "1",
    },
    "deterministic_outputs": {
        "phase_aware_trace_fixtures": str(static_run / "artifacts/test-results/PHASE_AWARE_TRACE_FIXTURE_RESULT.json"),
        "mount_topology_fixtures": str(static_run / "artifacts/test-results/MOUNT_TOPOLOGY_FIXTURE_RESULT.json"),
        "static_validation": str(static_run / "artifacts/test-results/PRODUCT_V2_STATIC_VALIDATION_RESULT.json"),
        "independent_validation": str(static_run / "artifacts/test-results/PRODUCT_V2_INDEPENDENT_STATIC_VALIDATION_RESULT.json"),
        "trace_prefix": str(static_run / "artifacts/traces/static.strace"),
    },
    "path_rules": ["create-new only", "realpath must remain beneath static-run-v1", "reject symlink components", "reject .. traversal", "reject absolute output paths outside static-run-v1", "no implicit /tmp fallback", "flush close readback hash for evidence"],
})

write_json("P3_IDENTITY_ELIGIBILITY_DECISION.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "P3_BLOCKED_NOT_EXECUTABLE",
    "old_execution_identity": OLD_P3_IDENTITY,
    "old_operation_identity": OLD_P3_OPERATION,
    "old_attempt_count": 0,
    "old_identity_disposition": "UNUSED_BUT_INELIGIBLE_SOURCE_PREREQUISITES_FAILED_NOT_REBINDABLE_TO_PRODUCT_V2",
    "reserved_successor_execution_identity": NEW_P3_IDENTITY,
    "reserved_successor_operation_identity": NEW_P3_OPERATION,
    "successor_identity_status": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE",
    "required_future_binding": ["product-v2 source digest root", "product-v2 static lock", "confined static validation evidence", "exact P3 argv", "exact dotnet command sequence", "toolchain closure", "local feed closure", "runtime gates", "single-use consumption contract"],
    "future_authorization": "SEPARATE_GOVERNANCE_REQUIRED_AFTER_CONFINED_P0_P2_PASS",
    "P6": "NOT_ELIGIBLE_NOT_ISSUED",
})

write_json("EVIDENCE_PRESERVATION_AUTHORIZATION.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "AUTHORIZED_FUTURE_SINGLE_USE_NOT_EXECUTED",
    "operation_identity": PRESERVATION_OPERATION,
    "source": str(INCIDENT),
    "expected_source_sha256": EXPECTED[INCIDENT],
    "expected_source_bytes": 1696,
    "destination_root": str(ARCHIVE_ROOT),
    "destination": str(ARCHIVE_FILE),
    "rules": ["source must exist as regular non-symlink with exact hash and size", "destination root and file must be absent before create-once", "copy bytes without move or source deletion", "flush close reopen exact byte and hash verification", "freeze copied evidence read-only", "emit a separate preservation result and manifest", "if source unavailable record SOURCE_UNAVAILABLE and do not recreate"],
    "execution_in_this_governance": False,
    "cleanup_authorization": "NONE",
})

write_json("SERIALIZATION_REGRESSION_DISPOSITION.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "STATIC_REPAIR_SCOPE_ADMISSIBLE_RUNTIME_RESULTS_NOT_EXECUTED",
    "tests": {"json_quote_escape": "NOT_EXECUTED", "json_slash_escape": "NOT_EXECUTED"},
    "product_v1_source": "REFERENCE_ONLY",
    "product_v2_requirement": "Reapply only to actual serialized fields, preserve slot schema, digest-bind new tests, and run under future confined P3 after separate authorization.",
    "forbidden": ["promote static inspection to runtime PASS", "add HostIdentity solely for tests", "weaken assertions", "reuse old 101/103"],
})

write_json("OPERATION_AUTHORIZATION_MATRIX.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "STAGED_FAIL_CLOSED_AUTHORIZATION",
    "decisions": [
        {"stage": "incident preservation", "decision": "AUTHORIZED_FUTURE_SINGLE_USE", "operation": PRESERVATION_OPERATION},
        {"stage": "product-v2 offline source implementation", "decision": "AUTHORIZED_AFTER_GOVERNANCE_LOCK_AND_PRESERVATION_GATE", "operation": "NO_EXECUTION"},
        {"stage": "product-v2 static preparation and lock", "decision": "AUTHORIZED", "operation": "NO_DOTNET_NO_NUGET"},
        {"stage": "product-v2 confined static validation", "decision": "CONDITIONAL_SINGLE_USE_AUTHORIZED", "operation": STATIC_OPERATION},
        {"stage": "old P3 V1", "decision": "NOT_ELIGIBLE_NOT_EXECUTABLE", "operation": OLD_P3_OPERATION},
        {"stage": "new P3 V2", "decision": "RESERVED_NOT_AUTHORIZED", "operation": NEW_P3_OPERATION},
        {"stage": "P6 provisional freeze", "decision": "NOT_AUTHORIZED_NOT_ELIGIBLE", "operation": "NONE"},
        {"stage": "protected broker Guard V3 Recovery V3 Windows VM I5 V0.3", "decision": "NOT_AUTHORIZED", "operation": "NONE"},
    ],
    "governance_execution_counts": {"product_tests": 0, "P3": 0, "bubblewrap": 0, "strace": 0, "dotnet": 0, "nuget": 0, "windows": 0, "vboxmanage": 0, "guard": 0, "recovery": 0},
})

negative_cases = [
    ("tmp_output_silently_accepted", "REJECT"),
    ("passing_test_count_overrides_write_violation", "REJECT"),
    ("missing_original_fixture_ignored", "REJECT"),
    ("stale_source_digest_accepted", "REJECT"),
    ("unauthorized_cleanup", "REJECT"),
    ("old_product_v1_modified", "REJECT"),
    ("old_p0_p2_promoted", "REJECT"),
    ("old_p3_automatically_reused", "REJECT"),
    ("unexpected_tempfile_fallback", "REJECT"),
    ("python_cache_outside_scope", "REJECT"),
    ("symlink_escape", "REJECT"),
    ("unapproved_output_directory", "REJECT"),
    ("failed_audit_marked_pass", "REJECT"),
    ("serialization_schema_weakened", "REJECT"),
    ("dotnet_before_p3_gate", "REJECT"),
    ("p6_without_product_tests", "REJECT"),
    ("historical_s03_promoted", "REJECT"),
    ("recovery_v2_unknown_rewritten", "REJECT"),
    ("unauthorized_guard_or_recovery", "REJECT"),
]
write_json("NEGATIVE_TEST_MATRIX.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "DEFINED_INERT_GOVERNANCE_FIXTURES",
    "tests_total": len(negative_cases),
    "cases": [{"id": f"N{index:02d}", "scenario": name, "expected": expected} for index, (name, expected) in enumerate(negative_cases, 1)],
})

write_json("HISTORICAL_IMMUTABILITY_RESULT.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_AT_PREFLIGHT",
    "historical_mutations": 0,
    "product_v1": "TERMINAL_UNMODIFIED_DURING_GOVERNANCE",
    "incident_evidence": "VERIFIED_IN_PLACE_NO_CLEANUP_NO_COPY",
    "original_s03": "FAIL_CLOSED_NO_RETRY_NO_REWRITE_NO_PROMOTION",
    "s03_evidence_admissibility": "PASS_ADMISSIBLE_AS_SEPARATE_CONFINEMENT_EVIDENCE",
    "temporal_predecessor_verifier": "23_OF_24_ONLY_F14_PRODUCT_ABSENCE_FALSE_AFTER_AUTHORIZED_PRODUCT_CREATION_NOT_REWRITTEN",
    "Recovery_V2": "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY",
    "PFX_content_accessed": False,
    "PFX_metadata": pfx_meta,
})

write_json("RISK_REGISTER.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "OPEN_RISKS_FAIL_CLOSED",
    "risks": [
        {"risk": "ephemeral incident source may disappear", "control": "future exact create-once archival operation; never regenerate"},
        {"risk": "application path validation cannot constrain shell redirection", "control": "OS-enforced static sandbox plus exact runner-owned output paths"},
        {"risk": "partial product-v1 appears technically complete", "control": "terminal identity and no promotion; all successor bytes revalidated"},
        {"risk": "old unused P3 mistaken as reusable", "control": "old identity ineligible; new identity only reserved"},
        {"risk": "unreviewed static writer escapes", "control": "single writable bind, strace -ff audit, snapshots, fail closed"},
        {"risk": "Kali synthetic tests overclaimed", "control": "Windows durability, production broker, Guard V3 and recovery remain not evaluated/authorized"},
    ],
})

write_json("PRE_DECISION_LOCK.json", {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "READY_FOR_SELF_TEST_AND_INDEPENDENT_VALIDATION",
    "incident_disposition": "TERMINAL_CONFIRMED",
    "successor_decision": "A_DISTINCT_PRODUCT_V2_SUBTREE_WITHIN_EXISTING_SUCCESSOR_V3",
    "product_v2_identity": PRODUCT_V2_IDENTITY,
    "product_v2_root": str(PRODUCT_V2),
    "static_operation": STATIC_OPERATION,
    "old_P3": "UNUSED_BUT_INELIGIBLE",
    "new_P3": "RESERVED_NOT_AUTHORIZED",
    "next_legal_milestone": "PRESERVE_PRODUCT_V1_FIXTURE_INCIDENT_EVIDENCE_THEN_IMPLEMENT_AND_STATICALLY_LOCK_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_AND_EXECUTE_CONFINED_STATIC_VALIDATION_V1_ONCE_IF_ALL_GATES_PASS",
    "claim_boundary": "Governance only; no source repair, product test, P3, P6, runtime recovery, Windows, VBoxManage, Guard, VM, I5, or V0.3 action.",
})

print(json.dumps({"status": "PREFLIGHT_PASS_GOVERNANCE_ARTIFACTS_CREATED_PENDING_VALIDATION", "checks_passed": len(checks), "checks_total": len(checks), "partial_product_files": len(product_inventory)}, indent=2))
