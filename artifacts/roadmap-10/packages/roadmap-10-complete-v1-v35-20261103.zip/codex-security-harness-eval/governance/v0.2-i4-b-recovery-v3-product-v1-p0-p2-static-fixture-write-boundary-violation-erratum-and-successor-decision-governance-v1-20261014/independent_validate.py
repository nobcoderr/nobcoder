#!/usr/bin/env python3
import hashlib
import json
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V1_P0_P2_STATIC_FIXTURE_WRITE_BOUNDARY_VIOLATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
BASE = Path("/home/nobcoder")
SUCCESSOR = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014"
OLD = SUCCESSOR / "product-v1"
NEW = SUCCESSOR / "product-v2"
INCIDENT = Path("/tmp/product-v1-trace-fixtures.json")
PREV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-successor-v3-offline-product-implementation-and-confined-dotnet-test-authorization-governance-v1-20261014"


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_result(value):
    (ROOT / "INDEPENDENT_VALIDATION_RESULT.json").write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


checks = []


def verify(name, value, detail=None):
    item = {"id": f"V{len(checks) + 1:03d}", "name": name, "pass": bool(value)}
    if detail is not None:
        item["detail"] = detail
    checks.append(item)


names = [
    "PREFLIGHT_RESULT.json",
    "P0_P2_TERMINAL_DISPOSITION.json",
    "STATIC_FIXTURE_WRITE_BOUNDARY_INCIDENT.json",
    "OUT_OF_SCOPE_FIXTURE_EVIDENCE_REVIEW.json",
    "STATIC_FIXTURE_ROOT_CAUSE.json",
    "PARTIAL_PRODUCT_ARTIFACT_DISPOSITION.json",
    "SUCCESSOR_OR_CONTINUATION_DECISION.json",
    "STATIC_TEST_WRITE_CONFINEMENT_CONTRACT.json",
    "TEMP_AND_FIXTURE_PATH_BINDING.json",
    "P3_IDENTITY_ELIGIBILITY_DECISION.json",
    "EVIDENCE_PRESERVATION_AUTHORIZATION.json",
    "SERIALIZATION_REGRESSION_DISPOSITION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_TEST_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "HISTORICAL_IMMUTABILITY_RESULT.json",
    "RISK_REGISTER.json",
    "PRE_DECISION_LOCK.json",
    "GOVERNANCE_TEST_RESULT.json",
]
for name in names:
    verify("artifact regular " + name, (ROOT / name).is_file() and not (ROOT / name).is_symlink())

objects = {name: read(name) for name in names}
verify("identity consistent", all(value.get("governance_identity") == IDENTITY for value in objects.values()))
verify("governance self-test pass", objects["GOVERNANCE_TEST_RESULT.json"]["status"] == "PASS" and objects["GOVERNANCE_TEST_RESULT.json"]["checks_passed"] == objects["GOVERNANCE_TEST_RESULT.json"]["checks_total"])
verify("negative governance pass", objects["NEGATIVE_GOVERNANCE_TEST_RESULT.json"]["status"] == "PASS" and objects["NEGATIVE_GOVERNANCE_TEST_RESULT.json"]["tests_passed"] == objects["NEGATIVE_GOVERNANCE_TEST_RESULT.json"]["tests_total"] == 19)

prev_manifest = json.loads((PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json").read_text())
prev_lock = json.loads((PREV / "GOVERNANCE_LOCK.json").read_text())
verify("predecessor lock digest", sha(PREV / "GOVERNANCE_LOCK.json") == "da6b4adfd9d9ff4e791b6fefc48dfff1b4a8f8b6f8c3aaf1d88cafe2a7f1b95d")
verify("predecessor manifest digest", sha(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "18cb5a56f1bf265958ab5079f75ce2fdbd07a4ce6cb899debd8afadb6ec89de0")
verify("predecessor manifest members", len(prev_manifest["files"]) == prev_manifest["member_count"] == 25)
verify("predecessor members exact", all((PREV / item["path"]).is_file() and not (PREV / item["path"]).is_symlink() and (PREV / item["path"]).stat().st_size == item["bytes"] and sha(PREV / item["path"]) == item["sha256"] for item in prev_manifest["files"]))
rows = bytearray()
for item in sorted(prev_manifest["files"], key=lambda value: value["path"]):
    rows.extend(f"{item['sha256']}  {item['path']}\n".encode())
rows.extend(f"{sha(PREV / 'GOVERNANCE_ARTIFACT_MANIFEST.json')}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode())
verify("predecessor canonical root independent", hashlib.sha256(rows).hexdigest() == "7aa89cf06d212c58df9909d2cc4096709b7b2b1b2e439315f9cd4a0b868fd036")
verify("predecessor S03 terminal", prev_lock["original_s03_state"] == "FAIL_CLOSED_NO_RETRY_NO_REWRITE_NO_PROMOTION")
verify("predecessor admissibility separate", prev_lock["separate_evidence_admissibility"] == "PASS_ADMISSIBLE_AS_SEPARATE_CONFINEMENT_EVIDENCE")

incident = objects["STATIC_FIXTURE_WRITE_BOUNDARY_INCIDENT.json"]
verify("incident exists now", INCIDENT.is_file() and not INCIDENT.is_symlink())
verify("incident hash independently", sha(INCIDENT) == incident["sha256"] == "967f00ae0288db50ac2e884cf96fc638eac7fc6d334ffc0fcd843b070d42fc29")
verify("incident bytes independently", INCIDENT.stat().st_size == incident["bytes"] == 1696)
fixture = json.loads(INCIDENT.read_text())
verify("incident JSON exact fixture shape", fixture["schema_version"] == 1 and fixture["status"] == "PASS" and fixture["tests_total"] == fixture["tests_passed"] == 10 and len(fixture["results"]) == 10)
verify("incident security classification", incident["security_disposition"] == "TEST_PASS_DOES_NOT_OVERRIDE_OUT_OF_SCOPE_WRITE")
verify("no cleanup claim", incident["cleanup_performed"] is False)

root_cause = objects["STATIC_FIXTURE_ROOT_CAUSE.json"]
validator = (OLD / "tooling/validate_phase_aware_trace.py").read_text(encoding="utf-8")
verify("validator stdout writer", "print(json.dumps(result" in validator)
verify("validator does not name incident path", str(INCIDENT) not in validator)
verify("validator does not import tempfile", "import tempfile" not in validator)
verify("root cause writer exact", root_cause["writer_layer"] == "CALLING_SHELL_REDIRECTION")
verify("root cause command explicit absolute redirect", root_cause["exact_recorded_command"].endswith(">/tmp/product-v1-trace-fixtures.json"))
verify("root cause excludes TMP fallback", root_cause["TMPDIR_TMP_TEMP_relevant_to_direct_cause"] is False)
verify("root cause identifies missing OS confinement", root_cause["static_test_OS_confinement"] == "ABSENT")
independent_source = (OLD / "tooling/independent_static_validate.py").read_text(encoding="utf-8")
verify("old independent validator had no side-effect model", "write_surface" not in independent_source and "side_effect" not in independent_source)

terminal = objects["P0_P2_TERMINAL_DISPOSITION.json"]
verify("terminal classification exact", terminal["status"] == "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_CONTINUATION_NO_PROMOTION")
verify("P3 not consumed", terminal["P3_attempt_count"] == 0 and not (OLD / "run-v1/artifacts/runtime/P3_ONE_SHOT_ATTEMPT_STARTED.json").exists())
verify("old static lock absent", not (OLD / "PRODUCT_STATIC_EXECUTION_LOCK.json").exists())
verify("old static manifest absent", not (OLD / "PRODUCT_STATIC_SOURCE_MANIFEST.json").exists())
verify("old provisional lock absent", not (OLD / "PRODUCT_V1_PROVISIONAL_LOCK.json").exists())
verify("old provisional manifest absent", not (OLD / "PRODUCT_V1_PROVISIONAL_ARTIFACT_MANIFEST.json").exists())

partial = objects["PARTIAL_PRODUCT_ARTIFACT_DISPOSITION.json"]
verify("partial inventory count", partial["file_count"] == len(partial["files"]))
for item in partial["files"]:
    path = OLD / item["path"]
    verify("partial file " + item["path"], path.is_file() and not path.is_symlink() and path.stat().st_size == item["bytes"] and sha(path) == item["sha256"])
verify("partial results never product pass", "NOT_PRODUCT_PASS" in partial["partial_results_admissibility"])
verify("partial toolchain reverify", "REVERIFY" in partial["toolchain_manifest"])
verify("partial feed reverify", "REVERIFY" in partial["feed_manifest"])
verify("serializer runtime not executed", partial["serializer_repairs"] == "STATICALLY_PRESENT_RUNTIME_NOT_EXECUTED")

decision = objects["SUCCESSOR_OR_CONTINUATION_DECISION.json"]
verify("Option A explicit", decision["decision"] == "A_DISTINCT_PRODUCT_V2_SUBTREE_WITHIN_EXISTING_SUCCESSOR_V3")
verify("old continuation denied", decision["continuation_of_product_v1"] == "DENIED")
verify("new root exact", decision["new_product_root"] == str(NEW))
verify("new root currently absent", not NEW.exists() and not NEW.is_symlink())
verify("new identity distinct", decision["new_product_identity"] != terminal["product_identity"])
verify("new identity V4", decision["new_product_identity"].endswith("OFFLINE_PRODUCT_IMPLEMENTATION_V4"))
verify("existing S03 successor retained", decision["existing_successor_root"] == str(SUCCESSOR))
verify("old incident non-interference", str(INCIDENT) in decision["non_interference"])

confinement = objects["STATIC_TEST_WRITE_CONFINEMENT_CONTRACT.json"]
verify("static execution single-use", confinement["maximum_attempts"] == 1)
verify("static operation conditional", confinement["status"].startswith("FUTURE_CONDITIONAL_SINGLE_USE"))
verify("host root read-only", confinement["host_root"] == "READ_ONLY")
verify("network isolated", confinement["network_namespace"] == "UNSHARED")
verify("unsandboxed fallback forbidden", confinement["no_unsandboxed_fallback"] is True)
verify("sole write root exact", confinement["sole_host_backed_writable_bind_during_static_execution"] == str(NEW / "static-run-v1"))
verify("old tree read only", str(OLD) in confinement["read_only_during_static_execution"])
verify("new source read only during tests", str(NEW / "source") in confinement["read_only_during_static_execution"])
control_text = "\n".join(confinement["mandatory_controls"])
for token in ["canonicalized", "digest-bound", "bubblewrap", "only static-run-v1", "no shell redirection", "explicit in-scope", "strace -ff", "pre/post snapshot", "terminal", "evidence preserved", "independent write-surface"]:
    verify("confinement control " + token, token in control_text)
verify("static prohibits dotnet", "No dotnet" in confinement["prohibition"])
verify("static prohibits recovery", "Recovery" in confinement["prohibition"])

bindings = objects["TEMP_AND_FIXTURE_PATH_BINDING.json"]
run_root = str(NEW / "static-run-v1")
verify("binding root exact", bindings["static_run_root"] == run_root)
for key, value in bindings["environment"].items():
    if key == "PYTHONDONTWRITEBYTECODE":
        verify("bytecode setting", value == "1")
    else:
        verify("environment in scope " + key, value.startswith(run_root + "/"))
for key, value in bindings["deterministic_outputs"].items():
    verify("output in scope " + key, value.startswith(run_root + "/"))
verify("path traversal rejected", "reject .. traversal" in bindings["path_rules"])
verify("symlinks rejected", "reject symlink components" in bindings["path_rules"])
verify("external absolute paths rejected", "reject absolute output paths outside static-run-v1" in bindings["path_rules"])
verify("evidence durable sequence", "flush close readback hash for evidence" in bindings["path_rules"])

p3 = objects["P3_IDENTITY_ELIGIBILITY_DECISION.json"]
verify("old P3 exact", p3["old_execution_identity"].endswith("PRODUCT_TEST_V1"))
verify("old P3 attempt zero", p3["old_attempt_count"] == 0)
verify("old P3 ineligible", p3["old_identity_disposition"].startswith("UNUSED_BUT_INELIGIBLE"))
verify("new P3 distinct", p3["reserved_successor_execution_identity"].endswith("PRODUCT_TEST_V2"))
verify("new P3 not authorized", p3["successor_identity_status"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
verify("new P3 needs source root binding", "product-v2 source digest root" in p3["required_future_binding"])
verify("new P3 needs separate governance", p3["future_authorization"].startswith("SEPARATE_GOVERNANCE_REQUIRED"))
verify("P6 not issued", p3["P6"] == "NOT_ELIGIBLE_NOT_ISSUED")

preserve = objects["EVIDENCE_PRESERVATION_AUTHORIZATION.json"]
verify("archive operation not executed", preserve["execution_in_this_governance"] is False)
verify("archive source exact", preserve["source"] == str(INCIDENT))
verify("archive source digest exact", preserve["expected_source_sha256"] == sha(INCIDENT))
verify("archive destination outside terminal tree", not preserve["destination"].startswith(str(OLD) + "/"))
verify("archive destination currently absent", not Path(preserve["destination_root"]).exists() and not Path(preserve["destination_root"]).is_symlink())
verify("archive create once", any("create-once" in rule for rule in preserve["rules"]))
verify("archive source retained", any("without move or source deletion" in rule for rule in preserve["rules"]))
verify("archive no cleanup", preserve["cleanup_authorization"] == "NONE")

serialization = objects["SERIALIZATION_REGRESSION_DISPOSITION.json"]
verify("quote still not executed", serialization["tests"]["json_quote_escape"] == "NOT_EXECUTED")
verify("slash still not executed", serialization["tests"]["json_slash_escape"] == "NOT_EXECUTED")
verify("schema workaround forbidden", "add HostIdentity solely for tests" in serialization["forbidden"])
verify("old result reuse forbidden", "reuse old 101/103" in serialization["forbidden"])

matrix = objects["OPERATION_AUTHORIZATION_MATRIX.json"]
stage_map = {item["stage"]: item for item in matrix["decisions"]}
verify("incident preservation authorization bounded", stage_map["incident preservation"]["decision"] == "AUTHORIZED_FUTURE_SINGLE_USE")
verify("product-v2 creation gated", stage_map["product-v2 offline source implementation"]["decision"] == "AUTHORIZED_AFTER_GOVERNANCE_LOCK_AND_PRESERVATION_GATE")
verify("static test conditional only", stage_map["product-v2 confined static validation"]["decision"] == "CONDITIONAL_SINGLE_USE_AUTHORIZED")
verify("old P3 denied in matrix", stage_map["old P3 V1"]["decision"] == "NOT_ELIGIBLE_NOT_EXECUTABLE")
verify("new P3 reserved in matrix", stage_map["new P3 V2"]["decision"] == "RESERVED_NOT_AUTHORIZED")
verify("P6 denied in matrix", stage_map["P6 provisional freeze"]["decision"] == "NOT_AUTHORIZED_NOT_ELIGIBLE")
verify("operations zero independently", all(value == 0 for value in matrix["governance_execution_counts"].values()))

immutability = objects["HISTORICAL_IMMUTABILITY_RESULT.json"]
verify("historical mutations zero", immutability["historical_mutations"] == 0)
verify("S03 not promoted", immutability["original_s03"] == "FAIL_CLOSED_NO_RETRY_NO_REWRITE_NO_PROMOTION")
verify("temporal predicate contextualized", immutability["temporal_predecessor_verifier"].startswith("23_OF_24_ONLY_F14"))
verify("V2 unknown preserved", immutability["Recovery_V2"].startswith("CONSUMPTION_UNKNOWN"))
verify("PFX content unaccessed", immutability["PFX_content_accessed"] is False)
pfx = BASE / ".dotnet/corefx/cryptography/x509stores/my/6C1DA3DE00985BC59141C2F29474051A5FBD85EB.pfx"
st = pfx.lstat()
actual_pfx = {"content_accessed": False, "size": st.st_size, "mode": oct(stat.S_IMODE(st.st_mode)), "mtime_ns": st.st_mtime_ns}
verify("PFX metadata exact", actual_pfx == immutability["PFX_metadata"], actual_pfx)

prelock = objects["PRE_DECISION_LOCK.json"]
verify("predecision ready", prelock["status"] == "READY_FOR_SELF_TEST_AND_INDEPENDENT_VALIDATION")
verify("next milestone begins preservation", prelock["next_legal_milestone"].startswith("PRESERVE_PRODUCT_V1_FIXTURE_INCIDENT_EVIDENCE"))
verify("claim boundary no product tests", "no source repair, product test, P3, P6" in prelock["claim_boundary"])

status = "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED"
result = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": status,
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "checks": checks,
    "method": "Separate read-only verifier recomputing predecessor roots, incident bytes, partial inventory, path bindings, authorization matrix, and current PFX metadata without invoking product tooling.",
    "operation_counts": matrix["governance_execution_counts"],
}
write_result(result)
print(json.dumps({"status": status, "checks_passed": result["checks_passed"], "checks_total": result["checks_total"]}, indent=2))
if status != "PASS":
    raise SystemExit(1)
