#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V1_P0_P2_STATIC_FIXTURE_WRITE_BOUNDARY_VIOLATION_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


for required in ["PREFLIGHT_RESULT.json", "GOVERNANCE_TEST_RESULT.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "INDEPENDENT_VALIDATION_RESULT.json"]:
    value = load(required)
    if value["status"] != "PASS":
        raise SystemExit("mandatory validation not PASS: " + required)

if MANIFEST.exists() or LOCK.exists():
    raise SystemExit("manifest or lock already exists")

members = []
for path in sorted(ROOT.iterdir(), key=lambda value: value.name):
    if path.name in {MANIFEST.name, LOCK.name}:
        continue
    if path.is_symlink() or not path.is_file():
        raise SystemExit("non-regular governance member: " + path.name)
    members.append({"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path)})

manifest = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_COMPLETE_PENDING_FINAL_LOCK",
    "member_count": len(members),
    "files": members,
    "coverage": "Every regular governance artifact except this manifest and GOVERNANCE_LOCK.json; lock excluded to avoid circularity.",
}
MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
manifest_sha = sha(MANIFEST)

rows = bytearray()
for item in sorted(members, key=lambda value: value["path"]):
    rows.extend(f"{item['sha256']}  {item['path']}\n".encode())
rows.extend(f"{manifest_sha}  {MANIFEST.name}\n".encode())
canonical_root = hashlib.sha256(rows).hexdigest()

preflight = load("PREFLIGHT_RESULT.json")
self_test = load("GOVERNANCE_TEST_RESULT.json")
negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
independent = load("INDEPENDENT_VALIDATION_RESULT.json")
decision = load("SUCCESSOR_OR_CONTINUATION_DECISION.json")
p3 = load("P3_IDENTITY_ELIGIBILITY_DECISION.json")
preservation = load("EVIDENCE_PRESERVATION_AUTHORIZATION.json")
prelock = load("PRE_DECISION_LOCK.json")
matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")

lock = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_LOCKED_GOVERNANCE_ONLY",
    "disposition": "PRODUCT_V1_TERMINAL_DISTINCT_PRODUCT_V2_AUTHORIZED_OFFLINE_WITH_OS_CONFINED_STATIC_TESTING_P3_BLOCKED",
    "governance_manifest_sha256": manifest_sha,
    "canonical_artifact_root_sha256": canonical_root,
    "canonical_root_member_count": len(members) + 1,
    "canonical_root_algorithm": "SHA256 of member-path-sorted UTF-8 rows '<sha256>  <relative-path>\\n', followed by the GOVERNANCE_ARTIFACT_MANIFEST.json row; GOVERNANCE_LOCK.json excluded",
    "predecessor_governance_lock_sha256": "da6b4adfd9d9ff4e791b6fefc48dfff1b4a8f8b6f8c3aaf1d88cafe2a7f1b95d",
    "predecessor_governance_manifest_sha256": "18cb5a56f1bf265958ab5079f75ce2fdbd07a4ce6cb899debd8afadb6ec89de0",
    "predecessor_canonical_root_sha256": "7aa89cf06d212c58df9909d2cc4096709b7b2b1b2e439315f9cd4a0b868fd036",
    "canonical_preflight": f"{preflight['checks_passed']}_OF_{preflight['checks_total']}_PASS",
    "governance_self_tests": f"{self_test['checks_passed']}_OF_{self_test['checks_total']}_PASS",
    "negative_governance_tests": f"{negative['tests_passed']}_OF_{negative['tests_total']}_PASS",
    "independent_validation": f"{independent['checks_passed']}_OF_{independent['checks_total']}_PASS",
    "freeze_verification_expected": "30_OF_30_PASS",
    "incident_sha256": "967f00ae0288db50ac2e884cf96fc638eac7fc6d334ffc0fcd843b070d42fc29",
    "incident_bytes": 1696,
    "incident_disposition": "CONFIRMED_WRITE_BOUNDARY_VIOLATION_PRODUCT_V1_TERMINAL",
    "product_v1": "FAIL_CLOSED_TERMINAL_NO_RETRY_NO_CONTINUATION_NO_PROMOTION",
    "successor_decision": decision["decision"],
    "product_v2_identity": decision["new_product_identity"],
    "product_v2_root": decision["new_product_root"],
    "product_v2_source_authorization": "AUTHORIZED_AFTER_EVIDENCE_PRESERVATION_GATE",
    "confined_static_operation": "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V1",
    "confined_static_operation_status": "CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_EXECUTABLE_UNTIL_STATIC_BINDINGS_LOCKED",
    "incident_preservation_operation": preservation["operation_identity"],
    "incident_preservation_status": preservation["status"],
    "old_P3_identity": p3["old_execution_identity"],
    "old_P3_attempt_count": p3["old_attempt_count"],
    "old_P3_disposition": p3["old_identity_disposition"],
    "new_P3_identity": p3["reserved_successor_execution_identity"],
    "new_P3_status": p3["successor_identity_status"],
    "P6": p3["P6"],
    "original_S03": "FAIL_CLOSED_NO_RETRY_NO_REWRITE_NO_PROMOTION",
    "S03_evidence": "PASS_ADMISSIBLE_AS_SEPARATE_CONFINEMENT_EVIDENCE",
    "Recovery_V2": "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY",
    "governance_execution_counts": matrix["governance_execution_counts"],
    "protected_broker_Guard_V3_operational_recovery": "NOT_AUTHORIZED",
    "next_legal_milestone": prelock["next_legal_milestone"],
    "claim_boundary": "This is an immutable governance decision. It does not repair or continue product-v1, execute the archival operation, create product-v2, run static fixtures, consume P3, issue P6, or authorize operational recovery.",
}
LOCK.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps({"status": lock["status"], "manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": canonical_root, "member_count": len(members) + 1, "lock_sha256": sha(LOCK)}, indent=2))
