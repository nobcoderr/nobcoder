#!/usr/bin/env python3
"""Primary governance validation and negative mutation fixtures."""

from __future__ import annotations

import ast
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parent
V4 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v4-20261020")
V5 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v5-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V4_STARTUP_PROCESS_LINEAGE_EPHEMERAL_TMPFS_WRITE_CLASSIFICATION_TOKEN_BUDGET_SEMANTICS_AND_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V4_ROOT = "e2a319dfc6c31af46b8f0f136eb8ed2045f9c72b07625b0bbd25434e62726cac"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_ONCE_IF_ALL_GATES_PASS"
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V4_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json", "V4_TERMINAL_EVIDENCE_BINDING.json", "V4_TERMINAL_DISPOSITION.json",
    "STARTUP_PROCESS_LINEAGE_ADJUDICATION.json", "MOUNT_PROVENANCE_WRITE_CLASSIFICATION_ADJUDICATION.json",
    "TOKEN_BUDGET_SEMANTICS_ADJUDICATION.json", "FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "TYPED_RUNTIME_POLICY_CONTRACT.json",
    "V4_FAILURE_AND_V5_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V5_REQUIREMENTS.json",
    "SUCCESSOR_V5_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted(node for node in path.rglob("*") if node.is_file())]
    material = "".join(f"{digest}  {name}\n" for name, digest in rows).encode()
    return hashlib.sha256(material).hexdigest(), len(rows)


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def bundle_violations(docs: dict[str, dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    terminal = docs["terminal"]
    snapshot = docs["snapshot"]
    lineage = docs["lineage"]
    mount = docs["mount"]
    budget = docs["budget"]
    freeze = docs["freeze"]
    ownership = docs["ownership"]
    typed = docs["typed"]
    requirements = docs["requirements"]
    successor = docs["successor"]
    authority = docs["authority"]
    next_step = docs["next"]
    if terminal.get("disposition") != "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY" or terminal.get("immutable") is not True:
        errors.append("V4_TERMINAL")
    if terminal.get("attempt") != "1_OF_1_CONSUMED_NO_RETRY" or terminal.get("worker_invocation") != 1 or terminal.get("semantic_codex_execution") != 1:
        errors.append("V4_COUNTS")
    if terminal.get("worker_result") != "EMITTED_AND_CONTROLLER_WRAPPED" or terminal.get("candidate") != "HYPOTHESIS_QUARANTINED":
        errors.append("V4_OUTPUT")
    if terminal.get("post_validation") != "49_OF_53_FAIL_CLOSED_DIAGNOSTIC_COMPLETE" or terminal.get("confinement") != "NOT_PROVEN" or terminal.get("pass_locked") != "NOT_ISSUED":
        errors.append("V4_NO_PROMOTION")
    if any(terminal.get(key) != "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "evidence_reclassification", "promotion"]):
        errors.append("V4_CONTINUATION")
    if snapshot.get("canonical_tree_root_sha256") != V4_ROOT or snapshot.get("member_count") != 104 or len(snapshot.get("members", [])) != 104:
        errors.append("SNAPSHOT_CLOSURE")
    if snapshot.get("snapshot_kind") != "FROZEN_FAILURE_EVIDENCE_EXTERNAL_GOVERNANCE_BINDING" or snapshot.get("pass_locked_implication") != "NONE":
        errors.append("SNAPSHOT_SEMANTICS")
    process_contract = lineage.get("successor_semantics", {})
    if lineage.get("flat_executable_allowlist_classifier_defect") != "YES" or lineage.get("observed_event_count") != 11:
        errors.append("LINEAGE_DEFECT")
    if lineage.get("semantic_decision") != "EXPECTED_CODEX_SHELL_SNAPSHOT_STARTUP_LIFECYCLE_DESCENDANTS_FOR_THE_EXACT_OBSERVED_V4_TRACE" or lineage.get("actual_unexpected_worker_tool_execution_proven") != "NO":
        errors.append("LINEAGE_DECISION")
    if process_contract.get("flat_executable_allowlist") != "PROHIBITED" or process_contract.get("unknown_or_broken_lineage") != "FAIL_CLOSED" or len(process_contract.get("required_fields", [])) != 7:
        errors.append("LINEAGE_CONTRACT")
    write_contract = mount.get("successor_semantics", {})
    topology = mount.get("sandbox_topology_evidence", {})
    if mount.get("path_only_write_classifier_defect") != "YES" or mount.get("home_nobcoder_write_count") != 56 or mount.get("private_dev_null_write_count") != 5:
        errors.append("MOUNT_DEFECT")
    if topology.get("tmpfs_home_present") is not True or topology.get("tmpfs_precedes_codex_home_construction") is not True or topology.get("host_root_read_only") != "READ_ONLY":
        errors.append("MOUNT_TOPOLOGY")
    semantic_writes = mount.get("semantic_decision", {})
    if semantic_writes.get("home_nobcoder_writes") != "EPHEMERAL_SANDBOX_TMPFS_WRITES_FOR_THE_EXACT_OBSERVED_V4_TOPOLOGY" or semantic_writes.get("actual_out_of_scope_host_backed_write_proven") != "NO":
        errors.append("MOUNT_DECISION")
    if write_contract.get("home_path_blanket_exemption") != "PROHIBITED" or write_contract.get("path_string_only_inference") != "PROHIBITED" or write_contract.get("unknown_mount_or_backing_provenance") != "FAIL_CLOSED" or len(write_contract.get("classification_tuple", [])) != 7:
        errors.append("MOUNT_CONTRACT")
    token_contract = budget.get("successor_typed_contract", {})
    if budget.get("v4_configured_model_tokens") != 5000 or budget.get("v4_configured_semantics") != "AMBIGUOUS_UNTYPED_MODEL_TOKENS" or budget.get("budget_pass") != "NOT_PROVEN":
        errors.append("BUDGET_DEFECT")
    if budget.get("v4_derived_model_tokens_observed") != 14622 or budget.get("derived_formula_observed") != "INPUT_TOKENS_PLUS_OUTPUT_TOKENS":
        errors.append("BUDGET_EVIDENCE")
    mandatory_budget = ["accounting_source", "input_limit", "cached_input_policy", "cache_write_input_policy", "output_limit", "reasoning_output_limit", "total_limit", "total_formula", "measurement_semantics", "over_budget_action", "baseline_feasibility_precheck"]
    if any(key not in token_contract for key in mandatory_budget) or token_contract.get("baseline_feasibility_precheck") != "REQUIRED_BEFORE_ATTEMPT_MARKER" or token_contract.get("over_budget_action") != "FAIL_CLOSED_TERMINAL_NO_RETRY":
        errors.append("BUDGET_CONTRACT")
    if token_contract.get("numeric_limits_for_v5") != "MUST_BE_CHOSEN_AND_LOCKED_IN_FRESH_V5_CONTRACT_NOT_BY_THIS_ERRATUM":
        errors.append("BUDGET_NUMERIC_LIMIT_DECISION")
    if freeze.get("decision") != "FROZEN_FAILURE_EVIDENCE_IS_A_VALID_TERMINAL_PRESERVATION_STATE" or freeze.get("governance_snapshot_freeze") != "FROZEN_FAILURE_EVIDENCE":
        errors.append("FAILURE_FREEZE")
    if freeze.get("pass_locked") != "NO" or freeze.get("acceptance_promotion") != "NO" or freeze.get("snapshot_root_sha256") != V4_ROOT or freeze.get("snapshot_member_count") != 104:
        errors.append("FAILURE_FREEZE_NO_PROMOTION")
    if ownership.get("semantic_process_lineage_classifier_contract_defect") != "YES" or ownership.get("mount_provenance_write_classifier_contract_defect") != "YES" or ownership.get("typed_token_budget_contract_defect") != "YES" or ownership.get("failure_evidence_freeze_contract_gap") != "YES":
        errors.append("OWNERSHIP")
    if ownership.get("security_worker_runtime_v1_defect") != "NO" or ownership.get("codex_runtime_0_163_0_compatibility_defect") != "NO" or ownership.get("confinement_bypass") != "NO":
        errors.append("OWNERSHIP_EXCLUSIONS")
    if "FAILURE_FREEZE_NEVER_IMPLIES_PASS_LOCKED" not in typed.get("rules", []):
        errors.append("TYPED_POLICY")
    required = set(requirements.get("mandatory_requirements", []))
    mandatory = {
        "SEMANTIC_PROCESS_LINEAGE_CLASSIFICATION", "FLAT_EXECUTABLE_ALLOWLIST_PROHIBITED",
        "MOUNT_PROVENANCE_AWARE_WRITE_CLASSIFICATION", "PATH_ONLY_OR_HOME_PREFIX_WRITE_EXEMPTION_PROHIBITED",
        "TYPED_TOKEN_BUDGET_CONTRACT", "TOKEN_BUDGET_BASELINE_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT",
        "DIAGNOSTIC_FAILURE_EVIDENCE_FREEZE", "PASS_AND_FAILURE_FREEZE_STATES_SEPARATE",
        "STRICT_SCHEMA_COMPATIBILITY_PRECHECK_BEFORE_ATTEMPT", "BIND_DESTINATION_FEASIBILITY_PRECHECK_BEFORE_ATTEMPT",
        "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    }
    if not mandatory.issubset(required):
        errors.append("V5_REQUIREMENTS")
    if successor.get("decision") != DECISION or successor.get("state") != "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED":
        errors.append("SUCCESSOR_DECISION")
    if any(successor.get(key) != 0 for key in ["attempt_count", "worker_invocation_count", "semantic_codex_execution_count"]):
        errors.append("SUCCESSOR_COUNTS")
    counters = authority.get("current_governance_operation_counters", {})
    if len(counters) != 12 or any(value != 0 for value in counters.values()):
        errors.append("COUNTERS")
    for key, value in authority.items():
        if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False:
            errors.append("AUTHORITY_ESCALATION")
            break
    if next_step.get("next_if_pass_locked") != NEXT or next_step.get("v5_may_be_created_during_this_governance_milestone") is not False:
        errors.append("NEXT_MILESTONE")
    return errors


def main() -> None:
    expected = SCRIPTS | BASE
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"primary input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("P_SCRIPT_" + script, valid)
    docs = {
        "terminal": read("V4_TERMINAL_DISPOSITION.json"), "snapshot": read("V4_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json"),
        "lineage": read("STARTUP_PROCESS_LINEAGE_ADJUDICATION.json"), "mount": read("MOUNT_PROVENANCE_WRITE_CLASSIFICATION_ADJUDICATION.json"),
        "budget": read("TOKEN_BUDGET_SEMANTICS_ADJUDICATION.json"), "freeze": read("FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json"),
        "ownership": read("DEFECT_OWNERSHIP_DECISION.json"), "typed": read("TYPED_RUNTIME_POLICY_CONTRACT.json"),
        "requirements": read("SUCCESSOR_V5_REQUIREMENTS.json"), "successor": read("SUCCESSOR_V5_AUTHORIZATION_DECISION.json"),
        "authority": read("AUTHORITY_NON_ESCALATION_DECISION.json"), "next": read("NEXT_LEGAL_MILESTONE.json"),
    }
    violations = bundle_violations(docs)
    check("P001_BASE_BUNDLE", not violations, violations)
    root, members = tree(V4)
    check("P002_V4_BYTES_UNCHANGED", root == V4_ROOT and members == 104, {"root": root, "members": members})
    check("P003_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    binding = read("V4_TERMINAL_EVIDENCE_BINDING.json")
    check("P004_V4_BINDING", binding.get("canonical_tree_root_sha256") == V4_ROOT and binding.get("member_count") == 104 and binding.get("governance_snapshot_status") == "FROZEN_FAILURE_EVIDENCE")
    check("P005_LINEAGE_EXACT_EVENTS", docs["lineage"].get("observed_event_count") == len(docs["lineage"].get("observed_events", [])) == 11 and docs["lineage"].get("model_tool_call_count") == 0)
    check("P006_MOUNT_COUNTS", docs["mount"].get("observed_rejected_write_count") == 61 and docs["mount"].get("home_nobcoder_write_count") == 56 and docs["mount"].get("private_dev_null_write_count") == 5)
    usage = docs["budget"].get("provider_reported_usage", {})
    check("P007_TOKEN_EVIDENCE", usage.get("input_tokens") == 14447 and usage.get("output_tokens") == 175 and usage.get("reasoning_output_tokens") == 0 and 14447 + 175 == 14622)
    check("P008_FAILURE_IDS", docs["terminal"].get("failed_post_validation_checks") == ["P010_RUNTIME_PASS", "P013_NO_UNEXPECTED_EXEC", "P035_TOKEN_BUDGET", "P046_TYPED_WRITE_CLASSIFICATION"])
    regressions = read("V4_FAILURE_AND_V5_SUCCESSOR_REGRESSION_MATRIX.json").get("cases", [])
    check("P009_REGRESSION_MATRIX_16", len(regressions) == 16 and all(row.get("expected") for row in regressions))
    matrix = read("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    check("P010_NEGATIVE_MATRIX_32", len(matrix.get("cases", [])) == 32 and all(case.get("expected") == "REJECT" for case in matrix.get("cases", [])))
    failed = [row for row in checks if row["status"] == "FAIL"]
    write("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V4_ERRATUM_GOVERNANCE_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "GOVERNANCE_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
    })

    negative_results: list[dict[str, Any]] = []
    def add(case_id: str, mutator: Callable[[dict[str, dict[str, Any]]], None]) -> None:
        mutated = deepcopy(docs)
        mutator(mutated)
        rejected = bool(bundle_violations(mutated))
        negative_results.append({"case_id": case_id, "expected": "REJECT", "observed": "REJECT" if rejected else "ACCEPT", "status": "PASS" if rejected else "FAIL"})

    add("N001_V4_DISPOSITION_MUTATION", lambda d: d["terminal"].update(disposition="PASS_LOCKED"))
    add("N002_ATTEMPT_RESET", lambda d: d["terminal"].update(attempt="0_OF_1"))
    add("N003_EXEC_COUNT_CHANGE", lambda d: d["terminal"].update(semantic_codex_execution=0))
    add("N004_V4_RETRY", lambda d: d["terminal"].update(retry="AUTHORIZED"))
    add("N005_V4_REVALIDATION", lambda d: d["terminal"].update(revalidation="AUTHORIZED"))
    add("N006_V4_RECLASSIFICATION", lambda d: d["terminal"].update(post_validation="PASS"))
    add("N007_FLAT_EXEC_ALLOWLIST", lambda d: d["lineage"]["successor_semantics"].update(flat_executable_allowlist="ALLOWED"))
    add("N008_WRONG_PARENT_ALLOW", lambda d: d["lineage"]["successor_semantics"].update(required_fields=[x for x in d["lineage"]["successor_semantics"]["required_fields"] if x != "PARENT_PID"]))
    add("N009_WRONG_PHASE_ALLOW", lambda d: d["lineage"]["successor_semantics"].update(required_fields=[x for x in d["lineage"]["successor_semantics"]["required_fields"] if x != "LIFECYCLE_PHASE"]))
    add("N010_UNKNOWN_LINEAGE_ALLOW", lambda d: d["lineage"]["successor_semantics"].update(unknown_or_broken_lineage="ALLOW"))
    add("N011_PATH_ONLY_TMPFS", lambda d: d["mount"]["successor_semantics"].update(path_string_only_inference="ALLOWED"))
    add("N012_HOME_BLANKET_EXEMPTION", lambda d: d["mount"]["successor_semantics"].update(home_path_blanket_exemption="ALLOWED"))
    add("N013_MISSING_MOUNT_ID", lambda d: d["mount"]["successor_semantics"].update(classification_tuple=[x for x in d["mount"]["successor_semantics"]["classification_tuple"] if x != "MOUNT_ID"]))
    add("N014_HOST_BIND_AS_EPHEMERAL", lambda d: d["mount"]["semantic_decision"].update(actual_out_of_scope_host_backed_write_proven="YES_BUT_ACCEPTED"))
    add("N015_UNKNOWN_MOUNT_ALLOW", lambda d: d["mount"]["successor_semantics"].update(unknown_mount_or_backing_provenance="ALLOW"))
    add("N016_ASSUME_5000_OUTPUT", lambda d: d["budget"].update(v4_configured_semantics="OUTPUT_ONLY"))
    add("N017_RAISE_TO_OBSERVED", lambda d: d["budget"]["successor_typed_contract"].update(numeric_limits_for_v5="14622"))
    add("N018_NO_ACCOUNTING_SOURCE", lambda d: d["budget"]["successor_typed_contract"].pop("accounting_source"))
    add("N019_NO_TOTAL_FORMULA", lambda d: d["budget"]["successor_typed_contract"].pop("total_formula"))
    add("N020_NO_BUDGET_FEASIBILITY", lambda d: d["budget"]["successor_typed_contract"].update(baseline_feasibility_precheck="NOT_REQUIRED"))
    add("N021_FAILURE_FREEZE_PASS", lambda d: d["freeze"].update(pass_locked="YES"))
    add("N022_FAILURE_EVIDENCE_OVERWRITE", lambda d: d["freeze"].update(decision="OVERWRITE_AND_PASS"))
    add("N023_INCOMPLETE_FAILURE_SNAPSHOT", lambda d: d["snapshot"].update(member_count=103))
    add("N024_V5_CREATED", lambda d: d["successor"].update(state="CREATED"))
    add("N025_CURRENT_CODEX_AUTHORITY", lambda d: d["authority"].update(codex_as_worker_invocation_authorized_now=True))
    add("N026_TARGET_NETWORK_AUTHORITY", lambda d: d["authority"].update(target_access_authorized=True))
    add("N027_CREDENTIAL_AUTHORITY", lambda d: d["authority"].update(credential_use_authorized=True))
    add("N028_SUBAGENT_PARALLEL_AUTHORITY", lambda d: d["authority"].update(parallelism_authorized=True))
    add("N029_CAPABILITY_PROMOTION_AUTHORITY", lambda d: d["authority"].update(candidate_promotion_authorized=True))
    add("N030_SUBMISSION_AUTHORITY", lambda d: d["authority"].update(submission_automation_authorized=True))
    add("N031_DROP_ONE_SHOT", lambda d: d["requirements"].update(mandatory_requirements=[x for x in d["requirements"]["mandatory_requirements"] if x != "ONE_SHOT_EXECUTION"]))
    add("N032_DROP_SEPARATE_ACCEPTANCE", lambda d: d["requirements"].update(mandatory_requirements=[x for x in d["requirements"]["mandatory_requirements"] if x != "SEPARATE_ACCEPTANCE_ADJUDICATION"]))
    negative_failed = [row for row in negative_results if row["status"] == "FAIL"]
    write("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V4_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT", "schema_version": "1.0",
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001", "status": "PASS" if not negative_failed else "FAIL_CLOSED",
        "tests": negative_results, "tests_total": len(negative_results), "tests_passed": len(negative_results) - len(negative_failed), "tests_failed": len(negative_failed),
    })
    print(json.dumps({"primary": "PASS" if not failed else "FAIL_CLOSED", "primary_passed": len(checks) - len(failed), "primary_total": len(checks), "negative": "PASS" if not negative_failed else "FAIL_CLOSED", "negative_passed": len(negative_results) - len(negative_failed), "negative_total": len(negative_results)}, sort_keys=True))
    if failed or negative_failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
