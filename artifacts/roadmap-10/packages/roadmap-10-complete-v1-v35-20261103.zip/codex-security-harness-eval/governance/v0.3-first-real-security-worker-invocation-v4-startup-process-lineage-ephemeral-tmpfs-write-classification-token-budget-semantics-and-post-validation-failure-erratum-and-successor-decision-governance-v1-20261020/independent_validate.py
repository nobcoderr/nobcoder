#!/usr/bin/env python3
"""Independent read-only validation of the V4 governance adjudication."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V4 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v4-20261020")
V5 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v5-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V4_STARTUP_PROCESS_LINEAGE_EPHEMERAL_TMPFS_WRITE_CLASSIFICATION_TOKEN_BUDGET_SEMANTICS_AND_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V4_ROOT = "e2a319dfc6c31af46b8f0f136eb8ed2045f9c72b07625b0bbd25434e62726cac"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_CONDITIONALLY"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted(node for node in path.rglob("*") if node.is_file())]
    material = "".join(f"{digest}  {name}\n" for name, digest in rows).encode()
    return hashlib.sha256(material).hexdigest(), len(rows)


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(payload: dict[str, Any]) -> None:
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    root, members = tree(V4)
    check("I001_V4_BYTES_UNCHANGED", root == V4_ROOT and members == 104, {"root": root, "members": members})
    check("I002_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    marker = json.loads((V4 / "static-run-v4/ATTEMPT_MARKER.json").read_text())
    runtime = json.loads((V4 / "static-run-v4/runtime-result-0001.json").read_text())
    post = json.loads((V4 / "static-run-v4/independent-post-validation-0001.json").read_text())
    contract = json.loads((V4 / "contracts/EXECUTION_CONTRACT.json").read_text())
    lock = json.loads((V4 / "STATIC_EXECUTION_LOCK.json").read_text())
    check("I003_ATTEMPT_CONSUMED", marker.get("attempt_count") == 1 and marker.get("attempt_limit") == 1)
    check("I004_WORKER_COUNTS", marker.get("worker_invocation_count") == 1 and marker.get("codex_as_worker_invocation_count") == 1)
    check("I005_RUNTIME_SUCCESS_EXIT", runtime.get("exit_status") == 0 and runtime.get("semantic_codex_exec_count") == 1)
    check("I006_OUTPUT_EMITTED", runtime.get("worker_result_state") == "EMITTED_AND_CONTROLLER_WRAPPED" and runtime.get("controller_result", {}).get("status") == "PROPOSAL_COMPLETE")
    check("I007_CANDIDATE_QUARANTINED", runtime.get("controller_result", {}).get("proposals", [{}])[0].get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED")
    check("I008_POST_49_OF_53", post.get("status") == "FAIL_CLOSED_DIAGNOSTIC_COMPLETE" and post.get("checks_passed") == 49 and post.get("checks_total") == 53)
    check("I009_EXACT_FAILURE_IDS", post.get("failure_ids") == ["P010_RUNTIME_PASS", "P013_NO_UNEXPECTED_EXEC", "P035_TOKEN_BUDGET", "P046_TYPED_WRITE_CLASSIFICATION"])
    unexpected = runtime.get("unexpected_execve_events", [])
    check("I010_STARTUP_EVENT_COUNT", len(unexpected) == 11)
    paths = [row.get("executable") for row in unexpected]
    check("I011_STARTUP_PATHS", paths == ["/usr/bin/zsh", "/usr/bin/run-parts", "/usr/bin/tr", "/usr/bin/grep", "/usr/bin/kali-motd", "/usr/bin/wc", "/usr/bin/tr", "/usr/bin/sed", "/usr/bin/wc", "/usr/bin/tr", "/usr/bin/zsh"])
    check("I012_SNAPSHOT_GENERATOR_ARGV", "# Snapshot file" in unexpected[0].get("raw", "") and "__codex_snapshot_command" in unexpected[0].get("raw", ""))
    check("I013_SNAPSHOT_REPLAY_ARGV", "shell_snapshots" in unexpected[-1].get("raw", "") and "set -e; ." in unexpected[-1].get("raw", ""))
    check("I014_NO_MODEL_TOOL_CALL", runtime.get("transcript", {}).get("tool_call_count") == 0)
    rejected = runtime.get("typed_write_evidence", {}).get("rejected", [])
    home = [row for row in rejected if row.get("path", "").startswith("/home/nobcoder/")]
    dev = [row for row in rejected if row.get("path") == "/dev/null"]
    check("I015_WRITE_COUNTS", len(rejected) == 61 and len(home) == 56 and len(dev) == 5)
    argv = lock.get("strace_argv", [])
    home_tmpfs = next((i for i in range(len(argv) - 1) if argv[i:i + 2] == ["--tmpfs", "/home/nobcoder"]), -1)
    codex_home = next((i for i in range(len(argv) - 1) if argv[i:i + 2] == ["--dir", "/home/nobcoder/.codex"]), -1)
    check("I016_HOME_TMPFS_ORDER", 0 <= home_tmpfs < codex_home)
    check("I017_HOST_ROOT_READ_ONLY", contract.get("sandbox", {}).get("host_root") == "READ_ONLY")
    usage = runtime.get("transcript", {}).get("usage", {})
    check("I018_PROVIDER_USAGE", usage == {"cache_write_input_tokens": 0, "cached_input_tokens": 0, "input_tokens": 14447, "output_tokens": 175, "reasoning_output_tokens": 0})
    check("I019_DERIVED_TOKEN_TOTAL", runtime.get("resource_usage", {}).get("model_tokens_observed") == 14622 and usage.get("input_tokens", 0) + usage.get("output_tokens", 0) == 14622)
    check("I020_AMBIGUOUS_V4_BUDGET", contract.get("budget", {}).get("model_tokens") == 5000 and set(contract.get("budget", {})) == {"disk_bytes", "memory_bytes", "model_tokens", "output_bytes", "processes", "timeout_seconds"})

    terminal = read("V4_TERMINAL_DISPOSITION.json")
    snapshot = read("V4_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json")
    binding = read("V4_TERMINAL_EVIDENCE_BINDING.json")
    lineage = read("STARTUP_PROCESS_LINEAGE_ADJUDICATION.json")
    mount = read("MOUNT_PROVENANCE_WRITE_CLASSIFICATION_ADJUDICATION.json")
    budget = read("TOKEN_BUDGET_SEMANTICS_ADJUDICATION.json")
    freeze = read("FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    requirements = read("SUCCESSOR_V5_REQUIREMENTS.json")
    successor = read("SUCCESSOR_V5_AUTHORIZATION_DECISION.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I021_V4_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY" and terminal.get("immutable") is True)
    check("I022_V4_NO_CONTINUATION", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "evidence_reclassification", "promotion"]))
    check("I023_SNAPSHOT_COMPLETE", snapshot.get("canonical_tree_root_sha256") == V4_ROOT and snapshot.get("member_count") == len(snapshot.get("members", [])) == 104)
    check("I024_FAILURE_BINDING", binding.get("governance_snapshot_status") == "FROZEN_FAILURE_EVIDENCE" and binding.get("native_v4_evidence_freeze_status") == "NOT_ISSUED")
    check("I025_LINEAGE_DECISION", lineage.get("semantic_decision") == "EXPECTED_CODEX_SHELL_SNAPSHOT_STARTUP_LIFECYCLE_DESCENDANTS_FOR_THE_EXACT_OBSERVED_V4_TRACE" and lineage.get("actual_unexpected_worker_tool_execution_proven") == "NO")
    process_contract = lineage.get("successor_semantics", {})
    check("I026_LINEAGE_SEMANTIC", process_contract.get("flat_executable_allowlist") == "PROHIBITED" and process_contract.get("unknown_or_broken_lineage") == "FAIL_CLOSED")
    check("I027_MOUNT_DECISION", mount.get("semantic_decision", {}).get("home_nobcoder_writes") == "EPHEMERAL_SANDBOX_TMPFS_WRITES_FOR_THE_EXACT_OBSERVED_V4_TOPOLOGY" and mount.get("semantic_decision", {}).get("actual_out_of_scope_host_backed_write_proven") == "NO")
    write_contract = mount.get("successor_semantics", {})
    check("I028_MOUNT_SEMANTIC", write_contract.get("home_path_blanket_exemption") == "PROHIBITED" and write_contract.get("unknown_mount_or_backing_provenance") == "FAIL_CLOSED")
    check("I029_BUDGET_UNTYPED", budget.get("v4_configured_semantics") == "AMBIGUOUS_UNTYPED_MODEL_TOKENS" and budget.get("budget_pass") == "NOT_PROVEN")
    token_contract = budget.get("successor_typed_contract", {})
    check("I030_BUDGET_TYPED", token_contract.get("baseline_feasibility_precheck") == "REQUIRED_BEFORE_ATTEMPT_MARKER" and token_contract.get("total_formula") == "REQUIRED_EXACT_NON_OVERLAPPING_FORMULA")
    check("I031_FAILURE_FREEZE_NOT_PASS", freeze.get("governance_snapshot_freeze") == "FROZEN_FAILURE_EVIDENCE" and freeze.get("pass_locked") == "NO" and freeze.get("acceptance_promotion") == "NO")
    check("I032_OWNERSHIP_SEPARATED", ownership.get("semantic_process_lineage_classifier_contract_defect") == "YES" and ownership.get("mount_provenance_write_classifier_contract_defect") == "YES" and ownership.get("typed_token_budget_contract_defect") == "YES" and ownership.get("failure_evidence_freeze_contract_gap") == "YES")
    check("I033_NO_BASE_DEFECT", ownership.get("security_worker_runtime_v1_defect") == "NO" and ownership.get("codex_runtime_0_163_0_compatibility_defect") == "NO" and ownership.get("confinement_bypass") == "NO")
    check("I034_SUCCESSOR", successor.get("decision") == DECISION and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I035_SUCCESSOR_ZERO", successor.get("attempt_count") == 0 and successor.get("worker_invocation_count") == 0 and successor.get("semantic_codex_execution_count") == 0)
    required = set(requirements.get("mandatory_requirements", []))
    check("I036_V5_REQUIREMENTS", {"SEMANTIC_PROCESS_LINEAGE_CLASSIFICATION", "MOUNT_PROVENANCE_AWARE_WRITE_CLASSIFICATION", "TYPED_TOKEN_BUDGET_CONTRACT", "DIAGNOSTIC_FAILURE_EVIDENCE_FREEZE", "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION"}.issubset(required))
    counters = authority.get("current_governance_operation_counters", {})
    check("I037_ZERO_OPERATIONS", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    check("I038_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I039_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_passed") == 32 and negative.get("tests_failed") == 0)
    check("I040_V5_STILL_ABSENT", not V5.exists() and not V5.is_symlink())
    failed = [row for row in checks if row["status"] == "FAIL"]
    write({
        "record_type": "FIRST_WORKER_V4_ERRATUM_INDEPENDENT_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "INDEPENDENT_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": counters,
    })
    print(json.dumps({"status": "PASS" if not failed else "FAIL_CLOSED", "passed": len(checks) - len(failed), "total": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
