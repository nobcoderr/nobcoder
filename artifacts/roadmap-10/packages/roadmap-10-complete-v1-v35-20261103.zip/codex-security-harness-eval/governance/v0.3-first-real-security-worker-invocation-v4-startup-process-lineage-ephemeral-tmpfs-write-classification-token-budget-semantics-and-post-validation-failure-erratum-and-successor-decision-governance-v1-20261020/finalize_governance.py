#!/usr/bin/env python3
"""Final verification, immutable freeze, manifest, and governance lock."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V4 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v4-20261020")
V5 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v5-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V4_STARTUP_PROCESS_LINEAGE_EPHEMERAL_TMPFS_WRITE_CLASSIFICATION_TOKEN_BUDGET_SEMANTICS_AND_POST_VALIDATION_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5_ONCE_IF_ALL_GATES_PASS"
V4_ROOT = "e2a319dfc6c31af46b8f0f136eb8ed2045f9c72b07625b0bbd25434e62726cac"
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V4_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json", "V4_TERMINAL_EVIDENCE_BINDING.json", "V4_TERMINAL_DISPOSITION.json",
    "STARTUP_PROCESS_LINEAGE_ADJUDICATION.json", "MOUNT_PROVENANCE_WRITE_CLASSIFICATION_ADJUDICATION.json",
    "TOKEN_BUDGET_SEMANTICS_ADJUDICATION.json", "FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_DECISION.json", "TYPED_RUNTIME_POLICY_CONTRACT.json",
    "V4_FAILURE_AND_V5_SUCCESSOR_REGRESSION_MATRIX.json", "SUCCESSOR_V5_REQUIREMENTS.json",
    "SUCCESSOR_V5_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json"}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def tree(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted(node for node in path.rglob("*") if node.is_file())]
    material = "".join(f"{digest}  {name}\n" for name, digest in rows).encode()
    return hashlib.sha256(material).hexdigest(), len(rows)


def canonical(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"finalizer input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SCRIPT_" + script, valid)
    v4_root, v4_members = tree(V4)
    check("F001_V4_UNCHANGED", v4_root == V4_ROOT and v4_members == 104, {"root": v4_root, "members": v4_members})
    check("F002_V5_ABSENT", not V5.exists() and not V5.is_symlink())
    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = read("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F003_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("F004_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_passed") == 32 and negative.get("tests_failed") == 0)
    check("F005_INDEPENDENT_PASS", independent.get("status") == "PASS" and independent.get("checks_failed") == 0)
    check("F006_RESULT_IDENTITIES", all(doc.get("governance_identity") == IDENTITY for doc in [primary, negative, independent]))
    terminal = read("V4_TERMINAL_DISPOSITION.json")
    snapshot = read("V4_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json")
    binding = read("V4_TERMINAL_EVIDENCE_BINDING.json")
    lineage = read("STARTUP_PROCESS_LINEAGE_ADJUDICATION.json")
    mount = read("MOUNT_PROVENANCE_WRITE_CLASSIFICATION_ADJUDICATION.json")
    budget = read("TOKEN_BUDGET_SEMANTICS_ADJUDICATION.json")
    failure_freeze = read("FAILURE_EVIDENCE_FREEZE_ADJUDICATION.json")
    ownership = read("DEFECT_OWNERSHIP_DECISION.json")
    requirements = read("SUCCESSOR_V5_REQUIREMENTS.json")
    successor = read("SUCCESSOR_V5_AUTHORIZATION_DECISION.json")
    authority = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    summary = read("GOVERNANCE_DECISION_SUMMARY.json")
    next_step = read("NEXT_LEGAL_MILESTONE.json")
    check("F007_V4_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY" and terminal.get("immutable") is True)
    check("F008_V4_COUNTS", terminal.get("attempt") == "1_OF_1_CONSUMED_NO_RETRY" and terminal.get("worker_invocation") == 1 and terminal.get("semantic_codex_execution") == 1)
    check("F009_V4_OUTPUT", terminal.get("runtime_exit") == 0 and terminal.get("worker_result") == "EMITTED_AND_CONTROLLER_WRAPPED" and terminal.get("candidate") == "HYPOTHESIS_QUARANTINED")
    check("F010_V4_FAILURE", terminal.get("post_validation") == "49_OF_53_FAIL_CLOSED_DIAGNOSTIC_COMPLETE" and terminal.get("confinement") == "NOT_PROVEN" and terminal.get("pass_locked") == "NOT_ISSUED")
    check("F011_NO_V4_CONTINUATION", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "relock", "revalidation", "retry", "continuation", "evidence_reclassification", "promotion"]))
    check("F012_SNAPSHOT_COMPLETE", snapshot.get("canonical_tree_root_sha256") == V4_ROOT and snapshot.get("member_count") == len(snapshot.get("members", [])) == 104)
    check("F013_SNAPSHOT_FAILURE_ONLY", snapshot.get("snapshot_kind") == "FROZEN_FAILURE_EVIDENCE_EXTERNAL_GOVERNANCE_BINDING" and snapshot.get("pass_locked_implication") == "NONE")
    check("F014_BINDING", binding.get("governance_snapshot_status") == "FROZEN_FAILURE_EVIDENCE" and binding.get("native_v4_evidence_freeze_status") == "NOT_ISSUED")
    check("F015_LINEAGE_DEFECT", lineage.get("flat_executable_allowlist_classifier_defect") == "YES" and lineage.get("observed_event_count") == 11)
    check("F016_LINEAGE_DECISION", lineage.get("semantic_decision") == "EXPECTED_CODEX_SHELL_SNAPSHOT_STARTUP_LIFECYCLE_DESCENDANTS_FOR_THE_EXACT_OBSERVED_V4_TRACE" and lineage.get("actual_unexpected_worker_tool_execution_proven") == "NO")
    check("F017_LINEAGE_CONTRACT", lineage.get("successor_semantics", {}).get("flat_executable_allowlist") == "PROHIBITED" and lineage.get("successor_semantics", {}).get("unknown_or_broken_lineage") == "FAIL_CLOSED")
    check("F018_MOUNT_DEFECT", mount.get("path_only_write_classifier_defect") == "YES" and mount.get("home_nobcoder_write_count") == 56 and mount.get("private_dev_null_write_count") == 5)
    check("F019_MOUNT_DECISION", mount.get("semantic_decision", {}).get("home_nobcoder_writes") == "EPHEMERAL_SANDBOX_TMPFS_WRITES_FOR_THE_EXACT_OBSERVED_V4_TOPOLOGY" and mount.get("semantic_decision", {}).get("actual_out_of_scope_host_backed_write_proven") == "NO")
    check("F020_MOUNT_CONTRACT", mount.get("successor_semantics", {}).get("path_string_only_inference") == "PROHIBITED" and mount.get("successor_semantics", {}).get("unknown_mount_or_backing_provenance") == "FAIL_CLOSED")
    check("F021_BUDGET_DEFECT", budget.get("v4_configured_model_tokens") == 5000 and budget.get("v4_configured_semantics") == "AMBIGUOUS_UNTYPED_MODEL_TOKENS" and budget.get("budget_pass") == "NOT_PROVEN")
    check("F022_BUDGET_CONTRACT", budget.get("successor_typed_contract", {}).get("total_formula") == "REQUIRED_EXACT_NON_OVERLAPPING_FORMULA" and budget.get("successor_typed_contract", {}).get("baseline_feasibility_precheck") == "REQUIRED_BEFORE_ATTEMPT_MARKER")
    check("F023_FAILURE_FREEZE", failure_freeze.get("governance_snapshot_freeze") == "FROZEN_FAILURE_EVIDENCE" and failure_freeze.get("pass_locked") == "NO" and failure_freeze.get("acceptance_promotion") == "NO")
    check("F024_OWNERSHIP", ownership.get("semantic_process_lineage_classifier_contract_defect") == "YES" and ownership.get("mount_provenance_write_classifier_contract_defect") == "YES" and ownership.get("typed_token_budget_contract_defect") == "YES" and ownership.get("failure_evidence_freeze_contract_gap") == "YES")
    check("F025_NO_BASE_DEFECT", ownership.get("security_worker_runtime_v1_defect") == "NO" and ownership.get("codex_runtime_0_163_0_compatibility_defect") == "NO" and ownership.get("confinement_bypass") == "NO")
    check("F026_SUCCESSOR", successor.get("decision") == DECISION and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F027_SUCCESSOR_ZERO", successor.get("attempt_count") == 0 and successor.get("worker_invocation_count") == 0 and successor.get("semantic_codex_execution_count") == 0)
    required = set(requirements.get("mandatory_requirements", []))
    check("F028_REQUIREMENTS", {"SEMANTIC_PROCESS_LINEAGE_CLASSIFICATION", "MOUNT_PROVENANCE_AWARE_WRITE_CLASSIFICATION", "TYPED_TOKEN_BUDGET_CONTRACT", "DIAGNOSTIC_FAILURE_EVIDENCE_FREEZE", "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION"}.issubset(required))
    counters = authority.get("current_governance_operation_counters", {})
    check("F029_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {key: value for key, value in authority.items() if (key.endswith("_authorized") or key.endswith("_authorized_now")) and value is not False}
    check("F030_NO_CURRENT_ESCALATION", not escalations, escalations)
    check("F031_SUMMARY", summary.get("successor_decision") == DECISION and summary.get("failure_evidence_status") == "FROZEN_FAILURE_EVIDENCE" and summary.get("pass_locked") == "NO")
    check("F032_NEXT", next_step.get("next_if_pass_locked") == NEXT and next_step.get("v5_may_be_created_during_this_governance_milestone") is False)
    failed = [row for row in checks if row["status"] == "FAIL"]
    if failed:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failed))
    write(FREEZE, {
        "record_type": "FIRST_WORKER_V4_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT", "schema_version": "1.0",
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001", "status": "PASS",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "v4_tree_root_sha256": V4_ROOT, "v4_member_count": 104, "v5_absent": True,
        "failure_evidence_state": "FROZEN_FAILURE_EVIDENCE", "failure_evidence_does_not_imply_pass_locked": True,
        "current_governance_operation_counters": counters, "read_only_freeze_enforced_by_successful_finalizer_exit": True,
    })
    names = sorted(expected | {FREEZE})
    rows = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in names]
    artifact_root = canonical(rows)
    write(MANIFEST, {
        "record_type": "FIRST_WORKER_V4_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0",
        "member_count": len(rows), "members": rows, "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    snapshot_sha = sha(ROOT / "V4_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json")
    write(LOCK, {
        "record_type": "FIRST_WORKER_V4_ERRATUM_GOVERNANCE_LOCK", "schema_version": "1.0",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "v4_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V4",
        "v4_disposition": "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY", "v4_immutable": True,
        "v4_attempt_count": 1, "v4_attempt_limit": 1, "v4_worker_invocation_count": 1,
        "v4_semantic_codex_execution_count": 1, "v4_runtime_exit": 0,
        "v4_worker_result": "EMITTED_AND_CONTROLLER_WRAPPED", "v4_candidate": "HYPOTHESIS_QUARANTINED",
        "v4_post_validation": "49_OF_53_FAIL_CLOSED_DIAGNOSTIC_COMPLETE", "v4_confinement": "NOT_PROVEN", "v4_pass_locked": "NOT_ISSUED",
        "v4_failure_evidence_status": "FROZEN_FAILURE_EVIDENCE", "v4_failure_evidence_snapshot_manifest_sha256": snapshot_sha,
        "v4_failure_evidence_snapshot_root_sha256": V4_ROOT, "failure_freeze_implies_pass_locked": False,
        "semantic_process_lineage_classifier_contract_defect": "YES",
        "exact_observed_startup_lineage": "EXPECTED_CODEX_SHELL_SNAPSHOT_STARTUP_LIFECYCLE_DESCENDANTS",
        "actual_unexpected_worker_tool_execution_proven": "NO", "semantic_process_lineage_classification": "REQUIRED",
        "flat_executable_allowlist": "PROHIBITED", "unknown_process_lineage": "FAIL_CLOSED",
        "mount_provenance_write_classifier_contract_defect": "YES",
        "exact_observed_home_writes": "EPHEMERAL_SANDBOX_TMPFS_WRITES", "actual_out_of_scope_host_backed_write_proven": "NO",
        "mount_provenance_aware_write_classification": "REQUIRED", "path_only_write_exemption": "PROHIBITED", "unknown_mount_provenance": "FAIL_CLOSED",
        "typed_token_budget_contract_defect": "YES", "v4_model_tokens_5000_semantics": "AMBIGUOUS_UNTYPED",
        "v4_derived_model_tokens_observed": 14622, "v4_budget_pass": "NOT_PROVEN",
        "typed_token_budget_contract": "REQUIRED", "token_budget_baseline_feasibility_precheck": "REQUIRED_BEFORE_ATTEMPT_MARKER",
        "numeric_v5_token_limits": "MUST_BE_FRESHLY_CHOSEN_AND_LOCKED_NOT_INFERRED_FROM_14622",
        "failure_evidence_freeze_contract_gap": "YES", "diagnostic_failure_evidence_freeze": "REQUIRED",
        "security_worker_runtime_v1_defect": "NO", "codex_runtime_0_163_0_compatibility_defect": "NO", "confinement_bypass": "NO",
        "v5_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V5",
        "v5_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v5_attempt_count": 0, "v5_attempt_limit": 1, "v5_worker_invocation_count": 0, "v5_worker_invocation_limit": 1,
        "v5_semantic_codex_execution_count": 0, "v5_semantic_codex_execution_limit": 1,
        "one_shot_execution": "REQUIRED", "separate_acceptance_adjudication": "REQUIRED",
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "validation": {
            "primary": {"status": primary["status"], "passed": primary["checks_passed"], "total": primary["checks_total"]},
            "negative": {"status": negative["status"], "passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent": {"status": independent["status"], "passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        },
        "operation_counters": counters, "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root, "next_legal_milestone": NEXT,
        "authority_ceiling": "V5_ENGINEERING_AND_ONE_LOCAL_FIXTURE_WORKER_INVOCATION_CONDITIONALLY_AUTHORIZED_ONLY_AFTER_THIS_LOCK_NO_CURRENT_RUNTIME_TARGET_CREDENTIAL_OR_PARALLEL_AUTHORITY",
    })
    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    readonly = all((path.stat().st_mode & 0o222) == 0 for path in ROOT.iterdir() if path.is_file())
    v4_after, count_after = tree(V4)
    if not readonly or v4_after != V4_ROOT or count_after != 104 or V5.exists():
        raise SystemExit("post-freeze verification failed")
    print(json.dumps({"status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION, "manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root, "files": len(rows) + 2}, sort_keys=True))


if __name__ == "__main__":
    main()
