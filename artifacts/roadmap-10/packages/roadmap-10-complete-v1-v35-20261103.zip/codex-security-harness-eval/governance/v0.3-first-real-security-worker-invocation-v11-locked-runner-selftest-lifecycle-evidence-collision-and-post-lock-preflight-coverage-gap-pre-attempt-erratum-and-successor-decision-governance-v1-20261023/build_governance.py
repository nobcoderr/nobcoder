#!/usr/bin/env python3
"""Build the governance-only V11 locked self-test lifecycle erratum."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_LOCKED_RUNNER_SELFTEST_LIFECYCLE_"
    "EVIDENCE_COLLISION_AND_POST_LOCK_PREFLIGHT_COVERAGE_GAP_PRE_ATTEMPT_ERRATUM_"
    "AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "TERMINALIZE_V11_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONDITIONALLY"
NEXT = "IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_NO_EXECUTION_UNTIL_ALL_GATES_PASS"
V11_TREE_ROOT = "6b41bc493b1876468de57cb82cb3b7de9bf811450f9579ee5e493473d75023ef"
KEY_HASHES = {
    "STATIC_EXECUTION_LOCK.json": "3da68aa2f89327b30bbbd35eaa354b3701a5d395c06a5e9dd6bb96a72ec31b96",
    "STATIC_SOURCE_MANIFEST.json": "20a972c171dcf32d71e17cbfc247689c7e32f543a739449fda5b3d0d618100dc",
    "STATIC_EXECUTION_LOCK_VERIFICATION.json": "950faad0a48ee2f0a48775590ca92995c691657a66161a91b8c56eb5ebe8a554",
    "src/runner_v11.py": "696a52a3cbce95dd3bf3e91b2d299205cef7f076bd0bb305af34c0842440b43f",
    "src/topology_observer_v11.py": "3de60c5018ad90fb0da88ebde0d7ab9c87016954a9248495fab415cef05ab1c2",
    "static-run-v11/observer-selftest-result-0001.json": "4565dc9cc0717a210324f646069b3e6ce10b6e954273059331ff2aede755c4c9",
    "static-run-v11/observer-selftest-0001/snapshot.json": "afe2b707af4af9acd9de3e6b0163651de7cb8435e67cf1ae332aa9320a585244",
}
SOURCE_FILES = {"build_governance.py", "validate_governance.py", "negative_fixtures.py", "independent_validate.py", "freeze_governance.py", "verify_governance_freeze.py"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = []
    for item in sorted((p for p in path.rglob("*") if p.is_file()), key=lambda p: p.relative_to(path).as_posix()):
        rows.append({"path": item.relative_to(path).as_posix(), "sha256": sha(item), "bytes": item.stat().st_size})
    material = "".join(f"{r['sha256']}  {r['path']}\n" for r in rows)
    return hashlib.sha256(material.encode()).hexdigest(), rows


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_v11() -> list[dict[str, Any]]:
    root, rows = tree(V11)
    if root != V11_TREE_ROOT or len(rows) != 72:
        raise SystemExit(f"V11 drift: {root=} members={len(rows)}")
    for relative, expected in KEY_HASHES.items():
        if sha(V11 / relative) != expected:
            raise SystemExit(f"V11 key evidence drift: {relative}")
    lock = load(V11 / "STATIC_EXECUTION_LOCK.json")
    manifest = load(V11 / "STATIC_SOURCE_MANIFEST.json")
    verify = load(V11 / "STATIC_EXECUTION_LOCK_VERIFICATION.json")
    selftest = load(V11 / "static-run-v11/observer-selftest-result-0001.json")
    if lock["status"] != "STATIC_LOCKED_NOT_EXECUTED" or lock["canonical_source_root_sha256"] != "2cb45c5c31c754f6de3c422377732f31a1e11117be96f286b0790bedbf1e8d5f":
        raise SystemExit("V11 static lock fact drift")
    if manifest["member_count"] != 61 or verify["status"] != "PASS" or verify["checks_passed"] != verify["checks_total"] != 221:
        raise SystemExit("V11 lock verification fact drift")
    if selftest["status"] != "PASS" or len(selftest["checks"]) != 7 or not all(selftest["checks"].values()):
        raise SystemExit("V11 observer self-test fact drift")
    if any((V11 / "static-run-v11" / n).exists() for n in ["ATTEMPT_MARKER.json", "runtime-result-0001.json", "pre-attempt-gates-run-0001.json"]):
        raise SystemExit("V11 execution artifacts unexpectedly exist")
    src = (V11 / "src/runner_v11.py").read_text(encoding="utf-8")
    ast.parse(src)
    required = [
        'root = STATIC_RUN / "observer-selftest-0001"',
        "root.mkdir(mode=0o700, exist_ok=False)",
        "observer_selftest = run_temporal_observer_selftest()",
        'STATIC_RUN / "pre-attempt-gates-run-0001.json"',
        'STATIC_RUN / "ATTEMPT_MARKER.json"',
    ]
    if not all(token in src for token in required):
        raise SystemExit("V11 locked runner semantics drift")
    if not (src.index("observer_selftest = run_temporal_observer_selftest()") < src.index('STATIC_RUN / "pre-attempt-gates-run-0001.json"') < src.rindex('STATIC_RUN / "ATTEMPT_MARKER.json"')):
        raise SystemExit("V11 lifecycle ordering drift")
    if not (V11 / "static-run-v11/observer-selftest-0001").is_dir():
        raise SystemExit("V11 self-test evidence directory missing")
    return rows


def main() -> None:
    actual = {p.name for p in ROOT.iterdir() if p.is_file()}
    if actual != SOURCE_FILES or any(p.is_symlink() or p.is_dir() for p in ROOT.iterdir()):
        raise SystemExit(f"unexpected source set: {sorted(actual)}")
    rows = verify_v11()
    if V12.exists() or V12.is_symlink():
        raise SystemExit("V12 already exists")

    write("GOVERNANCE_CHARTER.json", {
        "record_type": "V11_LOCKED_SELFTEST_LIFECYCLE_ERRATUM_GOVERNANCE_CHARTER",
        "scope": "GOVERNANCE_ONLY_READ_ONLY_V11_LOCKED_PRE_ATTEMPT_EVIDENCE_ADJUDICATION",
        "authorized_actions": ["READ_V11_LOCKED_EVIDENCE", "ADJUDICATE_LIFECYCLE_AND_COVERAGE_DEFECTS", "AUTHORIZE_OR_DENY_DISTINCT_V12", "VALIDATE_AND_FREEZE_GOVERNANCE"],
        "prohibited_actions": ["PATCH_RELOCK_RETRY_REVALIDATE_OR_EXECUTE_V11", "DELETE_RENAME_OVERWRITE_OR_REGENERATE_OBSERVER_SELFTEST_0001", "CREATE_OR_EXECUTE_V12", "WORKER_OR_CODEX_INVOCATION", "CREDENTIAL_TARGET_NETWORK_SUBAGENT_PARALLEL_EXPLOIT_CAPABILITY_PROMOTION_OR_SUBMISSION_OPERATION"],
    })
    write("V11_EVIDENCE_BINDING.json", {
        "record_type": "V11_LOCKED_SELFTEST_LIFECYCLE_EXTERNAL_EVIDENCE_BINDING",
        "workspace": str(V11), "workspace_member_count": len(rows), "canonical_workspace_root_sha256": V11_TREE_ROOT,
        "key_artifact_sha256": KEY_HASHES, "static_source_member_count": 61,
        "canonical_source_root_sha256": "2cb45c5c31c754f6de3c422377732f31a1e11117be96f286b0790bedbf1e8d5f",
        "binding_semantics": "EXACT_BYTES_READ_ONLY_REFERENCE", "source_workspace_mutated": False,
    })
    write("V11_TERMINAL_DISPOSITION.json", {
        "record_type": "V11_LOCKED_SELFTEST_LIFECYCLE_TERMINAL_DISPOSITION",
        "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11",
        "disposition": "FAIL_CLOSED_PRE_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "static_lock": "EXISTING_STATIC_LOCK_REMAINS_IMMUTABLE", "attempt": "0_OF_1_NOT_CONSUMED",
        "worker_invocation": "0_OF_1", "codex_as_worker_invocation": "0_OF_1",
        "patch": "PROHIBITED", "relock": "PROHIBITED", "retry": "PROHIBITED", "revalidation": "PROHIBITED",
        "observer_selftest_evidence_mutation": "PROHIBITED", "pass_locked": False,
    })
    write("SELFTEST_LIFECYCLE_COLLISION_ADJUDICATION.json", {
        "record_type": "V11_LOCKED_RUNNER_SELFTEST_LIFECYCLE_COLLISION_ADJUDICATION",
        "locked_runner_selftest_lifecycle_defect": "YES",
        "facts": {
            "existing_selftest_identity": "observer-selftest-0001", "existing_selftest_status": "PASS_7_OF_7",
            "runner_always_calls_selftest_before_pre_attempt_record": True,
            "selftest_uses_write_once_directory_creation": "mkdir(mode=0o700, exist_ok=False)",
            "existing_directory_causes": "FileExistsError", "collision_is_deterministic": True,
            "collision_occurs_before_attempt_marker_worker_or_codex": True,
        },
        "temporal_observer_implementation_defect": "NO", "observer_selftest_defect": "NO",
        "generic_delete_overwrite_exist_ok_true_or_write_once_weakening": "PROHIBITED",
    })
    write("POST_LOCK_PREFLIGHT_COVERAGE_GAP_ADJUDICATION.json", {
        "record_type": "V11_POST_LOCK_PREFLIGHT_COVERAGE_GAP_ADJUDICATION",
        "post_lock_preflight_coverage_gap": "YES",
        "adjudication": "POST_LOCK_VALIDATION_DID_NOT_EXERCISE_LOCKED_ENTRYPOINT_THROUGH_COMPLETE_PRE_ATTEMPT_PATH",
        "required_successor_coverage": "EXECUTE_EXACT_LOCKED_ENTRYPOINT_THROUGH_COMPLETE_PRE_ATTEMPT_PATH_AND_STOP_IMMEDIATELY_BEFORE_AUTHORITATIVE_ATTEMPT_CREATION",
        "runtime_claim_limit": "STATIC_AND_SELFTEST_EVIDENCE_ONLY_NO_TEMPORAL_WORKER_RUNTIME_CLAIM",
    })
    write("UNPROVEN_RUNTIME_STATE.json", {
        "record_type": "V11_UNPROVEN_RUNTIME_STATE",
        "temporal_observer_runtime": "NOT_ESTABLISHED", "process_lineage": "NOT_PROVEN",
        "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN",
        "reason": "AUTHORITATIVE_ATTEMPT_REMAINS_0_OF_1_AND_WORKER_RUNTIME_NEVER_STARTED",
    })
    write("SUCCESSOR_V12_SELFTEST_LIFECYCLE_CONTRACT.json", {
        "record_type": "SUCCESSOR_V12_SELFTEST_LIFECYCLE_CONTRACT", "lifecycle_owner": "REQUIRED_EXPLICIT_SINGLE_OWNER",
        "authorized_strategies": {
            "CONSUME_LOCK_BOUND_IMMUTABLE_PASS_ARTIFACT": ["bind_exact_artifact_identity", "bind_exact_artifact_digest", "bind_exact_current_static_lock_digest", "require_PASS", "consume_read_only_without_rewrite"],
            "DISTINCT_APPEND_ONLY_PREFLIGHT_AND_RUNTIME_IDENTITIES": ["separate_exact_evidence_ids", "separate_paths", "append_only_creation", "no_alias_or_overwrite"],
        },
        "strategy_selection": "EXACTLY_ONE_SELECTED_AND_LOCKED_BEFORE_EXECUTION_NO_FALLBACK",
        "prohibited_shortcuts": ["DELETE_EXISTING_SELFTEST", "RENAME_EXISTING_SELFTEST", "OVERWRITE_EXISTING_SELFTEST", "exist_ok=True", "WEAKEN_WRITE_ONCE_PROVENANCE", "GENERIC_COLLISION_BYPASS"],
        "attempt_marker_rule": "ABSENT_UNTIL_SELFTEST_LIFECYCLE_GATE_COMPLETES_PASS",
        "post_lock_entrypoint_dry_run": "REQUIRED_COMPLETE_PRE_ATTEMPT_PATH_STOP_IMMEDIATELY_BEFORE_ATTEMPT_CREATION",
    })
    write("V11_FAILURE_AND_V12_REGRESSION_MATRIX.json", {
        "record_type": "V11_FAILURE_AND_V12_SUCCESSOR_REGRESSION_MATRIX",
        "cases": [
            {"id": "R001", "case": "existing_valid_selftest_exact_current_lock", "expected": "PASS_WITHOUT_COLLISION_OR_REWRITE"},
            {"id": "R002", "case": "missing_selftest", "expected": "FAIL_CLOSED_BEFORE_ATTEMPT"},
            {"id": "R003", "case": "modified_selftest_digest", "expected": "FAIL_CLOSED_BEFORE_ATTEMPT"},
            {"id": "R004", "case": "stale_selftest_from_different_lock", "expected": "FAIL_CLOSED_BEFORE_ATTEMPT"},
            {"id": "R005", "case": "exact_current_lock_selftest_acceptance", "expected": "PASS_READ_ONLY_CONSUMPTION"},
            {"id": "R006", "case": "attempt_marker_before_lifecycle_gate_complete", "expected": "FAIL_CLOSED"},
            {"id": "R007", "case": "locked_entrypoint_complete_pre_attempt_dry_run", "expected": "STOP_BEFORE_ATTEMPT_WITH_ALL_GATES_PASS"},
        ],
    })
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V11_LOCKED_SELFTEST_LIFECYCLE_NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "cases": [
            {"id": "N001", "mutation": "patch_or_relock_v11", "expected": "REJECT"},
            {"id": "N002", "mutation": "delete_rename_or_overwrite_selftest_0001", "expected": "REJECT"},
            {"id": "N003", "mutation": "use_exist_ok_true_to_hide_collision", "expected": "REJECT"},
            {"id": "N004", "mutation": "accept_missing_selftest", "expected": "REJECT"},
            {"id": "N005", "mutation": "accept_modified_digest", "expected": "REJECT"},
            {"id": "N006", "mutation": "accept_stale_different_lock_artifact", "expected": "REJECT"},
            {"id": "N007", "mutation": "create_attempt_before_lifecycle_pass", "expected": "REJECT"},
            {"id": "N008", "mutation": "infer_runtime_or_confinement_pass", "expected": "REJECT"},
            {"id": "N009", "mutation": "create_or_execute_v12_during_governance", "expected": "REJECT"},
            {"id": "N010", "mutation": "worker_or_codex_invocation", "expected": "REJECT"},
        ],
    })
    write("SUCCESSOR_V12_AUTHORIZATION_DECISION.json", {
        "record_type": "SUCCESSOR_V12_AUTHORIZATION_DECISION", "decision": DECISION,
        "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED", "attempt_count": 0,
        "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
        "creation_or_execution_this_milestone": False, "one_shot_execution_requires_separate_engineering_gates": True,
    })
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "V11_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION",
        "implementation_or_execution_authority_opened_now": False,
        "operation_counters": {k: 0 for k in ["v11_patch", "v11_relock", "v11_retry", "v11_revalidation", "v12_creation", "v12_execution", "worker_invocation", "codex_invocation", "credential", "target", "network", "subagent", "parallelism", "exploit_replay", "capability_graph", "promotion", "submission"]},
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V11_ERRATUM_NEXT_LEGAL_MILESTONE", "next_legal_milestone": NEXT,
        "current_milestone_ceiling": "PASS_LOCKED_GOVERNANCE_ONLY", "v12_execution_authorized_now": False,
    })


if __name__ == "__main__":
    main()
