#!/usr/bin/env python3
"""Freeze governance only after all validation gates pass."""
from __future__ import annotations
import hashlib,json,os
from pathlib import Path

ROOT=Path(__file__).resolve().parent; V11=Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020"); V12=Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY="V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_LOCKED_RUNNER_SELFTEST_LIFECYCLE_EVIDENCE_COLLISION_AND_POST_LOCK_PREFLIGHT_COVERAGE_GAP_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION="TERMINALIZE_V11_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_CONDITIONALLY"
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n): return json.loads((ROOT/n).read_text())
def write(n,x):
    with (ROOT/n).open("x") as f: json.dump({"governance_identity":IDENTITY,**x},f,indent=2,sort_keys=True); f.write("\n")
def v11root():
    rows=[(p.relative_to(V11).as_posix(),sha(p)) for p in sorted((x for x in V11.rglob("*") if x.is_file()),key=lambda x:x.relative_to(V11).as_posix())]
    return hashlib.sha256("".join(f"{h}  {n}\n" for n,h in rows).encode()).hexdigest(),len(rows)
def main():
    for n in ["GOVERNANCE_ARTIFACT_MANIFEST.json","GOVERNANCE_LOCK.json","FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"]:
        if (ROOT/n).exists(): raise SystemExit("freeze artifact exists")
    primary=read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"); negative=read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"); independent=read("INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    if any(x["status"]!="PASS" or x["checks_failed"] for x in [primary,negative,independent]): raise SystemExit("validation gate failed")
    vr,vc=v11root(); checks={"primary":primary["status"]=="PASS","negative":negative["status"]=="PASS","independent":independent["status"]=="PASS","v11_root":vr=="6b41bc493b1876468de57cb82cb3b7de9bf811450f9579ee5e493473d75023ef","v11_members":vc==72,"attempt_absent":not (V11/"static-run-v11/ATTEMPT_MARKER.json").exists(),"runtime_absent":not (V11/"static-run-v11/runtime-result-0001.json").exists(),"selftest_intact":sha(V11/"static-run-v11/observer-selftest-result-0001.json")=="4565dc9cc0717a210324f646069b3e6ce10b6e954273059331ff2aede755c4c9","v12_absent":not V12.exists()}
    if not all(checks.values()): raise SystemExit("final freeze verification failed")
    write("FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",{"record_type":"FINAL_FREEZE_VERIFICATION_RESULT","run_id":"RUN-0001","status":"PASS","checks_total":len(checks),"checks_passed":len(checks),"checks_failed":0,"checks":[{"check_id":k,"status":"PASS"} for k in checks]})
    excluded={"GOVERNANCE_ARTIFACT_MANIFEST.json","GOVERNANCE_LOCK.json"}; members=[]
    for p in sorted((x for x in ROOT.iterdir() if x.is_file() and x.name not in excluded),key=lambda x:x.name): members.append({"path":p.name,"sha256":sha(p),"bytes":p.stat().st_size})
    material="".join(f"{x['sha256']}  {x['path']}\n" for x in members); root=hashlib.sha256(material.encode()).hexdigest()
    write("GOVERNANCE_ARTIFACT_MANIFEST.json",{"record_type":"GOVERNANCE_ARTIFACT_MANIFEST","member_count":len(members),"members":members,"canonical_governance_root_sha256":root})
    write("GOVERNANCE_LOCK.json",{"record_type":"GOVERNANCE_LOCK","status":"PASS_LOCKED_GOVERNANCE_ONLY","decision":DECISION,"v11_disposition":"FAIL_CLOSED_PRE_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY","v12_state":"CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED","v12_attempt_count":0,"worker_or_codex_invocation_during_governance":0,"temporal_observer_runtime":"NOT_ESTABLISHED","process_lineage":"NOT_PROVEN","producer_authorization":"NOT_PROVEN","confinement":"NOT_PROVEN","governance_manifest_sha256":sha(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json"),"canonical_governance_root_sha256":root,"next_legal_milestone":"IMPLEMENT_STATICALLY_VALIDATE_AND_LOCK_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_NO_EXECUTION_UNTIL_ALL_GATES_PASS"})
    for p in ROOT.iterdir():
        if p.is_file(): os.chmod(p,0o444)
    os.chmod(ROOT,0o555)
if __name__=="__main__": main()
