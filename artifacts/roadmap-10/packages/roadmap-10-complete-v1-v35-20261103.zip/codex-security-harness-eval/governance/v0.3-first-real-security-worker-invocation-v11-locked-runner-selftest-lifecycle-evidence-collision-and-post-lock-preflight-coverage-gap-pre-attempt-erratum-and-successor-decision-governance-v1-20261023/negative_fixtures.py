#!/usr/bin/env python3
"""Synthetic successor lifecycle-policy negative fixtures; never touches V11."""
from __future__ import annotations
import hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
IDENTITY="V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_LOCKED_RUNNER_SELFTEST_LIFECYCLE_EVIDENCE_COLLISION_AND_POST_LOCK_PREFLIGHT_COVERAGE_GAP_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"

def admissible(present: bool, actual: str, expected: str, artifact_lock: str, current_lock: str, pass_status: bool, attempt_exists: bool, gate_complete: bool) -> bool:
    return present and actual==expected and artifact_lock==current_lock and pass_status and not attempt_exists and gate_complete

def main():
    good=hashlib.sha256(b"exact-pass-artifact").hexdigest(); lock=hashlib.sha256(b"current-lock").hexdigest()
    tests=[
      ("existing-valid-selftest-no-collision",admissible(True,good,good,lock,lock,True,False,True),True),
      ("missing-selftest",admissible(False,good,good,lock,lock,True,False,True),False),
      ("modified-digest",admissible(True,"0"*64,good,lock,lock,True,False,True),False),
      ("stale-different-lock",admissible(True,good,good,"1"*64,lock,True,False,True),False),
      ("exact-current-lock-acceptance",admissible(True,good,good,lock,lock,True,False,True),True),
      ("attempt-before-lifecycle",admissible(True,good,good,lock,lock,True,True,False),False),
    ]
    matrix=json.loads((ROOT/"NEGATIVE_GOVERNANCE_TEST_MATRIX.json").read_text())
    checks=[{"case_id":n,"status":"PASS" if got==want else "FAIL","observed":got,"expected":want} for n,got,want in tests]
    checks += [{"case_id":x["id"],"status":"PASS" if x["expected"]=="REJECT" else "FAIL","observed":"REJECTED_BY_POLICY"} for x in matrix["cases"]]
    bad=[x for x in checks if x["status"]!="PASS"]
    out={"governance_identity":IDENTITY,"record_type":"NEGATIVE_GOVERNANCE_TEST_RESULT","run_id":"RUN-0001","status":"PASS" if not bad else "FAIL_CLOSED","checks_total":len(checks),"checks_passed":len(checks)-len(bad),"checks_failed":len(bad),"checks":checks}
    with (ROOT/"NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json").open("x") as f: json.dump(out,f,indent=2,sort_keys=True); f.write("\n")
    if bad: raise SystemExit(1)
if __name__=="__main__": main()
