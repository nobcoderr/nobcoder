#!/usr/bin/env python3
"""Primary governance validation for the V11 self-test lifecycle erratum."""

from __future__ import annotations
import ast, hashlib, json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_LOCKED_RUNNER_SELFTEST_LIFECYCLE_EVIDENCE_COLLISION_AND_POST_LOCK_PREFLIGHT_COVERAGE_GAP_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DOCS = {"GOVERNANCE_CHARTER.json", "V11_EVIDENCE_BINDING.json", "V11_TERMINAL_DISPOSITION.json", "SELFTEST_LIFECYCLE_COLLISION_ADJUDICATION.json", "POST_LOCK_PREFLIGHT_COVERAGE_GAP_ADJUDICATION.json", "UNPROVEN_RUNTIME_STATE.json", "SUCCESSOR_V12_SELFTEST_LIFECYCLE_CONTRACT.json", "V11_FAILURE_AND_V12_REGRESSION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "SUCCESSOR_V12_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json", "NEXT_LEGAL_MILESTONE.json"}

def read(name: str) -> dict[str, Any]: return json.loads((ROOT/name).read_text())
def sha(p: Path) -> str: return hashlib.sha256(p.read_bytes()).hexdigest()
def main() -> None:
    checks=[]
    def ck(i,c,e=None): checks.append({"check_id":i,"status":"PASS" if c else "FAIL","evidence":e})
    ck("P001_DOC_SET", {p.name for p in ROOT.glob("*.json")} == DOCS)
    docs={n:read(n) for n in DOCS}; ck("P002_IDENTITY", all(x.get("governance_identity")==IDENTITY for x in docs.values()))
    for p in ROOT.glob("*.py"):
        try: ast.parse(p.read_text()); ok=True
        except SyntaxError: ok=False
        ck("P_SCRIPT_"+p.name,ok)
    b=docs["V11_EVIDENCE_BINDING.json"]; ck("P010_ROOT",b["canonical_workspace_root_sha256"]=="6b41bc493b1876468de57cb82cb3b7de9bf811450f9579ee5e493473d75023ef")
    ck("P011_LOCK_HASH",sha(V11/"STATIC_EXECUTION_LOCK.json")==b["key_artifact_sha256"]["STATIC_EXECUTION_LOCK.json"])
    ck("P012_RUNNER_HASH",sha(V11/"src/runner_v11.py")==b["key_artifact_sha256"]["src/runner_v11.py"])
    d=docs["V11_TERMINAL_DISPOSITION.json"]; ck("P020_TERMINAL",d["disposition"]=="FAIL_CLOSED_PRE_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    ck("P021_ZERO",d["attempt"]=="0_OF_1_NOT_CONSUMED" and d["worker_invocation"]==d["codex_as_worker_invocation"]=="0_OF_1")
    ck("P022_NO_MUTATION",all(d[k]=="PROHIBITED" for k in ["patch","relock","retry","revalidation","observer_selftest_evidence_mutation"]))
    a=docs["SELFTEST_LIFECYCLE_COLLISION_ADJUDICATION.json"]; ck("P030_DEFECT_YES",a["locked_runner_selftest_lifecycle_defect"]=="YES")
    ck("P031_OBSERVER_NO",a["temporal_observer_implementation_defect"]==a["observer_selftest_defect"]=="NO")
    ck("P032_COLLISION",a["facts"]["collision_is_deterministic"] and a["facts"]["existing_selftest_status"]=="PASS_7_OF_7")
    c=docs["POST_LOCK_PREFLIGHT_COVERAGE_GAP_ADJUDICATION.json"]; ck("P040_COVERAGE_YES",c["post_lock_preflight_coverage_gap"]=="YES")
    u=docs["UNPROVEN_RUNTIME_STATE.json"]; ck("P050_UNPROVEN",[u[k] for k in ["temporal_observer_runtime","process_lineage","producer_authorization","confinement"]]==["NOT_ESTABLISHED","NOT_PROVEN","NOT_PROVEN","NOT_PROVEN"])
    s=docs["SUCCESSOR_V12_SELFTEST_LIFECYCLE_CONTRACT.json"]; ck("P060_OWNER",s["lifecycle_owner"]=="REQUIRED_EXPLICIT_SINGLE_OWNER")
    ck("P061_STRATEGIES",set(s["authorized_strategies"])=={"CONSUME_LOCK_BOUND_IMMUTABLE_PASS_ARTIFACT","DISTINCT_APPEND_ONLY_PREFLIGHT_AND_RUNTIME_IDENTITIES"})
    ck("P062_PROHIBITIONS",{"DELETE_EXISTING_SELFTEST","OVERWRITE_EXISTING_SELFTEST","exist_ok=True","WEAKEN_WRITE_ONCE_PROVENANCE"}.issubset(s["prohibited_shortcuts"]))
    r=docs["V11_FAILURE_AND_V12_REGRESSION_MATRIX.json"]["cases"]; ck("P070_REGRESSIONS",[x["id"] for x in r]==[f"R{i:03d}" for i in range(1,8)])
    v=docs["SUCCESSOR_V12_AUTHORIZATION_DECISION.json"]; ck("P080_V12",v["state"]=="CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED" and not v["creation_or_execution_this_milestone"])
    au=docs["AUTHORITY_NON_ESCALATION_DECISION.json"]; ck("P090_OPS_ZERO",all(x==0 for x in au["operation_counters"].values()))
    ck("P091_NO_ATTEMPT",not (V11/"static-run-v11/ATTEMPT_MARKER.json").exists())
    ck("P092_NO_V12",not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023").exists())
    failures=[x for x in checks if x["status"]!="PASS"]
    out={"governance_identity":IDENTITY,"record_type":"PRIMARY_GOVERNANCE_VALIDATION_RESULT","run_id":"RUN-0001","status":"PASS" if not failures else "FAIL_CLOSED","checks_total":len(checks),"checks_passed":len(checks)-len(failures),"checks_failed":len(failures),"failure_ids":[x["check_id"] for x in failures],"checks":checks}
    with (ROOT/"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").open("x") as f: json.dump(out,f,indent=2,sort_keys=True); f.write("\n")
    if failures: raise SystemExit(1)
if __name__=="__main__": main()
