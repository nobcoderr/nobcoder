#!/usr/bin/env python3
"""Read-only verification of the frozen governance package."""
from __future__ import annotations
import hashlib,json,stat
from pathlib import Path
ROOT=Path(__file__).resolve().parent; V11=Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    lock=json.loads((ROOT/"GOVERNANCE_LOCK.json").read_text()); manifest=json.loads((ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json").read_text())
    failures=[]
    if lock["status"]!="PASS_LOCKED_GOVERNANCE_ONLY": failures.append("lock_status")
    if sha(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json")!=lock["governance_manifest_sha256"]: failures.append("manifest_digest")
    material=""
    for r in manifest["members"]:
        p=ROOT/r["path"]
        if not p.is_file() or sha(p)!=r["sha256"]: failures.append("member:"+r["path"])
        material+=f"{r['sha256']}  {r['path']}\n"
    if hashlib.sha256(material.encode()).hexdigest()!=manifest["canonical_governance_root_sha256"]: failures.append("root")
    if any(p.stat().st_mode & 0o222 for p in ROOT.iterdir() if p.is_file()): failures.append("writable_member")
    if (V11/"static-run-v11/ATTEMPT_MARKER.json").exists(): failures.append("attempt")
    if sha(V11/"src/runner_v11.py")!="696a52a3cbce95dd3bf3e91b2d299205cef7f076bd0bb305af34c0842440b43f": failures.append("runner_drift")
    print(json.dumps({"status":"PASS" if not failures else "FAIL_CLOSED","checks_failed":len(failures),"failure_ids":failures},sort_keys=True))
    if failures: raise SystemExit(1)
if __name__=="__main__": main()
