#!/usr/bin/env python3
"""Independent evidence and decision validation for the V11 erratum."""
from __future__ import annotations
import ast, hashlib, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent; V11=Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
IDENTITY="V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_LOCKED_RUNNER_SELFTEST_LIFECYCLE_EVIDENCE_COLLISION_AND_POST_LOCK_PREFLIGHT_COVERAGE_GAP_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
def read(n): return json.loads((ROOT/n).read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    c=[]
    def ck(i,x,e=None): c.append({"check_id":i,"status":"PASS" if x else "FAIL","evidence":e})
    p=read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"); n=read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    ck("I001_PRIMARY",p["status"]=="PASS" and p["checks_failed"]==0); ck("I002_NEGATIVE",n["status"]=="PASS" and n["checks_failed"]==0)
    lock=json.loads((V11/"STATIC_EXECUTION_LOCK.json").read_text()); verify=json.loads((V11/"STATIC_EXECUTION_LOCK_VERIFICATION.json").read_text()); st=json.loads((V11/"static-run-v11/observer-selftest-result-0001.json").read_text())
    ck("I010_LOCK",sha(V11/"STATIC_EXECUTION_LOCK.json")=="3da68aa2f89327b30bbbd35eaa354b3701a5d395c06a5e9dd6bb96a72ec31b96" and lock["status"]=="STATIC_LOCKED_NOT_EXECUTED")
    ck("I011_VERIFY",verify["status"]=="PASS" and verify["checks_passed"]==verify["checks_total"]==221)
    ck("I012_SELFTEST",st["status"]=="PASS" and len(st["checks"])==7 and all(st["checks"].values()))
    src=(V11/"src/runner_v11.py").read_text(); tree=ast.parse(src)
    calls=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=="mkdir":
            calls.append((node.lineno,{kw.arg:ast.literal_eval(kw.value) for kw in node.keywords if kw.arg and isinstance(kw.value,ast.Constant)}))
    ck("I020_EXIST_OK_FALSE",any(k.get("exist_ok") is False for _,k in calls),calls)
    a=src.index("observer_selftest = run_temporal_observer_selftest()"); b=src.index('STATIC_RUN / "pre-attempt-gates-run-0001.json"'); d=src.rindex('STATIC_RUN / "ATTEMPT_MARKER.json"')
    ck("I021_ORDER",a<b<d,(a,b,d)); ck("I022_DIRECTORY_EXISTS",(V11/"static-run-v11/observer-selftest-0001").is_dir())
    ck("I023_NO_ATTEMPT",not (V11/"static-run-v11/ATTEMPT_MARKER.json").exists() and not (V11/"static-run-v11/runtime-result-0001.json").exists())
    adj=read("SELFTEST_LIFECYCLE_COLLISION_ADJUDICATION.json"); cov=read("POST_LOCK_PREFLIGHT_COVERAGE_GAP_ADJUDICATION.json"); un=read("UNPROVEN_RUNTIME_STATE.json")
    ck("I030_DEFECT",adj["locked_runner_selftest_lifecycle_defect"]=="YES"); ck("I031_NO_OBSERVER_DEFECT",adj["temporal_observer_implementation_defect"]==adj["observer_selftest_defect"]=="NO")
    ck("I032_COVERAGE",cov["post_lock_preflight_coverage_gap"]=="YES"); ck("I033_UNPROVEN",un["temporal_observer_runtime"]=="NOT_ESTABLISHED" and un["confinement"]=="NOT_PROVEN")
    disp=read("V11_TERMINAL_DISPOSITION.json"); ck("I040_TERMINAL",disp["disposition"]=="FAIL_CLOSED_PRE_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    succ=read("SUCCESSOR_V12_AUTHORIZATION_DECISION.json"); ck("I041_SUCCESSOR",succ["state"]=="CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED" and succ["attempt_count"]==0)
    con=read("SUCCESSOR_V12_SELFTEST_LIFECYCLE_CONTRACT.json"); ck("I042_EXACT_OWNER",con["lifecycle_owner"]=="REQUIRED_EXPLICIT_SINGLE_OWNER" and con["attempt_marker_rule"].startswith("ABSENT"))
    auth=read("AUTHORITY_NON_ESCALATION_DECISION.json"); ck("I050_ZERO",all(v==0 for v in auth["operation_counters"].values()))
    bad=[x for x in c if x["status"]!="PASS"]; out={"governance_identity":IDENTITY,"record_type":"INDEPENDENT_GOVERNANCE_VALIDATION_RESULT","run_id":"RUN-0001","status":"PASS" if not bad else "FAIL_CLOSED","checks_total":len(c),"checks_passed":len(c)-len(bad),"checks_failed":len(bad),"failure_ids":[x["check_id"] for x in bad],"checks":c}
    with (ROOT/"INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").open("x") as f: json.dump(out,f,indent=2,sort_keys=True); f.write("\n")
    if bad: raise SystemExit(1)
if __name__=="__main__": main()
