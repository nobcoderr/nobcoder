#!/usr/bin/env python3
"""Deterministic governance tests for the V2 handoff path/PS5.1 addendum."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path, PurePosixPath, PureWindowsPath


ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
ERRATUM = BASE / "v0.2-i4-b-evidence-recovery-hash-binding-erratum-and-reauthorization-governance-v1-20261012"
CANDIDATE = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v2-handoff-v1-20261012")
IDENTITY = "V0.2_I4_B_V2_HANDOFF_SUCCESSOR_PATH_AND_PS51_VALIDATION_BINDING_GOVERNANCE_V1"
HANDOFF_ID = "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V2_HOST_HANDOFF_V1"
ERRATUM_LOCK = "4972f5bb4778d84159c01684c8659777fb285850eeacfc606ce6102184f592e5"
ERRATUM_ROOT = "92ae3aa2324508823c266ed9cf81d8cc0e51f073d781b2716104eacf76c3fc0a"
AUTH_SHA = "50c9bf4bf49cb5a777dce5021628bf3ea96536f549fd71dc68f35c86ed27c653"
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def governance_root(path: Path) -> str:
    ledger = bytearray()
    for member in sorted(path.iterdir(), key=lambda value: value.name):
        if member.is_file() and not member.is_symlink() and member.name != "GOVERNANCE_LOCK.json":
            ledger.extend(f"{sha(member)}  {member.name}\n".encode("utf-8"))
    return hashlib.sha256(ledger).hexdigest()


def valid_sha(value) -> bool:
    return isinstance(value, str) and HEX64.fullmatch(value) is not None


def path_guard(path: str, identity: str, exists: bool, symlink: bool, parent: str) -> bool:
    candidate = PurePosixPath(path)
    return (
        identity == HANDOFF_ID
        and candidate.is_absolute()
        and candidate.parent == PurePosixPath("/home/nobcoder")
        and candidate.name == "v0.2-i4-b-v3-partial-evidence-recovery-v2-handoff-v1-20261012"
        and parent == "/home/nobcoder"
        and not exists
        and not symlink
        and ".." not in candidate.parts
    )


def ps51_runtime(edition: str | None, version: str | None, interpreter_present: bool) -> bool:
    return interpreter_present and edition == "Desktop" and version == "5.1"


def parse_authorized(has_authority: bool, executes_candidate: bool, changes_policy: bool, calls_vbox: bool) -> bool:
    return has_authority and not executes_candidate and not changes_policy and not calls_vbox


def transfer_guard(source: str, destination: str, members: list[str], digest_matches: bool, destination_exists: bool) -> bool:
    allowed = [
        "Collect-V3PartialEvidenceRecoveryPackageV2.ps1",
        "HANDOFF_V2_PROVISIONAL_SOURCE_MANIFEST.json",
        "PS51_PARSE_VALIDATION_REQUEST.json",
    ]
    return (
        source == str(CANDIDATE)
        and destination == r"C:\Users\nitro 5\Downloads\v3-partial-evidence-recovery-v2-handoff-validation-v1-20261012"
        and members == allowed
        and digest_matches
        and not destination_exists
    )


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


protocol = load(ROOT / "GOVERNANCE_GATE_PROTOCOL.json")
preflight = load(ROOT / "PREFLIGHT_RESULT.json")
binding = load(ROOT / "HANDOFF_SUCCESSOR_PATH_BINDING.json")
environment = load(ROOT / "PS51_VALIDATION_ENVIRONMENT_REQUIREMENTS.json")
authorization = load(ROOT / "PS51_PARSE_ONLY_AUTHORIZATION.json")
sequence = load(ROOT / "PS51_VALIDATION_SEQUENCE.json")
transfer = load(ROOT / "SOURCE_TRANSFER_POLICY.json")
evidence = load(ROOT / "VALIDATION_EVIDENCE_CONTRACT.json")
matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
risks = load(ROOT / "RISK_REGISTER.json")
immutability = load(ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json")
decision = load(ROOT / "BINDING_DECISION.json")
erratum_lock = load(ERRATUM / "GOVERNANCE_LOCK.json")
erratum_auth = load(ERRATUM / "NEW_RECOVERY_AUTHORIZATION.json")

check("identity", protocol["gate_id"] == IDENTITY == decision["gate_id"])
check("scope_governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
check("scope_no_implementation", protocol["scope"]["handoff_implementation"] is False)
check("scope_no_windows_execution", protocol["scope"]["windows_validation_execution"] is False)
check("scope_no_recovery", protocol["scope"]["recovery_execution"] is False)
check("writes_before_preflight", protocol["writes_before_preflight_pass"] == 0)
check("preflight_count", preflight["checks_total"] == 30 and preflight["checks_passed"] == 30 and preflight["checks_failed"] == 0)
check("preflight_rows", len(preflight["checks"]) == 30 and all(row["result"] not in {"FAIL", "BLOCKED"} for row in preflight["checks"]))
check("predecessor_lock_bytes", sha(ERRATUM / "GOVERNANCE_LOCK.json") == ERRATUM_LOCK)
check("predecessor_root", governance_root(ERRATUM) == ERRATUM_ROOT == erratum_lock["artifact_root_sha256"])
check("predecessor_authorization_bytes", sha(ERRATUM / "NEW_RECOVERY_AUTHORIZATION.json") == AUTH_SHA)
check("v2_authorization_identity", erratum_auth["authorization_id"] == "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_AUTHORIZATION_V2")
check("v2_authorization_conditional", erratum_auth["status"] == "GRANTED_NOT_EXECUTABLE_PENDING_NEW_HANDOFF_DIGEST_LOCK")
check("handoff_identity", binding["handoff_identity"] == HANDOFF_ID == erratum_auth["required_handoff_identity"])
check("valid_successor_path", path_guard(binding["successor_path"], binding["handoff_identity"], False, False, binding["parent_realpath"]))
check("missing_successor_path_rejected", not path_guard("", HANDOFF_ID, False, False, "/home/nobcoder"))
check("conflicting_successor_identity_rejected", not path_guard(str(CANDIDATE), HANDOFF_ID + "_OTHER", False, False, "/home/nobcoder"))
check("existing_successor_rejected", not path_guard(str(CANDIDATE), HANDOFF_ID, True, False, "/home/nobcoder"))
check("symlink_successor_rejected", not path_guard(str(CANDIDATE), HANDOFF_ID, False, True, "/home/nobcoder"))
check("unauthorized_parent_rejected", not path_guard("/tmp/v0.2-i4-b-v3-partial-evidence-recovery-v2-handoff-v1-20261012", HANDOFF_ID, False, False, "/tmp"))
check("wrong_handoff_identity_rejected", not path_guard(str(CANDIDATE), "WRONG", False, False, "/home/nobcoder"))
check("candidate_absent_at_binding", not CANDIDATE.exists() and not CANDIDATE.is_symlink())
check("path_binding_status", binding["status"] == "AUTHORIZED_BOUND_NOT_CREATED")
check("path_cardinality", binding["binding_cardinality"] == "ONE_IDENTITY_TO_ONE_PATH")
check("path_separation", binding["separation"]["paths_are_distinct"] is True and len(set(binding["separation"].values())) == 3)
check("ps51_environment_status", environment["status"] == "BOUND_REQUIREMENTS_RUNTIME_NOT_YET_OBSERVED")
check("ps51_interpreter_path", PureWindowsPath(environment["candidate_interpreter_path"]) == PureWindowsPath(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"))
check("ps51_requirements", environment["required_runtime"] == {"product": "Windows PowerShell", "psedition": "Desktop", "major": 5, "minor": 1, "exact_major_minor_required": True})
check("linux_pwsh7_not_ps51", not ps51_runtime("Core", "7.6", True))
check("missing_ps51_evidence_rejected", not ps51_runtime(None, None, False))
check("valid_ps51_evidence_accepted", ps51_runtime("Desktop", "5.1", True))
check("ps51_runtime_not_claimed", environment["current_evidence"]["PS51_INTERPRETER_PRESENT"] == "NOT_EVALUATED")
check("parse_authorization_status", authorization["status"] == "GRANTED_NOT_EXECUTED_PENDING_CANDIDATE_DIGEST")
check("parse_authorization_single_use", authorization["single_use"]["retry"] == "FORBIDDEN_AFTER_CONSUMPTION")
check("missing_parse_authority_rejected", not parse_authorized(False, False, False, False))
check("parse_only_authority_accepted", parse_authorized(True, False, False, False))
check("handoff_execution_rejected", not parse_authorized(True, True, False, False))
check("execution_policy_change_rejected", not parse_authorized(True, False, True, False))
check("vboxmanage_rejected", not parse_authorized(True, False, False, True))
check("sequence_order", [row["order"] for row in sequence["sequence"]] == list(range(1, 14)))
check("parsefile_only", sequence["windows_parser_invocation_contract"]["parser_api"].endswith("Parser.ParseFile") and sequence["windows_parser_invocation_contract"]["candidate_invoked"] is False)
check("functional_claim_boundary", sequence["functional_test_policy"]["windows_powershell_5_1_functional_execution_test"] == "NOT_REQUIRED_BY_CURRENT_FROZEN_V2_AUTHORIZATION_AND_NOT_AUTHORIZED")
check("valid_transfer", transfer_guard(transfer["source_root"], transfer["windows_staging_root"], transfer["allowed_transfer_members"], True, False))
check("wrong_candidate_digest_rejected", not transfer_guard(transfer["source_root"], transfer["windows_staging_root"], transfer["allowed_transfer_members"], False, False))
check("mismatched_bytes_rejected", not transfer_guard(transfer["source_root"], transfer["windows_staging_root"], transfer["allowed_transfer_members"], False, False))
check("unauthorized_staging_rejected", not transfer_guard(transfer["source_root"], r"C:\Temp\other", transfer["allowed_transfer_members"], True, False))
check("existing_staging_rejected", not transfer_guard(transfer["source_root"], transfer["windows_staging_root"], transfer["allowed_transfer_members"], True, True))
check("extra_transfer_member_rejected", not transfer_guard(transfer["source_root"], transfer["windows_staging_root"], transfer["allowed_transfer_members"] + ["extra"], True, False))
check("return_path_exact", transfer["return_path"].endswith("/PS51_PARSE_VALIDATION_RESULT.json"))
check("missing_return_path_rejected", transfer["required_result_member"] == "PS51_PARSE_VALIDATION_RESULT.json" and bool(transfer["return_path"]))
check("no_mount_change", transfer["copy_rules"]["mount_changes"] is False and transfer["copy_rules"]["shared_folder_configuration_changes"] is False)
check("evidence_identity", evidence["required_fields"]["validation_identity"] == authorization["single_use_validation_identity"])
check("evidence_parser_only", evidence["required_fields"]["parser_only"] is True and evidence["required_fields"]["handoff_executed"] is False)
check("missing_independent_rejected", len(evidence["independent_validation"]) >= 6 and evidence["forgery_or_incompleteness"] == "BLOCK_NO_PASS_LOCK")
check("parser_not_functional", evidence["claim_statuses_after_valid_result"]["PS51_FUNCTIONAL_TEST_VALIDATED"].startswith("NOT_EVALUATED"))
decisions = {row["id"]: row["decision"] for row in matrix["operations"]}
check("operation_count", len(decisions) == matrix["operation_count"] == 17)
check("operation_ids_unique", len(decisions) == len(matrix["operations"]))
check("offline_implementation_authorized", decisions["H01"] == "AUTHORIZED_FUTURE_OFFLINE" and decisions["H02"] == "AUTHORIZED_FUTURE_OFFLINE")
check("transfer_conditionally_authorized", decisions["H04"] == "CONDITIONALLY_AUTHORIZED_FUTURE_SINGLE_USE")
check("parse_conditionally_authorized", decisions["H05"] == "CONDITIONALLY_AUTHORIZED_FUTURE_SINGLE_USE")
check("premature_lock_rejected", decisions["H08"] == "CONDITIONALLY_AUTHORIZED_ONLY_AFTER_ALL_MANDATORY_GATES_PASS")
check("v1_execution_denied", decisions["X01"] == "DENIED")
check("a1_a2_replay_denied", decisions["X03"] == "DENIED")
check("a3_a5_denied", decisions["X04"] == "DENIED")
check("vm_vdi_denied", decisions["X06"] == "DENIED")
check("windows_policy_denied", decisions["X08"] == "DENIED")
check("i5_v03_denied", decisions["X09"] == "DENIED")
check("host_operations_zero", matrix["currently_executed_host_operations"] == 0 and matrix["recovery_operations_authorized_by_this_addendum"] == 0)
check("risk_count", len(risks["risks"]) == risks["risk_count"] == 18)
check("risks_fail_closed", risks["all_fail_closed"] is True and all(row["failure"] in {"BLOCK", "BLOCK_INCIDENT", "TERMINAL_AFTER_CONSUMPTION", "NO_PASS_LOCK", "TERMINAL_NO_RETRY"} for row in risks["risks"]))
check("immutability", immutability["status"] == "PASS" and immutability["writes_to_historical_trees"] == 0)
check("windows_actions_zero", immutability["windows_host_actions"] == 0)
check("decision_status", decision["status"] == "PASS_LOCKED")
check("path_decision", decision["decisions"]["successor_path_binding"] == "AUTHORIZED_BOUND_NOT_CREATED")
check("parse_decision", decision["decisions"]["ps51_parse_only_validation"] == "AUTHORIZED_NOT_EXECUTED_PENDING_CANDIDATE_DIGEST")
check("transfer_decision", decision["decisions"]["candidate_transfer"] == "CONDITIONALLY_AUTHORIZED_NOT_EXECUTED")
check("implementation_eligible", decision["decisions"]["handoff_implementation"] == "ELIGIBLE_TO_RESUME_AFTER_THIS_LOCK_VERIFIES")
check("recovery_still_blocked", decision["decisions"]["evidence_recovery_v2"] == "NOT_EXECUTABLE_PENDING_FINAL_HANDOFF_DIGEST_LOCK")
check("original_export_lost", decision["original_export"] == "LOST_NOT_RECREATED")
check("old_recovery_terminal", decision["v1_recovery"] == "TERMINAL_FAILURE_NO_REPLAY")
check("next_event", decision["required_next_event"] == "IMPLEMENT_TEST_VALIDATE_AND_FREEZE_V3_PARTIAL_EVIDENCE_RECOVERY_HANDOFF_V2_OFFLINE")
check("no_automatic_execution", decision["automatic_execution"] is False and decision["automatic_follow_on"] is False)
check("valid_sha_positive", valid_sha(ERRATUM_LOCK) and valid_sha(ERRATUM_ROOT) and valid_sha(AUTH_SHA))
check("invalid_sha_63", not valid_sha("a" * 63))
check("invalid_sha_uppercase", not valid_sha("A" * 64))
check("invalid_sha_trailing_newline", not valid_sha("a" * 64 + "\n"))

failed = [row for row in checks if not row["pass"]]
result = {
    "validator": "v2_handoff_path_ps51_binding_governance_self_test_v1",
    "gate_id": IDENTITY,
    "status": "PASS" if not failed else "FAIL",
    "total": len(checks),
    "passed": len(checks) - len(failed),
    "failed": len(failed),
    "checks": checks,
}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(1 if failed else 0)
