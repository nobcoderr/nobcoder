#!/usr/bin/env python3
"""Verify the final manifest, lock, canonical root, and read-only freeze."""

import hashlib
import json
import stat
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


manifest = load(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
lock = load(ROOT / "GOVERNANCE_LOCK.json")
actual_members = sorted(path.name for path in ROOT.iterdir() if path.is_file() and path.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"})
listed_members = sorted(manifest["files"])
member_hashes_pass = actual_members == listed_members and all(sha(ROOT / name) == manifest["files"][name] for name in listed_members)
manifest_hash_pass = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock["artifact_manifest_sha256"]
ledger = bytearray()
for path in sorted(ROOT.iterdir(), key=lambda item: item.name):
    if path.is_file() and not path.is_symlink() and path.name != "GOVERNANCE_LOCK.json":
        ledger.extend(f"{sha(path)}  {path.name}\n".encode("utf-8"))
root_hash = hashlib.sha256(ledger).hexdigest()
root_pass = root_hash == lock["artifact_root_sha256"]
files_read_only = all(not (path.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)) for path in ROOT.iterdir() if path.is_file())
directory_read_only = not (ROOT.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH))
checks = {
    "manifest_coverage": actual_members == listed_members,
    "manifest_member_hashes": member_hashes_pass,
    "manifest_hash": manifest_hash_pass,
    "canonical_root": root_pass,
    "files_read_only": files_read_only,
    "directory_read_only": directory_read_only,
}
result = {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "canonical_root_sha256": root_hash, "file_count_excluding_lock": len(actual_members) + 1}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(0 if all(checks.values()) else 1)
