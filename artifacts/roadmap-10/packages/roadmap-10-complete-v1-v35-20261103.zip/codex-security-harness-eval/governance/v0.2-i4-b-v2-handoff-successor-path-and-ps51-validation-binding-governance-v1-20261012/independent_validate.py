#!/usr/bin/env python3
"""Independent validation for the V2 handoff path/PS5.1 addendum."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
PREV = BASE / "v0.2-i4-b-evidence-recovery-hash-binding-erratum-and-reauthorization-governance-v1-20261012"
CANDIDATE = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v2-handoff-v1-20261012")
IDENTITY = "V0.2_I4_B_V2_HANDOFF_SUCCESSOR_PATH_AND_PS51_VALIDATION_BINDING_GOVERNANCE_V1"
HANDOFF_ID = "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V2_HOST_HANDOFF_V1"
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def read_json(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def root_digest(path: Path) -> str:
    rows = []
    for item in sorted(path.iterdir(), key=lambda value: value.name):
        if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json":
            rows.append(f"{sha(item)}  {item.name}\n")
    return hashlib.sha256("".join(rows).encode("utf-8")).hexdigest()


def valid_digest(value) -> bool:
    return isinstance(value, str) and HEX64.fullmatch(value) is not None


def digest_fields(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key == "sha256" or key.endswith("_sha256"):
                yield child
            yield from digest_fields(child)
    elif isinstance(value, list):
        for child in value:
            yield from digest_fields(child)


checks: list[tuple[str, bool]] = []


def verify(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))


protocol = read_json("GOVERNANCE_GATE_PROTOCOL.json")
preflight = read_json("PREFLIGHT_RESULT.json")
binding = read_json("HANDOFF_SUCCESSOR_PATH_BINDING.json")
environment = read_json("PS51_VALIDATION_ENVIRONMENT_REQUIREMENTS.json")
authorization = read_json("PS51_PARSE_ONLY_AUTHORIZATION.json")
sequence = read_json("PS51_VALIDATION_SEQUENCE.json")
transfer = read_json("SOURCE_TRANSFER_POLICY.json")
evidence = read_json("VALIDATION_EVIDENCE_CONTRACT.json")
matrix = read_json("OPERATION_AUTHORIZATION_MATRIX.json")
risks = read_json("RISK_REGISTER.json")
immutability = read_json("HISTORICAL_IMMUTABILITY_RESULT.json")
decision = read_json("BINDING_DECISION.json")
previous_lock = json.loads((PREV / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8-sig"))
previous_auth = json.loads((PREV / "NEW_RECOVERY_AUTHORIZATION.json").read_text(encoding="utf-8-sig"))

verify("identity", protocol["gate_id"] == IDENTITY == decision["gate_id"])
verify("governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
verify("preflight_actual_count", preflight["checks_total"] == len(preflight["checks"]) == 30 and preflight["checks_failed"] == 0)
verify("previous_lock_bytes", sha(PREV / "GOVERNANCE_LOCK.json") == "4972f5bb4778d84159c01684c8659777fb285850eeacfc606ce6102184f592e5")
verify("previous_manifest_bytes", sha(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "dabc460706893850513247ecb152536b3d4822e77506faccbe04e53d8b14356e")
verify("previous_root", root_digest(PREV) == previous_lock["artifact_root_sha256"] == "92ae3aa2324508823c266ed9cf81d8cc0e51f073d781b2716104eacf76c3fc0a")
verify("previous_authorization_bytes", sha(PREV / "NEW_RECOVERY_AUTHORIZATION.json") == "50c9bf4bf49cb5a777dce5021628bf3ea96536f549fd71dc68f35c86ed27c653")
verify("previous_authorization_state", previous_auth["status"] == "GRANTED_NOT_EXECUTABLE_PENDING_NEW_HANDOFF_DIGEST_LOCK")
verify("previous_handoff_identity", previous_auth["required_handoff_identity"] == HANDOFF_ID)
verify("successor_exact", binding["successor_path"] == str(CANDIDATE))
verify("successor_parent", binding["parent_realpath"] == "/home/nobcoder")
verify("successor_absent", not CANDIDATE.exists() and not CANDIDATE.is_symlink())
verify("successor_no_alias", ".." not in Path(binding["successor_path"]).parts and Path(binding["successor_path"]).is_absolute())
verify("successor_one_to_one", binding["binding_cardinality"] == "ONE_IDENTITY_TO_ONE_PATH")
verify("separate_linux_paths", binding["successor_path"] != binding["separation"]["a3_a5_runner_successor"])
verify("separate_windows_destination", "handoff-validation" not in binding["separation"]["windows_recovery_package_destination"])
verify("runtime_requirement", environment["required_runtime"]["psedition"] == "Desktop" and environment["required_runtime"]["major"] == 5 and environment["required_runtime"]["minor"] == 1)
verify("runtime_unobserved", environment["current_evidence"]["PS51_INTERPRETER_PRESENT"] == "NOT_EVALUATED")
verify("pwsh7_rejected", environment["disallowed_substitute"]["observed_edition"] == "Core" and environment["disallowed_substitute"]["observed_version"] == "7.6.2")
verify("parser_api", environment["parser_api"] == "System.Management.Automation.Language.Parser.ParseFile")
verify("parse_auth_distinct", authorization["authorization_id"] != previous_auth["authorization_id"])
verify("parse_auth_not_executed", authorization["status"] == "GRANTED_NOT_EXECUTED_PENDING_CANDIDATE_DIGEST")
verify("non_elevated", authorization["actor"].endswith("NON_ELEVATED") and environment["elevation_allowed"] is False)
verify("no_policy_change", authorization["execution_constraints"]["execution_policy_change_allowed"] is False)
verify("no_candidate_execution", authorization["execution_constraints"]["candidate_may_be_executed"] is False and authorization["execution_constraints"]["candidate_may_be_dot_sourced"] is False)
verify("no_invoke_expression", authorization["execution_constraints"]["invoke_expression_allowed"] is False)
verify("no_vbox", authorization["execution_constraints"]["vboxmanage_allowed"] is False)
verify("no_recovery_output", authorization["execution_constraints"]["recovery_output_creation_allowed"] is False)
verify("single_use_consumption", authorization["single_use"]["consumption_point"].startswith("CREATION_OF_THE_EXACT_WINDOWS_VALIDATION_STAGING_DIRECTORY"))
verify("single_use_terminal", authorization["single_use"]["retry"] == "FORBIDDEN_AFTER_CONSUMPTION" and authorization["single_use"]["overwrite"] == "FORBIDDEN")
verify("sequence_complete", len(sequence["sequence"]) == 13 and [row["order"] for row in sequence["sequence"]] == list(range(1, 14)))
verify("candidate_not_file_arg", sequence["windows_parser_invocation_contract"]["candidate_passed_to_file_parameter"] is False)
verify("candidate_not_invoked", sequence["windows_parser_invocation_contract"]["candidate_invoked"] is False)
verify("functional_ps51_not_substituted", sequence["functional_test_policy"]["windows_powershell_5_1_functional_execution_test"].startswith("NOT_REQUIRED"))
verify("source_exact", transfer["source_root"] == str(CANDIDATE))
verify("staging_exact", transfer["windows_staging_root"] == r"C:\Users\nitro 5\Downloads\v3-partial-evidence-recovery-v2-handoff-validation-v1-20261012")
verify("kali_view_exact", transfer["kali_staging_view"] == "/media/sf_Downloads/v3-partial-evidence-recovery-v2-handoff-validation-v1-20261012")
verify("transfer_allowlist", transfer["allowed_transfer_members"] == ["Collect-V3PartialEvidenceRecoveryPackageV2.ps1", "HANDOFF_V2_PROVISIONAL_SOURCE_MANIFEST.json", "PS51_PARSE_VALIDATION_REQUEST.json"])
verify("transfer_no_overwrite", transfer["copy_rules"]["overwrite"] is False and transfer["copy_rules"]["extra_members"] is False)
verify("transport_no_network", transfer["copy_rules"]["network_transport"] is False)
verify("transport_no_mount_change", transfer["copy_rules"]["mount_changes"] is False)
verify("return_exact", transfer["return_path"].startswith(transfer["kali_staging_view"]) and transfer["return_path"].endswith(transfer["required_result_member"]))
verify("result_identity", evidence["required_fields"]["validation_identity"] == authorization["single_use_validation_identity"])
verify("result_candidate_path", evidence["required_fields"]["candidate_path"].startswith(transfer["windows_staging_root"]))
verify("result_ps51", evidence["required_fields"]["powershell_edition"] == "Desktop" and evidence["required_fields"]["powershell_version_major_minor"] == "5.1")
verify("result_zero_parse_errors", evidence["required_fields"]["parse_error_count"] == 0)
verify("result_zero_execution", evidence["required_fields"]["handoff_executed"] is False and evidence["required_fields"]["recovery_operations"] == 0)
verify("result_zero_host_mutation", evidence["required_fields"]["vboxmanage_invocations"] == 0 and evidence["required_fields"]["vm_vdi_operations"] == 0 and evidence["required_fields"]["execution_policy_changes"] == 0)
verify("result_independent_requirements", len(evidence["independent_validation"]) == 6)
verify("result_claim_boundary", evidence["claim_statuses_after_valid_result"]["RECOVERY_HANDOFF_EXECUTABLE"].startswith("STILL_REQUIRES"))
operations = {row["id"]: row for row in matrix["operations"]}
verify("matrix_unique", len(operations) == len(matrix["operations"]) == 17)
verify("implementation_future", operations["H01"]["decision"] == "AUTHORIZED_FUTURE_OFFLINE")
verify("parse_future", operations["H05"]["decision"] == "CONDITIONALLY_AUTHORIZED_FUTURE_SINGLE_USE")
verify("final_lock_conditional", operations["H08"]["decision"].startswith("CONDITIONALLY_AUTHORIZED_ONLY_AFTER"))
verify("handoff_execution_denied", operations["X01"]["decision"] == "DENIED")
verify("recovery_denied", operations["X02"]["decision"] == "DENIED")
verify("a1_a2_denied", operations["X03"]["decision"] == "DENIED")
verify("a3_a5_denied", operations["X04"]["decision"] == "DENIED")
verify("vm_denied", operations["X06"]["decision"] == "DENIED")
verify("later_milestones_denied", operations["X09"]["decision"] == "DENIED")
verify("risk_coverage", risks["risk_count"] == len(risks["risks"]) == 18)
verify("risk_fail_closed", risks["all_fail_closed"] is True)
verify("immutability", immutability["status"] == "PASS" and immutability["writes_to_historical_trees"] == 0)
verify("old_handoff_terminal", decision["v1_recovery"] == "TERMINAL_FAILURE_NO_REPLAY")
verify("lost_export_preserved", decision["original_export"] == "LOST_NOT_RECREATED")
verify("path_granted", decision["decisions"]["successor_path_binding"] == "AUTHORIZED_BOUND_NOT_CREATED")
verify("parse_granted", decision["decisions"]["ps51_parse_only_validation"].startswith("AUTHORIZED_NOT_EXECUTED"))
verify("implementation_eligible", decision["decisions"]["handoff_implementation"].startswith("ELIGIBLE_TO_RESUME"))
verify("recovery_not_executable", decision["decisions"]["evidence_recovery_v2"].startswith("NOT_EXECUTABLE"))
verify("no_auto_execution", decision["automatic_execution"] is False and decision["automatic_follow_on"] is False)
for filename in (
    "GOVERNANCE_GATE_PROTOCOL.json", "PREFLIGHT_RESULT.json", "HANDOFF_SUCCESSOR_PATH_BINDING.json",
    "PS51_VALIDATION_ENVIRONMENT_REQUIREMENTS.json", "PS51_PARSE_ONLY_AUTHORIZATION.json",
    "PS51_VALIDATION_SEQUENCE.json", "SOURCE_TRANSFER_POLICY.json", "VALIDATION_EVIDENCE_CONTRACT.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "RISK_REGISTER.json", "HISTORICAL_IMMUTABILITY_RESULT.json",
    "BINDING_DECISION.json",
):
    verify(f"digest_fields_{filename}", all(valid_digest(value) for value in digest_fields(read_json(filename))))

failed = [name for name, passed in checks if not passed]
result = {
    "validator": "independent_v2_handoff_path_ps51_binding_validator_v1",
    "gate_id": IDENTITY,
    "status": "PASS" if not failed else "FAIL",
    "total": len(checks),
    "passed": len(checks) - len(failed),
    "failed": len(failed),
    "checks": [{"check": name, "pass": passed} for name, passed in checks],
}
print(json.dumps(result, indent=2, sort_keys=True))
raise SystemExit(1 if failed else 0)
