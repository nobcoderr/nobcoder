#!/usr/bin/env python3
"""Independent governance verifier using direct evidence, not self-test output."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re


ROOT = pathlib.Path(__file__).resolve().parent
PRODUCT = pathlib.Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2")
VALIDATOR = PRODUCT / "validator-v2"
RUNTIME = PRODUCT / "static-run-v2/output/artifacts/runtime"
TRACE = PRODUCT / "static-run-v2/output/artifacts/traces/static-v2.strace.4"


def digest(target: pathlib.Path) -> str:
    value = hashlib.sha256()
    with target.open("rb") as stream:
        while chunk := stream.read(131072):
            value.update(chunk)
    return value.hexdigest()


def read_json(target: pathlib.Path):
    return json.loads(target.read_bytes())


def save_once(target: pathlib.Path, value) -> None:
    if os.path.lexists(target):
        raise RuntimeError(f"collision: {target.name}")
    target.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


terminal = read_json(ROOT / "STATIC_VALIDATION_V2_TERMINAL_DISPOSITION.json")
cause = read_json(ROOT / "EXECUTION_LOADER_ROOT_CAUSE_REVIEW.json")
partial = read_json(ROOT / "PARTIAL_RUNTIME_EVIDENCE_INVENTORY.json")
decision = read_json(ROOT / "SUCCESSOR_DECISION.json")
binding = read_json(ROOT / "STATIC_VALIDATION_V3_IDENTITY_BINDING.json")
contract = read_json(ROOT / "STATIC_VALIDATION_V3_AUTHORIZATION_CONTRACT.json")
matrix = read_json(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
manifest = read_json(VALIDATOR / "locks/STATIC_SOURCE_MANIFEST_V2.json")
attempt = read_json(RUNTIME / "STATIC_V2_ONE_SHOT_ATTEMPT_STARTED.json")
controller = read_json(RUNTIME / "STATIC_V2_CONTROLLER_TERMINAL_RESULT.json")
raw = read_json(RUNTIME / "STATIC_V2_RAW_CAPTURE_RESULT.json")
trace_text = TRACE.read_text(encoding="utf-8", errors="replace")
entry_source = (VALIDATOR / "static_run_entry_v2.py").read_text(encoding="utf-8")
model_source = (PRODUCT / "tooling/mountinfo_model.py").read_text(encoding="utf-8")

observations = []


def assert_fact(label: str, value) -> None:
    observations.append({"id": f"I{len(observations) + 1:03d}", "name": label, "pass": bool(value)})


assert_fact("manifest has forty unique members", manifest["member_count"] == 40 and len(manifest["members"]) == 40 and len({item["path"] for item in manifest["members"]}) == 40)
for item in manifest["members"]:
    source = PRODUCT / item["path"]
    assert_fact(f"locked member {item['path']}", source.is_file() and not source.is_symlink() and source.stat().st_size == item["bytes"] and digest(source) == item["sha256"])
rows = b"".join(f"{item['sha256']}  {item['path']}\n".encode() for item in sorted(manifest["members"], key=lambda row: row["path"]))
assert_fact("static root independently recomputed", hashlib.sha256(rows).hexdigest() == manifest["canonical_source_root_sha256"] == "a8c92e90479a63c0aba197da5c8c15d9d25217772a17df8bffd1171419faa2cd")
assert_fact("attempt consumed once", attempt["execution_count"] == 1 and attempt["status"] == "ATTEMPT_STARTED_SINGLE_USE_CONSUMED")
assert_fact("attempt cannot retry", attempt["retry_authorized"] is False and controller["retry_authorized"] is False)
assert_fact("controller observed exit one", controller["child_exit_code"] == 1)
assert_fact("controller recorded prohibited counters zero", all(controller[name] == 0 for name in ("dotnet_invocations", "nuget_invocations", "p3_invocations")))
assert_fact("raw digest independently verified", digest(RUNTIME / "STATIC_V2_RAW_MOUNTINFO.bin") == raw["raw_mountinfo_sha256"] == "16f6aa08ac6c2ba1b3174f21e6114da26d03e15c4520c673bcfd6680e9fab981")
assert_fact("trace digest independently verified", digest(TRACE) == "e166f6d3c2fbca65adde2d87339d56cd5791f909345195a3b56a1f3c14cd2289")
exec_events = [line for line in trace_text.splitlines() if re.match(r"^execve(at)?\(", line)]
assert_fact("one executable event", len(exec_events) == 1)
assert_fact("only Python executable", len(exec_events) == 1 and 'execve("/usr/bin/python3.14"' in exec_events[0] and exec_events[0].rstrip().endswith("= 0"))
assert_fact("loader constructs module", "module_from_spec(spec)" in entry_source)
assert_fact("loader executes module", "spec.loader.exec_module(module)" in entry_source)
assert_fact("loader has no registration", "sys.modules[" not in entry_source)
assert_fact("loaded module contains dataclass", "@dataclass(frozen=True)" in model_source)
assert_fact("trace enters dataclasses", "/usr/lib/python3.14/dataclasses.py" in trace_text)
assert_fact("trace exits one", "exit_group(1)" in trace_text)
for absent in ("STATIC_V2_RUNTIME_CONFINEMENT_RESULT.json", "STATIC_V2_WRITE_PROBE_RESULT.json", "STATIC_V2_TEST_SEQUENCE_RESULT.json", "STATIC_V2_CHILD_TERMINAL_RESULT.json"):
    assert_fact(f"missing mandatory artifact {absent}", not (RUNTIME / absent).exists())
assert_fact("terminal classification exact", terminal["classification"] == {"EXECUTION_LOADER_DEFECT": True, "POST_VALIDATION_COMPLETE": False, "PRODUCT_DEFECT": False, "SEMANTIC_ARGV_VALIDATOR_DEFECT": False, "STATIC_LOCK_DEFECT": False})
assert_fact("root cause scoped to loader", cause["status"] == "ROOT_CAUSE_CONFIRMED_EXECUTION_LOADER_DEFECT" and "not in Product V2" in cause["scope"])
assert_fact("partial evidence cannot prove confinement", partial["confinement_pass"] == "NOT_PROVEN")
assert_fact("decision authorizes a distinct successor", decision["decision"] == "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY" and decision["new_validation_successor_required"] is True)
assert_fact("old validator terminal", decision["old_validator_v2"] == "TERMINAL_IMMUTABLE_REFERENCE_ONLY")
assert_fact("V3 path absent", not os.path.lexists(binding["validator_source_path"]) and not os.path.lexists(binding["static_run_path"]))
assert_fact("V3 execution conditional", binding["execution_eligibility"].startswith("CONDITIONAL_NOT_EXECUTABLE"))
assert_fact("V3 maximum one attempt", binding["maximum_attempts"] == 1 and binding["attempt_count"] == 0 and binding["retry_authorized"] is False)
assert_fact("fresh digest lock required", contract["exact_argv_digest"].startswith("TO_BE_COMPUTED") and contract["source_digest"].startswith("TO_BE_COMPUTED"))
assert_fact("P3 prohibited", matrix["operations"]["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
assert_fact("P6 prohibited", matrix["operations"]["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
assert_fact("Recovery prohibited", matrix["operations"]["Recovery_V3"] == "NOT_AUTHORIZED")
assert_fact("V0.3 prohibited", matrix["operations"]["V0_3"] == "BLOCKED_G0_NOT_MET_NO_ARTIFACT_CREATION")

result = {
    "schema_version": 1,
    "status": "PASS" if all(item["pass"] for item in observations) else "FAIL_CLOSED",
    "checks_total": len(observations),
    "checks_passed": sum(item["pass"] for item in observations),
    "failed_ids": [item["id"] for item in observations if not item["pass"]],
    "checks": observations,
    "independence": "Directly rehashed locked members and runtime evidence and rederived loader ordering without using GOVERNANCE_TEST_RESULT.json.",
}
save_once(ROOT / "INDEPENDENT_VALIDATION_RESULT.json", result)
print(json.dumps({"status": result["status"], "checks": f"{result['checks_passed']}/{result['checks_total']}"}, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
