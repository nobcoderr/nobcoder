#!/usr/bin/env python3
"""Deterministic governance self-tests; no product or sandbox execution."""

from __future__ import annotations

import json
import os
import pathlib


ROOT = pathlib.Path(__file__).resolve().parent


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write_new(name: str, value) -> None:
    target = ROOT / name
    if os.path.lexists(target):
        raise RuntimeError(f"refusing to overwrite {name}")
    target.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


terminal = load("STATIC_VALIDATION_V2_TERMINAL_DISPOSITION.json")
root_cause = load("EXECUTION_LOADER_ROOT_CAUSE_REVIEW.json")
partial = load("PARTIAL_RUNTIME_EVIDENCE_INVENTORY.json")
completeness = load("POST_VALIDATION_COMPLETENESS_DECISION.json")
immutable = load("LOCKED_SOURCE_IMMUTABILITY_RESULT.json")
decision = load("SUCCESSOR_DECISION.json")
binding = load("STATIC_VALIDATION_V3_IDENTITY_BINDING.json")
regression = load("LOADER_REGRESSION_REQUIREMENTS.json")
contract = load("STATIC_VALIDATION_V3_AUTHORIZATION_CONTRACT.json")
matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
next_step = load("NEXT_LEGAL_MILESTONE.json")

checks = []


def add(name: str, condition) -> None:
    checks.append({"id": f"S{len(checks) + 1:03d}", "name": name, "pass": bool(condition)})


add("V2 terminal status", terminal["status"] == "FAIL_CLOSED_TERMINAL_NO_RETRY")
add("V2 attempt consumed", terminal["attempt_count"] == 1 and terminal["attempt_state"] == "CONSUMED")
add("V2 retry denied", terminal["retry_authorized"] is False)
add("V2 patch denied", terminal["patch_in_place"] == "PROHIBITED")
add("V2 relock denied", terminal["relock_same_identity"] == "PROHIBITED")
add("product defect false", terminal["classification"]["PRODUCT_DEFECT"] is False)
add("semantic argv defect false", terminal["classification"]["SEMANTIC_ARGV_VALIDATOR_DEFECT"] is False)
add("static lock defect false", terminal["classification"]["STATIC_LOCK_DEFECT"] is False)
add("execution loader defect true", terminal["classification"]["EXECUTION_LOADER_DEFECT"] is True)
add("post validation incomplete", terminal["classification"]["POST_VALIDATION_COMPLETE"] is False)
add("loader cause confirmed", root_cause["status"] == "ROOT_CAUSE_CONFIRMED_EXECUTION_LOADER_DEFECT")
add("loader missing registration", root_cause["source_facts"]["sys_modules_registration_before_exec"] is False)
add("dataclass path present", root_cause["source_facts"]["dataclass_present"] is True)
add("exact exception evidence limited", root_cause["exact_exception_text"].startswith("NOT_PERSISTED"))
add("raw evidence partial only", partial["status"] == "PARTIAL_HISTORICAL_EVIDENCE_ADMISSIBLE_WITH_LIMITS")
add("raw mount captured", partial["captured"]["raw_mountinfo"] is True)
add("trace captured", partial["captured"]["strace"] is True)
add("only Python exec observed", partial["captured"]["successful_execve_observed"] == ["/usr/bin/python3.14"])
add("confinement not proven", partial["confinement_pass"] == "NOT_PROVEN")
add("topology incomplete", completeness["topology_evaluation"] == "NOT_COMPLETED")
add("write probes not executed", completeness["negative_write_probes"] == "NOT_EXECUTED")
add("tests not executed", completeness["confined_static_tests"] == "NOT_EXECUTED")
add("independent post validation incomplete", completeness["independent_post_validation"] == "NOT_COMPLETED")
add("locked 40 of 40", immutable["locked_members_total"] == immutable["locked_members_matching"] == 40)
add("no Product V2 mutation", immutable["product_v2_mutation"] is False)
add("immutability grants no acceptance", immutable["acceptance_implication"].startswith("NONE"))
add("decision B", decision["decision"] == "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY")
add("old validator reference only", decision["old_validator_v2"] == "TERMINAL_IMMUTABLE_REFERENCE_ONLY")
add("fresh validator identity", binding["validator_identity"].endswith("CONFINED_STATIC_VALIDATOR_V3"))
add("fresh validation identity", binding["validation_identity"].endswith("CONFINED_STATIC_VALIDATION_V3"))
add("fresh operation identity", binding["operation_identity"].endswith("CONFINED_STATIC_VALIDATION_V3"))
add("fresh paths distinct", binding["validator_source_path"] != binding["static_run_path"] and "validator-v3" in binding["validator_source_path"] and "static-run-v3" in binding["static_run_path"])
add("fresh attempt zero", binding["attempt_count"] == 0)
add("fresh maximum one", binding["maximum_attempts"] == 1)
add("fresh retry denied", binding["retry_authorized"] is False)
add("eight loader regressions", len(regression["required_cases"]) == 8)
add("legacy failure fixture required", regression["required_cases"][0]["expected"] == "DETERMINISTIC_FAILURE_REPRODUCED_IN_INERT_FIXTURE")
add("module collision fails closed", regression["required_cases"][2]["expected"] == "FAIL_CLOSED_NO_OVERWRITE")
add("independent implementation required", "different implementation paths" in regression["independence"])
add("V3 authorization conditional", contract["status"] == "CONDITIONAL_SINGLE_USE_ENGINEERING_AUTHORIZATION")
add("fresh lock required", any("fresh static lock" in item for item in contract["mandatory_pre_execution_gates"]))
add("V3 one-shot terminal", contract["attempt_semantics"].startswith("ONE_ATTEMPT"))
add("V2 retry prohibited by contract", "retry Static Validation V2" in contract["prohibitions"])
add("P3 remains blocked", matrix["operations"]["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
add("P6 remains blocked", matrix["operations"]["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
add("V0.3 remains blocked", matrix["operations"]["V0_3"] == "BLOCKED_G0_NOT_MET_NO_ARTIFACT_CREATION")
add("V0.2 remains governance only", next_step["V0_2"] == "PASS_LOCKED_GOVERNANCE_ONLY")
add("G0 not met", next_step["G0"] == "NOT_MET")

negative_cases = [
    ("retry V2", terminal["retry_authorized"] is False),
    ("patch V2 in place", terminal["patch_in_place"] == "PROHIBITED"),
    ("relock V2", terminal["relock_same_identity"] == "PROHIBITED"),
    ("promote raw capture to confinement PASS", partial["confinement_pass"] == "NOT_PROVEN"),
    ("claim post-validation complete", completeness["status"] == "INCOMPLETE_FAIL_CLOSED"),
    ("treat 40/40 immutability as acceptance", immutable["acceptance_implication"].startswith("NONE")),
    ("reuse V2 identity", binding["validation_identity"] != terminal["validation_identity"]),
    ("reuse V2 operation", binding["operation_identity"] != terminal["operation_identity"]),
    ("reuse V2 validator path", "validator-v3" in binding["validator_source_path"]),
    ("execute before regression tests", "all loader regression tests pass" in contract["mandatory_pre_execution_gates"]),
    ("execute before static lock", any("fresh static lock" in item for item in contract["mandatory_pre_execution_gates"])),
    ("second V3 attempt", binding["maximum_attempts"] == 1 and binding["retry_authorized"] is False),
    ("overwrite module-name collision", regression["required_cases"][2]["expected"] == "FAIL_CLOSED_NO_OVERWRITE"),
    ("leave failed module registered", "RESTORED_OR_FRESH_ENTRY_REMOVED" in regression["required_cases"][3]["expected"]),
    ("mutate Product V2 core", decision["product_v2_core_reuse"] == "AUTHORIZED_READ_ONLY_UNCHANGED_INPUT"),
    ("start P3", matrix["operations"]["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE"),
    ("issue P6", matrix["operations"]["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED"),
    ("start recovery", matrix["operations"]["Recovery_V3"] == "NOT_AUTHORIZED"),
    ("publish V0.3", matrix["operations"]["V0_3"] == "BLOCKED_G0_NOT_MET_NO_ARTIFACT_CREATION"),
    ("rewrite historical V2 result", terminal["promotion"] == "PROHIBITED"),
]

self_result = {
    "schema_version": 1,
    "status": "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED",
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "failed_ids": [item["id"] for item in checks if not item["pass"]],
    "checks": checks,
}
negative_result = {
    "schema_version": 1,
    "status": "PASS" if all(passed for _, passed in negative_cases) else "FAIL_CLOSED",
    "tests_total": len(negative_cases),
    "tests_passed": sum(passed for _, passed in negative_cases),
    "tests": [{"id": f"N{index:03d}", "case": name, "pass": bool(passed)} for index, (name, passed) in enumerate(negative_cases, 1)],
}
write_new("GOVERNANCE_TEST_RESULT.json", self_result)
write_new("NEGATIVE_GOVERNANCE_TEST_RESULT.json", negative_result)
print(json.dumps({"self_tests": f"{self_result['checks_passed']}/{self_result['checks_total']}", "negative_tests": f"{negative_result['tests_passed']}/{negative_result['tests_total']}", "status": "PASS" if self_result["status"] == negative_result["status"] == "PASS" else "FAIL_CLOSED"}, indent=2))
if self_result["status"] != "PASS" or negative_result["status"] != "PASS":
    raise SystemExit(1)
