#!/usr/bin/env python3
"""Build governance-only adjudication records for Static Validation V2."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
from datetime import datetime, timezone


ROOT = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path("/home/nobcoder")
PRODUCT = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2"
PREV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v2-validator-v2-preflight-out-of-scope-tmp-write-and-cleanup-erratum-and-continuation-decision-governance-v1-20261015"
VALIDATOR_V2 = PRODUCT / "validator-v2"
RUN_V2 = PRODUCT / "static-run-v2"
RUNTIME = RUN_V2 / "output/artifacts/runtime"
TRACE = RUN_V2 / "output/artifacts/traces/static-v2.strace.4"
VALIDATOR_V3 = PRODUCT / "validator-v3"
RUN_V3 = PRODUCT / "static-run-v3"

IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATION_V2_IMPORT_LOADER_AND_POST_VALIDATION_INCOMPLETE_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
SUCCESSOR_AUTHORIZATION = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATION_V3_SUCCESSOR_AUTHORIZATION_V1"
VALIDATOR_V3_IDENTITY = "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATOR_V3"
VALIDATION_V3_IDENTITY = "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V3"
VALIDATION_V3_OPERATION = "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V3"
NEXT_MILESTONE = "IMPLEMENT_AND_STATICALLY_LOCK_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATOR_V3_THEN_EXECUTE_CONFINED_STATIC_VALIDATION_V3_ONCE_IF_ALL_GATES_PASS"

PREV_LOCK_SHA = "af991a4b6362ea4c04dbe7a063baa96495e5a854c4ade1a90896c4ce3588c55c"
PREV_MANIFEST_SHA = "4eadc9ff057cc27ff8919bd64e98e02ebca2328affeef71b66476c15749e7cf2"
PREV_ROOT_SHA = "cc3114ce8c7d776ce5f9a9199b822b9dd86b32e21f5cba01f985e525a5133437"
STATIC_LOCK_SHA = "36a24159313feb7bc9cfb9f1528ac65b88fc7b7790c8bd86de2ed253e003647c"
STATIC_MANIFEST_SHA = "61fd682e644cfbb7f772b4175ecf53a0f471f41e9c2c9861041328941406db0a"
STATIC_VERIFICATION_SHA = "ede3a1d955228f90eb769d2984c5dcdc968da79fa97345880b3076a1f537e24f"
STATIC_ROOT_SHA = "a8c92e90479a63c0aba197da5c8c15d9d25217772a17df8bffd1171419faa2cd"

EVIDENCE_HASHES = {
    "STATIC_V2_CHILD_NAMESPACE_FACTS.json": "5ee2d2e30a06a83499a5d010a4d8179f737e3eff2530f95487ad4e315c6b43ef",
    "STATIC_V2_CONTROLLER_TERMINAL_RESULT.json": "81e3e5811df4afe8618e8e13fa358ff7b16fd06bb85829d78f1df5c1dec30c95",
    "STATIC_V2_EXACT_ARGV.json": "a7e140d4407413308833cc1ebbbdece8d2706669771cfd215c17fe7d99ae889c",
    "STATIC_V2_LOCKED_SOURCE_SNAPSHOT.json": "59947769b7ac6908986f8dd6999eea767051df72ef3c059bdc0865fab9fa42fd",
    "STATIC_V2_ONE_SHOT_ATTEMPT_STARTED.json": "8879e99ba3c9641e65646576f3d66554c667ebb80baf0c2c71f853137545c62f",
    "STATIC_V2_PARENT_NAMESPACE_FACTS.json": "5276978c6299c1cf679ca1486bf544538177438cee17c4f5e0035f7b34fefc58",
    "STATIC_V2_RAW_CAPTURE_RESULT.json": "fc5601e45f1ef31ce8054eb1e13c113006a0530d67205082cefc608a791c1c66",
    "STATIC_V2_RAW_MOUNTINFO.bin": "16f6aa08ac6c2ba1b3174f21e6114da26d03e15c4520c673bcfd6680e9fab981",
    "STATIC_V2_STRACE_INDEX.json": "bf4c4bfb6b2b547f8c553300c43d9d4e8805bb2c638171fd7041d3993c4a189a",
    "traces/static-v2.strace.4": "e166f6d3c2fbca65adde2d87339d56cd5791f909345195a3b56a1f3c14cd2289",
}


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_governance_root(directory: pathlib.Path) -> str:
    manifest_path = directory / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest = load(manifest_path)
    rows = b"".join(
        f"{item['sha256']}  {item['path']}\n".encode("utf-8")
        for item in sorted(manifest["files"], key=lambda item: item["path"])
    )
    rows += f"{sha(manifest_path)}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("utf-8")
    return hashlib.sha256(rows).hexdigest()


def canonical_source_root(manifest: dict) -> str:
    rows = b"".join(
        f"{item['sha256']}  {item['path']}\n".encode("utf-8")
        for item in sorted(manifest["members"], key=lambda item: item["path"])
    )
    return hashlib.sha256(rows).hexdigest()


def write_json(name: str, value) -> None:
    target = ROOT / name
    if os.path.lexists(target):
        raise RuntimeError(f"refusing to overwrite governance artifact: {name}")
    target.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    checks: list[dict] = []

    def check(name: str, condition, evidence=None) -> None:
        row = {"id": f"C{len(checks) + 1:03d}", "name": name, "pass": bool(condition)}
        if evidence is not None:
            row["evidence"] = evidence
        checks.append(row)

    prev_lock_path = PREV / "GOVERNANCE_LOCK.json"
    prev_manifest_path = PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    prev_lock = load(prev_lock_path)
    prev_manifest = load(prev_manifest_path)
    prev_members = sorted(item["path"] for item in prev_manifest["files"])
    actual_prev_members = sorted(
        item.name for item in PREV.iterdir()
        if item.is_file() and item.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    )

    static_lock_path = VALIDATOR_V2 / "locks/STATIC_EXECUTION_LOCK_V2.json"
    static_manifest_path = VALIDATOR_V2 / "locks/STATIC_SOURCE_MANIFEST_V2.json"
    static_verification_path = VALIDATOR_V2 / "locks/STATIC_LOCK_VERIFICATION_V2.json"
    static_lock = load(static_lock_path)
    static_manifest = load(static_manifest_path)
    static_verification = load(static_verification_path)
    static_members_ok = all(
        (PRODUCT / item["path"]).is_file()
        and not (PRODUCT / item["path"]).is_symlink()
        and (PRODUCT / item["path"]).stat().st_size == item["bytes"]
        and sha(PRODUCT / item["path"]) == item["sha256"]
        for item in static_manifest["members"]
    )

    started_path = RUNTIME / "STATIC_V2_ONE_SHOT_ATTEMPT_STARTED.json"
    terminal_path = RUNTIME / "STATIC_V2_CONTROLLER_TERMINAL_RESULT.json"
    raw_result_path = RUNTIME / "STATIC_V2_RAW_CAPTURE_RESULT.json"
    trace_index_path = RUNTIME / "STATIC_V2_STRACE_INDEX.json"
    started = load(started_path)
    terminal = load(terminal_path)
    raw_result = load(raw_result_path)
    trace_index = load(trace_index_path)
    trace_text = TRACE.read_text(encoding="utf-8", errors="replace")
    successful_exec_lines = [line for line in trace_text.splitlines() if re.match(r"^execve(at)?\(", line) and line.rstrip().endswith("= 0")]

    loader_path = VALIDATOR_V2 / "static_run_entry_v2.py"
    model_path = PRODUCT / "tooling/mountinfo_model.py"
    loader_source = loader_path.read_text(encoding="utf-8")
    model_source = model_path.read_text(encoding="utf-8")
    runtime_inventory = []
    for item in sorted(RUNTIME.iterdir(), key=lambda item: item.name):
        if item.is_file():
            runtime_inventory.append({"path": item.name, "bytes": item.stat().st_size, "sha256": sha(item)})
    runtime_inventory.append({"path": "traces/static-v2.strace.4", "bytes": TRACE.stat().st_size, "sha256": sha(TRACE)})

    check("predecessor lock digest", sha(prev_lock_path) == PREV_LOCK_SHA)
    check("predecessor manifest digest", sha(prev_manifest_path) == PREV_MANIFEST_SHA)
    check("predecessor canonical root", canonical_governance_root(PREV) == PREV_ROOT_SHA == prev_lock["canonical_artifact_root_sha256"])
    check("predecessor governance status", prev_lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("predecessor manifest member count", prev_manifest["member_count"] == len(prev_manifest["files"]) == 24)
    check("predecessor manifest coverage", prev_members == actual_prev_members)
    check("predecessor member hashes", all((PREV / item["path"]).stat().st_size == item["bytes"] and sha(PREV / item["path"]) == item["sha256"] for item in prev_manifest["files"]))
    check("static execution lock digest", sha(static_lock_path) == STATIC_LOCK_SHA)
    check("static source manifest digest", sha(static_manifest_path) == STATIC_MANIFEST_SHA)
    check("static lock verification digest", sha(static_verification_path) == STATIC_VERIFICATION_SHA)
    check("static source member count", static_manifest["member_count"] == len(static_manifest["members"]) == 40)
    check("static source member hashes", static_members_ok)
    check("static source canonical root", canonical_source_root(static_manifest) == STATIC_ROOT_SHA == static_manifest["canonical_source_root_sha256"])
    check("static lock canonical root", static_lock["canonical_source_root_sha256"] == STATIC_ROOT_SHA)
    check("static lock originally ready", static_lock["status"] == "STATIC_LOCK_PASS_VALIDATOR_V2_ONE_SHOT_READY")
    check("attempt-start digest", sha(started_path) == EVIDENCE_HASHES[started_path.name])
    check("controller-terminal digest", sha(terminal_path) == EVIDENCE_HASHES[terminal_path.name])
    check("raw-capture-result digest", sha(raw_result_path) == EVIDENCE_HASHES[raw_result_path.name])
    check("raw-mountinfo digest", sha(RUNTIME / "STATIC_V2_RAW_MOUNTINFO.bin") == EVIDENCE_HASHES["STATIC_V2_RAW_MOUNTINFO.bin"])
    check("trace-index digest", sha(trace_index_path) == EVIDENCE_HASHES[trace_index_path.name])
    check("trace digest", sha(TRACE) == EVIDENCE_HASHES["traces/static-v2.strace.4"])
    check("parent namespace digest", sha(RUNTIME / "STATIC_V2_PARENT_NAMESPACE_FACTS.json") == EVIDENCE_HASHES["STATIC_V2_PARENT_NAMESPACE_FACTS.json"])
    check("child namespace digest", sha(RUNTIME / "STATIC_V2_CHILD_NAMESPACE_FACTS.json") == EVIDENCE_HASHES["STATIC_V2_CHILD_NAMESPACE_FACTS.json"])
    check("exact argv evidence digest", sha(RUNTIME / "STATIC_V2_EXACT_ARGV.json") == EVIDENCE_HASHES["STATIC_V2_EXACT_ARGV.json"])
    check("locked-source snapshot digest", sha(RUNTIME / "STATIC_V2_LOCKED_SOURCE_SNAPSHOT.json") == EVIDENCE_HASHES["STATIC_V2_LOCKED_SOURCE_SNAPSHOT.json"])
    check("attempt identity exact", started["static_identity"] == static_lock["validation_identity"] and started["operation_identity"] == static_lock["operation_identity"])
    check("attempt consumed once", started["execution_count"] == terminal["execution_count"] == 1 and started["status"] == "ATTEMPT_STARTED_SINGLE_USE_CONSUMED")
    check("retry denied", started["retry_authorized"] is False and terminal["retry_authorized"] is False)
    check("child exited one", terminal["child_exit_code"] == 1)
    check("recorded prohibited operation counters zero", all(terminal[key] == 0 for key in ("dotnet_invocations", "nuget_invocations", "p3_invocations")))
    check("raw capture durable", raw_result["status"] == "PASS_DURABLE_READBACK_VERIFIED" and raw_result["raw_mountinfo_sha256"] == EVIDENCE_HASHES["STATIC_V2_RAW_MOUNTINFO.bin"])
    check("trace index complete for declared inventory", trace_index["trace_file_count"] == 1 and trace_index["trace_files"][0]["sha256"] == EVIDENCE_HASHES["traces/static-v2.strace.4"])
    check("successful exec inventory", len(successful_exec_lines) == 1 and 'execve("/usr/bin/python3.14"' in successful_exec_lines[0])
    required_missing = [
        "STATIC_V2_RUNTIME_CONFINEMENT_RESULT.json",
        "STATIC_V2_WRITE_PROBE_RESULT.json",
        "STATIC_V2_TEST_SEQUENCE_RESULT.json",
        "STATIC_V2_CHILD_TERMINAL_RESULT.json",
    ]
    check("required post-loader artifacts absent", all(not (RUNTIME / name).exists() for name in required_missing), required_missing)
    module_from = loader_source.find("module = importlib.util.module_from_spec(spec)")
    exec_module = loader_source.find("spec.loader.exec_module(module)")
    registration = loader_source.find("sys.modules[")
    check("loader executes dynamic module", module_from >= 0 and exec_module > module_from)
    check("loader omits sys.modules registration", registration < 0)
    check("loaded model declares dataclass", "@dataclass(frozen=True)" in model_source)
    check("trace reaches dataclasses before exit one", "/usr/lib/python3.14/dataclasses.py" in trace_text and "exit_group(1)" in trace_text)
    check("successor validator path absent", not os.path.lexists(VALIDATOR_V3))
    check("successor run path absent", not os.path.lexists(RUN_V3))
    check("no conflicting governance lock", not (ROOT / "GOVERNANCE_LOCK.json").exists())
    check("governance output path exact", ROOT.parent == PREV.parent and ROOT.name.endswith("governance-v1-20261015"))

    if not all(item["pass"] for item in checks):
        print(json.dumps({"status": "STOP_FAIL_CLOSED", "failed": [item for item in checks if not item["pass"]]}, indent=2))
        return 1

    observed = datetime.now(timezone.utc).isoformat()
    write_json("PREFLIGHT_RESULT.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS",
        "checks_total": len(checks),
        "checks_passed": len(checks),
        "checks": checks,
        "observed_utc": observed,
    })
    write_json("ROUTING_AND_SCOPE_DECISION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS",
        "authorization": "GOVERNANCE_ONLY_STATIC_VALIDATION_V2_FAILURE_ADJUDICATION_AND_SUCCESSOR_DECISION",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness"],
        "deferred": ["Validator V3 implementation", "Static Validation V3 execution", "P3 V2", "P6", "V0.3-A"],
        "not_applicable": ["live target testing", "dotnet", "NuGet", "Windows", "VBoxManage", "Recovery V3", "subagents"],
        "claim_boundary": "No engineering execution, source patch, retry, relock, P3, P6, Recovery, or V0.3 artifact is authorized by this governance run.",
    })
    write_json("TEMPORAL_VERIFIER_SCOPE_DECISION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS_TEMPORAL_SCOPE_RECORDED",
        "predecessor_historical_freeze_result": "34_OF_34_PASS_AT_ISSUANCE",
        "current_integrity_method": "VERIFY_FROZEN_MANIFEST_MEMBERS_DIGESTS_AND_CANONICAL_ROOT",
        "current_immutable_integrity": "24_OF_24_MEMBERS_PASS",
        "expired_temporal_predicates": ["validator-v2 absent", "static-run-v2 absent", "static attempt zero"],
        "reason": "Those predicates were true before the separately authorized V2 engineering operation and are not current immutability requirements.",
        "historical_result_rewrite": "PROHIBITED",
    })
    write_json("STATIC_VALIDATION_V2_TERMINAL_DISPOSITION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "FAIL_CLOSED_TERMINAL_NO_RETRY",
        "validation_identity": static_lock["validation_identity"],
        "operation_identity": static_lock["operation_identity"],
        "attempt_count": 1,
        "attempt_state": "CONSUMED",
        "retry_authorized": False,
        "patch_in_place": "PROHIBITED",
        "relock_same_identity": "PROHIBITED",
        "promotion": "PROHIBITED",
        "classification": {
            "PRODUCT_DEFECT": False,
            "SEMANTIC_ARGV_VALIDATOR_DEFECT": False,
            "STATIC_LOCK_DEFECT": False,
            "EXECUTION_LOADER_DEFECT": True,
            "POST_VALIDATION_COMPLETE": False,
        },
    })
    write_json("EXECUTION_LOADER_ROOT_CAUSE_REVIEW.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "ROOT_CAUSE_CONFIRMED_EXECUTION_LOADER_DEFECT",
        "defective_source": str(loader_path),
        "loaded_source": str(model_path),
        "mechanism": [
            "spec_from_file_location creates a spec for locked_product_mountinfo_v2",
            "module_from_spec creates the module object",
            "the loader does not register the module in sys.modules before exec_module",
            "mountinfo_model.py declares MountRecord with @dataclass and postponed annotations",
            "Python 3.14 dataclasses consults sys.modules for the declaring module while processing those annotations",
        ],
        "trace_sequence": ["raw evidence persisted", "mountinfo_model.py opened", "dataclasses.py opened", "process exit_group(1)"],
        "source_facts": {
            "module_from_spec_before_exec_module": True,
            "sys_modules_registration_before_exec": False,
            "dataclass_present": True,
        },
        "exact_exception_text": "NOT_PERSISTED_AS_A_RUNTIME_ARTIFACT; authoritative operator report identifies AttributeError",
        "scope": "The defect is in the V2 execution loader, not in Product V2, semantic argv validation, or the issued static lock.",
        "old_source_repair": "PROHIBITED",
    })
    write_json("PARTIAL_RUNTIME_EVIDENCE_INVENTORY.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PARTIAL_HISTORICAL_EVIDENCE_ADMISSIBLE_WITH_LIMITS",
        "files": runtime_inventory,
        "captured": {
            "raw_mountinfo": True,
            "raw_mountinfo_durable_readback": True,
            "parent_namespace_facts": True,
            "child_namespace_facts": True,
            "exact_argv": True,
            "locked_source_snapshot": True,
            "strace": True,
            "successful_execve_observed": ["/usr/bin/python3.14"],
        },
        "not_completed": ["mount topology evaluation", "effective mount decision", "FD/socket/environment gate", "negative-write probes", "positive controls", "confined static tests", "independent post-validation"],
        "confinement_pass": "NOT_PROVEN",
        "limitation": "Partial evidence may establish provenance and failure ordering only; it cannot be promoted to a confinement PASS.",
    })
    write_json("POST_VALIDATION_COMPLETENESS_DECISION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "INCOMPLETE_FAIL_CLOSED",
        "topology_evaluation": "NOT_COMPLETED",
        "negative_write_probes": "NOT_EXECUTED",
        "confined_static_tests": "NOT_EXECUTED",
        "independent_post_validation": "NOT_COMPLETED",
        "confinement_verdict": "NOT_ESTABLISHED",
        "V0_2_acceptance": "NOT_ESTABLISHED",
    })
    write_json("LOCKED_SOURCE_IMMUTABILITY_RESULT.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS_IMMUTABILITY_ONLY",
        "static_execution_lock_sha256": STATIC_LOCK_SHA,
        "static_source_manifest_sha256": STATIC_MANIFEST_SHA,
        "canonical_source_root_sha256": STATIC_ROOT_SHA,
        "locked_members_total": 40,
        "locked_members_matching": 40,
        "locked_source_mutation": False,
        "product_v2_mutation": False,
        "acceptance_implication": "NONE; byte identity proves provenance, not confinement or V0.2 acceptance.",
    })
    write_json("SUCCESSOR_DECISION.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS_DECISION_B_DISTINCT_VALIDATION_SUCCESSOR_AUTHORIZED",
        "decision": "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY",
        "terminalized_identity": static_lock["validation_identity"],
        "product_v2_core_reuse": "AUTHORIZED_READ_ONLY_UNCHANGED_INPUT",
        "old_validator_v2": "TERMINAL_IMMUTABLE_REFERENCE_ONLY",
        "old_static_run_v2": "TERMINAL_IMMUTABLE_EVIDENCE_ONLY",
        "new_product_successor_required": False,
        "new_validation_successor_required": True,
        "successor_authorization_identity": SUCCESSOR_AUTHORIZATION,
        "validator_v3_identity": VALIDATOR_V3_IDENTITY,
        "validation_v3_identity": VALIDATION_V3_IDENTITY,
        "validation_v3_operation": VALIDATION_V3_OPERATION,
        "validator_v3_path": str(VALIDATOR_V3),
        "static_run_v3_path": str(RUN_V3),
    })
    write_json("STATIC_VALIDATION_V3_IDENTITY_BINDING.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "AUTHORIZED_RESERVED_NOT_CREATED_NOT_EXECUTED",
        "authorization_identity": SUCCESSOR_AUTHORIZATION,
        "validator_identity": VALIDATOR_V3_IDENTITY,
        "validation_identity": VALIDATION_V3_IDENTITY,
        "operation_identity": VALIDATION_V3_OPERATION,
        "validator_source_path": str(VALIDATOR_V3),
        "static_run_path": str(RUN_V3),
        "persistent_writable_output_path": str(RUN_V3 / "output"),
        "maximum_attempts": 1,
        "attempt_count": 0,
        "retry_authorized": False,
        "execution_eligibility": "CONDITIONAL_NOT_EXECUTABLE_UNTIL_FRESH_TESTS_INDEPENDENT_VALIDATION_AND_STATIC_LOCK_PASS",
    })
    write_json("LOADER_REGRESSION_REQUIREMENTS.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "MANDATORY_FOR_VALIDATOR_V3",
        "required_cases": [
            {"id": "L001", "case": "legacy unregistered dynamic import of a postponed-annotation dataclass", "expected": "DETERMINISTIC_FAILURE_REPRODUCED_IN_INERT_FIXTURE"},
            {"id": "L002", "case": "corrected loader registers the exact module identity before exec_module", "expected": "PASS"},
            {"id": "L003", "case": "module-name collision", "expected": "FAIL_CLOSED_NO_OVERWRITE"},
            {"id": "L004", "case": "exec_module failure after registration", "expected": "PRIOR_SYS_MODULES_STATE_RESTORED_OR_FRESH_ENTRY_REMOVED"},
            {"id": "L005", "case": "wrong source path or source digest", "expected": "REJECT"},
            {"id": "L006", "case": "loader returns a module whose __name__ differs from the bound identity", "expected": "REJECT"},
            {"id": "L007", "case": "canonical Product V2 mountinfo model", "expected": "LOAD_AND_PARSE_FIXTURE_PASS"},
            {"id": "L008", "case": "missing or truncated loader evidence", "expected": "FAIL_CLOSED"},
        ],
        "independence": "Main and independent validators must use different implementation paths and the same normative contract.",
        "old_validator_execution": "PROHIBITED",
    })
    write_json("STATIC_VALIDATION_V3_AUTHORIZATION_CONTRACT.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "CONDITIONAL_SINGLE_USE_ENGINEERING_AUTHORIZATION",
        "authorization_identity": SUCCESSOR_AUTHORIZATION,
        "permitted": [
            "create fresh validator-v3 source only at the bound path",
            "create inert loader regression fixtures and independent tests",
            "perform read-only Product V2 input verification",
            "create a fresh static source manifest and static execution lock",
            "execute Static Validation V3 once only after every pre-execution gate passes",
        ],
        "mandatory_pre_execution_gates": [
            "predecessor governance and V2 terminal evidence digests pass",
            "Product V2 core remains byte-identical",
            "Validator V2 and Static Validation V2 remain immutable",
            "all loader regression tests pass",
            "independent validator parity passes",
            "exact argv and environment are digest-bound",
            "host root read-only and network namespace isolation are enforced",
            "only static-run-v3/output is host-backed writable",
            "fresh static lock is issued and reread without mutation",
        ],
        "attempt_semantics": "ONE_ATTEMPT_CONSUMED_WHEN_EXECUTION_STARTS_NO_RETRY",
        "failure_semantics": "FAIL_CLOSED_TERMINAL_PRESERVE_EVIDENCE_NO_PATCH_NO_RELOCK_SAME_IDENTITY",
        "exact_argv_digest": "TO_BE_COMPUTED_AND_BOUND_BY_FRESH_STATIC_LOCK_BEFORE_EXECUTION",
        "source_digest": "TO_BE_COMPUTED_AND_BOUND_BY_FRESH_STATIC_LOCK_BEFORE_EXECUTION",
        "prohibitions": ["patch validator-v2", "retry Static Validation V2", "dotnet", "NuGet", "P3 V2", "P6", "Recovery", "V0.3 artifact creation"],
    })
    write_json("OPERATION_AUTHORIZATION_MATRIX.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS",
        "operations": {
            "Static_Validation_V2": "TERMINAL_CONSUMED_NO_RETRY",
            "Validator_V2_patch": "PROHIBITED",
            "Validator_V2_relock": "PROHIBITED",
            "Validator_V3_source_implementation": "AUTHORIZED_NEXT_MILESTONE",
            "Validator_V3_static_tests": "AUTHORIZED_NEXT_MILESTONE_INERT_ONLY_BEFORE_LOCK",
            "Static_Validation_V3": "CONDITIONAL_SINGLE_USE_NOT_EXECUTABLE_UNTIL_ALL_GATES_PASS",
            "P3_V2": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE",
            "P6": "NOT_ELIGIBLE_NOT_AUTHORIZED",
            "Recovery_V3": "NOT_AUTHORIZED",
            "V0_3": "BLOCKED_G0_NOT_MET_NO_ARTIFACT_CREATION",
        },
    })
    write_json("HISTORICAL_IMMUTABILITY_RESULT.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "PASS",
        "predecessor_governance_members_verified": 24,
        "static_v2_locked_members_verified": 40,
        "runtime_evidence_members_verified": len(runtime_inventory),
        "historical_mutations": 0,
        "Product_V1": "TERMINAL_UNCHANGED",
        "Product_V2": "LOCKED_INPUTS_UNCHANGED",
        "Static_Validation_V2": "TERMINAL_UNCHANGED",
    })
    write_json("NEXT_LEGAL_MILESTONE.json", {
        "schema_version": 1,
        "governance_identity": IDENTITY,
        "status": "AUTHORIZED_CONDITIONAL_ENGINEERING_NEXT",
        "milestone": NEXT_MILESTONE,
        "V0_2": "PASS_LOCKED_GOVERNANCE_ONLY",
        "G0": "NOT_MET",
        "V0_3": "BLOCKED",
        "stop_boundary": "STOP_AFTER_GOVERNANCE; do not create Validator V3 in this milestone.",
    })
    print(json.dumps({"status": "PASS", "preflight": f"{len(checks)}/{len(checks)}", "artifacts_created": 14}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
