#!/usr/bin/env python3
"""Create the non-circular governance manifest and lock, then freeze them."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib


ROOT = pathlib.Path(__file__).resolve().parent
PREV = pathlib.Path("/home/nobcoder/codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v2-validator-v2-preflight-out-of-scope-tmp-write-and-cleanup-erratum-and-continuation-decision-governance-v1-20261015")
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATION_V2_IMPORT_LOADER_AND_POST_VALIDATION_INCOMPLETE_EVIDENCE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
NEXT = "IMPLEMENT_AND_STATICALLY_LOCK_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATOR_V3_THEN_EXECUTE_CONFINED_STATIC_VALIDATION_V3_ONCE_IF_ALL_GATES_PASS"


def sha(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write_new(path: pathlib.Path, value) -> None:
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite {path.name}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


self_test = load("GOVERNANCE_TEST_RESULT.json")
negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
independent = load("INDEPENDENT_VALIDATION_RESULT.json")
preflight = load("PREFLIGHT_RESULT.json")
if any(item["status"] != "PASS" for item in (self_test, negative, independent, preflight)):
    raise SystemExit("mandatory governance validation did not pass")

manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
lock_path = ROOT / "GOVERNANCE_LOCK.json"
members = []
for path in sorted(ROOT.iterdir(), key=lambda item: item.name):
    if path.name in {manifest_path.name, lock_path.name}:
        continue
    if not path.is_file() or path.is_symlink():
        raise RuntimeError(f"unexpected non-regular governance member: {path}")
    members.append({"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path)})
manifest = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_MANIFEST_COMPLETE",
    "member_count": len(members),
    "files": members,
    "coverage": "Every top-level regular file except GOVERNANCE_ARTIFACT_MANIFEST.json and GOVERNANCE_LOCK.json; no subdirectories permitted.",
}
write_new(manifest_path, manifest)
manifest_sha = sha(manifest_path)
rows = b"".join(f"{item['sha256']}  {item['path']}\n".encode("utf-8") for item in sorted(members, key=lambda item: item["path"]))
rows += f"{manifest_sha}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("utf-8")
canonical_root = hashlib.sha256(rows).hexdigest()

binding = load("STATIC_VALIDATION_V3_IDENTITY_BINDING.json")
lock = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_LOCKED_GOVERNANCE_ONLY",
    "disposition": "STATIC_VALIDATION_V2_FAIL_CLOSED_TERMINAL_LOADER_DEFECT_POST_VALIDATION_INCOMPLETE_SUCCESSOR_V3_CONDITIONALLY_AUTHORIZED_P3_V03_BLOCKED",
    "predecessor_governance_lock_sha256": sha(PREV / "GOVERNANCE_LOCK.json"),
    "predecessor_governance_manifest_sha256": sha(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
    "predecessor_canonical_root_sha256": "cc3114ce8c7d776ce5f9a9199b822b9dd86b32e21f5cba01f985e525a5133437",
    "governance_manifest_sha256": manifest_sha,
    "canonical_artifact_root_sha256": canonical_root,
    "canonical_root_algorithm": "SHA256 of member-path-sorted UTF-8 rows '<sha256>  <relative-path>\\n', followed by the GOVERNANCE_ARTIFACT_MANIFEST.json row; GOVERNANCE_LOCK.json excluded",
    "canonical_root_member_count": len(members) + 1,
    "canonical_preflight": {"passed": preflight["checks_passed"], "total": preflight["checks_total"]},
    "governance_self_tests": {"passed": self_test["checks_passed"], "total": self_test["checks_total"]},
    "negative_governance_tests": {"passed": negative["tests_passed"], "total": negative["tests_total"]},
    "independent_validation": {"passed": independent["checks_passed"], "total": independent["checks_total"]},
    "freeze_verification_expected": "34_OF_34_PASS",
    "Static_Validation_V2": "FAIL_CLOSED_TERMINAL_CONSUMED_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION",
    "Static_Validation_V2_attempt_count": 1,
    "confinement_pass": "NOT_PROVEN",
    "post_validation": "INCOMPLETE",
    "locked_source_immutability": "40_OF_40_PASS_NO_MUTATION_ACCEPTANCE_NOT_IMPLIED",
    "successor_decision": "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY",
    "validator_V3_identity": binding["validator_identity"],
    "validation_V3_identity": binding["validation_identity"],
    "validation_V3_operation": binding["operation_identity"],
    "validation_V3_attempt_count": 0,
    "validation_V3_maximum_attempts": 1,
    "validation_V3_status": binding["execution_eligibility"],
    "P3_V2": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE",
    "P6": "NOT_ELIGIBLE_NOT_AUTHORIZED",
    "V0_2": "PASS_LOCKED_GOVERNANCE_ONLY",
    "G0": "NOT_MET",
    "V0_3": "BLOCKED_NO_ARTIFACT_CREATION",
    "Recovery_V3": "NOT_AUTHORIZED",
    "next_legal_milestone": NEXT,
    "claim_boundary": "This lock authorizes only the fresh Validator V3 engineering lineage and one conditional future Static Validation V3 attempt after all new gates pass. It does not prove confinement, authorize P3/P6/Recovery, or satisfy V0.3 G0.",
}
write_new(lock_path, lock)

for path in ROOT.iterdir():
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"unexpected governance entry before freeze: {path}")
    path.chmod(0o444)
ROOT.chmod(0o555)
print(json.dumps({"status": "PASS_LOCKED_GOVERNANCE_ONLY", "manifest_sha256": manifest_sha, "canonical_root_sha256": canonical_root, "member_count": len(members), "root_member_count": len(members) + 1}, indent=2))
