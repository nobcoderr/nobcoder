#!/usr/bin/env python3
"""Read-only verifier for the final Static Validation V2 adjudication freeze."""

from __future__ import annotations

import hashlib
import json
import pathlib
import stat


ROOT = pathlib.Path(__file__).resolve().parent
PREV = pathlib.Path("/home/nobcoder/codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v2-validator-v2-preflight-out-of-scope-tmp-write-and-cleanup-erratum-and-continuation-decision-governance-v1-20261015")
PRODUCT = pathlib.Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2")
RUNTIME = PRODUCT / "static-run-v2/output/artifacts/runtime"
TRACE = PRODUCT / "static-run-v2/output/artifacts/traces/static-v2.strace.4"


def sha(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def load(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))


manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
lock_path = ROOT / "GOVERNANCE_LOCK.json"
manifest = load(manifest_path)
lock = load(lock_path)
checks = []


def add(name: str, condition) -> None:
    checks.append({"id": f"F{len(checks) + 1:02d}", "name": name, "pass": bool(condition)})


listed = sorted(item["path"] for item in manifest["files"])
actual = sorted(item.name for item in ROOT.iterdir() if item.is_file() and item.name not in {manifest_path.name, lock_path.name})
add("manifest regular", manifest_path.is_file() and not manifest_path.is_symlink())
add("lock regular", lock_path.is_file() and not lock_path.is_symlink())
add("manifest count", manifest["member_count"] == len(manifest["files"]))
add("manifest coverage", listed == actual)
add("manifest unique", len(set(listed)) == len(listed))
add("members regular", all((ROOT / item["path"]).is_file() and not (ROOT / item["path"]).is_symlink() for item in manifest["files"]))
add("member bytes and hashes", all((ROOT / item["path"]).stat().st_size == item["bytes"] and sha(ROOT / item["path"]) == item["sha256"] for item in manifest["files"]))
add("manifest digest", sha(manifest_path) == lock["governance_manifest_sha256"])
rows = b"".join(f"{item['sha256']}  {item['path']}\n".encode() for item in sorted(manifest["files"], key=lambda row: row["path"]))
rows += f"{sha(manifest_path)}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode()
add("canonical root", hashlib.sha256(rows).hexdigest() == lock["canonical_artifact_root_sha256"])
add("canonical count", len(manifest["files"]) + 1 == lock["canonical_root_member_count"])
add("governance status", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
add("disposition exact", lock["disposition"] == "STATIC_VALIDATION_V2_FAIL_CLOSED_TERMINAL_LOADER_DEFECT_POST_VALIDATION_INCOMPLETE_SUCCESSOR_V3_CONDITIONALLY_AUTHORIZED_P3_V03_BLOCKED")
add("predecessor lock hash", sha(PREV / "GOVERNANCE_LOCK.json") == lock["predecessor_governance_lock_sha256"])
add("predecessor manifest hash", sha(PREV / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock["predecessor_governance_manifest_sha256"])
static_lock = PRODUCT / "validator-v2/locks/STATIC_EXECUTION_LOCK_V2.json"
static_manifest_path = PRODUCT / "validator-v2/locks/STATIC_SOURCE_MANIFEST_V2.json"
static_manifest = load(static_manifest_path)
add("static V2 lock hash", sha(static_lock) == "36a24159313feb7bc9cfb9f1528ac65b88fc7b7790c8bd86de2ed253e003647c")
add("static V2 manifest hash", sha(static_manifest_path) == "61fd682e644cfbb7f772b4175ecf53a0f471f41e9c2c9861041328941406db0a")
add("static V2 forty members", len(static_manifest["members"]) == 40 and all(sha(PRODUCT / item["path"]) == item["sha256"] and (PRODUCT / item["path"]).stat().st_size == item["bytes"] for item in static_manifest["members"]))
add("attempt-start hash", sha(RUNTIME / "STATIC_V2_ONE_SHOT_ATTEMPT_STARTED.json") == "8879e99ba3c9641e65646576f3d66554c667ebb80baf0c2c71f853137545c62f")
add("controller-terminal hash", sha(RUNTIME / "STATIC_V2_CONTROLLER_TERMINAL_RESULT.json") == "81e3e5811df4afe8618e8e13fa358ff7b16fd06bb85829d78f1df5c1dec30c95")
add("raw-mountinfo hash", sha(RUNTIME / "STATIC_V2_RAW_MOUNTINFO.bin") == "16f6aa08ac6c2ba1b3174f21e6114da26d03e15c4520c673bcfd6680e9fab981")
add("trace hash", sha(TRACE) == "e166f6d3c2fbca65adde2d87339d56cd5791f909345195a3b56a1f3c14cd2289")
terminal = load(ROOT / "STATIC_VALIDATION_V2_TERMINAL_DISPOSITION.json")
partial = load(ROOT / "PARTIAL_RUNTIME_EVIDENCE_INVENTORY.json")
decision = load(ROOT / "SUCCESSOR_DECISION.json")
binding = load(ROOT / "STATIC_VALIDATION_V3_IDENTITY_BINDING.json")
matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
history = load(ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json")
add("V2 attempt count one", terminal["attempt_count"] == 1)
add("V2 retry false", terminal["retry_authorized"] is False)
add("V2 terminal", terminal["status"] == "FAIL_CLOSED_TERMINAL_NO_RETRY")
add("confinement not proven", partial["confinement_pass"] == "NOT_PROVEN")
add("successor decision B", decision["decision"] == "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY")
add("V3 maximum one", binding["maximum_attempts"] == 1 and binding["attempt_count"] == 0)
add("P3 blocked", matrix["operations"]["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
add("V0.3 blocked", matrix["operations"]["V0_3"] == "BLOCKED_G0_NOT_MET_NO_ARTIFACT_CREATION")
add("governance files read-only", all(stat.S_IMODE(item.stat().st_mode) == 0o444 for item in ROOT.iterdir() if item.is_file()))
add("governance directory read-only", stat.S_IMODE(ROOT.stat().st_mode) == 0o555)
add("no governance symlinks", not any(item.is_symlink() for item in ROOT.iterdir()))
add("historical mutation zero", history["historical_mutations"] == 0)
add("operation matrix keeps Recovery blocked", matrix["operations"]["Recovery_V3"] == "NOT_AUTHORIZED")

result = {"status": "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": sum(item["pass"] for item in checks), "failed_ids": [item["id"] for item in checks if not item["pass"]], "checks": checks}
print(json.dumps(result, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
