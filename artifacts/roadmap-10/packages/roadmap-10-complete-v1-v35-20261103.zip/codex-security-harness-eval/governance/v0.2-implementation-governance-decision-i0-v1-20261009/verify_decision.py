#!/usr/bin/env python3
"""Read-only verifier for the V0.2 I0 implementation decision."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DESIGN_LOCK = ROOT / "governance/v0.2-architecture-contract-review-v1-20261009/DESIGN_REVIEW_LOCK.json"
EXPECTED_DESIGN_SHA = "4bd40a8ddeb7f397215092c809b3637e7e8e914a0ac6378a2f68d1e138189723"


def load(name: str) -> dict:
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add(rows: list[dict], name: str, ok: bool) -> None:
    rows.append({"check": name, "result": "PASS" if ok else "FAIL"})


def main() -> int:
    protocol = load("IMPLEMENTATION_GATE_PROTOCOL.json")
    auth = load("I0_AUTHORIZATION.json")
    risks = load("RISK_REGISTER.json")
    decision = load("IMPLEMENTATION_DECISION.json")
    pre_decision = load("PRE_DECISION_LOCK.json")
    design = json.loads(DESIGN_LOCK.read_text(encoding="utf-8"))
    rows: list[dict] = []
    add(rows, "design lock digest", sha256(DESIGN_LOCK) == EXPECTED_DESIGN_SHA)
    add(rows, "design review passed", design.get("status") == "PASS_LOCKED_IMPLEMENTATION_GOVERNANCE_REQUIRED")
    add(rows, "I0 explicit authorization", auth.get("authorized") is True and auth.get("authorized_stage") == "I0")
    add(rows, "implementation root absent before decision", pre_decision.get("implementation_root_absent") is True)
    add(rows, "I0 bounded components", protocol["authorized_stage"].get("id") == "I0" and len(protocol["authorized_stage"]["components"]) == 7)
    add(rows, "I1-I5 forbidden", set(protocol["forbidden_stages"]) == {"I1", "I2", "I3", "I4", "I5"})
    add(rows, "model and network forbidden", "no model or agent invocation" in auth["prohibitions"] and "no network activity" in auth["prohibitions"])
    add(rows, "V0.1 mutation forbidden", "no V0.1 mutation or evidence import" in auth["prohibitions"])
    add(rows, "router risk registered", any(risk.get("id") == "RISK_ROUTER_PACKAGE_INTEGRITY" and risk.get("status") == "OPEN_DEGRADED_NON_BLOCKING_FOR_I0" for risk in risks["risks"]))
    add(rows, "sandbox risk blocks I4/I5", any(risk.get("id") == "RISK_OS_CONTAINMENT_ABSENT" and risk.get("status") == "OPEN_BLOCKS_I4_I5" for risk in risks["risks"]))
    add(rows, "I0 only decision", decision.get("decision") == "AUTHORIZE_I0_ONLY" and decision.get("I0_SCHEMA_VALIDATORS_CONTRACT_TESTS") == "AUTHORIZED")
    add(rows, "successors unauthorized", all(decision.get(key) == "NOT_AUTHORIZED" for key in ("I1_TARGET_REGISTRY_TRAJECTORY_STORE", "I2_EVIDENCE_FREEZER_PRIVATE_VERIFIER", "I3_RESET_FIXTURE_PACKAGING", "I4_SANDBOX_EXECUTOR", "I5_FIXTURE_MODEL_EXECUTION")))
    add(rows, "no automatic successor", decision.get("automatic_successor_authorization") is False)
    add(rows, "zero execution", decision.get("model_invocations") == 0 and decision.get("network_activity") == 0 and decision.get("subject_artifact_writes") == 0)
    passed = sum(row["result"] == "PASS" for row in rows)
    result = {"schema_version": 1, "gate_id": protocol["gate_id"], "status": "PASS" if passed == len(rows) else "FAIL", "passed": passed, "total": len(rows), "checks": rows}
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
