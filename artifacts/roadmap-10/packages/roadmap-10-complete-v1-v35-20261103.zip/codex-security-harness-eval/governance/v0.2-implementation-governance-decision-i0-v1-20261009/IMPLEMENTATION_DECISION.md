# V0.2 Implementation Governance Decision — I0 V1

Only I0 is authorized: canonical JSON schemas, a local offline validator,
positive and negative contract tests, and an immutable I0 validation lock in a
new source tree at `/home/nobcoder/v0.2-experimental-research-engine`.

I1 through I5 remain unauthorized. In particular, this decision permits no
target registry, trajectory persistence, private verifier, fixture packaging,
sandbox execution, fixture execution, model invocation, network activity,
scoring, or Source Autonomy claim.

The router package integrity mismatch remains an open risk. It is non-blocking
for pure I0 contract validation, but it must be closed before any workflow uses
automatic security routing.

I0 completion does not authorize I1. A new governance decision is required.
