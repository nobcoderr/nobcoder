#!/usr/bin/env python3
"""Deterministic governance self-tests for the I4-B provisioning V2 gate."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent / "v0.2-i4-b-candidate-platform-selection-evidence-decision-v1-20261010"
IDENTITY = "V0.2_I4_B_DEDICATED_ENVIRONMENT_PROVISIONING_GOVERNANCE_V2"
EXPECTED_CANDIDATE_ROOT = "a420d5d39a4330d24500f4e437b0bc337b2803bf3ba7ef605f7898f5b82be0dc"


def load(name: str):
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def governance_root(path: Path, excluded: str = "GOVERNANCE_LOCK.json") -> str:
    records = [
        f"{sha(item)}  {item.name}"
        for item in sorted(path.iterdir(), key=lambda value: value.name)
        if item.is_file() and not item.is_symlink() and item.name != excluded
    ]
    return hashlib.sha256(("\n".join(records) + "\n").encode()).hexdigest()


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


protocol = load("GOVERNANCE_GATE_PROTOCOL.json")
preflight = load("PREFLIGHT_RESULT.json")
authority = load("PROVISIONING_AUTHORITY_ASSESSMENT.json")
decision = load("PROVISIONING_DECISION.json")
platform = load("HOST_PLATFORM_BINDING.json")
compat = load("HYPERVISOR_COMPATIBILITY_RESULT.json")
resources = load("RESOURCE_FEASIBILITY.json")
image = load("GUEST_IMAGE_BINDING.json")
security = load("VM_SECURITY_CONFIGURATION.json")
bootstrap = load("OFFLINE_BOOTSTRAP_PLAN.json")
transfer = load("EVIDENCE_TRANSFER_PLAN.json")
matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
readiness = load("PRE_PROVISION_READINESS.json")
post = load("POST_PROVISION_VALIDATION_CONTRACT.json")
docs = load("DOCUMENTATION_EVIDENCE.json")
threats = load("PROVISIONING_THREAT_MODEL.json")
risks = load("RISK_REGISTER.json")

check("identity_protocol", protocol["gate_id"] == IDENTITY)
check("identity_decision", decision["gate_id"] == IDENTITY)
check("governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
check("preflight_pass", preflight["status"] == "PASS")
check("preflight_scope", preflight["result"] == "SAFE_TO_CREATE_V2_GOVERNANCE_DECISION_ARTIFACTS_ONLY")
check("preflight_no_collision", preflight["authority_state"]["v2_identity_collision"] is False)
check("preflight_no_predecessor_writes", preflight["writes_to_predecessor_trees"] == 0)
check("router_not_required", protocol["router_integrity"]["router_required_for_this_direct_local_gate"] is False)
check("router_paths_blocked", preflight["router_dependent_workflows"] == "BLOCKED")

expected_files = {
    "GOVERNANCE_LOCK.json": "66cc7168e8799b373d41eb8e7e4d55efbd7d6801803cabfac887c69eb4320a3f",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "c160f641582e7535ff2ef921065dfc9eb15a885c66861eea51d28049adf68ea0",
}
for name, expected in expected_files.items():
    check(f"candidate_{name}_sha256", sha(CANDIDATE / name) == expected)
check("candidate_artifact_root", governance_root(CANDIDATE) == EXPECTED_CANDIDATE_ROOT)
candidate_lock = json.loads((CANDIDATE / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8"))
candidate_auth = json.loads((CANDIDATE / "HOST_AUTHORIZATION_EVIDENCE.json").read_text(encoding="utf-8"))
check("candidate_event_chain", candidate_lock["required_next_event"] == "NEW_I4_B_DEDICATED_ENVIRONMENT_PROVISIONING_AUTHORIZATION_DECISION_V2")
check("candidate_provisioning_denied", candidate_lock["authorization_boundary"]["provisioning"] == "NOT_GRANTED")
check("selection_attestation_limited", candidate_auth["status"] == "USER_ATTESTATION_ACCEPTED_FOR_PLATFORM_SELECTION_ONLY")
check("selection_attestation_no_effect", candidate_auth["authorization_effect"] == "NONE")

check("authority_not_established", authority["status"] == "PROVISIONING_SPECIFIC_AUTHORITY_NOT_ESTABLISHED")
check("authority_no_promotion", "must not be promoted" in authority["promotion_rule"])
check("decision_methodology_pass", decision["status"] == "PASS_LOCKED")
check("decision_blocked", decision["decision"] == "GOVERNANCE_REVIEW_PASS_PROVISIONING_AUTHORIZATION_BLOCKED")
check("decision_disposition", decision["disposition"] == "PROVISIONING_SPECIFIC_OWNER_AUTHORIZATION_NOT_ESTABLISHED")
check("provisioning_not_granted", decision["provisioning_authorization"] == "NOT_GRANTED")
check("approved_scope_none", decision["approved_provisioning_scope"] == "NONE")
check("image_acquisition_not_granted", decision["image_acquisition_authorization"] == "NOT_GRANTED")
check("host_config_not_granted", decision["host_configuration_authorization"] == "NOT_GRANTED")
check("vm_creation_denied", decision["vm_creation"] == "NOT_AUTHORIZED")
check("vm_start_denied", decision["vm_startup"] == "NOT_AUTHORIZED")
check("guest_install_denied", decision["guest_installation"] == "NOT_AUTHORIZED")
check("i4b_denied", decision["i4_b_execution_authorization"] == "NOT_GRANTED")
check("runtime_not_evaluated", decision["actual_runtime_isolation"] == "NOT_EVALUATED")
check("later_milestones_closed", decision["i5"] == "NOT_AUTHORIZED" and decision["v0_3"] == "NOT_OPENED")
check("no_auto_successor", decision["automatic_successor_authorization"] is False)

host = platform["host"]
hypervisor = platform["hypervisor"]
vm = platform["vm"]
guards = platform["guards"]
check("host_alias", host["alias"] == "lab-host-01")
check("host_os", host["operating_system"] == "Microsoft Windows 11 Home Single Language")
check("host_arch", host["architecture"] == "64-bit")
check("host_cpu", "i7-12650H" in host["cpu"])
check("host_cpu_count", host["physical_cores"] == 10 and host["logical_processors"] == 16)
check("host_ram", host["ram_gib"] == 15.69)
check("hypervisor_product", hypervisor["product"] == "Oracle VM VirtualBox")
check("hypervisor_version", hypervisor["version"] == "7.2.16.174877")
check("hardware_virtualization", hypervisor["hardware_virtualization_observation"] == "YES_BY_VBOXMANAGE")
check("nested_paging", hypervisor["nested_paging_observation"] == "YES_BY_VBOXMANAGE")
check("unrestricted_guest_preserved", hypervisor["unrestricted_guest_observation"] == "NO_BY_VBOXMANAGE")
check("vm_identity", vm["id"] == "v02-i4b-benign-isolation-lab-01")
check("sibling_topology", vm["topology"] == "SIBLING_VM_NOT_NESTED_IN_KALI")
check("resource_binding", (vm["vcpus"], vm["memory_bytes"], vm["disk_bytes"]) == (4, 6 * 1024**3, 64 * 1024**3))
check("d_volume", vm["storage_volume"] == "D:")
check("future_storage_guard", guards["minimum_d_free_gib_before_provisioning"] == 72)
check("future_memory_guard", guards["minimum_available_ram_gib_before_start"] == 8)
check("future_kali_guard", guards["kali_power_state_before_start"] == "POWERED_OFF")
check("nested_forbidden", guards["nested_virtualization"] == "FORBIDDEN")

check("windows_hypervisor_observed", compat["observed"]["windows_hypervisor_detected"] is True)
check("vbs_preserved", compat["observed"]["vbs_status"] == 2 and compat["observed"]["security_services_running"] == [2])
check("no_security_weakening", compat["decision"] == "DO_NOT_DISABLE_OR_MODIFY_WINDOWS_SECURITY_FEATURES")
check("new_vm_compatibility_unobserved", compat["actual_new_vm_boot_compatibility"] == "NOT_EVALUATED")
check("runtime_compatibility_unobserved", compat["runtime_isolation"] == "NOT_EVALUATED")

check("cpu_feasible", resources["cpu"]["result"] == "PASS" and resources["cpu"]["fraction"] == 0.25)
check("current_memory_guard_fails", resources["memory"]["observed_available_gib_with_kali_running"] == 2 and resources["memory"]["current_start_guard"].startswith("FAIL"))
check("memory_guard_is_future", resources["memory"]["governance_result"] == "PASS_AS_FUTURE_PRE_START_GUARD")
check("storage_feasible", resources["storage"]["observed_free_gib"] == 119.14 and resources["storage"]["result"] == "PASS")
check("storage_arithmetic", abs(resources["storage"]["expected_remaining_gib_at_full_virtual_disk_allocation"] - 55.14) < 0.001)
check("resource_no_authority", resources["authorization_effect"] == "NONE")

check("image_source", image["source"] == "https://releases.ubuntu.com/24.04/ubuntu-24.04.5-live-server-amd64.iso")
check("image_checksum_source", image["checksum_source"] == "https://releases.ubuntu.com/24.04/SHA256SUMS")
check("image_filename", image["filename"] == "ubuntu-24.04.5-live-server-amd64.iso")
check("image_length", image["expected_byte_length"] == 4080486400)
check("image_sha", image["expected_sha256"] == "97f3d7ffb032c3eb3b23d2c8be9cc76e60c2c1f2c0146ba5ba9fe01cafae0fd8")
check("image_publisher_metadata", image["publisher_metadata_cross_check"] == "PASS")
check("image_local_absent", image["local_image_exists"] is False)
check("image_bytes_unverified", image["local_byte_length_verified"] is False and image["local_sha256_verified"] is False)
check("image_acquisition_denied", image["image_acquisition_authorized"] is False)

check("zero_nic", security["network"]["adapter_count"] == 0)
check("all_network_modes_forbidden", all(value == "FORBIDDEN" for value in security["network"]["nic_modes"].values()))
check("no_network_protocol", all(security["network"][name] == "NO_INTERFACE" for name in ("ipv4", "ipv6", "dns")))
check("no_host_shares", security["host_integrations"]["shared_folders"] == "NONE")
check("no_clipboard_dnd", security["host_integrations"]["shared_clipboard"] == "DISABLED" and security["host_integrations"]["drag_and_drop"] == "DISABLED")
check("no_guest_additions", security["host_integrations"]["guest_additions"] == "NOT_INSTALLED_BY_DEFAULT")
check("no_usb_or_passthrough", security["host_integrations"]["usb_controllers"] == "DISABLED" and security["host_integrations"]["device_passthrough"] == "NONE")
check("credentials_forbidden", all(value == "FORBIDDEN" for value in security["credentials"].values()))
check("config_not_applied", security["status"] == "COMPLETE_PROPOSAL_NOT_APPLIED" and security["authorization_effect"] == "NONE")

check("bootstrap_offline", bootstrap["constraints"]["virtual_nics"] == 0 and bootstrap["constraints"]["online_package_installation"] == "FORBIDDEN")
check("bootstrap_separate_authority", bootstrap["trusted_bootstrap_material"]["execution"] == "not authorized by this decision")
check("bootstrap_fail_closed", "BLOCKED_NOT_ESTABLISHED" in bootstrap["guest_prerequisite_policy"][2])
check("transfer_no_integrations", not any(transfer["inbound"][name] for name in ("shared_folder", "clipboard", "guest_agent", "network")))
check("transfer_detach_before_parse", "fully power off the VM" in transfer["outbound"]["lifecycle"] and "detach the disk before host-side inspection" in transfer["outbound"]["lifecycle"])
check("transfer_not_authorized", transfer["current_authorization"].startswith("NOT_GRANTED"))

check("matrix_count", matrix["operation_count"] == len(matrix["operations"]) == 13)
check("matrix_all_denied", matrix["authorized_count"] == 0 and matrix["not_authorized_count"] == 13 and all(row["decision"] == "NOT_AUTHORIZED" for row in matrix["operations"]))
check("no_authorization_artifact", matrix["authorization_artifact_permitted"] is False)
check("readiness_count", readiness["summary"]["total"] == len(readiness["checks"]) == 18)
check("readiness_ids", [row["id"] for row in readiness["checks"]] == [f"P{x}" for x in range(1, 19)])
check("readiness_derived", readiness["summary"]["passed"] == 17 and readiness["summary"]["blocked"] == 1)
check("sole_blocker", [row["id"] for row in readiness["checks"] if row["result"] == "BLOCKED"] == ["P5"])
check("readiness_not_authorized", readiness["summary"]["authorization_ready"] is False and readiness["status"] == "BLOCKED")
check("post_contract_count", len(post["requirements"]) == 24 and [row["id"] for row in post["requirements"]] == [f"H{x}" for x in range(1, 25)])
check("post_contract_not_execution", post["decision_semantics"]["runtime_isolation"] == "NOT_EVALUATED" and post["decision_semantics"]["i4_b_execution"] == "NOT_AUTHORIZED_BY_THIS_CONTRACT")

check("official_docs_count", len(docs["sources"]) == 5)
check("docs_not_product_network", docs["network_activity_classification"].startswith("DEVELOPER_") and docs["product_network_activity"] == 0)
threat_fields = {"id", "threat", "boundary", "condition", "mitigation", "verification", "fail_closed"}
check("threat_count", threats["threat_count"] == len(threats["threats"]) == 26)
check("threat_unique", len({row["id"] for row in threats["threats"]}) == 26)
check("threat_complete", all(threat_fields <= set(row) for row in threats["threats"]))
check("threat_fail_closed", all(row["fail_closed"] for row in threats["threats"]))
threat_text = json.dumps(threats["threats"]).lower()
for term in ("hyper-v", "vbs", "nat", "ipv6", "credential", "cgroup", "landlock", "seccomp", "router"):
    check(f"threat_covers_{term}", term in threat_text)
check("risk_count", risks["risk_count"] == len(risks["risks"]) == 14)
check("risk_unique", len({row["id"] for row in risks["risks"]}) == 14)
check("hard_blocker_preserved", any(row["id"] == "R01" and row["state"] == "HARD_BLOCKER" and row["blocks_authorization"] for row in risks["risks"]))
check("router_open", risks["router"]["status"] == "OPEN" and risks["router"]["router_dependent_paths"] == "BLOCKED")


def can_authorize(record: dict[str, object]) -> bool:
    return (
        record.get("explicit_owner_authority") is True
        and record.get("host") == "lab-host-01"
        and record.get("hypervisor") == "7.2.16.174877"
        and record.get("vm") == "v02-i4b-benign-isolation-lab-01"
        and record.get("disk_free_gib", 0) >= 72
        and record.get("future_ram_guard_gib") == 8
        and record.get("kali_off_guard") is True
        and record.get("vbs_policy") == "UNCHANGED"
        and record.get("image_source") == image["source"]
        and record.get("image_sha") == image["expected_sha256"]
        and record.get("image_bytes_verified") is False
        and record.get("network") == "ZERO_NIC"
        and record.get("integrations") == "DISABLED"
        and record.get("cgroup_plan") is True
        and record.get("offline_bootstrap") is True
        and record.get("evidence_transfer") is True
        and record.get("recovery") is True
        and record.get("vm_boot_requested") is False
        and record.get("i4b_requested") is False
        and record.get("later_milestone_requested") is False
        and record.get("router_required") is False
    )


synthetic = {
    "explicit_owner_authority": True,
    "host": "lab-host-01",
    "hypervisor": "7.2.16.174877",
    "vm": "v02-i4b-benign-isolation-lab-01",
    "disk_free_gib": 119.14,
    "future_ram_guard_gib": 8,
    "kali_off_guard": True,
    "vbs_policy": "UNCHANGED",
    "image_source": image["source"],
    "image_sha": image["expected_sha256"],
    "image_bytes_verified": False,
    "network": "ZERO_NIC",
    "integrations": "DISABLED",
    "cgroup_plan": True,
    "offline_bootstrap": True,
    "evidence_transfer": True,
    "recovery": True,
    "vm_boot_requested": False,
    "i4b_requested": False,
    "later_milestone_requested": False,
    "router_required": False,
}
check("synthetic_complete_record", can_authorize(synthetic))
mutations = {
    "missing_provisioning_authority": ("explicit_owner_authority", False),
    "changed_host_alias": ("host", "other-host"),
    "changed_hypervisor_version": ("hypervisor", "different"),
    "changed_vm_identity": ("vm", "different"),
    "insufficient_d_capacity": ("disk_free_gib", 71.99),
    "wrong_ram_guard": ("future_ram_guard_gib", 7),
    "kali_not_off": ("kali_off_guard", False),
    "unknown_vbs": ("vbs_policy", "UNKNOWN"),
    "forbidden_security_change": ("vbs_policy", "DISABLE"),
    "incorrect_iso_checksum": ("image_sha", "0" * 64),
    "image_bytes_false_claim": ("image_bytes_verified", True),
    "invalid_image_source": ("image_source", "https://example.invalid/image.iso"),
    "default_nat": ("network", "NAT"),
    "shared_folder": ("integrations", "SHARED_FOLDER"),
    "clipboard": ("integrations", "CLIPBOARD"),
    "guest_agent": ("integrations", "GUEST_AGENT"),
    "device_passthrough": ("integrations", "PASSTHROUGH"),
    "missing_cgroup_plan": ("cgroup_plan", False),
    "impossible_offline_bootstrap": ("offline_bootstrap", False),
    "missing_evidence_transfer": ("evidence_transfer", False),
    "missing_recovery": ("recovery", False),
    "unauthorized_vm_boot": ("vm_boot_requested", True),
    "unauthorized_i4b": ("i4b_requested", True),
    "unauthorized_i5_v03": ("later_milestone_requested", True),
    "router_dependency": ("router_required", True),
}
for label, (field, value) in mutations.items():
    candidate = copy.deepcopy(synthetic)
    candidate[field] = value
    check(f"reject_{label}", not can_authorize(candidate))

current = copy.deepcopy(synthetic)
current["explicit_owner_authority"] = False
check("actual_record_denied", not can_authorize(current))

for forbidden in (
    "PROVISIONING_AUTHORIZATION.json",
    "I4_B_AUTHORIZATION.json",
    "HOST_EXECUTION_SEAL.json",
    "RUNTIME_RESULT.json",
):
    check(f"forbidden_artifact_absent_{forbidden}", not (HERE / forbidden).exists())

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": IDENTITY,
    "validator": "i4b_provisioning_v2_governance_self_test_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
