#!/usr/bin/env python3
"""Independent structural validator for the I4-B provisioning V2 decision."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT.parent / "v0.2-i4-b-candidate-platform-selection-evidence-decision-v1-20261010"
IDENTITY = "V0.2_I4_B_DEDICATED_ENVIRONMENT_PROVISIONING_GOVERNANCE_V2"
BASELINES = [
    (Path("/home/nobcoder/v0.2-experimental-research-engine"), "governance/i0/SOURCE_MANIFEST.json", "1a14d9c6dca921016acb79831e531308480fa9876e62ded6e1976b51ccbc311c"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i1"), "governance/i1/SOURCE_MANIFEST.json", "be1c40bb8c499672afe8e411dbb235060f1d0666931cdd3282d9a2ae4e3c651b"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i2"), "governance/i2/SOURCE_MANIFEST.json", "bb4abb8d766987a65a96205acca6c74ff2200551d8c925086431e0f27d0ee129"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i3"), "governance/i3/SOURCE_MANIFEST.json", "711d9b026870ff55135c5534f88bfc394d7734ee9943a8063baa189ac270c83e"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i4"), "governance/i4a/SOURCE_MANIFEST.json", "138fd2e59526a663486f54b263b8167283e1736a54fbceb777c7a73dbe02ac34"),
]


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_ok(root: Path, manifest_relative: str, expected: str) -> bool:
    manifest = json.loads((root / manifest_relative).read_text(encoding="utf-8"))
    ledger = bytearray()
    for record in sorted(manifest["files"], key=lambda value: value["path"]):
        path = root / record["path"]
        if not path.is_file() or path.is_symlink() or sha(path) != record["sha256"]:
            return False
        ledger.extend(f"{record['sha256']}  {record['path']}\n".encode())
    return hashlib.sha256(bytes(ledger)).hexdigest() == expected == manifest["source_tree_sha256"]


def governance_root(path: Path, excluded: str = "GOVERNANCE_LOCK.json") -> str:
    records = [
        f"{sha(item)}  {item.name}"
        for item in sorted(path.iterdir(), key=lambda value: value.name)
        if item.is_file() and not item.is_symlink() and item.name != excluded
    ]
    return hashlib.sha256(("\n".join(records) + "\n").encode()).hexdigest()


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


p = load("GOVERNANCE_GATE_PROTOCOL.json")
f = load("PREFLIGHT_RESULT.json")
a = load("PROVISIONING_AUTHORITY_ASSESSMENT.json")
d = load("PROVISIONING_DECISION.json")
h = load("HOST_PLATFORM_BINDING.json")
c = load("HYPERVISOR_COMPATIBILITY_RESULT.json")
r = load("RESOURCE_FEASIBILITY.json")
i = load("GUEST_IMAGE_BINDING.json")
s = load("VM_SECURITY_CONFIGURATION.json")
b = load("OFFLINE_BOOTSTRAP_PLAN.json")
e = load("EVIDENCE_TRANSFER_PLAN.json")
m = load("OPERATION_AUTHORIZATION_MATRIX.json")
q = load("PRE_PROVISION_READINESS.json")
v = load("POST_PROVISION_VALIDATION_CONTRACT.json")
t = load("PROVISIONING_THREAT_MODEL.json")
k = load("RISK_REGISTER.json")

check("identity_chain", p["gate_id"] == d["gate_id"] == IDENTITY)
check("preflight_boundary", f["result"] == "SAFE_TO_CREATE_V2_GOVERNANCE_DECISION_ARTIFACTS_ONLY")
check("candidate_lock_bytes", sha(CANDIDATE / "GOVERNANCE_LOCK.json") == "66cc7168e8799b373d41eb8e7e4d55efbd7d6801803cabfac887c69eb4320a3f")
check("candidate_manifest_bytes", sha(CANDIDATE / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "c160f641582e7535ff2ef921065dfc9eb15a885c66861eea51d28049adf68ea0")
check("candidate_root_recomputed", governance_root(CANDIDATE) == "a420d5d39a4330d24500f4e437b0bc337b2803bf3ba7ef605f7898f5b82be0dc")
old_lock = json.loads((CANDIDATE / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8"))
old_auth = json.loads((CANDIDATE / "HOST_AUTHORIZATION_EVIDENCE.json").read_text(encoding="utf-8"))
check("event_chain", old_lock["required_next_event"].endswith("_V2"))
check("source_roots_recomputed", all(tree_ok(*entry) for entry in BASELINES))
check("selection_authority_limited", old_auth["authorization_effect"] == "NONE" and old_auth["provisioning_authorization"] == "NOT_GRANTED")
check("no_authority_inference", a["available_attestation"]["authorization_effect"] == "NONE" and a["decision_effect"] == "BLOCKS_PROVISIONING_AUTHORIZATION")

check("blocked_decision_consistency", d["decision"].endswith("AUTHORIZATION_BLOCKED") and d["provisioning_authorization"] == "NOT_GRANTED" and d["approved_provisioning_scope"] == "NONE")
check("all_operations_denied", len(m["operations"]) == 13 and not any(row["decision"] == "AUTHORIZED" for row in m["operations"]))
check("authorization_artifact_forbidden", not m["authorization_artifact_permitted"] and not (ROOT / "PROVISIONING_AUTHORIZATION.json").exists())
check("no_runtime_grants", d["vm_startup"] == "NOT_AUTHORIZED" and d["i4_b_execution_authorization"] == "NOT_GRANTED" and d["actual_runtime_isolation"] == "NOT_EVALUATED")
check("later_milestones_closed", d["i5"] == "NOT_AUTHORIZED" and d["v0_3"] == "NOT_OPENED")

check("host_binding_exact", h["host"]["alias"] == "lab-host-01" and h["hypervisor"]["version"] == "7.2.16.174877")
check("vm_binding_exact", (h["vm"]["id"], h["vm"]["vcpus"], h["vm"]["memory_bytes"], h["vm"]["disk_bytes"]) == ("v02-i4b-benign-isolation-lab-01", 4, 6442450944, 68719476736))
check("sibling_not_nested", h["vm"]["topology"] == "SIBLING_VM_NOT_NESTED_IN_KALI" and h["guards"]["nested_virtualization"] == "FORBIDDEN")
check("storage_math", r["storage"]["observed_free_gib"] >= r["storage"]["minimum_required_free_gib_before_provisioning"] and abs(r["storage"]["observed_free_gib"] - 64 - r["storage"]["expected_remaining_gib_at_full_virtual_disk_allocation"]) < 0.001)
check("memory_state_truthful", r["memory"]["observed_available_gib_with_kali_running"] < r["memory"]["minimum_available_gib_before_future_start"] and r["memory"]["current_start_guard"].startswith("FAIL"))
check("future_start_guards", h["guards"]["minimum_available_ram_gib_before_start"] == 8 and h["guards"]["kali_power_state_before_start"] == "POWERED_OFF")

check("vbs_not_hidden", c["observed"]["windows_hypervisor_detected"] and c["observed"]["vbs_status"] == 2)
check("security_change_denied", c["decision"] == "DO_NOT_DISABLE_OR_MODIFY_WINDOWS_SECURITY_FEATURES")
check("compatibility_not_overclaimed", c["actual_new_vm_boot_compatibility"] == "NOT_EVALUATED")
check("image_metadata_exact", (i["filename"], i["expected_byte_length"], i["expected_sha256"]) == ("ubuntu-24.04.5-live-server-amd64.iso", 4080486400, "97f3d7ffb032c3eb3b23d2c8be9cc76e60c2c1f2c0146ba5ba9fe01cafae0fd8"))
check("image_not_locally_verified", not i["local_image_exists"] and not i["local_byte_length_verified"] and not i["local_sha256_verified"])
check("image_acquisition_denied", not i["image_acquisition_authorized"])

check("zero_nic_policy", s["network"]["adapter_count"] == 0 and all(value == "FORBIDDEN" for value in s["network"]["nic_modes"].values()))
check("integration_denial", s["host_integrations"]["shared_folders"] == "NONE" and s["host_integrations"]["shared_clipboard"] == "DISABLED" and s["host_integrations"]["guest_additions"] == "NOT_INSTALLED_BY_DEFAULT")
check("credential_denial", all(value == "FORBIDDEN" for value in s["credentials"].values()))
check("configuration_only", s["authorization_effect"] == "NONE" and s["status"].endswith("NOT_APPLIED"))
check("offline_install_no_workaround", b["constraints"]["virtual_nics"] == 0 and b["constraints"]["online_package_installation"] == "FORBIDDEN")
check("bootstrap_requires_later_authority", b["current_authorization_effect"] == "NONE" and "later" in b["feasibility"].lower())
check("evidence_channel_detached", not e["outbound"]["simultaneous_host_guest_mount"] and not e["outbound"]["direct_host_filesystem_access_from_guest"])
check("evidence_channel_not_granted", e["current_authorization"].startswith("NOT_GRANTED"))

blocked = [row["id"] for row in q["checks"] if row["result"] != "PASS"]
check("readiness_counts_derived", q["summary"]["total"] == 18 and q["summary"]["passed"] == 17 and q["summary"]["blocked"] == 1)
check("readiness_singular_blocker", blocked == ["P5"] and q["summary"]["sole_mandatory_blocker"].startswith("P5_"))
check("not_conditionally_waived", q["summary"]["authorization_requires"] == "18_OF_18_PASS" and not q["summary"]["authorization_ready"])
check("post_contract_complete", len(v["requirements"]) == 24 and {row["id"] for row in v["requirements"]} == {f"H{x}" for x in range(1, 25)})
check("post_is_not_runtime", v["decision_semantics"]["runtime_isolation"] == "NOT_EVALUATED")

threat_text = json.dumps(t["threats"]).lower()
check("threat_model_count", t["threat_count"] == len(t["threats"]) == 26)
check("threat_model_unique", len({row["id"] for row in t["threats"]}) == 26)
check("threat_model_fail_closed", all(row["fail_closed"] for row in t["threats"]))
check("threat_model_scope", all(term in threat_text for term in ("unauthorized provisioning", "hyper-v", "vbs", "nat", "ipv6", "cgroup", "seccomp", "landlock", "evidence export")))
check("risk_register_count", k["risk_count"] == len(k["risks"]) == 14)
check("hard_block_matches_decision", [row["id"] for row in k["risks"] if row.get("blocks_authorization")] == ["R01"])
check("router_risk_preserved", k["router"]["status"] == "OPEN" and k["router"]["router_dependent_paths"] == "BLOCKED")

for forbidden in ("PROVISIONING_AUTHORIZATION.json", "I4_B_AUTHORIZATION.json", "HOST_EXECUTION_SEAL.json", "RUNTIME_RESULT.json"):
    check(f"absent_{forbidden}", not (ROOT / forbidden).exists())

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": IDENTITY,
    "validator": "independent_i4b_provisioning_v2_structural_validator_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
