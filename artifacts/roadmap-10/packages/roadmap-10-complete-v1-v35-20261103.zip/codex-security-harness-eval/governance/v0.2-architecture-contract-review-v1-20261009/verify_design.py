#!/usr/bin/env python3
"""Read-only design verifier for V0.2 architecture contract review V1."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
GOVERNANCE_LOCK = ROOT / "governance/v0.2-experimental-research-initiative-governance-v1-20261009/GOVERNANCE_LOCK.json"
EXPECTED_GOVERNANCE_SHA = "635b24216ca6008907065095b6d694efeda53d9daaa872895d081c5dd1cdba91"


def load(name: str) -> dict:
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(rows: list[dict], label: str, condition: bool) -> None:
    rows.append({"check": label, "result": "PASS" if condition else "FAIL"})


def main() -> int:
    protocol = load("ARCHITECTURE_REVIEW_PROTOCOL.json")
    threat = load("THREAT_MODEL.json")
    gym = load("GYM_KERNEL_SPEC.json")
    schemas = load("BOUNDARY_SCHEMA_SET.json")
    evaluation = load("EVALUATION_CONTRACT.json")
    acceptance = load("ACCEPTANCE_PLAN.json")
    decision = load("DESIGN_REVIEW_DECISION.json")
    governance = json.loads(GOVERNANCE_LOCK.read_text(encoding="utf-8"))
    architecture = (HERE / "ARCHITECTURE_SPEC.md").read_text(encoding="utf-8")

    rows: list[dict] = []
    check(rows, "governance digest", sha256(GOVERNANCE_LOCK) == EXPECTED_GOVERNANCE_SHA)
    check(rows, "governance design-only authorization", governance.get("status") == "PASS_LOCKED_DESIGN_ONLY")
    check(rows, "review identity", protocol.get("review_id") == "V0.2_ARCHITECTURE_CONTRACT_REVIEW_V1")
    check(rows, "required design artifacts", all((HERE / name).is_file() for name in protocol["required_artifacts"]))
    check(rows, "single initial target class", protocol["review_rules"].get("one_initial_target_class") is True)
    check(rows, "network disabled", protocol["review_rules"].get("network_disabled") is True)
    check(rows, "ground truth withheld", protocol["review_rules"].get("ground_truth_worker_visible") is False)
    check(rows, "deterministic verifier", protocol["review_rules"].get("deterministic_verifier_required") is True and gym["components"]["private_verifier"].get("model_prose_is_grader") is False)
    check(rows, "three fixture control classes", gym["initial_suite"]["case_count"] == 8 and sum(gym["initial_suite"]["composition"].values()) == 8)
    check(rows, "sandbox execution remains blocked", gym["components"]["sandbox_executor"].get("status") == "IMPLEMENTATION_BLOCKED_PENDING_CONTAINMENT_READINESS")
    check(rows, "six trust boundaries", len(threat.get("trust_boundaries", [])) >= 6)
    check(rows, "boundary schema definitions", all(name in schemas["$defs"] for name in ("target_capsule", "trajectory_event", "evidence_submission", "verifier_result", "run_result")))
    check(rows, "acceptance no retry", evaluation["trial_policy"].get("retry") == 0 and evaluation["trial_policy"].get("replacement") == 0)
    check(rows, "false-positive gate", evaluation["development_acceptance"].get("false_report_ready_on_patched_or_decoy") == "0_OF_4")
    check(rows, "measurement before scoring", evaluation["failure_rule"].get("measurement_invalid") == "MEASUREMENT_INCOMPLETE_NEVER_SCORE")
    check(rows, "implementation gate first", acceptance["ordered_gates"][0].get("gate") == "IMPLEMENTATION_GOVERNANCE" and acceptance["ordered_gates"][0].get("current_status") == "NOT_AUTHORIZED")
    check(rows, "no automatic progression", acceptance.get("automatic_progression") is False)
    check(rows, "single-worker no-swarm architecture", "Single Research Worker" in architecture and "V0.2 does not use a swarm" in architecture)
    check(rows, "implementation denied by review", decision.get("V0.2_implementation") == "NOT_AUTHORIZED")
    check(rows, "source autonomy unopened", decision.get("V0.3_Source_Autonomy") == "NOT_OPENED")
    check(rows, "zero execution", all(decision.get(key) == 0 for key in ("model_invocations", "network_activity", "product_writes", "subject_artifact_writes")))

    passed = sum(row["result"] == "PASS" for row in rows)
    result = {
        "schema_version": 1,
        "review_id": protocol["review_id"],
        "status": "PASS" if passed == len(rows) else "FAIL",
        "passed": passed,
        "total": len(rows),
        "checks": rows,
    }
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
