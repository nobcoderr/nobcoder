# V0.2 Experimental Research Engine Architecture

## Objective and boundary

V0.2 is a bounded experimental source-research engine, not a general autonomous
security researcher. Its first supported target is one immutable local source
repository fixture with an explicit authorization/scope manifest. It cannot use
live targets or network access. It does not inherit V0.1 acceptance, scheduling,
or capacity claims.

The engine must produce either evidence that survives an independent verifier
or an honest `NO_VALID_FINDING`. A successful pipeline run is not itself proof
of autonomy.

## Planes

### Governance and control plane

- **Scope Validator** binds the target digest, authorization, allowed methods,
  resource limits, and prohibited actions before a run can be sealed.
- **Run Controller** owns the state machine, execution seal, deadlines, budget,
  lifecycle journal, cleanup, and fail-closed terminalization.
- **Action Broker** exposes a narrow typed action space. V0.2 design supports
  read/search plus allowlisted local build/test commands inside a future OS
  sandbox; candidate execution remains denied until containment readiness passes.

### Research plane

- **Single Research Worker** performs bounded observe, hypothesize, falsify, and
  test-design steps. V0.2 does not use a swarm.
- **Candidate Registry** stores candidate identity, lineage, claim, falsifier,
  evidence references, and monotonic state.
- **Trajectory Store** appends every action and observation with content digests,
  resource deltas, and candidate links.

### Verification plane

- **Evidence Freezer** seals the worker-visible trajectory and evidence before
  ground-truth access.
- **Private Verifier** receives the frozen submission and verifier-only oracle.
  It never receives or trusts researcher severity or persuasive prose as proof.
- **Evaluation Engine** computes measurement validity and metrics through
  deterministic rules. Human review remains required before any external
  security report is treated as report-ready.

### Gym-kernel plane

- **Target Registry** identifies each vulnerable, patched, or negative fixture.
- **Sandbox Executor** is a future implementation boundary, not supplied by this
  review. It must prove network denial, filesystem isolation, resource limits,
  and process cleanup before candidate execution is enabled.
- **Reset Controller** restores a fixture to its content-addressed baseline and
  attests cleanup between runs.

## Authoritative run state machine

```text
PLANNED
  -> PRECHECKED
  -> SEALED
  -> SANDBOX_READY
  -> RUNNING
  -> RESEARCH_TERMINAL
  -> EVIDENCE_FROZEN
  -> VERIFIED
  -> SCORED
  -> FINALIZED
```

Any identity, schema, scope, isolation, lifecycle, evidence, or observation
failure transitions to a typed invalid terminal state. Invalid runs are never
scored. Acceptance runs have no retry or replacement.

## Candidate states

```text
HYPOTHESIS
  -> TEST_DESIGNED
  -> TESTED
  -> EVIDENCE_BOUND
  -> REPRODUCED
  -> REPORT_READY

Any nonterminal state may transition to KILL_* or BLOCKED_*.
```

States are monotonic. `REPORT_READY` requires deterministic verifier success;
model agreement is not evidence. A clean run with no report-ready candidates
ends `NO_VALID_FINDING`. A run with unresolved operational or measurement state
does not become a successful terminal merely because execution stopped.

## Action and observation contracts

Actions use stable names and narrow typed inputs. No catch-all shell interface
is part of the initial contract. Future implementation may expose allowlisted
commands only through the sandbox boundary.

Every observation contains:

- `status`: `success`, `warning`, or `error`;
- `summary`: a bounded machine-readable description;
- `next_actions`: legal transitions, never an authorization grant;
- `artifacts`: content-addressed references;
- provenance, resource delta, and lifecycle sequence.

## Context and recovery

Large source material remains in immutable artifacts and is referenced by
digest. Compaction occurs only at phase boundaries. Errors declare a root-cause
class, safe continuation if one exists, and a stop condition. Hidden retry,
replacement, repair-agent, and silent rescore paths are forbidden.

## Explicit non-goals

V0.2 does not support live bug-bounty targets, binary/mobile/web autonomy,
cross-surface chains, multi-agent swarms, post-training, self-modification, or
automatic public reporting. Those require later governance identities.
