#!/usr/bin/env python3
"""Primary and mutation validation for first-worker invocation authorization."""

from __future__ import annotations

import ast
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IDENTITY = "AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_CONDITIONALLY"
FUTURE = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v1-20261020")
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_LOCK_BINDINGS.json",
    "FIRST_WORKER_INVOCATION_AUTHORIZATION_DECISION.json", "MINIMAL_ONE_SHOT_TOPOLOGY.json",
    "RUNTIME_AND_TRANSPORT_BOUNDARY.json", "STRUCTURED_IO_AND_QUARANTINE_REQUIREMENTS.json",
    "WORKSPACE_AND_CONFINEMENT_REQUIREMENTS.json", "PRE_ATTEMPT_GATE_REQUIREMENTS.json",
    "POST_VALIDATION_AND_EVIDENCE_REQUIREMENTS.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "ATTEMPT_AND_COUNTER_INITIAL_STATE.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
    "PRE_FREEZE_VALIDATION_TOOL_ABORT_DISPOSITION.json",
}
SCRIPTS = {"validate_governance.py", "independent_validate.py", "finalize_governance.py", "final_freeze_verify.py"}
EXPECTED_PREDECESSORS = {
    "RUNTIME_SUBSTRATE_V5": "8383ec457c0838fba668693ae9c837edf1a8c50222c524176dc60b9afda9191e",
    "CODEX_RUNTIME_0_163_0": "3aedf0a656fd12680311f07fcf01e911e7a6a62f0b81871af347a55bc1ba7fef",
    "SECURITY_WORKER_RUNTIME_V1": "cc7928e67b9d5c74f04a750d8faae5bbdf97f2dd7fd4337885ddf10f85d6e8f7",
    "CONTROL_PLANE_V2": "54e61cc5186ee5620a9d5116e4fa2650affef6e7919ca594ecd3921ff9671e2f",
    "FIXTURE_RUNNER_V2": "14ebdff93e45f275f14b1c6be6594bdbbf7d69921edb56e89329337e16bd2da4",
}


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def accepted(bundle: dict[str, dict[str, Any]]) -> bool:
    bindings = bundle["PREDECESSOR_LOCK_BINDINGS.json"].get("bindings", [])
    binding_map = {item.get("identity"): item for item in bindings}
    topology = bundle["MINIMAL_ONE_SHOT_TOPOLOGY.json"]
    runtime = bundle["RUNTIME_AND_TRANSPORT_BOUNDARY.json"]
    io = bundle["STRUCTURED_IO_AND_QUARANTINE_REQUIREMENTS.json"]
    workspace = bundle["WORKSPACE_AND_CONFINEMENT_REQUIREMENTS.json"]
    pre = bundle["PRE_ATTEMPT_GATE_REQUIREMENTS.json"]
    post = bundle["POST_VALIDATION_AND_EVIDENCE_REQUIREMENTS.json"]
    operations = bundle["OPERATION_AUTHORIZATION_MATRIX.json"]
    initial = bundle["ATTEMPT_AND_COUNTER_INITIAL_STATE.json"]
    authority = bundle["AUTHORITY_NON_ESCALATION_DECISION.json"]
    decision = bundle["FIRST_WORKER_INVOCATION_AUTHORIZATION_DECISION.json"]
    return all(
        [
            set(binding_map) == set(EXPECTED_PREDECESSORS),
            all(binding_map.get(name, {}).get("lock_sha256") == digest for name, digest in EXPECTED_PREDECESSORS.items()),
            all("PASS_LOCKED" in binding_map.get(name, {}).get("status", "") for name in EXPECTED_PREDECESSORS),
            decision.get("decision") == DECISION,
            decision.get("one_shot_attempt") == "0_OF_1_NOT_CONSUMED",
            decision.get("worker_invocation_count") == 0,
            decision.get("codex_as_worker_invocation_count") == 0,
            topology.get("campaign_count") == 1,
            topology.get("lane_count") == 1,
            topology.get("worker_identity_count") == 1,
            topology.get("codex_runtime_count") == 1,
            topology.get("worker_invocation_limit") == 1,
            topology.get("scheduling") == "SERIAL_ONLY",
            topology.get("workspace_kind") == "CONTROLLED_LOCAL_FIXTURE",
            runtime.get("version") == "0.163.0",
            runtime.get("binary_sha256") == "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215",
            runtime.get("compatibility_state") == "PASS_LOCKED",
            runtime.get("worker_external_network") == "DENY_ALL",
            runtime.get("target_network_access") is False,
            io.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED",
            io.get("output_authority") == "PROPOSAL_ONLY_NON_AUTHORITATIVE",
            io.get("worker_self_authorization") == "PERMANENTLY_PROHIBITED",
            io.get("worker_self_promotion") == "PERMANENTLY_PROHIBITED",
            workspace.get("workspace_kind", "CONTROLLED_LOCAL_FIXTURE") == "CONTROLLED_LOCAL_FIXTURE",
            workspace.get("target_material_available") is False,
            workspace.get("secrets_available") is False,
            workspace.get("network_mode") == "DENY_ALL_TO_WORKER",
            workspace.get("credential_mode") == "DENY_ALL",
            workspace.get("unsandboxed_fallback") == "PROHIBITED",
            pre.get("attempt_marker_rule") == "CREATE_ONLY_AFTER_ALL_PRE_ATTEMPT_GATES_PASS",
            len(pre.get("gates", [])) == 15,
            pre.get("on_failure") == "STOP_FAIL_CLOSED_ATTEMPT_REMAINS_0_OF_1",
            post.get("one_shot_no_automatic_retry") is True,
            post.get("independent_post_validation_required") is True,
            post.get("evidence_freeze_required") is True,
            post.get("separate_acceptance_adjudication_required") is True,
            operations.get("authorized_future_operation") == {"codex_as_worker_invocations": 1, "security_worker_invocations": 1},
            set(operations.get("not_authorized", [])) == {
                "SUBAGENT_INVOCATION", "CREDENTIAL_INJECTION", "TARGET_ACCESS", "WORKER_EXTERNAL_NETWORK",
                "DAYBREAK_INVOCATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH",
                "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION",
            },
            initial.get("attempt_count") == 0 and initial.get("attempt_limit") == 1,
            initial.get("worker_invocation_count") == 0 and initial.get("codex_as_worker_invocation_count") == 0,
            all(value == 0 for value in initial.get("operation_counters", {}).values()),
            authority.get("first_worker_invocation_authorized_conditionally") is True,
            all(authority.get(key) is False for key in (
                "target_access_authorized", "credential_use_authorized", "subagent_authorized",
                "external_network_authorized", "daybreak_invocation_authorized", "exploit_replay_authorized",
                "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized",
                "submission_automation_authorized",
            )),
        ]
    )


def write_once(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> int:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    historical = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"}
    if actual != BASE | SCRIPTS | historical:
        raise SystemExit(f"governance input set mismatch: {sorted(actual)}")
    docs = {name: read(ROOT / name) for name in BASE}
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": name, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"))
            valid = True
        except SyntaxError:
            valid = False
        check("SCRIPT_SYNTAX_" + script, valid)
    check("P001_IDENTITY_EXACT", all(doc.get("governance_identity") == IDENTITY for doc in docs.values()))
    bindings = docs["PREDECESSOR_LOCK_BINDINGS.json"]["bindings"]
    check("P002_FIVE_PREDECESSORS", len(bindings) == 5)
    for item in bindings:
        path = Path(item["lock_path"])
        check("P_LOCK_EXISTS_" + item["identity"], path.is_file())
        check("P_LOCK_HASH_" + item["identity"], path.is_file() and sha256(path) == item["lock_sha256"])
        if path.is_file():
            lock = read(path)
            check("P_LOCK_STATUS_" + item["identity"], "PASS_LOCKED" in str(lock.get("status", "")) or "PASS_LOCKED" in str(lock))
    check("P018_FUTURE_WORKSPACE_ABSENT", not FUTURE.exists())
    check("P019_DECISION_EXACT", docs["FIRST_WORKER_INVOCATION_AUTHORIZATION_DECISION.json"].get("decision") == DECISION)
    check("P020_ATTEMPT_ZERO", docs["ATTEMPT_AND_COUNTER_INITIAL_STATE.json"].get("attempt_count") == 0)
    check("P021_WORKER_INVOCATION_ZERO", docs["ATTEMPT_AND_COUNTER_INITIAL_STATE.json"].get("worker_invocation_count") == 0)
    check("P022_CODEX_WORKER_INVOCATION_ZERO", docs["ATTEMPT_AND_COUNTER_INITIAL_STATE.json"].get("codex_as_worker_invocation_count") == 0)
    check("P023_OPERATION_COUNTERS_ZERO", all(value == 0 for value in docs["ATTEMPT_AND_COUNTER_INITIAL_STATE.json"].get("operation_counters", {}).values()))
    topology = docs["MINIMAL_ONE_SHOT_TOPOLOGY.json"]
    check("P024_ONE_CAMPAIGN", topology.get("campaign_count") == 1)
    check("P025_ONE_LANE", topology.get("lane_count") == 1)
    check("P026_ONE_WORKER", topology.get("worker_identity_count") == 1)
    check("P027_SERIAL", topology.get("scheduling") == "SERIAL_ONLY")
    check("P028_FIXTURE_ONLY", topology.get("workspace_kind") == "CONTROLLED_LOCAL_FIXTURE")
    runtime = docs["RUNTIME_AND_TRANSPORT_BOUNDARY.json"]
    check("P029_CODEX_VERSION", runtime.get("version") == "0.163.0")
    check("P030_CODEX_DIGEST", runtime.get("binary_sha256") == "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215")
    check("P031_CODEX_COMPATIBILITY", runtime.get("compatibility_state") == "PASS_LOCKED")
    check("P032_NO_PATH_DISCOVERY", runtime.get("generic_path_resolution") == "PROHIBITED")
    check("P033_NO_GLOBAL_CONFIG_MUTATION", runtime.get("global_config_mutation") == "PROHIBITED")
    check("P034_WORKER_NETWORK_DENY", runtime.get("worker_external_network") == "DENY_ALL")
    io = docs["STRUCTURED_IO_AND_QUARANTINE_REQUIREMENTS.json"]
    check("P035_STRUCTURED_IO", io.get("input_schema") == "StructuredWorkerRequest" and io.get("output_schema") == "StructuredWorkerResult")
    check("P036_QUARANTINE_FIRST", io.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED")
    check("P037_PROPOSAL_ONLY", io.get("output_authority") == "PROPOSAL_ONLY_NON_AUTHORITATIVE")
    check("P038_NO_SELF_AUTH", io.get("worker_self_authorization") == "PERMANENTLY_PROHIBITED")
    check("P039_NO_SELF_PROMOTION", io.get("worker_self_promotion") == "PERMANENTLY_PROHIBITED")
    workspace = docs["WORKSPACE_AND_CONFINEMENT_REQUIREMENTS.json"]
    check("P040_NO_TARGET", workspace.get("target_material_available") is False)
    check("P041_NO_SECRET", workspace.get("secrets_available") is False)
    check("P042_NO_CREDENTIAL", workspace.get("credential_mode") == "DENY_ALL")
    check("P043_NO_UNSANDBOXED_FALLBACK", workspace.get("unsandboxed_fallback") == "PROHIBITED")
    check("P044_PRE_ATTEMPT_GATES", len(docs["PRE_ATTEMPT_GATE_REQUIREMENTS.json"].get("gates", [])) == 15)
    check("P045_MARKER_AFTER_GATES", docs["PRE_ATTEMPT_GATE_REQUIREMENTS.json"].get("attempt_marker_rule") == "CREATE_ONLY_AFTER_ALL_PRE_ATTEMPT_GATES_PASS")
    check("P046_ONE_SHOT_NO_RETRY", docs["POST_VALIDATION_AND_EVIDENCE_REQUIREMENTS.json"].get("one_shot_no_automatic_retry") is True)
    check("P047_POST_AND_FREEZE_REQUIRED", docs["POST_VALIDATION_AND_EVIDENCE_REQUIREMENTS.json"].get("independent_post_validation_required") is True and docs["POST_VALIDATION_AND_EVIDENCE_REQUIREMENTS.json"].get("evidence_freeze_required") is True)
    authority = docs["AUTHORITY_NON_ESCALATION_DECISION.json"]
    check("P048_CONDITIONAL_WORKER_ONLY", authority.get("first_worker_invocation_authorized_conditionally") is True)
    check("P049_NO_OTHER_AUTHORITY", all(authority.get(key) is False for key in (
        "target_access_authorized", "credential_use_authorized", "subagent_authorized", "external_network_authorized",
        "daybreak_invocation_authorized", "exploit_replay_authorized", "parallelism_authorized",
        "capability_graph_authorized", "candidate_promotion_authorized", "submission_automation_authorized",
    )))
    check("P050_BUNDLE_ACCEPTED", accepted(docs))
    failed = [row for row in checks if row["status"] == "FAIL"]
    write_once("GOVERNANCE_VALIDATION_RESULT_RUN-0002.json", {
        "record_type": "FIRST_REAL_SECURITY_WORKER_INVOCATION_PRIMARY_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0", "run_id": "GOVERNANCE_VALIDATION_RUN-0002",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks": checks,
        "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed),
        "worker_invoked": False, "codex_as_worker_invoked": False,
    })
    if failed:
        raise SystemExit("primary governance validation failed")

    tests = []
    for index, row in enumerate(docs["NEGATIVE_GOVERNANCE_TEST_MATRIX.json"]["tests"], 1):
        mutation = row["mutation"]
        mutated = deepcopy(docs)
        if mutation.startswith("MISSING_"):
            identity = {"MISSING_RUNTIME_SUBSTRATE_LOCK":"RUNTIME_SUBSTRATE_V5", "MISSING_CODEX_COMPATIBILITY_LOCK":"CODEX_RUNTIME_0_163_0", "MISSING_WORKER_RUNTIME_LOCK":"SECURITY_WORKER_RUNTIME_V1"}[mutation]
            mutated["PREDECESSOR_LOCK_BINDINGS.json"]["bindings"] = [item for item in mutated["PREDECESSOR_LOCK_BINDINGS.json"]["bindings"] if item["identity"] != identity]
        elif mutation == "RUNTIME_VERSION_DRIFT": mutated["RUNTIME_AND_TRANSPORT_BOUNDARY.json"]["version"] = "0.164.0"
        elif mutation == "RUNTIME_DIGEST_DRIFT": mutated["RUNTIME_AND_TRANSPORT_BOUNDARY.json"]["binary_sha256"] = "0" * 64
        elif mutation == "CAMPAIGN_COUNT_TWO": mutated["MINIMAL_ONE_SHOT_TOPOLOGY.json"]["campaign_count"] = 2
        elif mutation == "LANE_COUNT_TWO": mutated["MINIMAL_ONE_SHOT_TOPOLOGY.json"]["lane_count"] = 2
        elif mutation == "WORKER_COUNT_TWO": mutated["MINIMAL_ONE_SHOT_TOPOLOGY.json"]["worker_identity_count"] = 2
        elif mutation == "INVOCATION_LIMIT_TWO": mutated["MINIMAL_ONE_SHOT_TOPOLOGY.json"]["worker_invocation_limit"] = 2
        elif mutation == "PARALLEL_SCHEDULING": mutated["MINIMAL_ONE_SHOT_TOPOLOGY.json"]["scheduling"] = "PARALLEL"
        elif mutation == "NON_FIXTURE_WORKSPACE": mutated["MINIMAL_ONE_SHOT_TOPOLOGY.json"]["workspace_kind"] = "TARGET"
        elif mutation == "TARGET_MATERIAL_AVAILABLE": mutated["WORKSPACE_AND_CONFINEMENT_REQUIREMENTS.json"]["target_material_available"] = True
        elif mutation == "SECRETS_AVAILABLE": mutated["WORKSPACE_AND_CONFINEMENT_REQUIREMENTS.json"]["secrets_available"] = True
        elif mutation == "WORKER_NETWORK_ALLOWED": mutated["RUNTIME_AND_TRANSPORT_BOUNDARY.json"]["worker_external_network"] = "ALLOW"
        elif mutation == "CREDENTIAL_AUTHORIZED": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["credential_use_authorized"] = True
        elif mutation == "TARGET_AUTHORIZED": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["target_access_authorized"] = True
        elif mutation == "SUBAGENT_AUTHORIZED": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["subagent_authorized"] = True
        elif mutation == "CAPABILITY_GRAPH_AUTHORIZED": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["capability_graph_authorized"] = True
        elif mutation == "CANDIDATE_PROMOTION_AUTHORIZED": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["candidate_promotion_authorized"] = True
        elif mutation == "SUBMISSION_AUTHORIZED": mutated["AUTHORITY_NON_ESCALATION_DECISION.json"]["submission_automation_authorized"] = True
        elif mutation == "SELF_AUTHORIZATION_ALLOWED": mutated["STRUCTURED_IO_AND_QUARANTINE_REQUIREMENTS.json"]["worker_self_authorization"] = "ALLOWED"
        elif mutation == "SELF_PROMOTION_ALLOWED": mutated["STRUCTURED_IO_AND_QUARANTINE_REQUIREMENTS.json"]["worker_self_promotion"] = "ALLOWED"
        elif mutation == "ATTEMPT_ALREADY_CONSUMED": mutated["ATTEMPT_AND_COUNTER_INITIAL_STATE.json"]["attempt_count"] = 1
        elif mutation == "CODEX_ALREADY_INVOKED": mutated["ATTEMPT_AND_COUNTER_INITIAL_STATE.json"]["codex_as_worker_invocation_count"] = 1
        elif mutation == "ATTEMPT_MARKER_BEFORE_GATES": mutated["PRE_ATTEMPT_GATE_REQUIREMENTS.json"]["attempt_marker_rule"] = "CREATE_BEFORE_GATES"
        rejected = not accepted(mutated)
        tests.append({"test_id":f"N{index:03d}", "mutation":mutation, "expected":"REJECT", "observed":"REJECTED" if rejected else "ACCEPTED", "status":"PASS" if rejected else "FAIL"})
    negative_failed = [row for row in tests if row["status"] == "FAIL"]
    write_once("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", {
        "record_type": "FIRST_REAL_SECURITY_WORKER_INVOCATION_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "schema_version": "1.0", "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if not negative_failed else "FAIL_CLOSED", "tests": tests,
        "tests_total":len(tests), "tests_passed":len(tests)-len(negative_failed), "tests_failed":len(negative_failed),
        "worker_invoked":False, "codex_as_worker_invoked":False,
    })
    if negative_failed:
        raise SystemExit("negative governance fixtures failed")
    print(json.dumps({"primary":f"{len(checks)}/{len(checks)}", "negative":f"{len(tests)}/{len(tests)}", "status":"PASS"}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
