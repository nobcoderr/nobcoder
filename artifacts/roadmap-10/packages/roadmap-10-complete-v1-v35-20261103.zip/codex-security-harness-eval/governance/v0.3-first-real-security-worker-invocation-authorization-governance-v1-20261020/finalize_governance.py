#!/usr/bin/env python3
"""Freeze the first-worker invocation authorization package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT=Path(__file__).resolve().parent
IDENTITY="AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_GOVERNANCE_ONLY"
FINAL={"GOVERNANCE_ARTIFACT_MANIFEST.json","GOVERNANCE_LOCK.json","FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"}


def sha256(path:Path)->str: return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path:Path)->dict: return json.loads(path.read_text(encoding="utf-8"))
def canonical(members:list[dict[str,object]])->str:
    material="".join(f"{item['path']}\0{item['sha256']}\0{item['bytes']}\n" for item in members)
    return hashlib.sha256(material.encode()).hexdigest()


def main()->int:
    manifest_path=ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json"; lock_path=ROOT/"GOVERNANCE_LOCK.json"
    if manifest_path.exists() or lock_path.exists(): raise SystemExit("freeze artifacts already exist")
    actual=sorted(path.name for path in ROOT.iterdir() if path.is_file())
    if len(actual)!=25: raise SystemExit(f"expected 25 pre-freeze members, got {len(actual)}")
    for name in ("GOVERNANCE_VALIDATION_RESULT_RUN-0002.json","NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json","INDEPENDENT_VALIDATION_RESULT_RUN-0001.json"):
        result=read(ROOT/name)
        if result.get("status")!="PASS" or result.get("checks_failed",result.get("tests_failed"))!=0: raise SystemExit(f"validation not PASS: {name}")
    members=[{"path":name,"sha256":sha256(ROOT/name),"bytes":(ROOT/name).stat().st_size,"required_mode":"0444"} for name in actual]
    root_digest=canonical(members)
    manifest={"governance_identity":IDENTITY,"record_type":"FIRST_REAL_SECURITY_WORKER_INVOCATION_AUTHORIZATION_GOVERNANCE_ARTIFACT_MANIFEST","schema_version":"1.0","members":members,"member_count":len(members),"canonical_governance_root_sha256":root_digest}
    manifest_path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    lock={
        "governance_identity":IDENTITY,"record_type":"FIRST_REAL_SECURITY_WORKER_INVOCATION_AUTHORIZATION_GOVERNANCE_LOCK","schema_version":"1.0",
        "status":"PASS_LOCKED_GOVERNANCE_ONLY","decision":"AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_CONDITIONALLY",
        "authorization_state":"CONDITIONAL_ENGINEERING_AND_ONE_SHOT_WORKER_INVOCATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "future_execution_identity":"V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1","canonical_governance_root_sha256":root_digest,
        "manifest_sha256":sha256(manifest_path),"member_count":len(members),"attempt_count":0,"attempt_limit":1,
        "historical_primary_run_0001":"PRESERVED_REFERENCE_ONLY","final_primary_run":"RUN-0002",
        "worker_invocation_count":0,"codex_as_worker_invocation_count":0,"target_access_authorized":False,"credential_use_authorized":False,
        "external_network_authorized":False,"subagent_authorized":False,"parallelism_authorized":False,"capability_graph_authorized":False,
        "candidate_promotion_authorized":False,"submission_automation_authorized":False,
        "next_legal_milestone":"IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_ONCE_IF_ALL_GATES_PASS",
    }
    lock_path.write_text(json.dumps(lock,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    for name in actual:(ROOT/name).chmod(0o444)
    manifest_path.chmod(0o444); lock_path.chmod(0o444)
    print(json.dumps({"status":"PASS_LOCKED_GOVERNANCE_ONLY","member_count":len(members),"root":root_digest},sort_keys=True))
    return 0


if __name__=="__main__": raise SystemExit(main())
