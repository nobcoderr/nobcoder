#!/usr/bin/env python3
"""Verify the frozen authorization package and predecessor immutability."""

from __future__ import annotations

import hashlib,json,stat
from pathlib import Path


ROOT=Path(__file__).resolve().parent
OUTPUT=ROOT/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
IDENTITY="AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_GOVERNANCE_ONLY"


def sha256(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path:Path)->dict:return json.loads(path.read_text(encoding="utf-8"))
def canonical(members:list[dict[str,object]])->str:
    material="".join(f"{item['path']}\0{item['sha256']}\0{item['bytes']}\n" for item in members)
    return hashlib.sha256(material.encode()).hexdigest()


def main()->int:
    if OUTPUT.exists():raise SystemExit("final result is append-only")
    manifest=read(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json");lock=read(ROOT/"GOVERNANCE_LOCK.json")
    checks=[]
    def check(name:str,condition:bool)->None:checks.append({"check_id":name,"status":"PASS" if condition else "FAIL"})
    check("F001_MEMBER_COUNT",manifest.get("member_count")==25 and len(manifest.get("members",[]))==25)
    check("F002_HASHES",all(sha256(ROOT/item["path"])==item["sha256"] for item in manifest["members"]))
    check("F003_SIZES",all((ROOT/item["path"]).stat().st_size==item["bytes"] for item in manifest["members"]))
    check("F004_MODES",all(stat.S_IMODE((ROOT/item["path"]).stat().st_mode)==0o444 for item in manifest["members"]))
    check("F005_ROOT",canonical(manifest["members"])==manifest.get("canonical_governance_root_sha256")==lock.get("canonical_governance_root_sha256"))
    check("F006_MANIFEST_DIGEST",sha256(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json")==lock.get("manifest_sha256"))
    check("F007_MANIFEST_READ_ONLY",stat.S_IMODE((ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_mode)==0o444)
    check("F008_LOCK_READ_ONLY",stat.S_IMODE((ROOT/"GOVERNANCE_LOCK.json").stat().st_mode)==0o444)
    check("F009_LOCK_STATUS",lock.get("status")=="PASS_LOCKED_GOVERNANCE_ONLY")
    check("F010_DECISION",lock.get("decision")=="AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_CONDITIONALLY")
    check("F011_ATTEMPT_ZERO",lock.get("attempt_count")==0 and lock.get("attempt_limit")==1)
    check("F012_INVOCATIONS_ZERO",lock.get("worker_invocation_count")==0 and lock.get("codex_as_worker_invocation_count")==0)
    false_keys=("target_access_authorized","credential_use_authorized","external_network_authorized","subagent_authorized","parallelism_authorized","capability_graph_authorized","candidate_promotion_authorized","submission_automation_authorized")
    check("F013_AUTHORITY_CEILING",all(lock.get(key) is False for key in false_keys))
    for item in read(ROOT/"PREDECESSOR_LOCK_BINDINGS.json")["bindings"]:
        check("F_LOCK_"+item["identity"],sha256(Path(item["lock_path"]))==item["lock_sha256"])
    check("F019_FUTURE_WORKSPACE_ABSENT",not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v1-20261020").exists())
    check("F020_PRIMARY_HISTORY_PRESERVED",read(ROOT/"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").get("status")=="PASS")
    check("F021_PRIMARY_FINAL_PASS",read(ROOT/"GOVERNANCE_VALIDATION_RESULT_RUN-0002.json").get("status")=="PASS")
    check("F022_NEGATIVE_PASS",read(ROOT/"NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json").get("status")=="PASS")
    check("F023_INDEPENDENT_PASS",read(ROOT/"INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").get("status")=="PASS")
    failed=[row for row in checks if row["status"]=="FAIL"]
    payload={"governance_identity":IDENTITY,"record_type":"FIRST_REAL_SECURITY_WORKER_INVOCATION_AUTHORIZATION_FINAL_FREEZE_VERIFICATION_RESULT","schema_version":"1.0","run_id":"FINAL_FREEZE_VERIFICATION_RUN-0001","status":"PASS" if not failed else "FAIL_CLOSED","checks":checks,"checks_total":len(checks),"checks_passed":len(checks)-len(failed),"checks_failed":len(failed),"attempt_count":0,"worker_invocation_count":0,"codex_as_worker_invocation_count":0}
    OUTPUT.write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n",encoding="utf-8");OUTPUT.chmod(0o444)
    ROOT.chmod(0o555)
    if failed:raise SystemExit("final freeze verification failed")
    print(json.dumps({"status":"PASS","passed":len(checks),"total":len(checks)},sort_keys=True));return 0


if __name__=="__main__":raise SystemExit(main())
