#!/usr/bin/env python3
"""Independent predecessor and authority-ceiling validation."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IDENTITY = "AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_GOVERNANCE_ONLY"
FUTURE = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v1-20261020")


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    output = ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json"
    if output.exists():
        raise SystemExit("independent validation result is append-only")
    bindings = read(ROOT / "PREDECESSOR_LOCK_BINDINGS.json")["bindings"]
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id":name, "status":"PASS" if condition else "FAIL", "evidence":evidence})

    check("I001_BINDING_COUNT", len(bindings) == 5)
    for item in bindings:
        path = Path(item["lock_path"])
        check("I_EXISTS_"+item["identity"], path.is_file())
        check("I_HASH_"+item["identity"], path.is_file() and sha256(path) == item["lock_sha256"])
        if path.is_file():
            lock = read(path)
            check("I_STATUS_"+item["identity"], "PASS_LOCKED" in json.dumps(lock, sort_keys=True))
            if item["identity"] == "SECURITY_WORKER_RUNTIME_V1":
                check("I_WORKER_RUNTIME_NO_EXEC", lock.get("worker_execution_authorized") is False and lock.get("worker_invocation_count") == 0)
            if item["identity"] == "CODEX_RUNTIME_0_163_0":
                check("I_CODEX_COMPAT_NO_WORKER", lock.get("worker_execution_authorized") is False and lock.get("codex_runtime_0_163_0") == "COMPATIBILITY_PASS_LOCKED")
            if item["identity"] == "RUNTIME_SUBSTRATE_V5":
                check("I_SUBSTRATE_LOCKED", lock.get("runtime_substrate_v5_status") == "PASS_LOCKED")
    check("I020_FUTURE_WORKSPACE_ABSENT", not FUTURE.exists())
    decision = read(ROOT / "FIRST_WORKER_INVOCATION_AUTHORIZATION_DECISION.json")
    check("I021_DECISION", decision.get("decision") == "AUTHORIZE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_CONDITIONALLY")
    check("I022_ATTEMPT_ZERO", decision.get("one_shot_attempt") == "0_OF_1_NOT_CONSUMED")
    check("I023_INVOCATIONS_ZERO", decision.get("worker_invocation_count") == 0 and decision.get("codex_as_worker_invocation_count") == 0)
    topology = read(ROOT / "MINIMAL_ONE_SHOT_TOPOLOGY.json")
    check("I024_TOPOLOGY_COUNTS", (topology.get("campaign_count"),topology.get("lane_count"),topology.get("worker_identity_count"),topology.get("codex_runtime_count")) == (1,1,1,1))
    check("I025_SERIAL_ONE_SHOT", topology.get("scheduling") == "SERIAL_ONLY" and topology.get("worker_invocation_limit") == 1)
    runtime = read(ROOT / "RUNTIME_AND_TRANSPORT_BOUNDARY.json")
    check("I026_RUNTIME_IDENTITY", runtime.get("runtime_identity") == "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED")
    check("I027_RUNTIME_DIGEST", runtime.get("binary_sha256") == "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215")
    check("I028_NETWORK_DENY", runtime.get("worker_external_network") == "DENY_ALL" and runtime.get("target_network_access") is False)
    workspace = read(ROOT / "WORKSPACE_AND_CONFINEMENT_REQUIREMENTS.json")
    check("I029_FIXTURE_ONLY", workspace.get("allowed_input") == "INERT_RESEARCHER_OWNED_LOCAL_FIXTURE")
    check("I030_NO_SECRETS_TARGET", workspace.get("secrets_available") is False and workspace.get("target_material_available") is False)
    io = read(ROOT / "STRUCTURED_IO_AND_QUARANTINE_REQUIREMENTS.json")
    check("I031_QUARANTINE", io.get("candidate_initial_state") == "HYPOTHESIS_QUARANTINED")
    check("I032_PROPOSAL_ONLY", io.get("output_authority") == "PROPOSAL_ONLY_NON_AUTHORITATIVE")
    check("I033_NO_SELF_AUTH_PROMOTION", io.get("worker_self_authorization") == "PERMANENTLY_PROHIBITED" and io.get("worker_self_promotion") == "PERMANENTLY_PROHIBITED")
    initial = read(ROOT / "ATTEMPT_AND_COUNTER_INITIAL_STATE.json")
    check("I034_INITIAL_ZERO", initial.get("attempt_count") == 0 and initial.get("worker_invocation_count") == 0 and initial.get("codex_as_worker_invocation_count") == 0)
    check("I035_OTHER_COUNTERS_ZERO", all(value == 0 for value in initial.get("operation_counters", {}).values()))
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    false_keys = [key for key in authority if key.endswith("_authorized")]
    check("I036_AUTHORITY_CEILING", all(authority[key] is False for key in false_keys), false_keys)
    check("I037_CONDITIONAL_WORKER_FLAG", authority.get("first_worker_invocation_authorized_conditionally") is True)
    pre = read(ROOT / "PRE_ATTEMPT_GATE_REQUIREMENTS.json")
    check("I038_PRE_ATTEMPT_GATES", len(pre.get("gates", [])) == 15 and pre.get("attempt_marker_rule") == "CREATE_ONLY_AFTER_ALL_PRE_ATTEMPT_GATES_PASS")
    post = read(ROOT / "POST_VALIDATION_AND_EVIDENCE_REQUIREMENTS.json")
    check("I039_POST_FREEZE_AND_ADJUDICATION", post.get("independent_post_validation_required") is True and post.get("evidence_freeze_required") is True and post.get("separate_acceptance_adjudication_required") is True)
    historical_primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0002.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I040_PRIMARY_HISTORY_PRESERVED", historical_primary.get("status") == "PASS" and historical_primary.get("run_id") == "GOVERNANCE_VALIDATION_RUN-0001")
    check("I041_ABORT_DISPOSITION", read(ROOT / "PRE_FREEZE_VALIDATION_TOOL_ABORT_DISPOSITION.json").get("primary_run_0001_disposition") == "HISTORICAL_REFERENCE_ONLY_NOT_FINAL_VALIDATION")
    check("I042_PRIMARY_FINAL_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I043_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == 25 and negative.get("tests_failed") == 0)
    failed=[row for row in checks if row["status"]=="FAIL"]
    payload={"governance_identity":IDENTITY,"record_type":"FIRST_REAL_SECURITY_WORKER_INVOCATION_INDEPENDENT_VALIDATION_RESULT","schema_version":"1.0","run_id":"INDEPENDENT_VALIDATION_RUN-0001","status":"PASS" if not failed else "FAIL_CLOSED","checks":checks,"checks_total":len(checks),"checks_passed":len(checks)-len(failed),"checks_failed":len(failed),"worker_invoked":False,"codex_as_worker_invoked":False}
    with output.open("x",encoding="utf-8",newline="\n") as handle:
        json.dump(payload,handle,indent=2,sort_keys=True); handle.write("\n")
    if failed: raise SystemExit("independent validation failed")
    print(json.dumps({"status":"PASS","passed":len(checks),"total":len(checks)},sort_keys=True))
    return 0


if __name__ == "__main__": raise SystemExit(main())
