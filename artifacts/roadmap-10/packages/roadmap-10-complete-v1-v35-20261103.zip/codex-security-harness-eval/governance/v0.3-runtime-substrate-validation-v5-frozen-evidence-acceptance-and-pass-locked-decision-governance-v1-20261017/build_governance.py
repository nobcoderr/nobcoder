#!/usr/bin/env python3
"""Build the governance-only Runtime Substrate V5 acceptance package.

Only frozen V5 bytes are read.  This program never launches the V5 runner,
bubblewrap, strace, Codex, Daybreak, a worker, a target, or a network action.
"""

from __future__ import annotations

import copy
import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
V5 = BASE / "v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016"
PRED = BASE / "codex-security-harness-eval/governance/v0.3-runtime-substrate-validation-v4-trace-erratum-governance-post-freeze-mandatory-rejection-cardinality-verifier-failure-and-v5-reissuance-decision-governance-v1-20261016"
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V5_FROZEN_EVIDENCE_ACCEPTANCE_AND_PASS_LOCKED_DECISION_GOVERNANCE_V1"
V5_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
V5_OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"

EXPECTED = {
    "pred_lock": "0e5354bbf039cd6136e84c61b75c26df809fb717861e1a92ad60a2bc93942fb3",
    "pred_manifest": "3cfdf376e866cf91b008a25e33961752ae637ad2ac8f5b97c5bc868e3f80ba3d",
    "pred_root": "be0983c492e7999b3f03e2c106706c30e1dca9d72a3dbde41f54350df11dd10c",
    "source_manifest": "2fa49b6b269fcf0210d70fbbecd822921660704733e6278492f3960183846d1d",
    "source_root": "e00fce02526d0f43810b4682c55a677224e0feb81b7f710002d5eaca1d8d77ea",
    "static_lock": "cc80f2434f5a8a8a05d62aeff99bb0d25e19ee3476ae67954c8cccd008c00a76",
    "lock_verify": "0b43c52c1adcce18976fc8b8e2bfded94b261abd0fd6071e6fa9b717c491c5e3",
    "argv": "a7bddd0c1531d3124438fb1f0c43b729a768e2f72e951b322a4bc65f8e310902",
    "execution_contract": "d739da6e9aac8ade962fbf9e7a3acbca485ae2898214a0658c1afdf1c7c3716b",
    "outer_env": "5bf4c55d592143ab3033e889c4748cfba5c25713c1e9c4092fe9f595e0bdba81",
    "unit_old": "244324bcedd0ed45fed316c185762ab8b128bc5abdfddbaf0ac75e848060417e",
    "unit_final": "0e3288d417497355ed79a95a657d5368955aac1ff025c07b72dea42f89cb220a",
    "primary_old": "33087ed6fbc8553156ab2e562a61fa1c12828e91be235381f6c6aec2972c89d5",
    "primary_final": "5e7b96f140ed9e5b6a30c5352c7e0ee5c999158d3fed77fe29b9fda6de84bb1e",
    "independent": "4897cf5268208e8aeea3e7fefcc9b4b61b8df5c7113c94b1b45f66d02755ed31",
    "preflight": "0a571cbaec194dc6a086692a784a19967c4529ea471f7c122eaa3a9dd58cd446",
    "resource": "89a6fb2213b6979942f01e13408bcd77371a75981196eb4954e5cbf0501e4480",
    "bind": "2f453952e208b46438eaf5228f68638ed40d66f4b3e61a92faab1e78f6bcfe8f",
    "bind_recheck": "3d3e2a91ab0128aca69bd853f0b0338446be05204487891a2b580dc4260fad10",
    "mount": "f5d28c340183f3fb74502968c8d6163c56bc8dc4dd96a2594cb76a0ba2b34b1e",
    "private_dev": "ad4fab48092b00b76b21b2abe8a1bad3d85f9259933a05208c5e307fb2989445",
    "loopback": "c6d3a4b0328aa2b310b1887a79c872efc6ff83088738c556552b3d52166eacea",
    "lifecycle": "586bc1451de1eed3e9266856ea6ec9a4d1745ff1e08e6de0f0e501be045efa6e",
    "pre_execution": "d48bce8b729bd598928a125d6e3e2ffe7a207d6be3775be4473849b52141b0b2",
    "exact_execution": "7752c8b3f1358d4f4cb9376b596043c840d516ee477408adb7fdd45ece375d6d",
    "attempt": "7d3a30055e2a033ce5d36f794dd4b1a9bf1c6f881485a5f068cca6ef01561c96",
    "child_exit": "7d68d770c936b50446dc51871cf7e6491adf006f1a06d151a13c6bbecc38fc09",
    "runtime_gate": "f202e51597c11c49f4b9f39343ed65eb90d16b30f338ae8f20f92fd4fae1242d",
    "fixture": "078b934d8ee41b975862b209c8f91d6755ccec42c2baa715ab85ba258b1b0ae4",
    "f009": "d0ce7b49186acf33a7491eface6a684ac6eae90b216b3ccc58b78fcba000ec7c",
    "post": "4b13df6d7c96c4fbc0eacda3085fd38488ad1c662ff3cecb7480ece53d66f20a",
    "terminal": "7b0a13c5204872463e4ef77131c101c33f9c8b091dd7e8c0e84ed1181208a74c",
    "evidence_manifest": "00f1e91d5d8fc6f77cfb8bff681abfe691f56e0beb797ac5b8f7f457c18361fb",
    "evidence_lock": "3808a0ebf5eaba2c6239c22e1e63727c057bacdb852d71343d79011648590073",
    "freeze_verify": "5b660c684f81216d526a954ead3f8e5fb0e5b2c5a7d99c9d4d90c3148a53b2dd",
    "evidence_root": "f99a9c1926177fecf7add4d87b2feb8ec5c2f1aa77e0a0cbc6e0eb96cff570ae",
    "trace_outer": "f46303b4e0ad21bb618de9ca5213d23232b647eca5ea64d1db1c1e13f7d82640",
    "trace_supervisor": "faf6ceeaeed0956cdc4b521d5c9635905e628338a37ec3f94b5e743c34367db9",
    "trace_application": "4998ce8c7e6aa405b599bd0fd54d4a20d9d1ff648ea5dc464bc992f531343aa6",
}

OP_KEYS = frozenset({
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "containment_fixture_attempts", "exploit_replays", "external_network_operations",
    "parallel_operations", "real_worker_processes", "runtime_validation_attempts",
    "subagent_processes", "submission_operations", "target_operations",
})
ATTEMPT_KEYS = frozenset({"runtime_validation_attempts", "containment_fixture_attempts"})


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def write_once(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def rows_root(rows: list[dict[str, Any]]) -> str:
    raw = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"])).encode()
    return hashlib.sha256(raw).hexdigest()


def manifest_valid(root: Path, path: Path, root_key: str) -> bool:
    document = load(path)
    members = document.get("members")
    if not isinstance(members, list) or document.get("member_count") != len(members):
        return False
    for row in members:
        member = root / str(row.get("path", ""))
        if not member.is_file() or member.is_symlink() or not ro(member):
            return False
        if member.stat().st_size != row.get("bytes") or sha(member) != row.get("sha256"):
            return False
    return rows_root(members) == document.get(root_key)


def governance_valid() -> bool:
    manifest_path = PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    manifest = load(manifest_path)
    lock = load(PRED / "GOVERNANCE_LOCK.json")
    members = manifest.get("members", [])
    manifest_sha = sha(manifest_path)
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}])
    return (
        manifest_valid(PRED, manifest_path, "canonical_member_root_sha256")
        and manifest_sha == lock.get("governance_artifact_manifest_sha256")
        and artifact_root == EXPECTED["pred_root"] == lock.get("canonical_artifact_root_sha256")
    )


def counts(document: dict[str, Any], total: int, passed: int, failed: int) -> bool:
    value = document.get("validation_counts")
    return isinstance(value, dict) and value == {"total": total, "passed": passed, "failed": failed}


def expected_counters(after_attempt: bool) -> dict[str, int]:
    return {key: (1 if after_attempt and key in ATTEMPT_KEYS else 0) for key in sorted(OP_KEYS)}


def exact_counters(value: Any, after_attempt: bool) -> bool:
    return isinstance(value, dict) and set(value) == set(OP_KEYS) and value == expected_counters(after_attempt)


def source_coverage(manifest: dict[str, Any]) -> bool:
    excluded = {"locks", "run-v5", "evidence-v5"}
    actual = {str(path.relative_to(V5)) for path in V5.rglob("*") if path.is_file() and path.relative_to(V5).parts[0] not in excluded}
    recorded = {str(row.get("path")) for row in manifest.get("members", [])}
    return actual == recorded


def evidence_coverage(manifest: dict[str, Any]) -> bool:
    excluded = {"evidence-v5/EVIDENCE_MANIFEST.json", "evidence-v5/EVIDENCE_FREEZE_LOCK.json"}
    actual: set[str] = set()
    for subtree in (V5 / "run-v5", V5 / "evidence-v5"):
        actual.update(str(path.relative_to(V5)) for path in subtree.rglob("*") if path.is_file() and str(path.relative_to(V5)) not in excluded)
    recorded = {str(row.get("path")) for row in manifest.get("members", [])}
    return actual == recorded


def all_pass(document: dict[str, Any], total: int) -> bool:
    checks = document.get("checks", [])
    return document.get("status") == "PASS" and len(checks) == total and all(row.get("status") == "PASS" for row in checks)


def acceptance_snapshot() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    pred_lock = load(PRED / "GOVERNANCE_LOCK.json")
    check("G001_PRED_LOCK_SHA", sha(PRED / "GOVERNANCE_LOCK.json") == EXPECTED["pred_lock"])
    check("G002_PRED_MANIFEST_SHA", sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == EXPECTED["pred_manifest"])
    check("G003_PRED_CANONICAL_ROOT", governance_valid())
    check("G004_PRED_PASS_LOCKED", pred_lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    v5_auth = pred_lock.get("runtime_validation_v5", {})
    check("G005_V5_AUTHORIZED", v5_auth.get("execution_identity") == V5_IDENTITY and v5_auth.get("operation") == V5_OPERATION and v5_auth.get("maximum_attempts") == 1)

    source_path = V5 / "locks/STATIC_SOURCE_MANIFEST.json"
    lock_path = V5 / "locks/STATIC_EXECUTION_LOCK.json"
    verify_path = V5 / "locks/STATIC_LOCK_VERIFICATION.json"
    source = load(source_path); lock = load(lock_path); lock_verify = load(verify_path)
    check("G006_SOURCE_MANIFEST_SHA", sha(source_path) == EXPECTED["source_manifest"])
    check("G007_SOURCE_MANIFEST_VALID", manifest_valid(V5, source_path, "canonical_source_root_sha256"))
    check("G008_SOURCE_COVERAGE_EXACT", source_coverage(source))
    check("G009_SOURCE_ROOT", source.get("canonical_source_root_sha256") == EXPECTED["source_root"])
    check("G010_SOURCE_MEMBER_COUNT", source.get("member_count") == 42 == len(source.get("members", [])))
    check("G011_STATIC_LOCK_SHA", sha(lock_path) == EXPECTED["static_lock"])
    check("G012_STATIC_LOCK_IDENTITY", lock.get("execution_identity") == V5_IDENTITY and lock.get("operation") == V5_OPERATION)
    check("G013_STATIC_LOCK_SOURCE", lock.get("source_manifest_sha256") == EXPECTED["source_manifest"] and lock.get("canonical_source_root_sha256") == EXPECTED["source_root"])
    check("G014_STATIC_LOCK_STATUS", lock.get("status") == "PASS_LOCKED_READY_FOR_ONE_CONDITIONAL_ATTEMPT")
    check("G015_STATIC_LOCK_SINGLE_USE", lock.get("attempt_count") == 0 and lock.get("maximum_attempts") == 1)
    check("G016_STATIC_LOCK_ARGV", lock.get("canonical_argv_array_sha256") == EXPECTED["argv"])
    check("G017_STATIC_LOCK_EXECUTION_CONTRACT", lock.get("exact_execution_contract_sha256") == EXPECTED["execution_contract"])
    check("G018_STATIC_LOCK_ENV", lock.get("outer_environment_sha256") == EXPECTED["outer_env"])
    check("G019_STATIC_LOCK_COUNTERS", exact_counters(lock.get("operation_counters"), False))
    check("G020_LOCK_VERIFY_SHA", sha(verify_path) == EXPECTED["lock_verify"])
    check("G021_LOCK_VERIFY_PASS", lock_verify.get("status") == "PASS" and counts(lock_verify, 35, 35, 0))

    pre = V5 / "prelock-results"
    unit_old = load(pre / "UNIT_FIXTURES_RUN-0001.json"); unit_final = load(pre / "UNIT_FIXTURES_RUN-0002.json")
    primary_old = load(pre / "PRIMARY_STATIC_VALIDATION_RUN-0001.json"); primary_final = load(pre / "PRIMARY_STATIC_VALIDATION_RUN-0002.json")
    independent = load(pre / "INDEPENDENT_STATIC_VALIDATION_RUN-0001.json"); preflight = load(pre / "FRESH_PREFLIGHT_RUN-0001.json")
    check("G022_UNIT_OLD_SHA", sha(pre / "UNIT_FIXTURES_RUN-0001.json") == EXPECTED["unit_old"])
    check("G023_UNIT_OLD_PRESERVED", unit_old.get("status") == "FAIL_CLOSED" and counts(unit_old, 49, 48, 1))
    check("G024_UNIT_FINAL_SHA", sha(pre / "UNIT_FIXTURES_RUN-0002.json") == EXPECTED["unit_final"])
    check("G025_UNIT_FINAL_PASS", unit_final.get("status") == "PASS" and counts(unit_final, 49, 49, 0))
    check("G026_PRIMARY_OLD_SHA", sha(pre / "PRIMARY_STATIC_VALIDATION_RUN-0001.json") == EXPECTED["primary_old"])
    check("G027_PRIMARY_OLD_PRESERVED", primary_old.get("status") == "FAIL_CLOSED" and counts(primary_old, 117, 116, 1))
    check("G028_PRIMARY_FINAL_SHA", sha(pre / "PRIMARY_STATIC_VALIDATION_RUN-0002.json") == EXPECTED["primary_final"])
    check("G029_PRIMARY_FINAL_PASS", primary_final.get("status") == "PASS" and counts(primary_final, 117, 117, 0))
    check("G030_INDEPENDENT_SHA", sha(pre / "INDEPENDENT_STATIC_VALIDATION_RUN-0001.json") == EXPECTED["independent"])
    check("G031_INDEPENDENT_PASS", independent.get("status") == "PASS" and counts(independent, 57, 57, 0))
    check("G032_PREFLIGHT_SHA", sha(pre / "FRESH_PREFLIGHT_RUN-0001.json") == EXPECTED["preflight"])
    check("G033_PREFLIGHT_PASS", preflight.get("status") == "PASS" and counts(preflight, 65, 65, 0))
    check("G034_PRELOCK_APPEND_ONLY", len({sha(path) for path in pre.glob("*.json")}) == 6 and all(ro(path) for path in pre.glob("*.json")))

    pf = V5 / "evidence-v5/preflight"
    prechecks = [
        ("RESOURCE_LIMIT_FEASIBILITY_PRECHECK.json", "resource"),
        ("BIND_SOURCE_RESOLUTION_PRECHECK.json", "bind"),
        ("SEMANTIC_MOUNT_TOPOLOGY_PRECHECK.json", "mount"),
        ("PRIVATE_DEV_CLASSIFICATION_PRECHECK.json", "private_dev"),
        ("LOOPBACK_ROUTE_CLASSIFICATION_PRECHECK.json", "loopback"),
        ("PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_PRECHECK.json", "lifecycle"),
    ]
    for index, (name, key) in enumerate(prechecks, start=35):
        document = load(pf / name)
        check(f"G{index:03d}_{key.upper()}_SHA", sha(pf / name) == EXPECTED[key])
        check(f"G{index+6:03d}_{key.upper()}_PASS", document.get("status") == "PASS")
    check("G047_BIND_RECHECK_SHA", sha(pf / "BIND_SOURCE_RESOLUTION_RECHECK.json") == EXPECTED["bind_recheck"])
    check("G048_BIND_RECHECK_PASS", load(pf / "BIND_SOURCE_RESOLUTION_RECHECK.json").get("status") == "PASS")
    check("G049_PRE_EXECUTION_SHA", sha(pf / "PRE_EXECUTION_VERIFICATION.json") == EXPECTED["pre_execution"])
    check("G050_PRE_EXECUTION_STATUS", load(pf / "PRE_EXECUTION_VERIFICATION.json").get("attempt_count") == 0)
    check("G051_EXACT_EXECUTION_SHA", sha(pf / "EXACT_EXECUTION.json") == EXPECTED["exact_execution"])

    evidence = V5 / "evidence-v5"; run = V5 / "run-v5"
    attempt = load(evidence / "runtime/ATTEMPT_STARTED.json"); child_exit = load(evidence / "runtime/CHILD_EXIT.json")
    runtime_gate = load(evidence / "raw-before-fixture/11_HOST_RUNTIME_GATE_RESULT.json")
    fixture = load(run / "fixture-output/FIXTURE_RESULT.json"); f009 = load(evidence / "validation/F009_HOST_REJECTION.json")
    post = load(evidence / "validation/INDEPENDENT_POST_VALIDATION_RESULT.json")
    terminal = load(evidence / "RUNTIME_VALIDATION_TERMINAL_RESULT.json")
    manifest_path = evidence / "EVIDENCE_MANIFEST.json"; manifest = load(manifest_path); freeze = load(evidence / "EVIDENCE_FREEZE_LOCK.json")
    topology = load(evidence / "raw-before-fixture/09_MOUNT_TOPOLOGY.json")
    network = load(evidence / "raw-before-fixture/06_CHILD_NETWORK.json")
    fd = load(evidence / "raw-before-fixture/05_CHILD_FD_SOCKET.json")
    control = load(evidence / "raw-before-fixture/10_CONTROL_PLANE_VISIBILITY.json")
    check("G052_ATTEMPT_SHA", sha(evidence / "runtime/ATTEMPT_STARTED.json") == EXPECTED["attempt"])
    check("G053_ATTEMPT_CONSUMED", attempt.get("attempt_count") == 1 and attempt.get("state") == "CONSUMED_NO_RETRY")
    check("G054_ATTEMPT_COUNTERS", exact_counters(attempt.get("operation_counters"), True))
    check("G055_CHILD_EXIT_SHA", sha(evidence / "runtime/CHILD_EXIT.json") == EXPECTED["child_exit"])
    check("G056_CHILD_EXIT_ZERO", child_exit.get("attempt_count") == 1 and child_exit.get("returncode") == 0)
    check("G057_RUNTIME_GATE_SHA", sha(evidence / "raw-before-fixture/11_HOST_RUNTIME_GATE_RESULT.json") == EXPECTED["runtime_gate"])
    check("G058_RUNTIME_GATE_33", all_pass(runtime_gate, 33))
    check("G059_FIXTURE_SHA", sha(run / "fixture-output/FIXTURE_RESULT.json") == EXPECTED["fixture"])
    fixtures = fixture.get("fixtures", [])
    check("G060_FIXTURE_9", fixture.get("fixture_count") == len(fixtures) == 9 and len(fixture.get("hard_failures", [])) == 0)
    check("G061_FIXTURE_STATUSES", all(row.get("status") == "PASS" for row in fixtures[:8]) and fixtures[8].get("status") == "PASS_PENDING_HOST_REJECTION")
    check("G062_FIXTURE_NO_AUTHORITY", all(fixture.get(key) is False for key in ("codex_invoked", "exploit_replayed", "external_network_operation", "subagent_started", "target_touched", "worker_process_started")))
    check("G063_FIXTURE_COUNTERS", exact_counters(fixture.get("operation_counters"), True))
    check("G064_F009_SHA", sha(evidence / "validation/F009_HOST_REJECTION.json") == EXPECTED["f009"])
    check("G065_F009_REJECTED", f009.get("status") == "PASS_REJECTED_AS_UNTRUSTED" and f009.get("claim_matches_host_facts") is False)
    check("G066_POST_SHA", sha(evidence / "validation/INDEPENDENT_POST_VALIDATION_RESULT.json") == EXPECTED["post"])
    check("G067_POST_77", post.get("status") == "PASS" and counts(post, 77, 77, 0) and len(post.get("checks", [])) == 77)
    check("G068_POST_COUNTERS", exact_counters(post.get("operation_counters"), True))
    check("G069_NO_OUT_OF_SCOPE_WRITES", post.get("out_of_scope_successful_fixture_write_paths") == [])
    check("G070_EXEC_ALLOWLIST", [row.get("path") for row in post.get("successful_execve_or_execveat", [])] == ["/usr/bin/bwrap", "/usr/bin/python3.14"])
    lifecycle = post.get("semantic_trace_lifecycle", {})
    check("G071_LIFECYCLE_PRIMARY", lifecycle.get("primary", {}).get("status") == "PASS" and lifecycle.get("primary", {}).get("classification") == "COMPLETE_NORMAL_LIFECYCLE")
    check("G072_LIFECYCLE_INDEPENDENT", lifecycle.get("independent", {}).get("status") == "PASS" and lifecycle.get("independent", {}).get("classification") == "COMPLETE_NORMAL_LIFECYCLE")
    check("G073_TERMINAL_SHA", sha(evidence / "RUNTIME_VALIDATION_TERMINAL_RESULT.json") == EXPECTED["terminal"])
    check("G074_TERMINAL_STATUS", terminal.get("status") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION")
    check("G075_TERMINAL_BINDING", terminal.get("execution_identity") == V5_IDENTITY and terminal.get("operation") == V5_OPERATION and terminal.get("attempt_count") == 1 and terminal.get("state") == "CONSUMED_NO_RETRY")
    check("G076_TERMINAL_COUNTERS", exact_counters(terminal.get("operation_counters"), True))
    check("G077_MANIFEST_SHA", sha(manifest_path) == EXPECTED["evidence_manifest"])
    check("G078_MANIFEST_VALID", manifest_valid(V5, manifest_path, "canonical_evidence_root_sha256"))
    check("G079_MANIFEST_COVERAGE", evidence_coverage(manifest))
    check("G080_EVIDENCE_ROOT", manifest.get("canonical_evidence_root_sha256") == EXPECTED["evidence_root"])
    check("G081_EVIDENCE_MEMBER_COUNT", manifest.get("member_count") == 61 == len(manifest.get("members", [])))
    check("G082_FREEZE_SHA", sha(evidence / "EVIDENCE_FREEZE_LOCK.json") == EXPECTED["evidence_lock"])
    check("G083_FREEZE_STATUS", freeze.get("status") == "PASS_FROZEN_TECHNICAL_EVIDENCE_AWAITING_SEPARATE_ACCEPTANCE" and freeze.get("attempt_count") == 1)
    check("G084_FREEZE_BINDING", freeze.get("evidence_manifest_sha256") == EXPECTED["evidence_manifest"] and freeze.get("canonical_evidence_root_sha256") == EXPECTED["evidence_root"])
    check("G085_FREEZE_COUNTERS", exact_counters(freeze.get("operation_counters"), True))
    check("G086_FREEZE_VERIFY_SHA", sha(evidence / "FREEZE_VERIFICATION_RESULT.json") == EXPECTED["freeze_verify"])
    check("G087_FREEZE_VERIFY_PASS", load(evidence / "FREEZE_VERIFICATION_RESULT.json").get("status") == "PASS_CANDIDATE")
    traces = post.get("trace_inventory", [])
    check("G088_TRACE_DIGESTS", [row.get("sha256") for row in traces] == [EXPECTED["trace_outer"], EXPECTED["trace_supervisor"], EXPECTED["trace_application"]])
    check("G089_TOPOLOGY_PASS", topology.get("status") == "PASS" and topology.get("unexpected_writable_mounts") == [] and len(topology.get("writable_host_backed_mounts", [])) == 1)
    check("G090_ROOT_RO", "ro" in topology.get("effective_mounts", {}).get("/", {}).get("mount_options", []))
    check("G091_PRIVATE_DEV", topology.get("private_dev", {}).get("status") == "PASS" and topology.get("private_dev", {}).get("extra_writable_under_dev") == [] and len(topology.get("private_dev", {}).get("canonical_device_objects", [])) == 6)
    check("G092_NETWORK_LOOPBACK_ONLY", network.get("status") == "PASS" and network.get("classification") == "LOOPBACK_ONLY_NO_EXTERNAL_ROUTE" and network.get("external_route_absent") is True)
    check("G093_FD_SOCKET", fd.get("unexpected_socket_count") == 0 and fd.get("socket_descriptors") == [])
    check("G094_CONTROL_PLANE_HIDDEN", control.get("codex_state") is False and control.get("host_evidence") is False and control.get("host_monitor_pid_visible") is False)
    check("G095_V5_ALL_FILES_READ_ONLY", all(ro(path) for path in V5.rglob("*") if path.is_file()))
    check("G096_V5_NO_FILE_SYMLINKS", not any(path.is_symlink() for path in V5.rglob("*") if path.is_file()))

    summary = {
        "identity": V5_IDENTITY, "operation": V5_OPERATION, "attempt_count": 1,
        "attempt_state": "CONSUMED_NO_RETRY", "runtime_gates": [33, 33, 0],
        "fixture_body": [9, 9, 0], "post_validation": [77, 77, 0],
        "six_prechecks": "PASS", "source_root": EXPECTED["source_root"],
        "static_lock_sha256": EXPECTED["static_lock"], "evidence_root": EXPECTED["evidence_root"],
        "evidence_lock_sha256": EXPECTED["evidence_lock"], "operation_counters": expected_counters(True),
        "historical_failed_prelock_runs_preserved": True, "authority_escalation": False,
    }
    return checks, summary


def acceptable(snapshot: dict[str, Any]) -> bool:
    return (
        snapshot.get("identity") == V5_IDENTITY and snapshot.get("operation") == V5_OPERATION
        and snapshot.get("attempt_count") == 1 and snapshot.get("attempt_state") == "CONSUMED_NO_RETRY"
        and snapshot.get("runtime_gates") == [33, 33, 0] and snapshot.get("fixture_body") == [9, 9, 0]
        and snapshot.get("post_validation") == [77, 77, 0] and snapshot.get("six_prechecks") == "PASS"
        and snapshot.get("source_root") == EXPECTED["source_root"] and snapshot.get("static_lock_sha256") == EXPECTED["static_lock"]
        and snapshot.get("evidence_root") == EXPECTED["evidence_root"] and snapshot.get("evidence_lock_sha256") == EXPECTED["evidence_lock"]
        and exact_counters(snapshot.get("operation_counters"), True)
        and snapshot.get("historical_failed_prelock_runs_preserved") is True
        and snapshot.get("authority_escalation") is False
    )


def main() -> None:
    checks, snapshot = acceptance_snapshot()
    failed = [row for row in checks if row["status"] != "PASS"]
    if failed:
        raise SystemExit(json.dumps({"status": "FAIL_CLOSED", "failed": failed}, sort_keys=True))

    negative_cases = [
        ("wrong identity", "identity", "OTHER"), ("wrong operation", "operation", "OTHER"),
        ("zero attempt", "attempt_count", 0), ("replay attempt", "attempt_count", 2),
        ("retryable state", "attempt_state", "RETRYABLE"), ("runtime gate missing", "runtime_gates", [33, 32, 1]),
        ("fixture missing", "fixture_body", [9, 8, 1]), ("post incomplete", "post_validation", [77, 76, 1]),
        ("precheck failed", "six_prechecks", "FAIL"), ("source drift", "source_root", "0" * 64),
        ("lock drift", "static_lock_sha256", "0" * 64), ("evidence drift", "evidence_root", "0" * 64),
        ("freeze drift", "evidence_lock_sha256", "0" * 64), ("history lost", "historical_failed_prelock_runs_preserved", False),
        ("authority escalation", "authority_escalation", True),
    ]
    negative_results = []
    for case_id, key, value in negative_cases:
        mutated = copy.deepcopy(snapshot); mutated[key] = value
        negative_results.append({"case_id": case_id, "expected": "REJECT", "actual": "REJECT" if not acceptable(mutated) else "ACCEPT", "status": "PASS" if not acceptable(mutated) else "FAIL"})
    for key in sorted(OP_KEYS):
        mutated = copy.deepcopy(snapshot); mutated["operation_counters"][key] += 1
        rejected = not acceptable(mutated)
        negative_results.append({"case_id": f"counter mutation {key}", "expected": "REJECT", "actual": "REJECT" if rejected else "ACCEPT", "status": "PASS" if rejected else "FAIL"})
    negative_failed = [row for row in negative_results if row["status"] != "PASS"]

    write_once("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V5_ACCEPTANCE_ROUTING_AND_SCOPE_DECISION", "schema_version": "1.0",
        "governance_identity": IDENTITY, "mode": "GOVERNANCE_ONLY_FROZEN_EVIDENCE_READ_ONLY",
        "authorized_action": "ADJUDICATE_EXACT_FROZEN_V5_EVIDENCE",
        "prohibited": ["V5_PATCH", "V5_RELOCK", "V5_RETRY", "RUNTIME_EXECUTION", "CODEX_OR_DAYBREAK_INVOCATION", "WORKER_OR_SUBAGENT", "TARGET_OR_NETWORK", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION"],
        "operations_performed": {"runtime_validation": 0, "containment_fixture": 0, "codex_cli": 0, "daybreak": 0, "worker": 0, "subagent": 0, "target": 0, "network": 0, "exploit_replay": 0},
    })
    write_once("PREDECESSOR_GOVERNANCE_BINDING.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_ACCEPTANCE_PREDECESSOR_BINDING", "schema_version": "1.0", "governance_identity": IDENTITY, "predecessor_lock_sha256": EXPECTED["pred_lock"], "predecessor_manifest_sha256": EXPECTED["pred_manifest"], "predecessor_canonical_artifact_root_sha256": EXPECTED["pred_root"], "predecessor_status": "PASS_LOCKED_GOVERNANCE_ONLY", "v5_authorization": "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_VALIDATION_AUTHORIZED"})
    write_once("RUNTIME_SUBSTRATE_V5_FROZEN_EVIDENCE_INVENTORY.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_FROZEN_EVIDENCE_INVENTORY", "schema_version": "1.0", "governance_identity": IDENTITY, **snapshot, "source_manifest_sha256": EXPECTED["source_manifest"], "evidence_manifest_sha256": EXPECTED["evidence_manifest"], "evidence_member_count": 61, "trace_sha256": [EXPECTED["trace_outer"], EXPECTED["trace_supervisor"], EXPECTED["trace_application"]]})
    write_once("SIX_PRE_ATTEMPT_GATES_ACCEPTANCE_DECISION.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_SIX_PRE_ATTEMPT_GATES_ACCEPTANCE_DECISION", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS", "gates": {name: "PASS" for name in ("RESOURCE_LIMIT_FEASIBILITY", "BIND_SOURCE_RESOLUTION", "SEMANTIC_MOUNT_TOPOLOGY", "PRIVATE_DEV_CLASSIFICATION", "LOOPBACK_ROUTE_CLASSIFICATION", "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS")}, "attempt_marker_after_all_gates": True})
    write_once("RUNTIME_CONFINEMENT_ACCEPTANCE_DECISION.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_RUNTIME_CONFINEMENT_ACCEPTANCE_DECISION", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS", "runtime_gates": {"total": 33, "passed": 33, "failed": 0}, "root_read_only": True, "writable_host_backed_mount_count": 1, "unexpected_writable_mount_count": 0, "private_dev": "PASS_EXACT_CANONICAL_OBJECTS", "network": "LOOPBACK_ONLY_NO_EXTERNAL_ROUTE", "unexpected_socket_count": 0, "control_plane_hidden": True, "out_of_scope_successful_fixture_writes": 0})
    write_once("PROCESS_LIFECYCLE_TRACE_COMPLETENESS_ACCEPTANCE_DECISION.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_PROCESS_LIFECYCLE_TRACE_COMPLETENESS_ACCEPTANCE_DECISION", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS", "primary": "COMPLETE_NORMAL_LIFECYCLE", "independent": "COMPLETE_NORMAL_LIFECYCLE", "eventfd_completion_handshake": True, "application_exit_zero": True, "supervisor_child_reaped_zero": True, "supervisor_terminal": "EXIT_ZERO", "trace_file_count": 3, "successful_exec_allowlist": ["/usr/bin/bwrap", "/usr/bin/python3.14"]})
    write_once("APPEND_ONLY_LINEAGE_DECISION.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_APPEND_ONLY_LINEAGE_DECISION", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS", "historical_failed_runs": {"UNIT_FIXTURES_RUN-0001.json": EXPECTED["unit_old"], "PRIMARY_STATIC_VALIDATION_RUN-0001.json": EXPECTED["primary_old"]}, "final_successful_runs": {"UNIT_FIXTURES_RUN-0002.json": EXPECTED["unit_final"], "PRIMARY_STATIC_VALIDATION_RUN-0002.json": EXPECTED["primary_final"], "INDEPENDENT_STATIC_VALIDATION_RUN-0001.json": EXPECTED["independent"], "FRESH_PREFLIGHT_RUN-0001.json": EXPECTED["preflight"]}, "overwrite_observed": False})
    write_once("HISTORICAL_RUNTIME_VALIDATION_PRESERVATION.json", {"record_type": "V0_3_RUNTIME_VALIDATION_HISTORICAL_PRESERVATION", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS", "v1_v4": "TERMINAL_REFERENCE_ONLY_UNCHANGED_BY_THIS_GOVERNANCE", "v5_technical_status_preserved": "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION", "v5_attempt": "1_OF_1_CONSUMED_NO_RETRY", "v5_bytes_mutated": False})
    write_once("AUTHORITY_NON_ESCALATION_DECISION.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0", "governance_identity": IDENTITY, "broader_execution_authority_granted": False, "runtime_replay_authorized": False, "codex_or_daybreak_authorized": False, "worker_or_subagent_authorized": False, "target_or_network_authorized": False, "exploit_replay_authorized": False, "parallelism_authorized": False, "capability_graph_authorized": False, "candidate_promotion_authorized": False, "submission_authorized": False})
    write_once("OPERATION_AUTHORIZATION_MATRIX.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0", "governance_identity": IDENTITY, "default": "DENY", "current": {"frozen_evidence_read_and_governance_publication": "AUTHORIZED", "v5_replay": "PROHIBITED", "runtime_or_containment_execution": "NOT_AUTHORIZED", "codex_daybreak_worker_subagent": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION", "target_network": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION", "exploit_replay": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION", "parallel_capability_promotion_submission": "DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION"}})
    write_once("RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GATE_REVIEW.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GATE_REVIEW", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS_ELIGIBLE_FOR_FINAL_ACCEPTANCE_DECISION" if acceptable(snapshot) else "FAIL_CLOSED", "required": snapshot, "primary_check_count": len(checks)})
    write_once("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0", "governance_identity": IDENTITY, "test_count": len(negative_results), "tests": [{"case_id": row["case_id"], "expected": row["expected"]} for row in negative_results]})
    write_once("NEGATIVE_GOVERNANCE_TEST_RESULT.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_NEGATIVE_GOVERNANCE_TEST_RESULT", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS" if not negative_failed else "FAIL_CLOSED", "tests_total": len(negative_results), "tests_passed": len(negative_results) - len(negative_failed), "tests_failed": len(negative_failed), "failed": negative_failed, "operation_counters": expected_counters(True)})
    write_once("GOVERNANCE_TEST_RESULT.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GOVERNANCE_TEST_RESULT", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS", "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0, "failed": [], "checks": checks, "operation_counters": expected_counters(True)})
    print(json.dumps({"status": "PASS", "checks": len(checks), "negative_tests": len(negative_results)}, sort_keys=True))


if __name__ == "__main__":
    main()
