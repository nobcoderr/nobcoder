#!/usr/bin/env python3
"""Independent read-only validation of the V5 acceptance evidence."""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V5 = Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016")
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V5_FROZEN_EVIDENCE_ACCEPTANCE_AND_PASS_LOCKED_DECISION_GOVERNANCE_V1"
EXECUTION_IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
OPERATION = "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5"
KEYS = frozenset({"candidate_promotions", "capability_edges", "codex_cli_invocations", "containment_fixture_attempts", "exploit_replays", "external_network_operations", "parallel_operations", "real_worker_processes", "runtime_validation_attempts", "subagent_processes", "submission_operations", "target_operations"})


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def ro(path: Path) -> bool:
    return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0


def rows_root(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{r['sha256']}  {r['path']}\n" for r in sorted(rows, key=lambda r: r["path"])).encode()).hexdigest()


def counters(value: Any) -> bool:
    return isinstance(value, dict) and set(value) == set(KEYS) and value.get("runtime_validation_attempts") == value.get("containment_fixture_attempts") == 1 and all(v == 0 for k, v in value.items() if k not in {"runtime_validation_attempts", "containment_fixture_attempts"})


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(name: str, ok: bool, detail: Any = None) -> None:
        checks.append({"check_id": name, "status": "PASS" if ok else "FAIL", "evidence": detail})

    source_path = V5 / "locks/STATIC_SOURCE_MANIFEST.json"; source = load(source_path)
    source_rows = source.get("members", [])
    check("I001_SOURCE_ROOT_RECOMPUTED", rows_root(source_rows) == source.get("canonical_source_root_sha256") == "e00fce02526d0f43810b4682c55a677224e0feb81b7f710002d5eaca1d8d77ea")
    source_bytes = all((V5 / r["path"]).is_file() and not (V5 / r["path"]).is_symlink() and ro(V5 / r["path"]) and (V5 / r["path"]).stat().st_size == r["bytes"] and sha(V5 / r["path"]) == r["sha256"] for r in source_rows)
    check("I002_SOURCE_BYTES", source_bytes)
    check("I003_SOURCE_COUNT", source.get("member_count") == len(source_rows) == 42)
    lock = load(V5 / "locks/STATIC_EXECUTION_LOCK.json")
    check("I004_LOCK_SHA", sha(V5 / "locks/STATIC_EXECUTION_LOCK.json") == "cc80f2434f5a8a8a05d62aeff99bb0d25e19ee3476ae67954c8cccd008c00a76")
    check("I005_LOCK_BINDING", lock.get("execution_identity") == EXECUTION_IDENTITY and lock.get("operation") == OPERATION and lock.get("attempt_count") == 0 and lock.get("maximum_attempts") == 1)
    check("I006_LOCK_VERIFY", load(V5 / "locks/STATIC_LOCK_VERIFICATION.json").get("status") == "PASS")

    pre = V5 / "prelock-results"
    expected = {
        "UNIT_FIXTURES_RUN-0001.json": ("244324bcedd0ed45fed316c185762ab8b128bc5abdfddbaf0ac75e848060417e", "FAIL_CLOSED", 49, 48, 1),
        "UNIT_FIXTURES_RUN-0002.json": ("0e3288d417497355ed79a95a657d5368955aac1ff025c07b72dea42f89cb220a", "PASS", 49, 49, 0),
        "PRIMARY_STATIC_VALIDATION_RUN-0001.json": ("33087ed6fbc8553156ab2e562a61fa1c12828e91be235381f6c6aec2972c89d5", "FAIL_CLOSED", 117, 116, 1),
        "PRIMARY_STATIC_VALIDATION_RUN-0002.json": ("5e7b96f140ed9e5b6a30c5352c7e0ee5c999158d3fed77fe29b9fda6de84bb1e", "PASS", 117, 117, 0),
        "INDEPENDENT_STATIC_VALIDATION_RUN-0001.json": ("4897cf5268208e8aeea3e7fefcc9b4b61b8df5c7113c94b1b45f66d02755ed31", "PASS", 57, 57, 0),
        "FRESH_PREFLIGHT_RUN-0001.json": ("0a571cbaec194dc6a086692a784a19967c4529ea471f7c122eaa3a9dd58cd446", "PASS", 65, 65, 0),
    }
    for index, (name, values) in enumerate(expected.items(), start=7):
        document = load(pre / name); count = document.get("validation_counts", {})
        check(f"I{index:03d}_{name}", sha(pre / name) == values[0] and document.get("status") == values[1] and count == {"total": values[2], "passed": values[3], "failed": values[4]} and ro(pre / name))

    prechecks = {
        "RESOURCE_LIMIT_FEASIBILITY_PRECHECK.json": "89a6fb2213b6979942f01e13408bcd77371a75981196eb4954e5cbf0501e4480",
        "BIND_SOURCE_RESOLUTION_PRECHECK.json": "2f453952e208b46438eaf5228f68638ed40d66f4b3e61a92faab1e78f6bcfe8f",
        "SEMANTIC_MOUNT_TOPOLOGY_PRECHECK.json": "f5d28c340183f3fb74502968c8d6163c56bc8dc4dd96a2594cb76a0ba2b34b1e",
        "PRIVATE_DEV_CLASSIFICATION_PRECHECK.json": "ad4fab48092b00b76b21b2abe8a1bad3d85f9259933a05208c5e307fb2989445",
        "LOOPBACK_ROUTE_CLASSIFICATION_PRECHECK.json": "c6d3a4b0328aa2b310b1887a79c872efc6ff83088738c556552b3d52166eacea",
        "PROCESS_LIFECYCLE_AND_TRACE_COMPLETENESS_PRECHECK.json": "586bc1451de1eed3e9266856ea6ec9a4d1745ff1e08e6de0f0e501be045efa6e",
    }
    for index, (name, digest) in enumerate(prechecks.items(), start=13):
        document = load(V5 / "evidence-v5/preflight" / name)
        check(f"I{index:03d}_{name}", sha(V5 / "evidence-v5/preflight" / name) == digest and document.get("status") == "PASS")

    attempt = load(V5 / "evidence-v5/runtime/ATTEMPT_STARTED.json")
    terminal = load(V5 / "evidence-v5/RUNTIME_VALIDATION_TERMINAL_RESULT.json")
    runtime_gate = load(V5 / "evidence-v5/raw-before-fixture/11_HOST_RUNTIME_GATE_RESULT.json")
    fixture = load(V5 / "run-v5/fixture-output/FIXTURE_RESULT.json")
    post = load(V5 / "evidence-v5/validation/INDEPENDENT_POST_VALIDATION_RESULT.json")
    check("I019_ATTEMPT", attempt.get("attempt_count") == 1 and attempt.get("state") == "CONSUMED_NO_RETRY" and counters(attempt.get("operation_counters")))
    check("I020_RUNTIME_GATE", runtime_gate.get("status") == "PASS" and len(runtime_gate.get("checks", [])) == 33 and all(r.get("status") == "PASS" for r in runtime_gate.get("checks", [])))
    fixtures = fixture.get("fixtures", [])
    check("I021_FIXTURE_BODY", fixture.get("fixture_count") == len(fixtures) == 9 and len(fixture.get("hard_failures", [])) == 0 and counters(fixture.get("operation_counters")))
    check("I022_POST", post.get("status") == "PASS" and post.get("validation_counts") == {"total": 77, "passed": 77, "failed": 0} and counters(post.get("operation_counters")))
    lifecycle = post.get("semantic_trace_lifecycle", {})
    check("I023_LIFECYCLE", all(lifecycle.get(k, {}).get("status") == "PASS" and lifecycle.get(k, {}).get("classification") == "COMPLETE_NORMAL_LIFECYCLE" for k in ("primary", "independent")))
    check("I024_TERMINAL", terminal.get("status") == "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION" and terminal.get("state") == "CONSUMED_NO_RETRY" and counters(terminal.get("operation_counters")))

    manifest_path = V5 / "evidence-v5/EVIDENCE_MANIFEST.json"; manifest = load(manifest_path); rows = manifest.get("members", [])
    check("I025_EVIDENCE_ROOT", rows_root(rows) == manifest.get("canonical_evidence_root_sha256") == "f99a9c1926177fecf7add4d87b2feb8ec5c2f1aa77e0a0cbc6e0eb96cff570ae")
    evidence_bytes = all((V5 / r["path"]).is_file() and not (V5 / r["path"]).is_symlink() and ro(V5 / r["path"]) and (V5 / r["path"]).stat().st_size == r["bytes"] and sha(V5 / r["path"]) == r["sha256"] for r in rows)
    check("I026_EVIDENCE_BYTES", evidence_bytes)
    check("I027_EVIDENCE_COUNT", manifest.get("member_count") == len(rows) == 61)
    freeze = load(V5 / "evidence-v5/EVIDENCE_FREEZE_LOCK.json")
    check("I028_FREEZE", sha(V5 / "evidence-v5/EVIDENCE_FREEZE_LOCK.json") == "3808a0ebf5eaba2c6239c22e1e63727c057bacdb852d71343d79011648590073" and freeze.get("status") == "PASS_FROZEN_TECHNICAL_EVIDENCE_AWAITING_SEPARATE_ACCEPTANCE" and counters(freeze.get("operation_counters")))
    topology = load(V5 / "evidence-v5/raw-before-fixture/09_MOUNT_TOPOLOGY.json")
    check("I029_TOPOLOGY", topology.get("status") == "PASS" and topology.get("unexpected_writable_mounts") == [] and len(topology.get("writable_host_backed_mounts", [])) == 1)
    check("I030_PRIVATE_DEV", topology.get("private_dev", {}).get("status") == "PASS" and len(topology.get("private_dev", {}).get("canonical_device_objects", [])) == 6)
    network = load(V5 / "evidence-v5/raw-before-fixture/06_CHILD_NETWORK.json")
    check("I031_NETWORK", network.get("classification") == "LOOPBACK_ONLY_NO_EXTERNAL_ROUTE" and network.get("external_route_absent") is True)
    check("I032_WRITES", post.get("out_of_scope_successful_fixture_write_paths") == [])
    check("I033_EXECS", [r.get("path") for r in post.get("successful_execve_or_execveat", [])] == ["/usr/bin/bwrap", "/usr/bin/python3.14"])
    check("I034_ALL_V5_FILES_RO", all(ro(path) for path in V5.rglob("*") if path.is_file()))
    check("I035_NO_V5_FILE_SYMLINK", not any(path.is_symlink() for path in V5.rglob("*") if path.is_file()))

    primary = load(ROOT / "GOVERNANCE_TEST_RESULT.json"); negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    review = load(ROOT / "RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GATE_REVIEW.json")
    check("I036_PRIMARY_GOVERNANCE", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I037_NEGATIVE_GOVERNANCE", negative.get("status") == "PASS" and negative.get("tests_failed") == 0)
    check("I038_REVIEW_ELIGIBLE", review.get("status") == "PASS_ELIGIBLE_FOR_FINAL_ACCEPTANCE_DECISION")
    check("I039_NO_RUNTIME_REEXECUTION", load(ROOT / "ROUTING_AND_SCOPE_DECISION.json").get("operations_performed", {}).get("runtime_validation") == 0)
    check("I040_AUTHORITY_CEILING", load(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json").get("broader_execution_authority_granted") is False)

    failed = [row for row in checks if row["status"] != "PASS"]
    result = {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_ACCEPTANCE_INDEPENDENT_VALIDATION_RESULT", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed), "failed": failed, "checks": checks, "operation_counters": {key: (1 if key in {"runtime_validation_attempts", "containment_fixture_attempts"} else 0) for key in sorted(KEYS)}}
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True); handle.write("\n")
    print(json.dumps({"status": result["status"], "checks": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
