#!/usr/bin/env python3
"""Read-only final freeze verification for V5 acceptance governance."""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V5_FROZEN_EVIDENCE_ACCEPTANCE_AND_PASS_LOCKED_DECISION_GOVERNANCE_V1"
FILES = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_GOVERNANCE_BINDING.json", "RUNTIME_SUBSTRATE_V5_FROZEN_EVIDENCE_INVENTORY.json",
    "RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GATE_REVIEW.json", "SIX_PRE_ATTEMPT_GATES_ACCEPTANCE_DECISION.json",
    "RUNTIME_CONFINEMENT_ACCEPTANCE_DECISION.json", "PROCESS_LIFECYCLE_TRACE_COMPLETENESS_ACCEPTANCE_DECISION.json",
    "APPEND_ONLY_LINEAGE_DECISION.json", "HISTORICAL_RUNTIME_VALIDATION_PRESERVATION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
    "GOVERNANCE_TEST_RESULT.json", "INDEPENDENT_VALIDATION_RESULT.json", "RUNTIME_SUBSTRATE_V5_FINAL_ACCEPTANCE_DECISION.json",
    "RUNTIME_SUBSTRATE_V5_PASS_LOCKED.json", "NEXT_LEGAL_MILESTONE.json", "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json",
}
KEYS = frozenset({"candidate_promotions", "capability_edges", "codex_cli_invocations", "containment_fixture_attempts", "exploit_replays", "external_network_operations", "parallel_operations", "real_worker_processes", "runtime_validation_attempts", "subagent_processes", "submission_operations", "target_operations"})


def sha(path: Path) -> str: return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise TypeError(path)
    return value
def ro(path: Path) -> bool: return (stat.S_IMODE(path.stat().st_mode) & 0o222) == 0
def rows_root(rows: list[dict[str, Any]]) -> str: return hashlib.sha256("".join(f"{r['sha256']}  {r['path']}\n" for r in sorted(rows, key=lambda r: r["path"])).encode()).hexdigest()
def counters(value: Any) -> bool: return isinstance(value, dict) and set(value) == set(KEYS) and value.get("runtime_validation_attempts") == value.get("containment_fixture_attempts") == 1 and all(v == 0 for k, v in value.items() if k not in {"runtime_validation_attempts", "containment_fixture_attempts"})


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(name: str, ok: bool, detail: Any = None) -> None: checks.append({"check_id": name, "status": "PASS" if ok else "FAIL", "detail": detail})
    actual = {p.name for p in ROOT.iterdir() if p.is_file()}
    check("F001_EXACT_FILE_SET", actual == FILES, {"extra": sorted(actual-FILES), "missing": sorted(FILES-actual)})
    check("F002_NO_DIRECTORIES", not any(p.is_dir() for p in ROOT.iterdir()))
    check("F003_ROOT_READ_ONLY", ro(ROOT))
    check("F004_FILES_REGULAR_READ_ONLY", all(p.is_file() and not p.is_symlink() and ro(p) for p in ROOT.iterdir()))
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"; lock_path = ROOT / "GOVERNANCE_LOCK.json"
    manifest = load(manifest_path); lock = load(lock_path); members = manifest.get("members", [])
    check("F005_IDENTITY", manifest.get("governance_identity") == lock.get("governance_identity") == IDENTITY)
    check("F006_STATUS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F007_MEMBER_COUNT", manifest.get("member_count") == len(members) == 22)
    check("F008_ROOT_COUNT", lock.get("root_member_count") == 23)
    check("F009_MANIFEST_LOCK_EXCLUDED", {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}.isdisjoint({r.get("path") for r in members}))
    member_ok = all((ROOT / str(r.get("path"))).is_file() and not (ROOT / str(r.get("path"))).is_symlink() and ro(ROOT / str(r.get("path"))) and (ROOT / str(r.get("path"))).stat().st_size == r.get("bytes") and sha(ROOT / str(r.get("path"))) == r.get("sha256") for r in members)
    check("F010_MEMBER_BYTES", member_ok)
    member_root = rows_root(members)
    check("F011_MEMBER_ROOT", member_root == manifest.get("canonical_member_root_sha256") == lock.get("canonical_member_root_sha256"))
    manifest_sha = sha(manifest_path)
    check("F012_MANIFEST_SHA", manifest_sha == lock.get("governance_manifest_sha256"))
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}])
    check("F013_ARTIFACT_ROOT", artifact_root == lock.get("canonical_artifact_root_sha256"))
    check("F014_STRUCTURAL_COUNTS", lock.get("structural_counts") == {"manifest_members": 22, "root_members": 23})
    primary = load(ROOT / "GOVERNANCE_TEST_RESULT.json"); negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json"); independent = load(ROOT / "INDEPENDENT_VALIDATION_RESULT.json")
    decision = load(ROOT / "RUNTIME_SUBSTRATE_V5_FINAL_ACCEPTANCE_DECISION.json"); accepted = load(ROOT / "RUNTIME_SUBSTRATE_V5_PASS_LOCKED.json")
    check("F015_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_total") == primary.get("checks_passed") and primary.get("checks_failed") == 0)
    check("F016_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_total") == negative.get("tests_passed") and negative.get("tests_failed") == 0)
    check("F017_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_total") == independent.get("checks_passed") and independent.get("checks_failed") == 0)
    check("F018_DECISION", decision.get("decision") == "A_ACCEPT_AND_PROMOTE_RUNTIME_SUBSTRATE_V5_TO_PASS_LOCKED")
    check("F019_ACCEPTED", accepted.get("status") == lock.get("runtime_substrate_v5_status") == "PASS_LOCKED")
    check("F020_ATTEMPT", decision.get("attempt_count") == decision.get("maximum_attempts") == accepted.get("attempt_count") == lock.get("attempt_count") == 1)
    check("F021_CONSUMED", decision.get("attempt_state") == accepted.get("attempt_state") == lock.get("attempt_state") == "CONSUMED_NO_RETRY")
    check("F022_NO_REPLAY", decision.get("runtime_replay_or_retry_authorized") is False and lock.get("runtime_replay_or_retry_authorized") is False)
    check("F023_SOURCE_ROOT", accepted.get("canonical_source_root_sha256") == "e00fce02526d0f43810b4682c55a677224e0feb81b7f710002d5eaca1d8d77ea")
    check("F024_STATIC_LOCK", accepted.get("static_execution_lock_sha256") == "cc80f2434f5a8a8a05d62aeff99bb0d25e19ee3476ae67954c8cccd008c00a76")
    check("F025_EVIDENCE_ROOT", accepted.get("canonical_evidence_root_sha256") == "f99a9c1926177fecf7add4d87b2feb8ec5c2f1aa77e0a0cbc6e0eb96cff570ae")
    check("F026_EVIDENCE_LOCK", accepted.get("evidence_freeze_lock_sha256") == "3808a0ebf5eaba2c6239c22e1e63727c057bacdb852d71343d79011648590073")
    check("F027_COUNTERS_LOCK", counters(lock.get("operation_counters")))
    check("F028_COUNTERS_ACCEPTED", counters(accepted.get("operation_counters")))
    check("F029_COUNTERS_PRIMARY", counters(primary.get("operation_counters")))
    check("F030_COUNTERS_NEGATIVE", counters(negative.get("operation_counters")))
    check("F031_COUNTERS_INDEPENDENT", counters(independent.get("operation_counters")))
    forbidden = ("codex_or_daybreak_authorized", "worker_or_subagent_authorized", "target_or_network_authorized", "exploit_replay_authorized", "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized", "submission_authorized")
    check("F032_LOCK_CEILING", all(lock.get(k) is False for k in forbidden))
    check("F033_ACCEPTED_CEILING", all(accepted.get(k) is False for k in forbidden))
    authority = load(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    check("F034_AUTHORITY", authority.get("broader_execution_authority_granted") is False)
    check("F035_DEFAULT_DENY", load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json").get("default") == "DENY")
    next_gate = load(ROOT / "NEXT_LEGAL_MILESTONE.json")
    check("F036_NEXT_GOVERNANCE_ONLY", next_gate.get("status") == "PROPOSAL_ONLY_REQUIRES_SEPARATE_GOVERNANCE_AUTHORIZATION" and next_gate.get("compatibility_execution_authority_now") == "NONE")
    check("F037_VALIDATION_COUNTS", all(v.get("total") == v.get("passed") and v.get("failed") == 0 for v in lock.get("validation_counts", {}).values()))
    check("F038_V5_SOURCE_UNCHANGED", sha(Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016/locks/STATIC_SOURCE_MANIFEST.json")) == "2fa49b6b269fcf0210d70fbbecd822921660704733e6278492f3960183846d1d")
    check("F039_V5_LOCK_UNCHANGED", sha(Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016/locks/STATIC_EXECUTION_LOCK.json")) == "cc80f2434f5a8a8a05d62aeff99bb0d25e19ee3476ae67954c8cccd008c00a76")
    check("F040_V5_EVIDENCE_UNCHANGED", sha(Path("/home/nobcoder/v0.3-runtime-substrate-validation-and-safe-containment-fixtures-v5-20261016/evidence-v5/EVIDENCE_FREEZE_LOCK.json")) == "3808a0ebf5eaba2c6239c22e1e63727c057bacdb852d71343d79011648590073")
    failed = [row for row in checks if row["status"] != "PASS"]
    result = {"status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed), "failed": failed, "governance_lock_sha256": sha(lock_path), "governance_manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root, "runtime_substrate_v5_status": lock.get("runtime_substrate_v5_status"), "operation_counters": lock.get("operation_counters")}
    print(json.dumps(result, sort_keys=True))
    if failed: raise SystemExit(1)


if __name__ == "__main__":
    main()
