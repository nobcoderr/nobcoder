#!/usr/bin/env python3
"""Finalize and freeze the governance-only V5 acceptance decision."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IDENTITY = "V0_3_RUNTIME_SUBSTRATE_VALIDATION_V5_FROZEN_EVIDENCE_ACCEPTANCE_AND_PASS_LOCKED_DECISION_GOVERNANCE_V1"
PREFINAL = {
    "build_governance.py", "independent_validate.py", "finalize_governance.py", "freeze_verify.py",
    "ROUTING_AND_SCOPE_DECISION.json", "PREDECESSOR_GOVERNANCE_BINDING.json",
    "RUNTIME_SUBSTRATE_V5_FROZEN_EVIDENCE_INVENTORY.json", "RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GATE_REVIEW.json",
    "SIX_PRE_ATTEMPT_GATES_ACCEPTANCE_DECISION.json", "RUNTIME_CONFINEMENT_ACCEPTANCE_DECISION.json",
    "PROCESS_LIFECYCLE_TRACE_COMPLETENESS_ACCEPTANCE_DECISION.json", "APPEND_ONLY_LINEAGE_DECISION.json",
    "HISTORICAL_RUNTIME_VALIDATION_PRESERVATION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "GOVERNANCE_TEST_RESULT.json", "INDEPENDENT_VALIDATION_RESULT.json",
}
FINAL = {"RUNTIME_SUBSTRATE_V5_FINAL_ACCEPTANCE_DECISION.json", "RUNTIME_SUBSTRATE_V5_PASS_LOCKED.json", "NEXT_LEGAL_MILESTONE.json"}
OP_KEYS = ("candidate_promotions", "capability_edges", "codex_cli_invocations", "containment_fixture_attempts", "exploit_replays", "external_network_operations", "parallel_operations", "real_worker_processes", "runtime_validation_attempts", "subagent_processes", "submission_operations", "target_operations")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict): raise TypeError(path)
    return value


def write_once(name: str, value: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True); handle.write("\n")


def rows_root(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{r['sha256']}  {r['path']}\n" for r in sorted(rows, key=lambda r: r["path"])).encode()).hexdigest()


def counters() -> dict[str, int]:
    return {key: (1 if key in {"runtime_validation_attempts", "containment_fixture_attempts"} else 0) for key in OP_KEYS}


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != PREFINAL:
        raise RuntimeError(f"unexpected pre-final set: extra={sorted(actual-PREFINAL)} missing={sorted(PREFINAL-actual)}")
    primary = load(ROOT / "GOVERNANCE_TEST_RESULT.json"); negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json"); independent = load(ROOT / "INDEPENDENT_VALIDATION_RESULT.json")
    review = load(ROOT / "RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GATE_REVIEW.json")
    if any(doc.get("status") != "PASS" for doc in (primary, negative, independent)) or review.get("status") != "PASS_ELIGIBLE_FOR_FINAL_ACCEPTANCE_DECISION":
        raise RuntimeError("mandatory acceptance validation not PASS")

    write_once("RUNTIME_SUBSTRATE_V5_FINAL_ACCEPTANCE_DECISION.json", {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V5_FINAL_ACCEPTANCE_DECISION", "schema_version": "1.0", "governance_identity": IDENTITY,
        "decision": "A_ACCEPT_AND_PROMOTE_RUNTIME_SUBSTRATE_V5_TO_PASS_LOCKED",
        "execution_identity": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5", "operation": "V03_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5",
        "attempt_count": 1, "maximum_attempts": 1, "attempt_state": "CONSUMED_NO_RETRY",
        "original_technical_status_preserved": "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION",
        "resulting_runtime_substrate_status": "PASS_LOCKED", "accepted_evidence_scope": "EXACT_FROZEN_V5_SOURCE_LOCK_RUNTIME_FIXTURE_TRACE_POST_VALIDATION_AND_EVIDENCE_SET",
        "runtime_replay_or_retry_authorized": False, "broader_execution_authority_granted": False,
    })
    write_once("RUNTIME_SUBSTRATE_V5_PASS_LOCKED.json", {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V5_PASS_LOCKED", "schema_version": "1.0", "governance_identity": IDENTITY, "status": "PASS_LOCKED",
        "execution_identity": "V0_3_RUNTIME_SUBSTRATE_VALIDATION_AND_SAFE_CONTAINMENT_FIXTURES_V5", "attempt_count": 1, "attempt_state": "CONSUMED_NO_RETRY",
        "canonical_source_root_sha256": "e00fce02526d0f43810b4682c55a677224e0feb81b7f710002d5eaca1d8d77ea",
        "static_execution_lock_sha256": "cc80f2434f5a8a8a05d62aeff99bb0d25e19ee3476ae67954c8cccd008c00a76",
        "canonical_evidence_root_sha256": "f99a9c1926177fecf7add4d87b2feb8ec5c2f1aa77e0a0cbc6e0eb96cff570ae",
        "evidence_freeze_lock_sha256": "3808a0ebf5eaba2c6239c22e1e63727c057bacdb852d71343d79011648590073",
        "operation_counters": counters(), "runtime_replay_authorized": False, "codex_or_daybreak_authorized": False,
        "worker_or_subagent_authorized": False, "target_or_network_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False, "candidate_promotion_authorized": False, "submission_authorized": False,
    })
    write_once("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V5_NEXT_LEGAL_MILESTONE", "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "PROPOSAL_ONLY_REQUIRES_SEPARATE_GOVERNANCE_AUTHORIZATION",
        "next_legal_work_class": "GOVERNANCE_ONLY_AUTHORIZATION_FOR_RUNTIME_MODEL_COMPATIBILITY_CONTRACT_PUBLICATION",
        "candidate_runtime_tracks": ["CODEX_CLI", "DAYBREAK_OR_FUTURE_RUNTIME"],
        "compatibility_execution_authority_now": "NONE", "worker_execution_authority_now": "NONE", "target_or_network_authority_now": "NONE",
    })

    names = PREFINAL | FINAL
    members = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in sorted(names)]
    member_root = rows_root(members)
    write_once("GOVERNANCE_ARTIFACT_MANIFEST.json", {"record_type": "V0_3_RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0", "governance_identity": IDENTITY, "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE", "member_count": len(members), "members": members, "canonical_member_root_sha256": member_root, "self_referential_hashes": False})
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"; manifest_sha = sha(manifest_path)
    artifact_root = rows_root(members + [{"path": manifest_path.name, "sha256": manifest_sha, "bytes": manifest_path.stat().st_size}])
    lock = {
        "record_type": "V0_3_RUNTIME_SUBSTRATE_V5_ACCEPTANCE_GOVERNANCE_LOCK", "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": "A_ACCEPT_AND_PROMOTE_RUNTIME_SUBSTRATE_V5_TO_PASS_LOCKED",
        "runtime_substrate_v5_status": "PASS_LOCKED", "attempt_count": 1, "attempt_state": "CONSUMED_NO_RETRY",
        "governance_manifest_sha256": manifest_sha, "canonical_member_root_sha256": member_root, "canonical_artifact_root_sha256": artifact_root,
        "root_member_count": len(members) + 1, "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 1},
        "validation_counts": {"governance": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]}, "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]}, "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]}},
        "operation_counters": counters(), "runtime_replay_or_retry_authorized": False, "codex_or_daybreak_authorized": False,
        "worker_or_subagent_authorized": False, "target_or_network_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False, "candidate_promotion_authorized": False, "submission_authorized": False,
        "next_milestone": "PROPOSAL_ONLY_REQUIRES_SEPARATE_GOVERNANCE",
    }
    write_once("GOVERNANCE_LOCK.json", lock)
    for path in ROOT.iterdir():
        if path.is_file(): os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": lock["status"], "runtime_substrate_v5": lock["runtime_substrate_v5_status"], "members": len(members), "manifest_sha256": manifest_sha, "canonical_artifact_root": artifact_root}, sort_keys=True))


if __name__ == "__main__":
    main()
