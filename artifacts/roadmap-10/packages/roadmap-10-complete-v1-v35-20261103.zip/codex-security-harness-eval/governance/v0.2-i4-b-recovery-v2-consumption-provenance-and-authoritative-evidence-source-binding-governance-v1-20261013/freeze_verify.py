#!/usr/bin/env python3
"""Verify the frozen Recovery V2 consumption provenance governance tree."""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


manifest = load(MANIFEST)
lock = load(LOCK)
actual_without_lock = sorted(
    item.name for item in ROOT.iterdir()
    if item.is_file() and not item.is_symlink() and item.name != LOCK.name
)
ledger = b"".join(f"{sha(ROOT / name)}  {name}\n".encode("utf-8") for name in actual_without_lock)
root_digest = hashlib.sha256(ledger).hexdigest()
listed = manifest["files"]
checks = {
    "root_real_directory": ROOT.is_dir() and not ROOT.is_symlink(),
    "manifest_hash": sha(MANIFEST) == lock["artifact_manifest_sha256"],
    "manifest_coverage": set(listed) == {name for name in actual_without_lock if name != MANIFEST.name},
    "manifest_count": manifest["file_count"] == len(listed),
    "manifest_member_hashes": all(sha(ROOT / name) == digest for name, digest in listed.items()),
    "canonical_root": root_digest == lock["artifact_root_sha256"],
    "lock_status": lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY",
    "state_model_hash": sha(ROOT / "CONSUMPTION_STATE_MODEL.json") == lock["consumption_state_model_sha256"],
    "coverage_hash": sha(ROOT / "HISTORICAL_SOURCE_COVERAGE_REVIEW.json") == lock["historical_source_coverage_review_sha256"],
    "source_decision_hash": sha(ROOT / "AUTHORITATIVE_EVIDENCE_SOURCE_DECISION.json") == lock["authoritative_evidence_source_decision_sha256"],
    "binding_hash": sha(ROOT / "EVIDENCE_SOURCE_BINDING.json") == lock["evidence_source_binding_sha256"],
    "provenance_hash": sha(ROOT / "EVIDENCE_PROVENANCE_CONTRACT.json") == lock["evidence_provenance_contract_sha256"],
    "state_decision_hash": sha(ROOT / "SINGLE_USE_STATE_DECISION.json") == lock["single_use_state_decision_sha256"],
    "ledger_requirements_hash": sha(ROOT / "PROSPECTIVE_ATTEMPT_LEDGER_REQUIREMENTS.json") == lock["prospective_attempt_ledger_requirements_sha256"],
    "governance_result_hash": sha(ROOT / "GOVERNANCE_TEST_RESULT.json") == lock["governance_test_result_sha256"],
    "independent_result_hash": sha(ROOT / "INDEPENDENT_VALIDATION_RESULT.json") == lock["independent_validation_result_sha256"],
    "negative_result_hash": sha(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json") == lock["negative_governance_test_result_sha256"],
    "no_collection_authorization": not (ROOT / "EVIDENCE_COLLECTION_AUTHORIZATION.json").exists(),
    "files_read_only": all(not item.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH) for item in ROOT.iterdir() if item.is_file()),
    "directory_read_only": not ROOT.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH),
    "no_symlinks": not any(item.is_symlink() for item in ROOT.iterdir()),
}
failed = [name for name, value in checks.items() if not value]
print(json.dumps({
    "schema_version": 1,
    "validator": "recovery_v2_consumption_provenance_governance_freeze_verifier_v1",
    "status": "PASS" if not failed else "FAIL",
    "checks_total": len(checks),
    "checks_passed": len(checks) - len(failed),
    "checks_failed": len(failed),
    "artifact_manifest_sha256": sha(MANIFEST),
    "canonical_root_sha256": root_digest,
    "governance_lock_sha256": sha(LOCK),
    "failed_checks": failed,
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(1 if failed else 0)
