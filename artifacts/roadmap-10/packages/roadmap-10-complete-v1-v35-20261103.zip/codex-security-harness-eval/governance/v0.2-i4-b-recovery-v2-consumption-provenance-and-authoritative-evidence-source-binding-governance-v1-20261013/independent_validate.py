#!/usr/bin/env python3
"""Independent validator for Recovery V2 consumption provenance governance."""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
HOME = Path("/home/nobcoder")
BASE = HOME / "codex-security-harness-eval/governance"
GUARD = HOME / "v0.2-i4-b-v2-evidence-recovery-live-guard-v2-20261013"
HANDOFF = HOME / "v0.2-i4-b-v3-partial-evidence-recovery-v2-handoff-v1-20261012"
ERRATUM = BASE / "v0.2-i4-b-evidence-recovery-hash-binding-erratum-and-reauthorization-governance-v1-20261012"
OPERATIONAL = BASE / "v0.2-i4-b-v2-evidence-recovery-operational-staging-live-guard-evidence-and-operator-handoff-binding-governance-v1-20261012"
IDENTITY = "V0.2_I4_B_RECOVERY_V2_CONSUMPTION_PROVENANCE_AND_AUTHORITATIVE_EVIDENCE_SOURCE_BINDING_GOVERNANCE_V1"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def directory_root(path: Path) -> str:
    ledger = b"".join(
        f"{sha(item)}  {item.name}\n".encode("utf-8")
        for item in sorted(path.iterdir(), key=lambda item: item.name.encode("utf-8"))
        if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json"
    )
    return hashlib.sha256(ledger).hexdigest()


def source_manifest_root(path: Path, manifest_name: str) -> str:
    manifest = load(path / manifest_name)
    ledger = b"".join(
        f"{record['sha256']}  {name}\n".encode("utf-8")
        for name, record in sorted(manifest["files"].items())
        if sha(path / name) == record["sha256"]
    )
    if len(manifest["files"]) != ledger.count(b"\n"):
        return "MISMATCH"
    return hashlib.sha256(ledger).hexdigest()


def outcome(*, exact_identity=True, exact_source=True, attempt=False, destination=False, failure=False, complete_negative=False):
    if not exact_identity or not exact_source:
        return "UNKNOWN"
    if complete_negative:
        return "NOT_ATTEMPTED_PROVEN"
    if destination:
        return "CONSUMED"
    if attempt and failure:
        return "TERMINAL_FAILURE"
    if attempt:
        return "ATTEMPT_STARTED"
    return "UNKNOWN"


checks: list[tuple[str, bool]] = []


def verify(name: str, condition: bool) -> None:
    checks.append((name, bool(condition)))


p = load(ROOT / "GOVERNANCE_GATE_PROTOCOL.json")
f = load(ROOT / "PREFLIGHT_RESULT.json")
s = load(ROOT / "CONSUMPTION_STATE_MODEL.json")
c = load(ROOT / "HISTORICAL_SOURCE_COVERAGE_REVIEW.json")
a = load(ROOT / "AUTHORITATIVE_EVIDENCE_SOURCE_DECISION.json")
b = load(ROOT / "EVIDENCE_SOURCE_BINDING.json")
e = load(ROOT / "EVIDENCE_PROVENANCE_CONTRACT.json")
d = load(ROOT / "SINGLE_USE_STATE_DECISION.json")
l = load(ROOT / "PROSPECTIVE_ATTEMPT_LEDGER_REQUIREMENTS.json")
m = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
r = load(ROOT / "RISK_REGISTER.json")
i = load(ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json")
q = load(ROOT / "PRE_DECISION_LOCK.json")

verify("identity", p["gate_id"] == IDENTITY)
verify("task_class", p["task_class"] == "GOVERNANCE_ONLY")
verify("preflight_status", f["status"] == "PASS" and f["checks_failed"] == 0)
verify("preflight_count_derived", f["checks_total"] == len(f["checks"]) == 42)
verify("scope_no_windows", p["scope"]["windows_host_action"] is False and p["scope"]["windows_log_collection"] is False)
verify("scope_no_execution", p["scope"]["live_guard_execution"] is False and p["scope"]["recovery_v2_execution"] is False)
verify("scope_no_vbox", p["scope"]["vboxmanage_invocation"] is False)
verify("scope_no_provisioning", p["scope"]["a3_a5_operation"] is False and p["scope"]["vm_vdi_iso_mutation"] is False)

verify("authorization_bytes", sha(ERRATUM / "NEW_RECOVERY_AUTHORIZATION.json") == "50c9bf4bf49cb5a777dce5021628bf3ea96536f549fd71dc68f35c86ed27c653")
verify("single_use_boundary_bytes", sha(OPERATIONAL / "SINGLE_USE_CONSUMPTION_BOUNDARY.json") == "cb574596b956ed925a4680d610978361905379db5e172ff8e8ec64e68e045027")
verify("operational_root", directory_root(OPERATIONAL) == "f10641bf6d16dc30a0086c9828e07eeae2c1a834d0369e8c77cfa791853e563c")
verify("guard_source_bytes", sha(GUARD / "Test-V3PartialEvidenceRecoveryV2LiveGuardsV2.ps1") == "2133e61216f65eee4f396a252ed8881a531ba9f0e668655f5fb6aca2901b4de4")
verify("guard_source_root", source_manifest_root(GUARD, "LIVE_GUARD_V2_SOURCE_MANIFEST.json") == "6428cf7324e25e9b27a2fdb5d02963869b5b1abaf58e9adc12fff95596c7d466")
verify("guard_digest_lock", sha(GUARD / "LIVE_GUARD_V2_DIGEST_LOCK.json") == "0bf6089ad569b36c8b7a8bb4ffc263ba0fcf320393dcaddce61aaa2b9b65f73c")
verify("guard_validation_lock", sha(GUARD / "LIVE_GUARD_V2_VALIDATION_LOCK.json") == "f734c0a7a67c428588f886add6134e9534ca988864b16122d8fd67e7b8545a25")
guard_lock = load(GUARD / "LIVE_GUARD_V2_VALIDATION_LOCK.json")
verify("guard_lock_unknown", guard_lock["consumption_provenance"] == "CONSUMPTION_UNKNOWN" and guard_lock["unconsumed_proven"] is False)
verify("guard_not_authorized_live", guard_lock["live_guard_authorization_state"].startswith("NOT_AUTHORIZED"))
verify("handoff_source_bytes", sha(HANDOFF / "Collect-V3PartialEvidenceRecoveryPackageV2.ps1") == "a03ed48401c25829125bee639059a1cfa600854c64756bd75cf5cf23d5347f7c")
verify("handoff_source_root", source_manifest_root(HANDOFF, "HANDOFF_V2_SOURCE_MANIFEST.json") == "0b4ec22e317f8c229cb43fcf0f3e74b0202ff516a60dd156fd04087309e0e08b")
verify("handoff_digest_lock", sha(HANDOFF / "HANDOFF_V2_DIGEST_LOCK.json") == "652752b9bf5d0bfe859d80f4a8d6b03ec89f53f51695138ff1b4c60a904ff5ef")
verify("handoff_validation_lock", sha(HANDOFF / "HANDOFF_V2_VALIDATION_LOCK.json") == "a594134c42050e082aea1a8161658241c9e52d53ab81079b51f16ff0249d52ee")
verify("guard_tree_read_only", all(not item.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH) for item in GUARD.iterdir() if item.is_file()))
verify("handoff_tree_read_only", all(not item.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH) for item in HANDOFF.iterdir() if item.is_file()))

source = (HANDOFF / "Collect-V3PartialEvidenceRecoveryPackageV2.ps1").read_text(encoding="utf-8")
verify("switch_gate_present", 'if (-not $ExecuteAuthorizedEvidenceRecoveryV2)' in source)
verify("confirmation_present", "to consume the single-use V2 recovery authorization" in source)
verify("destination_creation_present", '$null = New-Item -ItemType Directory -Path $Destination' in source)
verify("consumption_timestamp_present", '$AuthorizationConsumedUtc = (Get-Date).ToUniversalTime().ToString("o")' in source)
verify("failure_record_requires_destination", 'if (-not $DestinationCreated -or -not (Test-Path -LiteralPath $Destination -PathType Container))' in source)
verify("failure_record_early_return", "if (-not $DestinationCreated" in source and "return" in source[source.index("if (-not $DestinationCreated"):source.index("if (-not $DestinationCreated") + 250])
verify("model_states", [row["state"] for row in s["canonical_states"]] == ["NOT_ATTEMPTED_PROVEN", "ATTEMPT_STARTED", "CONSUMED", "TERMINAL_FAILURE", "UNKNOWN"])
verify("model_two_axis_gap", s["structural_coverage_gap"]["failure_record_before_destination_creation"] is False)
verify("model_current_unknown", s["current_state"] == "UNKNOWN" and s["current_predecessor_literal"] == "CONSUMPTION_UNKNOWN")

verify("coverage_count", c["sources_reviewed"] == len(c["sources"]) == 9)
verify("coverage_no_complete_boundary", c["complete_observation_boundary_established"] is False)
verify("coverage_no_negative_source", c["sources_sufficient_for_negative_nonoccurrence"] == 0)
verify("coverage_no_positive_source", c["sources_sufficient_for_positive_attempt_or_consumption"] == 0)
verify("authorization_timestamp_gap", c["required_interval"]["start_timestamp_precision"].startswith("NOT_CANONICALLY_RECORDED"))
verify("decision_governance_pass", a["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
verify("decision_historical_insufficient", a["decisions"]["D1_historical_consumption_evidence_sufficiency"] == "INSUFFICIENT")
verify("decision_no_source", a["decisions"]["D2_authoritative_historical_source_availability"].startswith("NONE"))
verify("decision_no_collection", a["decisions"]["D3_exact_collection_authorization_scope"] == "NOT_GRANTED")
verify("decision_v2_blocked", a["decisions"]["D7_existing_recovery_v2_eligibility"] == "BLOCKED_NOT_EXECUTABLE_NO_RETRY")
verify("binding_none", b["status"] == "NO_AUTHORITATIVE_HISTORICAL_SOURCE_BOUND" and b["bound_source"] is None)
verify("binding_no_host_path", b["bound_host_path"] is None and b["bound_event_channel"] is None)
verify("binding_no_authority", b["collection_authority"] == "NOT_GRANTED")
verify("provenance_destination_absence_rejected", e["negative_claim_standard"]["destination_absence_alone"] == "REJECTED")
verify("provenance_new_ledger_rejected", e["negative_claim_standard"]["new_ledger_as_historical_proof"] == "REJECTED")
verify("single_state_unknown", d["historical_consumption_state"] == "CONSUMPTION_UNKNOWN")
verify("single_state_no_positive_claims", not any(d[key] for key in ("not_attempted_proven", "attempt_started_proven", "consumed_proven", "terminal_failure_proven")))
verify("single_state_blocked", d["existing_recovery_v2_eligibility"] == "BLOCKED_NOT_EXECUTABLE")
verify("successor_separate", d["successor_policy"].startswith("A prospective recovery successor requires"))
verify("prospective_not_created", l["created_in_this_milestone"] is False and l["operational_authority_granted"] is False)
verify("prospective_pre_side_effect", l["mandatory_properties"]["exclusive_create_before_side_effects"] is True)
verify("prospective_crash_terminal", "terminal" in l["crash_policy"].lower())
verify("prospective_no_retroactive", l["retrospective_effect_on_recovery_v2"] == "NONE")

ops = {row["id"]: row["decision"] for row in m["operations"]}
verify("matrix_count", m["operation_count"] == len(ops) == 20)
verify("matrix_current_windows_zero", m["currently_executable_windows_operations"] == 0)
verify("matrix_current_guard_zero", m["currently_executable_live_guard_operations"] == 0)
verify("matrix_current_recovery_zero", m["currently_executable_recovery_operations"] == 0)
verify("matrix_denied", m["denied"] == 15 and all(ops[f"X{index:02d}"] == "DENIED" for index in range(1, 16)))
verify("risk_register", r["risk_count"] == len(r["risks"]) == 18 and r["all_fail_closed"])
verify("immutability_result", i["status"] == "PASS" and i["writes_to_predecessor_trees"] == 0)
verify("prelock_integrity", all(sha(ROOT / name) == digest for name, digest in q["locked_artifacts"].items()))

scenarios = [
    ("empty", {}, "UNKNOWN"),
    ("destination_absent", {"destination": False}, "UNKNOWN"),
    ("complete_negative", {"complete_negative": True}, "NOT_ATTEMPTED_PROVEN"),
    ("attempt", {"attempt": True}, "ATTEMPT_STARTED"),
    ("pre_destination_failure", {"attempt": True, "failure": True}, "TERMINAL_FAILURE"),
    ("destination_created", {"destination": True}, "CONSUMED"),
    ("destination_created_then_failure", {"attempt": True, "destination": True, "failure": True}, "CONSUMED"),
    ("wrong_identity", {"attempt": True, "exact_identity": False}, "UNKNOWN"),
    ("wrong_source", {"destination": True, "exact_source": False}, "UNKNOWN"),
]
for name, args, expected in scenarios:
    verify(f"state_scenario_{name}", outcome(**args) == expected)

for forbidden in (
    "EVIDENCE_COLLECTION_AUTHORIZATION.json", "LIVE_GUARD_EXECUTION_AUTHORIZATION.json",
    "RECOVERY_V2_EXECUTION_RESULT.json", "EVIDENCE_RECOVERY_LOCK.json",
    "A3_A5_EXECUTION_RESULT.json", "VM_BOOT_AUTHORIZATION.json", "I4_B_RUNTIME_RESULT.json",
):
    verify(f"forbidden_absent_{forbidden}", not (ROOT / forbidden).exists())

passed = sum(result for _, result in checks)
failed = len(checks) - passed
print(json.dumps({
    "schema_version": 1,
    "gate_id": IDENTITY,
    "validator": "independent_recovery_v2_consumption_provenance_validator_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "independence": "Separate implementation; does not import governance_self_test.py and independently parses the frozen handoff state transitions.",
    "checks": [{"check": name, "pass": result} for name, result in checks],
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
