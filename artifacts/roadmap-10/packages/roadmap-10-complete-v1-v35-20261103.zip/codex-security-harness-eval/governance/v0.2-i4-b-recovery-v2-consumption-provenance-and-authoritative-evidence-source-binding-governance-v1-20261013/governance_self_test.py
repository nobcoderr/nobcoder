#!/usr/bin/env python3
"""Deterministic self-test for Recovery V2 consumption provenance governance."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
HOME = Path("/home/nobcoder")
GOVBASE = HOME / "codex-security-harness-eval/governance"
IDENTITY = "V0.2_I4_B_RECOVERY_V2_CONSUMPTION_PROVENANCE_AND_AUTHORITATIVE_EVIDENCE_SOURCE_BINDING_GOVERNANCE_V1"
GUARD = HOME / "v0.2-i4-b-v2-evidence-recovery-live-guard-v2-20261013"
HANDOFF = HOME / "v0.2-i4-b-v3-partial-evidence-recovery-v2-handoff-v1-20261012"
GUARD_V1 = HOME / "v0.2-i4-b-v2-evidence-recovery-live-guard-v1-20261012"
OLD_F02 = Path("/media/sf_Downloads/v3-partial-evidence-recovery-v2-live-guard-ps51-validation-v1-20261012")
ERRATUM = GOVBASE / "v0.2-i4-b-evidence-recovery-hash-binding-erratum-and-reauthorization-governance-v1-20261012"
HANDOFF_BINDING = GOVBASE / "v0.2-i4-b-v2-handoff-successor-path-and-ps51-validation-binding-governance-v1-20261012"
OPERATIONAL = GOVBASE / "v0.2-i4-b-v2-evidence-recovery-operational-staging-live-guard-evidence-and-operator-handoff-binding-governance-v1-20261012"
GUARD_ERRATUM = GOVBASE / "v0.2-i4-b-guard-f02-ps51-encoding-failure-erratum-and-successor-authorization-governance-v1-20261013"
PARTIAL = GOVBASE / "v0.2-i4-b-powered-off-provisioning-partial-failure-recovery-governance-v1-20261011"
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def governance_root(path: Path) -> str:
    rows = bytearray()
    for item in sorted(path.iterdir(), key=lambda value: value.name.encode("utf-8")):
        if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json":
            rows.extend(f"{sha(item)}  {item.name}\n".encode("utf-8"))
    return hashlib.sha256(rows).hexdigest()


def source_root(root: Path, manifest_name: str) -> str:
    manifest = load(root / manifest_name)
    rows = bytearray()
    for name, record in sorted(manifest["files"].items(), key=lambda row: row[0]):
        if sha(root / name) != record["sha256"]:
            return "MISMATCH"
        rows.extend(f"{record['sha256']}  {name}\n".encode("utf-8"))
    return hashlib.sha256(rows).hexdigest()


def tree_root(root: Path, relative: str) -> str:
    manifest = load(root / relative)
    rows = bytearray()
    for record in sorted(manifest["files"], key=lambda row: row["path"]):
        if sha(root / record["path"]) != record["sha256"]:
            return "MISMATCH"
        rows.extend(f"{record['sha256']}  {record['path']}\n".encode("utf-8"))
    return hashlib.sha256(rows).hexdigest()


def classify(evidence: dict) -> str:
    if not evidence.get("identity_valid", True) or not evidence.get("source_digest_valid", True):
        return "UNKNOWN"
    if evidence.get("complete_non_attempt_boundary"):
        return "NOT_ATTEMPTED_PROVEN"
    if evidence.get("destination_created") or evidence.get("valid_consumption_record"):
        return "CONSUMED"
    if evidence.get("attempt_started") and evidence.get("terminal_failure"):
        return "TERMINAL_FAILURE"
    if evidence.get("attempt_started"):
        return "ATTEMPT_STARTED"
    return "UNKNOWN"


checks: list[dict[str, object]] = []


def check(name: str, condition: bool, category: str = "governance") -> None:
    checks.append({"check": name, "category": category, "pass": bool(condition)})


protocol = load(ROOT / "GOVERNANCE_GATE_PROTOCOL.json")
preflight = load(ROOT / "PREFLIGHT_RESULT.json")
state = load(ROOT / "CONSUMPTION_STATE_MODEL.json")
coverage = load(ROOT / "HISTORICAL_SOURCE_COVERAGE_REVIEW.json")
source_decision = load(ROOT / "AUTHORITATIVE_EVIDENCE_SOURCE_DECISION.json")
binding = load(ROOT / "EVIDENCE_SOURCE_BINDING.json")
provenance = load(ROOT / "EVIDENCE_PROVENANCE_CONTRACT.json")
decision = load(ROOT / "SINGLE_USE_STATE_DECISION.json")
prospective = load(ROOT / "PROSPECTIVE_ATTEMPT_LEDGER_REQUIREMENTS.json")
matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
risks = load(ROOT / "RISK_REGISTER.json")
immutability = load(ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json")
prelock = load(ROOT / "PRE_DECISION_LOCK.json")

check("identity", protocol["gate_id"] == IDENTITY)
check("governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
check("fail_closed", protocol["fail_closed"] is True)
check("no_automatic_execution", protocol["automatic_execution"] is False)
check("no_automatic_follow_on", protocol["automatic_follow_on"] is False)
check("writes_before_preflight_zero", protocol["writes_before_preflight_pass"] == preflight["writes_before_preflight_pass"] == 0)
check("preflight_counts", preflight["checks_total"] == len(preflight["checks"]) == preflight["checks_passed"] == 42 and preflight["checks_failed"] == 0)
check("preflight_all_pass", all(row["result"].startswith("PASS") for row in preflight["checks"]))

check("foundation_lock", sha(GOVBASE / "v0.1-foundation-freeze-snapshot-20261009/SNAPSHOT_LOCK.json") == "66ef07d8fa5336ccba83a4d41db42c788e01d455ed4cdc492f4365d51387dbaa", "predecessor")
baselines = [
    (HOME / "v0.2-experimental-research-engine", "governance/i0/SOURCE_MANIFEST.json", "1a14d9c6dca921016acb79831e531308480fa9876e62ded6e1976b51ccbc311c"),
    (HOME / "v0.2-experimental-research-engine-i1", "governance/i1/SOURCE_MANIFEST.json", "be1c40bb8c499672afe8e411dbb235060f1d0666931cdd3282d9a2ae4e3c651b"),
    (HOME / "v0.2-experimental-research-engine-i2", "governance/i2/SOURCE_MANIFEST.json", "bb4abb8d766987a65a96205acca6c74ff2200551d8c925086431e0f27d0ee129"),
    (HOME / "v0.2-experimental-research-engine-i3", "governance/i3/SOURCE_MANIFEST.json", "711d9b026870ff55135c5534f88bfc394d7734ee9943a8063baa189ac270c83e"),
    (HOME / "v0.2-experimental-research-engine-i4", "governance/i4a/SOURCE_MANIFEST.json", "138fd2e59526a663486f54b263b8167283e1736a54fbceb777c7a73dbe02ac34"),
]
for index, entry in enumerate(baselines):
    check(f"baseline_{index}_root", tree_root(entry[0], entry[1]) == entry[2], "predecessor")

for name, path, lock_sha, root_sha in (
    ("partial", PARTIAL, "d1eec39e5243f7cf3396b9ebf29962fc7a2c0e321d87ed9a3d6266ecd04b6fc8", "0568e0bb75f4be39f4321d93cd0c240e39399c32f91932481bc1d14e31a04e51"),
    ("erratum", ERRATUM, "4972f5bb4778d84159c01684c8659777fb285850eeacfc606ce6102184f592e5", "92ae3aa2324508823c266ed9cf81d8cc0e51f073d781b2716104eacf76c3fc0a"),
    ("handoff_binding", HANDOFF_BINDING, "abae4c1be68ac21a771623a0eb6eaf335ef096b4359b6ab85d39bb7abb919c5e", "5ccee22ec84b010dacfac62d1ca67dc1eedff0a81686cce5f50bbd5d05f701cb"),
    ("operational", OPERATIONAL, "f01ec5cdc56021f3565eeaf14b0fc863985bc5715befce66804efe0ede6d224b", "f10641bf6d16dc30a0086c9828e07eeae2c1a834d0369e8c77cfa791853e563c"),
    ("guard_erratum", GUARD_ERRATUM, "79cd829f3061d19eac3edf1bfdfa8e527cea16169a5ec6610a2fce6cf099df95", "02d77700e79059bc8b2551cbeaeebff4ee0f31fd209d147f31c88965d566f6e8"),
):
    check(f"{name}_lock", sha(path / "GOVERNANCE_LOCK.json") == lock_sha, "predecessor")
    check(f"{name}_root", governance_root(path) == root_sha, "predecessor")

check("v2_authorization", sha(ERRATUM / "NEW_RECOVERY_AUTHORIZATION.json") == "50c9bf4bf49cb5a777dce5021628bf3ea96536f549fd71dc68f35c86ed27c653", "predecessor")
check("single_use_boundary", sha(OPERATIONAL / "SINGLE_USE_CONSUMPTION_BOUNDARY.json") == "cb574596b956ed925a4680d610978361905379db5e172ff8e8ec64e68e045027", "predecessor")
check("guard_source", sha(GUARD / "Test-V3PartialEvidenceRecoveryV2LiveGuardsV2.ps1") == "2133e61216f65eee4f396a252ed8881a531ba9f0e668655f5fb6aca2901b4de4", "predecessor")
check("guard_root", source_root(GUARD, "LIVE_GUARD_V2_SOURCE_MANIFEST.json") == "6428cf7324e25e9b27a2fdb5d02963869b5b1abaf58e9adc12fff95596c7d466", "predecessor")
check("guard_digest_lock", sha(GUARD / "LIVE_GUARD_V2_DIGEST_LOCK.json") == "0bf6089ad569b36c8b7a8bb4ffc263ba0fcf320393dcaddce61aaa2b9b65f73c", "predecessor")
check("guard_validation_lock", sha(GUARD / "LIVE_GUARD_V2_VALIDATION_LOCK.json") == "f734c0a7a67c428588f886add6134e9534ca988864b16122d8fd67e7b8545a25", "predecessor")
guard_result = load(GUARD / "GUARD_V2_PS51_PARSE_VALIDATION_RESULT.json")
check("guard_ps51_result", sha(GUARD / "GUARD_V2_PS51_PARSE_VALIDATION_RESULT.json") == "ff5f8bac087c2af2c05058722aff8892fc51d65bdb4acfd9e86a8bf380830e91" and guard_result["parse_error_count"] == 0, "predecessor")
check("guard_frozen", all(not (p.stat().st_mode & 0o222) for p in GUARD.iterdir() if p.is_file()), "predecessor")
check("handoff_source", sha(HANDOFF / "Collect-V3PartialEvidenceRecoveryPackageV2.ps1") == "a03ed48401c25829125bee639059a1cfa600854c64756bd75cf5cf23d5347f7c", "predecessor")
check("handoff_root", source_root(HANDOFF, "HANDOFF_V2_SOURCE_MANIFEST.json") == "0b4ec22e317f8c229cb43fcf0f3e74b0202ff516a60dd156fd04087309e0e08b", "predecessor")
check("handoff_digest_lock", sha(HANDOFF / "HANDOFF_V2_DIGEST_LOCK.json") == "652752b9bf5d0bfe859d80f4a8d6b03ec89f53f51695138ff1b4c60a904ff5ef", "predecessor")
check("handoff_validation_lock", sha(HANDOFF / "HANDOFF_V2_VALIDATION_LOCK.json") == "a594134c42050e082aea1a8161658241c9e52d53ab81079b51f16ff0249d52ee", "predecessor")
check("handoff_frozen", all(not (p.stat().st_mode & 0o222) for p in HANDOFF.iterdir() if p.is_file()), "predecessor")
check("v1_source_preserved", sha(GUARD_V1 / "Test-V3PartialEvidenceRecoveryV2LiveGuards.ps1") == "0a0d7c4a41a9beaf1905d679196b4bf2cac4066bdb14ede48492d71cc4778957", "predecessor")
check("v1_result_preserved", sha(OLD_F02 / "GUARD_PS51_PARSE_VALIDATION_RESULT.json") == "5d37591b651992c745f0d76e6fbc2f20fe22ac4dab61d077080dd4d891d9dbd0", "predecessor")

source_lines = (HANDOFF / "Collect-V3PartialEvidenceRecoveryPackageV2.ps1").read_text(encoding="utf-8").splitlines()
check("switch_line", "ExecuteAuthorizedEvidenceRecoveryV2" in source_lines[321], "state_model")
check("confirmation_line", "Read-Host" in source_lines[366] and "consume the single-use" in source_lines[366], "state_model")
check("destination_create_line", "New-Item -ItemType Directory" in source_lines[474], "state_model")
check("consumption_timestamp_line", "AuthorizationConsumedUtc" in source_lines[476], "state_model")
check("pre_destination_failure_unrecorded", "if (-not $DestinationCreated" in source_lines[282] and "return" in source_lines[283], "state_model")
check("state_count", len(state["canonical_states"]) == 5, "state_model")
check("unknown_current", state["current_state"] == "UNKNOWN" and state["unconsumed_proven"] is False, "state_model")
check("model_gap", state["structural_coverage_gap"]["attempt_marker_before_destination_creation"] is False, "state_model")

check("coverage_sources", coverage["sources_reviewed"] == len(coverage["sources"]) == 9, "coverage")
check("no_negative_source", coverage["sources_sufficient_for_negative_nonoccurrence"] == 0 and coverage["complete_observation_boundary_established"] is False, "coverage")
check("no_positive_source", coverage["sources_sufficient_for_positive_attempt_or_consumption"] == 0, "coverage")
check("source_decision_pass", source_decision["status"] == "PASS_LOCKED_GOVERNANCE_ONLY", "decision")
check("historical_insufficient", source_decision["decisions"]["D1_historical_consumption_evidence_sufficiency"] == "INSUFFICIENT", "decision")
check("collection_not_granted", source_decision["decisions"]["D3_exact_collection_authorization_scope"] == "NOT_GRANTED", "decision")
check("no_bound_source", binding["bound_source"] is None and binding["collection_authority"] == "NOT_GRANTED", "decision")
check("no_return_path", binding["evidence_return_path"] is None and binding["validation_schema"] is None, "decision")
check("negative_standard", provenance["negative_claim_standard"]["destination_absence_alone"] == "REJECTED", "decision")
check("state_unknown", decision["historical_consumption_state"] == "CONSUMPTION_UNKNOWN" and decision["model_state"] == "UNKNOWN", "decision")
check("v2_blocked", decision["existing_recovery_v2_eligibility"] == "BLOCKED_NOT_EXECUTABLE", "decision")
check("next_milestone", decision["exact_next_legally_permissible_milestone"] == "SEPARATE_PROSPECTIVE_RECOVERY_SUCCESSOR_AUTHORIZATION_AND_PRE_SIDE_EFFECT_DURABLE_ATTEMPT_LEDGER_GOVERNANCE", "decision")
check("future_only", prospective["retrospective_effect_on_recovery_v2"] == "NONE" and prospective["operational_authority_granted"] is False, "decision")
check("durable_gate", prospective["mandatory_properties"]["durable_flush_before_continuation"] is True, "decision")
check("crash_terminal", prospective["crash_policy"].startswith("If ATTEMPT_ACCEPTED exists"), "decision")

decisions = {row["id"]: row["decision"] for row in matrix["operations"]}
check("matrix_counts", matrix["operation_count"] == len(decisions) == 20 and matrix["denied"] == 15, "authorization")
check("matrix_unique", len(decisions) == len(matrix["operations"]), "authorization")
check("only_governance_authorized", matrix["authorized_this_milestone"] == 3, "authorization")
check("host_collection_zero", matrix["authorized_future_host_collection"] == 0 and matrix["currently_executable_windows_operations"] == 0, "authorization")
check("live_guard_zero", matrix["currently_executable_live_guard_operations"] == 0, "authorization")
check("recovery_zero", matrix["currently_executable_recovery_operations"] == 0, "authorization")
check("all_denials", all(decisions[f"X{i:02d}"] == "DENIED" for i in range(1, 16)), "authorization")
check("risk_count", risks["risk_count"] == len(risks["risks"]) == 18, "risk")
check("all_risks_fail_closed", risks["all_fail_closed"] and all(row["failure"] == "BLOCK" for row in risks["risks"]), "risk")
check("immutability", immutability["status"] == "PASS" and immutability["writes_to_predecessor_trees"] == 0, "predecessor")
check("prelock_members", all(sha(ROOT / name) == digest for name, digest in prelock["locked_artifacts"].items()), "integrity")
check("prelock_decision", prelock["decision"].endswith("RECOVERY_V2_BLOCKED"), "integrity")

negative = {
    "N01_destination_absent_after_authenticated_failed_attempt": classify({"attempt_started": True, "terminal_failure": True, "destination_created": False}) == "TERMINAL_FAILURE",
    "N02_destination_absent_without_complete_history": classify({"destination_created": False}) == "UNKNOWN",
    "N03_destination_present_package_incomplete": classify({"destination_created": True}) == "CONSUMED",
    "N04_valid_destination_wrong_identity": classify({"destination_created": True, "identity_valid": False}) == "UNKNOWN",
    "N05_missing_attempt_ledger": classify({}) == "UNKNOWN",
    "N06_partial_transcript": classify({"partial_transcript": True}) == "UNKNOWN",
    "N07_disabled_process_audit": classify({"audit_enabled": False}) == "UNKNOWN",
    "N08_rotated_event_logs": classify({"event_log_rotated": True}) == "UNKNOWN",
    "N09_inconsistent_timestamps": classify({"timestamps_consistent": False}) == "UNKNOWN",
    "N10_forged_operator_attestation": classify({"operator_attestation": True}) == "UNKNOWN",
    "N11_untrusted_host_alias": binding["collection_authority"] == "NOT_GRANTED",
    "N12_stale_guard_observation": decision["guard_v2_effect_on_recovery_state"] == "NONE",
    "N13_source_digest_mismatch": classify({"attempt_started": True, "source_digest_valid": False}) == "UNKNOWN",
    "N14_recovery_identity_collision": decisions["X09"] == "DENIED",
    "N15_terminal_authorization_replay": decisions["X09"] == "DENIED",
    "N16_new_ledger_as_historical_evidence": provenance["negative_claim_standard"]["new_ledger_as_historical_proof"] == "REJECTED",
    "N17_new_recovery_identity_without_authorization": prospective["operational_authority_granted"] is False,
    "N18_unknown_promoted_to_pass": decision["existing_recovery_v2_eligibility"] == "BLOCKED_NOT_EXECUTABLE",
    "N19_guard_pass_promoted_to_eligibility": decision["guard_v2_effect_on_recovery_state"] == "NONE",
    "N20_recovery_execution_without_fresh_authorization": decisions["X07"] == "DENIED",
    "N21_unauthorized_windows_collection": decisions["X03"] == "DENIED" and decisions["X14"] == "DENIED",
    "N22_retroactive_reclassification": state["current_state"] == "UNKNOWN",
    "N23_manual_success_message_as_authority": provenance["negative_claim_standard"]["operator_attestation_alone"] == "REJECTED",
    "N24_current_process_list_as_history": coverage["complete_observation_boundary_established"] is False,
}
for name, passed in negative.items():
    check(name, passed, "negative")

for forbidden in (
    "EVIDENCE_COLLECTION_AUTHORIZATION.json", "LIVE_GUARD_EXECUTION_AUTHORIZATION.json",
    "EVIDENCE_RECOVERY_LOCK.json", "RECOVERY_V2_EXECUTION_RESULT.json",
    "A3_A5_EXECUTION_RESULT.json", "VM_BOOT_AUTHORIZATION.json", "I4_B_RUNTIME_RESULT.json",
):
    check(f"forbidden_absent_{forbidden}", not (ROOT / forbidden).exists(), "prohibition")

for value in protocol["authoritative_predecessors"].values():
    if isinstance(value, str) and value.endswith(("_V2", "_V1")):
        continue
    if isinstance(value, str) and len(value) == 64:
        check(f"digest_format_{value[:12]}", HEX64.fullmatch(value) is not None, "integrity")

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
negative_total = sum(row["category"] == "negative" for row in checks)
negative_passed = sum(row["category"] == "negative" and row["pass"] for row in checks)
print(json.dumps({
    "schema_version": 1,
    "gate_id": IDENTITY,
    "validator": "recovery_v2_consumption_provenance_governance_self_test_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "negative_tests_total": negative_total,
    "negative_tests_passed": negative_passed,
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
