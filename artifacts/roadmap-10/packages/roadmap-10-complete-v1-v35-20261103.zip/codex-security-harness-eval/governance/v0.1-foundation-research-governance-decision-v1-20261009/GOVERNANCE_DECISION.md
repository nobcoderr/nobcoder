# V0.1 Foundation Research Governance Decision V1

## Decision

The gate is `PASS_LOCKED`, but no research or product branch is authorized.
The fail-closed current state is `RESEARCH_BLOCKED_NO_PROVEN_REPAIR`; branch A
(`FREEZE_V0_1_CAPACITY_LINE`) is the active default.

Branch B (`NEW_MODEL_FAMILY_DISCOVERY`) and branch C
(`SEMANTIC_TERMINAL_RESEARCH`) each require a new explicit, branch-specific
authorization artifact conforming to the frozen schema. Neither authorization
may create a product candidate, select a policy, rescore RC2, or authorize live
acceptance.

## Locked prohibitions

V0.1.8, RC3, Role Capacity V6 tuning, reservation changes, policy selection,
release, packaging, fresh holdout, and Pilot V3 remain unauthorized.

This gate performed no analysis, scoring, model invocation, network activity,
or product mutation.
