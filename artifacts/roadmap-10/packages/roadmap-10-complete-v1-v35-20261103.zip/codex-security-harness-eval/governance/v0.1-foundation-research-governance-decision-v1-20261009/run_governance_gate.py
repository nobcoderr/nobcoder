#!/usr/bin/env python3
"""Offline fail-closed governance gate for the blocked V0.1 foundation line."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
PROTOCOL = HERE / "GOVERNANCE_GATE_PROTOCOL.json"
SCHEMA = HERE / "BRANCH_AUTHORIZATION_SCHEMA_V1.json"
SCRIPT = Path(__file__).resolve()
SELF_TEST = HERE / "SELF_TEST_RESULT.json"
PRELOCK = HERE / "PRE_DECISION_LOCK.json"
DECISION = HERE / "GOVERNANCE_DECISION.json"
ROADMAP = HERE / "ROADMAP_STATE.json"
REPORT = HERE / "GOVERNANCE_DECISION.md"
LOCK = HERE / "GOVERNANCE_LOCK.json"


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode()


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: Path, value: Any) -> None:
    with path.open("wb") as handle:
        handle.write(canonical_bytes(value))
        handle.flush()
        os.fsync(handle.fileno())


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_authorization(document: dict[str, Any]) -> tuple[bool, str]:
    required = {
        "schema_version", "authorization_id", "gate_id", "branch",
        "authorization_kind", "authorized", "scope", "prohibitions",
    }
    if set(document) != required:
        return False, "FIELD_SET_MISMATCH"
    if document["schema_version"] != 1 or document["gate_id"] != "V0.1_FOUNDATION_RESEARCH_GOVERNANCE_DECISION_V1":
        return False, "IDENTITY_MISMATCH"
    mapping = {
        "B_NEW_MODEL_FAMILY_DISCOVERY": "NEW_MODEL_FAMILY_DISCOVERY_AUTHORIZATION",
        "C_SEMANTIC_TERMINAL_RESEARCH": "SEMANTIC_TERMINAL_RESEARCH_AUTHORIZATION",
    }
    if document["branch"] not in mapping or document["authorization_kind"] != mapping[document["branch"]]:
        return False, "BRANCH_KIND_MISMATCH"
    if document["authorized"] is not True:
        return False, "NOT_AUTHORIZED"
    if not isinstance(document["scope"], list) or not document["scope"]:
        return False, "EMPTY_SCOPE"
    if not isinstance(document["prohibitions"], list) or not document["prohibitions"]:
        return False, "EMPTY_PROHIBITIONS"
    return True, "PASS"


def self_test() -> dict[str, Any]:
    base = {
        "schema_version": 1,
        "authorization_id": "AUTH-TEST-001",
        "gate_id": "V0.1_FOUNDATION_RESEARCH_GOVERNANCE_DECISION_V1",
        "branch": "B_NEW_MODEL_FAMILY_DISCOVERY",
        "authorization_kind": "NEW_MODEL_FAMILY_DISCOVERY_AUTHORIZATION",
        "authorized": True,
        "scope": ["offline discovery protocol only"],
        "prohibitions": ["no product candidate"],
    }
    cases = []
    def record(name: str, document: dict[str, Any], expected: bool) -> None:
        actual, reason = validate_authorization(document)
        cases.append({"case": name, "expected": expected, "actual": actual, "reason": reason, "pass": actual == expected})
    record("valid_branch_B", dict(base), True)
    branch_c = dict(base, branch="C_SEMANTIC_TERMINAL_RESEARCH", authorization_kind="SEMANTIC_TERMINAL_RESEARCH_AUTHORIZATION")
    record("valid_branch_C", branch_c, True)
    record("wrong_kind", dict(base, authorization_kind="SEMANTIC_TERMINAL_RESEARCH_AUTHORIZATION"), False)
    record("not_authorized", dict(base, authorized=False), False)
    record("empty_scope", dict(base, scope=[]), False)
    record("unknown_branch", dict(base, branch="D_PRODUCT", authorization_kind="PRODUCT"), False)
    record("extra_field", dict(base, product_candidate=True), False)
    return {
        "schema_version": 1,
        "gate_id": "V0.1_FOUNDATION_RESEARCH_GOVERNANCE_DECISION_V1",
        "status": "PASS" if all(case["pass"] for case in cases) else "FAIL",
        "cases": cases,
        "model_invocations": 0,
        "network_activity": 0,
    }


def verify_inputs(protocol: dict[str, Any]) -> list[dict[str, Any]]:
    verified = []
    for item in protocol["authoritative_inputs"]:
        path = Path(item["path"])
        actual = sha256_file(path)
        if actual != item["sha256"]:
            raise RuntimeError(f"authoritative input drift: {item['kind']}")
        verified.append({**item, "verified": True})
    design = load_json(Path(protocol["authoritative_inputs"][3]["path"]))
    for key, expected in protocol["required_input_state"].items():
        if design.get(key) != expected:
            raise RuntimeError(f"required state mismatch: {key}")
    return verified


def seal() -> dict[str, Any]:
    protocol = load_json(PROTOCOL)
    verified = verify_inputs(protocol)
    if load_json(SELF_TEST)["status"] != "PASS":
        raise RuntimeError("self-test failed")
    files = [
        {"kind": "PROTOCOL", "path": str(PROTOCOL), "sha256": sha256_file(PROTOCOL)},
        {"kind": "AUTHORIZATION_SCHEMA", "path": str(SCHEMA), "sha256": sha256_file(SCHEMA)},
        {"kind": "GATE_IMPLEMENTATION", "path": str(SCRIPT), "sha256": sha256_file(SCRIPT)},
        {"kind": "SELF_TEST", "path": str(SELF_TEST), "sha256": sha256_file(SELF_TEST)},
        *verified,
    ]
    lock = {
        "schema_version": 1,
        "gate_id": protocol["gate_id"],
        "status": "PRE_DECISION_PASS_LOCKED",
        "files": files,
        "manifest_sha256": hashlib.sha256(canonical_bytes(files)).hexdigest(),
        "model_invocations": 0,
        "network_activity": 0,
    }
    write_json(PRELOCK, lock)
    for path in (PROTOCOL, SCHEMA, SCRIPT, SELF_TEST, PRELOCK):
        os.chmod(path, 0o444)
    return lock


def verify_prelock() -> None:
    lock = load_json(PRELOCK)
    if lock["status"] != "PRE_DECISION_PASS_LOCKED":
        raise RuntimeError("pre-decision lock status invalid")
    if hashlib.sha256(canonical_bytes(lock["files"])).hexdigest() != lock["manifest_sha256"]:
        raise RuntimeError("pre-decision manifest drift")
    for item in lock["files"]:
        if sha256_file(Path(item["path"])) != item["sha256"]:
            raise RuntimeError(f"pre-decision file drift: {item['path']}")


def decide_once() -> dict[str, Any]:
    if any(path.exists() for path in (DECISION, ROADMAP, REPORT, LOCK)):
        raise RuntimeError("governance identity already consumed")
    verify_prelock()
    protocol = load_json(PROTOCOL)
    verify_inputs(protocol)
    decision = {
        "schema_version": 1,
        "gate_id": protocol["gate_id"],
        "status": "PASS_LOCKED",
        "CURRENT_STATE": "RESEARCH_BLOCKED_NO_PROVEN_REPAIR",
        "SELECTED_BRANCH": "A_FREEZE_V0_1_CAPACITY_LINE",
        "selection_basis": "FAIL_CLOSED_DEFAULT_WITHOUT_NEW_EXPLICIT_BRANCH_AUTHORIZATION",
        "V5_PATH": "CLOSED_DESIGN_FAMILY_NONVIABLE",
        "NEW_MODEL_FAMILY_DISCOVERY": "NOT_AUTHORIZED",
        "SEMANTIC_TERMINAL_RESEARCH": "NOT_AUTHORIZED",
        "V0_1_8": "NOT_AUTHORIZED",
        "RC3": "NOT_AUTHORIZED",
        "ROLE_CAPACITY_V6": "NOT_AUTHORIZED",
        "POLICY_SELECTION": "NOT_AUTHORIZED",
        "RELEASE_PACKAGING": "DENIED",
        "FRESH_HOLDOUT": "DENIED",
        "PILOT_V3": "DENIED",
        "CLAIM": "INSUFFICIENT_DATA",
        "required_next_event": "NEW_EXPLICIT_GOVERNANCE_BRANCH_AUTHORIZATION_OR_CONTINUED_FREEZE",
        "model_invocations": 0,
        "network_activity": 0,
    }
    roadmap = {
        "schema_version": 1,
        "foundation_line": "V0.1",
        "current_node": "NO_AUTHORIZED_REPAIR_PATH",
        "history": [
            "V0.1.7_RC2_VALID_FAIL",
            "RC2_POSTMORTEM_PASS_LOCKED",
            "ROLE_CAPACITY_REQUALIFICATION_V1_DESIGN_FAIL_LOCKED",
            "V5_DESIGN_POSTMORTEM_PASS_LOCKED",
            "RESEARCH_BLOCKED_NO_PROVEN_REPAIR"
        ],
        "available_governance_branches": [
            {"branch": "A_FREEZE_V0_1_CAPACITY_LINE", "status": "ACTIVE_DEFAULT"},
            {"branch": "B_NEW_MODEL_FAMILY_DISCOVERY", "status": "AWAITING_EXPLICIT_AUTHORIZATION"},
            {"branch": "C_SEMANTIC_TERMINAL_RESEARCH", "status": "AWAITING_EXPLICIT_AUTHORIZATION"}
        ],
        "product_candidate_authorized": False,
        "live_execution_authorized": False
    }
    report = """# V0.1 Foundation Research Governance Decision V1

## Decision

The gate is `PASS_LOCKED`, but no research or product branch is authorized.
The fail-closed current state is `RESEARCH_BLOCKED_NO_PROVEN_REPAIR`; branch A
(`FREEZE_V0_1_CAPACITY_LINE`) is the active default.

Branch B (`NEW_MODEL_FAMILY_DISCOVERY`) and branch C
(`SEMANTIC_TERMINAL_RESEARCH`) each require a new explicit, branch-specific
authorization artifact conforming to the frozen schema. Neither authorization
may create a product candidate, select a policy, rescore RC2, or authorize live
acceptance.

## Locked prohibitions

V0.1.8, RC3, Role Capacity V6 tuning, reservation changes, policy selection,
release, packaging, fresh holdout, and Pilot V3 remain unauthorized.

This gate performed no analysis, scoring, model invocation, network activity,
or product mutation.
"""
    with tempfile.TemporaryDirectory(prefix=".decision-staging-", dir=HERE) as temporary:
        staging = Path(temporary)
        write_json(staging / DECISION.name, decision)
        write_json(staging / ROADMAP.name, roadmap)
        with (staging / REPORT.name).open("w", encoding="utf-8") as handle:
            handle.write(report)
            handle.flush()
            os.fsync(handle.fileno())
        for target in (DECISION, ROADMAP, REPORT):
            os.replace(staging / target.name, target)
    files = [
        {"path": str(path), "sha256": sha256_file(path), "bytes": path.stat().st_size}
        for path in (DECISION, ROADMAP, REPORT)
    ]
    lock = {
        "schema_version": 1,
        "gate_id": protocol["gate_id"],
        "status": "PASS_LOCKED",
        "protocol_sha256": sha256_file(PROTOCOL),
        "authorization_schema_sha256": sha256_file(SCHEMA),
        "implementation_sha256": sha256_file(SCRIPT),
        "pre_decision_lock_sha256": sha256_file(PRELOCK),
        "files": files,
        "artifact_root_sha256": hashlib.sha256(canonical_bytes(files)).hexdigest(),
        "current_state": decision["CURRENT_STATE"],
        "selected_branch": decision["SELECTED_BRANCH"],
        "product_candidate_authorized": False,
        "model_invocations": 0,
        "network_activity": 0
    }
    write_json(LOCK, lock)
    for path in (DECISION, ROADMAP, REPORT, LOCK):
        os.chmod(path, 0o444)
    return lock


def verify() -> dict[str, Any]:
    verify_prelock()
    lock = load_json(LOCK)
    errors = []
    for item in lock["files"]:
        path = Path(item["path"])
        if not path.exists() or sha256_file(path) != item["sha256"]:
            errors.append(f"digest:{path}")
        elif path.stat().st_mode & 0o222:
            errors.append(f"writable:{path}")
    if hashlib.sha256(canonical_bytes(lock["files"])).hexdigest() != lock["artifact_root_sha256"]:
        errors.append("artifact_root_sha256")
    if LOCK.stat().st_mode & 0o222:
        errors.append("writable:GOVERNANCE_LOCK.json")
    return {"status": "PASS" if not errors else "FAIL", "errors": errors}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("self-test", "seal", "decide", "verify"))
    args = parser.parse_args()
    if args.mode == "self-test":
        result = self_test()
        write_json(SELF_TEST, result)
    elif args.mode == "seal":
        result = seal()
    elif args.mode == "decide":
        result = decide_once()
    else:
        result = verify()
    print(json.dumps(result, sort_keys=True))
    return 0 if result.get("status") in {"PASS", "PASS_LOCKED", "PRE_DECISION_PASS_LOCKED"} else 1


if __name__ == "__main__":
    sys.exit(main())
