#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    manifest = load_json(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load_json(PACKAGE / "GOVERNANCE_LOCK.json")
    checks: list[dict[str, Any]] = []

    def check(identity: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    listed: list[Path] = []
    for item in manifest["members"]:
        path = PACKAGE / item["path"]
        listed.append(path)
        check(
            f"F_MEMBER_{item['path']}",
            path.is_file() and not path.is_symlink() and sha256_file(path) == item["sha256"]
            and path.stat().st_size == item["bytes"] and is_read_only(path),
        )
    check("F001_COUNT", len(listed) == manifest["member_count"])
    check("F002_ROOT", package_root(listed) == manifest["canonical_root_sha256"])
    check("F003_LOCK_BINDING", lock["manifest_sha256"] == sha256_file(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json") and lock["canonical_root_sha256"] == manifest["canonical_root_sha256"])
    check("F004_STATUS", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY" and lock["decision"] == DECISION)
    check("F005_LOCK_READ_ONLY", is_read_only(PACKAGE / "GOVERNANCE_LOCK.json") and is_read_only(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json"))
    check("F006_V23_UNCHANGED", normative_tree(V23) == V23_TREE, normative_tree(V23))
    check("F007_V23_PRELOCK_UNCHANGED", normative_tree(V23 / "results/prelock") == V23_PRELOCK_TREE)
    check("F008_V22_UNCHANGED", normative_tree(V22) == V22_TREE)
    terminal = load_json(V23 / PATHS["terminal"])
    execution = terminal.get("execution_state", {})
    check("F009_NO_EXECUTION", execution.get("static_lock") == "NOT_ISSUED" and execution.get("attempt") == execution.get("worker_invocation") == execution.get("codex_as_worker_invocation") == "0/1" and execution.get("attempt_marker") == execution.get("runtime_evidence") == "ABSENT")
    check("F010_FAILURE_EVIDENCE_READ_ONLY", all(is_read_only(V23 / PATHS[name]) for name in ("terminal", "manifest", "freeze", "unit", "nested_result", "nested_snapshot", "nested_stderr")))
    check("F011_V24_ABSENT", not Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v24-20261101").exists())
    failed = [item["id"] for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "FINAL_GOVERNANCE_FREEZE_VERIFICATION",
        "governance_identity": GOVERNANCE_ID,
        "checks": checks,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "governance_lock_sha256": sha256_file(PACKAGE / "GOVERNANCE_LOCK.json"),
    }
    write_json_once(PACKAGE / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json", result)
    set_read_only(PACKAGE / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json")
    os.chmod(PACKAGE, 0o555)
    print(f"FINAL_FREEZE_VERIFICATION={result['status']} {len(checks)-len(failed)}/{len(checks)} LOCK_SHA256={result['governance_lock_sha256']}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
