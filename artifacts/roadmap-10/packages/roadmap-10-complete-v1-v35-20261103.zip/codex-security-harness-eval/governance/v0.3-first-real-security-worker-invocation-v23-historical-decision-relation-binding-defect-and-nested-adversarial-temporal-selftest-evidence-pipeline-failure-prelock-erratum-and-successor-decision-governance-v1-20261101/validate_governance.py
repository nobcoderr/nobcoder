#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    assert_v23_frozen()
    assert_v22_integrity()
    checks: list[dict[str, Any]] = []

    def check(identity: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("G001_DOCUMENTS", all((PACKAGE / name).is_file() for name in DOCUMENT_FILES))
    unit = load_json(V23 / PATHS["unit"])
    terminal = load_json(V23 / PATHS["terminal"])
    check("G002_STATE", terminal.get("status") == V23_STATE and unit.get("validation_counts") == {"failed": 3, "passed": 254, "total": 257})
    check("G003_FAILURE_SET", unit.get("failure_ids") == ["U049_PREDECESSOR", "U087_V19_ALL_ADVERSARIAL_SELFTESTS_PASS", "U091_V19_SELFTEST_TRACE_DENOMINATOR"])
    execution = terminal.get("execution_state", {})
    check("G004_NO_EXECUTION", execution == {"attempt": "0/1", "attempt_marker": "ABSENT", "codex_as_worker_invocation": "0/1", "runtime_evidence": "ABSENT", "static_lock": "NOT_ISSUED", "worker_invocation": "0/1"})
    for key in ("terminal", "manifest", "freeze", "unit", "nested_result", "nested_events", "nested_root", "nested_snapshot", "nested_stderr"):
        check(f"G_HASH_{key}", sha256_file(V23 / PATHS[key]) == HASHES[key])

    adjudication = load_json(PACKAGE / "V23_TWO_FAMILY_FAILURE_ADJUDICATION.json")
    check("G005_HISTORICAL_RELATION_DEFECT", adjudication.get("HISTORICAL_DECISION_RELATION_BINDING_DEFECT") == "YES")
    canonical_decision = load_json(CANONICAL_V20_DECISION)
    check(
        "G006_CANONICAL_V20_DECISION",
        sha256_file(CANONICAL_V20_DECISION) == CANONICAL_V20_DECISION_SHA256
        and sha256_file(CANONICAL_V20_GOVERNANCE_LOCK) == CANONICAL_V20_GOVERNANCE_LOCK_SHA256
        and canonical_decision.get("decision") == "TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V21_CONDITIONALLY",
    )
    invocation_source = (V23 / PATHS["invocation"]).read_text(encoding="utf-8")
    check(
        "G007_STALE_V23_VERIFIER_RELATION",
        'contracts/V20_TERMINAL_AND_V23_SUCCESSOR_DECISION.json' in invocation_source
        and 'TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V23_CONDITIONALLY' in invocation_source,
    )
    unified = load_json(V23 / PATHS["unified_generation"])
    historical = next(row for row in unified["members"] if row.get("logical_artifact_identity") == "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION")
    check(
        "G008_UNIFIED_GENERATION_CANONICAL_HISTORY",
        historical.get("canonical_locator") == str(CANONICAL_V20_DECISION)
        and historical.get("sha256") == CANONICAL_V20_DECISION_SHA256
        and historical.get("relationship") == "TRANSITIVE_HISTORY",
    )
    relation = {
        "logical_decision_identity": "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION",
        "governance_owner": "V20_GOVERNANCE",
        "artifact_role": "TERMINAL_SUCCESSOR_DECISION",
        "relation_semantics": "TERMINALIZE_V20_AUTHORIZE_V21",
        "artifact_sha256": CANONICAL_V20_DECISION_SHA256,
        "governance_lock_sha256": CANONICAL_V20_GOVERNANCE_LOCK_SHA256,
        "selection_method": "EXACT_GOVERNANCE_BOUND_LOGICAL_IDENTITY",
    }
    check("G009_RELATION_REGISTRY_ORACLE", historical_relation_verdict(relation).get("status") == "PASS")
    pass_ids = {item["id"] for item in unit["checks"] if item.get("status") == "PASS"}
    check("G010_PREDECESSOR_AND_TRANSITIVE_RESOLVER_NOT_DEFECTIVE", {"U_PREDECESSOR_EXACT_GOVERNANCE_V18", "U_EXTERNAL_000_EXACT_RESOLUTION"} <= pass_ids)

    nested = load_json(V23 / PATHS["nested_result"])
    snapshot = load_json(V23 / PATHS["nested_snapshot"])
    events = load_jsonl(V23 / PATHS["nested_events"])
    trace_dir = V23 / "results/prelock/adversarial-selftests-run-0001/nested-0001/traces"
    trace_ids = sorted(int(path.name.rsplit(".", 1)[1]) for path in trace_dir.glob("trace.*"))
    check("G011_NESTED_EXIT", nested.get("observer_exit_code") == 2 and nested.get("observer_exit_reason") == "OBSERVER_INTERNAL_ERROR")
    check("G012_NESTED_TYPED_ERROR", snapshot.get("error") == {"type": "JSONDecodeError", "message": "Expecting value: line 1 column 1 (char 0)"})
    check("G013_NESTED_TRACE_SET", trace_ids == [89820, 89821, 89822] and nested.get("lineage_relevant_trace_visible_identity_count") == 3)
    check("G014_NESTED_ABORT_BEFORE_ACCOUNTING", nested.get("identity_capture_attempt_count") == 0 and nested.get("valid_temporal_mapping_count") == 0 and nested.get("checks", {}).get("trace_denominator_independently_enumerated") is False)
    check("G015_READY_ONLY_EVENT", len(events) == 1 and events[0].get("record_type") == "TEMPORAL_PROCESS_IDENTITY_OBSERVER_READINESS")
    check("G016_ROOT_FINAL_VALID_BUT_UNBOUND", load_json(V23 / PATHS["nested_root"]).get("root_pid") == 89818 and not (V23 / "results/prelock/adversarial-selftests-run-0001/nested-0001/root-bound.json").exists())
    non_nested = ["long-lived", "sequential", "overlapping", "immediate"]
    non_nested_results = [load_json(V23 / f"results/prelock/adversarial-selftests-run-0001/{mode}-0001-result.json") for mode in non_nested]
    check(
        "G017_NON_NESTED_PASS_N_OF_N",
        all(row.get("status") == "PASS" and row.get("valid_temporal_mapping_count") == row.get("lineage_relevant_trace_visible_identity_count") and row.get("missing_mapping_count") == row.get("ambiguous_mapping_count") == 0 for row in non_nested_results),
    )

    runner_source = (V23 / PATHS["runner"]).read_text(encoding="utf-8")
    observer_source = (V23 / PATHS["observer"]).read_text(encoding="utf-8")
    boundary_source = (V23 / PATHS["workspace_boundary"]).read_text(encoding="utf-8")
    check("G018_NONATOMIC_FINAL_PATH_PRODUCER", 'append_only_json(paths["root"]' in runner_source and 'path.open("x"' in boundary_source and "json.dump(payload" in boundary_source)
    check("G019_EXISTENCE_BASED_CONSUMER", 'root_record.is_file()' in observer_source and 'json.loads(root_record.read_text' in observer_source)
    check(
        "G020_PIPELINE_CAUSAL_ADJUDICATION",
        adjudication.get("NESTED_ADVERSARIAL_TEMPORAL_SELFTEST_EVIDENCE_PIPELINE_FAILURE") == "YES"
        and adjudication["nested_family"]["evidence_transport_publication_defect"] == "YES"
        and adjudication["nested_family"]["parser_consumer_completion_gate_defect"] == "YES"
        and adjudication["nested_family"]["observer_capture_implementation_defect"] == "NOT_ESTABLISHED"
        and adjudication["nested_family"]["nested_n_of_n"] == "NOT_PROVEN",
    )
    check("G021_RUNTIME_NOT_INFERRED", adjudication["runtime_adjudication"] == {"V23_SECURITY_WORKER_RUNTIME": "NOT_ESTABLISHED", "V23_CODEX_RUNTIME": "NOT_ESTABLISHED", "TEMPORAL_RUNTIME": "NOT_ESTABLISHED", "PROCESS_LINEAGE": "NOT_PROVEN", "PRODUCER_AUTHORIZATION": "NOT_PROVEN", "CONFINEMENT": "NOT_PROVEN"})
    decision = load_json(PACKAGE / "V23_TERMINAL_AND_V24_SUCCESSOR_DECISION.json")
    check("G022_DECISION", decision.get("decision") == DECISION and decision.get("v23_continuation") == "PROHIBITED" and decision.get("v24") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    telemetry_contract = load_json(PACKAGE / "ADVERSARIAL_SELFTEST_TRANSACTIONAL_TELEMETRY_CONTRACT.json")
    check("G023_SUCCESSOR_TELEMETRY_CONTRACT", telemetry_contract.get("failure_envelope_required") is True and telemetry_contract.get("strict_coverage") == {"valid": "N", "trace_visible": "N", "missing": 0, "ambiguous": 0, "percentage_thresholds": "PROHIBITED"})
    check("G024_V23_TREE", normative_tree(V23) == V23_TREE, normative_tree(V23))
    check("G025_V23_PRELOCK_TREE", normative_tree(V23 / "results/prelock") == V23_PRELOCK_TREE)
    check("G026_V22_TREE", normative_tree(V22) == V22_TREE)

    failed = [item["id"] for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "PRIMARY_GOVERNANCE_VALIDATION",
        "governance_identity": GOVERNANCE_ID,
        "checks": checks,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
    }
    write_json_once(PACKAGE / VALIDATION_FILES[0], result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failed)}/{len(checks)}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
