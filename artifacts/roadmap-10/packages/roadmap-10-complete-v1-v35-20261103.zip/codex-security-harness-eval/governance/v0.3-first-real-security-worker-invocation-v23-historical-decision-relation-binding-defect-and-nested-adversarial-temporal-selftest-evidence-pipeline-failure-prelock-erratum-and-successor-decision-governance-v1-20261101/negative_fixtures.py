#!/usr/bin/env python3
from copy import deepcopy
from governance_common import *


def main() -> None:
    assert_v23_frozen()
    assert_v22_integrity()
    cases: list[dict[str, Any]] = []

    def case(identity: str, verdict: Mapping[str, Any], expected_pass: bool) -> None:
        actual_pass = verdict.get("status") == "PASS"
        cases.append({"id": identity, "status": "PASS" if actual_pass is expected_pass else "FAIL", "expected_pass": expected_pass, "verdict": verdict})

    relation = {
        "logical_decision_identity": "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION",
        "governance_owner": "V20_GOVERNANCE",
        "artifact_role": "TERMINAL_SUCCESSOR_DECISION",
        "relation_semantics": "TERMINALIZE_V20_AUTHORIZE_V21",
        "artifact_sha256": CANONICAL_V20_DECISION_SHA256,
        "governance_lock_sha256": CANONICAL_V20_GOVERNANCE_LOCK_SHA256,
        "selection_method": "EXACT_GOVERNANCE_BOUND_LOGICAL_IDENTITY",
    }
    case("N001_EXACT_HISTORICAL_RELATION", historical_relation_verdict(relation), True)
    for identity, changes in {
        "N002_STALE_V20_TO_V23_RELATION": {"relation_semantics": "TERMINALIZE_V20_AUTHORIZE_V23"},
        "N003_VERSION_NUMBER_INFERENCE": {"selection_method": "VERSION_NUMBER_ARITHMETIC"},
        "N004_WRONG_GOVERNANCE_OWNER": {"governance_owner": "V23_GOVERNANCE"},
        "N005_WRONG_DECISION_DIGEST": {"artifact_sha256": "0" * 64},
        "N006_WRONG_GOVERNANCE_LOCK": {"governance_lock_sha256": "f" * 64},
        "N007_SYNTHETIC_LOGICAL_IDENTITY": {"logical_decision_identity": "V20_TERMINAL_AND_V23_SYNTHETIC_DECISION"},
        "N008_NEAREST_ARTIFACT_SELECTION": {"selection_method": "NEAREST_FILENAME"},
    }.items():
        mutated = {**relation, **changes}
        case(identity, historical_relation_verdict(mutated), False)

    telemetry = {
        "publication": "ATOMIC_RENAME_AFTER_FSYNC",
        "telemetry_complete": False,
        "consumer_requires_completion": True,
        "raw_output_sha256": "1" * 64,
        "raw_output_bytes": 17,
        "failure_envelope": {
            "fixture_identity": "nested-0001",
            "observer_exit_code": 2,
            "failure_stage": "TELEMETRY_PARSE",
            "failure_reason": "MALFORMED_JSON",
            "classification": "TELEMETRY_PARSER_FAILURE",
            "available_counters": {
                "trace_identity_count": 3,
                "capture_attempt_count": 0,
                "valid_mapping_count": 0,
                "missing_mapping_count": 0,
                "ambiguous_mapping_count": 0,
            },
        },
    }
    case("N009_TYPED_PARSER_FAILURE_ENVELOPE", telemetry_publication_verdict(telemetry), True)
    observer_failure = deepcopy(telemetry)
    observer_failure["failure_envelope"].update({"failure_stage": "OBSERVER_RUNTIME", "failure_reason": "NETLINK_SUBSCRIPTION_FAILED", "classification": "OBSERVER_EXECUTION_FAILURE"})
    case("N010_TYPED_OBSERVER_FAILURE_ENVELOPE", telemetry_publication_verdict(observer_failure), True)
    for identity, mutator in {
        "N011_DIRECT_FINAL_PATH_PUBLICATION": lambda row: row.update(publication="DIRECT_FINAL_PATH_WRITE"),
        "N012_CONSUMER_ACCEPTS_EXISTENCE": lambda row: row.update(consumer_requires_completion=False),
        "N013_MISSING_RAW_DIGEST": lambda row: row.update(raw_output_sha256=None),
        "N014_MISSING_RAW_SIZE": lambda row: row.update(raw_output_bytes=None),
        "N015_MISSING_FAILURE_STAGE": lambda row: row["failure_envelope"].update(failure_stage=None),
        "N016_MISSING_COUNTER": lambda row: row["failure_envelope"]["available_counters"].pop("trace_identity_count"),
        "N017_UNTYPED_CLASSIFICATION": lambda row: row["failure_envelope"].update(classification="OBSERVER_BROKEN"),
    }.items():
        mutated = deepcopy(telemetry)
        mutator(mutated)
        case(identity, telemetry_publication_verdict(mutated), False)

    def n_of_n(trace_count: int, valid: int, missing: int, ambiguous: int) -> dict[str, Any]:
        passed = trace_count == valid and missing == 0 and ambiguous == 0
        return {"status": "PASS" if passed else "FAIL_CLOSED", "trace": trace_count, "valid": valid, "missing": missing, "ambiguous": ambiguous}

    case("N018_NESTED_N_OF_N", n_of_n(3, 3, 0, 0), True)
    case("N019_NESTED_N_MINUS_ONE", n_of_n(3, 2, 1, 0), False)
    case("N020_NESTED_AMBIGUOUS", n_of_n(3, 3, 0, 1), False)
    case("N021_V23_UNCHANGED", {"status": "PASS" if normative_tree(V23) == V23_TREE else "FAIL_CLOSED"}, True)
    case("N022_V22_UNCHANGED", {"status": "PASS" if normative_tree(V22) == V22_TREE else "FAIL_CLOSED"}, True)

    failed = [item["id"] for item in cases if item["status"] != "PASS"]
    result = {
        "record_type": "NEGATIVE_GOVERNANCE_FIXTURES",
        "governance_identity": GOVERNANCE_ID,
        "cases": cases,
        "validation_counts": {"total": len(cases), "passed": len(cases) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
    }
    write_json_once(PACKAGE / VALIDATION_FILES[1], result)
    print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['status']} {len(cases)-len(failed)}/{len(cases)}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
