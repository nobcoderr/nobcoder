#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath

from governance_common import (
    CANONICAL_V20_DECISION,
    CANONICAL_V20_DECISION_SHA256,
    CANONICAL_V20_GOVERNANCE_LOCK,
    CANONICAL_V20_GOVERNANCE_LOCK_SHA256,
    DECISION,
    DOCUMENT_FILES,
    GOVERNANCE_ID,
    PACKAGE,
    PATHS,
    VALIDATION_FILES,
    V22,
    V22_TREE,
    V23,
    V23_PRELOCK_TREE,
    V23_STATE,
    V23_TREE,
    write_json_once,
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def tree(root: Path) -> tuple[int, str]:
    rows = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"symlink:{path}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            rows.append((tuple(part.encode("utf-8") for part in PurePosixPath(relative).parts), relative, digest(path)))
    rows.sort(key=lambda row: row[0])
    material = b"".join(relative.encode() + b"\0" + value.encode("ascii") + b"\n" for _, relative, value in rows)
    return len(rows), hashlib.sha256(material).hexdigest()


def main() -> None:
    checks = []

    def check(identity, condition, evidence=None):
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("I001_PRIMARY", load(PACKAGE / VALIDATION_FILES[0]).get("status") == "PASS")
    check("I002_NEGATIVE", load(PACKAGE / VALIDATION_FILES[1]).get("status") == "PASS")
    check("I003_DOCUMENTS", all((PACKAGE / name).is_file() for name in DOCUMENT_FILES))
    check("I004_V23_TREE", tree(V23) == V23_TREE, tree(V23))
    check("I005_V23_PRELOCK_TREE", tree(V23 / "results/prelock") == V23_PRELOCK_TREE, tree(V23 / "results/prelock"))
    check("I006_V22_TREE", tree(V22) == V22_TREE, tree(V22))

    terminal = load(V23 / PATHS["terminal"])
    unit = load(V23 / PATHS["unit"])
    check("I007_STATE", terminal.get("status") == V23_STATE and unit.get("validation_counts") == {"failed": 3, "passed": 254, "total": 257})
    check("I008_FAILURE_SET", unit.get("failure_ids") == ["U049_PREDECESSOR", "U087_V19_ALL_ADVERSARIAL_SELFTESTS_PASS", "U091_V19_SELFTEST_TRACE_DENOMINATOR"])
    state = terminal.get("execution_state", {})
    check("I009_NO_EXECUTION", state.get("static_lock") == "NOT_ISSUED" and state.get("attempt") == state.get("worker_invocation") == state.get("codex_as_worker_invocation") == "0/1" and state.get("attempt_marker") == state.get("runtime_evidence") == "ABSENT")

    canonical = load(CANONICAL_V20_DECISION)
    check("I010_CANONICAL_DECISION_DIGEST", digest(CANONICAL_V20_DECISION) == CANONICAL_V20_DECISION_SHA256)
    check("I011_CANONICAL_DECISION_SEMANTICS", canonical.get("decision") == "TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V21_CONDITIONALLY" and canonical.get("v20_continuation") == "PROHIBITED")
    check("I012_CANONICAL_GOVERNANCE_OWNER", digest(CANONICAL_V20_GOVERNANCE_LOCK) == CANONICAL_V20_GOVERNANCE_LOCK_SHA256 and load(CANONICAL_V20_GOVERNANCE_LOCK).get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    invocation = (V23 / PATHS["invocation"]).read_text(encoding="utf-8")
    check("I013_V23_STALE_RELATION_SOURCE", 'V20_TERMINAL_AND_V23_SUCCESSOR_DECISION.json' in invocation and 'TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V23_CONDITIONALLY' in invocation)
    check("I014_STALE_ARTIFACT_ABSENT", not (V23 / "contracts/V20_TERMINAL_AND_V23_SUCCESSOR_DECISION.json").exists())
    unified = load(V23 / PATHS["unified_generation"])
    rows = [row for row in unified.get("members", []) if row.get("logical_artifact_identity") == "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION"]
    check("I015_UNIFIED_CANONICAL_RELATION", len(rows) == 1 and rows[0].get("canonical_locator") == str(CANONICAL_V20_DECISION) and rows[0].get("sha256") == CANONICAL_V20_DECISION_SHA256)

    nested_root = V23 / "results/prelock/adversarial-selftests-run-0001/nested-0001"
    snapshot = load(nested_root / "snapshot.json")
    result = load(V23 / PATHS["nested_result"])
    ready = load(nested_root / "ready.json")
    root = load(nested_root / "root.json")
    event_lines = [line for line in (nested_root / "events.jsonl").read_text(encoding="utf-8").splitlines() if line]
    trace_paths = sorted((nested_root / "traces").glob("trace.*"), key=lambda path: int(path.name.rsplit(".", 1)[1]))
    trace_ids = [int(path.name.rsplit(".", 1)[1]) for path in trace_paths]
    check("I016_READY", ready.get("state") == "OBSERVER_READY" and len(event_lines) == 1)
    check("I017_TRACE_DENOMINATOR_RAW", trace_ids == [89820, 89821, 89822] and sum(path.stat().st_size for path in trace_paths) == 798178)
    check("I018_OBSERVER_FAILURE", result.get("observer_exit_code") == 2 and snapshot.get("observer_exit_reason") == "OBSERVER_INTERNAL_ERROR")
    error = snapshot.get("error", {})
    check("I019_PARSE_FAILURE", error.get("type") == "JSONDecodeError" and error.get("message") == "Expecting value: line 1 column 1 (char 0)")
    check("I020_FINAL_ROOT_VALID", root.get("root_pid") == 89818 and (nested_root / "root.json").stat().st_size == 145)
    check("I021_ROOT_NOT_BOUND", not (nested_root / "root-bound.json").exists())
    accounting = snapshot.get("coverage_accounting", {})
    check("I022_ACCOUNTING_ABORTED", accounting.get("coverage_complete") is False and accounting.get("identity_capture_attempt_count") == 0 and result.get("checks", {}).get("trace_denominator_independently_enumerated") is False)

    runner = (V23 / PATHS["runner"]).read_text(encoding="utf-8")
    boundary = (V23 / PATHS["workspace_boundary"]).read_text(encoding="utf-8")
    observer = (V23 / PATHS["observer"]).read_text(encoding="utf-8")
    producer_create = boundary.index('path.open("x"')
    producer_serialize = boundary.index("json.dump(payload")
    consumer_exists = observer.index("root_record.is_file()")
    consumer_parse = observer.index("json.loads(root_record.read_text")
    check("I023_NONATOMIC_PUBLICATION_ORDER", producer_create < producer_serialize and 'append_only_json(paths["root"]' in runner)
    check("I024_PREMATURE_CONSUMER_ORDER", consumer_exists < consumer_parse and "completion" not in observer[consumer_exists:consumer_parse])

    adjudication = load(PACKAGE / "V23_TWO_FAMILY_FAILURE_ADJUDICATION.json")
    check("I025_TWO_FAMILIES", adjudication.get("HISTORICAL_DECISION_RELATION_BINDING_DEFECT") == "YES" and adjudication.get("NESTED_ADVERSARIAL_TEMPORAL_SELFTEST_EVIDENCE_PIPELINE_FAILURE") == "YES")
    nested_adjudication = adjudication.get("nested_family", {})
    check("I026_CAUSE_BOUND", nested_adjudication.get("cause") == "NON_ATOMIC_FINAL_PATH_PUBLICATION_AND_PREMATURE_EXISTENCE_BASED_JSON_CONSUMPTION")
    check("I027_NO_CAPTURE_DEFECT_PROMOTION", nested_adjudication.get("observer_capture_implementation_defect") == "NOT_ESTABLISHED" and nested_adjudication.get("nested_process_topology_defect") == "NOT_ESTABLISHED")
    check("I028_STRICT_N_OF_N_NOT_PROVEN", nested_adjudication.get("nested_n_of_n") == "NOT_PROVEN")
    check("I029_RUNTIME_UNKNOWN", adjudication.get("runtime_adjudication") == {"V23_SECURITY_WORKER_RUNTIME": "NOT_ESTABLISHED", "V23_CODEX_RUNTIME": "NOT_ESTABLISHED", "TEMPORAL_RUNTIME": "NOT_ESTABLISHED", "PROCESS_LINEAGE": "NOT_PROVEN", "PRODUCER_AUTHORIZATION": "NOT_PROVEN", "CONFINEMENT": "NOT_PROVEN"})
    decision = load(PACKAGE / "V23_TERMINAL_AND_V24_SUCCESSOR_DECISION.json")
    check("I030_SUCCESSOR_DECISION", decision.get("decision") == DECISION and decision.get("v23_continuation") == "PROHIBITED" and decision.get("v24") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    contract = load(PACKAGE / "ADVERSARIAL_SELFTEST_TRANSACTIONAL_TELEMETRY_CONTRACT.json")
    check("I031_TRANSACTIONAL_CONTRACT", contract.get("consumer_rule") == "FINAL_PATH_EXISTENCE_ALONE_NEVER_MEANS_COMPLETE" and contract.get("malformed_or_truncated_telemetry") == "FAIL_CLOSED_WITHOUT_RECLASSIFYING_OBSERVER_CAPTURE_LOGIC")

    failed = [item["id"] for item in checks if item["status"] != "PASS"]
    output = {
        "record_type": "INDEPENDENT_GOVERNANCE_VALIDATION",
        "governance_identity": GOVERNANCE_ID,
        "implementation_independence": "SEPARATE_BYTE_DIGEST_TREE_SOURCE_ORDER_RAW_TRACE_AND_DECISION_RECOMPUTATION_WITHOUT_PRIMARY_EVIDENCE_REUSE",
        "checks": checks,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
    }
    write_json_once(PACKAGE / VALIDATION_FILES[2], output)
    print(f"INDEPENDENT_GOVERNANCE_VALIDATION={output['status']} {len(checks)-len(failed)}/{len(checks)}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
