#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

GOVERNANCE_ID = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V23_HISTORICAL_DECISION_RELATION_"
    "BINDING_DEFECT_AND_NESTED_ADVERSARIAL_TEMPORAL_SELFTEST_EVIDENCE_PIPELINE_"
    "FAILURE_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
PACKAGE = Path(__file__).resolve().parent
V23 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v23-20261101")
V22 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v22-20261101")
V20_GOV = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v20-independent-validator-external-"
    "predecessor-artifact-path-binding-defect-prelock-erratum-and-successor-decision-"
    "governance-v1-20261101"
)

V23_STATE = "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE"
DECISION = "TERMINALIZE_V23_AND_AUTHORIZE_DISTINCT_V24_CONDITIONALLY"
V23_TREE = (209, "b0241401264938ebd0b89e8408aff69dfc1f14ee4ddad571c5a536e3558913d3")
V23_PRELOCK_TREE = (77, "2b69746f0afd64aa79aa9359c5c2ce6f84a14ef921650b6efa094da1f81c50e9")
V22_TREE = (197, "7039dfbd361f7cbd58f1ac3bbde2e44719dcd65910f9c102c27136a2c7c848b4")

PATHS = {
    "terminal": "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "manifest": "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
    "freeze": "results/prelock/PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
    "unit": "results/prelock/unit-fixtures-run-0001.json",
    "nested_result": "results/prelock/adversarial-selftests-run-0001/nested-0001-result.json",
    "nested_events": "results/prelock/adversarial-selftests-run-0001/nested-0001/events.jsonl",
    "nested_ledger": "results/prelock/adversarial-selftests-run-0001/nested-0001/fixture-expected-identity-ledger.jsonl",
    "nested_ready": "results/prelock/adversarial-selftests-run-0001/nested-0001/ready.json",
    "nested_root": "results/prelock/adversarial-selftests-run-0001/nested-0001/root.json",
    "nested_snapshot": "results/prelock/adversarial-selftests-run-0001/nested-0001/snapshot.json",
    "nested_stderr": "results/prelock/adversarial-selftests-run-0001/nested-0001/observer-stderr.txt",
    "nested_stop": "results/prelock/adversarial-selftests-run-0001/nested-0001/stop.json",
    "invocation": "src/invocation_v23.py",
    "runner": "src/runner_v23.py",
    "observer": "src/topology_observer_v23.py",
    "workspace_boundary": "src/workspace_boundary_v23.py",
    "unified_generation": "contracts/UNIFIED_AUTHORITATIVE_BINDING_GENERATION.json",
}

HASHES = {
    "terminal": "ae3ad1f322452415200c8cdc6a63d4956577777dee6d71a747dfdb25fadd7d06",
    "manifest": "5bb596cdbbe57c64ccb7dea1cc1cbaa8ad6a3b72059038ba4169879ccc0106a0",
    "freeze": "633ff20b3cc22fc989998c0482cb4ef149d9cd5d44da8d551407f15b7c64b244",
    "unit": "a4c245a54d125b489ce1c3f900f31f8c47c625dd095209b5b4d86e18cf8f297a",
    "nested_result": "ba777d7c73a0e7b381d0776c9b5e96d923cee30a50ef01dc8212cc1f92a689c3",
    "nested_events": "669f867da1a52e0b43ff90a10c224f82d2b7af073b9c21dff9af4a75b8f39c2f",
    "nested_ledger": "89ec4e28cfd611426a5b249f22a32abb362dbd533ac7eb7d5696cf5f61ed08d1",
    "nested_ready": "db26d802e95dc36d257453ad1838d30045decea560ea95d41bb1aa9ad2af07c9",
    "nested_root": "2c59c3431f05024492ad8ef13660cf0f8110b8a1c7220f6d690b2a6bbcb68cf5",
    "nested_snapshot": "c46488c5ab2ef070eb4ff450e318e3ab708b9317f3e02b7e7d54dda3377c0140",
    "nested_stderr": "d35ca46d474dd1da3a1b0d1a0b898fa9dbf65fcdba3d5c5dae8c598409be4b2f",
    "nested_stop": "f6f05a76b7cd9b244b6ab0a0e3dd2fd46e9d5773911b8d03fa9098fa47ee6503",
    "invocation": "bf5bdc6e96382d7f49554f4c5c98a73d39c1a9a4f3416d2d968bdec94f3eac0d",
    "runner": "02da4b76d4fa64a2157dd2e016c32e985c6b36a1fe9f40b5e9f9ea2ff8eec2e9",
    "observer": "3e79364d7f0dc376518fdaba687af33fdd72572d28a8b377cfea7cd3304b8a42",
    "unified_generation": "5a11ba83d10f4d879ff8bfab44a1a6da6fffcee3e07f1bf05b5932a987ac6b83",
}

CANONICAL_V20_DECISION = V20_GOV / "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION.json"
CANONICAL_V20_DECISION_SHA256 = "8c78c347a293605db31122f42482ce2caca5bb52a5e750be341377087f3aeff3"
CANONICAL_V20_GOVERNANCE_LOCK = V20_GOV / "GOVERNANCE_LOCK.json"
CANONICAL_V20_GOVERNANCE_LOCK_SHA256 = "da417f8ae6243edc4a91be0b46fef9e1a81e6282d2c849dd0eb5a74885bff39d"

SOURCE_FILES = (
    "governance_common.py",
    "build_governance.py",
    "validate_governance.py",
    "negative_fixtures.py",
    "independent_validate.py",
    "freeze_governance.py",
    "verify_governance_freeze.py",
)
DOCUMENT_FILES = (
    "GOVERNANCE_CHARTER.json",
    "V23_FROZEN_FAILURE_EVIDENCE_BINDING.json",
    "NESTED_SELFTEST_EVIDENCE_DECOMPOSITION.json",
    "V23_TWO_FAMILY_FAILURE_ADJUDICATION.json",
    "HISTORICAL_DECISION_RELATION_REGISTRY_CONTRACT.json",
    "ADVERSARIAL_SELFTEST_TRANSACTIONAL_TELEMETRY_CONTRACT.json",
    "V23_TERMINAL_AND_V24_SUCCESSOR_DECISION.json",
    "SUCCESSOR_V24_REQUIREMENTS.json",
    "V23_FAILURE_AND_V24_REGRESSION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "ROUTING_LEDGER.json",
    "NEXT_LEGAL_MILESTONE.json",
)
VALIDATION_FILES = (
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_jsonl(path: Path) -> list[Any]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def canonical_json_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def write_json_once(path: Path, value: Any) -> None:
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"append-only output exists: {path}")
    path.write_bytes(canonical_json_bytes(value))


def component_key(relative: str) -> tuple[bytes, ...]:
    return tuple(part.encode("utf-8") for part in PurePosixPath(relative).parts)


def normative_tree(root: Path) -> tuple[int, str]:
    rows: list[tuple[tuple[bytes, ...], str, str]] = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise AssertionError(f"unexpected symlink: {path}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            rows.append((component_key(relative), relative, sha256_file(path)))
    rows.sort(key=lambda row: row[0])
    stream = b"".join(relative.encode() + b"\0" + digest.encode("ascii") + b"\n" for _, relative, digest in rows)
    return len(rows), sha256_bytes(stream)


def is_read_only(path: Path) -> bool:
    return (path.stat().st_mode & 0o222) == 0


def set_read_only(path: Path) -> None:
    os.chmod(path, 0o444)


def assert_v23_frozen() -> None:
    if normative_tree(V23) != V23_TREE:
        raise AssertionError("V23 frozen tree drift")
    if normative_tree(V23 / "results/prelock") != V23_PRELOCK_TREE:
        raise AssertionError("V23 prelock evidence drift")
    for key, expected in HASHES.items():
        path = V23 / PATHS[key]
        if sha256_file(path) != expected:
            raise AssertionError(f"V23 artifact drift: {PATHS[key]}")
    terminal = load_json(V23 / PATHS["terminal"])
    execution = terminal.get("execution_state", {})
    if terminal.get("status") != V23_STATE or execution.get("static_lock") != "NOT_ISSUED":
        raise AssertionError("V23 terminal state drift")
    if (execution.get("attempt"), execution.get("worker_invocation"), execution.get("codex_as_worker_invocation")) != ("0/1", "0/1", "0/1"):
        raise AssertionError("V23 execution counters changed")
    forbidden = (
        V23 / "results/runtime/attempt-marker.json",
        V23 / "results/runtime/runtime-result.json",
        V23 / "results/static-run/STATIC_EXECUTION_LOCK.json",
        V23 / "results/prelock/primary-static-validation-run-0001.json",
        V23 / "results/prelock/independent-static-validation-run-0001.json",
    )
    if any(path.exists() or path.is_symlink() for path in forbidden):
        raise AssertionError("V23 prohibited post-unit evidence exists")
    if not all(is_read_only(V23 / PATHS[key]) for key in ("terminal", "manifest", "freeze", "unit", "nested_result", "nested_snapshot", "nested_stderr")):
        raise AssertionError("V23 failure evidence not read-only")


def assert_v22_integrity() -> None:
    if normative_tree(V22) != V22_TREE:
        raise AssertionError("V22 predecessor drift")


def historical_relation_verdict(record: Mapping[str, Any]) -> dict[str, Any]:
    checks = {
        "logical_decision_identity": record.get("logical_decision_identity") == "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION",
        "governance_owner": record.get("governance_owner") == "V20_GOVERNANCE",
        "artifact_role": record.get("artifact_role") == "TERMINAL_SUCCESSOR_DECISION",
        "relation_semantics": record.get("relation_semantics") == "TERMINALIZE_V20_AUTHORIZE_V21",
        "decision_artifact_digest": record.get("artifact_sha256") == CANONICAL_V20_DECISION_SHA256,
        "governance_lock_digest": record.get("governance_lock_sha256") == CANONICAL_V20_GOVERNANCE_LOCK_SHA256,
        "inference_prohibited": record.get("selection_method") == "EXACT_GOVERNANCE_BOUND_LOGICAL_IDENTITY",
    }
    return {"status": "PASS" if all(checks.values()) else "FAIL_CLOSED", "checks": checks}


def telemetry_publication_verdict(record: Mapping[str, Any]) -> dict[str, Any]:
    failure = record.get("failure_envelope", {}) if isinstance(record.get("failure_envelope"), Mapping) else {}
    counters = failure.get("available_counters", {}) if isinstance(failure.get("available_counters"), Mapping) else {}
    checks = {
        "transactional_publication": record.get("publication") in {"ATOMIC_RENAME_AFTER_FSYNC", "WRITE_ONCE_COMMIT_MARKER"},
        "completion_state_explicit": record.get("telemetry_complete") in {True, False},
        "consumer_requires_completion": record.get("consumer_requires_completion") is True,
        "raw_digest_present": isinstance(record.get("raw_output_sha256"), str) and len(record.get("raw_output_sha256")) == 64,
        "raw_size_present": isinstance(record.get("raw_output_bytes"), int) and record.get("raw_output_bytes") >= 0,
        "typed_failure_stage": isinstance(failure.get("failure_stage"), str) and bool(failure.get("failure_stage")),
        "typed_failure_reason": isinstance(failure.get("failure_reason"), str) and bool(failure.get("failure_reason")),
        "observer_exit_status": isinstance(failure.get("observer_exit_code"), int),
        "fixture_identity": isinstance(failure.get("fixture_identity"), str) and bool(failure.get("fixture_identity")),
        "available_counters_typed": all(isinstance(counters.get(name), int) for name in ("trace_identity_count", "capture_attempt_count", "valid_mapping_count", "missing_mapping_count", "ambiguous_mapping_count")),
        "observer_and_pipeline_distinct": failure.get("classification") in {"OBSERVER_EXECUTION_FAILURE", "TELEMETRY_PUBLICATION_FAILURE", "TELEMETRY_SERIALIZATION_FAILURE", "TELEMETRY_PARSER_FAILURE"},
    }
    return {"status": "PASS" if all(checks.values()) else "FAIL_CLOSED", "checks": checks}


def package_member_paths(exclude: tuple[str, ...] = ()) -> list[Path]:
    excluded = set(exclude)
    return sorted((path for path in PACKAGE.iterdir() if path.is_file() and path.name not in excluded), key=lambda path: path.name.encode("utf-8"))


def package_root(paths: list[Path]) -> str:
    return sha256_bytes(b"".join(path.name.encode() + b"\0" + sha256_file(path).encode("ascii") + b"\n" for path in paths))
