#!/usr/bin/env python3
"""AST/control-flow negative fixtures for critical validator helper returns."""

from governance_common import ROOT, typed_helper_contract_verdict, write_once


GOOD_CALLER = """
def consume(verdict):
    if not isinstance(verdict, dict):
        raise TypeError('typed verdict required')
    return verdict.get('status') == 'PASS'
"""
BAD_CALLER = """
def consume(verdict):
    return verdict.get('status') == 'PASS'
"""


def main() -> int:
    fixtures = [
        ("N001_EXACT_TYPED_VERDICT_RETURN", "def critical_helper():\n    return {'record_type':'X','status':'PASS','checks':{}}\n", GOOD_CALLER, True),
        ("N002_CONSTRUCTS_CHECKS_OMITS_RETURN", "def critical_helper():\n    checks={'x':True}\n", GOOD_CALLER, False),
        ("N003_UNREACHABLE_RETURN", "def critical_helper():\n    if False:\n        return {'record_type':'X','status':'PASS','checks':{}}\n", GOOD_CALLER, False),
        ("N004_RETURN_NESTED_AFTER_SIBLING_FUNCTION", "def critical_helper():\n    checks={'x':True}\ndef sibling():\n    return {'record_type':'X','status':'PASS','checks':{}}\n", GOOD_CALLER, False),
        ("N005_IMPLICIT_NONE", "def critical_helper(flag):\n    if flag:\n        return {'record_type':'X','status':'PASS','checks':{}}\n", GOOD_CALLER, False),
        ("N006_WRONG_RESULT_TYPE", "def critical_helper():\n    return 'PASS'\n", GOOD_CALLER, False),
        ("N007_CALLER_WITHOUT_TYPE_VALIDATION", "def critical_helper():\n    return {'record_type':'X','status':'PASS','checks':{}}\n", BAD_CALLER, False),
    ]
    rows = []
    for identity, helper, caller, expected in fixtures:
        actual = typed_helper_contract_verdict(helper, caller)
        rows.append({"id": identity, "expected_accept": expected, "actual_accept": actual, "status": "PASS" if actual is expected else "FAIL"})
    result = {"record_type": "NEGATIVE_GOVERNANCE_FIXTURES", "fixtures": rows, "passed": sum(row["status"] == "PASS" for row in rows), "total": len(rows), "filesystem_mutations": 0, "status": "PASS" if all(row["status"] == "PASS" for row in rows) else "FAIL_CLOSED"}
    write_once(ROOT / "NEGATIVE_GOVERNANCE_FIXTURES.json", result)
    print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
