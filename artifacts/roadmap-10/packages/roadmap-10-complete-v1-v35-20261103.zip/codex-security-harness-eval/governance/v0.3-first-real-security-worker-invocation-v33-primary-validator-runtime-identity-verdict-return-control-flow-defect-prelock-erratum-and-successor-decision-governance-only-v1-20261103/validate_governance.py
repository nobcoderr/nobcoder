#!/usr/bin/env python3
"""Primary validation of the V33 governance-only adjudication."""

from governance_common import ROOT, V34, control_flow_evidence, load, verify_runtime_authority, verify_v33_frozen, write_once


def main() -> int:
    adjudication = load(ROOT / "V33_RUNTIME_IDENTITY_VERDICT_RETURN_ADJUDICATION.json")
    separation = load(ROOT / "V33_RUNTIME_AND_PROOF_GATE_SEPARATION_ADJUDICATION.json")
    contract = load(ROOT / "SUCCESSOR_V34_TYPED_VALIDATOR_HELPER_RETURN_CONTRACT.json")
    matrix = load(ROOT / "V33_FAILURE_AND_V34_REGRESSION_MATRIX.json")
    decision = load(ROOT / "V33_TERMINAL_AND_V34_SUCCESSOR_DECISION.json")
    checks = {
        "G001_V33_FROZEN": verify_v33_frozen()["status"] == "PASS",
        "G002_CONTROL_FLOW_RECONSTRUCTED": control_flow_evidence()["status"] == "PASS",
        "G003_DEFECT_YES": adjudication["PRIMARY_VALIDATOR_RUNTIME_IDENTITY_VERDICT_RETURN_CONTROL_FLOW_DEFECT"] == "YES",
        "G004_S_RUNTIME_DERIVED": adjudication["S_RUNTIME"] == "DERIVED_FAIL_CLOSED_EXECUTION_ERROR_FROM_VALIDATOR_CONTROL_FLOW_DEFECT",
        "G005_NO_RUNTIME_DEFECT_INFERENCE": adjudication["codex_runtime_identity_defect_inferred"] is False,
        "G006_RUNTIME_AUTHORITY": verify_runtime_authority()["status"] == "PASS",
        "G007_RUNTIME_NOT_ESTABLISHED": separation["V33_WORKER_RUNTIME_DEFECT"] == separation["TEMPORAL_RUNTIME"] == "NOT_ESTABLISHED",
        "G008_PROOF_GATES_NOT_PROVEN": separation["PROCESS_LINEAGE"] == separation["PRODUCER_AUTHORIZATION"] == separation["CONFINEMENT"] == "NOT_PROVEN",
        "G009_TYPED_RETURN": contract["required_return_semantics"]["explicit_typed_verdict_object"] is True,
        "G010_ALL_PATHS_RETURN": contract["required_return_semantics"]["reachable_terminal_return_for_every_valid_control_flow_outcome"] is True,
        "G011_NONE_PROHIBITED": contract["required_return_semantics"]["implicit_none"] == "PROHIBITED",
        "G012_UNREACHABLE_PROHIBITED": contract["required_return_semantics"]["unreachable_return"] == "PROHIBITED",
        "G013_CALLER_TYPE_GUARD": contract["required_return_semantics"]["caller_side_runtime_type_validation_before_field_consumption"] is True,
        "G014_AST_CFG_REQUIRED": contract["required_validation"][:2] == ["AST_TOP_LEVEL_AND_NESTING_ANALYSIS", "CONTROL_FLOW_REACHABILITY_ANALYSIS"],
        "G015_REGRESSIONS": matrix["count"] == len(set(matrix["required_regressions"])) == 7,
        "G016_V33_TERMINAL": decision["v33_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY",
        "G017_V34_CONDITIONAL": decision["v34_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "G018_V34_ABSENT": not V34.exists(),
    }
    result = {"record_type": "PRIMARY_GOVERNANCE_VALIDATION", "checks": [{"id": key, "status": "PASS" if value else "FAIL"} for key, value in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "PRIMARY_GOVERNANCE_VALIDATION.json", result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
