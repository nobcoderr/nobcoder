#!/usr/bin/env python3
"""Build the governance-only V33 validator-return adjudication."""

from governance_common import (
    IDENTITY, ROOT, V33, V33_IDENTITY, V34, V34_IDENTITY, control_flow_evidence,
    sha256, verify_runtime_authority, verify_v33_frozen, write_once,
)


def emit(name: str, value: dict) -> None:
    write_once(ROOT / name, value)


def main() -> int:
    frozen = verify_v33_frozen()
    flow = control_flow_evidence()
    runtime = verify_runtime_authority()
    if frozen["status"] != "PASS" or flow["status"] != "PASS":
        raise SystemExit("frozen evidence or control-flow reconstruction failed")
    if runtime["status"] != "PASS":
        raise SystemExit("frozen Codex runtime authority did not independently verify")
    if V34.exists():
        raise SystemExit("governance-only milestone forbids V34 creation")

    regressions = [
        "HELPER_CONSTRUCTS_CHECKS_BUT_OMITS_RETURN_FAILS_CLOSED",
        "UNREACHABLE_RETURN_FAILS_CLOSED",
        "RETURN_INCORRECTLY_NESTED_AFTER_SIBLING_FUNCTION_DEFINITION_FAILS_CLOSED",
        "IMPLICIT_NONE_FAILS_CLOSED",
        "WRONG_RESULT_TYPE_FAILS_CLOSED",
        "CALLER_CONSUMES_FIELDS_WITHOUT_RESULT_TYPE_VALIDATION_FAILS_CLOSED",
        "EXACT_CANONICAL_TYPED_VERDICT_RETURN_SUCCEEDS",
    ]
    contract = {
        "record_type": "SUCCESSOR_V34_TYPED_VALIDATOR_HELPER_RETURN_CONTRACT",
        "contract_identity": "V34_TYPED_CRITICAL_VALIDATOR_HELPER_RETURN_CONTRACT_V1",
        "successor_identity": V34_IDENTITY,
        "authorizing_governance_identity": IDENTITY,
        "authorizing_governance_lock": "EXACT_SHA256_OF_THIS_PACKAGE_GOVERNANCE_LOCK_JSON",
        "critical_helper_inventory": "EXPLICIT_COMPLETE_INVENTORY_REQUIRED_BEFORE_UNIT_OR_STATIC_VALIDATION",
        "required_verdict_fields": ["record_type", "status", "checks"],
        "required_return_semantics": {
            "explicit_typed_verdict_object": True,
            "reachable_terminal_return_for_every_valid_control_flow_outcome": True,
            "implicit_none": "PROHIBITED",
            "unreachable_return": "PROHIBITED",
            "return_after_or_inside_sibling_function_due_to_nesting_or_placement": "PROHIBITED",
            "caller_side_runtime_type_validation_before_field_consumption": True,
        },
        "required_validation": [
            "AST_TOP_LEVEL_AND_NESTING_ANALYSIS",
            "CONTROL_FLOW_REACHABILITY_ANALYSIS",
            "RETURN_TYPE_SHAPE_VALIDATION",
            "CALLER_CONSUMPTION_TYPE_GUARD_VALIDATION",
            "ACTUAL_CANONICAL_HELPER_INVOCATION_IN_AUTHORIZED_VALIDATION_ENVIRONMENT",
        ],
        "failure_policy": "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT",
        "status": "NORMATIVE_FOR_CONDITIONALLY_AUTHORIZED_SUCCESSOR_ONLY",
    }

    emit("GOVERNANCE_CHARTER.json", {
        "record_type": "GOVERNANCE_CHARTER", "governance_identity": IDENTITY,
        "scope": "GOVERNANCE_ONLY",
        "prohibited": ["PATCH_V33", "RERUN_V33", "DUPLICATE_V33", "RUN_INDEPENDENT_V33", "RUN_FRESH_PREFLIGHT_V33", "ISSUE_V33_STATIC_LOCK", "INVOKE_SECURITY_WORKER", "INVOKE_CODEX", "CREATE_OR_EXECUTE_V34"],
        "status": "ACTIVE",
    })
    emit("ROUTING_LEDGER.json", {
        "record_type": "ROUTING_LEDGER",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "expert-python-engineer"],
        "deferred": [],
        "not_applicable": ["live-target", "recon", "exploit-execution", "external-tools", "paid-tools", "subagents", "parallelism"],
        "reason": "LOCAL_GOVERNANCE_ONLY_PYTHON_CONTROL_FLOW_ADJUDICATION", "status": "PASS",
    })
    emit("V33_FROZEN_FAILURE_EVIDENCE_BINDING.json", {
        "record_type": "V33_FROZEN_FAILURE_EVIDENCE_BINDING", "execution_identity": V33_IDENTITY,
        "canonical_evidence_root_sha256": "7697ad9d1f20e8e47d6544031c229b9037dec1fd8c7ab7574d1f3091e729227d",
        "terminal_sha256": "6fc29626608e6a286e21b7b442ccc5d3c299513fa378439f23c2898630e7ad62",
        "failure_manifest_sha256": "67e9a687aae31566859e01d58a1713e91ccb6bb2876154f3dd9032ba4640c01c",
        "freeze_verification_sha256": "111604877cb22a242b4c8252a7472555dd673f9b1512d34f4cd9c1a84bfb260b",
        "unit_sha256": "3f2f8dc40fba2cb3fb981dc482a0021741ea1391c7eb3ad14b05e96f98c87ef9",
        "primary_execution_error_sha256": "0823c88ecaea58c6a1e1fcb9929ef2debf19fb4f9bc8eea2e36e9c36fa73e88f",
        "verification": frozen, "status": "PASS",
    })
    emit("V33_FAILURE_FACTS.json", {
        "record_type": "V33_FAILURE_FACTS", "unit": "385/385 PASS", "primary": "FAIL_CLOSED_EXECUTION_ERROR",
        "failed_gate": "S_RUNTIME", "independent": "NOT_STARTED", "preflight": "NOT_STARTED",
        "static_lock": "NOT_ISSUED", "attempt": "0/1", "worker": "0/1", "codex": "0/1",
        "attempt_marker": "ABSENT", "runtime_evidence": "ABSENT", "status": "PASS",
    })
    emit("V33_RUNTIME_IDENTITY_RETURN_CONTROL_FLOW_EVIDENCE.json", flow)
    emit("V33_RUNTIME_IDENTITY_VERDICT_RETURN_ADJUDICATION.json", {
        "record_type": "V33_RUNTIME_IDENTITY_VERDICT_RETURN_ADJUDICATION",
        "PRIMARY_VALIDATOR_RUNTIME_IDENTITY_VERDICT_RETURN_CONTROL_FLOW_DEFECT": "YES",
        "S_RUNTIME": "DERIVED_FAIL_CLOSED_EXECUTION_ERROR_FROM_VALIDATOR_CONTROL_FLOW_DEFECT",
        "cause": "INSPECT_RUNTIME_IDENTITY_FALLS_THROUGH_IMPLICIT_NONE_AND_INTENDED_RETURN_IS_MISBOUND_UNREACHABLY_INSIDE_FOLLOWING_HELPER",
        "codex_runtime_identity_defect_inferred": False,
        "source_patch_authorized": False,
        "status": "PASS",
    })
    emit("V33_RUNTIME_AND_PROOF_GATE_SEPARATION_ADJUDICATION.json", {
        "record_type": "V33_RUNTIME_AND_PROOF_GATE_SEPARATION_ADJUDICATION",
        "codex_0_166_0_frozen_static_authority_verification": runtime,
        "current_worker_runtime_authority": "CODEX_RUNTIME_0_166_0_COMPATIBILITY_PASS_LOCKED",
        "V33_WORKER_RUNTIME_DEFECT": "NOT_ESTABLISHED",
        "TEMPORAL_RUNTIME": "NOT_ESTABLISHED",
        "PROCESS_LINEAGE": "NOT_PROVEN",
        "PRODUCER_AUTHORIZATION": "NOT_PROVEN",
        "CONFINEMENT": "NOT_PROVEN",
        "reason": "V33_NEVER_REACHED_STATIC_LOCK_OR_EXECUTION",
        "status": "PASS",
    })
    emit("SUCCESSOR_V34_TYPED_VALIDATOR_HELPER_RETURN_CONTRACT.json", contract)
    emit("V33_FAILURE_AND_V34_REGRESSION_MATRIX.json", {
        "record_type": "V33_FAILURE_AND_V34_REGRESSION_MATRIX", "required_regressions": regressions,
        "count": len(regressions), "ast_control_flow_validation_required": True,
        "carry_forward": "ALL_V33_CONTROLS_NOT_IMPLICATED_BY_FROZEN_EVIDENCE",
        "preserved_controls": ["DERIVED_CURRENT_EXPECTED_DIGEST_VIEW", "AUTHORITATIVE_ARTIFACT_FINALIZATION", "EXACT_CODEX_0_166_0_RUNTIME_AUTHORITY", "BIND_SOURCE_LIFECYCLE", "MOUNT_OUTPUT_IDENTITY", "TYPED_PREFLIGHT_PREDICATES", "TYPED_HISTORICAL_REGISTRY", "PREDECESSOR_TRANSITIVE_RESOLUTION", "TYPED_MODULE_SYMBOL_RESOLUTION", "PYTHON_CACHE_POLICY", "WORKSPACE_BOUNDARY", "TRANSACTIONAL_TELEMETRY", "STRICT_N_OF_N_TEMPORAL_COVERAGE"],
        "status": "PASS",
    })
    emit("V33_TERMINAL_AND_V34_SUCCESSOR_DECISION.json", {
        "record_type": "V33_TERMINAL_AND_V34_SUCCESSOR_DECISION",
        "v33_disposition": "TERMINAL_IMMUTABLE_NO_RETRY",
        "v34_disposition": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v34_authorized_scope": "FRESH_SUCCESSOR_IMPLEMENTING_TYPED_VALIDATOR_HELPER_RETURN_CONTRACT_AND_CARRYING_FORWARD_UNIMPLICATED_CONTROLS",
        "attempt": "0/1", "worker_invocation": "0/1", "codex_as_worker_invocation": "0/1",
        "status": "PASS",
    })
    emit("V33_IMMUTABILITY_AND_AUTHORITY_CEILING.json", {
        "record_type": "V33_IMMUTABILITY_AND_AUTHORITY_CEILING",
        "v33_write_authority": "NONE", "v33_retry_authority": "NONE", "v33_execution_authority": "NONE",
        "v34_creation_authority_during_this_milestone": "NONE",
        "v34_execution_authority_during_this_milestone": "NONE",
        "status": "PASS",
    })
    emit("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "NEXT_LEGAL_MILESTONE",
        "milestone": "IMPLEMENT_FRESH_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V34_ONLY_UNDER_SEPARATE_EXPLICIT_ENGINEERING_REQUEST",
        "current_state": "V34_CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "status": "PASS",
    })
    print("GOVERNANCE_BUILD=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
