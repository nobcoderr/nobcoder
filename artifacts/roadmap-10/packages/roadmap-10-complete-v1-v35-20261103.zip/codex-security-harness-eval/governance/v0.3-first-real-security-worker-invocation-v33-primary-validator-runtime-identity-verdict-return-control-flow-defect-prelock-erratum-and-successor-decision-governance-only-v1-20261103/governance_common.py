"""Read-only helpers for the V33 validator-return governance adjudication."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parent
V33 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v33-20261103")
V34 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v34-20261103")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V33_PRIMARY_VALIDATOR_RUNTIME_"
    "IDENTITY_VERDICT_RETURN_CONTROL_FLOW_DEFECT_PRELOCK_ERRATUM_AND_SUCCESSOR_"
    "DECISION_GOVERNANCE_ONLY"
)
V33_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V33"
V34_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V34"
V33_STATUS = "FAIL_CLOSED_DURING_PRIMARY_STATIC_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE"
V33_ROOT_SHA = "7697ad9d1f20e8e47d6544031c229b9037dec1fd8c7ab7574d1f3091e729227d"
V33_TERMINAL_SHA = "6fc29626608e6a286e21b7b442ccc5d3c299513fa378439f23c2898630e7ad62"
V33_MANIFEST_SHA = "67e9a687aae31566859e01d58a1713e91ccb6bb2876154f3dd9032ba4640c01c"
V33_FREEZE_SHA = "111604877cb22a242b4c8252a7472555dd673f9b1512d34f4cd9c1a84bfb260b"
V33_UNIT_SHA = "3f2f8dc40fba2cb3fb981dc482a0021741ea1391c7eb3ad14b05e96f98c87ef9"
V33_PRIMARY_ERROR_SHA = "0823c88ecaea58c6a1e1fcb9929ef2debf19fb4f9bc8eea2e36e9c36fa73e88f"
RUNTIME_BINARY_SHA = "b8a11fedf24b2dfb59a70c9e52b030f9a508dcd49cd2dd0d41956f4c785156b8"
RUNTIME_PACKAGE_SHA = "ffdfc731eed492fa436a304cff8792ea3a96233a45ec9a561f6f56eaca911446"
RUNTIME_CONFIG_SHA = "7ae835188ef2ab3221e15effac45375b2d6112954d022aa7776f802f7b8697c0"
RUNTIME_ACCEPTANCE_LOCK_SHA = "060b39551d4543999e79ccfd5d133d751faefc018fdc8adab718f5b9c7479a5e"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_once(path: Path, value: Any) -> None:
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"append-only output exists: {path}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def paths() -> dict[str, Path]:
    pre = V33 / "results/prelock"
    return {
        "terminal": pre / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
        "manifest": pre / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
        "freeze": pre / "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
        "unit": pre / "unit-fixtures-run-0001.json",
        "primary_error": pre / "primary-static-validation-run-0001.json",
        "source": V33 / "src/invocation_v33.py",
        "primary_source": V33 / "validators/primary_static_validate.py",
        "runtime_binding": V33 / "contracts/V33_CODEX_0_166_0_RUNTIME_BINDING.json",
        "runtime_contract": V33 / "contracts/TYPED_CODEX_RUNTIME_ACCEPTANCE_BINDING_CONTRACT.json",
        "digest_view": V33 / "contracts/CURRENT_EXPECTED_DIGEST_VIEW.json",
    }


def _direct_returns(node: ast.FunctionDef) -> list[ast.Return]:
    returns: list[ast.Return] = []

    def visit(statement: ast.AST) -> None:
        if isinstance(statement, ast.Return):
            returns.append(statement)
            return
        if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
            return
        for child in ast.iter_child_nodes(statement):
            visit(child)

    for statement in node.body:
        visit(statement)
    return returns


def _statement_always_returns(statement: ast.stmt) -> bool:
    if isinstance(statement, (ast.Return, ast.Raise)):
        return True
    if isinstance(statement, ast.If):
        return bool(statement.body and statement.orelse) and _block_always_returns(statement.body) and _block_always_returns(statement.orelse)
    if isinstance(statement, ast.Try):
        body = _block_always_returns(statement.body)
        handlers = bool(statement.handlers) and all(_block_always_returns(handler.body) for handler in statement.handlers)
        final = _block_always_returns(statement.finalbody) if statement.finalbody else False
        return final or (body and handlers)
    return False


def _block_always_returns(statements: list[ast.stmt]) -> bool:
    for statement in statements:
        if _statement_always_returns(statement):
            return True
    return False


def analyze_helper_source(source: str, helper_name: str) -> dict[str, Any]:
    tree = ast.parse(source)
    helper = next((node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == helper_name), None)
    if helper is None:
        return {"helper_found": False, "status": "FAIL_CLOSED"}
    returns = _direct_returns(helper)
    return_values = [item.value for item in returns]
    return {
        "helper_found": True,
        "helper_name": helper_name,
        "helper_line": helper.lineno,
        "direct_return_count": len(returns),
        "direct_return_lines": [item.lineno for item in returns],
        "explicit_return_present": bool(returns),
        "all_valid_paths_return": _block_always_returns(helper.body),
        "all_returns_typed_dict_literals": bool(return_values) and all(isinstance(value, ast.Dict) for value in return_values),
        "implicit_none_possible": not _block_always_returns(helper.body),
        "status": "PASS" if returns and _block_always_returns(helper.body) and all(isinstance(value, ast.Dict) for value in return_values) else "FAIL_CLOSED",
    }


def caller_type_guard_present(source: str, verdict_name: str = "verdict") -> bool:
    tree = ast.parse(source)
    guards: list[int] = []
    consumes: list[int] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "isinstance" and node.args:
            if isinstance(node.args[0], ast.Name) and node.args[0].id == verdict_name:
                guards.append(node.lineno)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "get":
            if isinstance(node.func.value, ast.Name) and node.func.value.id == verdict_name:
                consumes.append(node.lineno)
    return bool(guards and consumes and min(guards) < min(consumes))


def typed_helper_contract_verdict(helper_source: str, caller_source: str, helper_name: str = "critical_helper") -> bool:
    verdict = analyze_helper_source(helper_source, helper_name)
    return bool(verdict.get("status") == "PASS" and caller_type_guard_present(caller_source))


def control_flow_evidence() -> dict[str, Any]:
    p = paths()
    source = p["source"].read_text(encoding="utf-8")
    primary = p["primary_source"].read_text(encoding="utf-8")
    tree = ast.parse(source)
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    index = next(i for i, node in enumerate(functions) if node.name == "inspect_runtime_identity")
    helper = functions[index]
    sibling = functions[index + 1]
    sibling_returns = _direct_returns(sibling)
    helper_verdict = analyze_helper_source(source, "inspect_runtime_identity")
    return {
        "record_type": "V33_RUNTIME_IDENTITY_HELPER_CONTROL_FLOW_EVIDENCE",
        "source_artifact": str(p["source"]),
        "source_sha256": sha256(p["source"]),
        "helper": helper.name,
        "helper_line": helper.lineno,
        "helper_end_line": helper.end_lineno,
        "helper_analysis": helper_verdict,
        "checks_assignment_lines": [3053, 3064],
        "next_sibling_function": sibling.name,
        "next_sibling_line": sibling.lineno,
        "sibling_direct_return_lines": [row.lineno for row in sibling_returns],
        "intended_verdict_return_misbound_to_sibling_lines": [3092, 3102],
        "misbound_return_unreachable_after_unconditional_sibling_return_line": 3087,
        "primary_source_artifact": str(p["primary_source"]),
        "primary_source_sha256": sha256(p["primary_source"]),
        "primary_helper_call_line": 110,
        "primary_unchecked_field_consumption_line": 117,
        "primary_has_typed_result_guard_before_get": caller_type_guard_present(primary),
        "actual_failure": "IMPLICIT_NONE_THEN_ATTRIBUTE_ERROR_ON_GET",
        "status": "PASS" if helper_verdict["status"] == "FAIL_CLOSED" and helper_verdict["direct_return_count"] == 0 and sibling.name == "runtime_binding_fixture_verdict" else "FAIL_CLOSED",
    }


def verify_runtime_authority() -> dict[str, Any]:
    p = paths()
    binding = load(p["runtime_binding"])
    contract = load(p["runtime_contract"])
    checks = {
        "runtime_identity": binding.get("runtime_logical_identity") == contract.get("runtime_logical_identity") == "CODEX_RUNTIME_0_166_0_COMPATIBILITY_PASS_LOCKED",
        "version": binding.get("version") == contract.get("runtime_version") == "0.166.0",
        "binary_digest": binding.get("binary_sha256") == contract.get("binary_sha256") == RUNTIME_BINARY_SHA,
        "package_digest": binding.get("package_sha256") == contract.get("package_sha256") == RUNTIME_PACKAGE_SHA,
        "config_digest": binding.get("dedicated_config_sha256") == contract.get("dedicated_config_sha256") == RUNTIME_CONFIG_SHA,
        "compatibility_lock": binding.get("compatibility_acceptance_governance_lock_sha256") == contract.get("compatibility_governance_lock_sha256") == RUNTIME_ACCEPTANCE_LOCK_SHA,
        "current_authority": contract.get("current_authority_field") == "codex_runtime_0_166_0" and contract.get("current_authority_state") == "COMPATIBILITY_PASS_LOCKED",
        "no_fallback": binding.get("fallback_to_0_163_0") is False and contract.get("fallback_runtime") is None,
    }
    return {"record_type": "V33_RUNTIME_AUTHORITY_FROZEN_STATIC_VERDICT", "checks": checks, "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}


def verify_v33_frozen() -> dict[str, Any]:
    p = paths()
    terminal, manifest, unit, primary = (load(p[name]) for name in ("terminal", "manifest", "unit", "primary_error"))
    members = manifest.get("members", [])
    exact = []
    for row in members:
        member = V33 / row.get("path", "")
        exact.append(
            member.is_file() and not member.is_symlink()
            and sha256(member) == row.get("sha256")
            and member.stat().st_size == row.get("bytes")
            and stat.S_IMODE(member.stat().st_mode) == 0o444
        )
    root_rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    computed_root = hashlib.sha256(root_rows.encode()).hexdigest()
    failed = [row.get("id") for row in unit.get("checks", []) if row.get("status") != "PASS"]
    checks = {
        "terminal_digest": sha256(p["terminal"]) == V33_TERMINAL_SHA,
        "manifest_digest": sha256(p["manifest"]) == V33_MANIFEST_SHA,
        "freeze_digest": sha256(p["freeze"]) == V33_FREEZE_SHA,
        "unit_digest": sha256(p["unit"]) == V33_UNIT_SHA,
        "primary_error_digest": sha256(p["primary_error"]) == V33_PRIMARY_ERROR_SHA,
        "root_exact": computed_root == manifest.get("canonical_evidence_root_sha256") == V33_ROOT_SHA,
        "members_exact": len(members) == manifest.get("member_count") == 339 and all(exact),
        "workspace_read_only": stat.S_IMODE(V33.stat().st_mode) == 0o555,
        "terminal_state": terminal.get("status") == V33_STATUS,
        "unit_counts": unit.get("validation_counts") == {"failed": 0, "passed": 385, "total": 385} and not failed,
        "primary_failure": primary.get("status") == "FAIL_CLOSED_EXECUTION_ERROR" and primary.get("failed_gate") == "S_RUNTIME",
        "later_gates_not_started": terminal.get("independent") == terminal.get("fresh_preflight") == terminal.get("dependency_closure") == "NOT_STARTED",
        "static_lock_absent": terminal.get("static_lock") == "NOT_ISSUED" and not (V33 / "STATIC_EXECUTION_LOCK.json").exists(),
        "attempt_absent": not any(V33.rglob("ATTEMPT_MARKER.json")),
        "runtime_absent": not any(V33.rglob("runtime-result-0001.json")),
        "counts_zero": terminal.get("attempt_count") == terminal.get("worker_invocation_count") == terminal.get("codex_as_worker_invocation_count") == 0,
        "no_bytecode": not any(V33.rglob("*.pyc")) and not any(path.name == "__pycache__" for path in V33.rglob("*")),
        "derived_digest_view_unit_pass": any(row.get("id") == "U_V33_DERIVED_CURRENT_EXPECTED_DIGEST_VIEW_PRECHECK" and row.get("status") == "PASS" for row in unit.get("checks", [])),
        "runtime_authority_static_pass": verify_runtime_authority()["status"] == "PASS",
    }
    return {
        "record_type": "V33_FROZEN_FAILURE_EVIDENCE_VERDICT",
        "checks": checks,
        "member_count": len(members),
        "canonical_evidence_root_sha256": computed_root,
        "status": "PASS" if all(checks.values()) else "FAIL_CLOSED",
    }
