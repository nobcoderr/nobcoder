#!/usr/bin/env python3
"""Independent reconstruction of the V33 primary-validator control-flow failure."""

import ast
import hashlib
import json
import stat
from pathlib import Path

from governance_common import ROOT, V33, V34, write_once


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    pre = V33 / "results/prelock"
    terminal_path = pre / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json"
    manifest_path = pre / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json"
    freeze_path = pre / "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json"
    unit_path = pre / "unit-fixtures-run-0001.json"
    error_path = pre / "primary-static-validation-run-0001.json"
    terminal, manifest, unit, error = map(read, (terminal_path, manifest_path, unit_path, error_path))
    rows_text = "".join(f"{row['sha256']}  {row['path']}\n" for row in manifest["members"])
    root_sha = hashlib.sha256(rows_text.encode()).hexdigest()
    members_exact = all(
        (V33 / row["path"]).is_file() and not (V33 / row["path"]).is_symlink()
        and digest(V33 / row["path"]) == row["sha256"]
        and (V33 / row["path"]).stat().st_size == row["bytes"]
        and stat.S_IMODE((V33 / row["path"]).stat().st_mode) == 0o444
        for row in manifest["members"]
    )
    source_path = V33 / "src/invocation_v33.py"
    tree = ast.parse(source_path.read_text(encoding="utf-8"))
    top_functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    helper_index = next(index for index, node in enumerate(top_functions) if node.name == "inspect_runtime_identity")
    helper = top_functions[helper_index]
    sibling = top_functions[helper_index + 1]
    helper_direct_returns = [node for statement in helper.body for node in ast.walk(statement) if isinstance(node, ast.Return) and not isinstance(statement, (ast.FunctionDef, ast.ClassDef))]
    sibling_returns = [node for node in ast.walk(sibling) if isinstance(node, ast.Return)]
    primary_source = (V33 / "validators/primary_static_validate.py").read_text(encoding="utf-8")
    adjudication = read(ROOT / "V33_RUNTIME_IDENTITY_VERDICT_RETURN_ADJUDICATION.json")
    decision = read(ROOT / "V33_TERMINAL_AND_V34_SUCCESSOR_DECISION.json")
    checks = {
        "I001_TERMINAL_SHA": digest(terminal_path) == "6fc29626608e6a286e21b7b442ccc5d3c299513fa378439f23c2898630e7ad62",
        "I002_MANIFEST_SHA": digest(manifest_path) == "67e9a687aae31566859e01d58a1713e91ccb6bb2876154f3dd9032ba4640c01c",
        "I003_FREEZE_SHA": digest(freeze_path) == "111604877cb22a242b4c8252a7472555dd673f9b1512d34f4cd9c1a84bfb260b",
        "I004_UNIT_SHA": digest(unit_path) == "3f2f8dc40fba2cb3fb981dc482a0021741ea1391c7eb3ad14b05e96f98c87ef9",
        "I005_PRIMARY_ERROR_SHA": digest(error_path) == "0823c88ecaea58c6a1e1fcb9929ef2debf19fb4f9bc8eea2e36e9c36fa73e88f",
        "I006_ROOT": root_sha == manifest["canonical_evidence_root_sha256"] == "7697ad9d1f20e8e47d6544031c229b9037dec1fd8c7ab7574d1f3091e729227d",
        "I007_MEMBERS": len(manifest["members"]) == 339 and members_exact,
        "I008_UNIT": unit["validation_counts"] == {"failed": 0, "passed": 385, "total": 385} and unit["status"] == "PASS",
        "I009_PRIMARY_ERROR": error["status"] == "FAIL_CLOSED_EXECUTION_ERROR" and error["failed_gate"] == "S_RUNTIME" and error["exception_type"] == "AttributeError",
        "I010_HELPER_NO_RETURN": helper.lineno == 3043 and helper.end_lineno == 3064 and not helper_direct_returns,
        "I011_SIBLING_MISBOUND_RETURN": sibling.name == "runtime_binding_fixture_verdict" and any(row.lineno == 3092 for row in sibling_returns),
        "I012_CONSUMER_GET": 'verdict.get("status")' in primary_source,
        "I013_ADJUDICATION": adjudication["PRIMARY_VALIDATOR_RUNTIME_IDENTITY_VERDICT_RETURN_CONTROL_FLOW_DEFECT"] == "YES" and adjudication["S_RUNTIME"].startswith("DERIVED_FAIL_CLOSED"),
        "I014_TERMINAL": terminal["status"] == "FAIL_CLOSED_DURING_PRIMARY_STATIC_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE",
        "I015_NO_EXECUTION": terminal["static_lock"] == "NOT_ISSUED" and not any(V33.rglob("ATTEMPT_MARKER.json")) and not any(V33.rglob("runtime-result-0001.json")),
        "I016_PRIMARY_PASS": read(ROOT / "PRIMARY_GOVERNANCE_VALIDATION.json")["status"] == "PASS",
        "I017_NEGATIVES_PASS": read(ROOT / "NEGATIVE_GOVERNANCE_FIXTURES.json")["status"] == "PASS",
        "I018_V33_TERMINAL": decision["v33_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY",
        "I019_V34_CONDITIONAL": decision["v34_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "I020_V34_ABSENT": not V34.exists(),
    }
    result = {"record_type": "INDEPENDENT_GOVERNANCE_VALIDATION", "checks": [{"id": key, "status": "PASS" if value else "FAIL"} for key, value in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION.json", result)
    print(f"INDEPENDENT_GOVERNANCE_VALIDATION={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
