#!/usr/bin/env python3
"""Verify V33 immutability and the governance authority ceiling."""

from governance_common import ROOT, V33, V34, load, verify_v33_frozen, write_once


def main() -> int:
    required = ["PRIMARY_GOVERNANCE_VALIDATION.json", "NEGATIVE_GOVERNANCE_FIXTURES.json", "INDEPENDENT_GOVERNANCE_VALIDATION.json"]
    checks = {
        "R001_V33_BYTE_EXACT": verify_v33_frozen()["status"] == "PASS",
        "R002_VALIDATIONS_PASS": all(load(ROOT / name)["status"] == "PASS" for name in required),
        "R003_STATIC_LOCK_ABSENT": not (V33 / "STATIC_EXECUTION_LOCK.json").exists(),
        "R004_ATTEMPT_ABSENT": not any(V33.rglob("ATTEMPT_MARKER.json")),
        "R005_RUNTIME_ABSENT": not any(V33.rglob("runtime-result-0001.json")),
        "R006_V34_ABSENT": not V34.exists(),
        "R007_NO_BYTECODE": not any(V33.rglob("*.pyc")) and not any(path.name == "__pycache__" for path in V33.rglob("*")),
        "R008_COUNTERS_ZERO": load(V33 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json")["attempt_count"] == load(V33 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json")["worker_invocation_count"] == load(V33 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json")["codex_as_worker_invocation_count"] == 0,
    }
    result = {"record_type": "READ_ONLY_INTEGRITY_VERIFICATION", "checks": [{"id": key, "status": "PASS" if value else "FAIL"} for key, value in checks.items()], "passed": sum(checks.values()), "total": len(checks), "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}
    write_once(ROOT / "READ_ONLY_INTEGRITY_VERIFICATION.json", result)
    print(f"READ_ONLY_INTEGRITY={result['passed']}/{result['total']} {result['status']}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
