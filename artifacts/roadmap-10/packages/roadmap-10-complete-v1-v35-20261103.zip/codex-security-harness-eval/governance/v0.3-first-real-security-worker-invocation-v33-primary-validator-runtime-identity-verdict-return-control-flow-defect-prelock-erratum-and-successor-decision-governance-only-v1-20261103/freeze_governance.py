#!/usr/bin/env python3
"""Freeze the validated V33 governance-only package append-only."""

import hashlib
import os

from governance_common import IDENTITY, ROOT, V33, V34, load, sha256, verify_v33_frozen, write_once


def main() -> int:
    validations = ["PRIMARY_GOVERNANCE_VALIDATION.json", "NEGATIVE_GOVERNANCE_FIXTURES.json", "INDEPENDENT_GOVERNANCE_VALIDATION.json", "READ_ONLY_INTEGRITY_VERIFICATION.json"]
    if verify_v33_frozen()["status"] != "PASS" or not all(load(ROOT / name)["status"] == "PASS" for name in validations):
        raise SystemExit("governance readiness failed")
    if V34.exists() or (V33 / "STATIC_EXECUTION_LOCK.json").exists() or any(V33.rglob("ATTEMPT_MARKER.json")):
        raise SystemExit("governance authority ceiling violated")
    reserved = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION.json"}
    members = [{"path": path.name, "sha256": sha256(path), "bytes": path.stat().st_size} for path in sorted((path for path in ROOT.iterdir() if path.is_file() and path.name not in reserved), key=lambda path: path.name.encode())]
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    root_sha = hashlib.sha256(rows.encode()).hexdigest()
    write_once(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", {"record_type": "GOVERNANCE_ARTIFACT_MANIFEST", "governance_identity": IDENTITY, "members": members, "member_count": len(members), "canonical_governance_root_sha256": root_sha, "status": "PASS"})
    lock = {
        "record_type": "V33_PRIMARY_VALIDATOR_RUNTIME_IDENTITY_VERDICT_RETURN_CONTROL_FLOW_DEFECT_ERRATUM_AND_V34_SUCCESSOR_DECISION_GOVERNANCE_LOCK",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "canonical_governance_root_sha256": root_sha,
        "governance_artifact_manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "PRIMARY_VALIDATOR_RUNTIME_IDENTITY_VERDICT_RETURN_CONTROL_FLOW_DEFECT": "YES",
        "S_RUNTIME": "DERIVED_FAIL_CLOSED_EXECUTION_ERROR_FROM_VALIDATOR_CONTROL_FLOW_DEFECT",
        "codex_0_166_0_runtime_authority": "COMPATIBILITY_PASS_LOCKED_PRESERVED",
        "v33_disposition": "TERMINAL_IMMUTABLE_NO_RETRY",
        "v34_disposition": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt": "0/1", "worker_invocation": "0/1", "codex_as_worker_invocation": "0/1",
        "V33_WORKER_RUNTIME_DEFECT": "NOT_ESTABLISHED", "TEMPORAL_RUNTIME": "NOT_ESTABLISHED",
        "PROCESS_LINEAGE": "NOT_PROVEN", "PRODUCER_AUTHORIZATION": "NOT_PROVEN", "CONFINEMENT": "NOT_PROVEN",
        "next_legal_milestone": "IMPLEMENT_FRESH_V34_ONLY_UNDER_SEPARATE_EXPLICIT_ENGINEERING_REQUEST",
    }
    write_once(ROOT / "GOVERNANCE_LOCK.json", lock)
    write_once(ROOT / "FINAL_FREEZE_VERIFICATION.json", {"record_type": "FINAL_FREEZE_VERIFICATION", "manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"), "governance_lock_sha256": sha256(ROOT / "GOVERNANCE_LOCK.json"), "member_count": len(members), "canonical_governance_root_sha256": root_sha, "v33_reverified": True, "v34_absent": True, "status": "PASS"})
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(f"GOVERNANCE_FREEZE=PASS ROOT={root_sha} LOCK_SHA256={sha256(ROOT / 'GOVERNANCE_LOCK.json')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
