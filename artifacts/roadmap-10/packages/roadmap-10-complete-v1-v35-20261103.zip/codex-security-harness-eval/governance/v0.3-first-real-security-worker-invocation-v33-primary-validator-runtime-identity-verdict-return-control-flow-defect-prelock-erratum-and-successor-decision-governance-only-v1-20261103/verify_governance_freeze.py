#!/usr/bin/env python3
"""Read-only final verifier for the frozen V33 governance package."""

import hashlib
import stat

from governance_common import ROOT, V33, V34, load, sha256, verify_v33_frozen


def main() -> int:
    manifest = load(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load(ROOT / "GOVERNANCE_LOCK.json")
    final = load(ROOT / "FINAL_FREEZE_VERIFICATION.json")
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in manifest["members"])
    root_sha = hashlib.sha256(rows.encode()).hexdigest()
    exact = all((ROOT / row["path"]).is_file() and not (ROOT / row["path"]).is_symlink() and sha256(ROOT / row["path"]) == row["sha256"] and (ROOT / row["path"]).stat().st_size == row["bytes"] and stat.S_IMODE((ROOT / row["path"]).stat().st_mode) == 0o444 for row in manifest["members"])
    checks = {
        "F001_ROOT": root_sha == manifest["canonical_governance_root_sha256"] == lock["canonical_governance_root_sha256"] == final["canonical_governance_root_sha256"],
        "F002_MANIFEST": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock["governance_artifact_manifest_sha256"] == final["manifest_sha256"],
        "F003_LOCK": sha256(ROOT / "GOVERNANCE_LOCK.json") == final["governance_lock_sha256"],
        "F004_MEMBERS": exact and len(manifest["members"]) == manifest["member_count"] == final["member_count"],
        "F005_READ_ONLY": stat.S_IMODE(ROOT.stat().st_mode) == 0o555 and all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()),
        "F006_DEFECT": lock["PRIMARY_VALIDATOR_RUNTIME_IDENTITY_VERDICT_RETURN_CONTROL_FLOW_DEFECT"] == "YES",
        "F007_DERIVED_GATE": lock["S_RUNTIME"] == "DERIVED_FAIL_CLOSED_EXECUTION_ERROR_FROM_VALIDATOR_CONTROL_FLOW_DEFECT",
        "F008_RUNTIME_AUTHORITY": lock["codex_0_166_0_runtime_authority"] == "COMPATIBILITY_PASS_LOCKED_PRESERVED",
        "F009_DECISION": lock["v33_disposition"] == "TERMINAL_IMMUTABLE_NO_RETRY" and lock["v34_disposition"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "F010_V33_FROZEN": verify_v33_frozen()["status"] == "PASS",
        "F011_NO_V33_EXECUTION": not (V33 / "STATIC_EXECUTION_LOCK.json").exists() and not any(V33.rglob("ATTEMPT_MARKER.json")) and not any(V33.rglob("runtime-result-0001.json")),
        "F012_V34_ABSENT": not V34.exists(),
        "F013_FINAL": final["status"] == "PASS",
    }
    passed = sum(checks.values())
    status = "PASS" if all(checks.values()) else "FAIL_CLOSED"
    print(f"FINAL_FREEZE_VERIFICATION={passed}/{len(checks)} {status}")
    print(f"GOVERNANCE_ROOT_SHA256={root_sha}")
    print(f"GOVERNANCE_LOCK_SHA256={sha256(ROOT / 'GOVERNANCE_LOCK.json')}")
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
