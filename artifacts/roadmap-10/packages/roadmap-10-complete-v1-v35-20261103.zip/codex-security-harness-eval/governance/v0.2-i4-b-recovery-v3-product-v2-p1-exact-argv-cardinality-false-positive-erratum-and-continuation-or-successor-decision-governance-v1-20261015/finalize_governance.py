#!/usr/bin/env python3
"""Issue the non-circular governance manifest and final governance-only lock."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_P1_EXACT_ARGV_CARDINALITY_FALSE_POSITIVE_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_V1"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


required = {
    "PREFLIGHT_RESULT.json": "PASS",
    "NEGATIVE_GOVERNANCE_TEST_RESULT.json": "PASS",
    "GOVERNANCE_TEST_RESULT.json": "PASS",
    "INDEPENDENT_VALIDATION_RESULT.json": "PASS",
    "HISTORICAL_IMMUTABILITY_RESULT.json": "PASS",
}
for name, expected in required.items():
    if load(name)["status"] != expected:
        raise SystemExit(f"mandatory result not {expected}: {name}")

if MANIFEST.exists() or LOCK.exists():
    raise SystemExit("manifest or governance lock already exists")

members = []
for path in sorted(ROOT.iterdir(), key=lambda item: item.name):
    if path.name in {MANIFEST.name, LOCK.name}:
        continue
    if path.is_symlink() or not path.is_file():
        raise SystemExit(f"non-regular governance member: {path.name}")
    members.append({"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path)})

manifest = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_COMPLETE_PENDING_FINAL_LOCK",
    "member_count": len(members),
    "files": members,
    "coverage": "Every regular governance artifact except this manifest and GOVERNANCE_LOCK.json; the lock is excluded to avoid circularity.",
}
MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
manifest_sha = sha(MANIFEST)
rows = b"".join(
    f"{item['sha256']}  {item['path']}\n".encode("utf-8")
    for item in sorted(members, key=lambda item: item["path"])
)
rows += f"{manifest_sha}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("utf-8")
canonical_root = hashlib.sha256(rows).hexdigest()

preflight = load("PREFLIGHT_RESULT.json")
negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT.json")
self_test = load("GOVERNANCE_TEST_RESULT.json")
independent = load("INDEPENDENT_VALIDATION_RESULT.json")
matrix = load("OPERATION_AUTHORIZATION_MATRIX.json")
binds = load("SEMANTIC_WRITABLE_BIND_INVENTORY.json")
continuation = load("PRODUCT_V2_CONTINUATION_OR_SUCCESSOR_DECISION.json")
source_binding = load("PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json")
fresh = load("FRESH_VALIDATION_AUTHORIZATION_DECISION.json")
next_step = load("NEXT_LEGAL_MILESTONE.json")

lock = {
    "schema_version": 1,
    "governance_identity": IDENTITY,
    "status": "PASS_LOCKED_GOVERNANCE_ONLY",
    "disposition": "CONFIRMED_CARDINALITY_FALSE_POSITIVE_OPTION_A_EXISTING_PRODUCT_V2_DISTINCT_VALIDATOR_V2_CONDITIONAL_STATIC_RUN_V2_P3_BLOCKED",
    "governance_manifest_sha256": manifest_sha,
    "canonical_artifact_root_sha256": canonical_root,
    "canonical_root_member_count": len(members) + 1,
    "canonical_root_algorithm": "SHA256 of member-path-sorted UTF-8 rows '<sha256>  <relative-path>\\n', followed by the GOVERNANCE_ARTIFACT_MANIFEST.json row; GOVERNANCE_LOCK.json excluded",
    "predecessor_governance_lock_sha256": "c2876c89697f2a7bb7b50b5e79591ddff12c05505f90ab81f62262bee942d613",
    "predecessor_governance_manifest_sha256": "d8596043f5d9beb646dbe4865131458ed53af38140f807afb8afa360fa4c7fd7",
    "predecessor_canonical_root_sha256": "00a44dc1ebc1371f85ddea3c335004b2faea2ea84fa45b587fe792f0c9259190",
    "canonical_preflight": f"{preflight['checks_passed']}_OF_{preflight['checks_total']}_PASS",
    "negative_governance_tests": f"{negative['tests_passed']}_OF_{negative['tests_total']}_PASS",
    "governance_self_tests": f"{self_test['checks_passed']}_OF_{self_test['checks_total']}_PASS",
    "independent_validation": f"{independent['checks_passed']}_OF_{independent['checks_total']}_PASS",
    "freeze_verification_expected": "33_OF_33_PASS",
    "original_P1": "FAIL_CLOSED_BLOCKED_BEFORE_STATIC_LOCK_TERMINAL_NO_RERUN_NO_PROMOTION",
    "original_P1_product_result_sha256": "b66303ce5f908b55f48eae335e8b421a1b6b5bbcbc636b358a32f99d8d3d2b5d",
    "original_P1_independent_result_sha256": "52fbf8f92f3a3e4bb87dc3e50d194871e305d1e877a097fe5173343f9fe8fd30",
    "root_cause": "CONFIRMED_RAW_PATH_OCCURRENCE_COUNT_INCLUDED_APPLICATION_RUN_OPERAND",
    "canonical_argv_sha256": "6c91cfaec676e5910ecb3339d4d1e0361384f96cfa67855bd795faa91489439a",
    "explicit_writable_bind_operation_count": binds["total_bind_operations"],
    "primary_root_bind_operation_count": binds["primary_root_bind_operations"],
    "nested_authorized_projection_operation_count": binds["nested_authorized_projection_operations"],
    "persistent_backing_authority_root_count": len(binds["distinct_persistent_backing_authority_roots"]),
    "product_v2_identity": "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V3_OFFLINE_PRODUCT_IMPLEMENTATION_V4",
    "product_v2_root": source_binding["product_root"],
    "product_v2_disposition": continuation["decision"],
    "product_v2_existing_source": "PRESERVED_AND_DIGEST_BOUND_NO_MUTATION_AUTHORIZED",
    "fresh_validator_identity": fresh["validator_identity"],
    "fresh_validator_path": fresh["validator_path"],
    "fresh_validation_identity": fresh["validation_identity"],
    "fresh_validation_operation": fresh["operation_identity"],
    "fresh_validation_output_path": fresh["writable_output_path"],
    "fresh_validation_status": fresh["status"],
    "fresh_validation_execution_eligibility": fresh["current_execution_eligibility"],
    "fresh_validation_attempt_count": fresh["attempt_count"],
    "P3_V2": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE",
    "P6": "NOT_ELIGIBLE_NOT_AUTHORIZED",
    "Recovery_V2": "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY",
    "original_S03": "FAIL_CLOSED_NO_RETRY_SEPARATE_EVIDENCE_ADMISSIBLE",
    "execution_counts": matrix["execution_counts"],
    "next_legal_milestone": next_step["milestone"],
    "claim_boundary": "Governance-only semantic adjudication. It does not rewrite or rerun P1, implement validator V2, issue a Product V2 static execution lock, execute static-run V2, authorize P3/P6, or authorize operational Recovery V3.",
}
LOCK.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8")

print(json.dumps({
    "status": lock["status"],
    "member_count": len(members) + 1,
    "manifest_sha256": manifest_sha,
    "lock_sha256": sha(LOCK),
    "canonical_artifact_root_sha256": canonical_root,
}, indent=2))
