#!/usr/bin/env python3
"""Build governance-only P1 argv-cardinality adjudication artifacts."""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import pathlib
import stat
from datetime import datetime, timezone


ROOT = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path("/home/nobcoder")
GOV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v1-incident-evidence-source-unavailable-adjudication-and-product-v2-eligibility-governance-v1-20261014"
PRODUCT = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2"
PRODUCT_V1 = PRODUCT.parent / "product-v1"
S03 = PRODUCT.parent / "artifacts/runtime"
GUARD = BASE / "v0.2-i4-b-v2-evidence-recovery-live-guard-v2-20261013"
CONTRACT = PRODUCT / "contracts/STATIC_RUN_CONTRACT.json"
P1 = PRODUCT / "prelock-results/PRE_EXECUTION_STATIC_VALIDATION_RESULT.json"
P1_INDEPENDENT = PRODUCT / "prelock-results/PRE_EXECUTION_INDEPENDENT_STATIC_VALIDATION_RESULT.json"
RUN_V1 = PRODUCT / "static-run-v1"
VALIDATOR_V2 = PRODUCT / "validator-v2"
RUN_V2 = PRODUCT / "static-run-v2"
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_P1_EXACT_ARGV_CARDINALITY_FALSE_POSITIVE_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_V1"
PREDECESSOR_LOCK_SHA = "c2876c89697f2a7bb7b50b5e79591ddff12c05505f90ab81f62262bee942d613"
PREDECESSOR_MANIFEST_SHA = "d8596043f5d9beb646dbe4865131458ed53af38140f807afb8afa360fa4c7fd7"
PREDECESSOR_ROOT = "00a44dc1ebc1371f85ddea3c335004b2faea2ea84fa45b587fe792f0c9259190"
P1_SHA = "b66303ce5f908b55f48eae335e8b421a1b6b5bbcbc636b358a32f99d8d3d2b5d"
P1_INDEPENDENT_SHA = "52fbf8f92f3a3e4bb87dc3e50d194871e305d1e877a097fe5173343f9fe8fd30"
ARGV_SHA = "6c91cfaec676e5910ecb3339d4d1e0361384f96cfa67855bd795faa91489439a"
CONTRACT_SHA = "ae3525180990e47006a041b9ec552ac3d7d320f9fcda586e2312b5fb25a47c46"


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))


def json_digest(value) -> str:
    return hashlib.sha256(json.dumps(value, separators=(",", ":"), ensure_ascii=True).encode("ascii")).hexdigest()


def write_json(name: str, value) -> None:
    path = ROOT / name
    if os.path.lexists(path):
        raise RuntimeError(f"refusing to overwrite governance artifact: {name}")
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


ZERO = {
    "--unshare-user", "--unshare-pid", "--unshare-net", "--unshare-ipc",
    "--unshare-uts", "--die-with-parent", "--new-session", "--clearenv",
}
ONE = {
    "--cap-drop", "--proc", "--dev", "--tmpfs", "--remount-ro", "--chdir",
    "--unsetenv", "--lock-file", "--sync-fd", "--overlay-src", "--tmp-overlay",
    "--ro-overlay", "--perms", "--size",
}
TWO = {
    "--bind", "--bind-try", "--dev-bind", "--dev-bind-try", "--ro-bind",
    "--ro-bind-try", "--setenv", "--file", "--bind-data", "--ro-bind-data",
}
THREE = {"--overlay"}
MOUNT_OPTIONS = {
    "--bind", "--bind-try", "--dev-bind", "--dev-bind-try", "--ro-bind",
    "--ro-bind-try", "--proc", "--dev", "--tmpfs", "--remount-ro",
    "--overlay-src", "--overlay", "--tmp-overlay", "--ro-overlay",
}
WRITABLE_HOST_OPTIONS = {"--bind", "--bind-try", "--dev-bind", "--dev-bind-try", "--overlay"}


def parse_bwrap(argv: list[str]) -> dict:
    if not argv or argv[0] != "/usr/bin/bwrap":
        raise ValueError("unexpected bubblewrap executable")
    parsed = []
    mounts = []
    index = 1
    command_index = None
    while index < len(argv):
        token = argv[index]
        if token == "--":
            command_index = index + 1
            break
        if not token.startswith("--"):
            command_index = index
            break
        if token in ZERO:
            arity = 0
        elif token in ONE:
            arity = 1
        elif token in TWO:
            arity = 2
        elif token in THREE:
            arity = 3
        else:
            raise ValueError(f"unknown bubblewrap option: {token}")
        if index + arity >= len(argv):
            raise ValueError(f"missing operand for {token}")
        operands = argv[index + 1:index + 1 + arity]
        if token in MOUNT_OPTIONS and any(value.startswith("--") for value in operands):
            raise ValueError(f"malformed mount operands for {token}")
        row = {"argv_index": index, "option": token, "operands": operands}
        parsed.append(row)
        if token in MOUNT_OPTIONS:
            mount = dict(row)
            if token in {"--bind", "--bind-try", "--dev-bind", "--dev-bind-try", "--ro-bind", "--ro-bind-try"}:
                mount.update({"source": operands[0], "destination": operands[1]})
            elif token == "--overlay":
                mount.update({"source": operands[0], "workdir": operands[1], "destination": operands[2]})
            elif token == "--overlay-src":
                mount.update({"source": operands[0]})
            else:
                mount.update({"destination": operands[-1]})
            mount["host_backed_writable"] = token in WRITABLE_HOST_OPTIONS
            mounts.append(mount)
        index += arity + 1
    if command_index is None or command_index >= len(argv):
        raise ValueError("missing sandbox command")
    return {"options": parsed, "mounts": mounts, "command_index": command_index, "command": argv[command_index:]}


def minimal_authority_roots(paths: list[pathlib.Path]) -> list[pathlib.Path]:
    roots = []
    for candidate in sorted(set(paths), key=lambda p: (len(p.parts), str(p))):
        if not any(candidate == root or root in candidate.parents for root in roots):
            roots.append(candidate)
    return roots


def predecessor_root() -> str:
    manifest = load(GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    rows = b"".join(
        f"{item['sha256']}  {item['path']}\n".encode()
        for item in sorted(manifest["files"], key=lambda value: value["path"])
    )
    rows += f"{sha(GOV / 'GOVERNANCE_ARTIFACT_MANIFEST.json')}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode()
    return hashlib.sha256(rows).hexdigest()


def product_inventory() -> list[dict]:
    return [
        {"path": path.relative_to(PRODUCT).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}
        for path in sorted(PRODUCT.rglob("*")) if path.is_file()
    ]


def main() -> int:
    expected_product = {
        "source/Collect-V3PartialEvidenceRecoveryPackageV3.ps1": "2b6e9b173f65711015de9b499aa8307cf74ffc3d335f5de109516a44cf20a3c3",
        "source/RecoveryV3AttemptLedgerClient.psm1": "bc40da1a680c321b427f28f2dd89cc8cd4c4c1184c9f1cc4d49837c29778f7f3",
        "source/broker/RecoveryAttemptLedgerBrokerV1.cs": "c8f5f97ae2ccf4333dca0f9350f45df33094a4d5939569de32769440d3dfc1a7",
        "source/broker/RecoveryAttemptLedgerBrokerV1.csproj": "6ea2ab175db687a797dd8c0c26c9ac06a7438b907170e1696e3c85fbcac991ec",
        "source/global.json": "44d40d0f4ec71ba8c5e0576b028464fda2687d730384c411c9839c20122dc0e4",
        "source/tests/RecoveryV3OfflineTests.cs": "a1ef5c521a06f9f064f7b248dce6ae4211a6eb6bdb63444338005c506e61c3bb",
        "source/tests/RecoveryV3OfflineTests.csproj": "e0b18d0727aab97b5684ae7acd5af9dd3f9eafcc261efb638a371f0901e201bf",
        "source/tests/packages.lock.json": "5d580649a2d50d1274d1a059b1ae66cf0a907afe003ef68f8bcbe6e6c6691ab1",
    }
    old_product = {
        "source/Collect-V3PartialEvidenceRecoveryPackageV3.ps1": "0ae64638b63e77d2cab585a89c3de2cb4cb2aa7c576599786b6c241113210421",
        "source/RecoveryV3AttemptLedgerClient.psm1": "2b418c2fd46b09c44c81dae423db05588956e3b0727b93cd095376fd65e8cbf7",
        "source/broker/RecoveryAttemptLedgerBrokerV1.cs": "af6fed892baa61dac88e01b5ab23de1fc15fbddd158ea49d76e3a0859bb33910",
        "source/tests/RecoveryV3OfflineTests.cs": "a1ef5c521a06f9f064f7b248dce6ae4211a6eb6bdb63444338005c506e61c3bb",
        "contracts/TOOLCHAIN_CLOSURE_MANIFEST.json": "23477cb21b2f7d2d77a1d4a39a0a84a1f750713c68be5b2733760a3f3c1a75f7",
        "contracts/OFFLINE_FEED_MANIFEST.json": "3c4ea49346c2334aa0b74d7ddd0f947a344d637f8b8701b4c91b8b99d8b8bef8",
    }
    checks = []
    def check(name, condition, evidence=None):
        row = {"id": f"C{len(checks)+1:03d}", "name": name, "pass": bool(condition)}
        if evidence is not None:
            row["evidence"] = evidence
        checks.append(row)

    manifest = load(GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load(GOV / "GOVERNANCE_LOCK.json")
    actual_members = sorted(p.name for p in GOV.iterdir() if p.is_file() and p.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"})
    listed_members = sorted(item["path"] for item in manifest["files"])
    check("predecessor lock digest", sha(GOV / "GOVERNANCE_LOCK.json") == PREDECESSOR_LOCK_SHA)
    check("predecessor manifest digest", sha(GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json") == PREDECESSOR_MANIFEST_SHA)
    check("predecessor canonical root", predecessor_root() == lock["canonical_artifact_root_sha256"] == PREDECESSOR_ROOT)
    check("predecessor manifest count", manifest["member_count"] == len(manifest["files"]) == 20)
    check("predecessor manifest coverage", actual_members == listed_members)
    check("predecessor members exact", all((GOV / item["path"]).stat().st_size == item["bytes"] and sha(GOV / item["path"]) == item["sha256"] for item in manifest["files"]))
    check("P1 product result digest", sha(P1) == P1_SHA)
    check("P1 independent result digest", sha(P1_INDEPENDENT) == P1_INDEPENDENT_SHA)
    p1 = load(P1); independent = load(P1_INDEPENDENT)
    check("P1 product result terminal", p1["status"] == "FAIL_CLOSED" and p1["checks_passed"] == 55 and p1["checks_total"] == 56)
    check("P1 independent result terminal", independent["status"] == "FAIL_CLOSED" and independent["checks_passed"] == 47 and independent["checks_total"] == 48)
    check("S021 is sole product failure", [x["id"] for x in p1["checks"] if not x["pass"]] == ["S021"])
    check("I013 is sole independent failure", [x["id"] for x in independent["checks"] if not x["pass"]] == ["I013"])
    check("static contract digest", sha(CONTRACT) == CONTRACT_SHA)
    static_contract = load(CONTRACT); argv = static_contract["argv"]
    check("canonical argv digest", json_digest(argv) == independent["argv_sha256"] == ARGV_SHA)
    check("Product V2 identity", load(PRODUCT / "contracts/PRODUCT_V2_CONTRACT.json")["product_identity"] == "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V3_OFFLINE_PRODUCT_IMPLEMENTATION_V4")
    check("Product V2 source anchors", all(sha(PRODUCT / path) == digest for path, digest in expected_product.items()))
    check("Product V2 regular no symlink files", all(not path.is_symlink() for path in PRODUCT.rglob("*") if path.is_file()))
    check("Product V2 static lock absent", not os.path.lexists(PRODUCT / "STATIC_EXECUTION_LOCK.json"))
    check("Product V2 source manifest absent", not os.path.lexists(PRODUCT / "STATIC_SOURCE_MANIFEST.json"))
    check("static run V1 file count zero", not any(path.is_file() for path in RUN_V1.rglob("*")))
    check("fresh validator V2 path absent", not os.path.lexists(VALIDATOR_V2))
    check("fresh static run V2 path absent", not os.path.lexists(RUN_V2))
    check("Product V1 six anchors", all(sha(PRODUCT_V1 / path) == digest for path, digest in old_product.items()))
    check("SOURCE_UNAVAILABLE final", load(GOV / "SOURCE_UNAVAILABLE_RECORD.json")["status"] == "SOURCE_UNAVAILABLE_FORMALLY_RECORDED" and not os.path.lexists("/tmp/product-v1-trace-fixtures.json"))
    check("S03 mountinfo anchor", sha(S03 / "S03_V3_RAW_MOUNTINFO.bin") == "7b0aadc088593aace8b113b63e976bb74c04457ce14c6cbc593090c94c8d3bc0")
    check("S03 trace anchor", sha(S03 / "traces/s03.strace.4") == "d13d47b7bf7b0f36e244359a178335701ab689e8e135a4c93d932d8cb5376f47")
    check("S03 independent anchor", sha(S03 / "S03_V3_INDEPENDENT_VALIDATION_RESULT.json") == "224623ddd0f307e8542c2e7a3eeae8e502f215793828400c1fe776fa397dc594")
    check("Guard V2 source anchor", sha(GUARD / "Test-V3PartialEvidenceRecoveryV2LiveGuardsV2.ps1") == "2133e61216f65eee4f396a252ed8881a531ba9f0e668655f5fb6aca2901b4de4")
    guard_manifest = load(GUARD / "LIVE_GUARD_V2_SOURCE_MANIFEST.json")
    check("Guard V2 source manifest root", guard_manifest["source_root_sha256"] == "6428cf7324e25e9b27a2fdb5d02963869b5b1abaf58e9adc12fff95596c7d466")
    check("Guard V2 digest lock", load(GUARD / "LIVE_GUARD_V2_DIGEST_LOCK.json")["status"] == "PASS_LOCKED")
    check("Guard V2 validation lock", load(GUARD / "LIVE_GUARD_V2_VALIDATION_LOCK.json")["status"] == "PASS_LOCKED")
    check("Recovery V2 UNKNOWN", lock["Recovery_V2"] == "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY")
    check("P3 V2 prohibited", lock["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
    check("P6 prohibited", lock["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
    pfx = BASE / ".dotnet/corefx/cryptography/x509stores/my/6C1DA3DE00985BC59141C2F29474051A5FBD85EB.pfx"
    pfx_stat = pfx.lstat()
    check("PFX metadata only", pfx_stat.st_size == 2383 and stat.S_IMODE(pfx_stat.st_mode) == 0o600 and pfx_stat.st_mtime_ns == 1791882874439759161)
    check("bubblewrap binary digest", sha(pathlib.Path("/usr/bin/bwrap")) == "042763bc80c8a895a497e6f801af003d585ea5588a580f7a4349d9ab2aa22980")
    check("bubblewrap man page present", pathlib.Path("/usr/share/man/man1/bwrap.1.gz").is_file())
    man = gzip.decompress(pathlib.Path("/usr/share/man/man1/bwrap.1.gz").read_bytes())
    check("installed man documents bind arity", b"\\-\\-bind \\fR\\fBSRC" in man and b"\\fR\\fBDEST" in man)
    check("no conflicting governance lock", not any(path.name != ROOT.name and (path / "GOVERNANCE_LOCK.json").exists() for path in ROOT.parent.glob("*product-v2*p1*cardinality*")))

    parsed = parse_bwrap(argv)
    run_text = str(RUN_V1)
    run_positions = [index for index, value in enumerate(argv) if value == run_text]
    bind_mounts = [row for row in parsed["mounts"] if row["option"] == "--bind"]
    writable_sources = [pathlib.Path(row["source"]).resolve() for row in parsed["mounts"] if row["host_backed_writable"]]
    authority_roots = minimal_authority_roots(writable_sources)
    primary = [row for row in bind_mounts if row["source"] == run_text and row["destination"] == run_text]
    temp = [row for row in bind_mounts if row["destination"] in {"/tmp", "/var/tmp"}]
    check("raw RUN occurrences exact", run_positions == [20, 21, 91], run_positions)
    check("bubblewrap command boundary", parsed["command_index"] == 76 and parsed["command"][0] == "/usr/bin/strace")
    check("application run operand", argv[90:92] == ["--run", run_text])
    check("three bind operations", len(bind_mounts) == 3)
    check("one primary root bind", len(primary) == 1 and primary[0]["argv_index"] == 19)
    check("two nested temp projections", len(temp) == 2 and {x["destination"] for x in temp} == {"/tmp", "/var/tmp"})
    check("one backing authority root", authority_roots == [RUN_V1.resolve()])
    check("no out-of-root writable source", all(source == RUN_V1.resolve() or RUN_V1.resolve() in source.parents for source in writable_sources))
    check("S021 source raw count", 'argv.count(str(RUN)) == 2' in (PRODUCT / "tooling/static_product_checks.py").read_text())
    check("I013 source raw positions", 'run_positions = [i for i, value in enumerate(argv) if value == str(RUN)]' in (PRODUCT / "tooling/independent_static_product_checks.py").read_text())
    check("preflight all pass", all(row["pass"] for row in checks))
    if not all(row["pass"] for row in checks):
        print(json.dumps({"status": "FAIL_CLOSED", "failed": [row for row in checks if not row["pass"]]}, indent=2))
        return 1

    observed = datetime.now(timezone.utc).isoformat()
    write_json("PREFLIGHT_RESULT.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS",
        "checks_total": len(checks), "checks_passed": len(checks), "checks": checks,
        "observed_utc": observed, "write_boundary": str(ROOT),
    })
    write_json("ROUTING_AND_SCOPE_DECISION.json", {
        "schema_version": 1, "status": "PASS", "governance_identity": IDENTITY,
        "authorization": "GOVERNANCE_ONLY_LOCAL_IMMUTABLE_EVIDENCE_ADJUDICATION",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness", "PATH_CLI_GADGET_CHAIN_METHOD", "HARNESS_FALSIFICATION_METHOD", "STATE_MACHINE_SECURITY_METHOD"],
        "deferred": ["future semantic validator implementation", "future confined static validation V2"],
        "not_applicable": ["live target recon", "scanner execution", "multi-agent execution", "Windows operations", "dotnet execution", "NuGet execution", "P3", "P6", "operational recovery"],
        "claim_boundary": "Local read-only source and immutable evidence adjudication; no P1 rerun or operational execution.",
    })
    write_json("P1_TERMINAL_DISPOSITION.json", {
        "schema_version": 1, "status": "FAIL_CLOSED_TERMINAL_PRESERVED", "governance_identity": IDENTITY,
        "product_result": {"sha256": P1_SHA, "checks": "55_OF_56", "failed": "S021"},
        "independent_result": {"sha256": P1_INDEPENDENT_SHA, "checks": "47_OF_48", "failed": "I013"},
        "static_run_attempt_count": 0, "static_lock": "NOT_ISSUED", "promotion": "PROHIBITED", "rerun": "PROHIBITED",
    })
    hypotheses = [
        {"id": "H1", "hypothesis": "Validators count raw path occurrences rather than mount operations", "evidence": ["static_product_checks.py uses argv.count(str(RUN))", "independent_static_product_checks.py counts every equal token"], "independent_method": "source re-read plus structural argv parse", "falsifier": "either validator semantically parses option arity", "decision": "CONFIRMED"},
        {"id": "H2", "hypothesis": "The argv contains exactly one writable host-backed bind operation", "evidence": ["three --bind options at indices 19, 22, 25", "all three sources are RUN or descendants"], "independent_method": "bubblewrap option-arity parse", "falsifier": "a second writable bind operation or alias", "decision": "FALSIFIED_AS_LITERAL_OPERATION_COUNT_REFRAMED_AS_ONE_BACKING_AUTHORITY_ROOT"},
        {"id": "H3", "hypothesis": "Application --run operand was included in bind cardinality", "evidence": ["RUN occurs at indices 20,21,91", "index 91 follows application --run after command boundary 76"], "independent_method": "grammar boundary reconstruction", "falsifier": "index 91 lies in bubblewrap option region", "decision": "CONFIRMED"},
        {"id": "H4", "hypothesis": "A structural validator can reject unsafe mounts without weakening policy", "evidence": ["typed option arity", "explicit authority-root and alias inventory", "22 required negative fixture specifications"], "independent_method": "future independently locked validator and inert fixtures", "falsifier": "any forbidden duplicate, overlap, alias, option, digest, or application binding is accepted", "decision": "SUPPORTED_BY_CONTRACT_NOT_YET_IMPLEMENTED"},
        {"id": "H5", "hypothesis": "Existing Product V2 source can be reused under a distinct authorization", "evidence": ["static-run attempt count zero", "source anchors verified", "failure confined to validators", "new validator and result paths separated"], "independent_method": "single-use and historical non-interference review", "falsifier": "predecessor contract prohibits continuation or source drift is found", "decision": "CONFIRMED_ELIGIBLE_BY_THIS_GOVERNANCE_DECISION"},
    ]
    write_json("HYPOTHESIS_ADJUDICATION.json", {"schema_version": 1, "status": "PASS", "governance_identity": IDENTITY, "hypotheses": hypotheses})
    write_json("ARGV_CARDINALITY_ROOT_CAUSE.json", {
        "schema_version": 1, "status": "CONFIRMED_CARDINALITY_FALSE_POSITIVE", "governance_identity": IDENTITY,
        "S021": "RAW_PATH_TOKEN_COUNT_INCLUDES_APPLICATION_ARGUMENT", "I013": "RAW_EQUAL_TOKEN_POSITIONS_INCLUDE_APPLICATION_ARGUMENT",
        "raw_run_path_occurrences": 3, "occurrence_indices": run_positions,
        "root_cause_boundary": "The original PASS cannot be restored; both immutable results remain FAIL_CLOSED.",
    })
    mount_inventory = []
    for row in parsed["mounts"]:
        item = dict(row)
        if "source" in item and item["source"].startswith("/"):
            item["canonical_source"] = str(pathlib.Path(item["source"]).resolve())
        item["authorization"] = "AUTHORIZED" if row["option"] in {"--ro-bind", "--proc", "--dev", "--tmpfs", "--bind"} else "NOT_AUTHORIZED"
        mount_inventory.append(item)
    write_json("BUBBLEWRAP_OPTION_SEMANTICS_REVIEW.json", {
        "schema_version": 1, "status": "PASS_STRUCTURALLY_PARSED", "governance_identity": IDENTITY,
        "installed_version": "0.11.2-2", "binary_sha256": sha(pathlib.Path("/usr/bin/bwrap")),
        "manpage_sha256": sha(pathlib.Path("/usr/share/man/man1/bwrap.1.gz")),
        "command_index": parsed["command_index"], "option_count": len(parsed["options"]), "mount_operations": mount_inventory,
        "unknown_options": [], "runtime_confinement_claim": "NOT_EVALUATED_BY_THIS_GOVERNANCE",
    })
    write_json("SEMANTIC_WRITABLE_BIND_INVENTORY.json", {
        "schema_version": 1, "status": "PASS_NO_UNAUTHORIZED_BACKING_ROOT_IDENTIFIED", "governance_identity": IDENTITY,
        "total_bind_operations": len(bind_mounts), "primary_root_bind_operations": len(primary), "nested_authorized_projection_operations": len(temp),
        "distinct_persistent_backing_authority_roots": [str(path) for path in authority_roots],
        "unauthorized_backing_roots": [], "binds": bind_mounts,
        "semantic_conclusion": "One persistent writable authority root is exposed through three explicit bind operations: root, /tmp, and /var/tmp.",
    })
    write_json("EXACT_ARGV_INTEGRITY_REVIEW.json", {
        "schema_version": 1, "status": "PASS_EXACT_BYTES_VERIFIED_NOT_STATICALLY_LOCKED", "governance_identity": IDENTITY,
        "contract_path": str(CONTRACT), "contract_sha256": sha(CONTRACT), "canonical_argv_sha256": json_digest(argv),
        "expected_sha256": ARGV_SHA, "argv_length": len(argv), "command_index": parsed["command_index"],
        "application_run_operand_index": 91, "static_lock_issued": False,
    })
    write_json("CORRECTED_VALIDATOR_REQUIREMENTS.json", {
        "schema_version": 1, "status": "AUTHORIZED_REQUIREMENTS", "governance_identity": IDENTITY,
        "validator_identity": "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2",
        "requirements": [
            "Parse bubblewrap option region and operands using version-bound arity", "Fail closed on unknown or malformed options",
            "Verify the exact canonical argv digest independently", "Separate bubblewrap options from command and application arguments",
            "Require exactly one primary RUN-to-RUN writable root bind", "Allow only the two explicit nested RUN-backed projections to /tmp and /var/tmp",
            "Reject any additional writable backing authority root", "Reject duplicate destinations and unauthorized overlapping mounts",
            "Reject dev-bind, bind-try, unsafe remount, and writable overlay unless separately authorized",
            "Canonicalize and reject traversal or symlink aliases", "Verify the application --run operand separately",
            "Keep filesystem policy and argv identity as independent gates", "Retain original validators and results unchanged",
        ],
        "implementation_status": "NOT_IMPLEMENTED", "old_validator_repair": "PROHIBITED",
    })
    fixture_names = [
        "one_valid_primary_bind", "duplicate_identical_bind", "second_writable_authority_root", "overlapping_writable_mount",
        "unauthorized_dev_bind", "unauthorized_bind_try", "unexpected_remount_ro_order", "writable_overlay",
        "run_in_application_argument", "run_in_environment_value", "run_as_read_only_bind_operand", "missing_bind_operand",
        "wrong_bind_source", "wrong_bind_destination", "path_traversal", "symlink_alias", "unknown_option",
        "unexpected_argv_suffix", "incorrect_argv_digest", "corrupted_argv_representation", "invalid_application_run_binding",
        "correct_primary_cardinality_unsafe_mount_policy",
    ]
    write_json("NEGATIVE_TEST_MATRIX.json", {
        "schema_version": 1, "status": "SPECIFIED", "governance_identity": IDENTITY,
        "tests": [{"id": f"N{index+1:02d}", "name": name, "expected": "PASS" if name in {"one_valid_primary_bind", "run_in_application_argument", "run_in_environment_value"} else "REJECT_OR_SEPARATELY_CLASSIFY"} for index, name in enumerate(fixture_names)],
    })
    inventory = product_inventory()
    write_json("PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json", {
        "schema_version": 1, "status": "PASS_BOUND_FOR_CONTINUATION", "governance_identity": IDENTITY,
        "product_identity": "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V3_OFFLINE_PRODUCT_IMPLEMENTATION_V4",
        "product_root": str(PRODUCT), "inventory_count": len(inventory), "files": inventory,
        "source_anchors": expected_product, "allowed_future_change": "NEW_VALIDATOR_V2_AND_STATIC_RUN_V2_PATHS_ONLY_UNDER_SEPARATE_LOCK",
        "existing_product_source_mutation": "PROHIBITED",
    })
    write_json("PRODUCT_V2_CONTINUATION_OR_SUCCESSOR_DECISION.json", {
        "schema_version": 1, "status": "PASS_DECISION_ISSUED", "governance_identity": IDENTITY,
        "decision": "OPTION_A_EXISTING_PRODUCT_V2_SOURCE_WITH_DISTINCT_VALIDATOR_AND_VALIDATION_IDENTITY",
        "product_source": "PRESERVE_AND_REUSE_EXACT_BOUND_BYTES", "old_validators": "TERMINAL_IMMUTABLE_NO_PATCH_NO_RERUN",
        "new_validator_path": str(VALIDATOR_V2), "new_static_output_path": str(RUN_V2),
        "new_product_successor_required": False,
        "basis": ["zero static-run attempts", "no source drift", "failure isolated to cardinality predicates", "distinct output and identity prevent replay"],
    })
    write_json("FRESH_VALIDATION_AUTHORIZATION_DECISION.json", {
        "schema_version": 1, "status": "CONDITIONAL_SINGLE_USE_AUTHORIZED_NOT_EXECUTABLE_YET", "governance_identity": IDENTITY,
        "validator_identity": "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2",
        "validation_identity": "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V2",
        "operation_identity": "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V2",
        "maximum_attempts": 1, "attempt_count": 0, "no_retry": True,
        "validator_path": str(VALIDATOR_V2), "writable_output_path": str(RUN_V2),
        "execution_preconditions": ["validator V2 implementation complete", "22 semantic fixtures pass", "independent validator review passes", "exact future argv and digest locked", "existing Product V2 source digests rebound", "runtime confinement gates pass"],
        "current_execution_eligibility": "BLOCKED_PENDING_VALIDATOR_V2_IMPLEMENTATION_STATIC_LOCK_AND_EXACT_ARGV_BINDING",
        "P1_V1_reuse": "PROHIBITED",
    })
    write_json("OPERATION_AUTHORIZATION_MATRIX.json", {
        "schema_version": 1, "status": "STAGED_FAIL_CLOSED_AUTHORIZATION", "governance_identity": IDENTITY,
        "decisions": [
            {"stage": "original P1", "operation": "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V1", "decision": "TERMINAL_FAIL_CLOSED_NO_RERUN_NO_PROMOTION"},
            {"stage": "validator V2 implementation", "operation": "NO_BUBBLEWRAP_NO_STRACE", "decision": "AUTHORIZED_OFFLINE_NEW_PATH_ONLY"},
            {"stage": "validator V2 inert fixtures and static lock", "operation": "NO_PRODUCT_RUNTIME", "decision": "AUTHORIZED_AFTER_THIS_GOVERNANCE_LOCK"},
            {"stage": "fresh confined static validation V2", "operation": "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V2", "decision": "CONDITIONAL_SINGLE_USE_NOT_EXECUTABLE_UNTIL_NEW_STATIC_LOCK"},
            {"stage": "P3 V2", "operation": "P03_SUCCESSOR_V3_CONFINED_DOTNET_BUILD_AND_PRODUCT_TEST_V2", "decision": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE"},
            {"stage": "P6", "operation": "NONE", "decision": "NOT_ELIGIBLE_NOT_AUTHORIZED"},
            {"stage": "operational recovery", "operation": "NONE", "decision": "NOT_AUTHORIZED"},
        ],
        "execution_counts": {"P1_rerun": 0, "static_run_v2": 0, "bubblewrap": 0, "strace": 0, "dotnet": 0, "nuget": 0, "P3": 0, "P6": 0, "guard": 0, "recovery": 0, "windows": 0, "vboxmanage": 0, "vm_vdi_iso": 0},
    })
    write_json("HISTORICAL_IMMUTABILITY_RESULT.json", {
        "schema_version": 1, "status": "PASS", "governance_identity": IDENTITY,
        "product_v1": "TERMINAL_SIX_ANCHORS_VERIFIED", "product_v2_existing_inventory": f"{len(inventory)}_OF_{len(inventory)}_BOUND_READ_ONLY_DURING_GOVERNANCE",
        "original_P1": "FAIL_CLOSED_RESULTS_UNCHANGED", "original_S03": "FAIL_CLOSED_NO_RETRY_SEPARATE_EVIDENCE_ADMISSIBLE",
        "source_unavailable": "FINAL_NO_RECONSTRUCTION", "Recovery_V2": "CONSUMPTION_UNKNOWN_BLOCKED_NOT_EXECUTABLE_NO_RETRY",
        "historical_mutations": 0, "PFX_private_key_read": False,
    })
    write_json("NEXT_LEGAL_MILESTONE.json", {
        "schema_version": 1, "status": "AUTHORIZED_NEXT", "governance_identity": IDENTITY,
        "milestone": "IMPLEMENT_TEST_AND_STATICALLY_LOCK_RECOVERY_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2_THEN_EXECUTE_CONFINED_STATIC_VALIDATION_V2_ONCE_IF_ALL_GATES_PASS",
        "scope": "Create only validator-v2 and static-run-v2, preserve existing Product V2 bytes, run inert semantic fixtures, issue a new static lock, and consume the fresh operation at most once only after every gate passes.",
        "still_blocked": ["P3 V2", "P6", ".NET", "NuGet", "Guard V3", "Recovery V3", "Windows", "VBoxManage", "VM provisioning", "I5", "V0.3"],
    })
    print(json.dumps({"status": "PASS", "preflight": f"{len(checks)}/{len(checks)}", "bind_operations": len(bind_mounts), "authority_roots": len(authority_roots)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
