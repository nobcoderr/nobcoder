#!/usr/bin/env python3
"""Network-free inert negative fixtures for the proposed structural validator."""

from __future__ import annotations

import copy
import json
import os
import pathlib

from build_governance import ARGV_SHA, CONTRACT, IDENTITY, PRODUCT, RUN_V1, json_digest, load, parse_bwrap


ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json"
RUN = str(RUN_V1)


def assess(argv, expected_digest=ARGV_SHA, alias_escape=False):
    if not isinstance(argv, list) or not all(isinstance(value, str) for value in argv):
        return False, "CORRUPTED_REPRESENTATION"
    try:
        parsed = parse_bwrap(argv)
    except (ValueError, IndexError) as exc:
        return False, "PARSE_FAIL:" + str(exc)
    mounts = parsed["mounts"]
    forbidden = {"--bind-try", "--dev-bind", "--dev-bind-try", "--remount-ro", "--overlay", "--tmp-overlay", "--ro-overlay"}
    if any(row["option"] in forbidden for row in mounts):
        return False, "FORBIDDEN_MOUNT_MECHANISM"
    expected_mounts = [
        ("--ro-bind", "/", "/"), ("--proc", None, "/proc"), ("--dev", None, "/dev"),
        ("--tmpfs", None, "/run"), ("--bind", RUN, RUN),
        ("--bind", RUN + "/sandbox/tmp", "/tmp"),
        ("--bind", RUN + "/sandbox/var-tmp", "/var/tmp"),
    ]
    actual_mounts = [(row["option"], row.get("source"), row.get("destination")) for row in mounts]
    if actual_mounts != expected_mounts:
        return False, "MOUNT_POLICY_MISMATCH"
    destinations = [row.get("destination") for row in mounts if row.get("destination")]
    if len(destinations) != len(set(destinations)):
        return False, "DUPLICATE_DESTINATION"
    writable = [row for row in mounts if row["host_backed_writable"]]
    if len(writable) != 3:
        return False, "WRITABLE_BIND_OPERATION_COUNT"
    if sum(row.get("source") == RUN and row.get("destination") == RUN for row in writable) != 1:
        return False, "PRIMARY_ROOT_BIND_COUNT"
    for row in writable:
        source = pathlib.PurePosixPath(row["source"])
        if ".." in source.parts:
            return False, "PATH_TRAVERSAL"
        if row["source"] != RUN and not row["source"].startswith(RUN + "/"):
            return False, "OUTSIDE_AUTHORITY_ROOT"
    if alias_escape:
        return False, "SYMLINK_ALIAS_ESCAPE"
    command = parsed["command"]
    if len(command) < 6 or command[-6:] != [
        "/usr/bin/python3.14", str(PRODUCT / "tooling/static_run_entry.py"),
        "--product", str(PRODUCT), "--run", RUN,
    ]:
        return False, "APPLICATION_BINDING_MISMATCH"
    if json_digest(argv) != expected_digest:
        return False, "EXACT_ARGV_DIGEST_MISMATCH"
    return True, "PASS"


def insert_before_command(argv, values):
    parsed = parse_bwrap(argv)
    return argv[:parsed["command_index"]] + values + argv[parsed["command_index"]:]


def main():
    if os.path.lexists(OUT):
        raise RuntimeError("refusing to overwrite negative result")
    base = load(CONTRACT)["argv"]
    fixtures = []
    def add(name, candidate, expected_accept, expected_reason=None, expected_digest=ARGV_SHA, alias=False):
        accepted, reason = assess(candidate, expected_digest=expected_digest, alias_escape=alias)
        passed = accepted == expected_accept and (expected_reason is None or reason.startswith(expected_reason))
        fixtures.append({"id": f"N{len(fixtures)+1:02d}", "name": name, "expected_accept": expected_accept, "expected_reason": expected_reason, "observed_accept": accepted, "observed_reason": reason, "pass": passed})

    add("one_valid_primary_bind", copy.deepcopy(base), True, "PASS")
    add("duplicate_identical_bind", insert_before_command(copy.deepcopy(base), ["--bind", RUN, RUN]), False, "MOUNT_POLICY_MISMATCH")
    add("second_writable_authority_root", insert_before_command(copy.deepcopy(base), ["--bind", "/outside", "/outside"]), False, "MOUNT_POLICY_MISMATCH")
    add("overlapping_writable_mount", insert_before_command(copy.deepcopy(base), ["--bind", RUN + "/sandbox/other", "/tmp/nested"]), False, "MOUNT_POLICY_MISMATCH")
    add("unauthorized_dev_bind", insert_before_command(copy.deepcopy(base), ["--dev-bind", RUN, "/dev/host"]), False, "FORBIDDEN_MOUNT_MECHANISM")
    add("unauthorized_bind_try", insert_before_command(copy.deepcopy(base), ["--bind-try", RUN, "/optional"]), False, "FORBIDDEN_MOUNT_MECHANISM")
    add("unexpected_remount_ro_order", insert_before_command(copy.deepcopy(base), ["--remount-ro", RUN]), False, "FORBIDDEN_MOUNT_MECHANISM")
    add("writable_overlay", insert_before_command(copy.deepcopy(base), ["--overlay", RUN + "/rw", RUN + "/work", "/overlay"]), False, "FORBIDDEN_MOUNT_MECHANISM")
    add("run_in_application_argument", copy.deepcopy(base), True, "PASS")
    add("run_in_environment_value", insert_before_command(copy.deepcopy(base), ["--setenv", "EXTRA_RUN_PATH", RUN]), False, "EXACT_ARGV_DIGEST_MISMATCH")
    add("run_as_read_only_bind_operand", insert_before_command(copy.deepcopy(base), ["--ro-bind", RUN, "/readonly-run"]), False, "MOUNT_POLICY_MISMATCH")
    malformed = copy.deepcopy(base); del malformed[21]
    add("missing_bind_operand", malformed, False, "PARSE_FAIL")
    wrong_source = copy.deepcopy(base); wrong_source[20] = "/outside"
    add("wrong_bind_source", wrong_source, False, "MOUNT_POLICY_MISMATCH")
    wrong_dest = copy.deepcopy(base); wrong_dest[21] = "/outside"
    add("wrong_bind_destination", wrong_dest, False, "MOUNT_POLICY_MISMATCH")
    traversal = copy.deepcopy(base); traversal[23] = RUN + "/sandbox/../escape"
    add("path_traversal", traversal, False, "MOUNT_POLICY_MISMATCH")
    add("symlink_alias", copy.deepcopy(base), False, "SYMLINK_ALIAS_ESCAPE", alias=True)
    add("unknown_bubblewrap_option", insert_before_command(copy.deepcopy(base), ["--unknown-security-option"]), False, "PARSE_FAIL")
    suffix = copy.deepcopy(base) + ["--unexpected"]
    add("unexpected_argv_suffix", suffix, False, "APPLICATION_BINDING_MISMATCH")
    add("incorrect_canonical_argv_digest", copy.deepcopy(base), False, "EXACT_ARGV_DIGEST_MISMATCH", expected_digest="0" * 64)
    add("corrupted_argv_representation", {"argv": base}, False, "CORRUPTED_REPRESENTATION")
    bad_run = copy.deepcopy(base); bad_run[91] = RUN + "-other"
    add("invalid_application_run_binding", bad_run, False, "APPLICATION_BINDING_MISMATCH")
    unsafe = copy.deepcopy(base); unsafe[23] = RUN + "/sandbox/tmp"; unsafe[24] = "/etc"
    add("correct_primary_cardinality_unsafe_mount_policy", unsafe, False, "MOUNT_POLICY_MISMATCH")

    result = {
        "schema_version": 1, "governance_identity": IDENTITY,
        "status": "PASS" if all(row["pass"] for row in fixtures) else "FAIL_CLOSED",
        "tests_total": len(fixtures), "tests_passed": sum(row["pass"] for row in fixtures),
        "failed_ids": [row["id"] for row in fixtures if not row["pass"]], "tests": fixtures,
        "execution_boundary": {"bubblewrap": 0, "strace": 0, "P1_rerun": 0, "dotnet": 0, "nuget": 0},
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "tests": f"{result['tests_passed']}/{result['tests_total']}"}, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
