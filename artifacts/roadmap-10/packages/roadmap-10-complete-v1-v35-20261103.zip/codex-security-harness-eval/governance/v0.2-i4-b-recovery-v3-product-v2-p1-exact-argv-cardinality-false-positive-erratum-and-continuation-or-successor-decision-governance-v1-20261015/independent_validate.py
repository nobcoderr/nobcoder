#!/usr/bin/env python3
"""Independent governance verifier with a separately implemented argv parser."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import stat


ROOT = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path("/home/nobcoder")
PRODUCT = BASE / "v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2"
GOV = BASE / "codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v1-incident-evidence-source-unavailable-adjudication-and-product-v2-eligibility-governance-v1-20261014"
RUN = PRODUCT / "static-run-v1"
OUT = ROOT / "INDEPENDENT_VALIDATION_RESULT.json"
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_P1_EXACT_ARGV_CARDINALITY_FALSE_POSITIVE_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_V1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def canon(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":"), ensure_ascii=True).encode("ascii")).hexdigest()


def independent_parse(argv):
    arities = {
        "--unshare-user": 0, "--unshare-pid": 0, "--unshare-net": 0, "--unshare-ipc": 0,
        "--unshare-uts": 0, "--die-with-parent": 0, "--new-session": 0, "--clearenv": 0,
        "--cap-drop": 1, "--proc": 1, "--dev": 1, "--tmpfs": 1, "--chdir": 1,
        "--remount-ro": 1, "--setenv": 2, "--bind": 2, "--bind-try": 2,
        "--dev-bind": 2, "--dev-bind-try": 2, "--ro-bind": 2, "--ro-bind-try": 2,
        "--overlay-src": 1, "--tmp-overlay": 1, "--ro-overlay": 1, "--overlay": 3,
    }
    if not isinstance(argv, list) or argv[0] != "/usr/bin/bwrap":
        raise ValueError("executable")
    options = []; i = 1
    while i < len(argv) and argv[i].startswith("--"):
        option = argv[i]
        if option == "--":
            i += 1; break
        if option not in arities:
            raise ValueError("unknown")
        arity = arities[option]
        if i + arity >= len(argv):
            raise ValueError("missing")
        operands = argv[i+1:i+1+arity]
        if option in {"--bind", "--bind-try", "--dev-bind", "--dev-bind-try", "--ro-bind", "--ro-bind-try", "--proc", "--dev", "--tmpfs", "--remount-ro", "--overlay", "--overlay-src", "--tmp-overlay", "--ro-overlay"} and any(x.startswith("--") for x in operands):
            raise ValueError("malformed")
        options.append((i, option, operands))
        i += arity + 1
    if i >= len(argv):
        raise ValueError("command")
    return options, i, argv[i:]


def main():
    if os.path.lexists(OUT):
        raise RuntimeError("refusing to overwrite independent result")
    checks = []
    def verify(name, value, evidence=None):
        row = {"id": f"I{len(checks)+1:03d}", "name": name, "pass": bool(value)}
        if evidence is not None:
            row["evidence"] = evidence
        checks.append(row)

    verify("predecessor lock", sha(GOV / "GOVERNANCE_LOCK.json") == "c2876c89697f2a7bb7b50b5e79591ddff12c05505f90ab81f62262bee942d613")
    verify("predecessor manifest", sha(GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "d8596043f5d9beb646dbe4865131458ed53af38140f807afb8afa360fa4c7fd7")
    manifest = load(GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    verify("predecessor coverage", len(manifest["files"]) == 20 and all(sha(GOV / row["path"]) == row["sha256"] for row in manifest["files"]))
    p1 = PRODUCT / "prelock-results/PRE_EXECUTION_STATIC_VALIDATION_RESULT.json"
    ind = PRODUCT / "prelock-results/PRE_EXECUTION_INDEPENDENT_STATIC_VALIDATION_RESULT.json"
    verify("P1 product hash", sha(p1) == "b66303ce5f908b55f48eae335e8b421a1b6b5bbcbc636b358a32f99d8d3d2b5d")
    verify("P1 independent hash", sha(ind) == "52fbf8f92f3a3e4bb87dc3e50d194871e305d1e877a097fe5173343f9fe8fd30")
    verify("P1 product unchanged failure", load(p1)["status"] == "FAIL_CLOSED" and load(p1)["checks_passed"] == 55)
    verify("P1 independent unchanged failure", load(ind)["status"] == "FAIL_CLOSED" and load(ind)["checks_passed"] == 47)
    primary_source = (PRODUCT / "tooling/static_product_checks.py").read_text()
    independent_source = (PRODUCT / "tooling/independent_static_product_checks.py").read_text()
    verify("S021 raw count proven", 'argv.count(str(RUN)) == 2' in primary_source)
    verify("I013 raw positions proven", 'len(run_positions) == 2' in independent_source and 'value == str(RUN)' in independent_source)
    contract = load(PRODUCT / "contracts/STATIC_RUN_CONTRACT.json"); argv = contract["argv"]
    verify("argv digest", canon(argv) == "6c91cfaec676e5910ecb3339d4d1e0361384f96cfa67855bd795faa91489439a")
    options, command_index, command = independent_parse(argv)
    verify("command boundary", command_index == 76)
    verify("command is strace", command[0] == "/usr/bin/strace")
    run_positions = [i for i, value in enumerate(argv) if value == str(RUN)]
    verify("RUN occurrence indices", run_positions == [20, 21, 91], run_positions)
    verify("application RUN outside option region", 91 >= command_index and argv[90] == "--run")
    bind_rows = [(i, operands[0], operands[1]) for i, option, operands in options if option == "--bind"]
    verify("three actual bind operations", len(bind_rows) == 3, bind_rows)
    verify("one primary bind", sum(src == str(RUN) and dst == str(RUN) for _, src, dst in bind_rows) == 1)
    verify("two exact nested projections", {(src, dst) for _, src, dst in bind_rows if dst != str(RUN)} == {(str(RUN / "sandbox/tmp"), "/tmp"), (str(RUN / "sandbox/var-tmp"), "/var/tmp")})
    verify("single minimal authority root", all(src == str(RUN) or src.startswith(str(RUN) + "/") for _, src, _ in bind_rows))
    verify("no duplicate destination", len({dst for _, _, dst in bind_rows}) == len(bind_rows))
    verify("no writable alternate mechanism", not any(option in {"--bind-try", "--dev-bind", "--dev-bind-try", "--overlay", "--tmp-overlay"} for _, option, _ in options))
    for name in [
        "PREFLIGHT_RESULT.json", "P1_TERMINAL_DISPOSITION.json", "HYPOTHESIS_ADJUDICATION.json",
        "ARGV_CARDINALITY_ROOT_CAUSE.json", "BUBBLEWRAP_OPTION_SEMANTICS_REVIEW.json",
        "SEMANTIC_WRITABLE_BIND_INVENTORY.json", "EXACT_ARGV_INTEGRITY_REVIEW.json",
        "CORRECTED_VALIDATOR_REQUIREMENTS.json", "NEGATIVE_TEST_MATRIX.json",
        "NEGATIVE_GOVERNANCE_TEST_RESULT.json", "PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json",
        "PRODUCT_V2_CONTINUATION_OR_SUCCESSOR_DECISION.json", "FRESH_VALIDATION_AUTHORIZATION_DECISION.json",
        "OPERATION_AUTHORIZATION_MATRIX.json", "HISTORICAL_IMMUTABILITY_RESULT.json", "NEXT_LEGAL_MILESTONE.json",
        "GOVERNANCE_TEST_RESULT.json",
    ]:
        verify(f"artifact {name} regular", (ROOT / name).is_file() and not (ROOT / name).is_symlink())
    verify("preflight complete", load(ROOT / "PREFLIGHT_RESULT.json")["status"] == "PASS")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")
    verify("negative fixtures complete", negative["status"] == "PASS" and negative["tests_passed"] == negative["tests_total"] == 22)
    verify("negative fixtures inert", all(value == 0 for value in negative["execution_boundary"].values()))
    root = load(ROOT / "ARGV_CARDINALITY_ROOT_CAUSE.json")
    verify("root cause confirmed", root["status"] == "CONFIRMED_CARDINALITY_FALSE_POSITIVE")
    verify("root cause does not promote P1", load(ROOT / "P1_TERMINAL_DISPOSITION.json")["promotion"] == "PROHIBITED")
    semantic = load(ROOT / "SEMANTIC_WRITABLE_BIND_INVENTORY.json")
    verify("semantic counts", (semantic["total_bind_operations"], semantic["primary_root_bind_operations"], semantic["nested_authorized_projection_operations"]) == (3, 1, 2))
    verify("semantic authority root", semantic["distinct_persistent_backing_authority_roots"] == [str(RUN.resolve())])
    verify("no unauthorized roots", semantic["unauthorized_backing_roots"] == [])
    corrected = load(ROOT / "CORRECTED_VALIDATOR_REQUIREMENTS.json")
    verify("corrected validator distinct", corrected["validator_identity"].endswith("SEMANTIC_ARGV_VALIDATOR_V2"))
    verify("old validator patch prohibited", corrected["old_validator_repair"] == "PROHIBITED")
    verify("implementation not falsely claimed", corrected["implementation_status"] == "NOT_IMPLEMENTED")
    continuation = load(ROOT / "PRODUCT_V2_CONTINUATION_OR_SUCCESSOR_DECISION.json")
    verify("Option A explicit", continuation["decision"].startswith("OPTION_A"))
    verify("validator path absent and bound", continuation["new_validator_path"] == str(PRODUCT / "validator-v2") and not os.path.lexists(PRODUCT / "validator-v2"))
    verify("run V2 path absent and bound", continuation["new_static_output_path"] == str(PRODUCT / "static-run-v2") and not os.path.lexists(PRODUCT / "static-run-v2"))
    binding = load(ROOT / "PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json")
    actual = {p.relative_to(PRODUCT).as_posix(): sha(p) for p in PRODUCT.rglob("*") if p.is_file()}
    frozen = {row["path"]: row["sha256"] for row in binding["files"]}
    verify("Product V2 inventory exact", actual == frozen and len(actual) == 24)
    fresh = load(ROOT / "FRESH_VALIDATION_AUTHORIZATION_DECISION.json")
    verify("fresh identity distinct", fresh["validation_identity"].endswith("VALIDATION_V2"))
    verify("fresh attempt zero", fresh["attempt_count"] == 0 and fresh["maximum_attempts"] == 1)
    verify("fresh execution still gated", fresh["current_execution_eligibility"].startswith("BLOCKED_PENDING"))
    matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    verify("all operation counts zero", all(value == 0 for value in matrix["execution_counts"].values()))
    decisions = {row["stage"]: row["decision"] for row in matrix["decisions"]}
    verify("P3 blocked", decisions["P3 V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
    verify("P6 blocked", decisions["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
    verify("recovery blocked", decisions["operational recovery"] == "NOT_AUTHORIZED")
    immutable = load(ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json")
    verify("historical mutation zero", immutable["historical_mutations"] == 0)
    verify("PFX content not read claim", immutable["PFX_private_key_read"] is False)
    pfx = BASE / ".dotnet/corefx/cryptography/x509stores/my/6C1DA3DE00985BC59141C2F29474051A5FBD85EB.pfx"
    st = pfx.lstat()
    verify("PFX metadata unchanged", st.st_size == 2383 and stat.S_IMODE(st.st_mode) == 0o600 and st.st_mtime_ns == 1791882874439759161)
    verify("no static lock issued", not os.path.lexists(PRODUCT / "STATIC_EXECUTION_LOCK.json"))
    verify("no static-run files", not any(path.is_file() for path in (PRODUCT / "static-run-v1").rglob("*")))
    self_test = load(ROOT / "GOVERNANCE_TEST_RESULT.json")
    verify("self-test pass", self_test["status"] == "PASS" and self_test["checks_passed"] == self_test["checks_total"])
    result = {
        "schema_version": 1, "governance_identity": IDENTITY,
        "status": "PASS" if all(row["pass"] for row in checks) else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": sum(row["pass"] for row in checks),
        "failed_ids": [row["id"] for row in checks if not row["pass"]], "checks": checks,
        "independence": "Separate parser and direct evidence checks; product assertions were not rerun.",
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "checks": f"{result['checks_passed']}/{result['checks_total']}"}, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
