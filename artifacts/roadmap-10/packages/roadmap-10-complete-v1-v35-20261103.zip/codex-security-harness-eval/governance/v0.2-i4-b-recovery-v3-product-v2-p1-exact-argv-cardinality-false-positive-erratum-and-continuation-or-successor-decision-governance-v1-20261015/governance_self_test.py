#!/usr/bin/env python3
"""Governance self-tests over frozen predecessor evidence and new decisions."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib

from build_governance import (
    ARGV_SHA, CONTRACT, IDENTITY, P1, P1_INDEPENDENT, P1_INDEPENDENT_SHA,
    P1_SHA, PRODUCT, RUN_V1, RUN_V2, VALIDATOR_V2, json_digest, load, parse_bwrap, sha,
)


ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / "GOVERNANCE_TEST_RESULT.json"


def main():
    if os.path.lexists(OUT):
        raise RuntimeError("refusing to overwrite governance self-test result")
    checks = []
    def add(name, value):
        checks.append({"id": f"G{len(checks)+1:03d}", "name": name, "pass": bool(value)})

    required = [
        "PREFLIGHT_RESULT.json", "ROUTING_AND_SCOPE_DECISION.json", "P1_TERMINAL_DISPOSITION.json",
        "HYPOTHESIS_ADJUDICATION.json", "ARGV_CARDINALITY_ROOT_CAUSE.json",
        "BUBBLEWRAP_OPTION_SEMANTICS_REVIEW.json", "SEMANTIC_WRITABLE_BIND_INVENTORY.json",
        "EXACT_ARGV_INTEGRITY_REVIEW.json", "CORRECTED_VALIDATOR_REQUIREMENTS.json",
        "NEGATIVE_TEST_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_RESULT.json",
        "PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json", "PRODUCT_V2_CONTINUATION_OR_SUCCESSOR_DECISION.json",
        "FRESH_VALIDATION_AUTHORIZATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
        "HISTORICAL_IMMUTABILITY_RESULT.json", "NEXT_LEGAL_MILESTONE.json",
    ]
    for name in required:
        add(f"artifact {name} regular", (ROOT / name).is_file() and not (ROOT / name).is_symlink())
    add("preflight pass", load(ROOT / "PREFLIGHT_RESULT.json")["status"] == "PASS")
    add("negative tests pass", load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")["status"] == "PASS")
    add("negative fixture count", load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")["tests_passed"] == load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json")["tests_total"] == 22)
    add("original product result hash", sha(P1) == P1_SHA)
    add("original independent result hash", sha(P1_INDEPENDENT) == P1_INDEPENDENT_SHA)
    p1 = load(P1); independent = load(P1_INDEPENDENT)
    add("original product stays fail closed", p1["status"] == "FAIL_CLOSED" and p1["checks_passed"] == 55)
    add("original independent stays fail closed", independent["status"] == "FAIL_CLOSED" and independent["checks_passed"] == 47)
    add("original failures exact", [row["id"] for row in p1["checks"] if not row["pass"]] == ["S021"] and [row["id"] for row in independent["checks"] if not row["pass"]] == ["I013"])
    argv = load(CONTRACT)["argv"]
    add("argv digest exact", json_digest(argv) == ARGV_SHA)
    parsed = parse_bwrap(argv)
    add("command boundary exact", parsed["command_index"] == 76)
    add("strace command exact", parsed["command"][0] == "/usr/bin/strace")
    add("RUN indices exact", [i for i, value in enumerate(argv) if value == str(RUN_V1)] == [20, 21, 91])
    binds = [row for row in parsed["mounts"] if row["option"] == "--bind"]
    add("three total binds", len(binds) == 3)
    add("one primary bind", sum(row["source"] == str(RUN_V1) and row["destination"] == str(RUN_V1) for row in binds) == 1)
    add("two temp projections", {row["destination"] for row in binds if row["destination"] != str(RUN_V1)} == {"/tmp", "/var/tmp"})
    add("all writable sources under root", all(row["source"] == str(RUN_V1) or row["source"].startswith(str(RUN_V1) + "/") for row in binds))
    root_cause = load(ROOT / "ARGV_CARDINALITY_ROOT_CAUSE.json")
    add("root cause confirmed", root_cause["status"] == "CONFIRMED_CARDINALITY_FALSE_POSITIVE")
    add("root cause occurrences", root_cause["occurrence_indices"] == [20, 21, 91])
    hypotheses = {row["id"]: row for row in load(ROOT / "HYPOTHESIS_ADJUDICATION.json")["hypotheses"]}
    add("H1 confirmed", hypotheses["H1"]["decision"] == "CONFIRMED")
    add("H2 literal falsified", hypotheses["H2"]["decision"].startswith("FALSIFIED_AS_LITERAL"))
    add("H3 confirmed", hypotheses["H3"]["decision"] == "CONFIRMED")
    add("H4 remains implementation pending", hypotheses["H4"]["decision"] == "SUPPORTED_BY_CONTRACT_NOT_YET_IMPLEMENTED")
    add("H5 continuation eligible", hypotheses["H5"]["decision"] == "CONFIRMED_ELIGIBLE_BY_THIS_GOVERNANCE_DECISION")
    semantic = load(ROOT / "SEMANTIC_WRITABLE_BIND_INVENTORY.json")
    add("semantic total", semantic["total_bind_operations"] == 3)
    add("semantic primary", semantic["primary_root_bind_operations"] == 1)
    add("semantic projections", semantic["nested_authorized_projection_operations"] == 2)
    add("semantic one authority root", semantic["distinct_persistent_backing_authority_roots"] == [str(RUN_V1.resolve())])
    add("semantic no unauthorized root", semantic["unauthorized_backing_roots"] == [])
    exact = load(ROOT / "EXACT_ARGV_INTEGRITY_REVIEW.json")
    add("exact argv pass not locked", exact["status"] == "PASS_EXACT_BYTES_VERIFIED_NOT_STATICALLY_LOCKED" and exact["static_lock_issued"] is False)
    requirements = load(ROOT / "CORRECTED_VALIDATOR_REQUIREMENTS.json")
    add("replacement distinct", requirements["old_validator_repair"] == "PROHIBITED")
    add("replacement not implemented", requirements["implementation_status"] == "NOT_IMPLEMENTED")
    add("replacement requirement count", len(requirements["requirements"]) >= 12)
    continuation = load(ROOT / "PRODUCT_V2_CONTINUATION_OR_SUCCESSOR_DECISION.json")
    add("Option A selected", continuation["decision"].startswith("OPTION_A"))
    add("existing source preserved", continuation["product_source"] == "PRESERVE_AND_REUSE_EXACT_BOUND_BYTES")
    add("old validators terminal", continuation["old_validators"] == "TERMINAL_IMMUTABLE_NO_PATCH_NO_RERUN")
    add("validator path exact", continuation["new_validator_path"] == str(VALIDATOR_V2))
    add("run V2 path exact", continuation["new_static_output_path"] == str(RUN_V2))
    add("new product successor not required", continuation["new_product_successor_required"] is False)
    fresh = load(ROOT / "FRESH_VALIDATION_AUTHORIZATION_DECISION.json")
    add("fresh identity distinct", fresh["validation_identity"].endswith("CONFINED_STATIC_VALIDATION_V2"))
    add("fresh operation distinct", fresh["operation_identity"].endswith("CONFINED_STATIC_VALIDATION_V2"))
    add("fresh attempt zero", fresh["attempt_count"] == 0 and fresh["maximum_attempts"] == 1 and fresh["no_retry"] is True)
    add("fresh run currently blocked", fresh["current_execution_eligibility"].startswith("BLOCKED_PENDING"))
    add("P1 identity reuse prohibited", fresh["P1_V1_reuse"] == "PROHIBITED")
    matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    add("all execution counters zero", all(value == 0 for value in matrix["execution_counts"].values()))
    decisions = {row["stage"]: row["decision"] for row in matrix["decisions"]}
    add("P3 blocked", decisions["P3 V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
    add("P6 blocked", decisions["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
    add("recovery blocked", decisions["operational recovery"] == "NOT_AUTHORIZED")
    preservation = load(ROOT / "PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json")
    current = {path.relative_to(PRODUCT).as_posix(): sha(path) for path in PRODUCT.rglob("*") if path.is_file()}
    bound = {row["path"]: row["sha256"] for row in preservation["files"]}
    add("Product V2 inventory count", preservation["inventory_count"] == len(bound) == 24)
    add("Product V2 inventory exact", current == bound)
    add("validator V2 absent", not os.path.lexists(VALIDATOR_V2))
    add("run V2 absent", not os.path.lexists(RUN_V2))
    add("static lock still absent", not os.path.lexists(PRODUCT / "STATIC_EXECUTION_LOCK.json"))
    immutable = load(ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json")
    add("historical mutations zero", immutable["historical_mutations"] == 0)
    add("private key not read", immutable["PFX_private_key_read"] is False)
    next_step = load(ROOT / "NEXT_LEGAL_MILESTONE.json")
    add("next milestone limited", next_step["milestone"].startswith("IMPLEMENT_TEST_AND_STATICALLY_LOCK_RECOVERY_V3_PRODUCT_V2_SEMANTIC_ARGV_VALIDATOR_V2"))
    add("P3 remains next-stage blocked", "P3 V2" in next_step["still_blocked"])
    result = {
        "schema_version": 1, "governance_identity": IDENTITY,
        "status": "PASS" if all(row["pass"] for row in checks) else "FAIL_CLOSED",
        "checks_total": len(checks), "checks_passed": sum(row["pass"] for row in checks),
        "failed_ids": [row["id"] for row in checks if not row["pass"]], "checks": checks,
    }
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "checks": f"{result['checks_passed']}/{result['checks_total']}"}, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
