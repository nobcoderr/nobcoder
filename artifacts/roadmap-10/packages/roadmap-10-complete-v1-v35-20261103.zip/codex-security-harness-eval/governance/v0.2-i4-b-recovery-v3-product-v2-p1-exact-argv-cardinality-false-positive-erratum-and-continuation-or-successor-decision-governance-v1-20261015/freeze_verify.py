#!/usr/bin/env python3
"""Read-only verifier for the final governance freeze."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = ROOT / "GOVERNANCE_LOCK.json"
PRODUCT = Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2")
P1 = PRODUCT / "prelock-results/PRE_EXECUTION_STATIC_VALIDATION_RESULT.json"
P1I = PRODUCT / "prelock-results/PRE_EXECUTION_INDEPENDENT_STATIC_VALIDATION_RESULT.json"


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


checks = []


def add(name: str, value) -> None:
    checks.append({"id": f"F{len(checks) + 1:02d}", "name": name, "pass": bool(value)})


add("manifest regular", MANIFEST.is_file() and not MANIFEST.is_symlink())
add("lock regular", LOCK.is_file() and not LOCK.is_symlink())
manifest = load(MANIFEST)
lock = load(LOCK)
listed = sorted(item["path"] for item in manifest["files"])
actual = sorted(path.name for path in ROOT.iterdir() if path.is_file() and path.name not in {MANIFEST.name, LOCK.name})
add("manifest count", manifest["member_count"] == len(manifest["files"]))
add("manifest complete", listed == actual)
add("manifest unique", len(set(listed)) == len(listed))
add("members regular", all((ROOT / item["path"]).is_file() and not (ROOT / item["path"]).is_symlink() for item in manifest["files"]))
add("member bytes and hashes", all((ROOT / item["path"]).stat().st_size == item["bytes"] and sha(ROOT / item["path"]) == item["sha256"] for item in manifest["files"]))
add("manifest digest", sha(MANIFEST) == lock["governance_manifest_sha256"])
rows = b"".join(
    f"{item['sha256']}  {item['path']}\n".encode("utf-8")
    for item in sorted(manifest["files"], key=lambda item: item["path"])
)
rows += f"{sha(MANIFEST)}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("utf-8")
add("canonical root", hashlib.sha256(rows).hexdigest() == lock["canonical_artifact_root_sha256"])
add("canonical member count", len(manifest["files"]) + 1 == lock["canonical_root_member_count"])
add("governance status", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
add("disposition exact", lock["disposition"] == "CONFIRMED_CARDINALITY_FALSE_POSITIVE_OPTION_A_EXISTING_PRODUCT_V2_DISTINCT_VALIDATOR_V2_CONDITIONAL_STATIC_RUN_V2_P3_BLOCKED")
add("original product P1 hash", sha(P1) == lock["original_P1_product_result_sha256"])
add("original independent P1 hash", sha(P1I) == lock["original_P1_independent_result_sha256"])
add("P1 terminal preserved", lock["original_P1"].startswith("FAIL_CLOSED_BLOCKED_BEFORE_STATIC_LOCK"))
add("argv digest preserved", load(ROOT / "EXACT_ARGV_INTEGRITY_REVIEW.json")["canonical_argv_sha256"] == lock["canonical_argv_sha256"])
add("three writable bind operations", lock["explicit_writable_bind_operation_count"] == 3)
add("one primary root bind", lock["primary_root_bind_operation_count"] == 1)
add("two nested projections", lock["nested_authorized_projection_operation_count"] == 2)
add("one backing authority root", lock["persistent_backing_authority_root_count"] == 1)
source_binding = load(ROOT / "PRODUCT_V2_SOURCE_PRESERVATION_BINDING.json")
current_inventory = sorted(
    (
        {"path": path.relative_to(PRODUCT).as_posix(), "bytes": path.stat().st_size, "sha256": sha(path)}
        for path in PRODUCT.rglob("*") if path.is_file()
    ),
    key=lambda item: item["path"],
)
expected_inventory = sorted(source_binding["files"], key=lambda item: item["path"])
add("Product V2 inventory count", len(current_inventory) == source_binding["inventory_count"] == 24)
add("Product V2 inventory unchanged", current_inventory == expected_inventory)
add("old static-run V1 remains empty", not any(path.is_file() for path in (PRODUCT / "static-run-v1").rglob("*")))
add("validator V2 not implemented", not os.path.lexists(PRODUCT / "validator-v2"))
add("static-run V2 not created", not os.path.lexists(PRODUCT / "static-run-v2"))
add("Product V2 static lock absent", not os.path.lexists(PRODUCT / "STATIC_EXECUTION_LOCK.json"))
add("fresh validation count zero", lock["fresh_validation_attempt_count"] == 0)
add("P3 V2 prohibited", lock["P3_V2"] == "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE")
add("P6 prohibited", lock["P6"] == "NOT_ELIGIBLE_NOT_AUTHORIZED")
add("all operation counters zero", all(value == 0 for value in lock["execution_counts"].values()))
add("all governance files read-only", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()))
add("governance directory read-only", stat.S_IMODE(ROOT.stat().st_mode) == 0o555)
add("no governance symlinks", not any(path.is_symlink() for path in ROOT.iterdir()))

result = {
    "status": "PASS" if all(item["pass"] for item in checks) else "FAIL_CLOSED",
    "checks_total": len(checks),
    "checks_passed": sum(item["pass"] for item in checks),
    "failed_ids": [item["id"] for item in checks if not item["pass"]],
    "checks": checks,
}
print(json.dumps(result, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
