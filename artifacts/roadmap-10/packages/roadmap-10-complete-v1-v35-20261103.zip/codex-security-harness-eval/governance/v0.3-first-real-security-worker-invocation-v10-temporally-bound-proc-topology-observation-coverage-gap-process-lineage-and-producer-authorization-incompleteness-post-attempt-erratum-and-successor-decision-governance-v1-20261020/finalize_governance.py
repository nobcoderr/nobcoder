#!/usr/bin/env python3
"""Freeze the V10 governance erratum only after every validation gate passes."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V10 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v10-20261020")
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V10_TEMPORALLY_BOUND_PROC_TOPOLOGY_"
    "OBSERVATION_COVERAGE_GAP_PROCESS_LINEAGE_AND_PRODUCER_AUTHORIZATION_INCOMPLETENESS_"
    "POST_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "TERMINALIZE_V10_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_CONDITIONALLY"
EXPECTED_V10_ROOT = "0150c34f0f8d6f7adce038714f07ef4b9acb1c76d0f0a1e051b1b30346261e91"
FINAL = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree_root(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted((node for node in path.rglob("*") if node.is_file()), key=lambda node: node.relative_to(path).as_posix())]
    material = "".join(f"{digest}  {relative}\n" for relative, digest in rows)
    return hashlib.sha256(material.encode()).hexdigest(), len(rows)


def write_once(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    if any((ROOT / name).exists() for name in [FINAL, MANIFEST, LOCK]):
        raise SystemExit("freeze artifacts already exist")
    if V11.exists() or V11.is_symlink():
        raise SystemExit("V11 exists before governance freeze")
    primary = load(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = load(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    if any(item.get("status") != "PASS" or item.get("checks_failed") != 0 for item in [primary, negative, independent]):
        raise SystemExit("validation gate not PASS")
    root, count = tree_root(V10)
    if (root, count) != (EXPECTED_V10_ROOT, 127):
        raise SystemExit("V10 changed before freeze")
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    check("F001_PRIMARY", primary["status"] == "PASS")
    check("F002_NEGATIVE", negative["status"] == "PASS")
    check("F003_INDEPENDENT", independent["status"] == "PASS")
    check("F004_V10_ROOT", root == EXPECTED_V10_ROOT, root)
    check("F005_V10_MEMBER_COUNT", count == 127, count)
    disposition = load(ROOT / "V10_TERMINAL_DISPOSITION.json")
    check("F006_V10_TERMINAL", disposition["disposition"] == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY")
    check("F007_V10_NO_PASS_LOCK", disposition["pass_locked"] is False)
    temporal = load(ROOT / "TEMPORALLY_BOUND_PROC_TOPOLOGY_OBSERVATION_COVERAGE_GAP_ADJUDICATION.json")
    check("F008_TEMPORAL_GAP", temporal["temporally_bound_proc_topology_observation_coverage_gap"] == "YES")
    check("F009_TWENTY_ONE", temporal["unmapped_trace_pid_count"] == 21)
    lineage = load(ROOT / "PROCESS_LINEAGE_EVIDENCE_DISPOSITION.json")
    check("F010_LINEAGE_NOT_PROVEN", lineage["process_lineage"] == "NOT_PROVEN")
    mount = load(ROOT / "MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_ADJUDICATION.json")
    check("F011_MOUNT_PASS", mount["mount_provenance"] == "PASS")
    check("F012_PRODUCER_NOT_PROVEN", mount["producer_lineage_authorization"] == "NOT_PROVEN")
    successor = load(ROOT / "SUCCESSOR_V11_AUTHORIZATION_DECISION.json")
    check("F013_SUCCESSOR_DECISION", successor["decision"] == DECISION)
    check("F014_SUCCESSOR_STATE", successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F015_SUCCESSOR_ZERO", successor["attempt_count"] == successor["worker_invocation_count"] == successor["codex_as_worker_invocation_count"] == 0)
    observer = load(ROOT / "SUCCESSOR_V11_TEMPORAL_PROCESS_IDENTITY_OBSERVER_CONTRACT.json")
    check("F016_OBSERVER_BEFORE_WORKER", observer["observer_start_order"][-1] == "START_WORKER_EXECUTION")
    check("F017_STABLE_IDENTITY", observer["stable_identity_minimum"] == ["host_pid", "proc_starttime", "pid_namespace_identity"])
    matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    check("F018_ZERO_GOVERNANCE_OPS", all(value == 0 for value in matrix["operation_counters"].values()))
    check("F019_V11_ABSENT", not V11.exists() and not V11.is_symlink())
    check("F020_NO_SYMLINKS_OR_DIRECTORIES", not any(item.is_symlink() or item.is_dir() for item in ROOT.iterdir()))
    if not all(row["status"] == "PASS" for row in checks):
        raise SystemExit("final freeze verification failed closed")
    write_once(FINAL, {
        "record_type": "FIRST_WORKER_V10_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT", "run_id": "RUN-0001",
        "status": "PASS", "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "checks": checks, "v10_source_unchanged": True, "v11_not_created_or_executed": True,
    })
    members = []
    excluded = {MANIFEST, LOCK}
    for item in sorted((p for p in ROOT.iterdir() if p.is_file() and p.name not in excluded), key=lambda p: p.name):
        members.append({"path": item.name, "sha256": sha(item), "bytes": item.stat().st_size})
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    package_root = hashlib.sha256(material.encode()).hexdigest()
    write_once(MANIFEST, {
        "record_type": "FIRST_WORKER_V10_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0",
        "member_count": len(members), "members": members, "canonical_governance_root_sha256": package_root,
    })
    write_once(LOCK, {
        "record_type": "FIRST_WORKER_V10_ERRATUM_GOVERNANCE_LOCK", "schema_version": "1.0",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "v10_disposition": "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "v11_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v11_attempt_count": 0, "v11_worker_invocation_count": 0, "v11_codex_as_worker_invocation_count": 0,
        "compatibility_or_worker_acceptance_issued": False, "confinement": "NOT_PROVEN",
        "governance_manifest_sha256": sha(ROOT / MANIFEST), "canonical_governance_root_sha256": package_root,
        "next_legal_milestone": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_ONCE_IF_ALL_GATES_PASS",
    })
    for item in ROOT.iterdir():
        if item.is_file():
            os.chmod(item, 0o444)
    os.chmod(ROOT, 0o555)
    reread = load(ROOT / LOCK)
    if reread["status"] != "PASS_LOCKED_GOVERNANCE_ONLY" or tree_root(V10) != (EXPECTED_V10_ROOT, 127):
        raise SystemExit("post-freeze reread verification failed")


if __name__ == "__main__":
    main()
