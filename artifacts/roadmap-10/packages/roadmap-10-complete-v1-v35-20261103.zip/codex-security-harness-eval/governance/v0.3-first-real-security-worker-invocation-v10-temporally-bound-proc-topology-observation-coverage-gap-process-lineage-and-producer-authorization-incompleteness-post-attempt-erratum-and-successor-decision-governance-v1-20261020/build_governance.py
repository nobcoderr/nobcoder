#!/usr/bin/env python3
"""Build the governance-only V10 temporal-process-evidence erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V10 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v10-20261020")
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V9_GOV = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v9-contract-and-schema-expected-digest-"
    "identity-mismatch-and-pre-preflight-validation-coverage-gap-erratum-and-successor-"
    "decision-governance-v1-20261020"
)
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V10_TEMPORALLY_BOUND_PROC_TOPOLOGY_"
    "OBSERVATION_COVERAGE_GAP_PROCESS_LINEAGE_AND_PRODUCER_AUTHORIZATION_INCOMPLETENESS_"
    "POST_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
DECISION = "TERMINALIZE_V10_AND_AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11_ONCE_IF_ALL_GATES_PASS"
V10_ROOT = "0150c34f0f8d6f7adce038714f07ef4b9acb1c76d0f0a1e051b1b30346261e91"
V10_MEMBERS = 127
V9_GOV_LOCK_SHA = "fa2564ef667a95a4e496f0b242949d1c7990588977ddc3815554134aed24fbe7"
V9_GOV_MANIFEST_SHA = "46c8dd887bb2139fd36826c69ad8738e2f630f5518520f401495b7f3ed82eed2"
KEY_HASHES = {
    "STATIC_EXECUTION_LOCK.json": "ada51262f2ba7970d088ac5e5ffb6bd8df8bc311d95cbbef726919388cc36707",
    "STATIC_SOURCE_MANIFEST.json": "f5c667a61ca770a86893d6f71b5e35e6aea1af2eda5b92f14d34db8c20865c32",
    "STATIC_EXECUTION_LOCK_VERIFICATION.json": "708d3ae7c15d05a527f10128a72656b9777cc5329a1a74877836b99564fcf432",
    "static-run-v10/ATTEMPT_MARKER.json": "4d0dc972042dd9a5502a179abc6a074ed50cdba7846b8b32b0588194340068ba",
    "static-run-v10/runtime-result-0001.json": "cf40fbb571735e9b22d001c6dd68c8a07c82285360f608123a256f6348b3f5db",
    "static-run-v10/independent-post-validation-0001.json": "80482fb2618417a273b3a1ea0adad8ba08d613b62dca335378c5b642f1e9273c",
    "static-run-v10/TERMINAL_ENGINEERING_RESULT.json": "f9c4e40ef2a808cbd1127320defa913f019be7b9b2a246be9b6761951933109f",
    "static-run-v10/EVIDENCE_MANIFEST.json": "1d85a46fe6e9854f48da453db0c0d4c2c4bf649a715b923828fb141da015d2b6",
    "static-run-v10/EVIDENCE_FREEZE_LOCK.json": "6234481c68397a2bb9be60c422e64f2edf3a4c7b896c876d4a73ac21ebb42ccd",
    "static-run-v10/EVIDENCE_FREEZE_VERIFICATION.json": "ad5d73d9c7e3b37b941b057323ae95251454e4bf47ca3d0752cad50f1d6d7933",
    "static-run-v10/controller-worker-result-0001.json": "1ae7b50d99d3b2d7594bace18e80846eed61afe13f9f066398d5cc3d26456fa4",
    "static-run-v10/runtime-topology-snapshot-0001.json": "0239cc1d67c7544f69c07c2331cc125fe85685a668cd123de72d1e23323c04a2",
}
FAILURE_IDS = [
    "P010_RUNTIME_PASS",
    "P013_SEMANTIC_PROCESS_LINEAGE",
    "P046_MOUNT_PROVENANCE_WRITE_CLASSIFICATION",
    "P046B_PRODUCER_LINEAGE_SEPARATE_GATE",
    "P046C_FINAL_WRITE_AUTHORIZATION_REQUIRES_BOTH",
    "P055_LINEAGE_NAMESPACE_BINDING",
    "P056_CROSS_NAMESPACE_PROCESS_IDENTITY_COMPLETE",
    "P058_PROCESS_PARENT_EDGES_EVIDENCE_BOUND",
]
MISSING_TRACE_PIDS = [
    551708, 551709, 551710, 551711, 551733, 551734, 551768, 551772, 551783,
    551794, 551795, 551796, 551797, 551798, 551799, 551800, 551811, 551814,
    551815, 551816, 551817,
]
SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
OPERATION_KEYS = [
    "v10_patch_operations", "v10_relock_operations", "v10_retry_operations",
    "v10_revalidation_operations", "v11_creation_operations", "v11_execution_operations",
    "worker_invocations", "codex_as_worker_invocations", "subagent_invocations",
    "credential_operations", "target_operations", "external_network_operations",
    "daybreak_invocations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def tree(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = [
        {
            "path": item.relative_to(path).as_posix(),
            "sha256": sha(item),
            "bytes": item.stat().st_size,
            "mode": oct(item.stat().st_mode & 0o777),
            "writable": bool(item.stat().st_mode & 0o222),
        }
        for item in sorted((node for node in path.rglob("*") if node.is_file()), key=lambda node: node.relative_to(path).as_posix())
    ]
    return canonical(rows), rows


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_inputs() -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    root, rows = tree(V10)
    if root != V10_ROOT or len(rows) != V10_MEMBERS:
        raise SystemExit(f"V10 tree drift: {root=} members={len(rows)}")
    for relative, expected in KEY_HASHES.items():
        if sha(V10 / relative) != expected:
            raise SystemExit(f"V10 evidence drift: {relative}")
    if sha(V9_GOV / "GOVERNANCE_LOCK.json") != V9_GOV_LOCK_SHA:
        raise SystemExit("V9 governance lock drift")
    if sha(V9_GOV / "GOVERNANCE_ARTIFACT_MANIFEST.json") != V9_GOV_MANIFEST_SHA:
        raise SystemExit("V9 governance manifest drift")
    attempt = load(V10 / "static-run-v10/ATTEMPT_MARKER.json")
    runtime = load(V10 / "static-run-v10/runtime-result-0001.json")
    post = load(V10 / "static-run-v10/independent-post-validation-0001.json")
    terminal = load(V10 / "static-run-v10/TERMINAL_ENGINEERING_RESULT.json")
    freeze = load(V10 / "static-run-v10/EVIDENCE_FREEZE_VERIFICATION.json")
    if attempt["attempt_count"] != 1 or attempt["worker_invocation_count"] != 1 or attempt["codex_as_worker_invocation_count"] != 1:
        raise SystemExit("V10 attempt identity drift")
    if runtime.get("exit_status") != 0 or runtime.get("semantic_codex_exec_count") != 1:
        raise SystemExit("V10 runtime fact drift")
    if runtime.get("worker_result_state") != "EMITTED_AND_CONTROLLER_WRAPPED":
        raise SystemExit("V10 WorkerResult fact drift")
    if runtime.get("controller_result", {}).get("proposals", [{}])[0].get("candidate_initial_state") != "HYPOTHESIS_QUARANTINED":
        raise SystemExit("V10 candidate state drift")
    if post.get("checks_passed") != 65 or post.get("checks_total") != 73 or post.get("failure_ids") != FAILURE_IDS:
        raise SystemExit("V10 post-validation identity drift")
    if terminal.get("status") != "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE":
        raise SystemExit("V10 terminal status drift")
    if freeze.get("status") != "PASS" or freeze.get("checks_passed") != 75 or freeze.get("checks_total") != 75:
        raise SystemExit("V10 freeze verification drift")
    lineage = runtime.get("semantic_process_lineage", {}).get("cross_namespace_process_identity", {})
    failures = lineage.get("failures", [])
    observed = [row.get("trace_file_pid") for row in failures if row.get("reason") == "NO_TEMPORALLY_BOUND_PROC_TOPOLOGY_OBSERVATION"]
    if observed != MISSING_TRACE_PIDS or lineage.get("mapped_trace_file_count") != 41:
        raise SystemExit("V10 temporal topology coverage fact drift")
    write_evidence = runtime.get("typed_write_evidence", {})
    if write_evidence.get("mount_provenance_gate", {}).get("status") != "PASS":
        raise SystemExit("V10 mount provenance fact drift")
    if write_evidence.get("producer_lineage_authorization_gate", {}).get("status") != "FAIL_CLOSED":
        raise SystemExit("V10 producer authorization fact drift")
    if V11.exists() or V11.is_symlink():
        raise SystemExit("V11 already exists")
    return rows, runtime, post, terminal, freeze


def routing_decisions() -> list[dict[str, str]]:
    routing = load(ROUTER_MAP)
    active = {"agentic-security-research-harness", "external-ai-security-tool-governor"}
    decisions: list[dict[str, str]] = []
    for name, route in sorted(routing["skill_routes"].items()):
        if route.get("mode") == "always":
            state, reason = "ACTIVE", "MANDATORY_CORE_POLICY"
        elif name in active:
            state, reason = "ACTIVE", "LOCAL_HARNESS_GOVERNANCE_WITHOUT_EXTERNAL_EXECUTION"
        else:
            state, reason = "NOT_APPLICABLE", "GOVERNANCE_ONLY_NO_TARGET_DISCOVERY_OR_EXECUTION"
        decisions.append({"module": name, "state": state, "reason": reason})
    decisions.append({"module": "codex-security-harness", "state": "ACTIVE", "reason": "LOCAL_HARNESS_GOVERNANCE_IDENTITY"})
    return decisions


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != SCRIPTS or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    rows, runtime, post, terminal, freeze = verify_inputs()
    zero = {key: 0 for key in OPERATION_KEYS}
    decisions = routing_decisions()
    predecessor_lock = load(V9_GOV / "GOVERNANCE_LOCK.json")

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "FIRST_WORKER_V10_TEMPORAL_TOPOLOGY_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0",
        "scope": "GOVERNANCE_ONLY_READ_ONLY_V10_FROZEN_FAILURE_EVIDENCE_ADJUDICATION",
        "scope_evidence_card": {
            "asset": str(V10), "asset_kind": "LOCAL_FROZEN_POST_ATTEMPT_FAILURE_WORKSPACE",
            "allowed_mode": "READ_ONLY_EVIDENCE_ADJUDICATION_LOCAL_GOVERNANCE_VALIDATION_AND_FREEZE",
            "target": "NONE", "credential": "NONE", "network": "NONE",
            "worker_or_codex_invocation": "NONE", "v10_mutation_or_retry": "NONE", "v11_implementation": "NONE",
        },
        "authorized_actions": [
            "READ_FROZEN_V10_EVIDENCE", "ADJUDICATE_TEMPORALLY_BOUND_PROC_OBSERVATION_GAP",
            "ADJUDICATE_PROCESS_LINEAGE_AND_PRODUCER_AUTHORIZATION_INCOMPLETENESS",
            "PRESERVE_PROVEN_V10_FACTS", "AUTHORIZE_OR_DENY_DISTINCT_SUCCESSOR",
            "RUN_LOCAL_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE",
        ],
        "forbidden_actions": [
            "PATCH_RELOCK_RETRY_REVALIDATE_OR_RECLASSIFY_V10", "CREATE_OR_EXECUTE_V11",
            "CODEX_WORKER_OR_SUBAGENT_INVOCATION", "CREDENTIAL_TARGET_OR_NETWORK_OPERATION",
            "DAYBREAK_INVOCATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH",
            "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION",
        ],
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "FIRST_WORKER_V10_TEMPORAL_TOPOLOGY_ERRATUM_ROUTING_LEDGER",
        "schema_version": "1.0", "router_map_sha256": sha(ROUTER_MAP), "module_decisions": decisions,
        "active_count": sum(row["state"] == "ACTIVE" for row in decisions),
        "deferred_count": 0, "not_applicable_count": sum(row["state"] == "NOT_APPLICABLE" for row in decisions),
        "subagents_used": False, "codex_invoked_during_governance": False,
        "worker_invoked_during_governance": False, "network_used_during_governance": False,
    })
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "FIRST_WORKER_V10_TEMPORAL_TOPOLOGY_ERRATUM_PREDECESSOR_CHAIN_BINDING",
        "schema_version": "1.0",
        "v10_authorization": {"identity": predecessor_lock["governance_identity"], "status": predecessor_lock["status"],
            "decision": predecessor_lock["decision"], "lock_sha256": V9_GOV_LOCK_SHA,
            "manifest_sha256": V9_GOV_MANIFEST_SHA},
        "v10_static_execution_lock_sha256": KEY_HASHES["STATIC_EXECUTION_LOCK.json"],
        "v10_failure_evidence_freeze_lock_sha256": KEY_HASHES["static-run-v10/EVIDENCE_FREEZE_LOCK.json"],
    })
    write("V10_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST.json", {
        "record_type": "FIRST_WORKER_V10_FAILURE_EVIDENCE_SNAPSHOT_MANIFEST", "schema_version": "1.0",
        "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V10", "workspace": str(V10),
        "member_count": len(rows), "members": rows, "canonical_tree_root_sha256": V10_ROOT,
        "snapshot_kind": "EXTERNAL_GOVERNANCE_BINDING_OF_FROZEN_FAILURE_EVIDENCE",
        "source_workspace_mutated_during_governance": False,
    })
    write("V10_TERMINAL_EVIDENCE_BINDING.json", {
        "record_type": "FIRST_WORKER_V10_TERMINAL_EVIDENCE_BINDING", "schema_version": "1.0",
        "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V10", "workspace": str(V10),
        "member_count": len(rows), "canonical_tree_root_sha256": V10_ROOT,
        "canonical_frozen_evidence_root_sha256": freeze["canonical_evidence_root_sha256"],
        "key_artifact_sha256": KEY_HASHES, "content_mutation_during_governance": "PROHIBITED",
        "binding_semantics": "EXACT_BYTES_REFERENCE_ONLY",
    })
    write("V10_TERMINAL_DISPOSITION.json", {
        "record_type": "FIRST_WORKER_V10_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V10",
        "disposition": "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "immutable": True, "attempt": "1_OF_1_CONSUMED", "worker_invocation": "1_OF_1",
        "codex_as_worker_invocation": "1_OF_1", "semantic_codex_execve": "EXACTLY_1",
        "runtime_exit": 0, "worker_result": "EMITTED_AND_CONTROLLER_WRAPPED",
        "candidate": "HYPOTHESIS_QUARANTINED", "post_validation": "65_OF_73_FAIL_CLOSED",
        "evidence_freeze": "75_OF_75_PASS_FROZEN_FAILURE_EVIDENCE", "pass_locked": False,
        "patch": "PROHIBITED", "relock": "PROHIBITED", "retry": "PROHIBITED",
        "revalidation": "PROHIBITED", "evidence_reclassification": "PROHIBITED",
    })
    write("TEMPORALLY_BOUND_PROC_TOPOLOGY_OBSERVATION_COVERAGE_GAP_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V10_TEMPORAL_PROC_TOPOLOGY_COVERAGE_GAP_ADJUDICATION",
        "schema_version": "1.0", "status": "DEFECT_CONFIRMED",
        "temporally_bound_proc_topology_observation_coverage_gap": "YES",
        "trace_pid_count": 62, "mapped_trace_pid_count": 41, "unmapped_trace_pid_count": 21,
        "unmapped_trace_pids": MISSING_TRACE_PIDS,
        "uniform_failure_reason": "NO_TEMPORALLY_BOUND_PROC_TOPOLOGY_OBSERVATION",
        "adjudication": "POST_RUN_PROC_SNAPSHOT_CANNOT_PROVE_IDENTITY_OF_EXITED_SHORT_LIVED_PROCESS",
        "pid_reuse_rule": "HOST_PID_ALONE_IS_NOT_STABLE_PROCESS_IDENTITY",
        "minimum_stable_identity_tuple": ["host_pid", "proc_starttime", "pid_namespace_identity"],
    })
    write("PROCESS_LINEAGE_EVIDENCE_DISPOSITION.json", {
        "record_type": "FIRST_WORKER_V10_PROCESS_LINEAGE_EVIDENCE_DISPOSITION", "schema_version": "1.0",
        "process_lineage": "NOT_PROVEN", "confinement": "NOT_PROVEN",
        "reason": "TWENTY_ONE_TRACE_PIDS_LACK_TEMPORALLY_BOUND_PROC_TOPOLOGY_OBSERVATION",
        "successful_partial_evidence_is_not_promoted": True,
        "missing_edge_inference": "PROHIBITED", "unknown_lineage": "FAIL_CLOSED",
    })
    write("MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V10_MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_ADJUDICATION",
        "schema_version": "1.0", "mount_provenance": "PASS", "mount_provenance_defect": "NO",
        "producer_lineage_authorization": "NOT_PROVEN", "final_write_authorization": "NOT_PROVEN",
        "separate_gate_invariant": "MOUNT_PROVENANCE_PASS_DOES_NOT_IMPLY_PRODUCER_AUTHORIZATION_PASS",
        "producer_authorization_requires": "EVIDENCE_BOUND_PROCESS_LINEAGE_FOR_EACH_LINEAGE_RELEVANT_WRITER",
    })
    write("PRESERVED_PROVEN_RESULTS.json", {
        "record_type": "FIRST_WORKER_V10_PRESERVED_PROVEN_RESULTS", "schema_version": "1.0",
        "exact_codex_execve": 1, "runtime_exit": 0, "worker_result": "VALIDLY_EMITTED_AND_CONTROLLER_WRAPPED",
        "candidate_quarantine": "PROVEN_HYPOTHESIS_QUARANTINED", "mount_provenance": "PASS",
        "forbidden_operation_counters": {
            key: runtime["operation_counters"][key] for key in [
                "credential_operations", "target_operations", "external_network_operations",
                "subagent_invocations", "parallel_operations", "exploit_replays", "capability_edges",
                "candidate_promotions", "submission_operations", "daybreak_invocations",
            ]
        },
        "post_validation_failure_ids": FAILURE_IDS,
    })
    write("DEFECT_OWNERSHIP_DECISION.json", {
        "record_type": "FIRST_WORKER_V10_DEFECT_OWNERSHIP_DECISION", "schema_version": "1.0",
        "temporally_bound_proc_topology_observation_coverage_gap": "YES",
        "process_lineage_observation_contract_gap": "YES",
        "producer_authorization_incomplete_due_to_lineage_gap": "YES",
        "codex_defect": "NO", "worker_behavior_defect": "NO", "mount_provenance_defect": "NO",
        "prompt_identity_defect": "NO", "predecessor_binding_defect": "NO",
        "causal_history_beyond_observed_coverage_gap": "NOT_ESTABLISHED",
    })
    write("SUCCESSOR_V11_TEMPORAL_PROCESS_IDENTITY_OBSERVER_CONTRACT.json", {
        "record_type": "FIRST_WORKER_V11_TEMPORAL_PROCESS_IDENTITY_OBSERVER_CONTRACT", "schema_version": "1.0",
        "observer_start_order": ["START_HOST_CONTROLLED_TOPOLOGY_OBSERVER", "PROVE_OBSERVER_READY",
            "START_TRACE_CAPTURE", "START_WORKER_EXECUTION"],
        "per_lineage_relevant_pid_required_fields": [
            "host_pid", "local_pid", "host_parent_pid", "local_parent_pid", "proc_starttime",
            "pid_namespace_identity", "executable_identity", "observation_timestamp_monotonic_ns",
            "trace_event_timestamp_or_bounded_interval", "evidence_source", "immutable_record_digest",
        ],
        "stable_identity_minimum": ["host_pid", "proc_starttime", "pid_namespace_identity"],
        "temporal_binding": "OBSERVATION_MUST_OVERLAP_OR_BE_PROVABLY_BOUNDED_TO_RELEVANT_TRACE_LIFETIME",
        "post_exit_retention": "OBSERVATION_RECORD_REMAINS_IMMUTABLE_AFTER_PROCESS_EXIT",
        "post_run_proc_snapshot_only": "INSUFFICIENT",
        "missing_record": "FAIL_CLOSED_BEFORE_PROCESS_LINEAGE_OR_PRODUCER_AUTHORIZATION_PASS",
        "observer_authority": "HOST_CONTROLLED_OUTSIDE_WORKER_MUTATION_AUTHORITY",
        "observer_identity_and_configuration": "EXACTLY_BOUND_IN_STATIC_LOCK_AND_RUNTIME_EVIDENCE",
    })
    regressions = [
        ("R001_SHORT_LIVED_CHILD_TRACE_AND_TEMPORAL_OBSERVATION", "PASS"),
        ("R002_TRACE_PID_WITHOUT_TEMPORAL_OBSERVATION", "FAIL_CLOSED"),
        ("R003_POST_RUN_PROC_SNAPSHOT_ONLY", "FAIL_CLOSED"),
        ("R004_HOST_PID_ONLY_WITHOUT_STARTTIME_OR_NAMESPACE", "FAIL_CLOSED"),
        ("R005_REUSED_HOST_PID_DIFFERENT_STARTTIME", "FAIL_CLOSED"),
        ("R006_OBSERVATION_OUTSIDE_TRACE_TIME_BOUND", "FAIL_CLOSED"),
        ("R007_OBSERVER_STARTED_AFTER_WORKER", "FAIL_CLOSED_BEFORE_ATTEMPT"),
        ("R008_OBSERVER_RECORD_MUTABLE_AFTER_PROCESS_EXIT", "FAIL_CLOSED"),
        ("R009_MOUNT_PROVENANCE_PASS_PRODUCER_UNKNOWN", "FINAL_WRITE_AUTHORIZATION_FAIL_CLOSED"),
        ("R010_MOUNT_PROVENANCE_FAIL_PRODUCER_PASS", "FINAL_WRITE_AUTHORIZATION_FAIL_CLOSED"),
        ("R011_BOTH_MOUNT_AND_PRODUCER_GATES_PASS", "FINAL_WRITE_AUTHORIZATION_MAY_PASS"),
        ("R012_ALL_TWENTY_ONE_V10_MISSING_TRACE_PIDS", "REPRODUCE_V10_FAIL_CLOSED"),
        ("R013_V10_PATCH_RELOCK_RETRY_OR_REVALIDATION", "REJECT"),
        ("R014_V11_CREATION_OR_EXECUTION_DURING_GOVERNANCE", "REJECT"),
    ]
    write("V10_FAILURE_AND_V11_SUCCESSOR_REGRESSION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V10_FAILURE_AND_V11_SUCCESSOR_REGRESSION_MATRIX", "schema_version": "1.0",
        "cases": [{"case_id": case_id, "expected": expected} for case_id, expected in regressions],
    })
    requirements = [
        "FRESH_V11_IDENTITY_SOURCE_TESTS_LOCK_AND_ONE_SHOT_ATTEMPT", "V10_REFERENCE_PREDECESSOR_IMMUTABLE",
        "HOST_CONTROLLED_TOPOLOGY_OBSERVER_STARTS_BEFORE_WORKER", "OBSERVER_READINESS_PROVEN_BEFORE_ATTEMPT_MARKER",
        "TEMPORALLY_BOUND_OBSERVATION_FOR_EVERY_LINEAGE_RELEVANT_TRACE_PID",
        "HOST_PID_PROC_STARTTIME_PID_NAMESPACE_STABLE_IDENTITY", "LOCAL_AND_HOST_PID_IDENTITIES_REMAIN_DISTINCT",
        "PARENT_RELATIONS_EVIDENCE_BOUND", "EXECUTABLE_IDENTITY_AND_OBSERVATION_TIMESTAMP_BOUND",
        "TRACE_EVENT_TIMESTAMP_OR_BOUNDED_INTERVAL_BOUND", "IMMUTABLE_POST_EXIT_OBSERVATION_RECORD",
        "NO_POST_RUN_PROC_SNAPSHOT_ONLY_PROOF", "SHORT_LIVED_CHILD_POSITIVE_PRE_ATTEMPT_FIXTURE",
        "TRACE_PID_WITHOUT_TEMPORAL_RECORD_NEGATIVE_FIXTURE", "PID_REUSE_NEGATIVE_FIXTURE",
        "MOUNT_PROVENANCE_SEPARATE_FROM_PRODUCER_AUTHORIZATION", "UNKNOWN_LINEAGE_FAIL_CLOSED",
        "FAILURE_EVIDENCE_FREEZE", "ALL_PREVIOUSLY_PASSING_V10_GATES_CARRIED_FORWARD",
        "COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE", "ONE_SHOT_EXECUTION", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    write("SUCCESSOR_V11_REQUIREMENTS.json", {
        "record_type": "FIRST_WORKER_V11_SUCCESSOR_REQUIREMENTS", "schema_version": "1.0",
        "mandatory_requirements": requirements,
        "pre_attempt_order": "OBSERVER_FIXTURES_READINESS_AND_ALL_STATIC_PREFLIGHT_LOCK_GATES_PASS_BEFORE_ATTEMPT_MARKER",
    })
    write("SUCCESSOR_V11_AUTHORIZATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V11_SUCCESSOR_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": DECISION, "continuation_v10": "DO_NOT_AUTHORIZE",
        "successor_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V11",
        "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt_count": 0, "attempt_limit": 1, "worker_invocation_count": 0, "worker_invocation_limit": 1,
        "codex_as_worker_invocation_count": 0, "codex_as_worker_invocation_limit": 1,
        "creation_or_execution_this_milestone": False,
    })
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V10_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "current_governance_operation_counters": zero, "v10_continuation_authorized": False,
        "v11_engineering_authorized_only_after_this_governance_freeze": True,
        "v11_worker_execution_authorized_only_under_successor_one_shot_contract": True,
        "credential_target_network_subagent_parallel_exploit_graph_promotion_submission_daybreak_authority": "NOT_GRANTED",
        "successor_authorization_does_not_reclassify_v10": True,
    })
    allowed = [
        "READ_V10_FROZEN_EVIDENCE", "RUN_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE",
        "ISSUE_CONDITIONAL_V11_SUCCESSOR_AUTHORIZATION",
    ]
    denied = [
        "PATCH_V10", "RELOCK_V10", "RETRY_V10", "REVALIDATE_V10", "RECLASSIFY_V10_EVIDENCE",
        "CREATE_V11", "EXECUTE_V11", "INVOKE_ADDITIONAL_WORKER", "INVOKE_ADDITIONAL_CODEX_AS_WORKER",
        "INVOKE_SUBAGENT", "USE_CREDENTIAL", "ACCESS_TARGET", "ACCESS_EXTERNAL_NETWORK", "INVOKE_DAYBREAK",
        "REPLAY_EXPLOIT", "ENABLE_PARALLELISM", "CREATE_CAPABILITY_EDGE", "PROMOTE_CANDIDATE", "SUBMIT_REPORT",
    ]
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V10_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "allowed": allowed, "denied": denied, "operation_counters": zero,
    })
    negative_cases = [
        ("N001", "PROMOTE_V10_TO_PASS_LOCKED", "REJECT"),
        ("N002", "INFER_LINEAGE_FROM_MOUNT_PROVENANCE", "REJECT"),
        ("N003", "INFER_PRODUCER_AUTHORIZATION_FROM_TMPFS", "REJECT"),
        ("N004", "USE_POST_RUN_PROC_SNAPSHOT_AS_COMPLETE_PROOF", "REJECT"),
        ("N005", "USE_HOST_PID_WITHOUT_STARTTIME_AND_NAMESPACE", "REJECT"),
        ("N006", "GUESS_MISSING_PARENT_EDGE", "REJECT"),
        ("N007", "IGNORE_ONE_OF_TWENTY_ONE_MISSING_TRACE_PIDS", "REJECT"),
        ("N008", "START_OBSERVER_AFTER_WORKER", "REJECT"),
        ("N009", "ALLOW_MUTABLE_TOPOLOGY_RECORD", "REJECT"),
        ("N010", "PATCH_OR_RETRY_V10", "REJECT"),
        ("N011", "CREATE_OR_EXECUTE_V11_DURING_GOVERNANCE", "REJECT"),
        ("N012", "OPEN_CREDENTIAL_TARGET_NETWORK_AUTHORITY", "REJECT"),
        ("N013", "OPEN_SUBAGENT_OR_PARALLELISM", "REJECT"),
        ("N014", "OPEN_EXPLOIT_GRAPH_PROMOTION_OR_SUBMISSION", "REJECT"),
        ("N015", "CLASSIFY_CODEX_OR_WORKER_DEFECT_WITHOUT_EVIDENCE", "REJECT"),
        ("N016", "TREAT_PARTIAL_MAPPING_AS_COMPLETE_LINEAGE", "REJECT"),
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "FIRST_WORKER_V10_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0",
        "cases": [{"case_id": case_id, "mutation": mutation, "expected": expected} for case_id, mutation, expected in negative_cases],
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "FIRST_WORKER_V10_TEMPORAL_TOPOLOGY_ERRATUM_GOVERNANCE_DECISION_SUMMARY",
        "schema_version": "1.0", "status": "PENDING_GOVERNANCE_VALIDATION_AND_FREEZE",
        "decision": DECISION, "v10_disposition": "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "temporally_bound_proc_topology_observation_coverage_gap": "YES",
        "process_lineage": "NOT_PROVEN", "producer_authorization": "NOT_PROVEN",
        "mount_provenance": "PASS", "confinement": "NOT_PROVEN", "pass_locked": False,
        "v11_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "authority_ceiling": "SUCCESSOR_ENGINEERING_AND_SINGLE_ONE_SHOT_LOCAL_FIXTURE_ONLY_AFTER_GOVERNANCE_FREEZE",
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "FIRST_WORKER_V10_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "milestone": NEXT, "available_only_if_governance_lock_status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "v11_attempt_before_milestone": "0_OF_1", "v11_worker_invocation_before_milestone": "0_OF_1",
        "v11_codex_as_worker_invocation_before_milestone": "0_OF_1",
    })


if __name__ == "__main__":
    main()
