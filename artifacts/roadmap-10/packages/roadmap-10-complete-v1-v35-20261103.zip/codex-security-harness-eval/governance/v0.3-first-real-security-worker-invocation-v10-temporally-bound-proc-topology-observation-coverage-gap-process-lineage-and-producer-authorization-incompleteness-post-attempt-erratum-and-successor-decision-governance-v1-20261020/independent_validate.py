#!/usr/bin/env python3
"""Independent evidence-grounded validation of the V10 governance erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
V10 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v10-20261020")
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V10_TEMPORALLY_BOUND_PROC_TOPOLOGY_"
    "OBSERVATION_COVERAGE_GAP_PROCESS_LINEAGE_AND_PRODUCER_AUTHORIZATION_INCOMPLETENESS_"
    "POST_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
EXPECTED_ROOT = "0150c34f0f8d6f7adce038714f07ef4b9acb1c76d0f0a1e051b1b30346261e91"
EXPECTED_MISSING = {551708, 551709, 551710, 551711, 551733, 551734, 551768, 551772, 551783, 551794, 551795, 551796, 551797, 551798, 551799, 551800, 551811, 551814, 551815, 551816, 551817}


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_root(path: Path) -> tuple[str, int]:
    rows = [(item.relative_to(path).as_posix(), sha(item)) for item in sorted((node for node in path.rglob("*") if node.is_file()), key=lambda node: node.relative_to(path).as_posix())]
    material = "".join(f"{digest}  {relative}\n" for relative, digest in rows)
    return hashlib.sha256(material.encode()).hexdigest(), len(rows)


def main() -> None:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    root, count = tree_root(V10)
    check("I001_V10_TREE_ROOT", root == EXPECTED_ROOT, root)
    check("I002_V10_TREE_COUNT", count == 127, count)
    attempt = load(V10 / "static-run-v10/ATTEMPT_MARKER.json")
    runtime = load(V10 / "static-run-v10/runtime-result-0001.json")
    post = load(V10 / "static-run-v10/independent-post-validation-0001.json")
    terminal = load(V10 / "static-run-v10/TERMINAL_ENGINEERING_RESULT.json")
    freeze = load(V10 / "static-run-v10/EVIDENCE_FREEZE_VERIFICATION.json")
    check("I003_ATTEMPT_COUNTS", (attempt["attempt_count"], attempt["worker_invocation_count"], attempt["codex_as_worker_invocation_count"]) == (1, 1, 1))
    check("I004_SEMANTIC_CODEX_EXACT", runtime["semantic_codex_exec_count"] == 1)
    check("I005_RUNTIME_EXIT", runtime["exit_status"] == 0)
    check("I006_WORKER_RESULT", runtime["worker_result_state"] == "EMITTED_AND_CONTROLLER_WRAPPED")
    proposals = runtime["controller_result"]["proposals"]
    check("I007_CANDIDATE_QUARANTINE", len(proposals) == 1 and proposals[0]["candidate_initial_state"] == "HYPOTHESIS_QUARANTINED")
    check("I008_POST_COUNTS", (post["checks_passed"], post["checks_total"], post["checks_failed"]) == (65, 73, 8))
    check("I009_TERMINAL_STATUS", terminal["status"] == "FAIL_CLOSED_POST_ATTEMPT_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE")
    check("I010_FAILURE_FREEZE", freeze["status"] == "PASS" and freeze["checks_passed"] == 75 and freeze["checks_total"] == 75 and not freeze["technical_pass"])
    cross = runtime["semantic_process_lineage"]["cross_namespace_process_identity"]
    failures = cross["failures"]
    reasons = {row["reason"] for row in failures}
    missing = {row["trace_file_pid"] for row in failures}
    check("I011_TEMPORAL_GAP_COUNT", len(failures) == 21, len(failures))
    check("I012_TEMPORAL_GAP_REASON", reasons == {"NO_TEMPORALLY_BOUND_PROC_TOPOLOGY_OBSERVATION"}, sorted(reasons))
    check("I013_TEMPORAL_GAP_PID_SET", missing == EXPECTED_MISSING, sorted(missing))
    check("I014_PARTIAL_MAPPING_NOT_COMPLETE", cross["mapped_trace_file_count"] == 41 and cross["status"] == "FAIL_CLOSED")
    writes = runtime["typed_write_evidence"]
    check("I015_MOUNT_PROVENANCE_PASS", writes["mount_provenance_gate"]["status"] == "PASS")
    check("I016_PRODUCER_GATE_FAIL_CLOSED", writes["producer_lineage_authorization_gate"]["status"] == "FAIL_CLOSED")
    check("I017_FINAL_WRITE_FAIL_CLOSED", writes["final_write_authorization_gate"]["status"] == "FAIL_CLOSED")
    forbidden = ["credential_operations", "target_operations", "external_network_operations", "subagent_invocations", "parallel_operations", "exploit_replays", "capability_edges", "candidate_promotions", "submission_operations", "daybreak_invocations"]
    check("I018_FORBIDDEN_COUNTERS_ZERO", all(runtime["operation_counters"][key] == 0 for key in forbidden))
    temporal_doc = load(ROOT / "TEMPORALLY_BOUND_PROC_TOPOLOGY_OBSERVATION_COVERAGE_GAP_ADJUDICATION.json")
    check("I019_ADJUDICATION_EXACT", temporal_doc["unmapped_trace_pid_count"] == 21 and set(temporal_doc["unmapped_trace_pids"]) == EXPECTED_MISSING)
    mount_doc = load(ROOT / "MOUNT_PROVENANCE_AND_PRODUCER_AUTHORIZATION_ADJUDICATION.json")
    check("I020_SEPARATE_GATE_DOC", mount_doc["mount_provenance"] == "PASS" and mount_doc["producer_lineage_authorization"] == "NOT_PROVEN")
    ownership = load(ROOT / "DEFECT_OWNERSHIP_DECISION.json")
    check("I021_OWNERSHIP_POSITIVE", ownership["temporally_bound_proc_topology_observation_coverage_gap"] == "YES")
    check("I022_OWNERSHIP_NEGATIVE", all(ownership[key] == "NO" for key in ["codex_defect", "worker_behavior_defect", "mount_provenance_defect", "prompt_identity_defect", "predecessor_binding_defect"]))
    observer = load(ROOT / "SUCCESSOR_V11_TEMPORAL_PROCESS_IDENTITY_OBSERVER_CONTRACT.json")
    check("I023_OBSERVER_BEFORE_WORKER", observer["observer_start_order"].index("PROVE_OBSERVER_READY") < observer["observer_start_order"].index("START_WORKER_EXECUTION"))
    check("I024_STABLE_TUPLE", observer["stable_identity_minimum"] == ["host_pid", "proc_starttime", "pid_namespace_identity"])
    check("I025_POSTRUN_INSUFFICIENT", observer["post_run_proc_snapshot_only"] == "INSUFFICIENT")
    requirements = load(ROOT / "SUCCESSOR_V11_REQUIREMENTS.json")["mandatory_requirements"]
    check("I026_SHORT_LIVED_FIXTURE", "SHORT_LIVED_CHILD_POSITIVE_PRE_ATTEMPT_FIXTURE" in requirements)
    check("I027_MISSING_RECORD_FIXTURE", "TRACE_PID_WITHOUT_TEMPORAL_RECORD_NEGATIVE_FIXTURE" in requirements)
    check("I028_PID_REUSE_FIXTURE", "PID_REUSE_NEGATIVE_FIXTURE" in requirements)
    successor = load(ROOT / "SUCCESSOR_V11_AUTHORIZATION_DECISION.json")
    check("I029_SUCCESSOR_STATE", successor["state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I030_SUCCESSOR_ZERO", successor["attempt_count"] == successor["worker_invocation_count"] == successor["codex_as_worker_invocation_count"] == 0)
    check("I031_V11_ABSENT", not V11.exists() and not V11.is_symlink())
    primary = load(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I032_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_failed"] == 0)
    check("I033_NEGATIVE_PASS", negative["status"] == "PASS" and negative["checks_failed"] == 0)
    matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    check("I034_GOVERNANCE_COUNTERS_ZERO", all(value == 0 for value in matrix["operation_counters"].values()))
    check("I035_NO_V10_MUTATION", tree_root(V10) == (EXPECTED_ROOT, 127))
    status = "PASS" if all(row["status"] == "PASS" for row in checks) else "FAIL_CLOSED"
    with (ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY,
            "record_type": "FIRST_WORKER_V10_ERRATUM_INDEPENDENT_GOVERNANCE_VALIDATION_RESULT",
            "run_id": "RUN-0001", "status": status, "checks_total": len(checks),
            "checks_passed": sum(row["status"] == "PASS" for row in checks),
            "checks_failed": sum(row["status"] != "PASS" for row in checks), "checks": checks},
            handle, indent=2, sort_keys=True)
        handle.write("\n")
    if status != "PASS":
        raise SystemExit("independent governance validation failed closed")


if __name__ == "__main__":
    main()
