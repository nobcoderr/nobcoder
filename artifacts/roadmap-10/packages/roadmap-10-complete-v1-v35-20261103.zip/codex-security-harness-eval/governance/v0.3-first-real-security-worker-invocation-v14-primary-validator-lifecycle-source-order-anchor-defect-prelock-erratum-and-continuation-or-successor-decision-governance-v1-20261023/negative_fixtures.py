"""Semantic lifecycle-anchor negative and positive governance fixtures."""
from __future__ import annotations

from governance_common import *

PRELUDE = """\
import subprocess
from pathlib import Path
STATIC_RUN = Path('/fixture')
def wait_for_json(*a): pass
def append_only_json(*a): pass
"""
A = "observer_process = subprocess.Popen(['observer'])"
B = "observer_ready = wait_for_json('ready')"
C = "process = subprocess.Popen(['trace'])"
D = "trace_ready = any([True])"
E = "append_only_json(STATIC_RUN / 'ATTEMPT_MARKER.json', {})"


def result_for(lines: list[str]) -> str:
    return semantic_lifecycle_anchors(PRELUDE + "\n".join(lines) + "\n")["status"]


def main() -> int:
    fixtures = [
        ("N001_CANONICAL_ORDER", [A, B, C, D, E], "PASS"),
        ("N002_OBSERVER_SUFFIX_NOT_C", [A, B, D, E], "FAIL_CLOSED"),
        ("N003_EXACT_PROCESS_IS_C", [A, B, C, D, E], "PASS"),
        ("N004_EARLY_MARKER_READ_IGNORED", ["early = (STATIC_RUN / 'ATTEMPT_MARKER.json').exists()", A, B, C, D, E], "PASS"),
        ("N005_APPEND_ONLY_CREATION_IS_E", [A, B, C, D, E], "PASS"),
        ("N006_TRACED_PROCESS_BEFORE_READY", [A, C, B, D, E], "FAIL_CLOSED"),
        ("N007_TRACER_READY_INVALID_POSITION", [D, A, B, C, E], "FAIL_CLOSED"),
        ("N008_ATTEMPT_BEFORE_TRACER_READY", [A, B, C, E, D], "FAIL_CLOSED"),
        ("N009_MISSING_ANCHOR", [A, B, C, E], "FAIL_CLOSED"),
        ("N010_AMBIGUOUS_ANCHOR", [A, B, C, C, D, E], "FAIL_CLOSED"),
        ("N011_COMMENT_STRING_INERT", ["# process = subprocess.Popen(['fake'])", "fake = \"append_only_json(STATIC_RUN / 'ATTEMPT_MARKER.json', {})\"", A, B, C, D, E], "PASS"),
    ]
    checks = []
    for identifier, lines, expected in fixtures:
        actual = result_for(lines)
        checks.append({"id": identifier, "status": "PASS" if actual == expected else "FAIL", "expected": expected, "actual": actual})
    failures = [row["id"] for row in checks if row["status"] == "FAIL"]
    result = {"record_type": "V14_LIFECYCLE_ANCHOR_NEGATIVE_GOVERNANCE_FIXTURES", "status": "PASS" if not failures else "FAIL_CLOSED", "checks": checks, "failure_ids": failures, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}}
    write_json_once(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", result)
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
