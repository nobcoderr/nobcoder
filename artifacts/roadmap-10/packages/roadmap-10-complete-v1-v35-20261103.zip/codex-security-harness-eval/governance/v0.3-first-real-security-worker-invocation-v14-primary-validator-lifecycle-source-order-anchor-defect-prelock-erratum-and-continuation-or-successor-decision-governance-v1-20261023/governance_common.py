"""Shared, read-only helpers for the V14 lifecycle-anchor governance package."""
from __future__ import annotations

import ast
import hashlib
import json
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V14 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v14-20261023")
V15 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v15-20261023")
RUNNER = V14 / "src/runner_v14.py"
PRIMARY_VALIDATOR = V14 / "validators/primary_static_validate.py"
INDEPENDENT_VALIDATOR = V14 / "validators/independent_static_validate.py"
UNIT = V14 / "results/prelock/unit-fixtures-run-0001.json"
PRIMARY = V14 / "results/prelock/primary-static-validation-run-0001.json"
STATIC_RUN = V14 / "static-run-v14"

IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V14_"
    "PRIMARY_VALIDATOR_LIFECYCLE_SOURCE_ORDER_ANCHOR_DEFECT_"
    "PRELOCK_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
UNIT_SHA256 = "3b91f58fc216c396b19988d90323b0f331adab50aa28068c08e9d2b726e82804"
PRIMARY_SHA256 = "f4cbd3434d34b4c04f1fda19fb96904e4a356c9d59174fb1e7a41d54184b2cc5"
RUNNER_SHA256 = "ff5c4e307a94b80e012b5f85f9c7f3d5b8dcc9470925f7573f0964facc4e5350"
PRIMARY_VALIDATOR_SHA256 = "a2c27fe341e60004d18a21879c164fbac012a98869874f6415bb21ae9f7103bd"
INDEPENDENT_VALIDATOR_SHA256 = "da6fafe72246968880fdbcbaed1f734f09fffaa202348ef0e80813688c2a4994"
TESTS_SHA256 = "4caf5b1cff3b7b4ee86d171fa0a4d2f85591ff0bec74522a12d32b090efb8172"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_json_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def write_json_once(path: Path, value: Any) -> None:
    with path.open("xb") as handle:
        handle.write(canonical_json_bytes(value))


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_only(path: Path) -> bool:
    return stat.S_IMODE(path.stat().st_mode) & 0o222 == 0


def snapshot_tree(root: Path) -> dict[str, Any]:
    members = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        members.append(
            {
                "path": path.relative_to(root).as_posix(),
                "sha256": sha256(path),
                "size": path.stat().st_size,
                "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
            }
        )
    root_digest = hashlib.sha256(
        "".join(f"{row['path']}\0{row['sha256']}\n" for row in members).encode()
    ).hexdigest()
    return {
        "algorithm": "SHA256_OF_SORTED_RELATIVE_PATH_NUL_SHA256_NEWLINE",
        "member_count": len(members),
        "tree_root_sha256": root_digest,
        "members": members,
    }


def _call_name(node: ast.AST | None) -> str | None:
    if not isinstance(node, ast.Call):
        return None
    function = node.func
    if isinstance(function, ast.Name):
        return function.id
    if isinstance(function, ast.Attribute) and isinstance(function.value, ast.Name):
        return f"{function.value.id}.{function.attr}"
    return None


def _exact_target(node: ast.Assign | ast.AnnAssign, name: str) -> bool:
    targets = node.targets if isinstance(node, ast.Assign) else [node.target]
    return len(targets) == 1 and isinstance(targets[0], ast.Name) and targets[0].id == name


def _attempt_marker_operand(node: ast.AST) -> bool:
    return (
        isinstance(node, ast.BinOp)
        and isinstance(node.op, ast.Div)
        and isinstance(node.left, ast.Name)
        and node.left.id == "STATIC_RUN"
        and isinstance(node.right, ast.Constant)
        and node.right.value == "ATTEMPT_MARKER.json"
    )


def semantic_lifecycle_anchors(source: str) -> dict[str, Any]:
    """Find unique authoritative AST anchors; comments and strings are inert."""
    tree = ast.parse(source)
    found: dict[str, list[int]] = {key: [] for key in "ABCDE"}
    marker_references: list[int] = []
    for node in ast.walk(tree):
        value = node.value if isinstance(node, (ast.Assign, ast.AnnAssign)) else None
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            if _exact_target(node, "observer_process") and _call_name(value) == "subprocess.Popen":
                found["A"].append(node.lineno)
            if _exact_target(node, "observer_ready") and _call_name(value) == "wait_for_json":
                found["B"].append(node.lineno)
            if _exact_target(node, "process") and _call_name(value) == "subprocess.Popen":
                found["C"].append(node.lineno)
            if _exact_target(node, "trace_ready") and _call_name(value) == "any":
                found["D"].append(node.lineno)
        if isinstance(node, ast.Call):
            if _call_name(node) == "append_only_json" and node.args and _attempt_marker_operand(node.args[0]):
                found["E"].append(node.lineno)
            for child in ast.walk(node):
                if _attempt_marker_operand(child):
                    marker_references.append(node.lineno)
                    break
    unique = all(len(found[key]) == 1 for key in "ABCDE")
    lines = [found[key][0] for key in "ABCDE"] if unique else []
    return {
        "status": "PASS" if unique and lines == sorted(lines) else "FAIL_CLOSED",
        "anchors": found,
        "ordered_lines": lines,
        "required_order": "A < B < C < D < E",
        "marker_call_reference_lines": sorted(set(marker_references)),
    }


def frozen_state() -> dict[str, Any]:
    unit = load_json(UNIT)
    primary = load_json(PRIMARY)
    s023 = next(row for row in primary["checks"] if row["id"] == "S023_LIFECYCLE_SOURCE_ORDER")
    return {
        "unit": unit,
        "primary": primary,
        "s023": s023,
        "tree": snapshot_tree(V14),
        "lifecycle": semantic_lifecycle_anchors(RUNNER.read_text(encoding="utf-8")),
    }


def exact_frozen_hashes() -> bool:
    return all(
        (
            sha256(UNIT) == UNIT_SHA256,
            sha256(PRIMARY) == PRIMARY_SHA256,
            sha256(RUNNER) == RUNNER_SHA256,
            sha256(PRIMARY_VALIDATOR) == PRIMARY_VALIDATOR_SHA256,
            sha256(INDEPENDENT_VALIDATOR) == INDEPENDENT_VALIDATOR_SHA256,
            sha256(V14 / "tests/run_unit_fixtures.py") == TESTS_SHA256,
        )
    )


def no_execution_state() -> bool:
    prohibited = [
        V14 / "STATIC_EXECUTION_LOCK.json",
        V14 / "results/prelock/independent-static-validation-run-0001.json",
        V14 / "results/prelock/fresh-preflight-run-0001.json",
        STATIC_RUN / "ATTEMPT_MARKER.json",
        STATIC_RUN / "runtime-result-0001.json",
    ]
    return not any(path.exists() for path in prohibited) and not any(
        path.is_file() for path in STATIC_RUN.rglob("*")
    )
