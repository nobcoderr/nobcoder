"""Create the append-only governance manifest and PASS_LOCKED lock."""
from __future__ import annotations

import os
from governance_common import *

EXCLUDED = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"}


def main() -> int:
    for name in ("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"):
        if load_json(ROOT / name).get("status") != "PASS":
            raise RuntimeError(f"cannot freeze: {name} is not PASS")
    if not exact_frozen_hashes() or not no_execution_state() or V15.exists():
        raise RuntimeError("cannot freeze: V14/V15 boundary drift")
    members = []
    for path in sorted(item for item in ROOT.iterdir() if item.is_file() and item.name not in EXCLUDED):
        members.append({"path": path.name, "sha256": sha256(path), "size": path.stat().st_size})
    root_digest = hashlib.sha256("".join(f"{row['path']}\0{row['sha256']}\n" for row in members).encode()).hexdigest()
    manifest = {"record_type": "V14_LIFECYCLE_ANCHOR_GOVERNANCE_ARTIFACT_MANIFEST", "status": "PASS", "member_count": len(members), "canonical_root_sha256": root_digest, "members": members}
    write_json_once(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    lock = {
        "record_type": "V14_LIFECYCLE_ANCHOR_GOVERNANCE_LOCK", "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "canonical_root_sha256": root_digest,
        "PRIMARY_VALIDATOR_LIFECYCLE_SOURCE_ORDER_ANCHOR_DEFECT": "YES",
        "RUNNER_LIFECYCLE_SOURCE_ORDER_DEFECT": "NO",
        "TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT": "NOT_ESTABLISHED",
        "v14_disposition": "FAIL_CLOSED_PRELOCK_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "decision": "TERMINALIZE_V14_AND_AUTHORIZE_DISTINCT_V15_CONDITIONALLY",
        "v15_status": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "unit_evidence_sha256": UNIT_SHA256, "primary_evidence_sha256": PRIMARY_SHA256,
        "static_lock": "NOT_ISSUED", "attempt": "0_OF_1", "worker_invocation": "0_OF_1", "codex_as_worker_invocation": "0_OF_1",
        "worker_or_codex_invocation_during_governance": 0,
    }
    write_json_once(ROOT / "GOVERNANCE_LOCK.json", lock)
    for path in [*(ROOT / row["path"] for row in members), ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", ROOT / "GOVERNANCE_LOCK.json"]:
        os.chmod(path, 0o444)
    print(json.dumps({"status": lock["status"], "members": len(members), "root": root_digest}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
