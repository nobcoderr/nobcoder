"""Build the V14 governance-only lifecycle-anchor erratum from frozen evidence."""
from __future__ import annotations

from governance_common import *


def emit(name: str, value: dict) -> None:
    write_json_once(ROOT / name, value)


def main() -> int:
    if not exact_frozen_hashes() or not no_execution_state():
        raise RuntimeError("V14 frozen evidence or zero-execution state drift")
    state = frozen_state()
    if state["lifecycle"]["status"] != "PASS":
        raise RuntimeError("semantic runner lifecycle order not established")
    unit, primary, s023 = state["unit"], state["primary"], state["s023"]
    emit("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V14_LIFECYCLE_ANCHOR_GOVERNANCE_ROUTING",
        "governance_identity": IDENTITY,
        "status": "PASS",
        "task_class": "LOCAL_FROZEN_EVIDENCE_GOVERNANCE_ONLY",
        "active_skills": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness"],
        "subagents": "NOT_USED",
        "target_network_credential_worker_codex_activity": "PROHIBITED",
    })
    emit("ROUTING_LEDGER.json", {
        "record_type": "V14_LIFECYCLE_ANCHOR_GOVERNANCE_ROUTING_LEDGER", "status": "PASS",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness"],
        "deferred": ["program-impact-boundary-gate", "external-ai-security-tool-governor"],
        "not_applicable": ["live-target-testing", "credentials", "network", "subagents", "parallelism", "exploit-replay", "promotion", "submission"],
    })
    emit("V14_FROZEN_EVIDENCE_SNAPSHOT_MANIFEST.json", {
        "record_type": "V14_FROZEN_PRELOCK_EVIDENCE_SNAPSHOT", "status": "PASS", **state["tree"]
    })
    emit("V14_FROZEN_EVIDENCE_BINDING.json", {
        "record_type": "V14_FROZEN_VALIDATION_EVIDENCE_BINDING", "status": "PASS",
        "unit": {"path": str(UNIT), "sha256": UNIT_SHA256, "status": unit["status"], "counts": unit["validation_counts"], "read_only": read_only(UNIT)},
        "primary": {"path": str(PRIMARY), "sha256": PRIMARY_SHA256, "status": primary["status"], "counts": primary["validation_counts"], "failure_ids": primary["failure_ids"], "read_only": read_only(PRIMARY)},
        "runner_sha256": RUNNER_SHA256,
        "primary_validator_sha256": PRIMARY_VALIDATOR_SHA256,
        "independent_validator_sha256": INDEPENDENT_VALIDATOR_SHA256,
        "tests_sha256": TESTS_SHA256,
        "static_lock": "NOT_ISSUED", "attempt": "0_OF_1", "worker_invocation": "0_OF_1", "codex_as_worker_invocation": "0_OF_1",
    })
    emit("LIFECYCLE_SOURCE_ORDER_EVIDENCE_ADJUDICATION.json", {
        "record_type": "V14_LIFECYCLE_SOURCE_ORDER_EVIDENCE_ADJUDICATION", "status": "PASS",
        "semantic_anchors": {
            "A": "AUTHORITATIVE_OBSERVER_PROCESS_START_CREATION",
            "B": "OBSERVER_READINESS_PROOF",
            "C": "AUTHORITATIVE_TRACED_PROCESS_CREATION",
            "D": "TRACER_READINESS_PROOF",
            "E": "AUTHORITATIVE_APPEND_ONLY_ATTEMPT_MARKER_CREATION",
        },
        "runner_ast_result": state["lifecycle"],
        "actual_order": "A < B < C < D < E",
        "primary_failed_gate": s023,
        "primary_raw_text_failure_mechanism": {
            "observed_offsets": s023["evidence"],
            "traced_process_false_anchor": "process = subprocess.Popen matched as a suffix within observer_process = subprocess.Popen",
            "attempt_false_anchor": "first ATTEMPT_MARKER path occurrence was a read/check, not append-only creation",
        },
        "independent_validator_latent_same_class": "YES_STATIC_SOURCE_EVIDENCE_RAW_INDEX_FIRST_OCCURRENCE_AND_SUFFIX_COLLISION",
        "runtime_observer_behavior": "NOT_ESTABLISHED_NO_WORKER_EXECUTION",
    })
    emit("DEFECT_OWNERSHIP_DECISION.json", {
        "record_type": "V14_LIFECYCLE_ANCHOR_DEFECT_OWNERSHIP", "status": "PASS",
        "PRIMARY_VALIDATOR_LIFECYCLE_SOURCE_ORDER_ANCHOR_DEFECT": "YES",
        "RUNNER_LIFECYCLE_SOURCE_ORDER_DEFECT": "NO",
        "TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT": "NOT_ESTABLISHED",
        "INDEPENDENT_VALIDATOR_LATENT_LIFECYCLE_ANCHOR_GAP": "YES_STATIC_SOURCE_EVIDENCE",
        "basis": "Frozen AST establishes unique A<B<C<D<E; primary raw-text offsets select non-authoritative anchors; independent source uses the same non-semantic method but was not executed.",
    })
    emit("V14_PRELOCK_TERMINAL_DISPOSITION.json", {
        "record_type": "V14_PRELOCK_TERMINAL_DISPOSITION",
        "status": "FAIL_CLOSED_PRELOCK_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "immutable": True, "continuation": "PROHIBITED", "static_lock": "NOT_ISSUED",
        "attempt": "0_OF_1", "worker_invocation": "0_OF_1", "codex_as_worker_invocation": "0_OF_1",
        "independent_validation": "NOT_STARTED", "fresh_preflight": "NOT_STARTED",
        "no_patch": True, "no_rerun": True, "no_execution": True,
    })
    emit("CONTINUATION_OR_SUCCESSOR_DECISION.json", {
        "record_type": "V14_CONTINUATION_OR_SUCCESSOR_DECISION", "status": "PASS",
        "decision": "TERMINALIZE_V14_AND_AUTHORIZE_DISTINCT_V15_CONDITIONALLY",
        "v15_status": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "reason": "The permitted primary-only continuation scope cannot produce a valid full chain because the frozen independent validator contains the same raw-text anchor class and append-only historical slots would require broader provenance changes. A fresh identity is the narrowest complete correction.",
    })
    emit("SUCCESSOR_V15_REQUIREMENTS.json", {
        "record_type": "SUCCESSOR_V15_LIFECYCLE_ANCHOR_REQUIREMENTS", "status": "NORMATIVE_IF_V15_IMPLEMENTED",
        "fresh_workspace": True, "v14_reference_only": True,
        "requirements": [
            "PRIMARY_AND_INDEPENDENT_VALIDATORS_RECOMPUTE_SEMANTIC_ANCHORS_INDEPENDENTLY",
            "UNIQUE_AUTHORITATIVE_A_B_C_D_E_ANCHORS", "EXACT_ORDER_A_LT_B_LT_C_LT_D_LT_E",
            "EXACT_TARGET_OBSERVER_PROCESS_FOR_A", "EXACT_TARGET_PROCESS_FOR_C",
            "ATTEMPT_CREATION_REQUIRES_APPEND_ONLY_JSON_EXACT_STATIC_RUN_MARKER_OPERAND",
            "COMMENTS_STRINGS_READS_CHECKS_REFERENCES_SUFFIXES_AND_FIRST_OCCURRENCE_MATCHES_PROHIBITED",
            "MISSING_OR_AMBIGUOUS_ANCHOR_FAIL_CLOSED", "FRESH_VALIDATION_RUN_0001_SLOTS",
            "FULL_UNIT_PRIMARY_INDEPENDENT_PREFLIGHT_CLOSURE_LOCK_POSTLOCK_CHAIN",
            "N_OF_N_TEMPORAL_IDENTITY_COVERAGE", "ONE_SHOT_ONLY_AFTER_ALL_GATES_PASS",
        ],
        "preserve": ["TEMPORAL_TELEMETRY", "ADVERSARIAL_SELFTEST_CORPUS", "WORKER_REQUEST", "PROMPT", "CODEX_RUNTIME_CONFIG", "MOUNT_PROVENANCE_PRODUCER_AUTHORIZATION_SEPARATION"],
        "prohibitions": ["V14_MUTATION", "V14_RERUN", "SUBSTRING_ANCHORS", "TARGET", "CREDENTIAL", "TARGET_NETWORK", "SUBAGENT", "PARALLELISM", "PROMOTION", "SUBMISSION"],
    })
    cases = [
        ("R01", "observer_process assignment cannot satisfy C", "FAIL_CLOSED_MISSING_C"),
        ("R02", "exact process assignment satisfies authoritative C", "PASS_WHEN_FULL_ORDER_VALID"),
        ("R03", "early attempt marker read/check/reference", "IGNORED"),
        ("R04", "exact append-only attempt marker creation", "AUTHORITATIVE_E"),
        ("R05", "canonical A<B<C<D<E", "PASS"),
        ("R06", "C before B", "FAIL_CLOSED"),
        ("R07", "D in invalid lifecycle position", "FAIL_CLOSED"),
        ("R08", "E before D", "FAIL_CLOSED"),
        ("R09", "missing anchor", "FAIL_CLOSED"),
        ("R10", "ambiguous duplicate anchor", "FAIL_CLOSED"),
        ("R11", "comments or strings contain anchor text", "IGNORED"),
    ]
    emit("V14_FAILURE_AND_V15_REGRESSION_MATRIX.json", {
        "record_type": "V14_FAILURE_AND_V15_REGRESSION_MATRIX", "status": "PASS",
        "cases": [{"id": i, "case": case, "expected": expected} for i, case, expected in cases],
    })
    emit("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "V14_GOVERNANCE_OPERATION_AUTHORIZATION_MATRIX", "status": "PASS",
        "governance_artifact_creation": "AUTHORIZED", "read_frozen_v14_evidence": "AUTHORIZED",
        "v14_patch_rerun_revalidation_lock_or_execution": "PROHIBITED",
        "worker_or_codex_invocation": "PROHIBITED", "v15_creation_or_execution_during_governance": "PROHIBITED",
        "target_credential_network_subagent_parallelism_capability_promotion_submission": "PROHIBITED",
    })
    emit("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V14_LIFECYCLE_ANCHOR_NEGATIVE_TEST_MATRIX", "status": "PASS",
        "tests": [case for _, case, _ in cases] + ["reject frozen evidence digest drift", "reject V14 execution state drift", "reject V15 creation during governance"],
    })
    emit("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "V14_LIFECYCLE_ANCHOR_ERRATUM_DECISION_SUMMARY", "governance_identity": IDENTITY,
        "status": "PASS_PENDING_FREEZE",
        "PRIMARY_VALIDATOR_LIFECYCLE_SOURCE_ORDER_ANCHOR_DEFECT": "YES",
        "RUNNER_LIFECYCLE_SOURCE_ORDER_DEFECT": "NO",
        "TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT": "NOT_ESTABLISHED",
        "decision": "TERMINALIZE_V14_AND_AUTHORIZE_DISTINCT_V15_CONDITIONALLY",
        "worker_or_codex_invocation_count": 0,
    })
    emit("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V14_GOVERNANCE_NEXT_LEGAL_MILESTONE", "status": "PASS",
        "milestone": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V15_ONCE_IF_ALL_GATES_PASS",
        "precondition": "THIS_GOVERNANCE_PACKAGE_PASS_LOCKED_GOVERNANCE_ONLY",
        "v15_created_or_executed_here": False,
    })
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
