"""Final read-only verification of the frozen V14 governance package."""
from __future__ import annotations

import os
from governance_common import *


def main() -> int:
    checks = []
    def check(identifier: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    manifest = load_json(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load_json(ROOT / "GOVERNANCE_LOCK.json")
    rows = manifest.get("members", [])
    recomputed_root = hashlib.sha256("".join(f"{row['path']}\0{row['sha256']}\n" for row in rows).encode()).hexdigest()
    check("F001_LOCK_PASS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F002_MANIFEST_DIGEST", sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock.get("manifest_sha256"))
    check("F003_ROOT", recomputed_root == manifest.get("canonical_root_sha256") == lock.get("canonical_root_sha256"))
    check("F004_MEMBER_COUNT", len(rows) == manifest.get("member_count"))
    missing_or_drift = []
    writable = []
    for row in rows:
        path = ROOT / row["path"]
        if not path.is_file() or sha256(path) != row["sha256"] or path.stat().st_size != row["size"]:
            missing_or_drift.append(row["path"])
        elif not read_only(path):
            writable.append(row["path"])
    check("F005_MEMBERS_EXACT", not missing_or_drift, missing_or_drift)
    check("F006_MEMBERS_READ_ONLY", not writable, writable)
    check("F007_LOCK_FILES_READ_ONLY", read_only(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") and read_only(ROOT / "GOVERNANCE_LOCK.json"))
    check("F008_V14_HASHES", exact_frozen_hashes())
    snapshot = load_json(ROOT / "V14_FROZEN_EVIDENCE_SNAPSHOT_MANIFEST.json")
    current = snapshot_tree(V14)
    check("F009_V14_TREE_UNCHANGED", current["members"] == snapshot["members"] and current["tree_root_sha256"] == snapshot["tree_root_sha256"])
    check("F010_ZERO_EXECUTION_STATE", no_execution_state())
    check("F011_V15_NOT_CREATED", not V15.exists())
    check("F012_DECISION", lock.get("decision") == "TERMINALIZE_V14_AND_AUTHORIZE_DISTINCT_V15_CONDITIONALLY")
    failures = [row["id"] for row in checks if row["status"] == "FAIL"]
    result = {"record_type": "V14_LIFECYCLE_ANCHOR_FINAL_FREEZE_VERIFICATION", "status": "PASS" if not failures else "FAIL_CLOSED", "checks": checks, "failure_ids": failures, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "worker_or_codex_invocation_count": 0}
    write_json_once(ROOT / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json", result)
    os.chmod(ROOT / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json", 0o444)
    if not failures:
        os.chmod(ROOT, 0o555)
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
