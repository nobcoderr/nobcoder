"""Independent governance validation with its own AST lifecycle extraction."""
from __future__ import annotations

import ast
from governance_common import *


def independent_anchors(source: str) -> dict[str, list[int]]:
    tree = ast.parse(source)
    out = {key: [] for key in "ABCDE"}
    for node in ast.walk(tree):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if len(targets) != 1 or not isinstance(targets[0], ast.Name) or not isinstance(node.value, ast.Call):
                continue
            target = targets[0].id
            function = node.value.func
            call = function.id if isinstance(function, ast.Name) else f"{function.value.id}.{function.attr}" if isinstance(function, ast.Attribute) and isinstance(function.value, ast.Name) else None
            mapping = {("observer_process", "subprocess.Popen"): "A", ("observer_ready", "wait_for_json"): "B", ("process", "subprocess.Popen"): "C", ("trace_ready", "any"): "D"}
            if (target, call) in mapping:
                out[mapping[(target, call)]].append(node.lineno)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "append_only_json" and node.args:
            arg = node.args[0]
            if isinstance(arg, ast.BinOp) and isinstance(arg.op, ast.Div) and isinstance(arg.left, ast.Name) and arg.left.id == "STATIC_RUN" and isinstance(arg.right, ast.Constant) and arg.right.value == "ATTEMPT_MARKER.json":
                out["E"].append(node.lineno)
    return out


def main() -> int:
    checks = []
    def check(identifier: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    primary_result = load_json(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative_result = load_json(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    snapshot = load_json(ROOT / "V14_FROZEN_EVIDENCE_SNAPSHOT_MANIFEST.json")
    current = snapshot_tree(V14)
    independent = independent_anchors(RUNNER.read_text(encoding="utf-8"))
    lines = [independent[key][0] for key in "ABCDE"] if all(len(independent[key]) == 1 for key in "ABCDE") else []
    primary_source = PRIMARY_VALIDATOR.read_text(encoding="utf-8")
    independent_source = INDEPENDENT_VALIDATOR.read_text(encoding="utf-8")
    decision = load_json(ROOT / "CONTINUATION_OR_SUCCESSOR_DECISION.json")
    ownership = load_json(ROOT / "DEFECT_OWNERSHIP_DECISION.json")

    check("I001_PRIMARY_GOVERNANCE_PASS", primary_result.get("status") == "PASS")
    check("I002_NEGATIVE_FIXTURES_PASS", negative_result.get("status") == "PASS")
    check("I003_FROZEN_HASHES", exact_frozen_hashes())
    check("I004_TREE_UNCHANGED", current["member_count"] == snapshot["member_count"] and current["tree_root_sha256"] == snapshot["tree_root_sha256"] and current["members"] == snapshot["members"])
    check("I005_HISTORICAL_RESULTS_READ_ONLY", read_only(UNIT) and read_only(PRIMARY))
    check("I006_INDEPENDENT_AST_ANCHORS", independent == {"A": [500], "B": [508], "C": [555], "D": [573], "E": [622]}, independent)
    check("I007_ORDER_A_B_C_D_E", lines == sorted(lines) == [500, 508, 555, 573, 622], lines)
    check("I008_PRIMARY_RAW_TEXT_BUG_PRESENT", "runner.index(token)" in primary_source and '"process = subprocess.Popen"' in primary_source and "ATTEMPT_MARKER.json" in primary_source)
    check("I009_INDEPENDENT_LATENT_BUG_PRESENT", "runner.index(token)" in independent_source and '"process = subprocess.Popen"' in independent_source and "ATTEMPT_MARKER.json" in independent_source)
    check("I010_DEFECT_OWNERSHIP", ownership.get("PRIMARY_VALIDATOR_LIFECYCLE_SOURCE_ORDER_ANCHOR_DEFECT") == "YES" and ownership.get("RUNNER_LIFECYCLE_SOURCE_ORDER_DEFECT") == "NO")
    check("I011_RUNTIME_NOT_ESTABLISHED", ownership.get("TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT") == "NOT_ESTABLISHED")
    check("I012_SUCCESSOR_DECISION", decision.get("decision") == "TERMINALIZE_V14_AND_AUTHORIZE_DISTINCT_V15_CONDITIONALLY")
    check("I013_ZERO_EXECUTION_STATE", no_execution_state())
    check("I014_V15_NOT_CREATED", not V15.exists())
    failures = [row["id"] for row in checks if row["status"] == "FAIL"]
    result = {"record_type": "V14_LIFECYCLE_ANCHOR_INDEPENDENT_GOVERNANCE_VALIDATION", "status": "PASS" if not failures else "FAIL_CLOSED", "checks": checks, "failure_ids": failures, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "worker_or_codex_invocation_count": 0}
    write_json_once(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
