"""Primary validation for the V14 governance-only lifecycle-anchor erratum."""
from __future__ import annotations

from governance_common import *


def main() -> int:
    checks = []
    def check(identifier: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    state = frozen_state()
    binding = load_json(ROOT / "V14_FROZEN_EVIDENCE_BINDING.json")
    snapshot = load_json(ROOT / "V14_FROZEN_EVIDENCE_SNAPSHOT_MANIFEST.json")
    adjudication = load_json(ROOT / "LIFECYCLE_SOURCE_ORDER_EVIDENCE_ADJUDICATION.json")
    ownership = load_json(ROOT / "DEFECT_OWNERSHIP_DECISION.json")
    disposition = load_json(ROOT / "V14_PRELOCK_TERMINAL_DISPOSITION.json")
    decision = load_json(ROOT / "CONTINUATION_OR_SUCCESSOR_DECISION.json")
    requirements = load_json(ROOT / "SUCCESSOR_V15_REQUIREMENTS.json")
    matrix = load_json(ROOT / "V14_FAILURE_AND_V15_REGRESSION_MATRIX.json")
    operations = load_json(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")

    check("G001_EXACT_FROZEN_HASHES", exact_frozen_hashes())
    check("G002_HISTORICAL_RESULTS_READ_ONLY", read_only(UNIT) and read_only(PRIMARY))
    check("G003_UNIT_104_OF_104", state["unit"].get("status") == "PASS" and state["unit"].get("validation_counts") == {"total": 104, "passed": 104, "failed": 0})
    check("G004_PRIMARY_49_OF_50", state["primary"].get("status") == "FAIL_CLOSED" and state["primary"].get("validation_counts") == {"total": 50, "passed": 49, "failed": 1})
    check("G005_ONLY_S023_FAILED", state["primary"].get("failure_ids") == ["S023_LIFECYCLE_SOURCE_ORDER"])
    check("G006_S023_OFFSETS", state["s023"].get("evidence") == [24808, 25086, 24817, 28275, 19981, 31828])
    check("G007_ZERO_EXECUTION_STATE", no_execution_state())
    check("G008_BINDING_EXACT", binding["unit"]["sha256"] == UNIT_SHA256 and binding["primary"]["sha256"] == PRIMARY_SHA256)
    check("G009_SNAPSHOT_EXACT", snapshot["member_count"] == state["tree"]["member_count"] and snapshot["tree_root_sha256"] == state["tree"]["tree_root_sha256"] and snapshot["members"] == state["tree"]["members"])
    check("G010_UNIQUE_SEMANTIC_ORDER", state["lifecycle"]["status"] == "PASS" and state["lifecycle"]["ordered_lines"] == [500, 508, 555, 573, 622], state["lifecycle"])
    check("G011_ADJUDICATION_BINDS_AST", adjudication["runner_ast_result"] == state["lifecycle"])
    check("G012_PRIMARY_DEFECT_YES", ownership.get("PRIMARY_VALIDATOR_LIFECYCLE_SOURCE_ORDER_ANCHOR_DEFECT") == "YES")
    check("G013_RUNNER_DEFECT_NO", ownership.get("RUNNER_LIFECYCLE_SOURCE_ORDER_DEFECT") == "NO")
    check("G014_OBSERVER_RUNTIME_NOT_ESTABLISHED", ownership.get("TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT") == "NOT_ESTABLISHED")
    check("G015_V14_TERMINAL", disposition.get("status") == "FAIL_CLOSED_PRELOCK_TERMINAL_NO_RETRY_REFERENCE_ONLY" and disposition.get("continuation") == "PROHIBITED")
    check("G016_COUNTS_ZERO", disposition.get("attempt") == disposition.get("worker_invocation") == disposition.get("codex_as_worker_invocation") == "0_OF_1")
    check("G017_SUCCESSOR_DECISION", decision.get("decision") == "TERMINALIZE_V14_AND_AUTHORIZE_DISTINCT_V15_CONDITIONALLY")
    required = set(requirements.get("requirements", []))
    check("G018_V15_SEMANTIC_REQUIREMENTS", {"PRIMARY_AND_INDEPENDENT_VALIDATORS_RECOMPUTE_SEMANTIC_ANCHORS_INDEPENDENTLY", "UNIQUE_AUTHORITATIVE_A_B_C_D_E_ANCHORS", "EXACT_ORDER_A_LT_B_LT_C_LT_D_LT_E", "MISSING_OR_AMBIGUOUS_ANCHOR_FAIL_CLOSED"} <= required)
    check("G019_REGRESSION_MATRIX_COMPLETE", len(matrix.get("cases", [])) == 11 and {row["id"] for row in matrix["cases"]} == {f"R{i:02d}" for i in range(1, 12)})
    check("G020_AUTHORITY_CEILING", operations.get("v14_patch_rerun_revalidation_lock_or_execution") == "PROHIBITED" and operations.get("worker_or_codex_invocation") == "PROHIBITED")
    check("G021_V15_NOT_CREATED", not V15.exists())
    failures = [row["id"] for row in checks if row["status"] == "FAIL"]
    result = {"record_type": "V14_LIFECYCLE_ANCHOR_PRIMARY_GOVERNANCE_VALIDATION", "status": "PASS" if not failures else "FAIL_CLOSED", "checks": checks, "failure_ids": failures, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failures), "failed": len(failures)}, "worker_or_codex_invocation_count": 0}
    write_json_once(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
