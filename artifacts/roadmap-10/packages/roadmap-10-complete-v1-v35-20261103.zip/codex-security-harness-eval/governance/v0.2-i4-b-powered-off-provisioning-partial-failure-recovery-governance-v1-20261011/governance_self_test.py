#!/usr/bin/env python3
"""Deterministic offline self-tests for the V3 partial-failure recovery decision."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
V3 = ROOT.parent / "v0.2-i4-b-dedicated-environment-provisioning-governance-v3-20261010"
EVIDENCE = Path("/media/sf_Downloads/v3-a1-a2-partial-evidence-20261010")
RUNNER_DIR = Path("/home/nobcoder")
IDENTITY = "V0.2_I4_B_POWERED_OFF_PROVISIONING_PARTIAL_FAILURE_RECOVERY_GOVERNANCE_V1"
V3_LOCK = "84a3a4daa6f9375ec8c02161aca38066530fd252fdfbd16ae4f25c675e39919f"
V3_ROOT = "f4442097e2032e1ee12d27b967e19faddad95c7c475bcdc8d88214cb1a9a446f"
R3_HASH = "d9ac56cf5df6576272c2d692c4b0c191cae4563645d35dacbf7ea07dadb55285"
ISO_HASH = "97f3d7ffb032c3eb3b23d2c8be9cc76e60c2c1f2c0146ba5ba9fe01cafae0fd8"


def load(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def governance_root(path: Path) -> str:
    rows = [
        f"{sha(item)}  {item.name}"
        for item in sorted(path.iterdir(), key=lambda value: value.name)
        if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json"
    ]
    return hashlib.sha256(("\n".join(rows) + "\n").encode()).hexdigest()


ID_LINE = re.compile(r"^ID / Description:\s+([A-Za-z0-9][A-Za-z0-9_]*)\s+--\s+(.+)$")


def accept_os_type(output: str, exit_code: int, authorized: str = "Ubuntu_64") -> bool:
    if exit_code != 0:
        return False
    identifiers: list[str] = []
    for line in output.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if not line:
            continue
        match = ID_LINE.fullmatch(line)
        if match:
            identifiers.append(match.group(1))
        elif line.startswith("ID"):
            return False
    return identifiers.count(authorized) == 1


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


p = load("RECOVERY_GATE_PROTOCOL.json")
pf = load("PREFLIGHT_RESULT.json")
eb = load("EVIDENCE_BINDING.json")
fr = load("PARTIAL_FAILURE_REVIEW.json")
rc = load("ROOT_CAUSE_ANALYSIS.json")
rs = load("RUNNER_REPAIR_SPEC.json")
ep = load("EXECUTION_PROVENANCE_ASSESSMENT.json")
om = load("RECOVERY_OPERATION_MATRIX.json")
pg = load("PRE_EXECUTION_GUARDS.json")
rr = load("RISK_REGISTER.json")
d = load("RECOVERY_DECISION.json")
a = load("RECOVERY_AUTHORIZATION.json")

check("fresh_identity", p["gate_id"] == d["gate_id"] == IDENTITY)
check("preflight_pass", pf["status"] == "PASS")
check("v3_lock", sha(V3 / "GOVERNANCE_LOCK.json") == V3_LOCK)
check("v3_manifest", sha(V3 / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "2745d1f8144b792e1bb38121324464164c08e6c5d57df1cfb504f706d2065e99")
check("v3_root", governance_root(V3) == V3_ROOT)
check("v3_terminal", fr["terminal_v3_disposition"] == "STOP_QUARANTINE_NO_RETRY_NO_CLEANUP")

for row in eb["files"]:
    check(f"evidence_{row['name']}", sha(EVIDENCE / row["name"]) == row["sha256"])
check("evidence_count", eb["file_count"] == len(eb["files"]) == 6)

a0 = json.loads((EVIDENCE / "A0_PREFLIGHT_RECORD.json").read_text(encoding="utf-8-sig"))
a1 = json.loads((EVIDENCE / "A1_ACQUISITION_RECORD.json").read_text(encoding="utf-8-sig"))
a2 = json.loads((EVIDENCE / "A2_ACQUISITION_RECORD.json").read_text(encoding="utf-8-sig"))
failure = json.loads((EVIDENCE / "FAILURE-V3-A1-A5-20261010T133016Z-894c6da4cf0647adb217fd482b92b611.json").read_text(encoding="utf-8-sig"))
state = json.loads((EVIDENCE / "PARTIAL_STATE.json").read_text(encoding="utf-8-sig"))
otypes = (EVIDENCE / "VBOX_UBUNTU_OSTYPES.txt").read_text(encoding="utf-8-sig")

check("run_chain", a0["run_id"] == a1["run_id"] == a2["run_id"] == failure["run_id"] == eb["v3_run_id"])
check("r3_bound_by_a0_a1", a0["script_sha256"] == a1["script_sha256"] == R3_HASH)
check("r3_exact_local_bytes", sha(RUNNER_DIR / "i4b-v3-powered-off-provisioning-a1-a5-r3.ps1") == R3_HASH)
check("r1_exact_local_bytes", sha(RUNNER_DIR / "i4b-v3-powered-off-provisioning-a1-a5.ps1") == rs["original_runner_policy"]["r1_sha256"])
check("r2_exact_local_bytes", sha(RUNNER_DIR / "i4b-v3-powered-off-provisioning-a1-a5-r2.ps1") == rs["original_runner_policy"]["r2_sha256"])
check("runners_read_only", all(not ((RUNNER_DIR / name).stat().st_mode & 0o222) for name in ("i4b-v3-powered-off-provisioning-a1-a5.ps1", "i4b-v3-powered-off-provisioning-a1-a5-r2.ps1", "i4b-v3-powered-off-provisioning-a1-a5-r3.ps1")))
check("a1_final", state["a1"] == "PASS" and fr["operation_matrix"][1]["status"] == "PASS_FINAL_NO_REPLAY")
check("a2_final", state["a2"] == "PASS" and a2["verified"] is True and fr["operation_matrix"][2]["status"] == "PASS_FINAL_NO_REPLAY")
check("iso_exact", a2["actual_bytes"] == 4080486400 and a2["actual_sha256"] == ISO_HASH == a2["expected_sha256"] == a2["published_sha256"])
check("a3_not_executed", state["a3"] == "NOT_EXECUTED_GUARD_DEFECT" and not state["vm_directory_exists"] and state["target_vm_registry_matches"] == 0)
check("a4_a5_not_started", state["a4"] == "NOT_STARTED" and state["a5"] == "NOT_STARTED")
check("failure_exact", failure["failed_phase"] == "A3_POWERED_OFF_VM_DEFINITION" and failure["disposition"] == "STOP_QUARANTINE_NO_RETRY_NO_CLEANUP")

r3 = (RUNNER_DIR / "i4b-v3-powered-off-provisioning-a1-a5-r3.ps1").read_text(encoding="utf-8")
check("guard_before_createvm", r3.index("$OsTypes.Text -notmatch") < r3.index('"createvm",'))
check("defective_guard_present", "(?m)^ID:\\s+Ubuntu_64\\s*$" in r3)
check("actual_identifier_present", accept_os_type(otypes, 0))
check("root_cause_class", rc["classification"] == "OS_TYPE_GUARD_OUTPUT_FORMAT_MISMATCH")
check("not_runtime_failure", "RUNTIME_ISOLATION_FAILURE" in rc["excluded_causes"])

positive = {
    "p01": "ID / Description: Ubuntu_64 -- Ubuntu (64-bit)\r\nFamily: Linux / Ubuntu (Linux)\r\nArchitecture: x86 (64-bit)\r\n",
    "p02": "ID / Description: Debian_64 -- Debian (64-bit)\nFamily: Linux\nID / Description: Ubuntu_64 -- Ubuntu (64-bit)\nFamily: Linux / Ubuntu (Linux)\n",
}
negative = {
    "missing": "ID / Description: Debian_64 -- Debian (64-bit)\n",
    "legacy": "ID: Ubuntu_64\n",
    "substring": "ID / Description: EvilUbuntu_64 -- Not Ubuntu\n",
    "duplicate": "ID / Description: Ubuntu_64 -- Ubuntu\nID / Description: Ubuntu_64 -- Ubuntu duplicate\n",
    "case": "ID / Description: ubuntu_64 -- Ubuntu\n",
    "alternate": "ID / Description: Ubuntu24_LTS_64 -- Ubuntu 24.04 LTS\n",
    "separator": "ID / Description: Ubuntu_64 Ubuntu\n",
    "ambiguous_prefix": "ID-Description: Ubuntu_64 -- Ubuntu\n",
    "empty_description": "ID / Description: Ubuntu_64 -- \n",
}
for name, text in positive.items():
    check(f"parser_accept_{name}", accept_os_type(text, 0))
for name, text in negative.items():
    check(f"parser_reject_{name}", not accept_os_type(text, 0))
check("parser_reject_nonzero", not accept_os_type(positive["p01"], 1))
check("parser_exact_authorized_id", rs["parser_contract"]["authorized_exact_identifier"] == "Ubuntu_64")
check("parser_no_substitution", rs["parser_contract"]["alternate_identifier_substitution"] == "FORBIDDEN_WITHOUT_NEW_AUTHORIZATION")

decisions = {row["id"]: row["decision"] for row in om["operations"]}
check("a1_a2_replay_denied", decisions["A1"] == decisions["A2"] == "DENIED_FINAL_NO_REPLAY")
check("a3_a5_conditional_only", all(decisions[x].startswith("GRANTED_NOT_EXECUTABLE_PENDING") for x in ("A3", "A4", "A5")))
check("denied_runtime_operations", all(decisions[x] == "NOT_AUTHORIZED" for x in ("B1", "B2", "B3", "B4", "B5", "B6")))
check("operation_counts", om["operation_count"] == len(om["operations"]) == 11 and om["conditional_grant_count"] == 3 and om["denied_or_not_authorized_count"] == 8)
check("runner_not_created", rs["future_runner"]["implementation_status"] == "NOT_CREATED_NOT_AUTHORIZED_BY_THIS_TASK" and rs["future_runner"]["digest_status"] == "NOT_ESTABLISHED")
check("runner_digest_lock_required", "validation lock" in rs["future_runner"]["digest_requirement"])
check("authorization_not_executable", a["status"] == "GRANTED_NOT_EXECUTABLE_PENDING_RUNNER_DIGEST_LOCK")
check("authorization_a3_a5_only", [x["id"] for x in a["conditionally_granted_operations"]] == ["A3", "A4", "A5"])
check("new_identity_required", a["validity"]["execution_identity"] == "NEW_SINGLE_USE_ID_REQUIRED_NOT_V3_RUN_ID")
check("no_auto_execution", a["automatic_execution"] is False and d["automatic_execution"] is False)
check("exact_binding", a["binding"]["host_alias"] == "lab-host-01" and a["binding"]["vm_id"] == "v02-i4b-benign-isolation-lab-01" and a["binding"]["vcpus"] == 4 and a["binding"]["memory_mib"] == 6144 and a["binding"]["virtual_disk_bytes_maximum"] == 68719476736)
check("zero_nic", a["binding"]["virtual_nics"] == 0 and a["binding"]["host_integrations"] == "DISABLED")
check("iso_predecessor_only", a["predecessor_iso"]["use"] == "IMMUTABLE_PREDECESSOR_EVIDENCE_ONLY" and a["predecessor_iso"]["reacquisition_or_reverification_as_A2"] == "FORBIDDEN")
check("future_failure_terminal", a["validity"]["partial_failure"] == "STOP_QUARANTINE_NO_RETRY_NO_CLEANUP_AND_REQUIRE_NEW_GOVERNED_REVIEW")

check("guard_count", pg["guard_count"] == len(pg["guards"]) == 14 and pg["all_required"] is True)
check("guards_no_cleanup_retry", pg["automatic_cleanup"] is False and pg["automatic_retry"] is False)
check("risk_count", rr["risk_count"] == len(rr["risks"]) == 16)
check("risks_fail_closed", all(row["fail_closed"] for row in rr["risks"]))
check("provenance_r3", ep["runner_lineage"][2]["sha256"] == R3_HASH)
check("provenance_process_override", ep["successful_invocation"]["process_scoped_execution_policy_argument_observed"] is True)
check("provenance_no_persistent_claim", ep["successful_invocation"]["persistent_execution_policy_change_evidenced"] is False)
check("provenance_non_elevated", ep["successful_invocation"]["elevation"] == "FALSE_CONFIRMED_BY_A0_RECORD" and a0["elevated_powershell"] is False)
check("provenance_limit_stated", "supplied transcript" in ep["successful_invocation"]["limitation"])
check("runtime_not_authorized", d["i4_b_execution"] == "NOT_GRANTED" and d["runtime_isolation"] == "NOT_EVALUATED")
check("later_milestones_denied", d["i5"] == "NOT_AUTHORIZED" and d["v0_3"] == "NOT_OPENED")
check("router_dependent_denied", p["router_integrity"]["status"] == "OPEN_DEGRADED_ROUTER_DEPENDENT_PATHS_BLOCKED")

for forbidden in (
    "RECOVERY_RUNNER.ps1",
    "VM_BOOT_AUTHORIZATION.json",
    "I4_B_AUTHORIZATION.json",
    "I5_AUTHORIZATION.json",
    "V0_3_AUTHORIZATION.json",
    "RUNTIME_RESULT.json",
):
    check(f"absent_{forbidden}", not (ROOT / forbidden).exists())

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": IDENTITY,
    "validator": "recovery_governance_self_test_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
