#!/usr/bin/env python3
"""Independent evidence-first validator for recovery governance V1."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
V3 = BASE / "v0.2-i4-b-dedicated-environment-provisioning-governance-v3-20261010"
EVIDENCE = Path("/media/sf_Downloads/v3-a1-a2-partial-evidence-20261010")
IDENTITY = "V0.2_I4_B_POWERED_OFF_PROVISIONING_PARTIAL_FAILURE_RECOVERY_GOVERNANCE_V1"
BASELINES = [
    (Path("/home/nobcoder/v0.2-experimental-research-engine"), "governance/i0/SOURCE_MANIFEST.json", "1a14d9c6dca921016acb79831e531308480fa9876e62ded6e1976b51ccbc311c"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i1"), "governance/i1/SOURCE_MANIFEST.json", "be1c40bb8c499672afe8e411dbb235060f1d0666931cdd3282d9a2ae4e3c651b"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i2"), "governance/i2/SOURCE_MANIFEST.json", "bb4abb8d766987a65a96205acca6c74ff2200551d8c925086431e0f27d0ee129"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i3"), "governance/i3/SOURCE_MANIFEST.json", "711d9b026870ff55135c5534f88bfc394d7734ee9943a8063baa189ac270c83e"),
    (Path("/home/nobcoder/v0.2-experimental-research-engine-i4"), "governance/i4a/SOURCE_MANIFEST.json", "138fd2e59526a663486f54b263b8167283e1736a54fbceb777c7a73dbe02ac34"),
]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_root_ok(root: Path, manifest_relative: str, expected: str) -> bool:
    manifest = read_json(root / manifest_relative)
    ledger = bytearray()
    for row in sorted(manifest["files"], key=lambda value: value["path"]):
        member = root / row["path"]
        if not member.is_file() or member.is_symlink() or sha(member) != row["sha256"]:
            return False
        ledger.extend(f"{row['sha256']}  {row['path']}\n".encode())
    actual = hashlib.sha256(ledger).hexdigest()
    return actual == manifest["source_tree_sha256"] == expected


def governance_root(path: Path) -> str:
    rows = []
    for member in sorted(path.iterdir(), key=lambda value: value.name):
        if member.is_file() and not member.is_symlink() and member.name != "GOVERNANCE_LOCK.json":
            rows.append(f"{sha(member)}  {member.name}")
    return hashlib.sha256(("\n".join(rows) + "\n").encode()).hexdigest()


def independently_accept_os_type(output: str, exit_code: int) -> bool:
    if exit_code != 0:
        return False
    found = []
    for raw in output.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if not raw:
            continue
        prefix = "ID / Description: "
        if raw.startswith(prefix):
            body = raw[len(prefix):]
            if " -- " not in body:
                return False
            identifier, description = body.split(" -- ", 1)
            if not identifier or not description or any(not (ch.isascii() and (ch.isalnum() or ch == "_")) for ch in identifier):
                return False
            found.append(identifier)
        elif raw.startswith("ID"):
            return False
    return found == ["Ubuntu_64"] or (found.count("Ubuntu_64") == 1 and len(found) > 1)


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


protocol = read_json(ROOT / "RECOVERY_GATE_PROTOCOL.json")
preflight = read_json(ROOT / "PREFLIGHT_RESULT.json")
binding = read_json(ROOT / "EVIDENCE_BINDING.json")
review = read_json(ROOT / "PARTIAL_FAILURE_REVIEW.json")
root_cause = read_json(ROOT / "ROOT_CAUSE_ANALYSIS.json")
repair = read_json(ROOT / "RUNNER_REPAIR_SPEC.json")
provenance = read_json(ROOT / "EXECUTION_PROVENANCE_ASSESSMENT.json")
matrix = read_json(ROOT / "RECOVERY_OPERATION_MATRIX.json")
guards = read_json(ROOT / "PRE_EXECUTION_GUARDS.json")
risks = read_json(ROOT / "RISK_REGISTER.json")
decision = read_json(ROOT / "RECOVERY_DECISION.json")
authorization = read_json(ROOT / "RECOVERY_AUTHORIZATION.json")

check("identity", protocol["gate_id"] == decision["gate_id"] == IDENTITY)
check("governance_only", protocol["task_class"] == "GOVERNANCE_ONLY" and protocol["automatic_execution"] is False)
check("preflight", preflight["status"] == "PASS")
check("v01_lock", sha(Path("/home/nobcoder/codex-security-harness-eval/governance/v0.1-foundation-freeze-snapshot-20261009/SNAPSHOT_LOCK.json")) == "66ef07d8fa5336ccba83a4d41db42c788e01d455ed4cdc492f4365d51387dbaa")
check("source_roots", all(source_root_ok(*entry) for entry in BASELINES))
check("v3_lock", sha(V3 / "GOVERNANCE_LOCK.json") == "84a3a4daa6f9375ec8c02161aca38066530fd252fdfbd16ae4f25c675e39919f")
check("v3_manifest", sha(V3 / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "2745d1f8144b792e1bb38121324464164c08e6c5d57df1cfb504f706d2065e99")
check("v3_root", governance_root(V3) == "f4442097e2032e1ee12d27b967e19faddad95c7c475bcdc8d88214cb1a9a446f")
check("v3_readonly", not any(member.stat().st_mode & 0o222 for member in V3.rglob("*") if not member.is_symlink()))

expected = {row["name"]: row["sha256"] for row in binding["files"]}
check("six_evidence_rows", len(expected) == binding["file_count"] == 6)
for name, digest in expected.items():
    check(f"hash_{name}", sha(EVIDENCE / name) == digest)

a0 = read_json(EVIDENCE / "A0_PREFLIGHT_RECORD.json")
a1 = read_json(EVIDENCE / "A1_ACQUISITION_RECORD.json")
a2 = read_json(EVIDENCE / "A2_ACQUISITION_RECORD.json")
failure = read_json(EVIDENCE / "FAILURE-V3-A1-A5-20261010T133016Z-894c6da4cf0647adb217fd482b92b611.json")
state = read_json(EVIDENCE / "PARTIAL_STATE.json")
otypes = (EVIDENCE / "VBOX_UBUNTU_OSTYPES.txt").read_text(encoding="utf-8-sig")

check("run_id", len({a0["run_id"], a1["run_id"], a2["run_id"], failure["run_id"], binding["v3_run_id"]}) == 1)
check("executed_r3", a0["script_sha256"] == a1["script_sha256"] == "d9ac56cf5df6576272c2d692c4b0c191cae4563645d35dacbf7ea07dadb55285")
check("non_elevated", a0["elevated_powershell"] is False)
check("exact_host", a0["host_alias"] == "lab-host-01" and a0["virtualbox_version"] == "7.2.16r174877")
check("a1_exact_urls", a1["checksum_download"]["Url"] == a1["checksum_download"]["FinalUrl"] == "https://releases.ubuntu.com/24.04/SHA256SUMS" and a1["iso_download"]["Url"] == a1["iso_download"]["FinalUrl"] == "https://releases.ubuntu.com/24.04/ubuntu-24.04.5-live-server-amd64.iso")
check("a1_complete", a1["checksum_download"]["HttpStatus"] == 200 and a1["iso_download"]["HttpStatus"] == 200 and a1["iso_download"]["DownloadedBytes"] == 4080486400)
check("a2_three_way", a2["verified"] is True and len({a2["expected_sha256"], a2["published_sha256"], a2["actual_sha256"]}) == 1 and a2["actual_sha256"] == "97f3d7ffb032c3eb3b23d2c8be9cc76e60c2c1f2c0146ba5ba9fe01cafae0fd8")
check("a2_atomic_readonly", a2["atomic_acceptance_rename"] is True and a2["accepted_file_read_only"] is True)
check("a3_terminal_guard", failure["failed_phase"] == "A3_POWERED_OFF_VM_DEFINITION" and failure["disposition"] == "STOP_QUARANTINE_NO_RETRY_NO_CLEANUP")
check("no_vm", state["target_vm_registry_matches"] == 0 and state["vm_directory_exists"] is False)
check("operation_state", [state[x] for x in ("a1", "a2", "a3", "a4", "a5")] == ["PASS", "PASS", "NOT_EXECUTED_GUARD_DEFECT", "NOT_STARTED", "NOT_STARTED"])

r3_path = Path("/home/nobcoder/i4b-v3-powered-off-provisioning-a1-a5-r3.ps1")
r3_text = r3_path.read_text(encoding="utf-8")
check("r3_local_hash", sha(r3_path) == a0["script_sha256"])
check("guard_precedes_mutation", r3_text.find("$OsTypes.Text -notmatch") >= 0 and r3_text.find("$OsTypes.Text -notmatch") < r3_text.find('"createvm",'))
check("root_classification", root_cause["classification"] == "OS_TYPE_GUARD_OUTPUT_FORMAT_MISMATCH")
check("actual_output_accepts", independently_accept_os_type(otypes, 0))
check("missing_rejects", not independently_accept_os_type("ID / Description: Debian_64 -- Debian\n", 0))
check("legacy_rejects", not independently_accept_os_type("ID: Ubuntu_64\n", 0))
check("substring_rejects", not independently_accept_os_type("ID / Description: EvilUbuntu_64 -- bad\n", 0))
check("duplicate_rejects", not independently_accept_os_type("ID / Description: Ubuntu_64 -- one\nID / Description: Ubuntu_64 -- two\n", 0))
check("alternate_rejects", not independently_accept_os_type("ID / Description: Ubuntu24_LTS_64 -- Noble\n", 0))
check("nonzero_rejects", not independently_accept_os_type("ID / Description: Ubuntu_64 -- Ubuntu\n", 2))
check("repair_exact_id", repair["parser_contract"]["authorized_exact_identifier"] == "Ubuntu_64" and repair["parser_contract"]["required_exact_match_count"] == 1)
check("repair_no_runner", repair["future_runner"]["implementation_status"] == "NOT_CREATED_NOT_AUTHORIZED_BY_THIS_TASK" and repair["future_runner"]["digest_status"] == "NOT_ESTABLISHED")

decisions = {row["id"]: row["decision"] for row in matrix["operations"]}
check("no_a1_a2_replay", decisions["A1"] == decisions["A2"] == "DENIED_FINAL_NO_REPLAY")
check("only_a3_a5_conditional", [key for key, value in decisions.items() if value.startswith("GRANTED_")] == ["A3", "A4", "A5"])
check("runtime_denied", all(decisions[x] == "NOT_AUTHORIZED" for x in ("B1", "B2", "B3", "B4", "B5", "B6")))
check("authorization_conditional", authorization["status"] == "GRANTED_NOT_EXECUTABLE_PENDING_RUNNER_DIGEST_LOCK")
check("authorization_new_identity", authorization["validity"]["execution_identity"] == "NEW_SINGLE_USE_ID_REQUIRED_NOT_V3_RUN_ID")
check("authorization_terminal_failure", authorization["validity"]["partial_failure"].startswith("STOP_QUARANTINE_NO_RETRY_NO_CLEANUP"))
check("authorization_exact_resources", authorization["binding"]["vcpus"] == 4 and authorization["binding"]["memory_mib"] == 6144 and authorization["binding"]["virtual_disk_bytes_maximum"] == 68719476736 and authorization["binding"]["virtual_nics"] == 0)
check("authorization_iso_predecessor", authorization["predecessor_iso"]["use"] == "IMMUTABLE_PREDECESSOR_EVIDENCE_ONLY" and authorization["predecessor_iso"]["mount_attach_import_extract_execute"] == "NOT_AUTHORIZED")
check("future_runner_no_vbox", authorization["authorized_future_non_operational_step"]["may_execute_vboxmanage"] is False)
check("guard_completeness", guards["guard_count"] == len(guards["guards"]) == 14 and guards["all_required"] is True)
check("risk_completeness", risks["risk_count"] == len(risks["risks"]) == 16 and all(row["fail_closed"] for row in risks["risks"]))
check("provenance_limitation", provenance["status"] == "PASS_WITH_DECLARED_TRANSCRIPT_LIMITATION" and "transcript" in provenance["successful_invocation"]["limitation"])
check("no_persistent_policy_claim", provenance["successful_invocation"]["persistent_execution_policy_change_evidenced"] is False)
check("decision_not_runtime", decision["runtime_isolation"] == "NOT_EVALUATED" and decision["i4_b_execution"] == "NOT_GRANTED")
check("decision_no_later", decision["vm_boot"] == "NOT_AUTHORIZED" and decision["guest_installation"] == "NOT_AUTHORIZED" and decision["i5"] == "NOT_AUTHORIZED" and decision["v0_3"] == "NOT_OPENED")

for forbidden in ("RECOVERY_RUNNER.ps1", "VM_BOOT_AUTHORIZATION.json", "I4_B_AUTHORIZATION.json", "RUNTIME_RESULT.json"):
    check(f"absent_{forbidden}", not (ROOT / forbidden).exists())

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": IDENTITY,
    "validator": "independent_recovery_governance_validator_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
