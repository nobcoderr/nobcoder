#!/usr/bin/env python3
"""Build the governance-only V12 I006 canonicalization erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_INDEPENDENT_VALIDATOR_V11_TREE_"
    "CANONICALIZATION_MISMATCH_PRELOCK_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_"
    "GOVERNANCE_ONLY"
)
DECISION = "CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AUTHORIZED"
V11_ROOT = "6b41bc493b1876468de57cb82cb3b7de9bf811450f9579ee5e493473d75023ef"
ALT_ROOT = "3836d88bbae73ac793b62998c683293d800a9ca75f25eb1b23fd771b6a057f8a"
V12_PRE_ROOT = "1a6e3923eda4fd1ee1b18cce9d639bde4d20fcf97075c211ed1d5ff6a7a57780"
V11_LOCK_SHA = "3da68aa2f89327b30bbbd35eaa354b3701a5d395c06a5e9dd6bb96a72ec31b96"
V11_SELFTEST_SHA = "4565dc9cc0717a210324f646069b3e6ce10b6e954273059331ff2aede755c4c9"
ALLOWLIST = ["tests/run_unit_fixtures.py", "validators/independent_static_validate.py"]
APPEND_ONLY_SLOTS = [
    "results/prelock/unit-fixtures-run-0002.json",
    "results/prelock/primary-static-validation-run-0002.json",
    "results/prelock/independent-static-validation-run-0002.json",
]
RUN1_HASHES = {
    "results/prelock/unit-fixtures-run-0001.json": "b429af4eaff9403139ef41ba9145436ab4dac8778139d5b93f0e5ea632d3c36d",
    "results/prelock/primary-static-validation-run-0001.json": "81f3f6a449cf11dbc4faba8a070638fac2406e461d15e9753e89ba821d9e41ac",
    "results/prelock/independent-static-validation-run-0001.json": "56b1b6572dec7d83afbab91f427a336f7897db1fd5de94c2e3a14fee1a09346f",
}
MUTABLE_HASHES = {
    "tests/run_unit_fixtures.py": "1ba38aa7f024f549793dd28753c1af9135018d73e013c2d7c5326a442e0a3b48",
    "validators/independent_static_validate.py": "adfc0d0b12bc7cfad20bccd42946eb409fae5b387744002b4a536a1527c472d4",
}
SOURCE_FILES = {
    "build_governance.py", "validate_governance.py", "negative_fixtures.py",
    "independent_validate.py", "freeze_governance.py", "verify_governance_freeze.py",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_tree(path: Path) -> tuple[str, list[dict[str, Any]]]:
    members = []
    for item in sorted((p for p in path.rglob("*") if p.is_file()), key=lambda p: p.relative_to(path).as_posix()):
        members.append({"path": item.relative_to(path).as_posix(), "sha256": sha(item), "bytes": item.stat().st_size})
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    return hashlib.sha256(material.encode("utf-8")).hexdigest(), members


def alternate_tree(path: Path) -> str:
    rows = []
    for item in sorted((p for p in path.rglob("*") if p.is_file()), key=lambda p: p.relative_to(path).as_posix()):
        relative = item.relative_to(path).as_posix()
        rows.append(f"{relative}\0{sha(item)}\n")
    return hashlib.sha256("".join(rows).encode("utf-8")).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_prestate() -> list[dict[str, Any]]:
    v11_root, v11_members = canonical_tree(V11)
    if v11_root != V11_ROOT or len(v11_members) != 72:
        raise SystemExit("frozen V11 canonical tree drift")
    if alternate_tree(V11) != ALT_ROOT:
        raise SystemExit("independent-validator mismatch reproduction drift")
    if sha(V11 / "STATIC_EXECUTION_LOCK.json") != V11_LOCK_SHA:
        raise SystemExit("V11 static lock drift")
    if sha(V11 / "static-run-v11/observer-selftest-result-0001.json") != V11_SELFTEST_SHA:
        raise SystemExit("V11 observer self-test drift")
    v12_root, v12_members = canonical_tree(V12)
    if v12_root != V12_PRE_ROOT or len(v12_members) != 55:
        raise SystemExit("V12 pre-erratum tree drift")
    for relative, expected in {**RUN1_HASHES, **MUTABLE_HASHES}.items():
        if sha(V12 / relative) != expected:
            raise SystemExit(f"V12 bound member drift: {relative}")
    unit = load(V12 / "results/prelock/unit-fixtures-run-0001.json")
    primary = load(V12 / "results/prelock/primary-static-validation-run-0001.json")
    independent = load(V12 / "results/prelock/independent-static-validation-run-0001.json")
    if unit.get("status") != "PASS" or unit.get("validation_counts") != {"total": 77, "passed": 77, "failed": 0}:
        raise SystemExit("V12 unit evidence drift")
    if primary.get("status") != "PASS" or primary.get("validation_counts") != {"total": 95, "passed": 95, "failed": 0}:
        raise SystemExit("V12 primary evidence drift")
    if independent.get("status") != "FAIL_CLOSED" or independent.get("failure_ids") != ["I006_V11_TREE"]:
        raise SystemExit("V12 independent failure evidence drift")
    if independent.get("validation_counts") != {"total": 57, "passed": 56, "failed": 1}:
        raise SystemExit("V12 independent count drift")
    prohibited = [
        V12 / "STATIC_EXECUTION_LOCK.json", V12 / "STATIC_SOURCE_MANIFEST.json",
        V12 / "results/prelock/fresh-preflight-run-0001.json",
        V12 / "static-run-v12/ATTEMPT_MARKER.json", V12 / "static-run-v12/runtime-result-0001.json",
    ]
    if any(path.exists() or path.is_symlink() for path in prohibited):
        raise SystemExit("V12 advanced beyond authorized pre-lock state")
    return v12_members


def main() -> None:
    actual = {p.name for p in ROOT.iterdir() if p.is_file()}
    if actual != SOURCE_FILES or any(p.is_dir() or p.is_symlink() for p in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    v12_members = verify_prestate()
    protected = [row for row in v12_members if row["path"] not in ALLOWLIST]

    write("GOVERNANCE_CHARTER.json", {
        "record_type": "V12_I006_CANONICALIZATION_ERRATUM_GOVERNANCE_CHARTER",
        "scope": "GOVERNANCE_ONLY_READ_ONLY_V11_AND_V12_PRELOCK_EVIDENCE_ADJUDICATION",
        "authorized_actions": ["READ_FROZEN_EVIDENCE", "ADJUDICATE_I006", "DECIDE_CONTINUATION_OR_SUCCESSOR", "VALIDATE_AND_FREEZE_GOVERNANCE"],
        "prohibited_actions": ["PATCH_OR_RERUN_V12_VALIDATOR", "FRESH_PREFLIGHT", "STATIC_LOCK", "WORKER_OR_CODEX_INVOCATION", "CREATE_SUCCESSOR", "CREDENTIAL_TARGET_NETWORK_SUBAGENT_PARALLEL_EXPLOIT_CAPABILITY_PROMOTION_OR_SUBMISSION_OPERATION"],
    })
    write("V12_PRELOCK_EVIDENCE_BINDING.json", {
        "record_type": "V12_I006_PRELOCK_EXTERNAL_EVIDENCE_BINDING",
        "workspace": str(V12), "workspace_member_count": len(v12_members),
        "canonical_workspace_root_sha256": V12_PRE_ROOT,
        "historical_run_0001_sha256": RUN1_HASHES,
        "mutable_source_pre_erratum_sha256": MUTABLE_HASHES,
        "static_lock": "NOT_ISSUED", "attempt": "0_OF_1", "worker_invocation": "0_OF_1", "codex_as_worker_invocation": "0_OF_1",
        "fresh_preflight": "NOT_STARTED", "source_workspace_mutated_during_governance": False,
    })
    write("I006_CANONICALIZATION_ADJUDICATION.json", {
        "record_type": "V12_I006_V11_TREE_CANONICALIZATION_ADJUDICATION",
        "independent_validator_v11_tree_canonicalization_defect": "YES",
        "v11_predecessor_drift": "NO",
        "facts": {
            "normative_v11_tree_root_sha256": V11_ROOT,
            "independent_validator_observed_tree_root_sha256": ALT_ROOT,
            "normative_member_count": 72,
            "core_v12_predecessor_verification": "PASS",
            "v11_static_lock_sha256": V11_LOCK_SHA,
            "v11_observer_selftest_sha256": V11_SELFTEST_SHA,
        },
        "root_cause": "INDEPENDENT_VALIDATOR_USED_PATH_NUL_DIGEST_SERIALIZATION_INSTEAD_OF_NORMATIVE_DIGEST_TWO_SPACES_PATH_SERIALIZATION",
        "causal_history_beyond_frozen_evidence": "NOT_RECONSTRUCTED",
        "codex_worker_runtime_or_confinement_claim": "NOT_ESTABLISHED_OR_PROVEN",
    })
    write("V12_CONTINUATION_AUTHORIZATION_DECISION.json", {
        "record_type": "V12_CONTINUATION_OR_SUCCESSOR_DECISION",
        "decision": DECISION,
        "v12_state": "PRELOCK_FAIL_CLOSED_CONTINUATION_AUTHORIZED_VALIDATOR_CANONICALIZATION_ONLY",
        "v12_terminalized": False, "distinct_successor_authorized": False,
        "static_lock": "NOT_ISSUED", "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
        "execution_authorized_by_this_governance": False,
    })
    write("CONTINUATION_V12_SCOPE_LOCK.json", {
        "record_type": "CONTINUATION_V12_EXACT_MUTATION_SCOPE_LOCK",
        "source_mutation_allowlist": ALLOWLIST,
        "append_only_validation_output_allowlist": APPEND_ONLY_SLOTS,
        "historical_evidence_must_remain_immutable": list(RUN1_HASHES),
        "protected_domains": ["src/runner_v12.py", "src/topology_observer_v12.py", "contracts/**", "schemas/**", "contracts/WORKER_REQUEST.json", "fixture/worker-prompt.txt", "runtime-config-candidate/config.toml", "V11_PREDECESSOR_ARTIFACTS", "CODEX_RUNTIME_BINDING", "EXECUTION_SEMANTICS"],
        "all_unlisted_mutations": "PROHIBITED",
        "protected_member_count": len(protected),
        "protected_members_snapshot": "V12_PRE_ERRATUM_PROTECTED_MEMBER_SNAPSHOT.json",
    })
    write("V12_PRE_ERRATUM_PROTECTED_MEMBER_SNAPSHOT.json", {
        "record_type": "V12_PRE_ERRATUM_PROTECTED_MEMBER_SNAPSHOT",
        "workspace_root_before_continuation_sha256": V12_PRE_ROOT,
        "member_count": len(protected), "members": protected,
        "excluded_authorized_mutable_sources": ALLOWLIST,
    })
    write("CONTINUATION_V12_CANONICALIZATION_CONTRACT.json", {
        "record_type": "CONTINUATION_V12_I006_CANONICALIZATION_CONTRACT",
        "normative_member_set": "ALL_72_FROZEN_V11_REGULAR_FILES_SORTED_BY_EXACT_POSIX_RELATIVE_PATH_BYTES",
        "normative_member_row": "LOWERCASE_SHA256_HEX + TWO_ASCII_SPACES + EXACT_POSIX_RELATIVE_PATH + LF",
        "normative_tree_root": "SHA256_UTF8_CONCATENATION_OF_SORTED_MEMBER_ROWS",
        "independence_rule": "INDEPENDENT_VALIDATOR_MUST_REREAD_AND_REHASH_EVERY_MEMBER_AND_MUST_NOT_TRUST_CORE_V12_RESULT",
        "symlink_rule": "FROZEN_MEMBER_SET_CONTAINS_REGULAR_FILES_ONLY_AND_ANY_UNEXPECTED_SYMLINK_OR_MEMBER_FAILS_CLOSED",
        "mismatch_rule": "FAIL_CLOSED_BEFORE_FRESH_PREFLIGHT_STATIC_LOCK_AND_ATTEMPT",
        "post_correction_validation_order": ["UNIT_RUN_0002", "PRIMARY_RUN_0002", "INDEPENDENT_RUN_0002", "FRESH_PREFLIGHT_ONLY_AFTER_ALL_PASS"],
        "run_0002_semantics": "APPEND_ONLY_CURRENT_CONTINUATION_EVIDENCE_WITH_RUN_0001_RETAINED_IMMUTABLE",
    })
    write("CANONICALIZATION_REGRESSION_MATRIX.json", {
        "record_type": "V12_I006_CANONICALIZATION_REGRESSION_MATRIX",
        "cases": [
            {"id": "R001", "case": "exact_frozen_v11_member_set_and_normative_serialization", "expected": V11_ROOT},
            {"id": "R002", "case": "input_enumeration_permuted_but_normatively_sorted", "expected": V11_ROOT},
            {"id": "R003", "case": "exact_relative_path_representation_changed", "expected": "REJECT"},
            {"id": "R004", "case": "one_byte_member_mutation", "expected": "REJECT"},
            {"id": "R005", "case": "one_member_omitted", "expected": "REJECT"},
            {"id": "R006", "case": "one_extra_member", "expected": "REJECT"},
            {"id": "R007", "case": "alternate_path_nul_digest_serialization", "expected": "REJECT_WITH_OBSERVED_ROOT_" + ALT_ROOT},
            {"id": "R008", "case": "historical_run_0001_overwrite", "expected": "REJECT"},
            {"id": "R009", "case": "run_0002_without_full_unit_primary_independent_rerun", "expected": "REJECT"},
        ],
    })
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V12_I006_NEGATIVE_GOVERNANCE_TEST_MATRIX",
        "cases": [
            {"id": "N001", "mutation": "trust_core_v12_tree_result", "expected": "REJECT"},
            {"id": "N002", "mutation": "mutate_runner_observer_contract_prompt_request_runtime_or_predecessor", "expected": "REJECT"},
            {"id": "N003", "mutation": "overwrite_independent_run_0001", "expected": "REJECT"},
            {"id": "N004", "mutation": "continue_directly_to_fresh_preflight", "expected": "REJECT"},
            {"id": "N005", "mutation": "issue_static_lock_or_invoke_worker_or_codex", "expected": "REJECT"},
            {"id": "N006", "mutation": "infer_v11_drift_from_alternate_serialization", "expected": "REJECT"},
            {"id": "N007", "mutation": "allow_ambiguous_or_extra_current_validation_evidence", "expected": "REJECT"},
        ],
    })
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "V12_I006_AUTHORITY_NON_ESCALATION_DECISION",
        "implementation_authorized": "ONLY_EXACT_VALIDATOR_AND_TEST_CORRECTION_AFTER_GOVERNANCE_FREEZE",
        "execution_authorized_now": False,
        "operation_counters": {key: 0 for key in ["v12_patch_during_governance", "v12_validator_rerun", "fresh_preflight", "static_lock", "attempt", "worker_invocation", "codex_invocation", "credential", "target", "network", "subagent", "parallelism", "exploit_replay", "capability_graph", "promotion", "submission"]},
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "MANDATORY_AUTO_ROUTER_LEDGER",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness", "external-ai-security-tool-governor"],
        "deferred": ["program-impact-boundary-gate", "awesome-bugbounty-tools-catalog", "hermes-passive-evidence-review"],
        "not_applicable": ["live-target-testing", "recon", "exploit-execution", "credential-use", "subagents", "parallelism", "submission"],
        "external_tool_integration_state": "REFERENCE_ONLY_NO_EXTERNAL_OPERATION",
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V12_I006_NEXT_LEGAL_MILESTONE",
        "next_legal_milestone": "APPLY_CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AND_RERUN_FULL_PRELOCK_VALIDATION_CHAIN",
        "required_first_action": "MUTATE_ONLY_EXACT_SCOPE_LOCK_ALLOWLIST_AND_CREATE_APPEND_ONLY_RUN_0002_EVIDENCE",
        "fresh_preflight_allowed_only_after": "UNIT_PRIMARY_AND_INDEPENDENT_RUN_0002_ALL_PASS",
        "current_milestone_ceiling": "PASS_LOCKED_GOVERNANCE_ONLY",
    })


if __name__ == "__main__":
    main()
