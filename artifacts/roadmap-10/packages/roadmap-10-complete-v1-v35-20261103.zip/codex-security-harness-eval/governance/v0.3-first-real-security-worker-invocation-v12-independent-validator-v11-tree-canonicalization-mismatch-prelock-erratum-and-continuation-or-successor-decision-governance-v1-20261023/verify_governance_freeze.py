#!/usr/bin/env python3
"""Read-only verification of the frozen V12 I006 governance package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    failures = []
    lock = json.loads((ROOT / "GOVERNANCE_LOCK.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").read_text(encoding="utf-8"))
    if lock["status"] != "PASS_LOCKED_GOVERNANCE_ONLY": failures.append("lock_status")
    if sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") != lock["governance_manifest_sha256"]: failures.append("manifest_digest")
    material = ""
    for row in manifest["members"]:
        path = ROOT / row["path"]
        if not path.is_file() or sha(path) != row["sha256"]: failures.append("member:" + row["path"])
        material += f"{row['sha256']}  {row['path']}\n"
    if hashlib.sha256(material.encode("utf-8")).hexdigest() != manifest["canonical_governance_root_sha256"]: failures.append("governance_root")
    if any(path.stat().st_mode & 0o222 for path in ROOT.iterdir() if path.is_file()): failures.append("writable_member")
    final = json.loads((ROOT / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json").read_text(encoding="utf-8"))
    if final["status"] != "PASS" or final["checks_failed"] != 0: failures.append("final_freeze_verification")
    if sha(V12 / "results/prelock/independent-static-validation-run-0001.json") != "56b1b6572dec7d83afbab91f427a336f7897db1fd5de94c2e3a14fee1a09346f": failures.append("historical_run_0001")
    if (V12 / "STATIC_EXECUTION_LOCK.json").exists(): failures.append("v12_static_lock")
    if (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists(): failures.append("v12_attempt")
    print(json.dumps({"status": "PASS" if not failures else "FAIL_CLOSED", "checks_failed": len(failures), "failure_ids": failures}, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
