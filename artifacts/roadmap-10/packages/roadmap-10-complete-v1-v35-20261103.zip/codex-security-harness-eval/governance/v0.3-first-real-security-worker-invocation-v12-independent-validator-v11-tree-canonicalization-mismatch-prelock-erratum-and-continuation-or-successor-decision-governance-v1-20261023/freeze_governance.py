#!/usr/bin/env python3
"""Freeze V12 I006 governance after every governance gate passes."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_INDEPENDENT_VALIDATOR_V11_TREE_CANONICALIZATION_MISMATCH_PRELOCK_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AUTHORIZED"
V12_ROOT = "1a6e3923eda4fd1ee1b18cce9d639bde4d20fcf97075c211ed1d5ff6a7a57780"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload):
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True); handle.write("\n")


def tree_root(path: Path) -> tuple[str, int]:
    rows = []
    for item in sorted((p for p in path.rglob("*") if p.is_file()), key=lambda p: p.relative_to(path).as_posix()):
        rows.append(f"{sha(item)}  {item.relative_to(path).as_posix()}\n")
    return hashlib.sha256("".join(rows).encode("utf-8")).hexdigest(), len(rows)


def main() -> None:
    for name in ["GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"]:
        if (ROOT / name).exists():
            raise SystemExit("freeze artifact already exists")
    gates = [read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"), read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"), read("INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")]
    if any(gate["status"] != "PASS" or gate["checks_failed"] for gate in gates):
        raise SystemExit("governance validation gate failed")
    root, count = tree_root(V12)
    checks = {
        "primary_governance_validation": gates[0]["status"] == "PASS",
        "negative_governance_fixtures": gates[1]["status"] == "PASS",
        "independent_governance_validation": gates[2]["status"] == "PASS",
        "v12_pre_erratum_tree_unchanged": root == V12_ROOT and count == 55,
        "historical_independent_run_0001_immutable": sha(V12 / "results/prelock/independent-static-validation-run-0001.json") == "56b1b6572dec7d83afbab91f427a336f7897db1fd5de94c2e3a14fee1a09346f",
        "static_lock_absent": not (V12 / "STATIC_EXECUTION_LOCK.json").exists(),
        "fresh_preflight_absent": not (V12 / "results/prelock/fresh-preflight-run-0001.json").exists(),
        "attempt_absent": not (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists(),
        "runtime_absent": not (V12 / "static-run-v12/runtime-result-0001.json").exists(),
    }
    if not all(checks.values()):
        raise SystemExit("final freeze verification failed")
    write("FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json", {"record_type": "FINAL_FREEZE_VERIFICATION_RESULT", "run_id": "RUN-0001", "status": "PASS", "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0, "checks": [{"check_id": key, "status": "PASS"} for key in checks]})
    excluded = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    members = [{"path": p.name, "sha256": sha(p), "bytes": p.stat().st_size} for p in sorted((x for x in ROOT.iterdir() if x.is_file() and x.name not in excluded), key=lambda x: x.name)]
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    governance_root = hashlib.sha256(material.encode("utf-8")).hexdigest()
    write("GOVERNANCE_ARTIFACT_MANIFEST.json", {"record_type": "GOVERNANCE_ARTIFACT_MANIFEST", "member_count": len(members), "members": members, "canonical_governance_root_sha256": governance_root})
    write("GOVERNANCE_LOCK.json", {
        "record_type": "GOVERNANCE_LOCK", "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "v12_state": "PRELOCK_FAIL_CLOSED_CONTINUATION_AUTHORIZED_VALIDATOR_CANONICALIZATION_ONLY",
        "v12_static_lock": "NOT_ISSUED", "v12_attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
        "historical_independent_run_0001": "IMMUTABLE_FAILURE_EVIDENCE",
        "continuation_validation_evidence": "MUST_USE_APPEND_ONLY_RUN_0002_SLOTS",
        "governance_manifest_sha256": sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "canonical_governance_root_sha256": governance_root,
        "next_legal_milestone": "APPLY_CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AND_RERUN_FULL_PRELOCK_VALIDATION_CHAIN",
    })
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)


if __name__ == "__main__":
    main()
