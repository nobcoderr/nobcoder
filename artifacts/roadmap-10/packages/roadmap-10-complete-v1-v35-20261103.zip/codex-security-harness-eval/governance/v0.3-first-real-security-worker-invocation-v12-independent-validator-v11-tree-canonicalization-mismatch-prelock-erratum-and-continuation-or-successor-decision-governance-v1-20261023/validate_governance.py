#!/usr/bin/env python3
"""Primary validation for the V12 I006 governance erratum."""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_INDEPENDENT_VALIDATOR_V11_TREE_CANONICALIZATION_MISMATCH_PRELOCK_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DOCS = {
    "GOVERNANCE_CHARTER.json", "V12_PRELOCK_EVIDENCE_BINDING.json", "I006_CANONICALIZATION_ADJUDICATION.json",
    "V12_CONTINUATION_AUTHORIZATION_DECISION.json", "CONTINUATION_V12_SCOPE_LOCK.json",
    "V12_PRE_ERRATUM_PROTECTED_MEMBER_SNAPSHOT.json", "CONTINUATION_V12_CANONICALIZATION_CONTRACT.json",
    "CANONICALIZATION_REGRESSION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "ROUTING_LEDGER.json", "NEXT_LEGAL_MILESTONE.json",
}


def read(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    checks = []
    def check(check_id: str, ok: bool, evidence=None):
        checks.append({"check_id": check_id, "status": "PASS" if ok else "FAIL", "evidence": evidence})

    check("P001_DOC_SET", {p.name for p in ROOT.glob("*.json")} == DOCS)
    docs = {name: read(name) for name in DOCS}
    check("P002_IDENTITY", all(doc.get("governance_identity") == IDENTITY for doc in docs.values()))
    for script in sorted(ROOT.glob("*.py")):
        try:
            ast.parse(script.read_text(encoding="utf-8")); ok = True
        except SyntaxError:
            ok = False
        check("P_SCRIPT_" + script.name, ok)
    binding = docs["V12_PRELOCK_EVIDENCE_BINDING.json"]
    check("P010_PRELOCK", binding["static_lock"] == "NOT_ISSUED" and binding["attempt"] == binding["worker_invocation"] == binding["codex_as_worker_invocation"] == "0_OF_1")
    check("P011_HISTORICAL_HASHES", all(sha(V12 / path) == expected for path, expected in binding["historical_run_0001_sha256"].items()))
    check("P012_NO_ADVANCE", not any(path.exists() for path in [V12 / "STATIC_EXECUTION_LOCK.json", V12 / "results/prelock/fresh-preflight-run-0001.json", V12 / "static-run-v12/ATTEMPT_MARKER.json", V12 / "static-run-v12/runtime-result-0001.json"]))
    adjudication = docs["I006_CANONICALIZATION_ADJUDICATION.json"]
    check("P020_DEFECT_YES", adjudication["independent_validator_v11_tree_canonicalization_defect"] == "YES")
    check("P021_NO_DRIFT", adjudication["v11_predecessor_drift"] == "NO" and adjudication["facts"]["core_v12_predecessor_verification"] == "PASS")
    check("P022_V11_LOCK", sha(V11 / "STATIC_EXECUTION_LOCK.json") == adjudication["facts"]["v11_static_lock_sha256"])
    check("P023_V11_SELFTEST", sha(V11 / "static-run-v11/observer-selftest-result-0001.json") == adjudication["facts"]["v11_observer_selftest_sha256"])
    decision = docs["V12_CONTINUATION_AUTHORIZATION_DECISION.json"]
    check("P030_DECISION", decision["decision"] == "CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AUTHORIZED" and not decision["distinct_successor_authorized"])
    scope = docs["CONTINUATION_V12_SCOPE_LOCK.json"]
    check("P031_EXACT_ALLOWLIST", scope["source_mutation_allowlist"] == ["tests/run_unit_fixtures.py", "validators/independent_static_validate.py"])
    check("P032_APPEND_ONLY_SLOTS", scope["append_only_validation_output_allowlist"] == ["results/prelock/unit-fixtures-run-0002.json", "results/prelock/primary-static-validation-run-0002.json", "results/prelock/independent-static-validation-run-0002.json"])
    snapshot = docs["V12_PRE_ERRATUM_PROTECTED_MEMBER_SNAPSHOT.json"]
    check("P033_PROTECTED_COUNT", snapshot["member_count"] == 53 and len(snapshot["members"]) == 53)
    check("P034_PROTECTED_INTACT", all(sha(V12 / row["path"]) == row["sha256"] for row in snapshot["members"]))
    contract = docs["CONTINUATION_V12_CANONICALIZATION_CONTRACT.json"]
    check("P040_NORMATIVE_ROW", contract["normative_member_row"] == "LOWERCASE_SHA256_HEX + TWO_ASCII_SPACES + EXACT_POSIX_RELATIVE_PATH + LF")
    check("P041_INDEPENDENT", "MUST_NOT_TRUST_CORE_V12_RESULT" in contract["independence_rule"])
    check("P042_FULL_RERUN", contract["post_correction_validation_order"] == ["UNIT_RUN_0002", "PRIMARY_RUN_0002", "INDEPENDENT_RUN_0002", "FRESH_PREFLIGHT_ONLY_AFTER_ALL_PASS"])
    matrix = docs["CANONICALIZATION_REGRESSION_MATRIX.json"]["cases"]
    check("P050_REGRESSIONS", [row["id"] for row in matrix] == [f"R{i:03d}" for i in range(1, 10)])
    auth = docs["AUTHORITY_NON_ESCALATION_DECISION.json"]
    check("P060_COUNTERS_ZERO", all(value == 0 for value in auth["operation_counters"].values()))
    failures = [row for row in checks if row["status"] != "PASS"]
    result = {"governance_identity": IDENTITY, "record_type": "PRIMARY_GOVERNANCE_VALIDATION_RESULT", "run_id": "RUN-0001", "status": "PASS" if not failures else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": len(checks)-len(failures), "checks_failed": len(failures), "failure_ids": [row["check_id"] for row in failures], "checks": checks}
    with (ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True); handle.write("\n")
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
