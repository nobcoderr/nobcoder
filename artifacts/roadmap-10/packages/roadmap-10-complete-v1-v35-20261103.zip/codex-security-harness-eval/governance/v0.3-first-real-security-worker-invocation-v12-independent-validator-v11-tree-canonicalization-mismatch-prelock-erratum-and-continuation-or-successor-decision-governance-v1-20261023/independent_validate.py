#!/usr/bin/env python3
"""Independent governance validation for the V12 I006 erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
V12 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v12-20261023")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_INDEPENDENT_VALIDATOR_V11_TREE_CANONICALIZATION_MISMATCH_PRELOCK_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
EXPECTED = "6b41bc493b1876468de57cb82cb3b7de9bf811450f9579ee5e493473d75023ef"
ALTERNATE = "3836d88bbae73ac793b62998c683293d800a9ca75f25eb1b23fd771b6a057f8a"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def recompute() -> tuple[str, str, int]:
    entries = []
    for item in V11.rglob("*"):
        if item.is_symlink():
            raise SystemExit("unexpected V11 symlink")
        if item.is_file():
            entries.append((item.relative_to(V11).as_posix(), sha(item)))
    entries.sort(key=lambda row: row[0])
    normative = hashlib.sha256("".join(f"{digest}  {path}\n" for path, digest in entries).encode("utf-8")).hexdigest()
    alternate = hashlib.sha256("".join(f"{path}\0{digest}\n" for path, digest in entries).encode("utf-8")).hexdigest()
    return normative, alternate, len(entries)


def main() -> None:
    checks = []
    def check(check_id: str, ok: bool, evidence=None):
        checks.append({"check_id": check_id, "status": "PASS" if ok else "FAIL", "evidence": evidence})

    primary = read("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I001_PRIMARY", primary["status"] == "PASS" and primary["checks_failed"] == 0)
    check("I002_NEGATIVE", negative["status"] == "PASS" and negative["checks_failed"] == 0)
    normative, alternate, count = recompute()
    check("I003_V11_NORMATIVE_ROOT", normative == EXPECTED and count == 72, {"root": normative, "members": count})
    check("I004_ALTERNATE_REPRODUCTION", alternate == ALTERNATE, alternate)
    check("I005_V11_LOCK", sha(V11 / "STATIC_EXECUTION_LOCK.json") == "3da68aa2f89327b30bbbd35eaa354b3701a5d395c06a5e9dd6bb96a72ec31b96")
    check("I006_V11_SELFTEST", sha(V11 / "static-run-v11/observer-selftest-result-0001.json") == "4565dc9cc0717a210324f646069b3e6ce10b6e954273059331ff2aede755c4c9")
    old = json.loads((V12 / "results/prelock/independent-static-validation-run-0001.json").read_text(encoding="utf-8"))
    check("I007_RUN1_IMMUTABLE_FAILURE", sha(V12 / "results/prelock/independent-static-validation-run-0001.json") == "56b1b6572dec7d83afbab91f427a336f7897db1fd5de94c2e3a14fee1a09346f" and old["failure_ids"] == ["I006_V11_TREE"])
    adjudication = read("I006_CANONICALIZATION_ADJUDICATION.json")
    check("I008_OWNERSHIP", adjudication["independent_validator_v11_tree_canonicalization_defect"] == "YES" and adjudication["v11_predecessor_drift"] == "NO")
    decision = read("V12_CONTINUATION_AUTHORIZATION_DECISION.json")
    check("I009_CONTINUATION", decision["decision"] == "CONTINUATION_V12_INDEPENDENT_VALIDATOR_CANONICALIZATION_ONLY_CORRECTION_AUTHORIZED" and not decision["execution_authorized_by_this_governance"])
    scope = read("CONTINUATION_V12_SCOPE_LOCK.json")
    check("I010_MINIMAL_SCOPE", set(scope["source_mutation_allowlist"]) == {"validators/independent_static_validate.py", "tests/run_unit_fixtures.py"})
    check("I011_PROTECTED_DOMAINS", {"src/runner_v12.py", "src/topology_observer_v12.py", "contracts/**", "schemas/**", "contracts/WORKER_REQUEST.json", "fixture/worker-prompt.txt", "runtime-config-candidate/config.toml", "V11_PREDECESSOR_ARTIFACTS", "CODEX_RUNTIME_BINDING", "EXECUTION_SEMANTICS"}.issubset(scope["protected_domains"]))
    contract = read("CONTINUATION_V12_CANONICALIZATION_CONTRACT.json")
    check("I012_CANONICAL_RULE", contract["normative_member_row"].startswith("LOWERCASE_SHA256_HEX") and "TWO_ASCII_SPACES" in contract["normative_member_row"])
    check("I013_FULL_RERUN", contract["post_correction_validation_order"][:3] == ["UNIT_RUN_0002", "PRIMARY_RUN_0002", "INDEPENDENT_RUN_0002"])
    auth = read("AUTHORITY_NON_ESCALATION_DECISION.json")
    check("I014_ZERO_OPERATIONS", all(value == 0 for value in auth["operation_counters"].values()))
    check("I015_NO_STATIC_LOCK", not (V12 / "STATIC_EXECUTION_LOCK.json").exists())
    check("I016_NO_ATTEMPT", not (V12 / "static-run-v12/ATTEMPT_MARKER.json").exists())
    failed = [row for row in checks if row["status"] != "PASS"]
    result = {"governance_identity": IDENTITY, "record_type": "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT", "run_id": "RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed), "failure_ids": [row["check_id"] for row in failed], "checks": checks}
    with (ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True); handle.write("\n")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
