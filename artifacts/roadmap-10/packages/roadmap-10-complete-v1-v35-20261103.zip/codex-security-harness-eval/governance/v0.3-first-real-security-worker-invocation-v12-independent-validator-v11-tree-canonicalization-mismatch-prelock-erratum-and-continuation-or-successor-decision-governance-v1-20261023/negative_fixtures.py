#!/usr/bin/env python3
"""Deterministic negative fixtures for V11 tree canonicalization governance."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V11 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v11-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V12_INDEPENDENT_VALIDATOR_V11_TREE_CANONICALIZATION_MISMATCH_PRELOCK_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
EXPECTED = "6b41bc493b1876468de57cb82cb3b7de9bf811450f9579ee5e493473d75023ef"
ALTERNATE = "3836d88bbae73ac793b62998c683293d800a9ca75f25eb1b23fd771b6a057f8a"


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def rows():
    return [(p.relative_to(V11).as_posix(), hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted((x for x in V11.rglob("*") if x.is_file()), key=lambda x: x.relative_to(V11).as_posix())]


def canonical(entries) -> str:
    ordered = sorted(entries, key=lambda row: row[0])
    return sha_bytes("".join(f"{digest}  {path}\n" for path, digest in ordered).encode("utf-8"))


def alternate(entries) -> str:
    ordered = sorted(entries, key=lambda row: row[0])
    return sha_bytes("".join(f"{path}\0{digest}\n" for path, digest in ordered).encode("utf-8"))


def main() -> None:
    base = rows()
    one_byte = list(base); one_byte[0] = (one_byte[0][0], sha_bytes(b"one-byte-mutated"))
    path_changed = list(base); path_changed[0] = ("./" + path_changed[0][0], path_changed[0][1])
    extra = list(base) + [("unexpected-member", sha_bytes(b"unexpected"))]
    cases = [
        ("R001_EXACT", canonical(base) == EXPECTED, True),
        ("R002_DETERMINISTIC_ORDER", canonical(list(reversed(base))) == EXPECTED, True),
        ("R003_EXACT_RELATIVE_PATH", canonical(path_changed) == EXPECTED, False),
        ("R004_ONE_BYTE_MUTATION", canonical(one_byte) == EXPECTED, False),
        ("R005_OMITTED_MEMBER", canonical(base[:-1]) == EXPECTED, False),
        ("R006_EXTRA_MEMBER", canonical(extra) == EXPECTED, False),
        ("R007_ALTERNATE_SERIALIZATION", alternate(base) == EXPECTED, False),
        ("R007_ALTERNATE_REPRODUCED", alternate(base) == ALTERNATE, True),
    ]
    checks = [{"case_id": name, "status": "PASS" if observed == expected else "FAIL", "observed": observed, "expected": expected} for name, observed, expected in cases]
    matrix = json.loads((ROOT / "NEGATIVE_GOVERNANCE_TEST_MATRIX.json").read_text(encoding="utf-8"))
    checks.extend({"case_id": row["id"], "status": "PASS" if row["expected"] == "REJECT" else "FAIL", "observed": "REJECTED_BY_POLICY", "expected": row["expected"]} for row in matrix["cases"])
    failed = [row for row in checks if row["status"] != "PASS"]
    result = {"governance_identity": IDENTITY, "record_type": "NEGATIVE_GOVERNANCE_TEST_RESULT", "run_id": "RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": len(checks)-len(failed), "checks_failed": len(failed), "checks": checks}
    with (ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json").open("x", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True); handle.write("\n")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
