#!/usr/bin/env python3
"""Final freeze verification and immutable lock issuance for the V6 erratum."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
V7 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v7-20261020")
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v5-runtime-identity-unavailable-and-noncandidate-invocation-deviation-prelock-erratum-and-successor-decision-governance-v1-20261020")
CODEX_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl/bin/codex")
CODEX_PACKAGE = CODEX_BINARY.parent.parent / "codex-package.json"

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6_STATIC_LOCK_MEMBER_SET_INCOMPLETE_AND_WRITABLE_VALIDATOR_SCHEMA_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_CONDITIONALLY"
V7_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V7"
V7_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V8"
RUNTIME = "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL"
V6_ROOT = "6b7df42eb8b82adea4d3a9829874426de15e28358acd27191415f6ca5d84ea56"
BINARY_SHA = "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215"
PACKAGE_SHA = "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78"
CONFIG_SHA = "7ae835188ef2ab3221e15effac45375b2d6112954d022aa7776f802f7b8697c0"
PRED_LOCK_SHA = "e5ba9964c42be8d91811237a27fedb228bb603c28c66151be446a8f762db1194"
PRED_MANIFEST_SHA = "9571cfe1c61e7b0a0899cad1c5389c330de6a22a1780e829e2accd1f2304e62a"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V6_FROZEN_EVIDENCE_BINDING.json", "V6_TERMINAL_DISPOSITION.json", "STATIC_LOCK_COVERAGE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_ADJUDICATION.json", "NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT.json",
    "SUCCESSOR_V7_REQUIREMENTS.json", "SUCCESSOR_V7_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree_root(path: Path) -> str:
    rows = [f"{sha(member)}  {member.relative_to(path).as_posix()}\n" for member in sorted(item for item in path.rglob("*") if item.is_file())]
    return hashlib.sha256("".join(rows).encode()).hexdigest()


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def write_exclusive(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"finalizer input file-set mismatch: {sorted(actual)}")
    if V7.exists() or V7.is_symlink():
        raise SystemExit("V7 was created during governance-only milestone")

    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("F001_EXACT_INPUT_SET", actual == expected)
    check("F002_V6_ROOT", tree_root(V6) == V6_ROOT, tree_root(V6))
    check("F003_V7_ABSENT", not V7.exists() and not V7.is_symlink())
    check("F004_PREDECESSOR_LOCK", sha(PRED / "GOVERNANCE_LOCK.json") == PRED_LOCK_SHA)
    check("F005_PREDECESSOR_MANIFEST", sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == PRED_MANIFEST_SHA)
    check("F006_BINARY_SHA", sha(CODEX_BINARY) == BINARY_SHA)
    check("F007_PACKAGE_SHA", sha(CODEX_PACKAGE) == PACKAGE_SHA)
    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SYNTAX_" + script, valid)

    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = read(ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F012_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("F013_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == 24 and negative.get("tests_failed") == 0)
    check("F014_INDEPENDENT_PASS", independent.get("status") == "PASS" and independent.get("checks_failed") == 0)
    check("F015_RESULT_IDENTITIES", all(item.get("governance_identity") == IDENTITY for item in (primary, negative, independent)))

    terminal = read(ROOT / "V6_TERMINAL_DISPOSITION.json")
    coverage = read(ROOT / "STATIC_LOCK_COVERAGE_ADJUDICATION.json")
    ownership = read(ROOT / "DEFECT_OWNERSHIP_ADJUDICATION.json")
    closure = read(ROOT / "NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT.json")
    successor = read(ROOT / "SUCCESSOR_V7_AUTHORIZATION_DECISION.json")
    requirements = read(ROOT / "SUCCESSOR_V7_REQUIREMENTS.json")
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    summary = read(ROOT / "GOVERNANCE_DECISION_SUMMARY.json")
    check("F016_V6_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_PRE_ATTEMPT_REFERENCE_PREDECESSOR")
    check("F017_V6_NO_REUSE", all(terminal.get(key) == "PROHIBITED" for key in ("patch", "relock", "continuation", "runtime_invocation")))
    check("F018_V6_COUNTS_ZERO", terminal.get("attempt") == "0_OF_1_NOT_CONSUMED" and terminal.get("codex_0_163_0_invocation_count") == 0)
    check("F019_COVERAGE_TRIPLE", coverage.get("static_lock_member_set_incomplete") == "YES" and coverage.get("lock_verification_coverage_incomplete") == "YES" and coverage.get("writable_validator_dependency_outside_lock") == "YES")
    check("F020_72_NOT_PROMOTABLE", coverage.get("recorded_lock_promotable_to_valid_lock") is False)
    check("F021_DEFECT_OWNERSHIP", ownership.get("static_lock_closure_construction_defect") == "YES" and ownership.get("static_lock_verifier_coverage_defect") == "YES")
    zeros = closure.get("mandatory_zero_counters_before_attempt", {})
    check("F022_FOUR_ZERO_GATES", len(zeros) == 4 and all(value == 0 for value in zeros.values()))
    check("F023_SUCCESSOR_DECISION", successor.get("decision") == DECISION)
    check("F024_V7_IDENTITIES", successor.get("successor_execution_identity") == V7_EXECUTION and successor.get("successor_suite_identity") == V7_SUITE)
    check("F025_V7_RUNTIME", successor.get("successor_runtime_identity") == RUNTIME and successor.get("exact_runtime_identity_reauthorized") is True)
    check("F026_V7_ZERO_ONE", successor.get("attempt_count") == 0 and successor.get("attempt_limit") == 1 and successor.get("codex_0_163_0_invocation_count") == 0 and successor.get("codex_0_163_0_invocation_limit") == 1)
    binding = requirements.get("runtime_binding", {})
    check("F027_RUNTIME_BINDING", binding.get("binary_sha256") == BINARY_SHA and binding.get("package_sha256") == PACKAGE_SHA and binding.get("config_sha256") == CONFIG_SHA)
    check("F028_REAUTH_SCOPE", binding.get("reauthorization") == "EXPLICIT_FOR_COMPATIBILITY_EXECUTION_V7_ONLY")
    counters = authority.get("governance_operation_counters", {})
    check("F029_OPERATION_COUNTERS_ZERO", len(counters) == 15 and all(value == 0 for value in counters.values()))
    escalations = [key for key, value in authority.items() if key.endswith("_authorized") and value is not False]
    check("F030_NO_AUTHORITY_ESCALATION", not escalations, escalations)
    check("F031_NO_COMPATIBILITY_PROMOTION", summary.get("compatibility") == "NOT_ESTABLISHED")
    check("F032_NO_CONFINEMENT_PROMOTION", summary.get("confinement") == "NOT_PROVEN")

    failed = [row for row in checks if row["status"] == "FAIL"]
    if failed:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failed))

    write_exclusive(FREEZE, {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_LOCK_CLOSURE_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT",
        "schema_version": "1.0", "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001", "status": "PASS",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "v6_canonical_tree_root_sha256": V6_ROOT, "v7_absent": True,
        "operation_counters": counters,
    })

    manifest_names = sorted(expected | {FREEZE})
    rows = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in manifest_names]
    artifact_root = canonical_root(rows)
    write_exclusive(MANIFEST, {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_LOCK_CLOSURE_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "member_count": len(rows), "members": rows,
        "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    write_exclusive(LOCK, {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_LOCK_CLOSURE_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0", "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "v6_disposition": "FAIL_CLOSED_PRE_ATTEMPT_REFERENCE_PREDECESSOR",
        "v6_attempt": "0_OF_1_NOT_CONSUMED", "v6_codex_0_163_0_invocation_count": 0,
        "v6_static_lock": "ISSUED_BUT_NOT_ACCEPTABLE", "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "static_lock_member_set_incomplete": "YES", "lock_verification_coverage_incomplete": "YES",
        "writable_validator_dependency_outside_lock": "YES",
        "v7_execution_identity": V7_EXECUTION, "v7_suite_identity": V7_SUITE, "v7_runtime_identity": RUNTIME,
        "v7_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "exact_codex_0_163_0_identity_reauthorized": True, "v7_attempt_count": 0, "v7_attempt_limit": 1,
        "v7_codex_invocation_count": 0, "v7_codex_invocation_limit": 1,
        "mandatory_prelock_zero_counters": zeros,
        "validation": {
            "primary": {"passed": primary["checks_passed"], "total": primary["checks_total"], "status": primary["status"]},
            "negative": {"passed": negative["tests_passed"], "total": negative["tests_total"], "status": negative["status"]},
            "independent": {"passed": independent["checks_passed"], "total": independent["checks_total"], "status": independent["status"]},
            "final_freeze": {"passed": len(checks), "total": len(checks), "status": "PASS"},
        },
        "predecessor_lock_sha256": PRED_LOCK_SHA, "predecessor_manifest_sha256": PRED_MANIFEST_SHA,
        "v6_canonical_tree_root_sha256": V6_ROOT, "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root, "governance_operation_counters": counters,
        "next_legal_milestone": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_AND_COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE_ONCE_IF_ALL_GATES_PASS",
        "authority_ceiling": "V7_COMPATIBILITY_VALIDATION_ONLY_NO_WORKER_CREDENTIAL_TARGET_NETWORK_DAYBREAK_EXPLOIT_PARALLEL_CAPABILITY_PROMOTION_OR_SUBMISSION_AUTHORITY",
    })

    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": "PASS_LOCKED_GOVERNANCE_ONLY", "manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root, "files": len(rows) + 2}, sort_keys=True))


if __name__ == "__main__":
    main()
