#!/usr/bin/env python3
"""Primary and negative-fixture validation for the V6 lock-closure erratum."""

from __future__ import annotations

import ast
import hashlib
import json
import stat
from copy import deepcopy
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
V7 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v7-20261020")
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v5-runtime-identity-unavailable-and-noncandidate-invocation-deviation-prelock-erratum-and-successor-decision-governance-v1-20261020")
CODEX_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl/bin/codex")
CODEX_PACKAGE = CODEX_BINARY.parent.parent / "codex-package.json"

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6_STATIC_LOCK_MEMBER_SET_INCOMPLETE_AND_WRITABLE_VALIDATOR_SCHEMA_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V7_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V7"
V7_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V8"
RUNTIME = "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL"
V6_ROOT = "6b7df42eb8b82adea4d3a9829874426de15e28358acd27191415f6ca5d84ea56"
BINARY_SHA = "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215"
PACKAGE_SHA = "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78"
CONFIG_SHA = "7ae835188ef2ab3221e15effac45375b2d6112954d022aa7776f802f7b8697c0"
PRED_LOCK_SHA = "e5ba9964c42be8d91811237a27fedb228bb603c28c66151be446a8f762db1194"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V6_FROZEN_EVIDENCE_BINDING.json", "V6_TERMINAL_DISPOSITION.json",
    "STATIC_LOCK_COVERAGE_ADJUDICATION.json", "DEFECT_OWNERSHIP_ADJUDICATION.json",
    "NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT.json", "SUCCESSOR_V7_REQUIREMENTS.json",
    "SUCCESSOR_V7_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
ZERO_KEYS = {
    "unlocked_runtime_dependency_count", "unmanifested_validator_input_count",
    "writable_lock_member_count", "unexpected_prelock_workspace_member_count",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def tree_root(path: Path) -> str:
    rows = [f"{sha(member)}  {member.relative_to(path).as_posix()}\n" for member in sorted(item for item in path.rglob("*") if item.is_file())]
    return hashlib.sha256("".join(rows).encode()).hexdigest()


def canonical_policy() -> dict[str, Any]:
    return {
        "v6_terminal": True, "v6_patch": False, "v6_relock": False, "v6_continue": False,
        "v6_attempt": 0, "v6_codex_invocations": 0, "recorded_72_promotable": False,
        "member_set_complete": False, "verification_coverage_complete": False,
        "omitted_schema_count": 2, "writable_omitted_schema_count": 2,
        "closure_independent_of_manifest": True, "all_authoritative_inputs_manifested": True,
        "all_lock_members_read_only": True, "all_four_zero_counters": True,
        "same_identity_relock": False, "v7_execution": V7_EXECUTION, "v7_suite": V7_SUITE,
        "v7_runtime": RUNTIME, "runtime_reauthorized": True, "v7_attempt_limit": 1,
        "v7_invocation_limit": 1, "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "create_or_execute_v7_now": False, "worker_or_target_authority": False,
        "separate_acceptance": True,
    }


def mutations() -> dict[str, dict[str, Any]]:
    changes = [
        ("v6_patch", True), ("v6_relock", True), ("v6_continue", True), ("v6_codex_invocations", 1),
        ("create_or_execute_v7_now", True), ("closure_independent_of_manifest", False),
        ("all_authoritative_inputs_manifested", False), ("member_set_complete", True),
        ("omitted_schema_count", 0), ("all_lock_members_read_only", False),
        ("writable_omitted_schema_count", 0), ("all_four_zero_counters", False),
        ("same_identity_relock", True), ("recorded_72_promotable", True),
        ("verification_coverage_complete", True), ("v7_runtime", "CODEX_FROM_PATH"),
        ("runtime_reauthorized", False), ("v7_attempt_limit", 2), ("v7_invocation_limit", 2),
        ("compatibility", "PASS_LOCKED"), ("confinement", "PASS"), ("worker_or_target_authority", True),
        ("separate_acceptance", False), ("v7_execution", "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6"),
    ]
    output: dict[str, dict[str, Any]] = {}
    for index, (key, value) in enumerate(changes, 1):
        candidate = deepcopy(canonical_policy())
        candidate[key] = value
        output[f"N{index:03d}"] = candidate
    return output


def main() -> None:
    expected = SCRIPTS | BASE
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"primary input file-set mismatch: {sorted(actual)}")

    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("P001_EXACT_INPUT_SET", actual == expected, {"expected": len(expected), "actual": len(actual)})
    check("P002_V7_ABSENT", not V7.exists() and not V7.is_symlink())
    check("P003_V6_ROOT", tree_root(V6) == V6_ROOT, tree_root(V6))
    check("P004_PREDECESSOR_LOCK", sha(PRED / "GOVERNANCE_LOCK.json") == PRED_LOCK_SHA)
    check("P005_CODEX_BINARY_SHA", sha(CODEX_BINARY) == BINARY_SHA)
    check("P006_CODEX_PACKAGE_SHA", sha(CODEX_PACKAGE) == PACKAGE_SHA)
    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("P_SYNTAX_" + script, valid)

    docs: dict[str, dict[str, Any]] = {}
    for name in sorted(BASE):
        try:
            payload = load(name)
            docs[name] = payload
            valid = payload.get("governance_identity") == IDENTITY
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            valid = False
        check("P_JSON_" + name, valid)

    terminal = docs.get("V6_TERMINAL_DISPOSITION.json", {})
    coverage = docs.get("STATIC_LOCK_COVERAGE_ADJUDICATION.json", {})
    ownership = docs.get("DEFECT_OWNERSHIP_ADJUDICATION.json", {})
    closure = docs.get("NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT.json", {})
    requirements = docs.get("SUCCESSOR_V7_REQUIREMENTS.json", {})
    decision = docs.get("SUCCESSOR_V7_AUTHORIZATION_DECISION.json", {})
    authority = docs.get("AUTHORITY_NON_ESCALATION_DECISION.json", {})
    summary = docs.get("GOVERNANCE_DECISION_SUMMARY.json", {})
    matrix = docs.get("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {})
    next_step = docs.get("NEXT_LEGAL_MILESTONE.json", {})

    check("P030_V6_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_PRE_ATTEMPT_REFERENCE_PREDECESSOR")
    check("P031_V6_IMMUTABLE", terminal.get("immutable") is True)
    check("P032_NO_PATCH", terminal.get("patch") == "PROHIBITED")
    check("P033_NO_RELOCK", terminal.get("relock") == "PROHIBITED")
    check("P034_NO_CONTINUATION", terminal.get("continuation") == "PROHIBITED")
    check("P035_ATTEMPT_ZERO", terminal.get("attempt") == "0_OF_1_NOT_CONSUMED")
    check("P036_INVOCATION_ZERO", terminal.get("codex_0_163_0_invocation_count") == 0)
    check("P037_COMPATIBILITY_NOT_ESTABLISHED", terminal.get("compatibility") == "NOT_ESTABLISHED")
    check("P038_CONFINEMENT_NOT_PROVEN", terminal.get("confinement") == "NOT_PROVEN")
    check("P039_MEMBER_SET_INCOMPLETE", coverage.get("static_lock_member_set_incomplete") == "YES")
    check("P040_COVERAGE_INCOMPLETE", coverage.get("lock_verification_coverage_incomplete") == "YES")
    check("P041_WRITABLE_DEPENDENCY", coverage.get("writable_validator_dependency_outside_lock") == "YES")
    check("P042_TWO_OMITTED", coverage.get("unmanifested_authoritative_dependency_count") == 2)
    check("P043_TWO_WRITABLE", coverage.get("writable_unlocked_authoritative_dependency_count") == 2)
    omitted = coverage.get("omitted_dependencies", [])
    check("P044_OMITTED_PATHS", {row.get("path") for row in omitted} == {"schemas/COMPATIBILITY_REQUEST.schema.json", "schemas/COMPATIBILITY_RESULT.schema.json"})
    check("P045_OMITTED_MODES", len(omitted) == 2 and all(row.get("mode") == "0664" for row in omitted))
    check("P046_72_NOT_PROMOTABLE", coverage.get("recorded_lock_verification") == "72_OF_72_PASS_OVER_INCOMPLETE_MEMBER_SET" and coverage.get("recorded_lock_promotable_to_valid_lock") is False)
    check("P047_CLOSURE_DEFECT", ownership.get("static_lock_closure_construction_defect") == "YES")
    check("P048_VERIFIER_DEFECT", ownership.get("static_lock_verifier_coverage_defect") == "YES")
    check("P049_PREATTEMPT_GATE_DEFECT", ownership.get("pre_attempt_gate_coverage_defect") == "YES")
    check("P050_NO_CODEX_DEFECT", ownership.get("codex_runtime_defect") == "NO")
    required_categories = {
        "ALL_EXECUTABLE_SOURCE", "ALL_IMPORTED_LOCAL_MODULES", "ALL_SCHEMAS_READ_BY_VALIDATORS", "ALL_FIXTURE_INPUTS",
        "ALL_CONFIG_INPUTS", "ALL_GENERATED_PRELOCK_VALIDATION_RESULTS", "ALL_VALIDATOR_AND_LOCK_VERIFIER_PROGRAMS",
        "ALL_DECLARED_EXECUTION_CONTRACT_INPUTS",
    }
    check("P051_CLOSURE_CATEGORIES", set(closure.get("authoritative_workspace_categories", [])) == required_categories)
    counters = closure.get("mandatory_zero_counters_before_attempt", {})
    check("P052_TYPED_ZERO_COUNTERS", set(counters) == ZERO_KEYS and all(value == 0 for value in counters.values()))
    check("P053_CLOSURE_FAIL_CLOSED", closure.get("failure_semantics") == "STOP_FAIL_CLOSED_ATTEMPT_AND_CODEX_INVOCATION_REMAIN_ZERO_NO_RELOCK_SAME_IDENTITY")
    required_steps = closure.get("closure_algorithm", [])
    check("P054_INDEPENDENT_EXPECTED_SET", any("ENUMERATE_EVERY_REGULAR_FILE" in step for step in required_steps))
    check("P055_VALIDATOR_READ_DISCOVERY", any("VALIDATOR_READ_INPUTS" in step for step in required_steps))
    check("P056_READ_ONLY_AFTER_LOCK", any("REMOVE_WRITE_BITS" in step for step in required_steps))
    check("P057_SUCCESSOR_DECISION", decision.get("decision") == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_CONDITIONALLY")
    check("P058_V7_NOT_CREATED", decision.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED" and decision.get("creation_or_execution_this_milestone") is False)
    check("P059_V7_EXECUTION", decision.get("successor_execution_identity") == V7_EXECUTION)
    check("P060_V7_SUITE", decision.get("successor_suite_identity") == V7_SUITE)
    check("P061_V7_RUNTIME", decision.get("successor_runtime_identity") == RUNTIME)
    check("P062_EXPLICIT_REAUTH", decision.get("exact_runtime_identity_reauthorized") is True)
    check("P063_V7_ONE_SHOT", decision.get("attempt_count") == 0 and decision.get("attempt_limit") == 1)
    check("P064_V7_ONE_INVOCATION", decision.get("codex_0_163_0_invocation_count") == 0 and decision.get("codex_0_163_0_invocation_limit") == 1)
    binding = requirements.get("runtime_binding", {})
    check("P065_BINARY_PATH", binding.get("binary_path") == str(CODEX_BINARY))
    check("P066_BINARY_SHA", binding.get("binary_sha256") == BINARY_SHA)
    check("P067_PACKAGE_PATH", binding.get("package_path") == str(CODEX_PACKAGE))
    check("P068_PACKAGE_SHA", binding.get("package_sha256") == PACKAGE_SHA)
    check("P069_CONFIG_PATH", binding.get("config_path") == str(V7 / "runtime-config-candidate/config.toml"))
    check("P070_CONFIG_SHA", binding.get("config_sha256") == CONFIG_SHA)
    check("P071_REAUTH_SCOPE", binding.get("reauthorization") == "EXPLICIT_FOR_COMPATIBILITY_EXECUTION_V7_ONLY")
    required = set(requirements.get("mandatory_requirements", []))
    check("P072_ZERO_GATES_REQUIRED", {"UNLOCKED_RUNTIME_DEPENDENCY_COUNT_ZERO", "UNMANIFESTED_VALIDATOR_INPUT_COUNT_ZERO", "WRITABLE_LOCK_MEMBER_COUNT_ZERO", "UNEXPECTED_PRELOCK_WORKSPACE_MEMBER_COUNT_ZERO"}.issubset(required))
    operation_counters = authority.get("governance_operation_counters", {})
    check("P073_OPERATION_COUNTERS_ZERO", len(operation_counters) == 15 and all(value == 0 for value in operation_counters.values()))
    escalations = [key for key, value in authority.items() if key.endswith("_authorized") and value is not False]
    check("P074_NO_AUTHORITY_ESCALATION", not escalations, escalations)
    check("P075_SUMMARY", summary.get("successor_decision") == decision.get("decision"))
    check("P076_MATRIX_24", matrix.get("case_count") == 24 and len(matrix.get("cases", [])) == 24)
    check("P077_NEXT_STEP", next_step.get("next_if_pass_locked") == "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_AND_COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE_ONCE_IF_ALL_GATES_PASS")
    check("P078_CANONICAL_POLICY", canonical_policy() == canonical_policy())

    failed = [row for row in checks if row["status"] == "FAIL"]
    write("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_LOCK_CLOSURE_ERRATUM_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0", "run_id": "GOVERNANCE_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks": checks,
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": operation_counters,
    })

    matrix_cases = {row.get("case_id"): row for row in matrix.get("cases", [])}
    results = []
    canonical = canonical_policy()
    for case_id, candidate in sorted(mutations().items()):
        rejected = candidate != canonical
        expected_reject = matrix_cases.get(case_id, {}).get("expected") == "REJECT"
        results.append({"case_id": case_id, "expected": "REJECT", "observed": "REJECT" if rejected else "ACCEPT", "status": "PASS" if rejected and expected_reject else "FAIL"})
    negative_failed = [row for row in results if row["status"] == "FAIL"]
    write("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_LOCK_CLOSURE_ERRATUM_NEGATIVE_TEST_RESULT",
        "schema_version": "1.0", "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if not negative_failed and len(results) == 24 else "FAIL_CLOSED",
        "tests": results, "tests_total": len(results), "tests_passed": len(results) - len(negative_failed), "tests_failed": len(negative_failed),
        "positive_control": {"canonical_policy_accepted": canonical_policy() == canonical},
        "operation_counters": operation_counters,
    })
    print(json.dumps({"primary": [len(checks) - len(failed), len(checks)], "negative": [len(results) - len(negative_failed), len(results)]}, sort_keys=True))
    if failed or negative_failed or len(results) != 24:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
