#!/usr/bin/env python3
"""Independent raw-evidence validation for the V6 lock-closure erratum."""

from __future__ import annotations

import hashlib
import json
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
V7 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v7-20261020")
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v5-runtime-identity-unavailable-and-noncandidate-invocation-deviation-prelock-erratum-and-successor-decision-governance-v1-20261020")
CODEX_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl/bin/codex")
CODEX_PACKAGE = CODEX_BINARY.parent.parent / "codex-package.json"

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6_STATIC_LOCK_MEMBER_SET_INCOMPLETE_AND_WRITABLE_VALIDATOR_SCHEMA_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V7_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V7"
V7_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V8"
RUNTIME = "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL"
BINARY_SHA = "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215"
PACKAGE_SHA = "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78"
V6_ROOT = "6b7df42eb8b82adea4d3a9829874426de15e28358acd27191415f6ca5d84ea56"
PRED_LOCK_SHA = "e5ba9964c42be8d91811237a27fedb228bb603c28c66151be446a8f762db1194"
PRED_MANIFEST_SHA = "9571cfe1c61e7b0a0899cad1c5389c330de6a22a1780e829e2accd1f2304e62a"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V6_FROZEN_EVIDENCE_BINDING.json", "V6_TERMINAL_DISPOSITION.json", "STATIC_LOCK_COVERAGE_ADJUDICATION.json",
    "DEFECT_OWNERSHIP_ADJUDICATION.json", "NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT.json",
    "SUCCESSOR_V7_REQUIREMENTS.json", "SUCCESSOR_V7_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
PRIMARY_RESULTS = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree_root(path: Path) -> str:
    rows = [f"{sha(member)}  {member.relative_to(path).as_posix()}\n" for member in sorted(item for item in path.rglob("*") if item.is_file())]
    return hashlib.sha256("".join(rows).encode()).hexdigest()


def write(payload: dict[str, Any]) -> None:
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | PRIMARY_RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"independent input file-set mismatch: {sorted(actual)}")

    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("I001_EXACT_INPUT_SET", actual == expected)
    check("I002_V7_ABSENT", not V7.exists() and not V7.is_symlink())
    check("I003_V6_ROOT", tree_root(V6) == V6_ROOT, tree_root(V6))
    check("I004_PREDECESSOR_LOCK", sha(PRED / "GOVERNANCE_LOCK.json") == PRED_LOCK_SHA)
    check("I005_PREDECESSOR_MANIFEST", sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == PRED_MANIFEST_SHA)
    check("I006_BINARY_SHA", sha(CODEX_BINARY) == BINARY_SHA)
    check("I007_PACKAGE_SHA", sha(CODEX_PACKAGE) == PACKAGE_SHA)

    source_manifest = read(V6 / "STATIC_SOURCE_MANIFEST.json")
    manifest_paths = {row["path"] for row in source_manifest.get("members", [])}
    expected_omitted = {"schemas/COMPATIBILITY_REQUEST.schema.json", "schemas/COMPATIBILITY_RESULT.schema.json"}
    check("I008_MANIFEST_COUNT_22", source_manifest.get("member_count") == 22)
    check("I009_SCHEMAS_OMITTED", expected_omitted.isdisjoint(manifest_paths))
    modes = {path: f"{stat.S_IMODE((V6 / path).stat().st_mode):04o}" for path in expected_omitted}
    check("I010_SCHEMAS_WRITABLE", modes == {path: "0664" for path in expected_omitted}, modes)
    verification = read(V6 / "STATIC_EXECUTION_LOCK_VERIFICATION.json")
    check("I011_RECORDED_72_PASS", verification.get("status") == "PASS" and verification.get("validation_counts") == {"total": 72, "passed": 72, "failed": 0})
    terminal_raw = read(V6 / "static-run-v1/PRE_ATTEMPT_TERMINAL_RECORD.json")
    freeze_raw = read(V6 / "static-run-v1/PRE_ATTEMPT_FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json")
    check("I012_RAW_TERMINAL", terminal_raw.get("status") == "FAIL_CLOSED_BEFORE_ATTEMPT")
    check("I013_RAW_FREEZE", freeze_raw.get("status") == "FAIL_CLOSED_BEFORE_ATTEMPT_EVIDENCE_FROZEN")
    check("I014_NO_ATTEMPT_MARKER", not (V6 / "static-run-v1/ATTEMPT_MARKER.json").exists())
    check("I015_NO_RUNTIME_RESULT", not (V6 / "static-run-v1/runtime-result-0001.json").exists())

    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I016_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I017_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_total") == 24 and negative.get("tests_failed") == 0)

    docs = {name: read(ROOT / name) for name in BASE}
    check("I018_IDENTITIES", all(doc.get("governance_identity") == IDENTITY for doc in docs.values()))
    terminal = docs["V6_TERMINAL_DISPOSITION.json"]
    coverage = docs["STATIC_LOCK_COVERAGE_ADJUDICATION.json"]
    ownership = docs["DEFECT_OWNERSHIP_ADJUDICATION.json"]
    closure = docs["NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT.json"]
    decision = docs["SUCCESSOR_V7_AUTHORIZATION_DECISION.json"]
    requirements = docs["SUCCESSOR_V7_REQUIREMENTS.json"]
    authority = docs["AUTHORITY_NON_ESCALATION_DECISION.json"]
    summary = docs["GOVERNANCE_DECISION_SUMMARY.json"]

    check("I019_V6_DISPOSITION", terminal.get("disposition") == "FAIL_CLOSED_PRE_ATTEMPT_REFERENCE_PREDECESSOR")
    check("I020_V6_NO_MUTATION_PATH", all(terminal.get(key) == "PROHIBITED" for key in ("patch", "relock", "continuation", "runtime_invocation")))
    check("I021_ATTEMPT_ZERO", terminal.get("attempt") == "0_OF_1_NOT_CONSUMED")
    check("I022_INVOCATION_ZERO", terminal.get("codex_0_163_0_invocation_count") == 0)
    check("I023_MEMBER_SET_INCOMPLETE", coverage.get("static_lock_member_set_incomplete") == "YES")
    check("I024_COVERAGE_INCOMPLETE", coverage.get("lock_verification_coverage_incomplete") == "YES")
    check("I025_WRITABLE_OUTSIDE_LOCK", coverage.get("writable_validator_dependency_outside_lock") == "YES")
    check("I026_NOT_PROMOTABLE", coverage.get("recorded_lock_promotable_to_valid_lock") is False)
    adjudicated = {row.get("path"): (row.get("sha256"), row.get("mode")) for row in coverage.get("omitted_dependencies", [])}
    raw = {path: (sha(V6 / path), modes[path]) for path in expected_omitted}
    check("I027_OMISSION_EVIDENCE_MATCH", adjudicated == raw, {"adjudicated": adjudicated, "raw": raw})
    check("I028_OWNERSHIP_CLOSURE", ownership.get("static_lock_closure_construction_defect") == "YES")
    check("I029_OWNERSHIP_VERIFIER", ownership.get("static_lock_verifier_coverage_defect") == "YES")
    check("I030_NO_RUNTIME_DEFECT", ownership.get("codex_runtime_defect") == "NO" and ownership.get("compatibility_behavior_defect") == "NOT_EVALUATED")
    zeros = closure.get("mandatory_zero_counters_before_attempt", {})
    check("I031_FOUR_ZERO_GATES", len(zeros) == 4 and all(value == 0 for value in zeros.values()))
    check("I032_NO_RELOCK_FAILURE", "NO_RELOCK_SAME_IDENTITY" in closure.get("failure_semantics", ""))
    check("I033_V7_DECISION", decision.get("decision") == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_CONDITIONALLY")
    check("I034_V7_IDENTITY", decision.get("successor_execution_identity") == V7_EXECUTION and decision.get("successor_suite_identity") == V7_SUITE)
    check("I035_RUNTIME_IDENTITY", decision.get("successor_runtime_identity") == RUNTIME)
    check("I036_EXPLICIT_REAUTH", decision.get("exact_runtime_identity_reauthorized") is True)
    check("I037_V7_COUNTS_ZERO", decision.get("attempt_count") == 0 and decision.get("codex_0_163_0_invocation_count") == 0)
    check("I038_V7_LIMITS_ONE", decision.get("attempt_limit") == 1 and decision.get("codex_0_163_0_invocation_limit") == 1)
    binding = requirements.get("runtime_binding", {})
    check("I039_EXACT_BINARY_BINDING", binding.get("binary_path") == str(CODEX_BINARY) and binding.get("binary_sha256") == BINARY_SHA)
    check("I040_EXACT_PACKAGE_BINDING", binding.get("package_path") == str(CODEX_PACKAGE) and binding.get("package_sha256") == PACKAGE_SHA)
    check("I041_REAUTH_LIMITED", binding.get("reauthorization") == "EXPLICIT_FOR_COMPATIBILITY_EXECUTION_V7_ONLY")
    check("I042_V7_NOT_CREATED", decision.get("creation_or_execution_this_milestone") is False)
    counters = authority.get("governance_operation_counters", {})
    check("I043_OPERATION_COUNTERS_ZERO", len(counters) == 15 and all(value == 0 for value in counters.values()))
    escalations = [key for key, value in authority.items() if key.endswith("_authorized") and value is not False]
    check("I044_NO_AUTHORITY_ESCALATION", not escalations, escalations)
    check("I045_COMPATIBILITY_UNPROVEN", summary.get("compatibility") == "NOT_ESTABLISHED")
    check("I046_CONFINEMENT_UNPROVEN", summary.get("confinement") == "NOT_PROVEN")
    check("I047_GOVERNANCE_NOT_RUNTIME_PASS", summary.get("governance_pass_does_not_establish_runtime_compatibility") is True)

    failed = [row for row in checks if row["status"] == "FAIL"]
    write({
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_LOCK_CLOSURE_ERRATUM_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0", "run_id": "INDEPENDENT_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks": checks,
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "independent_raw_derivation": True, "codex_invoked": False, "v7_created": False,
    })
    print(json.dumps({"status": "PASS" if not failed else "FAIL_CLOSED", "passed": len(checks) - len(failed), "total": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
