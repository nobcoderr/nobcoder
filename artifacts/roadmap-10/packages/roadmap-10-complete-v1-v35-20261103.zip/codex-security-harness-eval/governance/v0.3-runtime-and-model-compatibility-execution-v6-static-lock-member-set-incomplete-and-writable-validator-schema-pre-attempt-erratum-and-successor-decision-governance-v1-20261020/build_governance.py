#!/usr/bin/env python3
"""Build the V6 dependency-closure erratum without executing any runtime."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v5-runtime-identity-unavailable-and-noncandidate-invocation-deviation-prelock-erratum-and-successor-decision-governance-v1-20261020")
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
V7 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v7-20261020")
CODEX_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl/bin/codex")
CODEX_PACKAGE = CODEX_BINARY.parent.parent / "codex-package.json"
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6_STATIC_LOCK_MEMBER_SET_INCOMPLETE_AND_WRITABLE_VALIDATOR_SCHEMA_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V6_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6"
V6_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V7"
V7_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V7"
V7_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V8"
RUNTIME = "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL"

HASHES = {
    "predecessor_lock": "e5ba9964c42be8d91811237a27fedb228bb603c28c66151be446a8f762db1194",
    "predecessor_manifest": "9571cfe1c61e7b0a0899cad1c5389c330de6a22a1780e829e2accd1f2304e62a",
    "predecessor_root": "d8b95755b1bfd17c9a89f9e3415061be016075f43b5aecd80dc8696ead837b62",
    "v6_tree_root": "6b7df42eb8b82adea4d3a9829874426de15e28358acd27191415f6ca5d84ea56",
    "source_manifest": "fff541e7a8fb29109188f85c27288d716f92c93ed21b1f94ad2ed5ae9484a517",
    "static_lock": "4914717a3d765c1e645533ebba193779e40fae8c03e84b5bf65885c38f92a615",
    "lock_verification": "ad5ce91e0ed509a1b598ac6621af07a5057151bf05a029239907107f40698a01",
    "request_schema": "5be11be4c166b6947387bb5b99bc9e6497cc0cd9ab35302fd9a543668d2e8350",
    "result_schema": "758a52bffd2cbf9ca267ddaedfcafef71c7d73e95573de715b340d8942b1625b",
    "pre_attempt": "b1060a54d1875b1b6403ba804d36519a4da5abfa9a590496fddd92464f0d473f",
    "terminal": "30259cbace283216c0889479814732ebfd15beb77f455217f699f3341a50746d",
    "evidence_manifest": "1114da929c82103f3df96c063f07930179ea29625bd5dc6dc12ea98c53a8fcb7",
    "evidence_freeze": "bd51f4de2676ee2e054884cae5a5c8a24d409bc989afa69262d1fa9cde05378b",
    "codex_binary": "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215",
    "codex_package": "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78",
    "config": "7ae835188ef2ab3221e15effac45375b2d6112954d022aa7776f802f7b8697c0",
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
}

V6_EVIDENCE = {
    "STATIC_SOURCE_MANIFEST.json": HASHES["source_manifest"],
    "STATIC_EXECUTION_LOCK.json": HASHES["static_lock"],
    "STATIC_EXECUTION_LOCK_VERIFICATION.json": HASHES["lock_verification"],
    "schemas/COMPATIBILITY_REQUEST.schema.json": HASHES["request_schema"],
    "schemas/COMPATIBILITY_RESULT.schema.json": HASHES["result_schema"],
    "static-run-v1/pre-attempt-gates-run-0001.json": HASHES["pre_attempt"],
    "static-run-v1/PRE_ATTEMPT_TERMINAL_RECORD.json": HASHES["terminal"],
    "static-run-v1/PRE_ATTEMPT_FAIL_CLOSED_EVIDENCE_MANIFEST.json": HASHES["evidence_manifest"],
    "static-run-v1/PRE_ATTEMPT_FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json": HASHES["evidence_freeze"],
}

OPERATION_KEYS = [
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "compatibility_suite_executions", "credential_operations", "daybreak_invocations",
    "exploit_replays", "external_network_operations", "future_runtime_invocations",
    "parallel_operations", "runtime_invocations", "subagent_processes",
    "submission_operations", "target_operations", "worker_processes",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def regular(path: Path) -> bool:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode)


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def tree_root(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = [
        {"path": member.relative_to(path).as_posix(), "sha256": sha(member), "bytes": member.stat().st_size}
        for member in sorted(item for item in path.rglob("*") if item.is_file())
    ]
    return canonical_root(rows), rows


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_predecessor() -> dict[str, Any]:
    if sha(PRED / "GOVERNANCE_LOCK.json") != HASHES["predecessor_lock"]:
        raise SystemExit("predecessor lock mismatch")
    if sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") != HASHES["predecessor_manifest"]:
        raise SystemExit("predecessor manifest mismatch")
    lock = load(PRED / "GOVERNANCE_LOCK.json")
    if lock.get("canonical_artifact_root_sha256") != HASHES["predecessor_root"]:
        raise SystemExit("predecessor canonical root mismatch")
    return lock


def main() -> None:
    expected_sources = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected_sources or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    if V7.exists() or V7.is_symlink():
        raise SystemExit("V7 must not exist during governance-only adjudication")
    predecessor = verify_predecessor()
    v6_root, v6_rows = tree_root(V6)
    if v6_root != HASHES["v6_tree_root"] or len(v6_rows) != 31:
        raise SystemExit("V6 tree changed")
    for relative, digest in V6_EVIDENCE.items():
        path = V6 / relative
        if not regular(path) or sha(path) != digest:
            raise SystemExit(f"V6 evidence mismatch: {relative}")
    if sha(CODEX_BINARY) != HASHES["codex_binary"] or sha(CODEX_PACKAGE) != HASHES["codex_package"]:
        raise SystemExit("Codex candidate filesystem identity drift")
    if sha(ROUTER_MAP) != HASHES["router_map"]:
        raise SystemExit("router map drift")

    manifest = load(V6 / "STATIC_SOURCE_MANIFEST.json")
    manifest_paths = {row["path"] for row in manifest["members"]}
    omitted = sorted({"schemas/COMPATIBILITY_REQUEST.schema.json", "schemas/COMPATIBILITY_RESULT.schema.json"} - manifest_paths)
    if len(omitted) != 2 or manifest.get("member_count") != 22:
        raise SystemExit("V6 omission facts changed")
    schema_modes = {
        relative: f"{stat.S_IMODE((V6 / relative).stat().st_mode):04o}" for relative in omitted
    }
    if schema_modes != {name: "0664" for name in omitted}:
        raise SystemExit("V6 writable-schema evidence changed")
    verification = load(V6 / "STATIC_EXECUTION_LOCK_VERIFICATION.json")
    terminal = load(V6 / "static-run-v1/PRE_ATTEMPT_TERMINAL_RECORD.json")
    freeze = load(V6 / "static-run-v1/PRE_ATTEMPT_FAIL_CLOSED_EVIDENCE_FREEZE_LOCK.json")
    if verification.get("status") != "PASS" or verification.get("validation_counts") != {"total": 72, "passed": 72, "failed": 0}:
        raise SystemExit("V6 verification record changed")
    if terminal.get("status") != "FAIL_CLOSED_BEFORE_ATTEMPT" or freeze.get("status") != "FAIL_CLOSED_BEFORE_ATTEMPT_EVIDENCE_FROZEN":
        raise SystemExit("V6 terminal evidence changed")
    for forbidden in ("static-run-v1/ATTEMPT_MARKER.json", "static-run-v1/runtime-result-0001.json"):
        if (V6 / forbidden).exists() or (V6 / forbidden).is_symlink():
            raise SystemExit(f"forbidden V6 execution artifact exists: {forbidden}")

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0", "scope": "GOVERNANCE_ONLY_FROZEN_V6_PRE_ATTEMPT_EVIDENCE_ADJUDICATION",
        "authorized_actions": ["READ_FROZEN_V6_EVIDENCE", "ADJUDICATE_LOCK_CLOSURE_AND_OWNERSHIP", "DEFINE_NORMATIVE_SUCCESSOR_CLOSURE", "ISSUE_CONDITIONAL_V7_DECISION", "RUN_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE"],
        "forbidden_actions": ["PATCH_RELOCK_REVALIDATE_OR_CONTINUE_V6", "INVOKE_CODEX_OR_ANY_MODEL_RUNTIME", "CREATE_OR_EXECUTE_V7", "WORKER_OR_SUBAGENT_EXECUTION", "CREDENTIAL_TARGET_OR_NETWORK_OPERATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION"],
        "runtime_execution_authority": False,
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_ROUTING_LEDGER", "schema_version": "1.0",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness", "external-ai-security-tool-governor"],
        "deferred": ["Compatibility Execution V7 implementation", "Codex compatibility invocation", "worker/subagent execution", "credential/target/network access", "exploit replay", "parallelism", "capability graph"],
        "not_applicable": ["live vulnerability discovery", "program-impact finding adjudication", "target prior-art screening", "target-specific offensive validation"],
        "subagents_used": False, "codex_invoked": False, "runtime_invoked": False, "router_map_sha256": HASHES["router_map"],
    })
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_PREDECESSOR_CHAIN_BINDING", "schema_version": "1.0",
        "predecessor_governance_identity": predecessor["governance_identity"], "predecessor_status": predecessor["status"],
        "predecessor_decision": predecessor["decision"], "predecessor_lock_sha256": HASHES["predecessor_lock"],
        "predecessor_manifest_sha256": HASHES["predecessor_manifest"], "predecessor_canonical_artifact_root_sha256": HASHES["predecessor_root"],
        "authorized_v6_execution_identity": predecessor["v6_execution_identity"], "authorized_v6_suite_identity": predecessor["v6_suite_identity"],
        "authorized_v6_runtime_identity": predecessor["v6_runtime_identity"],
    })
    write("V6_FROZEN_EVIDENCE_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_FROZEN_EVIDENCE_BINDING", "schema_version": "1.0",
        "v6_path": str(V6), "execution_identity": V6_EXECUTION, "suite_identity": V6_SUITE,
        "member_count": len(v6_rows), "canonical_tree_root_sha256": v6_root, "members": v6_rows,
        "key_artifact_sha256": V6_EVIDENCE, "integrity_at_adjudication": "PASS", "content_mutation_during_governance": "PROHIBITED",
    })
    write("V6_TERMINAL_DISPOSITION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "execution_identity": V6_EXECUTION, "suite_identity": V6_SUITE,
        "disposition": "FAIL_CLOSED_PRE_ATTEMPT_REFERENCE_PREDECESSOR", "immutable": True,
        "static_lock": "ISSUED_BUT_NOT_ACCEPTABLE", "attempt": "0_OF_1_NOT_CONSUMED", "codex_0_163_0_invocation_count": 0,
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "patch": "PROHIBITED", "relock": "PROHIBITED", "continuation": "PROHIBITED", "runtime_invocation": "PROHIBITED",
    })
    write("STATIC_LOCK_COVERAGE_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_STATIC_LOCK_COVERAGE_ADJUDICATION", "schema_version": "1.0",
        "static_lock_member_set_incomplete": "YES", "lock_verification_coverage_incomplete": "YES",
        "writable_validator_dependency_outside_lock": "YES", "unmanifested_authoritative_dependency_count": 2,
        "writable_unlocked_authoritative_dependency_count": 2, "recorded_lock_verification": "72_OF_72_PASS_OVER_INCOMPLETE_MEMBER_SET",
        "recorded_lock_promotable_to_valid_lock": False,
        "omitted_dependencies": [{"path": path, "sha256": V6_EVIDENCE[path], "mode": schema_modes[path], "authoritative_use": "READ_BY_INDEPENDENT_STATIC_VALIDATOR"} for path in omitted],
        "actual_post_lock_content_mutation_observed": False,
        "verdict": "LOCK_COVERAGE_INVALID_EVEN_WITHOUT_OBSERVED_CONTENT_MUTATION",
    })
    write("DEFECT_OWNERSHIP_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_DEFECT_OWNERSHIP_ADJUDICATION", "schema_version": "1.0",
        "control_plane_runtime_defect": "NO", "codex_runtime_defect": "NO", "compatibility_behavior_defect": "NOT_EVALUATED",
        "static_lock_closure_construction_defect": "YES", "static_lock_verifier_coverage_defect": "YES",
        "pre_attempt_gate_coverage_defect": "YES", "confinement_bypass": "NO_EVIDENCE_BUT_CONFINEMENT_NOT_PROVEN",
        "ownership": ["STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT", "STATIC_SOURCE_MANIFEST_CONSTRUCTION", "LOCK_VERIFIER_EXPECTED_SET_BINDING", "PRE_ATTEMPT_ZERO_UNMANIFESTED_DEPENDENCY_GATE"],
    })
    closure_categories = [
        "ALL_EXECUTABLE_SOURCE", "ALL_IMPORTED_LOCAL_MODULES", "ALL_SCHEMAS_READ_BY_VALIDATORS",
        "ALL_FIXTURE_INPUTS", "ALL_CONFIG_INPUTS", "ALL_GENERATED_PRELOCK_VALIDATION_RESULTS",
        "ALL_VALIDATOR_AND_LOCK_VERIFIER_PROGRAMS", "ALL_DECLARED_EXECUTION_CONTRACT_INPUTS",
    ]
    write("NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE_CONTRACT", "schema_version": "1.0",
        "normative_formula": "STATIC_LOCK_CLOSURE = EXECUTABLE_SOURCE + IMPORTED_LOCAL_MODULES + VALIDATOR_SCHEMAS + FIXTURES + CONFIG_INPUTS + GENERATED_PRELOCK_VALIDATION_DEPENDENCIES + DECLARED_EXTERNAL_RUNTIME_DEPENDENCIES",
        "authoritative_workspace_categories": closure_categories,
        "closure_algorithm": [
            "ENUMERATE_EVERY_REGULAR_FILE_IN_FRESH_PRELOCK_WORKSPACE_EXCEPT_EXPLICIT_RESERVED_LOCK_AND_RUNTIME_OUTPUT_NAMES",
            "REJECT_ALL_SYMLINKS_AND_NON_REGULAR_AUTHORITATIVE_INPUTS",
            "RESOLVE_LOCAL_IMPORTS_AND_ASSERT_SUBSET_OF_MANIFEST",
            "ENUMERATE_DECLARED_AND_STATICALLY_DISCOVERED_VALIDATOR_READ_INPUTS_AND_ASSERT_SUBSET_OF_MANIFEST",
            "INCLUDE_PRELOCK_TEST_PRIMARY_INDEPENDENT_AND_PREFLIGHT_RESULTS",
            "BIND_EXTERNAL_RUNTIME_DEPENDENCIES_IN_SEPARATE_EXACT_IDENTITY_TABLE",
            "ISSUE_LOCK_THEN_REMOVE_WRITE_BITS_FROM_EVERY_MANIFEST_MEMBER",
            "REOPEN_FROM_DISK_AND_RECOMPUTE_EXPECTED_SET_DIGESTS_MODES_AND_EXTERNAL_BINDINGS",
        ],
        "reserved_outputs_not_prelock_inputs": ["STATIC_SOURCE_MANIFEST.json", "STATIC_EXECUTION_LOCK.json", "STATIC_EXECUTION_LOCK_VERIFICATION.json", "static-run-v1/*"],
        "mandatory_zero_counters_before_attempt": {"unlocked_runtime_dependency_count": 0, "unmanifested_validator_input_count": 0, "writable_lock_member_count": 0, "unexpected_prelock_workspace_member_count": 0},
        "failure_semantics": "STOP_FAIL_CLOSED_ATTEMPT_AND_CODEX_INVOCATION_REMAIN_ZERO_NO_RELOCK_SAME_IDENTITY",
    })
    requirements = [
        "FRESH_V7_EXECUTION_AND_SUITE_IDENTITIES", "CARRY_FORWARD_V1_THROUGH_V6_REGRESSIONS",
        "EXPLICIT_REAUTHORIZATION_OF_EXACT_CODEX_0_163_0_IDENTITY", "EXACT_ABSOLUTE_BINARY_PATH_AND_SHA256",
        "EXACT_PACKAGE_PATH_METADATA_AND_SHA256", "FRESH_V7_CONFIG_PATH_AND_SHA256", "NO_PATH_OR_SYMLINK_RUNTIME_SELECTION",
        "IDENTITY_SAFE_NON_EXECUTING_DISCOVERY", "NORMATIVE_STATIC_LOCK_DEPENDENCY_CLOSURE",
        "ALL_EXECUTABLE_SOURCE_IMPORTED_MODULES_SCHEMAS_FIXTURES_CONFIG_AND_PRELOCK_RESULTS_MANIFESTED",
        "UNLOCKED_RUNTIME_DEPENDENCY_COUNT_ZERO", "UNMANIFESTED_VALIDATOR_INPUT_COUNT_ZERO",
        "WRITABLE_LOCK_MEMBER_COUNT_ZERO", "UNEXPECTED_PRELOCK_WORKSPACE_MEMBER_COUNT_ZERO",
        "EXPECTED_MEMBER_SET_INDEPENDENTLY_DERIVED_NOT_TRUSTED_FROM_MANIFEST",
        "SEMANTIC_EXECVE_NAMESPACE_WRITE_AND_TYPED_PATH_CLASSIFICATION", "TYPED_EXIT_GRAMMAR_AND_DIAGNOSTIC_COMPLETE_RESULT",
        "PRIMARY_NEGATIVE_AND_INDEPENDENT_VALIDATION", "FRESH_PREFLIGHT", "STATIC_LOCK_AND_FULL_CLOSURE_VERIFICATION_BEFORE_ATTEMPT",
        "EXACTLY_ONE_V7_ATTEMPT_AND_CODEX_0_163_0_INVOCATION", "INDEPENDENT_POST_VALIDATION", "EVIDENCE_FREEZE", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    runtime_binding = {
        "runtime_identity": RUNTIME, "binary_path": str(CODEX_BINARY), "binary_sha256": HASHES["codex_binary"],
        "package_path": str(CODEX_PACKAGE), "package_sha256": HASHES["codex_package"],
        "config_path": str(V7 / "runtime-config-candidate/config.toml"), "config_sha256": HASHES["config"],
        "reauthorization": "EXPLICIT_FOR_COMPATIBILITY_EXECUTION_V7_ONLY",
    }
    write("SUCCESSOR_V7_REQUIREMENTS.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_SUCCESSOR_V7_REQUIREMENTS", "schema_version": "1.0",
        "successor_execution_identity": V7_EXECUTION, "successor_suite_identity": V7_SUITE,
        "successor_runtime_identity": RUNTIME, "mandatory_requirements": requirements, "runtime_binding": runtime_binding,
        "pre_attempt_failure_semantics": "STOP_ATTEMPT_0_INVOCATION_0_NO_RELOCK_SAME_IDENTITY",
    })
    write("SUCCESSOR_V7_AUTHORIZATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_SUCCESSOR_V7_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_CONDITIONALLY",
        "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED", "successor_path": str(V7),
        "successor_execution_identity": V7_EXECUTION, "successor_suite_identity": V7_SUITE, "successor_runtime_identity": RUNTIME,
        "exact_runtime_identity_reauthorized": True, "attempt_count": 0, "attempt_limit": 1,
        "codex_0_163_0_invocation_count": 0, "codex_0_163_0_invocation_limit": 1,
        "authority_ceiling": "COMPATIBILITY_VALIDATION_ONLY_NO_WORKER_CREDENTIAL_TARGET_NETWORK_OR_OFFENSIVE_AUTHORITY",
        "creation_or_execution_this_milestone": False, "separate_acceptance_required": True,
    })
    zero = {key: 0 for key in OPERATION_KEYS}
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "governance_operation_counters": zero, "historical_v6_attempt_count": 0, "historical_v6_codex_invocation_count": 0,
        "v7_created": False, "v7_executed": False, "worker_execution_authorized": False, "subagent_execution_authorized": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "daybreak_invocation_authorized": False, "exploit_replay_authorized": False, "parallelism_authorized": False,
        "capability_graph_authorized": False, "candidate_promotion_authorized": False, "submission_automation_authorized": False,
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "current_milestone": {"read_frozen_v6_evidence": "AUTHORIZED", "governance_validation": "AUTHORIZED", "governance_freeze": "AUTHORIZED"},
        "conditionally_authorized_after_pass_locked": {"create_validate_lock_and_execute_v7_once": "AUTHORIZED_ONLY_UNDER_SUCCESSOR_REQUIREMENTS"},
        "not_authorized_now": ["PATCH_RELOCK_CONTINUE_OR_INVOKE_V6", "CREATE_OR_EXECUTE_V7_DURING_GOVERNANCE", "WORKER_SUBAGENT_CREDENTIAL_TARGET_NETWORK_DAYBREAK_EXPLOIT_PARALLEL_CAPABILITY_PROMOTION_OR_SUBMISSION"],
    })
    negative_cases = [
        "PATCH_V6", "RELOCK_V6", "CONTINUE_V6", "INVOKE_CODEX_DURING_GOVERNANCE", "CREATE_V7_DURING_GOVERNANCE",
        "MANIFEST_DERIVED_EXPECTED_SET_ONLY", "OMIT_EXECUTABLE_SOURCE", "OMIT_IMPORTED_LOCAL_MODULE", "OMIT_VALIDATOR_SCHEMA",
        "OMIT_FIXTURE", "OMIT_CONFIG", "OMIT_PRELOCK_RESULT", "ALLOW_SYMLINK_DEPENDENCY", "ALLOW_WRITABLE_LOCK_MEMBER",
        "ALLOW_UNMANIFESTED_VALIDATOR_READ", "ALLOW_UNLOCKED_EXTERNAL_RUNTIME", "ALLOW_UNEXPECTED_PRELOCK_MEMBER",
        "RELOCK_AFTER_CLOSURE_FAILURE", "INFER_COMPATIBILITY_FROM_IDENTITY", "INFER_CONFINEMENT_FROM_NO_ATTEMPT",
        "WORKER_AUTHORITY_ESCALATION", "TARGET_NETWORK_AUTHORITY_ESCALATION", "DAYBREAK_OR_EXPLOIT_AUTHORITY_ESCALATION", "PROMOTION_OR_SUBMISSION_AUTHORITY_ESCALATION",
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_NEGATIVE_TEST_MATRIX", "schema_version": "1.0",
        "expected_verdict": "REJECT", "case_count": len(negative_cases),
        "cases": [{"case_id": f"N{index:03d}", "mutation": name, "expected": "REJECT"} for index, name in enumerate(negative_cases, 1)],
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "v6_disposition": "FAIL_CLOSED_PRE_ATTEMPT_REFERENCE_PREDECESSOR", "static_lock_member_set_incomplete": "YES",
        "lock_verification_coverage_incomplete": "YES", "writable_validator_dependency_outside_lock": "YES",
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "successor_decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_CONDITIONALLY",
        "governance_pass_does_not_establish_runtime_compatibility": True,
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V6_DEPENDENCY_CLOSURE_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_if_pass_locked": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V7_WITH_EXACT_CODEX_0_163_0_AND_COMPLETE_STATIC_LOCK_DEPENDENCY_CLOSURE_ONCE_IF_ALL_GATES_PASS",
        "v7_attempt_before_milestone": 0, "v7_codex_invocation_before_milestone": 0,
    })


if __name__ == "__main__":
    main()
