"""Build the immutable-input V26 governance adjudication artifacts."""

from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path

from governance_common import (
    EXPECTED_FAILURE, EXPECTED_STATUS, IDENTITY, PYTHON, ROOT, V26, V26_FREEZE_SHA,
    V26_IDENTITY, V26_MANIFEST_SHA, V26_ROOT, V26_TERMINAL_SHA, V27_IDENTITY,
    expected_unresolved, load, module_identity_verdict, sha256, verify_v26_frozen,
    v26_paths, write_once,
)


def spec_row(module: str) -> dict:
    spec = importlib.util.find_spec(module)
    if spec is None:
        raise RuntimeError(f"canonical runtime cannot resolve {module}")
    if spec.origin == "built-in":
        category = "BUILTIN_MODULE"
        loader = "_frozen_importlib.BuiltinImporter"
    elif spec.origin == "frozen":
        category = "FROZEN_MODULE"
        loader = "_frozen_importlib.FrozenImporter"
    elif spec.origin and spec.origin.endswith(".so"):
        category = "EXTENSION_MODULE"
        loader = "_frozen_importlib_external.ExtensionFileLoader"
    else:
        category = "PURE_PYTHON_STDLIB"
        loader = "_frozen_importlib_external.SourceFileLoader"
    path = Path(spec.origin) if spec.origin not in {None, "built-in", "frozen"} else None
    return {
        "module_category": category,
        "expected_module_origin": spec.origin,
        "expected_loader_identity": loader,
        "expected_source_sha256": sha256(path) if path is not None else None,
        "expected_size": path.stat().st_size if path is not None else None,
        "has_location": spec.has_location,
    }


def main() -> int:
    frozen = verify_v26_frozen()
    if frozen["status"] != "PASS":
        raise RuntimeError("V26 frozen evidence integrity failed")
    paths = v26_paths()
    manifest = load(paths["symbols"])
    independent = load(paths["independent"])
    manifest_rows = {row["symbol"]: row for row in manifest["symbols"]}
    failed_check = next(row for row in independent["checks"] if row["id"] == EXPECTED_FAILURE)
    failures = {(row["symbol"], row["module"]): row for row in failed_check["evidence"]["failures"]}
    classifications = []
    for symbol, module in expected_unresolved():
        authoritative = manifest_rows[symbol]
        runtime = spec_row(module)
        row = {
            "logical_symbol_identity": f"V26_PREATTEMPT_SYMBOL::{symbol}",
            "expected_module_identity": module,
            "symbol_name": symbol,
            "logical_module_identity": f"PYTHON_3_14_STDLIB::{module}",
            "expected_import_name": module,
            "expected_module_spec_semantics": "RESOLVE_IN_PINNED_PYTHON_3_14_RUNTIME_BY_TYPED_MODULE_CLASS",
            "actual_independent_validator_module_spec": None,
            "actual_independent_validator_module_origin": None,
            "actual_independent_validator_loader_identity": None,
            "validation_environment": {
                "python_executable": str(PYTHON),
                "python_version": sys.version,
                "cwd": str(V26),
                "PYTHONPATH": "ABSENT",
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONHASHSEED": "0",
                "PYTHONPYCACHEPREFIX": "ABSENT",
                "independent_resolution_algorithm": "LOCAL_MODULE_BINDING_GATE_THEN_PATHFINDER_WITH_ONLY_V26_SRC",
            },
            "authoritative_manifest_row": authoritative,
            "independent_graph_row": {
                key: authoritative[key]
                for key in (
                    "symbol", "defining_module", "expected_imported_name", "expected_alias",
                    "expected_import_or_binding", "call_or_reference_sites",
                )
            },
            "exact_resolution_failure": failures[(symbol, module)],
            "failure_mechanism": "STDLIB_MODULE_ABSENT_FROM_LOCAL_MODULE_BINDING_SO_RESOLUTION_NOT_ATTEMPTED",
            **runtime,
        }
        if module_identity_verdict(row)["status"] != "PASS":
            raise RuntimeError(f"typed module classification invalid: {symbol}")
        classifications.append(row)

    charter = {
        "record_type": "V26_STDLIB_SYMBOL_RESOLUTION_GOVERNANCE_CHARTER",
        "governance_identity": IDENTITY,
        "scope": "GOVERNANCE_ONLY_READ_ONLY_V26_ADJUDICATION",
        "prohibitions": [
            "PATCH_V26", "RERUN_V26", "DUPLICATE_V26", "FRESH_PREFLIGHT",
            "STATIC_LOCK", "SECURITY_WORKER_INVOCATION", "CODEX_AS_WORKER_INVOCATION",
            "CREATE_OR_EXECUTE_V27",
        ],
        "status": "ACTIVE_FOR_GOVERNANCE_BUILD",
    }
    frozen_binding = {
        "record_type": "V26_FROZEN_FAILURE_EVIDENCE_BINDING",
        "execution_identity": V26_IDENTITY,
        "terminal_status": EXPECTED_STATUS,
        "unit": "314/314 PASS", "primary": "88/88 PASS", "independent": "101/102 FAIL_CLOSED",
        "failed_gate": EXPECTED_FAILURE,
        "static_lock": "NOT_ISSUED", "attempt": "0/1", "worker": "0/1", "codex": "0/1",
        "attempt_marker": "ABSENT", "runtime_evidence": "ABSENT",
        "canonical_evidence_root_sha256": V26_ROOT,
        "terminal_sha256": V26_TERMINAL_SHA,
        "failure_manifest_sha256": V26_MANIFEST_SHA,
        "freeze_verification_sha256": V26_FREEZE_SHA,
        "frozen_integrity_verdict": frozen,
    }
    incident = {
        "record_type": "V26_STANDARD_LIBRARY_SYMBOL_RESOLUTION_INCIDENT",
        "authoritative_symbol_count": 91,
        "independent_symbol_count": 91,
        "unresolved_binding_count": 9,
        "unique_unresolved_module_count": 8,
        "failed_gate": EXPECTED_FAILURE,
        "independent_algorithm": {
            "canonical_local_module_binding_required_before_resolution": True,
            "resolution_search_path": [str(V26 / "src")],
            "stdlib_typed_identity_model": "ABSENT",
            "result_for_unbound_stdlib": "MODULE_UNRESOLVABLE_WITHOUT_STDLIB_SPEC_ATTEMPT",
        },
        "classification_artifact": "NINE_UNRESOLVED_STANDARD_LIBRARY_BINDINGS.json",
    }
    classification = {
        "record_type": "V26_NINE_UNRESOLVED_STANDARD_LIBRARY_BINDINGS_CLASSIFICATION",
        "execution_identity": V26_IDENTITY,
        "binding_count": 9,
        "bindings": classifications,
        "category_counts": {
            "PURE_PYTHON_STDLIB": 7,
            "EXTENSION_MODULE": 1,
            "BUILTIN_MODULE": 1,
            "FROZEN_MODULE": 0,
        },
        "status": "EVIDENCE_BOUND_CLASSIFICATION_COMPLETE",
    }
    adjudication = {
        "record_type": "V26_STDLIB_SYMBOL_RESOLUTION_DEFECT_ADJUDICATION",
        "INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT": "YES",
        "COMPLETE_SYMBOL_GRAPH_CONTENT_DEFECT": "NO",
        "CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_SEMANTICS_DEFECT": "YES_IN_INDEPENDENT_VALIDATOR",
        "INDEPENDENT_VALIDATION_ENVIRONMENT_DEFECT": "NO",
        "LOADER_ORIGIN_CLASSIFICATION_DEFECT": "YES_IN_INDEPENDENT_VALIDATOR",
        "SYMBOL_BINDING_METADATA_DEFECT": "NO",
        "CAUSE": "ESTABLISHED",
        "cause_detail": (
            "Independent validation applies the canonical local-module binding gate and V26/src-only "
            "PathFinder semantics to standard-library modules. It therefore records MODULE_UNRESOLVABLE "
            "without using typed pure-Python, built-in, frozen, or extension-module identity semantics."
        ),
        "symbol_count_equality_sufficient": False,
        "canonical_predecessor_defect": "NO_EVIDENCE_OF_DEFECT",
        "typed_historical_registry_defect": "NO_EVIDENCE_OF_DEFECT",
        "mount_output_binding_defect": "NO_EVIDENCE_OF_DEFECT",
        "python_cache_policy_defect": "NO_EVIDENCE_OF_DEFECT",
        "runtime_classifications": {
            "SecurityWorker": "NOT_ESTABLISHED", "Codex": "NOT_ESTABLISHED",
            "temporal_observer": "NOT_ESTABLISHED", "process_lineage": "NOT_PROVEN",
            "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN",
        },
    }
    contract = {
        "record_type": "TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT",
        "contract_identity": "V27_TYPED_CANONICAL_MODULE_IDENTITY_CONTRACT_V1",
        "required_module_classes": [
            "LOCAL_SOURCE_MODULE", "PURE_PYTHON_STDLIB", "BUILTIN_MODULE", "FROZEN_MODULE", "EXTENSION_MODULE"
        ],
        "required_module_fields": [
            "logical_module_identity", "module_category", "expected_import_name",
            "expected_module_origin", "expected_loader_identity", "runtime_identity",
        ],
        "source_digest_rule": {
            "LOCAL_SOURCE_MODULE": "EXACT_SOURCE_DIGEST_REQUIRED",
            "PURE_PYTHON_STDLIB": "EXACT_SOURCE_DIGEST_REQUIRED",
            "EXTENSION_MODULE": "EXACT_BINARY_DIGEST_REQUIRED",
            "BUILTIN_MODULE": "NO_NORMAL_SOURCE_ARTIFACT;BIND_EXACT_RUNTIME_AND_BUILTIN_ORIGIN",
            "FROZEN_MODULE": "NO_NORMAL_SOURCE_ARTIFACT;BIND_EXACT_RUNTIME_AND_FROZEN_ORIGIN",
        },
        "per_symbol_equivalence": "EXACT_ROW_IDENTITY_REQUIRED",
        "count_only_equivalence": "PROHIBITED",
        "shadow_resolution": "FAIL_CLOSED",
        "wrong_origin_or_loader": "FAIL_CLOSED",
    }
    regressions = {
        "record_type": "V27_STDLIB_SYMBOL_RESOLUTION_REGRESSION_MATRIX",
        "required_cases": [
            "PURE_PYTHON_STDLIB", "BUILTIN_MODULE", "FROZEN_MODULE", "EXTENSION_MODULE",
            "MODULE_SHADOWING", "MISSING_EXPORTED_SYMBOL", "SAME_COUNT_DIFFERENT_ROWS",
            "WRONG_MODULE_ORIGIN", "WRONG_LOADER_CLASS", "EXACT_CANONICAL_91_OF_91_EQUIVALENCE",
        ],
        "acceptance": "ONLY_TYPED_EXACT_IDENTITY_AND_91_OF_91_ROW_EQUIVALENCE_PASSES",
    }
    successor = {
        "record_type": "SUCCESSOR_V27_REQUIREMENTS",
        "successor_identity": V27_IDENTITY,
        "authorization_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "normative_contract": "TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json",
        "requirements": [
            "FRESH_WORKSPACE_AND_EXECUTION_IDENTITY",
            "TYPED_MODULE_IDENTITIES_FOR_LOCAL_PURE_PYTHON_BUILTIN_FROZEN_AND_EXTENSION_MODULES",
            "PRIMARY_AND_INDEPENDENT_RESOLUTION_USING_INDEPENDENT_IMPLEMENTATIONS",
            "EXACT_PER_SYMBOL_PER_MODULE_EQUIVALENCE_NOT_COUNT_EQUALITY",
            "EXACT_RUNTIME_ORIGIN_LOADER_AND_DIGEST_BINDING_BY_MODULE_CLASS",
            "ALL_V1_TO_V26_CONTROLS_CARRIED_FORWARD_UNLESS_SEPARATELY_ADJUDICATED",
            "UNIT_PRIMARY_INDEPENDENT_PREFLIGHT_CLOSURE_LOCK_AND_POSTLOCK_CHAIN_BEFORE_ATTEMPT",
            "ONE_SHOT_ONLY_IF_EVERY_GATE_PASSES",
        ],
        "prohibitions": ["PATCH_OR_RETRY_V26", "INFER_MODULE_CLASS_FROM_FILENAME_ONLY", "COUNT_ONLY_GRAPH_PASS"],
    }
    decision = {
        "record_type": "V26_TERMINAL_AND_V27_SUCCESSOR_DECISION",
        "V26": "TERMINAL_IMMUTABLE_NO_RETRY",
        "V27": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "V26_CONTINUATION": "PROHIBITED",
        "reason": "V26 is already terminal and frozen; correction requires a distinct execution identity.",
    }
    authority = {
        "record_type": "V26_GOVERNANCE_AUTHORITY_CEILING",
        "allowed": ["READ_FROZEN_V26_EVIDENCE", "CREATE_AND_VALIDATE_THIS_GOVERNANCE_PACKAGE"],
        "prohibited": charter["prohibitions"],
        "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
    }
    routing = {
        "record_type": "GOVERNANCE_ROUTING_LEDGER",
        "ACTIVE": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness"],
        "DEFERRED": ["V27_ENGINEERING_UNTIL_GOVERNANCE_FREEZE_PASS"],
        "NOT_APPLICABLE": ["target", "network", "credentials", "external-tools", "subagents", "parallelism", "promotion", "submission"],
    }
    milestone = {
        "record_type": "NEXT_LEGAL_MILESTONE",
        "only_if_governance_pass_locked": "IMPLEMENT_FRESH_V27_TYPED_STANDARD_LIBRARY_MODULE_IDENTITY_MODEL",
        "not_authorized_now": ["CREATE_V27", "EXECUTE_V27", "PATCH_V26"],
    }
    artifacts = {
        "GOVERNANCE_CHARTER.json": charter,
        "V26_FROZEN_FAILURE_EVIDENCE_BINDING.json": frozen_binding,
        "STANDARD_LIBRARY_SYMBOL_RESOLUTION_INCIDENT.json": incident,
        "NINE_UNRESOLVED_STANDARD_LIBRARY_BINDINGS.json": classification,
        "INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT_ADJUDICATION.json": adjudication,
        "TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json": contract,
        "V27_STANDARD_LIBRARY_SYMBOL_RESOLUTION_REGRESSION_MATRIX.json": regressions,
        "SUCCESSOR_V27_REQUIREMENTS.json": successor,
        "V26_TERMINAL_AND_V27_SUCCESSOR_DECISION.json": decision,
        "V26_IMMUTABILITY_AND_AUTHORITY_CEILING.json": authority,
        "ROUTING_LEDGER.json": routing,
        "NEXT_LEGAL_MILESTONE.json": milestone,
    }
    for name, payload in artifacts.items():
        write_once(ROOT / name, payload)
    print({"status": "BUILT", "artifacts": len(artifacts)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
