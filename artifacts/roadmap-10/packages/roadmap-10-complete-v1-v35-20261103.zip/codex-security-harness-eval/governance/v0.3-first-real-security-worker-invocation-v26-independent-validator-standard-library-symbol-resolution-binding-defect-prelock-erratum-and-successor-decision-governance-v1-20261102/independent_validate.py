"""Independent governance validation from frozen V26 evidence."""

from __future__ import annotations

import importlib.util
from pathlib import Path

from governance_common import EXPECTED_FAILURE, ROOT, expected_unresolved, load, sha256, verify_v26_frozen, v26_paths, write_once


def classify(module: str) -> tuple[str, str | None, str]:
    spec = importlib.util.find_spec(module)
    if spec is None:
        return "UNRESOLVED", None, "NONE"
    if spec.origin == "built-in":
        return "BUILTIN_MODULE", spec.origin, "_frozen_importlib.BuiltinImporter"
    if spec.origin == "frozen":
        return "FROZEN_MODULE", spec.origin, "_frozen_importlib.FrozenImporter"
    if spec.origin and spec.origin.endswith(".so"):
        return "EXTENSION_MODULE", spec.origin, "_frozen_importlib_external.ExtensionFileLoader"
    return "PURE_PYTHON_STDLIB", spec.origin, "_frozen_importlib_external.SourceFileLoader"


def main() -> int:
    checks = []

    def check(identity: str, condition: bool, evidence=None) -> None:
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    frozen = verify_v26_frozen()
    check("I001_V26_FROZEN", frozen["status"] == "PASS", frozen)
    paths = v26_paths()
    symbol_manifest = load(paths["symbols"])
    independent = load(paths["independent"])
    failed = next(row for row in independent["checks"] if row["id"] == EXPECTED_FAILURE)
    failure_pairs = [(row["symbol"], row["module"]) for row in failed["evidence"]["failures"]]
    check("I002_NINE_FAILURES", failure_pairs == expected_unresolved(), failure_pairs)
    check("I003_EQUAL_COUNTS_NOT_PASS", failed["evidence"]["independent_symbol_count"] == failed["evidence"]["manifest_symbol_count"] == 91 and failed["status"] == "FAIL")
    classified = load(ROOT / "NINE_UNRESOLVED_STANDARD_LIBRARY_BINDINGS.json")
    rows = classified.get("bindings", [])
    check("I004_CLASSIFICATION_COUNT", len(rows) == 9)
    for index, row in enumerate(rows, 5):
        category, origin, loader = classify(row["expected_module_identity"])
        check(
            f"I{index:03d}_{row['symbol_name']}",
            category == row.get("module_category")
            and origin == row.get("expected_module_origin")
            and loader == row.get("expected_loader_identity")
            and row.get("actual_independent_validator_module_spec") is None
            and row.get("exact_resolution_failure", {}).get("reason") == "MODULE_UNRESOLVABLE",
        )
    source = paths["independent_source"].read_text(encoding="utf-8")
    algorithm_exact = (
        'bound=module_rows.get(module)' in source
        and 'PathFinder.find_spec(module,[str(package_root)]) if bound else None' in source
        and '"reason":"MODULE_UNRESOLVABLE"' in source
    )
    check("I014_CAUSAL_SOURCE", algorithm_exact)
    adjudication = load(ROOT / "INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT_ADJUDICATION.json")
    check("I015_DEFECT_DECISION", adjudication.get("INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT") == "YES")
    check("I016_CONTENT_DECISION", adjudication.get("COMPLETE_SYMBOL_GRAPH_CONTENT_DEFECT") == "NO")
    contract = load(ROOT / "TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json")
    check("I017_TYPED_CONTRACT", contract.get("count_only_equivalence") == "PROHIBITED" and len(contract.get("required_module_classes", [])) == 5)
    decision = load(ROOT / "V26_TERMINAL_AND_V27_SUCCESSOR_DECISION.json")
    check("I018_TERMINAL_SUCCESSOR", decision.get("V26") == "TERMINAL_IMMUTABLE_NO_RETRY" and decision.get("V27") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    primary = load(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I019_PRIMARY_PASS", primary.get("status") == "PASS")
    check("I020_NEGATIVE_PASS", negative.get("status") == "PASS")
    check("I021_V27_ABSENT", not any(ROOT.parent.parent.parent.glob("v0.3-first-real-security-worker-invocation-v27-*")))
    failures = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {
        "record_type": "V26_STDLIB_SYMBOL_RESOLUTION_INDEPENDENT_GOVERNANCE_VALIDATION",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
    }
    write_once(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(result["validation_counts"])
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
