"""Freeze the validated governance package append-only."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path

from governance_common import IDENTITY, ROOT, canonical_sha256, load, sha256, verify_v26_frozen, write_once


EXCLUDED = {
    "GOVERNANCE_ARTIFACT_MANIFEST.json",
    "GOVERNANCE_LOCK.json",
    "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",
}


def main() -> int:
    primary = load(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = load(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    if not all(row.get("status") == "PASS" for row in (primary, negative, independent)):
        raise RuntimeError("all governance validation families must pass")
    if verify_v26_frozen()["status"] != "PASS":
        raise RuntimeError("V26 frozen integrity failed before governance freeze")
    members = []
    for path in sorted(item for item in ROOT.iterdir() if item.is_file() and item.name not in EXCLUDED):
        members.append({
            "path": path.name,
            "sha256": sha256(path),
            "bytes": path.stat().st_size,
            "required_mode": "0444",
        })
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    root_digest = hashlib.sha256(rows.encode()).hexdigest()
    manifest = {
        "record_type": "V26_STDLIB_SYMBOL_RESOLUTION_GOVERNANCE_ARTIFACT_MANIFEST",
        "governance_identity": IDENTITY,
        "member_count": len(members),
        "canonical_governance_root_sha256": root_digest,
        "members": members,
    }
    write_once(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    lock = {
        "record_type": "V26_STDLIB_SYMBOL_RESOLUTION_GOVERNANCE_LOCK",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "canonical_governance_root_sha256": root_digest,
        "governance_artifact_manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "primary_governance_validation_sha256": sha256(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"),
        "negative_governance_fixtures_sha256": sha256(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json"),
        "independent_governance_validation_sha256": sha256(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json"),
        "INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT": "YES",
        "COMPLETE_SYMBOL_GRAPH_CONTENT_DEFECT": "NO",
        "V26": "TERMINAL_IMMUTABLE_NO_RETRY",
        "V27": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "attempt_count": 0,
        "worker_invocation_count": 0,
        "codex_as_worker_invocation_count": 0,
    }
    write_once(ROOT / "GOVERNANCE_LOCK.json", lock)
    for row in members:
        os.chmod(ROOT / row["path"], 0o444)
    os.chmod(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", 0o444)
    os.chmod(ROOT / "GOVERNANCE_LOCK.json", 0o444)
    print({"status": lock["status"], "members": len(members), "root": root_digest})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
