"""Shared deterministic helpers for the V26 governance-only adjudication."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any, Mapping


ROOT = Path(__file__).resolve().parent
V26 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v26-20261102")
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V26_INDEPENDENT_VALIDATOR_"
    "STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT_PRELOCK_ERRATUM_AND_"
    "SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
V26_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V26"
V27_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V27"
V26_ROOT = "1ff032bc531076421e45a311ede68e3593910a1e15dd868d0b3a50422ff2ac0b"
V26_TERMINAL_SHA = "4042cf6b95b39fb6c5e8071bb92503d13021c200e08dc0e38b34061f2600837d"
V26_MANIFEST_SHA = "17d3c2a05562a2ad2cdcf718dd96326f6efc96291e24b84829501269e96ce258"
V26_FREEZE_SHA = "80ccc986e12f77c826f3c9a3e3be0fcb10b5db5df5ad32522943580c76e8d8d5"
EXPECTED_STATUS = (
    "FAIL_CLOSED_DURING_INDEPENDENT_STATIC_VALIDATION_PRELOCK_TERMINAL_"
    "NO_RETRY_FROZEN_FAILURE_EVIDENCE"
)
EXPECTED_FAILURE = "I020C_COMPLETE_SYMBOL_GRAPH"
PYTHON = Path("/usr/bin/python3.14")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_sha256(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_once(path: Path, value: Any) -> None:
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"append-only output exists: {path}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def v26_paths() -> dict[str, Path]:
    pre = V26 / "results/prelock"
    return {
        "terminal": pre / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
        "manifest": pre / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
        "freeze": pre / "PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
        "unit": pre / "unit-fixtures-run-0001.json",
        "primary": pre / "primary-static-validation-run-0001.json",
        "independent": pre / "independent-static-validation-run-0001.json",
        "symbols": V26 / "contracts/LOCKED_ENTRYPOINT_SYMBOL_BINDING_MANIFEST.json",
        "independent_source": V26 / "validators/independent_static_validate.py",
    }


def verify_v26_frozen() -> dict[str, Any]:
    paths = v26_paths()
    terminal = load(paths["terminal"])
    manifest = load(paths["manifest"])
    freeze = load(paths["freeze"])
    independent = load(paths["independent"])
    members = manifest.get("members", [])
    member_checks = []
    for row in members:
        path = paths["manifest"].parent / row.get("path", "")
        member_checks.append(
            path.is_file()
            and not path.is_symlink()
            and sha256(path) == row.get("sha256")
            and path.stat().st_size == row.get("bytes")
            and stat.S_IMODE(path.stat().st_mode) == 0o444
        )
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    root = hashlib.sha256(rows.encode()).hexdigest()
    checks = {
        "terminal_digest": sha256(paths["terminal"]) == V26_TERMINAL_SHA,
        "manifest_digest": sha256(paths["manifest"]) == V26_MANIFEST_SHA,
        "freeze_digest": sha256(paths["freeze"]) == V26_FREEZE_SHA,
        "evidence_root": root == manifest.get("canonical_evidence_root_sha256") == V26_ROOT,
        "member_count": len(members) == manifest.get("member_count") == 103,
        "members_read_only_exact": bool(member_checks) and all(member_checks),
        "prelock_root_read_only": stat.S_IMODE(paths["manifest"].parent.stat().st_mode) == 0o555,
        "terminal_state": terminal.get("status") == EXPECTED_STATUS,
        "unit": terminal.get("unit", {}).get("passed") == 314 and terminal.get("unit", {}).get("failed") == 0,
        "primary": terminal.get("primary", {}).get("passed") == 88 and terminal.get("primary", {}).get("failed") == 0,
        "independent": terminal.get("independent", {}).get("passed") == 101 and terminal.get("independent", {}).get("failed") == 1,
        "failed_gate": terminal.get("failure_ids") == [EXPECTED_FAILURE] == independent.get("failure_ids"),
        "no_static_lock": not (V26 / "STATIC_EXECUTION_LOCK.json").exists(),
        "no_attempt": not (V26 / "static-run-v26/attempt-marker-0001.json").exists(),
        "no_runtime": not (V26 / "static-run-v26/runtime-result-0001.json").exists(),
    }
    return {
        "record_type": "V26_FROZEN_FAILURE_EVIDENCE_VERDICT",
        "checks": checks,
        "member_count": len(members),
        "canonical_evidence_root_sha256": root,
        "status": "PASS" if all(checks.values()) else "FAIL_CLOSED",
    }


def expected_unresolved() -> list[tuple[str, str]]:
    return [
        ("Any", "typing"),
        ("Path", "pathlib"),
        ("argparse", "argparse"),
        ("datetime", "datetime"),
        ("json", "json"),
        ("resource", "resource"),
        ("subprocess", "subprocess"),
        ("time", "time"),
        ("timezone", "datetime"),
    ]


def module_identity_verdict(row: Mapping[str, Any]) -> dict[str, Any]:
    category = row.get("module_category")
    origin = row.get("expected_module_origin")
    loader = row.get("expected_loader_identity")
    digest = row.get("expected_source_sha256")
    checks = {
        "category_supported": category in {
            "PURE_PYTHON_STDLIB", "BUILTIN_MODULE", "FROZEN_MODULE", "EXTENSION_MODULE"
        },
        "logical_identity": isinstance(row.get("logical_module_identity"), str)
        and row.get("logical_module_identity", "").startswith("PYTHON_3_14_STDLIB::"),
        "import_name": row.get("expected_import_name") == row.get("expected_module_identity"),
        "symbol_present": isinstance(row.get("symbol_name"), str) and bool(row.get("symbol_name")),
        "origin_semantics": (
            category == "BUILTIN_MODULE" and origin == "built-in" and digest is None
        ) or (
            category == "FROZEN_MODULE" and origin == "frozen" and digest is None
        ) or (
            category == "PURE_PYTHON_STDLIB"
            and isinstance(origin, str) and origin.endswith(".py")
            and isinstance(digest, str) and len(digest) == 64
        ) or (
            category == "EXTENSION_MODULE"
            and isinstance(origin, str) and origin.endswith(".so")
            and isinstance(digest, str) and len(digest) == 64
        ),
        "loader_semantics": (
            category == "PURE_PYTHON_STDLIB" and loader.endswith(".SourceFileLoader")
        ) or (
            category == "EXTENSION_MODULE" and loader.endswith(".ExtensionFileLoader")
        ) or (
            category == "BUILTIN_MODULE" and loader == "_frozen_importlib.BuiltinImporter"
        ) or (
            category == "FROZEN_MODULE" and loader == "_frozen_importlib.FrozenImporter"
        ),
    }
    return {"checks": checks, "status": "PASS" if all(checks.values()) else "FAIL_CLOSED"}


def graph_equivalence(left: list[Mapping[str, Any]], right: list[Mapping[str, Any]]) -> bool:
    fields = (
        "symbol", "defining_module", "expected_imported_name", "expected_alias",
        "expected_import_or_binding", "call_or_reference_sites",
    )
    normalize = lambda rows: {
        row.get("symbol"): {field: row.get(field) for field in fields} for row in rows
    }
    return len(left) == len(right) and normalize(left) == normalize(right)

