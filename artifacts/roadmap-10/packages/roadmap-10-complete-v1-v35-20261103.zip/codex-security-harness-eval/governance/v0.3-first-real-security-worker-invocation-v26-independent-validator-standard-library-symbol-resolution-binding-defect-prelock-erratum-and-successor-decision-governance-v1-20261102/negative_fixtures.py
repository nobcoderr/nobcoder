"""Negative and positive fixtures for typed standard-library module identities."""

from __future__ import annotations

from copy import deepcopy

from governance_common import ROOT, graph_equivalence, module_identity_verdict, write_once


def base(category: str, origin: str, loader: str, digest: str | None) -> dict:
    return {
        "logical_module_identity": "PYTHON_3_14_STDLIB::fixture",
        "module_category": category,
        "expected_module_identity": "fixture",
        "expected_import_name": "fixture",
        "symbol_name": "symbol",
        "expected_module_origin": origin,
        "expected_loader_identity": loader,
        "expected_source_sha256": digest,
    }


def main() -> int:
    digest = "a" * 64
    pure = base("PURE_PYTHON_STDLIB", "/usr/lib/python3.14/fixture.py", "_frozen_importlib_external.SourceFileLoader", digest)
    builtin = base("BUILTIN_MODULE", "built-in", "_frozen_importlib.BuiltinImporter", None)
    frozen = base("FROZEN_MODULE", "frozen", "_frozen_importlib.FrozenImporter", None)
    extension = base("EXTENSION_MODULE", "/usr/lib/python3.14/lib-dynload/fixture.so", "_frozen_importlib_external.ExtensionFileLoader", digest)
    symbol_row = {
        "symbol": "x", "defining_module": "fixture", "expected_imported_name": "x",
        "expected_alias": "x", "expected_import_or_binding": "FROM_IMPORT", "call_or_reference_sites": [1],
    }
    cases = []

    def add(identity: str, observed: bool, expected: bool) -> None:
        cases.append({"id": identity, "observed_pass": observed, "expected_pass": expected, "status": "PASS" if observed == expected else "FAIL"})

    add("N001_PURE_PYTHON_STDLIB", module_identity_verdict(pure)["status"] == "PASS", True)
    add("N002_BUILTIN_MODULE", module_identity_verdict(builtin)["status"] == "PASS", True)
    add("N003_FROZEN_MODULE", module_identity_verdict(frozen)["status"] == "PASS", True)
    add("N004_EXTENSION_MODULE", module_identity_verdict(extension)["status"] == "PASS", True)
    shadow = deepcopy(pure); shadow["expected_module_origin"] = "/tmp/shadow/fixture.py"
    add("N005_MODULE_SHADOWING", shadow["expected_module_origin"] == pure["expected_module_origin"], False)
    missing = deepcopy(pure); missing["symbol_name"] = ""
    add("N006_MISSING_EXPORTED_SYMBOL", module_identity_verdict(missing)["status"] == "PASS", False)
    different = deepcopy(symbol_row); different["defining_module"] = "other"
    add("N007_SAME_COUNT_DIFFERENT_ROWS", graph_equivalence([symbol_row], [different]), False)
    wrong_origin = deepcopy(builtin); wrong_origin["expected_module_origin"] = "/usr/lib/python3.14/time.py"
    add("N008_WRONG_MODULE_ORIGIN", module_identity_verdict(wrong_origin)["status"] == "PASS", False)
    wrong_loader = deepcopy(extension); wrong_loader["expected_loader_identity"] = "_frozen_importlib_external.SourceFileLoader"
    add("N009_WRONG_LOADER_CLASS", module_identity_verdict(wrong_loader)["status"] == "PASS", False)
    add("N010_EXACT_ROW_EQUIVALENCE", graph_equivalence([symbol_row], [deepcopy(symbol_row)]), True)
    matrix = {
        "record_type": "V26_GOVERNANCE_NEGATIVE_TEST_MATRIX",
        "cases": [{"id": row["id"], "expected_pass": row["expected_pass"]} for row in cases],
    }
    result = {
        "record_type": "V26_GOVERNANCE_NEGATIVE_TEST_RESULT",
        "status": "PASS" if all(row["status"] == "PASS" for row in cases) else "FAIL_CLOSED",
        "cases": cases,
        "validation_counts": {"total": len(cases), "passed": sum(row["status"] == "PASS" for row in cases), "failed": sum(row["status"] != "PASS" for row in cases)},
    }
    write_once(ROOT / "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", matrix)
    write_once(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", result)
    print(result["validation_counts"])
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
