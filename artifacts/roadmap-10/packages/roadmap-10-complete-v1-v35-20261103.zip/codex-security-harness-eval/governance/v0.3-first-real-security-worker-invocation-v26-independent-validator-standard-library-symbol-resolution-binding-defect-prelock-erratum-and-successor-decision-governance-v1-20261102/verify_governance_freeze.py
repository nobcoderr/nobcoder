"""Final independent read-only/freeze integrity verifier."""

from __future__ import annotations

import hashlib
import os
import stat

from governance_common import ROOT, load, sha256, verify_v26_frozen, write_once


def main() -> int:
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    lock_path = ROOT / "GOVERNANCE_LOCK.json"
    out = ROOT / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
    manifest = load(manifest_path)
    lock = load(lock_path)
    checks = []

    def check(identity: str, condition: bool, evidence=None) -> None:
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    members = manifest.get("members", [])
    member_results = []
    for row in members:
        path = ROOT / row.get("path", "")
        ok = (
            path.is_file() and not path.is_symlink()
            and sha256(path) == row.get("sha256")
            and path.stat().st_size == row.get("bytes")
            and stat.S_IMODE(path.stat().st_mode) == 0o444
        )
        member_results.append(ok)
    rows = "".join(f"{row['sha256']}  {row['path']}\n" for row in members)
    root_digest = hashlib.sha256(rows.encode()).hexdigest()
    check("F001_MEMBER_DIGESTS_MODES", bool(member_results) and all(member_results), {"total": len(member_results), "passed": sum(member_results)})
    check("F002_CANONICAL_ROOT", root_digest == manifest.get("canonical_governance_root_sha256") == lock.get("canonical_governance_root_sha256"))
    check("F003_MANIFEST_LOCK", sha256(manifest_path) == lock.get("governance_artifact_manifest_sha256") and stat.S_IMODE(manifest_path.stat().st_mode) == stat.S_IMODE(lock_path.stat().st_mode) == 0o444)
    check("F004_VALIDATION_DIGESTS", sha256(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json") == lock.get("primary_governance_validation_sha256") and sha256(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json") == lock.get("negative_governance_fixtures_sha256") and sha256(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json") == lock.get("independent_governance_validation_sha256"))
    check("F005_DECISIONS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY" and lock.get("INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT") == "YES" and lock.get("COMPLETE_SYMBOL_GRAPH_CONTENT_DEFECT") == "NO")
    check("F006_V26_FROZEN", verify_v26_frozen()["status"] == "PASS")
    check("F007_NO_EXECUTION", lock.get("attempt_count") == lock.get("worker_invocation_count") == lock.get("codex_as_worker_invocation_count") == 0)
    check("F008_V27_ABSENT", not any(ROOT.parent.parent.parent.glob("v0.3-first-real-security-worker-invocation-v27-*")))
    failures = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {
        "record_type": "V26_STDLIB_SYMBOL_RESOLUTION_FINAL_FREEZE_VERIFICATION",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "governance_status": lock.get("status") if not failures else "NOT_LOCKED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
        "canonical_governance_root_sha256": root_digest,
        "governance_lock_sha256": sha256(lock_path),
    }
    write_once(out, result)
    os.chmod(out, 0o444)
    os.chmod(ROOT, 0o555)
    print({"status": result["status"], "governance_lock_sha256": result["governance_lock_sha256"]})
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
