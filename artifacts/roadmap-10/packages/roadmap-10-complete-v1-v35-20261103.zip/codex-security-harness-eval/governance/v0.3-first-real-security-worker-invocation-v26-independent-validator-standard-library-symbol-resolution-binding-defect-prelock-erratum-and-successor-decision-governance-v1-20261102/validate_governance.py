"""Primary governance validator."""

from __future__ import annotations

from governance_common import (
    EXPECTED_FAILURE, EXPECTED_STATUS, ROOT, V26_IDENTITY, expected_unresolved,
    load, module_identity_verdict, verify_v26_frozen, write_once,
)


def main() -> int:
    checks: list[dict] = []

    def check(identity: str, condition: bool, evidence=None) -> None:
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    frozen = verify_v26_frozen()
    check("G001_V26_FROZEN", frozen["status"] == "PASS", frozen)
    charter = load(ROOT / "GOVERNANCE_CHARTER.json")
    binding = load(ROOT / "V26_FROZEN_FAILURE_EVIDENCE_BINDING.json")
    incident = load(ROOT / "STANDARD_LIBRARY_SYMBOL_RESOLUTION_INCIDENT.json")
    classified = load(ROOT / "NINE_UNRESOLVED_STANDARD_LIBRARY_BINDINGS.json")
    adjudication = load(ROOT / "INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT_ADJUDICATION.json")
    contract = load(ROOT / "TYPED_CANONICAL_STANDARD_LIBRARY_MODULE_IDENTITY_CONTRACT.json")
    regressions = load(ROOT / "V27_STANDARD_LIBRARY_SYMBOL_RESOLUTION_REGRESSION_MATRIX.json")
    successor = load(ROOT / "SUCCESSOR_V27_REQUIREMENTS.json")
    decision = load(ROOT / "V26_TERMINAL_AND_V27_SUCCESSOR_DECISION.json")
    authority = load(ROOT / "V26_IMMUTABILITY_AND_AUTHORITY_CEILING.json")
    check("G002_CHARTER_GOVERNANCE_ONLY", charter.get("scope") == "GOVERNANCE_ONLY_READ_ONLY_V26_ADJUDICATION")
    check("G003_V26_STATE", binding.get("terminal_status") == EXPECTED_STATUS and binding.get("failed_gate") == EXPECTED_FAILURE)
    check("G004_COUNTS", binding.get("unit") == "314/314 PASS" and binding.get("primary") == "88/88 PASS" and binding.get("independent") == "101/102 FAIL_CLOSED")
    check("G005_NO_EXECUTION", binding.get("static_lock") == "NOT_ISSUED" and binding.get("attempt") == binding.get("worker") == binding.get("codex") == "0/1")
    check("G006_INCIDENT_COUNTS", incident.get("authoritative_symbol_count") == incident.get("independent_symbol_count") == 91 and incident.get("unresolved_binding_count") == 9)
    rows = classified.get("bindings", [])
    pairs = [(row.get("symbol_name"), row.get("expected_module_identity")) for row in rows]
    check("G007_NINE_BINDINGS", classified.get("binding_count") == len(rows) == 9 and pairs == expected_unresolved())
    check("G008_TYPED_ROWS", all(module_identity_verdict(row)["status"] == "PASS" for row in rows))
    check("G009_CATEGORY_COUNTS", classified.get("category_counts") == {"PURE_PYTHON_STDLIB": 7, "EXTENSION_MODULE": 1, "BUILTIN_MODULE": 1, "FROZEN_MODULE": 0})
    check("G010_DEFECT_YES", adjudication.get("INDEPENDENT_VALIDATOR_STANDARD_LIBRARY_SYMBOL_RESOLUTION_BINDING_DEFECT") == "YES")
    check("G011_CONTENT_DEFECT_NO", adjudication.get("COMPLETE_SYMBOL_GRAPH_CONTENT_DEFECT") == "NO")
    check("G012_CAUSE_ESTABLISHED", adjudication.get("CAUSE") == "ESTABLISHED" and adjudication.get("INDEPENDENT_VALIDATION_ENVIRONMENT_DEFECT") == "NO")
    check("G013_RUNTIME_NOT_ESTABLISHED", set(adjudication.get("runtime_classifications", {}).values()) <= {"NOT_ESTABLISHED", "NOT_PROVEN"})
    classes = set(contract.get("required_module_classes", []))
    check("G014_TYPED_CONTRACT_CLASSES", {"LOCAL_SOURCE_MODULE", "PURE_PYTHON_STDLIB", "BUILTIN_MODULE", "FROZEN_MODULE", "EXTENSION_MODULE"} <= classes)
    check("G015_COUNT_ONLY_PROHIBITED", contract.get("count_only_equivalence") == "PROHIBITED" and contract.get("per_symbol_equivalence") == "EXACT_ROW_IDENTITY_REQUIRED")
    required_cases = set(regressions.get("required_cases", []))
    check("G016_REGRESSION_MATRIX", {"PURE_PYTHON_STDLIB", "BUILTIN_MODULE", "FROZEN_MODULE", "EXTENSION_MODULE", "MODULE_SHADOWING", "MISSING_EXPORTED_SYMBOL", "SAME_COUNT_DIFFERENT_ROWS", "WRONG_MODULE_ORIGIN", "WRONG_LOADER_CLASS", "EXACT_CANONICAL_91_OF_91_EQUIVALENCE"} == required_cases)
    check("G017_V26_TERMINAL", decision.get("V26") == "TERMINAL_IMMUTABLE_NO_RETRY" and decision.get("V26_CONTINUATION") == "PROHIBITED")
    check("G018_V27_CONDITIONAL", decision.get("V27") == successor.get("authorization_state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("G019_AUTHORITY_CEILING", authority.get("attempt_count") == authority.get("worker_invocation_count") == authority.get("codex_as_worker_invocation_count") == 0)
    check("G020_NO_V27_WORKSPACE", not any(ROOT.parent.parent.parent.glob("v0.3-first-real-security-worker-invocation-v27-*")))
    failed = [row["id"] for row in checks if row["status"] != "PASS"]
    result = {
        "record_type": "V26_STDLIB_SYMBOL_RESOLUTION_PRIMARY_GOVERNANCE_VALIDATION",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failed,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
    }
    write_once(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(result["validation_counts"])
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
