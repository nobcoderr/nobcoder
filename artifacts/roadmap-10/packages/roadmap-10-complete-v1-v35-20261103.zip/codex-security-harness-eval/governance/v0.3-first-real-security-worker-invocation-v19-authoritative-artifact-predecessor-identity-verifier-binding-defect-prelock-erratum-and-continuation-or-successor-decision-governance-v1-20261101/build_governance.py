#!/usr/bin/env python3
from governance_common import *

def main() -> None:
    assert_v19_frozen()
    authority = authority_facts()
    components = binding_component_facts()
    if authority != {
        "governance_lock_sha256": V18_GOVERNANCE_LOCK_SHA256,
        "successor_decision_sha256": V18_SUCCESSOR_DECISION_SHA256,
        "decision": "TERMINALIZE_V18_AND_AUTHORIZE_DISTINCT_V19_CONDITIONALLY",
        "predecessor_identity": V18_IDENTITY,
        "successor_identity": V19_IDENTITY,
    }:
        raise SystemExit(f"unexpected frozen predecessor authority: {authority}")
    evidence = [{"path": p.relative_to(V19 / "results/prelock").as_posix(), "sha256": sha256_file(p), "bytes": p.stat().st_size, "mode": oct(p.stat().st_mode & 0o777)} for p in evidence_members()]
    documents = {
        "GOVERNANCE_CHARTER.json": {
            "governance_identity": GOVERNANCE_ID, "milestone_type": "GOVERNANCE_ONLY",
            "authorized_actions": ["READ_V18_V19_FROZEN_EVIDENCE", "ADJUDICATE", "VALIDATE_GOVERNANCE", "FREEZE_GOVERNANCE"],
            "prohibited_actions": ["PATCH_RERUN_DUPLICATE_RELOCK_OR_EXECUTE_V19", "CREATE_OR_EXECUTE_V20", "SECURITY_WORKER_INVOCATION", "CODEX_INVOCATION"],
            "freeze_condition": "PRIMARY_AND_NEGATIVE_AND_INDEPENDENT_AND_READ_ONLY_AND_FINAL_FREEZE_VERIFICATION_ALL_PASS",
        },
        "V19_FROZEN_FAILURE_EVIDENCE_BINDING.json": {
            "execution_identity": V19_IDENTITY,
            "disposition": "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE",
            "static_lock": "NOT_ISSUED", "attempt": "0_OF_1", "worker_invocation": "0_OF_1", "codex_as_worker_invocation": "0_OF_1",
            "workspace_member_count": V19_MEMBER_COUNT, "workspace_tree_root_sha256": V19_TREE_ROOT,
            "prelock_member_count": V19_PRELOCK_MEMBER_COUNT, "prelock_tree_root_sha256": V19_PRELOCK_ROOT,
            "bound_hashes": V19_HASHES, "members": evidence,
        },
        "PREDECESSOR_BINDING_COMPONENT_COMPARISON.json": {
            "authority_source": {"governance_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V18_LOCKED_RUNNER_CANONICALIZATION_PRECHECK_IMPORT_BINDING_DEFECT_POST_LOCK_PRE_ATTEMPT_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY", **authority},
            "components": components,
            "all_execution_readiness_components_same_predecessor": False,
            "required_resolution": "ALL_COMPONENTS_MUST_INDEPENDENTLY_RESOLVE_EXACT_GOVERNANCE_BOUND_V18_IDENTITY_AND_DIGEST",
        },
        "AUTHORITATIVE_ARTIFACT_PREDECESSOR_BINDING_DEFECT_ADJUDICATION.json": {
            "AUTHORITATIVE_ARTIFACT_PREDECESSOR_IDENTITY_VERIFIER_BINDING_DEFECT": "YES",
            "governance_authorized_predecessor": V18_IDENTITY,
            "builder_predecessor": V18_IDENTITY,
            "verifier_predecessor": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V17",
            "defect_ownership": "V19_AUTHORITATIVE_ARTIFACT_PREDECESSOR_RELATION_VERIFICATION",
            "causal_evidence": "BUILDER_V18_VERIFIER_V17_EXACT_SOURCE_BINDING_MISMATCH",
            "runtime_adjudication": {"security_worker": "NOT_ESTABLISHED", "codex": "NOT_ESTABLISHED", "temporal_observer": "NOT_ESTABLISHED", "process_lineage": "NOT_PROVEN", "producer_authorization": "NOT_PROVEN", "confinement": "NOT_PROVEN"},
        },
        "V19_TERMINAL_AND_V20_SUCCESSOR_DECISION.json": {
            "decision": DECISION,
            "v19": "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE",
            "v19_continuation": "PROHIBITED", "v19_mutation_allowlist": [], "v19_retry": "PROHIBITED", "v19_duplicate_identity": "PROHIBITED",
            "v20": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED", "v20_attempt": "0_OF_1", "v20_worker_invocation": "0_OF_1", "v20_codex_as_worker_invocation": "0_OF_1",
            "reason": "FROZEN_TERMINAL_NO_RETRY_CONTRACT_HAS_NO_PRELOCK_CONTINUATION_EXCEPTION; CORRECTION_REQUIRES_NEW_SOURCE_AND_AUTHORITATIVE_BINDING_IDENTITY",
        },
        "CANONICAL_PREDECESSOR_BINDING_CONTRACT.json": {
            "contract_identity": "V20_CANONICAL_PREDECESSOR_BINDING_V1",
            "authority_source": {"governance_lock_sha256": V18_GOVERNANCE_LOCK_SHA256, "successor_decision_sha256": V18_SUCCESSOR_DECISION_SHA256},
            "predecessor_identity": V18_IDENTITY, "predecessor_workspace_tree_sha256": V18_TREE_ROOT,
            "resolution_order": ["READ_EXACT_GOVERNANCE_LOCK", "VERIFY_LOCK_DIGEST", "READ_EXACT_SUCCESSOR_DECISION", "VERIFY_DECISION_DIGEST", "PARSE_EXPLICIT_PREDECESSOR_AND_SUCCESSOR_IDENTITIES", "RESOLVE_EXACT_PREDECESSOR_ARTIFACT_SET", "REREAD_AND_REHASH", "BIND_COMPONENT_ATTESTATION"],
            "required_components": ["BUILDER", "PRIMARY_VALIDATOR", "INDEPENDENT_VALIDATOR", "FRESH_PREFLIGHT", "DEPENDENCY_CLOSURE", "STATIC_LOCK_PREPARATION"],
            "version_or_directory_inference": "PROHIBITED", "fallback": "PROHIBITED", "mismatch_action": "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT",
        },
        "V20_PREDECESSOR_BINDING_REGRESSION_MATRIX.json": {
            "required_cases": {
                "builder_v18_verifier_v17": "FAIL_CLOSED", "builder_v17_verifier_v18": "FAIL_CLOSED",
                "exact_governance_authorized_predecessor": "PASS", "version_number_only_inference": "FAIL_CLOSED",
                "missing_predecessor_authority": "FAIL_CLOSED", "ambiguous_predecessor_candidates": "FAIL_CLOSED",
                "stale_predecessor_binding": "FAIL_CLOSED", "exact_predecessor_artifact_digest_mismatch": "FAIL_CLOSED",
            }
        },
        "SUCCESSOR_V20_REQUIREMENTS.json": {
            "successor": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V20", "workspace": "FRESH_IDENTITY; V19_READ_ONLY_REFERENCE_ONLY",
            "canonical_predecessor_binding_contract": "REQUIRED_AND_GOVERNANCE_BOUND",
            "all_components_independently_verify_same_predecessor": True,
            "required_chain": ["UNIT", "PRIMARY", "INDEPENDENT", "FRESH_PREFLIGHT", "DEPENDENCY_CLOSURE", "STATIC_LOCK", "LOCK_VERIFICATION", "LOCKED_PREATTEMPT_DRY_WALK"],
            "carry_forward": ["V19_SYMBOL_IMPORT_DEPENDENCY_BINDING", "V16_NORMATIVE_CANONICALIZATION", "PYTHON_CACHE_POLICY", "WORKSPACE_WRITE_BOUNDARY", "A_LT_B_LT_C_LT_D_LT_E", "STRICT_N_OF_N_TEMPORAL_COVERAGE"],
            "one_shot": {"attempt": "0_TO_1_ONLY_IF_ALL_GATES_PASS", "worker": "EXACTLY_ONE", "codex": "EXACTLY_ONE", "retry": "PROHIBITED"},
            "authority_denied": ["TARGET", "CREDENTIAL", "TARGET_NETWORK", "SUBAGENT", "PARALLELISM", "PROMOTION", "SUBMISSION"],
            "maximum_outcome": "PASS_TECHNICAL_FROZEN_AWAITING_SEPARATE_ACCEPTANCE_ADJUDICATION",
        },
        "V19_IMMUTABILITY_AND_AUTHORITY_CEILING.json": {
            "v19_patch_rerun_duplicate_relock_execute": "PROHIBITED", "v19_mutation_allowlist": [],
            "v19_historical_evidence": "IMMUTABLE_APPEND_ONLY_HISTORY", "v20_creation_or_execution_during_governance": "PROHIBITED",
            "target_credential_network_subagent_parallelism_promotion_submission": "PROHIBITED",
        },
        "NEGATIVE_GOVERNANCE_TEST_MATRIX.json": {
            "cases": ["BUILDER_V18_VERIFIER_V17", "BUILDER_V17_VERIFIER_V18", "EXACT_AUTHORIZED_V18", "VERSION_ONLY_INFERENCE", "MISSING_AUTHORITY", "AMBIGUOUS_CANDIDATES", "STALE_BINDING", "DIGEST_MISMATCH", "V19_MUTATION", "V19_CONTINUATION", "CREATE_V20_DURING_GOVERNANCE", "INFER_RUNTIME_RESULT"]
        },
        "ROUTING_LEDGER.json": {
            "mandatory_auto_router": "ACTIVE", "authorized_security_autopilot": "ACTIVE_GOVERNANCE_ONLY", "codex_security_harness": "ACTIVE",
            "target_specialists": "NOT_APPLICABLE_NO_TARGET", "external_tools": "NOT_APPLICABLE", "subagents": "NOT_USED", "network_credentials": "NOT_AUTHORIZED",
        },
        "NEXT_LEGAL_MILESTONE.json": {
            "only_if_governance_pass_locked": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V20_ONCE_IF_ALL_GATES_PASS",
            "not_authorized": ["PATCH_RERUN_DUPLICATE_RELOCK_EXECUTE_V19", "CREATE_OR_EXECUTE_V20_DURING_THIS_GOVERNANCE", "INVOKE_WORKER_OR_CODEX"],
        },
    }
    for name, value in documents.items():
        write_json_once(PACKAGE / name, value)
    print(f"GOVERNANCE_BUILD=PASS DOCUMENTS={len(documents)}")

if __name__ == "__main__":
    main()
