#!/usr/bin/env python3
from governance_common import *

def main():
    for name in VALIDATION_FILES:
        if load_json(PACKAGE/name).get("status")!="PASS":raise SystemExit(f"cannot freeze:{name}")
    assert_v19_frozen()
    if V20.exists():raise SystemExit("V20 exists during governance")
    members=package_member_paths(exclude=("GOVERNANCE_ARTIFACT_MANIFEST.json","GOVERNANCE_LOCK.json","FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"))
    manifest={"record_type":"GOVERNANCE_ARTIFACT_MANIFEST","governance_identity":GOVERNANCE_ID,"member_count":len(members),"members":[{"path":p.name,"sha256":sha256_file(p)} for p in members],"canonical_root_sha256":package_root(members)}
    write_json_once(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json",manifest)
    lock={"record_type":"GOVERNANCE_LOCK","governance_identity":GOVERNANCE_ID,"status":"PASS_LOCKED_GOVERNANCE_ONLY","decision":DECISION,"manifest_sha256":sha256_file(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json"),"canonical_root_sha256":manifest["canonical_root_sha256"],"v19":"FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE","v20":"CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED"}
    write_json_once(PACKAGE/"GOVERNANCE_LOCK.json",lock)
    for path in package_member_paths(exclude=("FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",)):set_read_only(path)
    print(f"GOVERNANCE_FREEZE=PASS MEMBERS={len(members)} LOCK_SHA256={sha256_file(PACKAGE/'GOVERNANCE_LOCK.json')}")

if __name__=="__main__":main()
