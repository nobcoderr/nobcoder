#!/usr/bin/env python3
from governance_common import *

def main():
    manifest=load_json(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json");lock=load_json(PACKAGE/"GOVERNANCE_LOCK.json");checks=[]
    def check(cid,ok,e=None):checks.append({"id":cid,"status":"PASS" if ok else "FAIL","evidence":e})
    listed=[]
    for item in manifest["members"]:
        path=PACKAGE/item["path"];listed.append(path);check(f"F_MEMBER_{item['path']}",path.is_file() and sha256_file(path)==item["sha256"] and is_read_only(path))
    check("F001_COUNT",len(listed)==manifest["member_count"])
    check("F002_ROOT",package_root(listed)==manifest["canonical_root_sha256"])
    check("F003_LOCK",lock["manifest_sha256"]==sha256_file(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json") and lock["canonical_root_sha256"]==manifest["canonical_root_sha256"])
    check("F004_STATUS",lock["status"]=="PASS_LOCKED_GOVERNANCE_ONLY" and lock["decision"]==DECISION)
    check("F005_LOCK_READ_ONLY",is_read_only(PACKAGE/"GOVERNANCE_LOCK.json") and is_read_only(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json"))
    check("F006_V19_UNCHANGED",normative_tree(V19)==(V19_MEMBER_COUNT,V19_TREE_ROOT),normative_tree(V19))
    check("F007_EVIDENCE_UNCHANGED",normative_tree(V19/"results/prelock")== (V19_PRELOCK_MEMBER_COUNT,V19_PRELOCK_ROOT),normative_tree(V19/"results/prelock"))
    check("F008_EVIDENCE_READ_ONLY",all(is_read_only(p) for p in evidence_members()))
    terminal=load_json(V19/V19_PATHS["terminal"]);check("F009_ZERO_EXECUTION",terminal["static_lock"]=="NOT_ISSUED" and terminal["attempt_count"]==terminal["worker_invocation_count"]==terminal["codex_as_worker_invocation_count"]==terminal["semantic_codex_execve_count"]==0)
    check("F010_V20_ABSENT",not V20.exists())
    failed=[c["id"] for c in checks if c["status"]!="PASS"]
    result={"record_type":"FINAL_GOVERNANCE_FREEZE_VERIFICATION","governance_identity":GOVERNANCE_ID,"checks":checks,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failed),"failed":len(failed)},"failure_ids":failed,"status":"PASS" if not failed else "FAIL_CLOSED","governance_lock_sha256":sha256_file(PACKAGE/"GOVERNANCE_LOCK.json")}
    write_json_once(PACKAGE/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",result);set_read_only(PACKAGE/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json");os.chmod(PACKAGE,0o555)
    print(f"FINAL_FREEZE_VERIFICATION={result['status']} {len(checks)-len(failed)}/{len(checks)} LOCK_SHA256={result['governance_lock_sha256']}")
    if failed:raise SystemExit(1)

if __name__=="__main__":main()
