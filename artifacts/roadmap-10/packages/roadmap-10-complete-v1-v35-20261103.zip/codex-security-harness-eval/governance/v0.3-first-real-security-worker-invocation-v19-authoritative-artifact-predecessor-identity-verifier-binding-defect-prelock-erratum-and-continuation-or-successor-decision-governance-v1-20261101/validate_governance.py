#!/usr/bin/env python3
from governance_common import *

def main() -> None:
    checks = []
    def check(cid, ok, evidence=None): checks.append({"id": cid, "status": "PASS" if ok else "FAIL", "evidence": evidence})
    assert_v19_frozen()
    for name in DOCUMENT_FILES: check(f"G_DOC_{name}", (PACKAGE / name).is_file())
    for key, relative in V19_PATHS.items(): check(f"G_HASH_{key}", sha256_file(V19 / relative) == V19_HASHES[key])
    terminal = load_json(V19 / V19_PATHS["terminal"]); unit = load_json(V19 / V19_PATHS["unit"])
    check("G001_TERMINAL", terminal.get("status") == "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE")
    check("G002_ZERO_EXECUTION", terminal.get("static_lock") == "NOT_ISSUED" and terminal.get("attempt_count") == terminal.get("worker_invocation_count") == terminal.get("codex_as_worker_invocation_count") == terminal.get("semantic_codex_execve_count") == 0)
    check("G003_UNIT_FAILURE", unit.get("validation_counts") == {"total": 182, "passed": 180, "failed": 2} and set(unit.get("failure_ids", [])) == {"U027_V7_PROMPT_IDENTITY", "U029_V9_DIGEST_BINDING"})
    authority = authority_facts(); check("G004_AUTHORITY", authority.get("governance_lock_sha256") == V18_GOVERNANCE_LOCK_SHA256 and authority.get("successor_decision_sha256") == V18_SUCCESSOR_DECISION_SHA256 and authority.get("predecessor_identity") == V18_IDENTITY)
    facts = binding_component_facts(); check("G005_EXACT_MISMATCH", facts["builder"] == V18_IDENTITY and "V17" in facts["primary_validator"] and "V17" in facts["preflight"] and "V17" in facts["static_lock_preparation"])
    comparison = load_json(PACKAGE / "PREDECESSOR_BINDING_COMPONENT_COMPARISON.json"); check("G006_COMPARISON_COMPLETE", set(comparison["components"]) >= {"governance_authorized_predecessor", "builder", "primary_validator", "independent_validator", "preflight", "dependency_closure", "static_lock_preparation"})
    adjudication = load_json(PACKAGE / "AUTHORITATIVE_ARTIFACT_PREDECESSOR_BINDING_DEFECT_ADJUDICATION.json"); check("G007_DEFECT", adjudication["AUTHORITATIVE_ARTIFACT_PREDECESSOR_IDENTITY_VERIFIER_BINDING_DEFECT"] == "YES")
    check("G008_RUNTIME_NOT_INFERRED", all(value in {"NOT_ESTABLISHED", "NOT_PROVEN"} for value in adjudication["runtime_adjudication"].values()))
    decision = load_json(PACKAGE / "V19_TERMINAL_AND_V20_SUCCESSOR_DECISION.json"); check("G009_DECISION", decision["decision"] == DECISION and decision["v19_continuation"] == "PROHIBITED" and decision["v19_mutation_allowlist"] == [] and decision["v20"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    contract = load_json(PACKAGE / "CANONICAL_PREDECESSOR_BINDING_CONTRACT.json"); check("G010_CONTRACT", contract["predecessor_identity"] == V18_IDENTITY and contract["authority_source"]["governance_lock_sha256"] == V18_GOVERNANCE_LOCK_SHA256 and len(contract["required_components"]) == 6 and contract["version_or_directory_inference"] == "PROHIBITED")
    binding = load_json(PACKAGE / "V19_FROZEN_FAILURE_EVIDENCE_BINDING.json"); check("G011_EVIDENCE_SET", binding["prelock_member_count"] == len(binding["members"]) == V19_PRELOCK_MEMBER_COUNT and binding["prelock_tree_root_sha256"] == V19_PRELOCK_ROOT)
    check("G012_V19_EVIDENCE_READ_ONLY", all(is_read_only(p) for p in evidence_members()))
    check("G013_V20_ABSENT", not V20.exists())
    failed = [c["id"] for c in checks if c["status"] != "PASS"]
    result = {"record_type": "PRIMARY_GOVERNANCE_VALIDATION", "governance_identity": GOVERNANCE_ID, "checks": checks, "validation_counts": {"total": len(checks), "passed": len(checks)-len(failed), "failed": len(failed)}, "failure_ids": failed, "status": "PASS" if not failed else "FAIL_CLOSED"}
    write_json_once(PACKAGE / VALIDATION_FILES[0], result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failed)}/{len(checks)}")
    if failed: raise SystemExit(1)

if __name__ == "__main__": main()
