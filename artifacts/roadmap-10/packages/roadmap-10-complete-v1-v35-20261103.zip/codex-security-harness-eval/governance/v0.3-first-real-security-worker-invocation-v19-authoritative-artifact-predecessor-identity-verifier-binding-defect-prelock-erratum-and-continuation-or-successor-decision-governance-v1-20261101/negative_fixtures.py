#!/usr/bin/env python3
from governance_common import *

def predecessor_verdict(*, authority_lock, decision_digest, explicit_authority, candidates, bindings, artifact_digest_ok):
    checks = {
        "authority_lock": authority_lock == V18_GOVERNANCE_LOCK_SHA256,
        "decision_digest": decision_digest == V18_SUCCESSOR_DECISION_SHA256,
        "explicit_authority": explicit_authority is True,
        "single_candidate": candidates == [(V18_IDENTITY, V18_TREE_ROOT)],
        "all_components_exact": set(bindings) == {"builder", "primary", "independent", "preflight", "closure", "static_lock"} and all(value == V18_IDENTITY for value in bindings.values()),
        "artifact_digest_exact": artifact_digest_ok is True,
    }
    return all(checks.values())

def main() -> None:
    exact = dict(authority_lock=V18_GOVERNANCE_LOCK_SHA256, decision_digest=V18_SUCCESSOR_DECISION_SHA256, explicit_authority=True, candidates=[(V18_IDENTITY,V18_TREE_ROOT)], bindings={name:V18_IDENTITY for name in ("builder","primary","independent","preflight","closure","static_lock")}, artifact_digest_ok=True)
    cases=[]
    def case(cid, ok, expected): cases.append({"id":cid,"status":"PASS" if ok else "FAIL","expected_disposition":expected})
    case("N001_EXACT_AUTHORIZED_V18", predecessor_verdict(**exact), "PASS")
    altered=dict(exact);altered["bindings"]={**exact["bindings"],"primary":"V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V17"};case("N002_BUILDER_V18_VERIFIER_V17",not predecessor_verdict(**altered),"FAIL_CLOSED")
    altered=dict(exact);altered["bindings"]={**exact["bindings"],"builder":"V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V17"};case("N003_BUILDER_V17_VERIFIER_V18",not predecessor_verdict(**altered),"FAIL_CLOSED")
    altered=dict(exact);altered["explicit_authority"]=False;case("N004_VERSION_ONLY_INFERENCE",not predecessor_verdict(**altered),"FAIL_CLOSED")
    altered=dict(exact);altered["authority_lock"]=None;case("N005_MISSING_AUTHORITY",not predecessor_verdict(**altered),"FAIL_CLOSED")
    altered=dict(exact);altered["candidates"]=[(V18_IDENTITY,V18_TREE_ROOT),("V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V17","x")];case("N006_AMBIGUOUS_CANDIDATES",not predecessor_verdict(**altered),"FAIL_CLOSED")
    altered=dict(exact);altered["decision_digest"]="0"*64;case("N007_STALE_BINDING",not predecessor_verdict(**altered),"FAIL_CLOSED")
    altered=dict(exact);altered["artifact_digest_ok"]=False;case("N008_DIGEST_MISMATCH",not predecessor_verdict(**altered),"FAIL_CLOSED")
    decision=load_json(PACKAGE/"V19_TERMINAL_AND_V20_SUCCESSOR_DECISION.json");case("N009_CONTINUATION_PROHIBITED",decision["v19_continuation"]=="PROHIBITED" and decision["v19_mutation_allowlist"]==[],"FAIL_CLOSED")
    case("N010_V19_FROZEN",normative_tree(V19)==(V19_MEMBER_COUNT,V19_TREE_ROOT),"PASS")
    case("N011_V20_NOT_CREATED",not V20.exists(),"PASS")
    adjudication=load_json(PACKAGE/"AUTHORITATIVE_ARTIFACT_PREDECESSOR_BINDING_DEFECT_ADJUDICATION.json");case("N012_RUNTIME_NOT_INFERRED",adjudication["runtime_adjudication"]["security_worker"]=="NOT_ESTABLISHED" and adjudication["runtime_adjudication"]["confinement"]=="NOT_PROVEN","PASS")
    failed=[c["id"] for c in cases if c["status"]!="PASS"]
    result={"record_type":"NEGATIVE_GOVERNANCE_FIXTURES","governance_identity":GOVERNANCE_ID,"cases":cases,"validation_counts":{"total":len(cases),"passed":len(cases)-len(failed),"failed":len(failed)},"failure_ids":failed,"status":"PASS" if not failed else "FAIL_CLOSED"}
    write_json_once(PACKAGE/VALIDATION_FILES[1],result);print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['status']} {len(cases)-len(failed)}/{len(cases)}")
    if failed:raise SystemExit(1)

if __name__=="__main__":main()
