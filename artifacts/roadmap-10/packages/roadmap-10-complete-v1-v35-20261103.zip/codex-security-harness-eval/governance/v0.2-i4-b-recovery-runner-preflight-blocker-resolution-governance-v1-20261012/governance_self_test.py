#!/usr/bin/env python3
"""Deterministic self-tests for recovery preflight-blocker resolution V1."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
RECOVERY = BASE / "v0.2-i4-b-powered-off-provisioning-partial-failure-recovery-governance-v1-20261011"
V3 = BASE / "v0.2-i4-b-dedicated-environment-provisioning-governance-v3-20261010"
EVIDENCE = Path("/media/sf_Downloads/v3-a1-a2-partial-evidence-20261010")
SUCCESSOR = Path("/home/nobcoder/v0.2-i4-b-a3-a5-powered-off-recovery-runner-v1-20261012")
IDENTITY = "V0.2_I4_B_RECOVERY_RUNNER_PREFLIGHT_BLOCKER_RESOLUTION_GOVERNANCE_V1"


def read(name: str):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def governance_root(path: Path) -> str:
    rows = [
        f"{sha(item)}  {item.name}"
        for item in sorted(path.iterdir(), key=lambda value: value.name)
        if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json"
    ]
    return hashlib.sha256(("\n".join(rows) + "\n").encode()).hexdigest()


checks: list[dict[str, object]] = []


def check(name: str, condition: bool) -> None:
    checks.append({"check": name, "pass": bool(condition)})


protocol = read("GOVERNANCE_GATE_PROTOCOL.json")
preflight = read("PREFLIGHT_RESULT.json")
loss = read("EVIDENCE_LOSS_ASSESSMENT.json")
binding = read("SUCCESSOR_PATH_BINDING.json")
authorization = read("EVIDENCE_RECOVERY_AUTHORIZATION.json")
matrix = read("OPERATION_AUTHORIZATION_MATRIX.json")
risks = read("RISK_REGISTER.json")
decision = read("GOVERNANCE_DECISION.json")

check("identity", protocol["gate_id"] == decision["gate_id"] == IDENTITY)
check("governance_only", protocol["task_class"] == "GOVERNANCE_ONLY")
check("preflight_24", preflight["status"] == "PASS" and preflight["checks_passed"] == preflight["checks_total"] == 24)
check("recovery_lock", sha(RECOVERY / "GOVERNANCE_LOCK.json") == "d1eec39e5243f7cf3396b9ebf29962fc7a2c0e321d87ed9a3d6266ecd04b6fc8")
check("recovery_manifest", sha(RECOVERY / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "de526c1789d54d6b757e3739fa56154b87de09444b3963fc35482c7f9d12a3bc")
check("recovery_root", governance_root(RECOVERY) == "0568e0bb75f4be39f4321d93cd0c240e39399c32f91932481bc1d14e31a04e51")
check("v3_lock", sha(V3 / "GOVERNANCE_LOCK.json") == "84a3a4daa6f9375ec8c02161aca38066530fd252fdfbd16ae4f25c675e39919f")
check("v3_root", governance_root(V3) == "f4442097e2032e1ee12d27b967e19faddad95c7c475bcdc8d88214cb1a9a446f")
check("lost_export_absent", not EVIDENCE.exists() and not EVIDENCE.is_symlink())
check("loss_class", loss["status"] == "ORIGINAL_EXPORT_NOT_AVAILABLE_RECOVERY_REQUIRED")
check("lost_hash_count", len(loss["lost_export_expected_hashes"]) == 6)
check("no_digest_mismatch_claim", "not a digest mismatch" in loss["prohibited_interpretations"][0])
check("successor_absent", not SUCCESSOR.exists() and not SUCCESSOR.is_symlink())
check("successor_identity", binding["runner_identity"] == "V0.2_I4_B_A3_A5_POWERED_OFF_RECOVERY_RUNNER_V1")
check("successor_exact_path", binding["exact_path"] == str(SUCCESSOR))
check("successor_bound_not_created", binding["status"] == "AUTHORIZED_BOUND_NOT_CREATED" and binding["automatic_directory_creation"] is False)
check("successor_gate", binding["creation_gate"] == "ONLY_AFTER_NEW_EVIDENCE_RECOVERY_PACKAGE_AND_ITS_INDEPENDENT_VALIDATION_LOCK_VERIFY")
check("new_package_identity", authorization["recovery_package_identity"] == "V0.2_I4_B_V3_PARTIAL_EVIDENCE_RECOVERY_PACKAGE_V1")
check("new_package_not_executed", authorization["status"] == "GRANTED_NOT_EXECUTED_READ_ONLY_SOURCE_OBSERVATION_AND_NEW_EXPORT_ONLY")
check("destination_exact", authorization["destination"]["kali_expected_view"] == "/media/sf_Downloads/v3-partial-evidence-recovery-v1-20261012")
check("source_count", len(authorization["authorized_source_files_if_present"]) == 4)
check("allowlist_count", len(authorization["read_only_vboxmanage_allowlist"]) == 4)
check("allowlist_read_only", all(argv in (["--version"], ["list", "vms"], ["list", "runningvms"], ["list", "ostypes"]) for argv in authorization["read_only_vboxmanage_allowlist"]))
check("required_record_count", len(authorization["required_output_records"]) == 8)
check("single_use", authorization["destination"]["single_use"] is True)
check("no_auto_execution", authorization["automatic_execution"] is False and protocol["automatic_execution"] is False)

ops = {row["id"]: row["decision"] for row in matrix["operations"]}
check("matrix_count", len(ops) == matrix["operation_count"] == 13)
check("evidence_ops", all(ops[f"E0{i}"].startswith("AUTHORIZED_FUTURE") for i in range(1, 8)))
check("path_bound", ops["P01"] == "AUTHORIZED_BOUND_NOT_CREATED")
check("runner_blocked", ops["P02"] == "NOT_AUTHORIZED_UNTIL_EVIDENCE_RECOVERY_LOCK")
check("a1_a2_denied", ops["X01"] == "DENIED")
check("a3_a5_denied", ops["X02"] == "DENIED")
check("mutating_vbox_denied", ops["X03"] == "DENIED")
check("later_milestones_denied", ops["X04"] == "DENIED")
check("risk_count", risks["risk_count"] == len(risks["risks"]) == 14)
check("risks_fail_closed", risks["all_fail_closed"] is True and all(row["failure"].startswith("STOP") for row in risks["risks"]))
check("decision_pass_locked", decision["status"] == "PASS_LOCKED")
check("evidence_still_missing", decision["evidence_access"] == "ORIGINAL_EXPORT_NOT_AVAILABLE")
check("runner_still_blocked", decision["offline_runner_implementation"] == "BLOCKED_PENDING_EVIDENCE_RECOVERY_LOCK")
check("a3_a5_not_executable", decision["live_a3_a5_execution"] == "NOT_EXECUTABLE")
check("runtime_not_evaluated", decision["runtime_isolation"] == "NOT_EVALUATED")
check("i4b_not_granted", decision["i4_b_execution"] == "NOT_GRANTED")
check("later_not_authorized", decision["i5"] == "NOT_AUTHORIZED" and decision["v0_3"] == "NOT_OPENED")
check("no_successor_tree_created", not SUCCESSOR.exists())

for forbidden in (
    "RECOVERY_RUNNER.ps1",
    "A3_A5_EXECUTION_AUTHORIZATION.json",
    "I4_B_AUTHORIZATION.json",
    "VM_BOOT_AUTHORIZATION.json",
    "RUNTIME_RESULT.json",
):
    check(f"absent_{forbidden}", not (ROOT / forbidden).exists())

passed = sum(bool(row["pass"]) for row in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": IDENTITY,
    "validator": "preflight_blocker_resolution_self_test_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": checks,
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
