#!/usr/bin/env python3
"""Independent validator for blocker-resolution governance V1."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
RECOVERY = BASE / "v0.2-i4-b-powered-off-provisioning-partial-failure-recovery-governance-v1-20261011"
V3 = BASE / "v0.2-i4-b-dedicated-environment-provisioning-governance-v3-20261010"
OLD_EXPORT = Path("/media/sf_Downloads/v3-a1-a2-partial-evidence-20261010")
NEW_EXPORT = Path("/media/sf_Downloads/v3-partial-evidence-recovery-v1-20261012")
SUCCESSOR = Path("/home/nobcoder/v0.2-i4-b-a3-a5-powered-off-recovery-runner-v1-20261012")


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def root_digest(path: Path) -> str:
    ledger = bytearray()
    for item in sorted(path.iterdir(), key=lambda value: value.name):
        if item.is_file() and not item.is_symlink() and item.name != "GOVERNANCE_LOCK.json":
            ledger.extend(f"{sha(item)}  {item.name}\n".encode())
    return hashlib.sha256(ledger).hexdigest()


checks: list[tuple[str, bool]] = []


def verify(name: str, value: bool) -> None:
    checks.append((name, bool(value)))


protocol = load(ROOT / "GOVERNANCE_GATE_PROTOCOL.json")
preflight = load(ROOT / "PREFLIGHT_RESULT.json")
loss = load(ROOT / "EVIDENCE_LOSS_ASSESSMENT.json")
binding = load(ROOT / "SUCCESSOR_PATH_BINDING.json")
authorization = load(ROOT / "EVIDENCE_RECOVERY_AUTHORIZATION.json")
matrix = load(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
risks = load(ROOT / "RISK_REGISTER.json")
decision = load(ROOT / "GOVERNANCE_DECISION.json")

verify("gate_identity", protocol["gate_id"] == "V0.2_I4_B_RECOVERY_RUNNER_PREFLIGHT_BLOCKER_RESOLUTION_GOVERNANCE_V1")
verify("user_authority_recorded", protocol["authorization_basis"] == "USER_CONTINUE_AFTER_READ_ONLY_PREFLIGHT_BLOCKER_REVIEW_2026_10_12")
verify("scope_governance_only", protocol["task_class"] == "GOVERNANCE_ONLY" and not protocol["scope"]["evidence_recovery_execution"])
verify("recovery_lock_bytes", sha(RECOVERY / "GOVERNANCE_LOCK.json") == protocol["predecessors"]["recovery_governance_lock_sha256"])
verify("recovery_root", root_digest(RECOVERY) == protocol["predecessors"]["recovery_governance_root_sha256"])
verify("v3_lock_bytes", sha(V3 / "GOVERNANCE_LOCK.json") == protocol["predecessors"]["v3_governance_lock_sha256"])
verify("v3_root", root_digest(V3) == protocol["predecessors"]["v3_governance_root_sha256"])
verify("preflight_consistent", preflight["checks_failed"] == 0 and preflight["writes_before_preflight_pass"] == 0)
verify("old_export_absent", not OLD_EXPORT.exists() and not OLD_EXPORT.is_symlink())
verify("old_export_not_mismatch", loss["historical_status"]["direct_six_file_reverification_now"] == "NOT_POSSIBLE")
verify("six_historical_hashes_preserved", len(loss["lost_export_expected_hashes"]) == 6 and len(set(loss["lost_export_expected_hashes"].values())) == 6)
verify("history_preserved", loss["historical_status"]["a1"] == "PASS_FINAL_NO_REPLAY" and loss["historical_status"]["a3"] == "NOT_EXECUTED_GUARD_DEFECT")
verify("successor_exact", Path(binding["exact_path"]) == SUCCESSOR)
verify("successor_parent", Path(binding["parent_path"]) == Path("/home/nobcoder"))
verify("successor_absent", not SUCCESSOR.exists() and not SUCCESSOR.is_symlink())
verify("successor_not_created", binding["status"] == "AUTHORIZED_BOUND_NOT_CREATED" and binding["automatic_runner_implementation"] is False)
verify("new_export_absent", not NEW_EXPORT.exists() and not NEW_EXPORT.is_symlink())
verify("new_export_identity_distinct", authorization["recovery_package_identity"] != loss["identity"])
verify("windows_destination_new", "v3-partial-evidence-recovery-v1-20261012" in authorization["destination"]["windows"])
verify("source_allowlist_exact", len(authorization["authorized_source_files_if_present"]) == 4 and all(path.startswith("D:\\v02-i4b-benign-isolation-lab-01\\evidence\\") for path in authorization["authorized_source_files_if_present"]))
verify("vbox_allowlist_exact", authorization["read_only_vboxmanage_allowlist"] == [["--version"], ["list", "vms"], ["list", "runningvms"], ["list", "ostypes"]])
verify("no_mutating_vbox_text", not any(token in json.dumps(authorization["read_only_vboxmanage_allowlist"]) for token in ("createvm", "createmedium", "modifyvm", "storagectl", "storageattach", "startvm", "unregistervm", "controlvm")))
verify("new_record_names", all("PARTIAL_STATE.json" != name and "VBOX_UBUNTU_OSTYPES.txt" != name for name in authorization["required_output_records"]))
verify("independent_lock_required", "separate independent EVIDENCE_RECOVERY_LOCK" in authorization["completion_rule"])
verify("single_use_fail_closed", authorization["destination"]["single_use"] is True and len(authorization["fail_closed_rules"]) == 7)

decisions = {row["id"]: row["decision"] for row in matrix["operations"]}
verify("matrix_unique", len(decisions) == len(matrix["operations"]) == matrix["operation_count"])
verify("only_evidence_future", sum(value.startswith("AUTHORIZED_FUTURE") for value in decisions.values()) == 7)
verify("only_path_bound", sum(value == "AUTHORIZED_BOUND_NOT_CREATED" for value in decisions.values()) == 1)
verify("runner_not_authorized", decisions["P02"] == "NOT_AUTHORIZED_UNTIL_EVIDENCE_RECOVERY_LOCK")
verify("runtime_denials", all(decisions[key] == "DENIED" for key in ("X01", "X02", "X03", "X04")))
verify("risk_closed", risks["all_fail_closed"] is True and risks["risk_count"] == 14)
verify("decision_semantics", decision["evidence_recovery"] == "AUTHORIZED_NOT_EXECUTED" and decision["successor_path"] == "AUTHORIZED_BOUND_NOT_CREATED")
verify("runner_blocked", decision["offline_runner_implementation"] == "BLOCKED_PENDING_EVIDENCE_RECOVERY_LOCK")
verify("a3_a5_not_executable", decision["live_a3_a5_execution"] == "NOT_EXECUTABLE")
verify("no_runtime_claim", decision["runtime_isolation"] == "NOT_EVALUATED" and decision["i4_b_execution"] == "NOT_GRANTED")
verify("no_later_authority", decision["i5"] == "NOT_AUTHORIZED" and decision["v0_3"] == "NOT_OPENED")
verify("no_auto_follow_on", protocol["automatic_follow_on"] is False and decision["automatic_execution"] is False)

for forbidden in (
    "RECOVERY_RUNNER.ps1",
    "RUNNER_DIGEST_LOCK.json",
    "A3_A5_EXECUTION_RESULT.json",
    "VM_BOOT_AUTHORIZATION.json",
    "I4_B_AUTHORIZATION.json",
):
    verify(f"forbidden_absent_{forbidden}", not (ROOT / forbidden).exists())

passed = sum(result for _, result in checks)
failed = len(checks) - passed
print(json.dumps({
    "gate_id": protocol["gate_id"],
    "validator": "independent_preflight_blocker_resolution_validator_v1",
    "status": "PASS" if failed == 0 else "FAIL",
    "passed": passed,
    "failed": failed,
    "total": len(checks),
    "checks": [{"check": name, "pass": result} for name, result in checks],
}, indent=2, sort_keys=True))
raise SystemExit(0 if failed == 0 else 1)
