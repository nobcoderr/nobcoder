#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath

from governance_common import (
    CORRECT_EXTERNAL_ARTIFACT, DECISION, DOCUMENT_FILES, EXTERNAL_ARTIFACT_ID,
    EXTERNAL_ARTIFACT_RELATION, EXTERNAL_ARTIFACT_ROLE, EXTERNAL_ARTIFACT_SHA256,
    EXTERNAL_ARTIFACT_SIZE, GOVERNANCE_ID, PACKAGE, VALIDATION_FILES,
    V17_GOVERNANCE_LOCK_SHA256, V17_IDENTITY, V18, V18_IDENTITY, V18_TREE,
    V19, V19_TREE, V20, V20_HASHES, V20_IDENTITY, V20_PATHS,
    V20_PRELOCK_MEMBER_COUNT, V20_PRELOCK_TREE_SHA256, V20_WORKSPACE_MEMBER_COUNT,
    V20_WORKSPACE_TREE_SHA256, V21, WRONG_EXTERNAL_ARTIFACT, write_json_once,
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree(root: Path):
    records = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"symlink in frozen tree: {path}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            key = tuple(part.encode("utf-8", errors="strict") for part in PurePosixPath(relative).parts)
            records.append((key, relative, digest(path)))
    records.sort(key=lambda item: item[0])
    stream = b"".join(relative.encode("utf-8") + b"\x00" + sha.encode("ascii") + b"\x0a" for _, relative, sha in records)
    return len(records), hashlib.sha256(stream).hexdigest()


def load(path: Path):
    return json.loads(path.read_bytes().decode("utf-8"))


def main() -> None:
    checks = []

    def check(identity, condition, evidence=None):
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("I001_PRIMARY", load(PACKAGE / VALIDATION_FILES[0])["status"] == "PASS")
    check("I002_NEGATIVE", load(PACKAGE / VALIDATION_FILES[1])["status"] == "PASS")
    check("I003_DOCUMENTS", all((PACKAGE / name).is_file() for name in DOCUMENT_FILES))
    check("I004_V20_TREE", tree(V20) == (V20_WORKSPACE_MEMBER_COUNT, V20_WORKSPACE_TREE_SHA256), tree(V20))
    check("I005_V20_PRELOCK_TREE", tree(V20 / "results/prelock") == (V20_PRELOCK_MEMBER_COUNT, V20_PRELOCK_TREE_SHA256), tree(V20 / "results/prelock"))
    check("I006_BOUND_HASHES", all(digest(V20 / V20_PATHS[key]) == expected for key, expected in V20_HASHES.items()))

    failure = load(V20 / V20_PATHS["failure_record"])
    check("I007_FAILURE_CLASS", failure.get("failure_class") == "INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT" and failure.get("exception_type") == "FileNotFoundError" and failure.get("resolved_missing_path") == str(WRONG_EXTERNAL_ARTIFACT))
    source = (V20 / V20_PATHS["independent_validator"]).read_text(encoding="utf-8")
    check("I008_SOURCE_BINDING", f'v18_gov=Path("{WRONG_EXTERNAL_ARTIFACT.parent}")' in source and 'v17_binding=load(v18_gov/"V17_PRELOCK_FROZEN_EVIDENCE_BINDING.json")' in source)
    check("I009_WRONG_PATH_ABSENT", not WRONG_EXTERNAL_ARTIFACT.exists())
    external = load(CORRECT_EXTERNAL_ARTIFACT)
    check("I010_CANONICAL_EXTERNAL_ARTIFACT", CORRECT_EXTERNAL_ARTIFACT.is_file() and not CORRECT_EXTERNAL_ARTIFACT.is_symlink() and digest(CORRECT_EXTERNAL_ARTIFACT) == EXTERNAL_ARTIFACT_SHA256 and CORRECT_EXTERNAL_ARTIFACT.stat().st_size == EXTERNAL_ARTIFACT_SIZE and external.get("execution_identity") == V17_IDENTITY)

    primary = load(V20 / V20_PATHS["primary"])
    gate = next(item for item in primary["checks"] if item["id"] == "S008C3_CANONICAL_PREDECESSOR")
    contract_v20 = load(V20 / V20_PATHS["canonical_predecessor_contract"])
    check("I011_CANONICAL_PREDECESSOR", gate["status"] == "PASS" and gate["evidence"]["predecessor_identity"] == V18_IDENTITY and contract_v20["predecessor_identity"] == V18_IDENTITY)
    check("I012_V18_TREE", tree(V18) == V18_TREE, tree(V18))
    check("I013_V19_TREE", tree(V19) == V19_TREE, tree(V19))

    adjudication = load(PACKAGE / "INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT_ADJUDICATION.json")
    check("I014_ADJUDICATION", adjudication["INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT"] == "YES" and adjudication["CANONICAL_PREDECESSOR_IDENTITY_DEFECT"] == "NO" and adjudication["V18_PREDECESSOR_DRIFT"] == "NO" and adjudication["V19_HISTORY_DRIFT"] == "NO")
    decision = load(PACKAGE / "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION.json")
    check("I015_DECISION", decision["decision"] == DECISION and decision["v20_continuation"] == "PROHIBITED" and decision["v21"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")

    contract = load(PACKAGE / "CANONICAL_EXTERNAL_PREDECESSOR_ARTIFACT_BINDING_CONTRACT.json")
    bound = contract["canonical_binding_for_known_artifact"]
    check("I016_CONTRACT_BINDING", bound["logical_artifact_identity"] == EXTERNAL_ARTIFACT_ID and bound["owning_predecessor_identity"] == V17_IDENTITY and bound["artifact_role"] == EXTERNAL_ARTIFACT_ROLE and bound["canonical_locator"] == str(CORRECT_EXTERNAL_ARTIFACT) and bound["expected_sha256"] == EXTERNAL_ARTIFACT_SHA256 and bound["expected_size"] == EXTERNAL_ARTIFACT_SIZE and bound["authorizing_governance_lock_sha256"] == V17_GOVERNANCE_LOCK_SHA256 and bound["relationship_to_canonical_predecessor"] == EXTERNAL_ARTIFACT_RELATION)
    check("I017_NO_FALLBACK", {"VERSION_NUMBER_ARITHMETIC", "GUESSED_GOVERNANCE_DIRECTORY", "FILENAME_SEARCH", "FALLBACK_DIRECTORY_SCAN", "MANUAL_COPY", "SYMLINK_COMPATIBILITY_ARTIFACT", "HISTORICAL_ARTIFACT_RECONSTRUCTION"}.issubset(set(contract["prohibited_resolution"])))
    check("I018_V20_READ_ONLY", all((path.stat().st_mode & 0o222) == 0 for path in (V20 / "results/prelock").rglob("*") if path.is_file()))
    terminal = load(V20 / V20_PATHS["terminal"])
    check("I019_NO_EXECUTION", terminal["static_lock"] == "NOT_ISSUED" and terminal["attempt_count"] == terminal["worker_invocation_count"] == terminal["codex_as_worker_invocation_count"] == terminal["semantic_codex_execve_count"] == 0 and not list(V20.rglob("ATTEMPT_MARKER.json")))
    check("I020_V21_ABSENT", not V21.exists())

    failed = [item["id"] for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "INDEPENDENT_GOVERNANCE_VALIDATION",
        "governance_identity": GOVERNANCE_ID,
        "implementation_independence": "FROZEN_TREES_HASHES_SOURCE_BINDING_EXTERNAL_LOCATOR_OWNER_AND_CONTRACT_RECOMPUTED_WITH_SEPARATE_IMPLEMENTATION",
        "checks": checks,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
    }
    write_json_once(PACKAGE / VALIDATION_FILES[2], result)
    print(f"INDEPENDENT_GOVERNANCE_VALIDATION={result['status']} {len(checks) - len(failed)}/{len(checks)}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
