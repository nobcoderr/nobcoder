#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    manifest = load_json(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load_json(PACKAGE / "GOVERNANCE_LOCK.json")
    checks = []

    def check(identity, condition, evidence=None):
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    listed = []
    for item in manifest["members"]:
        path = PACKAGE / item["path"]
        listed.append(path)
        check(f"F_MEMBER_{item['path']}", path.is_file() and sha256_file(path) == item["sha256"] and path.stat().st_size == item["bytes"] and is_read_only(path))
    check("F001_COUNT", len(listed) == manifest["member_count"])
    check("F002_ROOT", package_root(listed) == manifest["canonical_root_sha256"])
    check("F003_LOCK_BINDING", lock["manifest_sha256"] == sha256_file(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json") and lock["canonical_root_sha256"] == manifest["canonical_root_sha256"])
    check("F004_STATUS", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY" and lock["decision"] == DECISION)
    check("F005_LOCK_READ_ONLY", is_read_only(PACKAGE / "GOVERNANCE_LOCK.json") and is_read_only(PACKAGE / "GOVERNANCE_ARTIFACT_MANIFEST.json"))
    check("F006_V20_UNCHANGED", normative_tree(V20) == (V20_WORKSPACE_MEMBER_COUNT, V20_WORKSPACE_TREE_SHA256), normative_tree(V20))
    check("F007_V20_PRELOCK_UNCHANGED", normative_tree(V20 / "results/prelock") == (V20_PRELOCK_MEMBER_COUNT, V20_PRELOCK_TREE_SHA256), normative_tree(V20 / "results/prelock"))
    check("F008_V20_EVIDENCE_READ_ONLY", all(is_read_only(path) for path in prelock_files()))
    check("F009_V18_UNCHANGED", normative_tree(V18) == V18_TREE, normative_tree(V18))
    check("F010_V19_UNCHANGED", normative_tree(V19) == V19_TREE, normative_tree(V19))
    check("F011_EXTERNAL_ARTIFACT_EXACT", CORRECT_EXTERNAL_ARTIFACT.is_file() and not CORRECT_EXTERNAL_ARTIFACT.is_symlink() and sha256_file(CORRECT_EXTERNAL_ARTIFACT) == EXTERNAL_ARTIFACT_SHA256 and CORRECT_EXTERNAL_ARTIFACT.stat().st_size == EXTERNAL_ARTIFACT_SIZE)
    check("F012_WRONG_LOCATOR_STILL_ABSENT", not WRONG_EXTERNAL_ARTIFACT.exists())
    terminal = load_json(V20 / V20_PATHS["terminal"])
    check("F013_NO_EXECUTION", terminal["static_lock"] == "NOT_ISSUED" and terminal["attempt_count"] == terminal["worker_invocation_count"] == terminal["codex_as_worker_invocation_count"] == terminal["semantic_codex_execve_count"] == 0 and not list(V20.rglob("ATTEMPT_MARKER.json")))
    check("F014_V21_ABSENT", not V21.exists())

    failed = [item["id"] for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "FINAL_GOVERNANCE_FREEZE_VERIFICATION",
        "governance_identity": GOVERNANCE_ID,
        "checks": checks,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "governance_lock_sha256": sha256_file(PACKAGE / "GOVERNANCE_LOCK.json"),
    }
    write_json_once(PACKAGE / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json", result)
    set_read_only(PACKAGE / "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json")
    os.chmod(PACKAGE, 0o555)
    print(f"FINAL_FREEZE_VERIFICATION={result['status']} {len(checks) - len(failed)}/{len(checks)} LOCK_SHA256={result['governance_lock_sha256']}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
