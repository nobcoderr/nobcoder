#!/usr/bin/env python3
from copy import deepcopy
from governance_common import *


def resolver_verdict(binding, *, candidates, exists=True, is_regular=True, is_symlink=False, actual_sha256=EXTERNAL_ARTIFACT_SHA256, actual_size=EXTERNAL_ARTIFACT_SIZE, parsed_owner=V17_IDENTITY, inferred=False):
    expected = {
        "logical_artifact_identity": EXTERNAL_ARTIFACT_ID,
        "owning_predecessor_identity": V17_IDENTITY,
        "artifact_role": EXTERNAL_ARTIFACT_ROLE,
        "canonical_locator": str(CORRECT_EXTERNAL_ARTIFACT),
        "expected_sha256": EXTERNAL_ARTIFACT_SHA256,
        "expected_size": EXTERNAL_ARTIFACT_SIZE,
        "authorizing_governance_identity": load_json(V17_GOVERNANCE / "GOVERNANCE_LOCK.json")["governance_identity"],
        "authorizing_governance_lock_sha256": V17_GOVERNANCE_LOCK_SHA256,
        "authorizing_successor_decision_sha256": V17_SUCCESSOR_DECISION_SHA256,
        "relationship_to_canonical_predecessor": EXTERNAL_ARTIFACT_RELATION,
    }
    checks = {
        "exact_binding": binding == expected,
        "single_candidate": candidates == [expected],
        "canonical_predecessor": binding.get("relationship_to_canonical_predecessor") == EXTERNAL_ARTIFACT_RELATION,
        "exact_locator": binding.get("canonical_locator") == str(CORRECT_EXTERNAL_ARTIFACT),
        "exists": exists is True,
        "safe_regular": is_regular is True and is_symlink is False,
        "digest": actual_sha256 == binding.get("expected_sha256") == EXTERNAL_ARTIFACT_SHA256,
        "size": actual_size == binding.get("expected_size") == EXTERNAL_ARTIFACT_SIZE,
        "owner": parsed_owner == binding.get("owning_predecessor_identity") == V17_IDENTITY,
        "governance": binding.get("authorizing_governance_lock_sha256") == V17_GOVERNANCE_LOCK_SHA256 and binding.get("authorizing_successor_decision_sha256") == V17_SUCCESSOR_DECISION_SHA256,
        "no_inference": inferred is False,
    }
    return all(checks.values())


def main() -> None:
    exact = load_json(PACKAGE / "CANONICAL_EXTERNAL_PREDECESSOR_ARTIFACT_BINDING_CONTRACT.json")["canonical_binding_for_known_artifact"]
    cases = []

    def case(identity, condition, expected):
        cases.append({"id": identity, "status": "PASS" if condition else "FAIL", "expected_disposition": expected})

    case("N001_EXACT_GOVERNANCE_BOUND_CANONICAL_RESOLUTION", resolver_verdict(exact, candidates=[exact]), "PASS")

    altered = deepcopy(exact)
    altered["canonical_locator"] = str(WRONG_EXTERNAL_ARTIFACT)
    case("N002_CORRECT_FILENAME_WRONG_GOVERNANCE_DIRECTORY", not resolver_verdict(altered, candidates=[altered], exists=False), "FAIL_CLOSED")

    altered = deepcopy(exact)
    altered["owning_predecessor_identity"] = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V16"
    case("N003_SAME_FILENAME_ANOTHER_PREDECESSOR", not resolver_verdict(altered, candidates=[altered], parsed_owner=V17_IDENTITY), "FAIL_CLOSED")

    case("N004_MISSING_ARTIFACT", not resolver_verdict(exact, candidates=[exact], exists=False, is_regular=False), "FAIL_CLOSED")
    case("N005_WRONG_DIGEST", not resolver_verdict(exact, candidates=[exact], actual_sha256="0" * 64), "FAIL_CLOSED")
    case("N006_WRONG_OWNER_IDENTITY", not resolver_verdict(exact, candidates=[exact], parsed_owner=V18_IDENTITY), "FAIL_CLOSED")

    altered = deepcopy(exact)
    altered["owning_predecessor_identity"] = V18_IDENTITY
    altered["relationship_to_canonical_predecessor"] = "ARTIFACT_IS_CANONICAL_PREDECESSOR"
    case("N007_STALE_V17_ARTIFACT_AS_CANONICAL_PREDECESSOR", not resolver_verdict(altered, candidates=[altered]), "FAIL_CLOSED")

    duplicate = deepcopy(exact)
    case("N008_AMBIGUOUS_MATCHING_ARTIFACTS", not resolver_verdict(exact, candidates=[exact, duplicate]), "FAIL_CLOSED")
    case("N009_PATH_SYNTHESIZED_FROM_INVOCATION_NUMBER", not resolver_verdict(exact, candidates=[exact], inferred=True), "FAIL_CLOSED")

    altered = deepcopy(exact)
    altered["authorizing_governance_lock_sha256"] = None
    case("N010_MISSING_GOVERNANCE_AUTHORITY", not resolver_verdict(altered, candidates=[altered]), "FAIL_CLOSED")
    case("N011_SYMLINK_COMPATIBILITY_ARTIFACT", not resolver_verdict(exact, candidates=[exact], is_symlink=True), "FAIL_CLOSED")

    case("N012_V20_FROZEN", normative_tree(V20) == (V20_WORKSPACE_MEMBER_COUNT, V20_WORKSPACE_TREE_SHA256), "PASS")
    case("N013_V20_PRELOCK_READ_ONLY", all(is_read_only(path) for path in prelock_files()), "PASS")
    case("N014_V21_NOT_CREATED", not V21.exists(), "PASS")
    decision = load_json(PACKAGE / "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION.json")
    case("N015_V20_CONTINUATION_PROHIBITED", decision["v20_continuation"] == "PROHIBITED" and decision["v20_mutation_allowlist"] == [], "PASS")
    adjudication = load_json(PACKAGE / "INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT_ADJUDICATION.json")
    case("N016_RUNTIME_NOT_INFERRED", adjudication["runtime_adjudication"]["security_worker"] == "NOT_ESTABLISHED" and adjudication["runtime_adjudication"]["confinement"] == "NOT_PROVEN", "PASS")

    failed = [item["id"] for item in cases if item["status"] != "PASS"]
    result = {
        "record_type": "NEGATIVE_GOVERNANCE_FIXTURES",
        "governance_identity": GOVERNANCE_ID,
        "cases": cases,
        "validation_counts": {"total": len(cases), "passed": len(cases) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
    }
    write_json_once(PACKAGE / VALIDATION_FILES[1], result)
    print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['status']} {len(cases) - len(failed)}/{len(cases)}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
