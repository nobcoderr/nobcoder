#!/usr/bin/env python3
from governance_common import *


def main() -> None:
    checks = []

    def check(identity, condition, evidence=None):
        checks.append({"id": identity, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    assert_v20_frozen()
    assert_predecessor_history_unchanged()
    for name in DOCUMENT_FILES:
        check(f"G_DOC_{name}", (PACKAGE / name).is_file())
    for key, relative in V20_PATHS.items():
        check(f"G_HASH_{key}", sha256_file(V20 / relative) == V20_HASHES[key])

    terminal = load_json(V20 / V20_PATHS["terminal"])
    failure = load_json(V20 / V20_PATHS["failure_record"])
    unit = load_json(V20 / V20_PATHS["unit"])
    primary = load_json(V20 / V20_PATHS["primary"])
    check("G001_TERMINAL", terminal.get("status") == "FAIL_CLOSED_DURING_INDEPENDENT_STATIC_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE")
    check("G002_NO_EXECUTION", terminal.get("static_lock") == "NOT_ISSUED" and all(terminal.get(key) == 0 for key in ("attempt_count", "worker_invocation_count", "codex_as_worker_invocation_count", "semantic_codex_execve_count")))
    check("G003_STATIC_RESULTS", unit.get("status") == "PASS" and unit.get("validation_counts") == {"total": 203, "passed": 203, "failed": 0} and primary.get("status") == "PASS" and primary.get("validation_counts") == {"total": 66, "passed": 66, "failed": 0})
    check("G004_INDEPENDENT_FAILURE", failure.get("failure_class") == "INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT" and failure.get("exception_type") == "FileNotFoundError" and failure.get("resolved_missing_path") == str(WRONG_EXTERNAL_ARTIFACT))

    facts = external_artifact_facts()
    check("G005_WRONG_LOCATOR_ABSENT", facts["wrong_locator_exists"] is False and facts["source_binds_wrong_governance_directory"] and facts["source_joins_filename_to_wrong_directory"], facts)
    check("G006_CANONICAL_LOCATOR_EXACT", facts["correct_locator_exists"] and not facts["correct_locator_is_symlink"] and facts["correct_sha256"] == EXTERNAL_ARTIFACT_SHA256 and facts["correct_size"] == EXTERNAL_ARTIFACT_SIZE and facts["correct_owner_identity"] == V17_IDENTITY)
    check("G007_CANONICAL_PREDECESSOR_UNCHANGED", facts["canonical_predecessor_identity"] == facts["primary_canonical_predecessor_identity"] == V18_IDENTITY and facts["primary_canonical_predecessor_gate"] == "PASS")
    check("G008_V18_NO_DRIFT", normative_tree(V18) == V18_TREE, normative_tree(V18))
    check("G009_V19_NO_DRIFT", normative_tree(V19) == V19_TREE, normative_tree(V19))

    adjudication = load_json(PACKAGE / "INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT_ADJUDICATION.json")
    check("G010_ADJUDICATION", adjudication["INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT"] == "YES" and adjudication["CANONICAL_PREDECESSOR_IDENTITY_DEFECT"] == "NO" and adjudication["V18_PREDECESSOR_DRIFT"] == "NO" and adjudication["V19_HISTORY_DRIFT"] == "NO")
    check("G011_RUNTIME_NOT_INFERRED", all(value in {"NOT_ESTABLISHED", "NOT_PROVEN"} for value in adjudication["runtime_adjudication"].values()))

    decision = load_json(PACKAGE / "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION.json")
    check("G012_DECISION", decision["decision"] == DECISION and decision["v20_continuation"] == "PROHIBITED" and decision["v20_mutation_allowlist"] == [] and decision["v21"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    contract = load_json(PACKAGE / "CANONICAL_EXTERNAL_PREDECESSOR_ARTIFACT_BINDING_CONTRACT.json")
    known = contract["canonical_binding_for_known_artifact"]
    check("G013_CONTRACT_FIELDS", set(contract["required_binding_fields"]) == set(known) and known["logical_artifact_identity"] == EXTERNAL_ARTIFACT_ID and known["owning_predecessor_identity"] == V17_IDENTITY and known["canonical_locator"] == str(CORRECT_EXTERNAL_ARTIFACT))
    check("G014_CONTRACT_PROHIBITIONS", set(contract["prohibited_resolution"]) >= {"VERSION_NUMBER_ARITHMETIC", "GUESSED_GOVERNANCE_DIRECTORY", "FILENAME_SEARCH", "FALLBACK_DIRECTORY_SCAN", "MANUAL_COPY", "SYMLINK_COMPATIBILITY_ARTIFACT", "HISTORICAL_ARTIFACT_RECONSTRUCTION"})
    check("G015_V20_READ_ONLY", all(is_read_only(path) for path in prelock_files()))
    check("G016_V21_ABSENT", not V21.exists())

    failed = [item["id"] for item in checks if item["status"] != "PASS"]
    result = {
        "record_type": "PRIMARY_GOVERNANCE_VALIDATION",
        "governance_identity": GOVERNANCE_ID,
        "checks": checks,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failed), "failed": len(failed)},
        "failure_ids": failed,
        "status": "PASS" if not failed else "FAIL_CLOSED",
    }
    write_json_once(PACKAGE / VALIDATION_FILES[0], result)
    print(f"PRIMARY_GOVERNANCE_VALIDATION={result['status']} {len(checks) - len(failed)}/{len(checks)}")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
