#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath

GOVERNANCE_ID = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V20_"
    "INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT_"
    "PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
PACKAGE = Path(__file__).resolve().parent
V20 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v20-20261101")
V21 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v21-20261101")
V18 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v18-20261023")
V19 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v19-20261025")

V19_GOVERNANCE = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v19-authoritative-artifact-"
    "predecessor-identity-verifier-binding-defect-prelock-erratum-and-"
    "continuation-or-successor-decision-governance-v1-20261101"
)
V18_GOVERNANCE = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v18-locked-runner-"
    "canonicalization-precheck-import-binding-defect-post-lock-pre-attempt-"
    "erratum-and-successor-decision-governance-v1-20261025"
)
V17_GOVERNANCE = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v17-independent-validator-"
    "v16-tree-canonicalization-order-mismatch-prelock-erratum-and-"
    "continuation-or-successor-decision-governance-v1-20261023"
)

V20_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V20"
V21_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V21"
V18_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V18"
V19_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V19"
V17_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V17"

V20_WORKSPACE_MEMBER_COUNT = 179
V20_WORKSPACE_TREE_SHA256 = "6a8c7a4516e81a8890d22948e7bd6f55c429cf9f83682b761b33afb4ff0eb192"
V20_PRELOCK_MEMBER_COUNT = 80
V20_PRELOCK_TREE_SHA256 = "da12a9ebc711de7c6a3eb61d8295f2772b89ef4b7ba02a063dcf09f5157d3242"
V20_MANIFEST_DECLARED_MEMBER_COUNT = 78
V20_MANIFEST_DECLARED_ROOT_SHA256 = "c172eccb0e43bd0fe15bdc110835fff6017e885ecfc927f9a4c807401aaf82fc"
V20_HASHES = {
    "terminal": "67d52f4970ee06e8799a5c9d2cfb11e24337ff8eebfa3adb44a4de952531adb0",
    "failure_manifest": "95c89dbf678e2ec96622c1f9ded590fdef570a576e54cee67fd4426ce32b380e",
    "freeze_verification": "3ab3115b8c933806b04a480054c3b17757f7d2d88a990727c003f043f1fc0ab9",
    "failure_record": "44383fd44c777a031933829e9d4c25d3a88fcac7053417ad49fe90114a657c35",
    "unit": "6ed00d3bacc473e04b494a877f72c4332355c15520800cf5ab99992d3616557c",
    "primary": "6e121dc8dc5c4c2eee89f321a236854d25192da7674c397b1fc6842eb11409bf",
    "independent_validator": "505c72034063d6380f5befe2bf030ec86dcaf2ce1642e53dfb1845b2db1f4959",
    "canonical_predecessor_contract": "71039416265891b802dffdfe2b04ae2a7b2c4604e99fd93148dd1683c3334445",
}
V20_PATHS = {
    "terminal": "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "failure_manifest": "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
    "freeze_verification": "results/prelock/PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
    "failure_record": "results/prelock/independent-static-validation-execution-failure-run-0001.json",
    "unit": "results/prelock/unit-fixtures-run-0001.json",
    "primary": "results/prelock/primary-static-validation-run-0001.json",
    "independent_validator": "validators/independent_static_validate.py",
    "canonical_predecessor_contract": "contracts/CANONICAL_PREDECESSOR_BINDING_CONTRACT.json",
}

V18_TREE = (164, "c92f0bd0d7ea111d9bfd6d3d4e612e5b1cd763d70c69f47fef6a2907c0be0f4d")
V19_TREE = (163, "830ca3de6980cb553725fbc97f79ac453a238f511c133c1a0ab5f751690601a5")
V19_GOVERNANCE_LOCK_SHA256 = "3a31a5ac2554ac9723a00fecd7d1bc54e41e79abbffee87c130f58c69a0e4afa"
V19_SUCCESSOR_DECISION_SHA256 = "bb59b30c4549d786e9e52872ac828c64fc002d3896abf6e06a564ceafd104e10"

EXTERNAL_ARTIFACT_ID = "V17_PRELOCK_FROZEN_EVIDENCE_BINDING"
EXTERNAL_ARTIFACT_ROLE = "TRANSITIVE_FROZEN_PREDECESSOR_EVIDENCE_BINDING"
EXTERNAL_ARTIFACT_RELATION = "V17_FROZEN_HISTORY_REQUIRED_TO_VERIFY_CANONICAL_PREDECESSOR_V18"
CORRECT_EXTERNAL_ARTIFACT = V17_GOVERNANCE / "V17_PRELOCK_FROZEN_EVIDENCE_BINDING.json"
WRONG_EXTERNAL_ARTIFACT = V18_GOVERNANCE / "V17_PRELOCK_FROZEN_EVIDENCE_BINDING.json"
EXTERNAL_ARTIFACT_SHA256 = "7b112d3a2f0e69e754d23051608a0cb8fb20edc375a9d42c0c8898dd0020f360"
EXTERNAL_ARTIFACT_SIZE = 1115
V17_GOVERNANCE_LOCK_SHA256 = "053abd247ab8b80624abe58346707deeb2cda5b9848ee245d9dc146c02624080"
V17_SUCCESSOR_DECISION_SHA256 = "8e0d1d19e6f443e8d2985bb884d437877bacd94da61541731af5d5046f75235f"

DECISION = "TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V21_CONDITIONALLY"

SOURCE_FILES = (
    "governance_common.py", "build_governance.py", "validate_governance.py",
    "negative_fixtures.py", "independent_validate.py", "freeze_governance.py",
    "verify_governance_freeze.py",
)
DOCUMENT_FILES = (
    "GOVERNANCE_CHARTER.json",
    "V20_FROZEN_FAILURE_EVIDENCE_BINDING.json",
    "EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_INCIDENT.json",
    "INDEPENDENT_VALIDATOR_EXTERNAL_PREDECESSOR_ARTIFACT_PATH_BINDING_DEFECT_ADJUDICATION.json",
    "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION.json",
    "CANONICAL_EXTERNAL_PREDECESSOR_ARTIFACT_BINDING_CONTRACT.json",
    "V21_EXTERNAL_PREDECESSOR_ARTIFACT_REGRESSION_MATRIX.json",
    "SUCCESSOR_V21_REQUIREMENTS.json",
    "V20_IMMUTABILITY_AND_AUTHORITY_CEILING.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "ROUTING_LEDGER.json",
    "NEXT_LEGAL_MILESTONE.json",
)
VALIDATION_FILES = (
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_json_bytes(value) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json_once(path: Path, value) -> None:
    if path.exists():
        raise FileExistsError(f"append-only output exists: {path}")
    path.write_bytes(canonical_json_bytes(value))


def component_key(relative: str):
    return tuple(part.encode("utf-8") for part in PurePosixPath(relative).parts)


def normative_tree(root: Path):
    rows = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise AssertionError(f"unexpected symlink in frozen tree: {path}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            rows.append((component_key(relative), relative, sha256_file(path)))
    rows.sort(key=lambda row: row[0])
    stream = b"".join(name.encode("utf-8") + b"\0" + digest.encode("ascii") + b"\n" for _, name, digest in rows)
    return len(rows), sha256_bytes(stream)


def prelock_files():
    root = V20 / "results/prelock"
    return sorted((p for p in root.rglob("*") if p.is_file()), key=lambda p: component_key(p.relative_to(root).as_posix()))


def assert_v20_frozen() -> None:
    if normative_tree(V20) != (V20_WORKSPACE_MEMBER_COUNT, V20_WORKSPACE_TREE_SHA256):
        raise AssertionError(f"V20 workspace drift: {normative_tree(V20)}")
    prelock = V20 / "results/prelock"
    if normative_tree(prelock) != (V20_PRELOCK_MEMBER_COUNT, V20_PRELOCK_TREE_SHA256):
        raise AssertionError(f"V20 prelock drift: {normative_tree(prelock)}")
    if not all((path.stat().st_mode & 0o222) == 0 for path in prelock_files()):
        raise AssertionError("V20 frozen prelock evidence contains writable member")
    for key, relative in V20_PATHS.items():
        if sha256_file(V20 / relative) != V20_HASHES[key]:
            raise AssertionError(f"V20 bound artifact drift: {relative}")
    manifest = load_json(V20 / V20_PATHS["failure_manifest"])
    if manifest.get("member_count") != V20_MANIFEST_DECLARED_MEMBER_COUNT:
        raise AssertionError("V20 manifest member count drift")
    if manifest.get("canonical_evidence_root_sha256") != V20_MANIFEST_DECLARED_ROOT_SHA256:
        raise AssertionError("V20 manifest root drift")
    for item in manifest.get("members", []):
        path = prelock / item["path"]
        if not path.is_file() or sha256_file(path) != item["sha256"] or path.stat().st_size != item["bytes"]:
            raise AssertionError(f"V20 manifest member drift: {item['path']}")
    terminal = load_json(V20 / V20_PATHS["terminal"])
    if terminal.get("status") != "FAIL_CLOSED_DURING_INDEPENDENT_STATIC_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE":
        raise AssertionError("V20 terminal status drift")
    if terminal.get("static_lock") != "NOT_ISSUED":
        raise AssertionError("V20 static lock unexpectedly issued")
    if any(terminal.get(name) != 0 for name in ("attempt_count", "worker_invocation_count", "codex_as_worker_invocation_count", "semantic_codex_execve_count")):
        raise AssertionError("V20 execution counters are not zero")
    if list(V20.rglob("ATTEMPT_MARKER.json")) or list(V20.rglob("RUNTIME_RESULT.json")):
        raise AssertionError("V20 attempt or runtime evidence unexpectedly exists")


def assert_predecessor_history_unchanged() -> None:
    if normative_tree(V18) != V18_TREE:
        raise AssertionError(f"V18 predecessor drift: {normative_tree(V18)}")
    if normative_tree(V19) != V19_TREE:
        raise AssertionError(f"V19 history drift: {normative_tree(V19)}")


def successor_authority_facts():
    lock = V19_GOVERNANCE / "GOVERNANCE_LOCK.json"
    decision = V19_GOVERNANCE / "V19_TERMINAL_AND_V20_SUCCESSOR_DECISION.json"
    value = load_json(decision)
    return {
        "governance_lock_sha256": sha256_file(lock),
        "successor_decision_sha256": sha256_file(decision),
        "decision": value.get("decision"),
        "v20": value.get("v20"),
    }


def external_artifact_facts():
    validator = (V20 / V20_PATHS["independent_validator"]).read_text(encoding="utf-8")
    failure = load_json(V20 / V20_PATHS["failure_record"])
    primary = load_json(V20 / V20_PATHS["primary"])
    canonical = load_json(V20 / V20_PATHS["canonical_predecessor_contract"])
    primary_gate = next(check for check in primary["checks"] if check["id"] == "S008C3_CANONICAL_PREDECESSOR")
    correct_value = load_json(CORRECT_EXTERNAL_ARTIFACT)
    return {
        "canonical_predecessor_identity": canonical.get("predecessor_identity"),
        "primary_canonical_predecessor_gate": primary_gate.get("status"),
        "primary_canonical_predecessor_identity": primary_gate.get("evidence", {}).get("predecessor_identity"),
        "failed_operation": failure.get("failed_operation"),
        "failure_class": failure.get("failure_class"),
        "exception_type": failure.get("exception_type"),
        "resolved_missing_path": failure.get("resolved_missing_path"),
        "wrong_locator": str(WRONG_EXTERNAL_ARTIFACT),
        "wrong_locator_exists": WRONG_EXTERNAL_ARTIFACT.exists(),
        "correct_locator": str(CORRECT_EXTERNAL_ARTIFACT),
        "correct_locator_exists": CORRECT_EXTERNAL_ARTIFACT.is_file(),
        "correct_locator_is_symlink": CORRECT_EXTERNAL_ARTIFACT.is_symlink(),
        "correct_sha256": sha256_file(CORRECT_EXTERNAL_ARTIFACT),
        "correct_size": CORRECT_EXTERNAL_ARTIFACT.stat().st_size,
        "correct_owner_identity": correct_value.get("execution_identity"),
        "source_binds_wrong_governance_directory": f'v18_gov=Path("{V18_GOVERNANCE}")' in validator,
        "source_joins_filename_to_wrong_directory": 'v17_binding=load(v18_gov/"V17_PRELOCK_FROZEN_EVIDENCE_BINDING.json")' in validator,
    }


def package_member_paths(exclude=()):
    excluded = set(exclude)
    return sorted((p for p in PACKAGE.iterdir() if p.is_file() and p.name not in excluded), key=lambda p: p.name.encode("utf-8"))


def package_root(paths):
    return sha256_bytes(b"".join(p.name.encode("utf-8") + b"\0" + sha256_file(p).encode("ascii") + b"\n" for p in paths))


def is_read_only(path: Path) -> bool:
    return (path.stat().st_mode & 0o222) == 0


def set_read_only(path: Path) -> None:
    os.chmod(path, 0o444)
