#!/usr/bin/env python3
from governance_common import *
def main():
    manifest=load_json(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json");lock=load_json(PACKAGE/"GOVERNANCE_LOCK.json");checks=[]
    def check(i,c,e=None):checks.append({"id":i,"status":"PASS" if c else "FAIL","evidence":e})
    listed=[]
    for item in manifest["members"]:
        path=PACKAGE/item["path"];listed.append(path);check(f"F_MEMBER_{item['path']}",path.is_file() and sha256_file(path)==item["sha256"] and path.stat().st_size==item["bytes"] and is_read_only(path))
    check("F001_COUNT",len(listed)==manifest["member_count"]);check("F002_ROOT",package_root(listed)==manifest["canonical_root_sha256"])
    check("F003_LOCK_BINDING",lock["manifest_sha256"]==sha256_file(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json") and lock["canonical_root_sha256"]==manifest["canonical_root_sha256"])
    check("F004_STATUS",lock["status"]=="PASS_LOCKED_GOVERNANCE_ONLY" and lock["decision"]==DECISION)
    check("F005_LOCK_READ_ONLY",is_read_only(PACKAGE/"GOVERNANCE_LOCK.json") and is_read_only(PACKAGE/"GOVERNANCE_ARTIFACT_MANIFEST.json"))
    check("F006_V22_UNCHANGED",normative_tree(V22)==V22_TREE,normative_tree(V22));check("F007_V22_PRELOCK_UNCHANGED",normative_tree(V22/"results/prelock")==V22_PRELOCK_TREE)
    check("F008_V21_UNCHANGED",normative_tree(V21)==V21_TREE,normative_tree(V21))
    terminal=load_json(V22/PATHS["terminal"]);check("F009_NO_EXECUTION",terminal["static_lock"]=="NOT_ISSUED" and terminal["attempt_count"]==terminal["worker_invocation_count"]==terminal["codex_as_worker_invocation_count"]==0 and not list(V22.rglob("ATTEMPT_MARKER.json")))
    check("F010_FAILURE_EVIDENCE_READ_ONLY",all(is_read_only(V22/PATHS[x]) for x in ("terminal","manifest","freeze","unit")))
    failed=[x["id"] for x in checks if x["status"]!="PASS"]
    result={"record_type":"FINAL_GOVERNANCE_FREEZE_VERIFICATION","governance_identity":GOVERNANCE_ID,"checks":checks,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failed),"failed":len(failed)},"failure_ids":failed,"status":"PASS" if not failed else "FAIL_CLOSED","governance_lock_sha256":sha256_file(PACKAGE/"GOVERNANCE_LOCK.json")}
    write_json_once(PACKAGE/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",result);set_read_only(PACKAGE/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json")
    os.chmod(PACKAGE,0o555);print(f"FINAL_FREEZE_VERIFICATION={result['status']} {len(checks)-len(failed)}/{len(checks)} LOCK_SHA256={result['governance_lock_sha256']}")
    if failed:raise SystemExit(1)
if __name__=="__main__":main()
