#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json
from pathlib import Path,PurePosixPath
from governance_common import GOVERNANCE_ID,PACKAGE,V22,V21,V20_GOV,V22_TREE,V21_TREE,V22_STATE,DECISION,PATHS,HASHES,V20_CANONICAL_DECISION,V20_CANONICAL_DECISION_SHA,V21_CANONICAL_REGRESSION,V21_CANONICAL_REGRESSION_SHA,V20_GOV_LOCK_SHA,VALIDATION_FILES,DOCUMENT_FILES,write_json_once
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def tree(root):
 rows=[]
 for p in root.rglob("*"):
  if p.is_symlink():raise RuntimeError(f"symlink:{p}")
  if p.is_file():
   r=p.relative_to(root).as_posix();rows.append((tuple(x.encode() for x in PurePosixPath(r).parts),r,digest(p)))
 rows.sort(key=lambda x:x[0]);return len(rows),hashlib.sha256(b"".join(r.encode()+b"\0"+d.encode()+b"\n" for _,r,d in rows)).hexdigest()
def main():
 checks=[]
 def check(i,c,e=None):checks.append({"id":i,"status":"PASS" if c else "FAIL","evidence":e})
 check("I001_PRIMARY",load(PACKAGE/VALIDATION_FILES[0])["status"]=="PASS")
 check("I002_NEGATIVE",load(PACKAGE/VALIDATION_FILES[1])["status"]=="PASS")
 check("I003_DOCUMENTS",all((PACKAGE/n).is_file() for n in DOCUMENT_FILES))
 check("I004_V22_TREE",tree(V22)==V22_TREE,tree(V22));check("I005_V21_TREE",tree(V21)==V21_TREE,tree(V21))
 for k in ("terminal","manifest","freeze","unit"):check(f"I_HASH_{k}",digest(V22/PATHS[k])==HASHES[k])
 unit=load(V22/PATHS["unit"]);terminal=load(V22/PATHS["terminal"])
 check("I006_STATE",terminal["status"]==V22_STATE and unit["validation_counts"]=={"failed":5,"passed":236,"total":241})
 check("I007_NO_EXECUTION",terminal["static_lock"]=="NOT_ISSUED" and terminal["attempt_count"]==terminal["worker_invocation_count"]==terminal["codex_as_worker_invocation_count"]==0 and not list(V22.rglob("ATTEMPT_MARKER.json")))
 binding=load(V22/PATHS["prompt_binding"]);prompt_sha=digest(V22/PATHS["prompt"]);request_sha=digest(V22/PATHS["request"])
 check("I008_PROMPT_BYTES",prompt_sha==HASHES["prompt"]==binding["first_prompt_sha256"]==binding["worker_request_bound_prompt_sha256"]==binding["reread_prompt_sha256"] and request_sha==binding["worker_request_sha256"])
 check("I009_PROMPT_MODE",(V22/PATHS["prompt"]).stat().st_mode&0o777==0o644 and (V22/PATHS["request"]).stat().st_mode&0o777==0o444)
 source=(V22/PATHS["invocation"]).read_text()
 check("I010_SELECTOR",'contracts/SUCCESSOR_V22_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json' in source and not (V22/'contracts/SUCCESSOR_V22_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json').exists())
 check("I011_CACHE_BYTES",digest(V22/PATHS["cache_policy"])==HASHES["cache_policy"] and digest(V22/PATHS["cache_companion"])==HASHES["cache_companion"])
 canonical=load(V20_CANONICAL_DECISION);local=load(V22/PATHS["v20_local_decision"])
 check("I012_HISTORICAL_DECISION",digest(V20_CANONICAL_DECISION)==V20_CANONICAL_DECISION_SHA and canonical["decision"]=="TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V21_CONDITIONALLY" and local["decision"]=="TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V22_CONDITIONALLY")
 check("I013_EXTERNAL_ARTIFACTS",digest(V21_CANONICAL_REGRESSION)==V21_CANONICAL_REGRESSION_SHA and digest(V20_GOV/'GOVERNANCE_LOCK.json')==V20_GOV_LOCK_SHA)
 adj=load(PACKAGE/'V22_FIVE_GATE_FAILURE_ADJUDICATION.json')
 check("I014_ADJUDICATION",adj["PYTHON_CACHE_SUCCESSOR_CONTRACT_SELECTOR_DEFECT"]==adj["PROMPT_BINDING_IMMUTABILITY_MODE_DEFECT"]==adj["V20_HISTORICAL_DECISION_VERIFIER_BINDING_DEFECT"]==adj["STALE_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT"]=="YES")
 check("I015_SEPARATE_EXTERNALS",len(adj["external_artifacts"])==2 and {x["failed_gate"] for x in adj["external_artifacts"]}=={"U091_EXTERNAL_v20_to_v22_successor_decision","U096_EXTERNAL_v22_external_predecessor_artifact_regression_matrix"})
 check("I016_RUNTIME_UNKNOWN",adj["runtime_adjudication"]["V22_RUNTIME_DEFECT"]==adj["runtime_adjudication"]["V22_CODEX_DEFECT"]==adj["runtime_adjudication"]["TEMPORAL_RUNTIME"]=="NOT_ESTABLISHED" and adj["runtime_adjudication"]["CONFINEMENT"]=="NOT_PROVEN")
 decision=load(PACKAGE/'V22_TERMINAL_AND_V23_SUCCESSOR_DECISION.json');check("I017_DECISION",decision["decision"]==DECISION and decision["v22_continuation"]=="PROHIBITED" and decision["v23"]=="CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
 contract=load(PACKAGE/'UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json');check("I018_CONTRACT",set(contract["bound_domains"])=={"SUCCESSOR_SELECTOR","PROMPT_BYTES_DIGEST_AND_MODE","HISTORICAL_GOVERNANCE_DECISIONS","CANONICAL_PREDECESSOR_ARTIFACTS","EXTERNAL_TRANSITIVE_ARTIFACTS"} and "MIXED_GENERATIONS" in contract["prohibited"])
 failed=[x["id"] for x in checks if x["status"]!="PASS"]
 result={"record_type":"INDEPENDENT_GOVERNANCE_VALIDATION","governance_identity":GOVERNANCE_ID,"implementation_independence":"SEPARATE_TREE_HASH_BYTE_MODE_AND_LOCATOR_RECOMPUTATION_WITHOUT_PRIMARY_VERDICT_REUSE","checks":checks,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failed),"failed":len(failed)},"failure_ids":failed,"status":"PASS" if not failed else "FAIL_CLOSED"}
 write_json_once(PACKAGE/VALIDATION_FILES[2],result);print(f"INDEPENDENT_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failed)}/{len(checks)}")
 if failed:raise SystemExit(1)
if __name__=="__main__":main()
