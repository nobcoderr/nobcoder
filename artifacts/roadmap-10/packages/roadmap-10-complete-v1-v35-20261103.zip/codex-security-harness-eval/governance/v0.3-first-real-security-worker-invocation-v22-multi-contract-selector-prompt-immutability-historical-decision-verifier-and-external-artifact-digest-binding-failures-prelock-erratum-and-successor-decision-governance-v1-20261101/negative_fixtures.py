#!/usr/bin/env python3
from governance_common import *

def verdict(*, selector="CACHE_POLICY_V22", selector_authorized=True, prompt_digest=True, prompt_mode="0444", decision_identity="V20_TO_V21", decision_authorized=True, external=("V20_TO_V21","V21_MATRIX"), generation="GEN-1", member_generations=("GEN-1","GEN-1","GEN-1","GEN-1"), exact_artifacts=True):
    checks={"selector":selector=="CACHE_POLICY_V22" and selector_authorized,"prompt":prompt_digest and prompt_mode=="0444","decision":decision_identity=="V20_TO_V21" and decision_authorized,"external":external==("V20_TO_V21","V21_MATRIX"),"generation":all(x==generation for x in member_generations),"artifacts":exact_artifacts}
    return {"status":"PASS" if all(checks.values()) else "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT","checks":checks}

def main():
    assert_v22_frozen();assert_v21_integrity();cases=[]
    def case(i,v,expect):cases.append({"id":i,"status":"PASS" if (v["status"]=="PASS")==expect else "FAIL","verdict":v})
    case("N001_EXACT_GENERATION",verdict(),True)
    case("N002_STALE_SELECTOR",verdict(selector="CACHE_POLICY_V21"),False)
    case("N003_VERSION_INFERENCE",verdict(selector_authorized=False),False)
    case("N004_PROMPT_DIGEST_RIGHT_MODE_WRONG",verdict(prompt_mode="0644"),False)
    case("N005_PROMPT_EXACT_DIGEST_MODE_0444",verdict(),True)
    case("N006_STALE_HISTORICAL_DECISION",verdict(decision_identity="V20_TO_V22"),False)
    case("N007_HISTORICAL_DECISION_UNAUTHORIZED",verdict(decision_authorized=False),False)
    case("N008_STALE_EXTERNAL_DECISION",verdict(external=("V20_TO_V22","V21_MATRIX")),False)
    case("N009_STALE_EXTERNAL_MATRIX",verdict(external=("V20_TO_V21","V22_MATRIX")),False)
    case("N010_WRONG_ARTIFACT_CORRECT_DIGEST_FIELD",verdict(exact_artifacts=False),False)
    case("N011_MIXED_GENERATIONS",verdict(member_generations=("GEN-1","GEN-2","GEN-1","GEN-1")),False)
    case("N012_MISSING_AUTHORITY",verdict(selector_authorized=False,decision_authorized=False),False)
    case("N013_V22_UNCHANGED",{"status":"PASS" if normative_tree(V22)==V22_TREE else "FAIL"},True)
    case("N014_V21_UNCHANGED",{"status":"PASS" if normative_tree(V21)==V21_TREE else "FAIL"},True)
    failed=[x["id"] for x in cases if x["status"]!="PASS"]
    result={"record_type":"NEGATIVE_GOVERNANCE_FIXTURES","governance_identity":GOVERNANCE_ID,"cases":cases,"validation_counts":{"total":len(cases),"passed":len(cases)-len(failed),"failed":len(failed)},"failure_ids":failed,"status":"PASS" if not failed else "FAIL_CLOSED"}
    write_json_once(PACKAGE/VALIDATION_FILES[1],result);print(f"NEGATIVE_GOVERNANCE_FIXTURES={result['status']} {len(cases)-len(failed)}/{len(cases)}")
    if failed:raise SystemExit(1)
if __name__=="__main__":main()
