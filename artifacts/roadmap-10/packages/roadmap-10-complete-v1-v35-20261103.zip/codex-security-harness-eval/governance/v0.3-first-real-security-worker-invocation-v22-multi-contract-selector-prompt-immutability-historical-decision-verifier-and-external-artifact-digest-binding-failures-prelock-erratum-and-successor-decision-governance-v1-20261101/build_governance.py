#!/usr/bin/env python3
from governance_common import *

def main():
    assert_v22_frozen(); assert_v21_integrity()
    unit = load_json(V22 / PATHS["unit"])
    prompt_binding = load_json(V22 / PATHS["prompt_binding"])
    docs = {
        "GOVERNANCE_CHARTER.json": {
            "record_type": "V22_GOVERNANCE_ONLY_CHARTER", "governance_identity": GOVERNANCE_ID,
            "scope": "ADJUDICATE_FIVE_FROZEN_UNIT_FAILURES_AND_DECIDE_SUCCESSOR_ONLY",
            "prohibited": ["V22_MUTATION", "V22_RERUN", "V22_CHMOD", "DIGEST_REPLACEMENT", "PRIMARY_OR_INDEPENDENT_CONTINUATION", "STATIC_LOCK", "SECURITY_WORKER_OR_CODEX_INVOCATION", "V23_CREATION_OR_EXECUTION"],
            "freeze_prerequisites": ["PRIMARY_GOVERNANCE_VALIDATION_PASS", "NEGATIVE_FIXTURES_PASS", "INDEPENDENT_GOVERNANCE_VALIDATION_PASS", "READ_ONLY_INTEGRITY_PASS", "FINAL_FREEZE_VERIFICATION_PASS"],
        },
        "V22_FROZEN_FAILURE_EVIDENCE_BINDING.json": {
            "record_type": "V22_FROZEN_FAILURE_EVIDENCE_BINDING", "execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V22",
            "disposition": V22_STATE, "workspace_member_count": V22_TREE[0], "workspace_tree_sha256": V22_TREE[1],
            "prelock_member_count": V22_PRELOCK_TREE[0], "prelock_tree_sha256": V22_PRELOCK_TREE[1],
            "hashes": {key: HASHES[key] for key in ("terminal", "manifest", "freeze", "unit")},
            "unit": unit["validation_counts"], "failure_ids": unit["failure_ids"],
            "primary": "NOT_STARTED", "independent": "NOT_STARTED", "static_lock": "NOT_ISSUED",
            "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
            "v21_reference": {"member_count": V21_TREE[0], "tree_sha256": V21_TREE[1]},
        },
        "V22_FIVE_GATE_FAILURE_ADJUDICATION.json": {
            "record_type": "V22_FIVE_GATE_FAILURE_ADJUDICATION",
            "PYTHON_CACHE_SUCCESSOR_CONTRACT_SELECTOR_DEFECT": "YES",
            "python_cache": {
                "failed_gate": "U000O_CACHE_PREFLIGHT", "evidence": "SOURCE_SELECTS_NONEXISTENT_SUCCESSOR_V22_FILENAME",
                "selected_nonexistent_locator": "contracts/SUCCESSOR_V22_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json",
                "normative_policy_identity": "V22_PYTHON_RUNTIME_SIDE_EFFECT_POLICY", "normative_policy_sha256": HASHES["cache_policy"],
                "normative_companion_logical_identity": "V22_PYTHON_CACHE_AND_WORKSPACE_WRITE_BOUNDARY_CONTRACT",
                "frozen_companion_locator": PATHS["cache_companion"], "frozen_companion_sha256": HASHES["cache_companion"],
                "selector_authority": "V22_AUTHORITATIVE_ARTIFACT_DIGEST_BINDING_RECORD_PLUS_V21_TO_V22_GOVERNANCE_AUTHORITY",
                "version_number_or_stale_literal_inference": "PROHIBITED",
            },
            "PROMPT_BINDING_IMMUTABILITY_MODE_DEFECT": "YES",
            "prompt": {
                "failed_gate": "U027_V7_PROMPT_IDENTITY", "prompt_sha256": HASHES["prompt"],
                "first_bound_reread_sha256_equal": prompt_binding["first_prompt_sha256"] == prompt_binding["worker_request_bound_prompt_sha256"] == prompt_binding["reread_prompt_sha256"] == HASHES["prompt"],
                "worker_request_sha256": HASHES["request"], "binding_worker_request_sha256": prompt_binding["worker_request_sha256"],
                "prompt_mode_observed": "0644", "prompt_mode_required": "0444", "request_mode_observed": "0444", "binding_mode_observed": "0444",
                "required_order": ["FINAL_PROMPT_BYTES", "SHA256", "BIND_TO_WORKER_REQUEST", "REREAD_AND_REHASH", "EXACT_DIGEST_EQUALITY", "APPLY_MODE_0444", "REREAD_MODE_AND_REQUIRE_EXACT_0444", "ADMIT_DEPENDENCY"],
                "prompt_byte_or_digest_identity_defect": "NO",
            },
            "V20_HISTORICAL_DECISION_VERIFIER_BINDING_DEFECT": "YES",
            "historical_decision": {
                "failed_gate": "U049_PREDECESSOR", "authoritative_identity": "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION",
                "owner": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V20_GOVERNANCE_ONLY",
                "canonical_locator": str(V20_CANONICAL_DECISION), "canonical_sha256": V20_CANONICAL_DECISION_SHA,
                "v22_local_stale_locator": PATHS["v20_local_decision"], "v22_local_stale_sha256": HASHES["v20_local_decision"],
                "canonical_decision": "TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V21_CONDITIONALLY",
                "v22_stale_decision": "TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V22_CONDITIONALLY",
                "resolution_authority": {"governance_lock": str(V20_GOV / "GOVERNANCE_LOCK.json"), "governance_lock_sha256": V20_GOV_LOCK_SHA},
                "number_directory_or_stale_literal_inference": "PROHIBITED",
            },
            "STALE_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT": "YES",
            "external_artifacts": [
                {
                    "failed_gate": "U091_EXTERNAL_v20_to_v22_successor_decision", "authoritative_logical_identity": "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION",
                    "owner": "V20_GOVERNANCE", "role": "HISTORICAL_SUCCESSOR_DECISION", "canonical_locator": str(V20_CANONICAL_DECISION),
                    "authoritative_sha256": V20_CANONICAL_DECISION_SHA, "v22_bound_logical_identity": "v20_to_v22_successor_decision",
                    "v22_bound_nonexistent_locator": str(V20_GOV / "V20_TERMINAL_AND_V22_SUCCESSOR_DECISION.json"), "v22_bound_stale_digest": V20_CANONICAL_DECISION_SHA,
                    "governance_authority_sha256": V20_GOV_LOCK_SHA, "staleness_source": "SUCCESSOR_VERSION_LITERAL_REWRITE_WITHOUT_LOGICAL_IDENTITY_AND_LOCATOR_REBINDING",
                },
                {
                    "failed_gate": "U096_EXTERNAL_v22_external_predecessor_artifact_regression_matrix", "authoritative_logical_identity": "V21_EXTERNAL_PREDECESSOR_ARTIFACT_REGRESSION_MATRIX",
                    "owner": "V20_GOVERNANCE", "role": "SUCCESSOR_V21_EXTERNAL_ARTIFACT_REGRESSION_MATRIX", "canonical_locator": str(V21_CANONICAL_REGRESSION),
                    "authoritative_sha256": V21_CANONICAL_REGRESSION_SHA, "v22_bound_logical_identity": "v22_external_predecessor_artifact_regression_matrix",
                    "v22_bound_nonexistent_locator": str(V20_GOV / "V22_EXTERNAL_PREDECESSOR_ARTIFACT_REGRESSION_MATRIX.json"), "v22_bound_stale_digest": V21_CANONICAL_REGRESSION_SHA,
                    "governance_authority_sha256": V20_GOV_LOCK_SHA, "staleness_source": "SUCCESSOR_VERSION_LITERAL_REWRITE_WITHOUT_LOGICAL_IDENTITY_AND_LOCATOR_REBINDING",
                },
            ],
            "runtime_adjudication": {"V22_RUNTIME_DEFECT": "NOT_ESTABLISHED", "V22_CODEX_DEFECT": "NOT_ESTABLISHED", "TEMPORAL_RUNTIME": "NOT_ESTABLISHED", "PROCESS_LINEAGE": "NOT_PROVEN", "PRODUCER_AUTHORIZATION": "NOT_PROVEN", "CONFINEMENT": "NOT_PROVEN"},
        },
        "V22_TERMINAL_AND_V23_SUCCESSOR_DECISION.json": {
            "record_type": "V22_TERMINAL_AND_V23_SUCCESSOR_DECISION", "decision": DECISION,
            "v22": V22_STATE, "v22_continuation": "PROHIBITED", "v22_mutation_allowlist": [],
            "v23": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED", "v23_attempt": "0_OF_1", "v23_worker": "0_OF_1", "v23_codex": "0_OF_1",
        },
        "UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json": {
            "record_type": "V23_UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT", "contract_identity": "V23_UNIFIED_BINDING_GENERATION_V1",
            "normative_order": ["RESOLVE_EXACT_GOVERNANCE_AUTHORITY", "RESOLVE_LOGICAL_ARTIFACT_IDENTITIES", "CONSTRUCT_FINAL_BYTES", "COMPUTE_DIGEST_AND_SIZE", "BIND_CANONICAL_LOCATOR_OWNER_ROLE_AND_RELATION", "REREAD_AND_REHASH", "APPLY_REQUIRED_MODE", "REREAD_MODE", "EMIT_ONE_GENERATION_MANIFEST", "INDEPENDENTLY_VALIDATE_COMPLETE_GENERATION"],
            "bound_domains": ["SUCCESSOR_SELECTOR", "PROMPT_BYTES_DIGEST_AND_MODE", "HISTORICAL_GOVERNANCE_DECISIONS", "CANONICAL_PREDECESSOR_ARTIFACTS", "EXTERNAL_TRANSITIVE_ARTIFACTS"],
            "required_fields": ["generation_identity", "governance_identity", "logical_artifact_identity", "owner_identity", "artifact_role", "canonical_locator", "sha256", "size", "required_mode", "relationship", "consumer_set"],
            "prohibited": ["VERSION_NUMBER_INFERENCE", "DIRECTORY_GUESSING", "STALE_LITERAL_REUSE", "FILENAME_SEARCH", "FALLBACK_SCAN", "MIXED_GENERATIONS", "DIGEST_ONLY_ACCEPTANCE", "MODE_ONLY_ACCEPTANCE", "POST_BIND_MUTATION"],
            "readiness": "ONLY_ONE_COMPLETE_EXACT_GENERATION_MAY_BE_CURRENT",
            "mismatch": "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT",
        },
        "V22_FAILURE_AND_V23_REGRESSION_MATRIX.json": {
            "record_type": "V22_FAILURE_AND_V23_REGRESSION_MATRIX", "required_cases": [
                "WRONG_OR_STALE_SUCCESSOR_SELECTOR", "VERSION_NUMBER_SELECTOR_INFERENCE", "PROMPT_CORRECT_DIGEST_WRONG_MODE", "PROMPT_EXACT_DIGEST_EXACT_0444_MODE",
                "STALE_HISTORICAL_DECISION_VERIFIER", "EXACT_GOVERNANCE_BOUND_HISTORICAL_DECISION", "STALE_EXTERNAL_DECISION_DIGEST_BINDING", "STALE_EXTERNAL_REGRESSION_DIGEST_BINDING",
                "WRONG_ARTIFACT_WITH_OTHERWISE_CORRECT_DIGEST", "MIXED_BINDING_GENERATIONS", "FULLY_CONSISTENT_EXACT_AUTHORITATIVE_BINDING_GENERATION"
            ], "all_negative_cases": "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT",
        },
        "SUCCESSOR_V23_REQUIREMENTS.json": {
            "record_type": "SUCCESSOR_V23_REQUIREMENTS", "status": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
            "fresh_workspace": "REQUIRED", "v22_reference_only": True, "unified_binding_generation_contract": "NORMATIVE",
            "complete_chain": ["UNIT", "PRIMARY", "INDEPENDENT", "FRESH_PREFLIGHT", "DEPENDENCY_CLOSURE", "STATIC_LOCK", "LOCK_VERIFICATION", "POST_LOCK_PREFLIGHT", "LOCKED_PRE_ATTEMPT_ENTRYPOINT"],
            "attempt_rule": "ONLY_IF_ALL_PRE_ATTEMPT_GATES_PASS", "retry": "PROHIBITED",
        },
        "NEGATIVE_GOVERNANCE_TEST_MATRIX.json": {"record_type": "NEGATIVE_GOVERNANCE_TEST_MATRIX", "cases": ["STALE_SELECTOR", "VERSION_INFERENCE", "PROMPT_MODE_0644", "STALE_DECISION", "STALE_EXTERNAL_1", "STALE_EXTERNAL_2", "WRONG_ARTIFACT_SAME_DIGEST_FIELD", "MIXED_GENERATION", "EXACT_GENERATION"]},
        "ROUTING_LEDGER.json": {"record_type": "GOVERNANCE_ROUTING_LEDGER", "active": ["mandatory-auto-router", "codex-security-harness", "expert-python-engineer"], "not_applicable": ["LIVE_TARGET", "CREDENTIAL", "NETWORK", "SUBAGENT", "PARALLELISM", "EXPLOIT", "PROMOTION", "SUBMISSION"]},
        "NEXT_LEGAL_MILESTONE.json": {"record_type": "NEXT_LEGAL_MILESTONE", "milestone": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V23_ONCE_IF_ALL_GATES_PASS", "precondition": "THIS_GOVERNANCE_LOCK_PASS_LOCKED_GOVERNANCE_ONLY"},
    }
    for name, value in docs.items(): write_json_once(PACKAGE / name, value)
    print(f"GOVERNANCE_BUILD=PASS DOCUMENTS={len(docs)}")

if __name__ == "__main__": main()
