#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath

GOVERNANCE_ID = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V22_MULTI_CONTRACT_SELECTOR_"
    "PROMPT_IMMUTABILITY_HISTORICAL_DECISION_VERIFIER_AND_EXTERNAL_ARTIFACT_"
    "DIGEST_BINDING_FAILURES_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
)
PACKAGE = Path(__file__).resolve().parent
V22 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v22-20261101")
V21 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v21-20261101")
V20_GOV = Path(
    "/home/nobcoder/codex-security-harness-eval/governance/"
    "v0.3-first-real-security-worker-invocation-v20-independent-validator-external-"
    "predecessor-artifact-path-binding-defect-prelock-erratum-and-successor-decision-"
    "governance-v1-20261101"
)
V22_STATE = "FAIL_CLOSED_DURING_UNIT_VALIDATION_PRELOCK_TERMINAL_NO_RETRY_FROZEN_FAILURE_EVIDENCE"
DECISION = "TERMINALIZE_V22_AND_AUTHORIZE_DISTINCT_V23_CONDITIONALLY"
V22_TREE = (197, "7039dfbd361f7cbd58f1ac3bbde2e44719dcd65910f9c102c27136a2c7c848b4")
V22_PRELOCK_TREE = (78, "23070f1f705d36e65eb54bd92a40d5118ee71bf372d67b9f39b118c555dd165a")
V21_TREE = (188, "4c31ae13f74a84769b83b77e433c9488322e826ba04bef7ed5626e66ff708efe")

PATHS = {
    "terminal": "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "manifest": "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
    "freeze": "results/prelock/PRELOCK_FAILURE_EVIDENCE_FREEZE_VERIFICATION.json",
    "unit": "results/prelock/unit-fixtures-run-0001.json",
    "prompt": "fixture/worker-prompt.txt",
    "request": "contracts/WORKER_REQUEST.json",
    "prompt_binding": "contracts/PROMPT_IDENTITY_BINDING.json",
    "artifact_binding": "contracts/AUTHORITATIVE_ARTIFACT_DIGEST_BINDINGS.json",
    "cache_policy": "contracts/PYTHON_RUNTIME_SIDE_EFFECT_POLICY.json",
    "cache_companion": "contracts/SUCCESSOR_V21_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json",
    "invocation": "src/invocation_v22.py",
    "v20_local_decision": "contracts/V20_TERMINAL_AND_V21_SUCCESSOR_DECISION.json",
}
HASHES = {
    "terminal": "be71536c0daee46c323f8a04dde6e0e676d03261a9989720610516a55f9200b4",
    "manifest": "ef047ad5eabe66cb83e423f672d5eddb3d766edcf4137f383f3898c780a711e8",
    "freeze": "e3834f63e82ee692772742b915967e0ed582ab71944178203ee76ea9b345f356",
    "unit": "c49f5038448fa5c3c1d9c9b624201705f539a4c15cea68380c2d53995ae0c0c1",
    "prompt": "25b441cd99c15c070f72ea1ace959f50e27979d57df105708d8d1c80e2cbf305",
    "request": "7b1ee484e81fef2fdc6dee7520edb66d5b66953cfbdb7c363ccf03e63567cc5e",
    "prompt_binding": "572dca17e214c1c7280460ec4e061b3841448a63a48464e216851bce30046aed",
    "artifact_binding": "5b5c15f97be5cd976ffa00b8e65fccf22a200989e1a028fa8fa567adf250b0a5",
    "cache_policy": "8f26fd793aa7007d626be9df83f81e2db1c5b04307c37d27036e8e8ab807eed4",
    "cache_companion": "f914e9591e70e9e60eb00b334102199bc22e462555a03ba229616e87e2138c5e",
    "v20_local_decision": "0549da46f068df11695d544a8e66dd5fdb32272f5d5176528c419b11e07e8ea5",
}
V20_CANONICAL_DECISION = V20_GOV / "V20_TERMINAL_AND_V21_SUCCESSOR_DECISION.json"
V20_CANONICAL_DECISION_SHA = "8c78c347a293605db31122f42482ce2caca5bb52a5e750be341377087f3aeff3"
V21_CANONICAL_REGRESSION = V20_GOV / "V21_EXTERNAL_PREDECESSOR_ARTIFACT_REGRESSION_MATRIX.json"
V21_CANONICAL_REGRESSION_SHA = "6facfd3c98611569f2c1ae56137a5bee2b5370f9aff5f6ded964d680abf85f22"
V20_GOV_LOCK_SHA = "da417f8ae6243edc4a91be0b46fef9e1a81e6282d2c849dd0eb5a74885bff39d"

SOURCE_FILES = (
    "governance_common.py", "build_governance.py", "validate_governance.py",
    "negative_fixtures.py", "independent_validate.py", "freeze_governance.py",
    "verify_governance_freeze.py",
)
DOCUMENT_FILES = (
    "GOVERNANCE_CHARTER.json", "V22_FROZEN_FAILURE_EVIDENCE_BINDING.json",
    "V22_FIVE_GATE_FAILURE_ADJUDICATION.json", "V22_TERMINAL_AND_V23_SUCCESSOR_DECISION.json",
    "UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json",
    "V22_FAILURE_AND_V23_REGRESSION_MATRIX.json", "SUCCESSOR_V23_REQUIREMENTS.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "ROUTING_LEDGER.json", "NEXT_LEGAL_MILESTONE.json",
)
VALIDATION_FILES = (
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json",
    "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json",
)

def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())

def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def canonical_json_bytes(value) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()

def write_json_once(path: Path, value) -> None:
    if path.exists() or path.is_symlink():
        raise FileExistsError(f"append-only output exists: {path}")
    path.write_bytes(canonical_json_bytes(value))

def component_key(relative: str):
    return tuple(part.encode("utf-8") for part in PurePosixPath(relative).parts)

def normative_tree(root: Path):
    rows = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise AssertionError(f"unexpected symlink: {path}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            rows.append((component_key(relative), relative, sha256_file(path)))
    rows.sort(key=lambda row: row[0])
    stream = b"".join(name.encode() + b"\0" + digest.encode("ascii") + b"\n" for _, name, digest in rows)
    return len(rows), sha256_bytes(stream)

def is_read_only(path: Path) -> bool:
    return (path.stat().st_mode & 0o222) == 0

def set_read_only(path: Path) -> None:
    os.chmod(path, 0o444)

def assert_v22_frozen() -> None:
    if normative_tree(V22) != V22_TREE or normative_tree(V22 / "results/prelock") != V22_PRELOCK_TREE:
        raise AssertionError("V22 frozen tree drift")
    for key, relative in PATHS.items():
        if key in HASHES and sha256_file(V22 / relative) != HASHES[key]:
            raise AssertionError(f"V22 artifact drift: {relative}")
    terminal = load_json(V22 / PATHS["terminal"])
    if terminal.get("status") != V22_STATE or terminal.get("static_lock") != "NOT_ISSUED":
        raise AssertionError("V22 terminal state drift")
    if any(terminal.get(key) != 0 for key in ("attempt_count", "worker_invocation_count", "codex_as_worker_invocation_count")):
        raise AssertionError("V22 execution counters changed")
    if list(V22.rglob("ATTEMPT_MARKER.json")) or list(V22.rglob("runtime-result-0001.json")):
        raise AssertionError("V22 execution evidence unexpectedly exists")
    if not all(is_read_only(V22 / PATHS[key]) for key in ("terminal", "manifest", "freeze", "unit")):
        raise AssertionError("V22 failure evidence is not read-only")

def assert_v21_integrity() -> None:
    if normative_tree(V21) != V21_TREE:
        raise AssertionError("V21 predecessor drift")

def check_by_id(record, identity):
    return next(item for item in record["checks"] if item["id"] == identity)

def package_member_paths(exclude=()):
    excluded = set(exclude)
    return sorted((p for p in PACKAGE.iterdir() if p.is_file() and p.name not in excluded), key=lambda p: p.name.encode())

def package_root(paths):
    return sha256_bytes(b"".join(p.name.encode() + b"\0" + sha256_file(p).encode("ascii") + b"\n" for p in paths))
