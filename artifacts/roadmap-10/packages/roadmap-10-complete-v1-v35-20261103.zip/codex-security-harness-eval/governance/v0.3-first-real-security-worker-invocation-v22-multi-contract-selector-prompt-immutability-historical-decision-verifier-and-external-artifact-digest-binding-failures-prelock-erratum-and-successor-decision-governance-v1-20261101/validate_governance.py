#!/usr/bin/env python3
from governance_common import *

def main():
    assert_v22_frozen(); assert_v21_integrity()
    checks=[]
    def check(i,c,e=None): checks.append({"id":i,"status":"PASS" if c else "FAIL","evidence":e})
    check("G001_DOCUMENTS",all((PACKAGE/n).is_file() for n in DOCUMENT_FILES))
    unit=load_json(V22/PATHS["unit"]);terminal=load_json(V22/PATHS["terminal"])
    check("G002_STATE",terminal["status"]==V22_STATE and unit["validation_counts"]=={"failed":5,"passed":236,"total":241})
    check("G003_FAILURE_SET",unit["failure_ids"]==["U000O_CACHE_PREFLIGHT","U027_V7_PROMPT_IDENTITY","U049_PREDECESSOR","U091_EXTERNAL_v20_to_v22_successor_decision","U096_EXTERNAL_v22_external_predecessor_artifact_regression_matrix"])
    check("G004_NO_EXECUTION",terminal["static_lock"]=="NOT_ISSUED" and terminal["attempt_count"]==terminal["worker_invocation_count"]==terminal["codex_as_worker_invocation_count"]==0)
    for key in ("terminal","manifest","freeze","unit"): check(f"G_HASH_{key}",sha256_file(V22/PATHS[key])==HASHES[key])
    adjudication=load_json(PACKAGE/"V22_FIVE_GATE_FAILURE_ADJUDICATION.json")
    check("G005_CACHE_DEFECT",adjudication["PYTHON_CACHE_SUCCESSOR_CONTRACT_SELECTOR_DEFECT"]=="YES" and not (V22/"contracts/SUCCESSOR_V22_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json").exists())
    source=(V22/PATHS["invocation"]).read_text()
    check("G006_STALE_SELECTOR_SOURCE",'contracts/SUCCESSOR_V22_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json' in source and sha256_file(V22/PATHS["cache_companion"])==HASHES["cache_companion"])
    binding=load_json(V22/PATHS["prompt_binding"])
    prompt_equal=binding["first_prompt_sha256"]==binding["worker_request_bound_prompt_sha256"]==binding["reread_prompt_sha256"]==sha256_file(V22/PATHS["prompt"])
    check("G007_PROMPT_DIGESTS",prompt_equal and binding["worker_request_sha256"]==sha256_file(V22/PATHS["request"]))
    check("G008_PROMPT_MODE_DEFECT",adjudication["PROMPT_BINDING_IMMUTABILITY_MODE_DEFECT"]=="YES" and (V22/PATHS["prompt"]).stat().st_mode&0o777==0o644 and (V22/PATHS["request"]).stat().st_mode&0o777==0o444 and (V22/PATHS["prompt_binding"]).stat().st_mode&0o777==0o444)
    canonical=load_json(V20_CANONICAL_DECISION);local=load_json(V22/PATHS["v20_local_decision"])
    check("G009_HISTORICAL_DECISION_DEFECT",adjudication["V20_HISTORICAL_DECISION_VERIFIER_BINDING_DEFECT"]=="YES" and canonical["decision"]=="TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V21_CONDITIONALLY" and local["decision"]=="TERMINALIZE_V20_AND_AUTHORIZE_DISTINCT_V22_CONDITIONALLY")
    check("G010_CANONICAL_DECISION_AUTHORITY",sha256_file(V20_CANONICAL_DECISION)==V20_CANONICAL_DECISION_SHA and sha256_file(V20_GOV/"GOVERNANCE_LOCK.json")==V20_GOV_LOCK_SHA)
    external=adjudication["external_artifacts"]
    check("G011_EXTERNAL_DEFECT",adjudication["STALE_EXTERNAL_ARTIFACT_DIGEST_BINDING_DEFECT"]=="YES" and len(external)==2)
    check("G012_EXTERNAL_DECISION",external[0]["authoritative_sha256"]==sha256_file(V20_CANONICAL_DECISION)==external[0]["v22_bound_stale_digest"] and not Path(external[0]["v22_bound_nonexistent_locator"]).exists())
    check("G013_EXTERNAL_REGRESSION",external[1]["authoritative_sha256"]==sha256_file(V21_CANONICAL_REGRESSION)==external[1]["v22_bound_stale_digest"] and not Path(external[1]["v22_bound_nonexistent_locator"]).exists())
    check("G014_RUNTIME_NOT_INFERRED",adjudication["runtime_adjudication"]=={"V22_RUNTIME_DEFECT":"NOT_ESTABLISHED","V22_CODEX_DEFECT":"NOT_ESTABLISHED","TEMPORAL_RUNTIME":"NOT_ESTABLISHED","PROCESS_LINEAGE":"NOT_PROVEN","PRODUCER_AUTHORIZATION":"NOT_PROVEN","CONFINEMENT":"NOT_PROVEN"})
    decision=load_json(PACKAGE/"V22_TERMINAL_AND_V23_SUCCESSOR_DECISION.json")
    check("G015_DECISION",decision["decision"]==DECISION and decision["v22_continuation"]=="PROHIBITED" and decision["v22_mutation_allowlist"]==[] and decision["v23"]=="CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    contract=load_json(PACKAGE/"UNIFIED_GOVERNANCE_BOUND_AUTHORITATIVE_BINDING_GENERATION_CONTRACT.json")
    check("G016_UNIFIED_CONTRACT",len(contract["bound_domains"])==5 and "MIXED_GENERATIONS" in contract["prohibited"] and contract["mismatch"]=="FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT")
    check("G017_V22_TREE",normative_tree(V22)==V22_TREE)
    check("G018_V21_TREE",normative_tree(V21)==V21_TREE)
    failed=[x["id"] for x in checks if x["status"]!="PASS"]
    result={"record_type":"PRIMARY_GOVERNANCE_VALIDATION","governance_identity":GOVERNANCE_ID,"checks":checks,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failed),"failed":len(failed)},"failure_ids":failed,"status":"PASS" if not failed else "FAIL_CLOSED"}
    write_json_once(PACKAGE/VALIDATION_FILES[0],result);print(f"PRIMARY_GOVERNANCE_VALIDATION={result['status']} {len(checks)-len(failed)}/{len(checks)}")
    if failed: raise SystemExit(1)
if __name__=="__main__":main()
