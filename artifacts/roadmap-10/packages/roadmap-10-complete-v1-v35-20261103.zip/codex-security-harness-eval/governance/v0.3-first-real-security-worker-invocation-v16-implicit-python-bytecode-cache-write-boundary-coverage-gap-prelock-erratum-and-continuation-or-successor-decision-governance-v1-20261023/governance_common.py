"""Shared immutable-evidence helpers for the V16 bytecode-cache erratum."""
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V14 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v14-20261023")
V15 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v15-20261023")
V16 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v16-20261023")
V17 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v17-20261023")
PRELOCK = V16 / "results/prelock"
IDENTITY = (
    "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V16_IMPLICIT_PYTHON_BYTECODE_CACHE_"
    "WRITE_BOUNDARY_COVERAGE_GAP_PRELOCK_ERRATUM_AND_CONTINUATION_OR_SUCCESSOR_"
    "DECISION_GOVERNANCE_ONLY"
)

HASHES = {
    "unit": "da3eec46df7120c3f3a105aa2ad69b9ec7979b7c0bb94f772494e9395ec4e31f",
    "primary": "e693592d8306d4b639f08c49c9b18b175f9dc9630ed4205b4712904a67bbf218",
    "terminal": "b2b323a18168d7d7d69d5a18a08daaec228a4bac799fc28d5034d8eb69958de8",
    "failure_manifest": "b39a41077ea660427d8cf55faab94286b48cfe0adb9e73a9133a814f6e80268c",
    "implicit_pyc": "d28afe1bf85796431bdd7e8c7a0d05da01f99b74af217084372befbe178208b0",
    "runner": "10d8a0df12da225f4782cd6794ff1f594737f56cf899b8bfc5596bab3fc3293d",
    "workspace_guard": "1f428aa96236b01aa6b8ed31b76b1c91e5cefe6100248fd714208ddafbeab427",
    "v14_added_preflight": "b75552ef68c5d5de2238ea5787b3ee7e04ae2fc098fc9c8b7666141ed3597562",
    "v14_added_closure": "a437d4f2a8a8032ebdda5f6a6f3c83bc7a3e4f89494dc7cf1bf706ac852a972b",
    "v15_unit": "38e3b1c71dee5c0d0c91f4134e439f2f0442626faa23747ac306063b9cdaa6cc",
    "v15_primary": "a308968912f1e7722d2bf700c5aaf3256c176b1d4f584a4b269596a0fd8c17c9",
    "v15_independent": "69053c72214931839eab7743d90e11147cd03ab46cf6fd09fcda9633720d0381",
    "v15_terminal": "ece516b4641d1f1b2506e9025620e595f09dc1782373abcd23cecab177eaf601",
    "v15_manifest": "6011559bd1522fd9d71934383b8df587fc558fb379c8608627877c457c7db443",
}

V16_FILES = {
    "unit": PRELOCK / "unit-fixtures-run-0001.json",
    "primary": PRELOCK / "primary-static-validation-run-0001.json",
    "terminal": PRELOCK / "PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "failure_manifest": PRELOCK / "PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
    "implicit_pyc": V16 / "src/__pycache__/workspace_boundary_v16.cpython-314.pyc",
    "runner": V16 / "src/runner_v16.py",
    "workspace_guard": V16 / "src/workspace_boundary_v16.py",
}

PREDECESSOR_FILES = {
    "v14_added_preflight": V14 / "results/prelock/fresh-preflight-run-0001.json",
    "v14_added_closure": V14 / "results/prelock/dependency-closure-run-0001.json",
    "v15_unit": V15 / "results/prelock/unit-fixtures-run-0001.json",
    "v15_primary": V15 / "results/prelock/primary-static-validation-run-0001.json",
    "v15_independent": V15 / "results/prelock/independent-static-validation-run-0001.json",
    "v15_terminal": V15 / "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
    "v15_manifest": V15 / "results/prelock/PRELOCK_FAILURE_EVIDENCE_MANIFEST.json",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_json_bytes(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def write_json_once(path: Path, value: Any) -> None:
    with path.open("xb") as handle:
        handle.write(canonical_json_bytes(value))


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_only(path: Path) -> bool:
    return stat.S_IMODE(path.stat().st_mode) & 0o222 == 0


def snapshot_tree(root: Path) -> dict[str, Any]:
    members = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        members.append({
            "path": path.relative_to(root).as_posix(),
            "sha256": sha256(path),
            "size": path.stat().st_size,
            "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
        })
    tree = hashlib.sha256(
        "".join(f"{row['path']}\0{row['sha256']}\n" for row in members).encode()
    ).hexdigest()
    return {"member_count": len(members), "tree_root_sha256": tree, "members": members}


def exact_v16_hashes() -> bool:
    return all(V16_FILES[name].is_file() and sha256(V16_FILES[name]) == HASHES[name] for name in V16_FILES)


def exact_predecessor_hashes() -> bool:
    return all(path.is_file() and sha256(path) == HASHES[name] for name, path in PREDECESSOR_FILES.items())


def v16_zero_execution_state() -> bool:
    forbidden = [
        V16 / "STATIC_EXECUTION_LOCK.json",
        V16 / "STATIC_SOURCE_MANIFEST.json",
        V16 / "STATIC_EXECUTION_LOCK_VERIFICATION.json",
        V16 / "static-run-v16/ATTEMPT_MARKER.json",
        V16 / "static-run-v16/runtime-result-0001.json",
        PRELOCK / "independent-static-validation-run-0001.json",
        PRELOCK / "fresh-preflight-run-0001.json",
    ]
    static_run = V16 / "static-run-v16"
    return not any(path.exists() for path in forbidden) and not any(static_run.iterdir())


def failure_manifest_verdict() -> dict[str, Any]:
    manifest = load_json(V16_FILES["failure_manifest"])
    rows = manifest.get("members", [])
    failures = []
    for row in rows:
        path = V16 / row.get("path", "")
        if not path.is_file() or path.is_symlink() or sha256(path) != row.get("sha256") or path.stat().st_size != row.get("bytes"):
            failures.append(row.get("path"))
    paths = {row.get("path") for row in rows}
    required = {
        "results/prelock/unit-fixtures-run-0001.json",
        "results/prelock/primary-static-validation-run-0001.json",
        "results/prelock/PRELOCK_TERMINAL_ENGINEERING_RESULT.json",
        "src/__pycache__/workspace_boundary_v16.cpython-314.pyc",
    }
    status = (
        manifest.get("status") == "FROZEN_FAILURE_EVIDENCE"
        and manifest.get("member_count") == len(rows) == 78
        and required <= paths
        and not failures
    )
    return {"status": "PASS" if status else "FAIL", "member_count": len(rows), "failures": failures, "required_present": required <= paths}


def frozen_v16_state() -> dict[str, Any]:
    return {name: load_json(path) for name, path in V16_FILES.items() if name in {"unit", "primary", "terminal", "failure_manifest"}}


def explicit_guard_regressions_passed() -> bool:
    unit = load_json(V16_FILES["unit"])
    indexed = {row.get("id"): row.get("status") for row in unit.get("checks", [])}
    required = {
        "U000A_V16_EXACT_DESTINATION",
        "U000B_V14_WRITE_DENIED",
        "U000C_V15_WRITE_DENIED",
        "U000D_RELATIVE_TRAVERSAL_DENIED",
        "U000E_IDENTITY_MISMATCH_DENIED",
        "U000F_WORKSPACE_MISMATCH_DENIED",
        "U000G_PREDECESSOR_READ_ALLOWED",
        "U000H_PREDECESSOR_APPEND_DENIED",
        "U000I_SYMLINK_TO_PREDECESSOR_DENIED",
        "U000J_REJECTIONS_ZERO_PREDECESSOR_MUTATION",
    }
    return all(indexed.get(name) == "PASS" for name in required)


def source_environment_evidence() -> dict[str, Any]:
    runner = V16_FILES["runner"].read_text(encoding="utf-8")
    observer_selftest_region = runner[runner.index("def run_temporal_observer_selftest"):runner.index("def consume_locked_selftest_artifact")]
    return {
        "runner_sha256": sha256(V16_FILES["runner"]),
        "guard_sha256": sha256(V16_FILES["workspace_guard"]),
        "observer_selftest_env_empty": "env={}" in observer_selftest_region,
        "observer_imports_workspace_guard": "from workspace_boundary_v16 import" in (V16 / "src/topology_observer_v16.py").read_text(encoding="utf-8"),
        "implicit_pyc_present": V16_FILES["implicit_pyc"].is_file(),
    }


class CachePolicyError(RuntimeError):
    """Fail-before-execution cache-policy rejection."""


def authorize_python_cache_policy(
    *,
    identity: str | None,
    expected_identity: str,
    workspace: Path | None,
    expected_workspace: Path,
    mode: str,
    cache_root: Path | None,
    deny_roots: list[Path],
) -> dict[str, str]:
    if identity != expected_identity or workspace is None:
        raise CachePolicyError("IDENTITY_OR_WORKSPACE_UNRESOLVED")
    actual_workspace = workspace.resolve(strict=True)
    exact_workspace = expected_workspace.resolve(strict=True)
    if actual_workspace != exact_workspace:
        raise CachePolicyError("WORKSPACE_MISMATCH")
    if mode == "DISABLED":
        if cache_root is not None:
            raise CachePolicyError("DISABLED_MODE_MUST_NOT_ROUTE_CACHE")
        return {"status": "PASS", "mode": mode}
    if mode != "ROUTED_CURRENT_WORKSPACE" or cache_root is None:
        raise CachePolicyError("CACHE_POLICY_MODE_UNSUPPORTED")
    if ".." in cache_root.parts:
        raise CachePolicyError("CACHE_PATH_TRAVERSAL")
    resolved = cache_root.resolve(strict=False)
    try:
        resolved.relative_to(exact_workspace)
    except ValueError as exc:
        raise CachePolicyError("CACHE_OUTSIDE_CURRENT_WORKSPACE") from exc
    for root in deny_roots:
        denied = root.resolve(strict=True)
        try:
            resolved.relative_to(denied)
        except ValueError:
            continue
        raise CachePolicyError("CACHE_INSIDE_PREDECESSOR")
    return {"status": "PASS", "mode": mode, "cache_root": str(resolved)}
