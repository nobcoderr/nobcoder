"""Final read-only verification of the V16 governance freeze."""
from __future__ import annotations

from governance_common import *


def main() -> int:
    checks: list[dict[str, Any]] = []

    def check(identifier: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    manifest = load_json(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    lock = load_json(ROOT / "GOVERNANCE_LOCK.json")
    rows = manifest.get("members", [])
    canonical_root = hashlib.sha256("".join(f"{row['path']}\0{row['sha256']}\n" for row in rows).encode()).hexdigest()
    check("F001_LOCK_PASS", lock.get("status") == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("F002_MANIFEST_DIGEST", sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock.get("manifest_sha256"))
    check("F003_CANONICAL_ROOT", canonical_root == manifest.get("canonical_root_sha256") == lock.get("canonical_root_sha256"))
    check("F004_MEMBER_COUNT", len(rows) == manifest.get("member_count"))
    drifted=[]; writable=[]
    for row in rows:
        path=ROOT/row["path"]
        if not path.is_file() or sha256(path)!=row["sha256"] or path.stat().st_size!=row["size"]: drifted.append(row["path"])
        elif not read_only(path): writable.append(row["path"])
    check("F005_MEMBERS_EXACT", not drifted, drifted)
    check("F006_MEMBERS_READ_ONLY", not writable, writable)
    check("F007_LOCK_FILES_READ_ONLY", read_only(ROOT/"GOVERNANCE_ARTIFACT_MANIFEST.json") and read_only(ROOT/"GOVERNANCE_LOCK.json"))
    check("F008_V16_HASHES_EXACT", exact_v16_hashes())
    check("F009_PREDECESSOR_HASHES_EXACT", exact_predecessor_hashes())
    check("F010_V16_MANIFEST_EXACT", failure_manifest_verdict().get("status")=="PASS")
    binding=load_json(ROOT/"V16_FROZEN_PRELOCK_EVIDENCE_BINDING.json");current=snapshot_tree(V16)
    check("F011_V16_TREE_UNCHANGED", current["member_count"]==binding["workspace_member_count"] and current["tree_root_sha256"]==binding["workspace_tree_root_sha256"])
    check("F012_ZERO_EXECUTION", v16_zero_execution_state())
    check("F013_DECISION", lock.get("decision")=="TERMINALIZE_V16_AND_AUTHORIZE_DISTINCT_V17_CONDITIONALLY")
    check("F014_COUNTS_ZERO", lock.get("attempt")==lock.get("worker_invocation")==lock.get("codex_as_worker_invocation")=="0_OF_1")
    check("F015_V17_ABSENT", not V17.exists())
    failures=[row["id"] for row in checks if row["status"]=="FAIL"]
    result={"record_type":"V16_BYTECODE_CACHE_FINAL_FREEZE_VERIFICATION","status":"PASS" if not failures else "FAIL_CLOSED","checks":checks,"failure_ids":failures,"validation_counts":{"total":len(checks),"passed":len(checks)-len(failures),"failed":len(failures)},"worker_or_codex_invocation_count":0}
    write_json_once(ROOT/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",result)
    os.chmod(ROOT/"FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json",0o444)
    if not failures: os.chmod(ROOT,0o555)
    print(json.dumps(result["validation_counts"],sort_keys=True))
    return 0 if not failures else 1


if __name__=="__main__":
    raise SystemExit(main())
