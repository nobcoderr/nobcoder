"""Build the governance-only V16 implicit-bytecode-write adjudication."""
from __future__ import annotations

from governance_common import *


def emit(name: str, value: dict[str, Any]) -> None:
    write_json_once(ROOT / name, value)


def main() -> int:
    if not exact_v16_hashes() or not exact_predecessor_hashes() or not v16_zero_execution_state() or V17.exists():
        raise RuntimeError("frozen V14/V15/V16 evidence, zero-execution state, or V17 boundary drift")
    manifest_verdict = failure_manifest_verdict()
    if manifest_verdict["status"] != "PASS":
        raise RuntimeError("V16 failure evidence manifest is not exact")
    state = frozen_v16_state()
    source = source_environment_evidence()
    tree = snapshot_tree(V16)

    emit("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V16_BYTECODE_CACHE_GOVERNANCE_ROUTING",
        "governance_identity": IDENTITY,
        "status": "PASS",
        "task_class": "LOCAL_FROZEN_EVIDENCE_GOVERNANCE_ONLY",
        "active_skills": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness"],
        "subagents": "NOT_USED",
        "v16_mutation_or_execution": "PROHIBITED",
        "target_network_credential_worker_codex_activity": "PROHIBITED",
    })
    emit("ROUTING_LEDGER.json", {
        "record_type": "V16_BYTECODE_CACHE_GOVERNANCE_ROUTING_LEDGER",
        "status": "PASS",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness"],
        "deferred": [],
        "not_applicable": ["live-target-testing", "credentials", "network", "subagents", "parallelism", "exploit-replay", "capability-graph", "promotion", "submission", "external-tool-execution"],
    })
    emit("V16_FROZEN_PRELOCK_EVIDENCE_BINDING.json", {
        "record_type": "V16_FROZEN_PRELOCK_EVIDENCE_BINDING",
        "status": "PASS",
        "workspace_member_count": tree["member_count"],
        "workspace_tree_root_sha256": tree["tree_root_sha256"],
        "unit": {"sha256": HASHES["unit"], "status": state["unit"]["status"], "counts": state["unit"]["validation_counts"]},
        "primary": {"sha256": HASHES["primary"], "status": state["primary"]["status"], "counts": state["primary"]["validation_counts"], "failure_ids": state["primary"]["failure_ids"]},
        "independent_validation": "NOT_STARTED",
        "fresh_preflight": "NOT_STARTED",
        "terminal_result_sha256": HASHES["terminal"],
        "failure_manifest_sha256": HASHES["failure_manifest"],
        "failure_manifest_member_count": manifest_verdict["member_count"],
        "implicit_pyc_path": "src/__pycache__/workspace_boundary_v16.cpython-314.pyc",
        "implicit_pyc_sha256": HASHES["implicit_pyc"],
        "runner_sha256": HASHES["runner"],
        "workspace_guard_sha256": HASHES["workspace_guard"],
        "v14_v15_predecessor_hash_mismatch_count": 0,
        "static_lock": "NOT_ISSUED",
        "attempt": "0_OF_1",
        "worker_invocation": "0_OF_1",
        "codex_as_worker_invocation": "0_OF_1",
    })
    emit("DEFECT_OWNERSHIP_ADJUDICATION.json", {
        "record_type": "V16_IMPLICIT_PYTHON_BYTECODE_CACHE_DEFECT_OWNERSHIP",
        "status": "PASS",
        "deterministic_blocker": "CPYTHON_BYTECODE_CACHE_CREATED_DURING_OBSERVER_SELFTEST_OUTSIDE_EXPLICIT_WORKSPACE_WRITE_GUARD",
        "IMPLICIT_PYTHON_BYTECODE_CACHE_WRITE_BOUNDARY_COVERAGE_GAP": "YES",
        "WORKSPACE_WRITE_BOUNDARY_COVERAGE_GAP": "YES",
        "PYTHON_EXECUTION_ENVIRONMENT_DEFECT": "YES_EMPTY_CHILD_ENV_DID_NOT_DISABLE_OR_ROUTE_BYTECODE_CACHE",
        "OBSERVER_SELFTEST_HARNESS_DEFECT": "YES_LAUNCH_ENVIRONMENT_DID_NOT_ACCOUNT_FOR_INTERPRETER_SIDE_EFFECT",
        "WORKSPACE_GUARD_CORE_LOGIC_DEFECT": "NO_EXPLICIT_GUARDED_MUTATION_REGRESSIONS_ALL_PASS",
        "TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT": "NOT_ESTABLISHED_NO_RUNTIME_ATTEMPT",
        "SECURITY_WORKER_OR_CODEX_DEFECT": "NOT_ESTABLISHED_NOT_EXECUTED",
        "CONFINEMENT": "NOT_PROVEN_NOT_EXECUTED",
        "explicit_guard_regressions_passed": explicit_guard_regressions_passed(),
        "source_environment_evidence": source,
        "distinction": {
            "explicit_application_write": "MUST_TRAVERSE_WORKSPACE_WRITE_GUARD",
            "implicit_interpreter_runtime_write": "MUST_BE_SUPPRESSED_OR_EXPLICITLY_CONTRACTED_AND_IDENTITY_BOUND",
        },
        "causal_limit": "The frozen evidence proves an unaccounted interpreter side effect and the self-test launch environment that permitted it; it does not prove a temporal observer runtime defect.",
    })
    emit("V16_PRELOCK_TERMINAL_DISPOSITION.json", {
        "record_type": "V16_PRELOCK_TERMINAL_DISPOSITION",
        "status": "FAIL_CLOSED_PRELOCK_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "immutable": True,
        "continuation": "PROHIBITED",
        "static_lock": "NOT_ISSUED",
        "attempt": "0_OF_1",
        "worker_invocation": "0_OF_1",
        "codex_as_worker_invocation": "0_OF_1",
        "no_patch": True,
        "no_rerun": True,
        "no_delete_or_cleanup": True,
        "no_lock": True,
        "no_execution": True,
    })
    emit("RUNTIME_FILESYSTEM_MUTATION_ACCOUNTING_CONTRACT.json", {
        "record_type": "V17_RUNTIME_FILESYSTEM_MUTATION_ACCOUNTING_CONTRACT",
        "status": "NORMATIVE_IF_V17_IMPLEMENTED",
        "applies_to": ["VALIDATION", "PREFLIGHT", "OBSERVER_SELFTEST", "RUNTIME", "POST_VALIDATION", "EVIDENCE_FREEZE"],
        "normative_rule": "EVERY_FILESYSTEM_MUTATION_MUST_BE_EXPLICITLY_AUTHORIZED_OR_EXPLICITLY_CONTRACTED_AS_AN_IDENTITY_BOUND_RUNTIME_SIDE_EFFECT",
        "mutation_classes": {
            "EXPLICIT_APPLICATION_WRITE": "MUST_TRAVERSE_EXACT_WORKSPACE_WRITE_GUARD",
            "IMPLICIT_RUNTIME_OR_INTERPRETER_WRITE": "MUST_BE_SUPPRESSED_OR_BOUND_TO_EXACT_AUTHORIZED_CURRENT_WORKSPACE_LOCATION_AND_IDENTITY",
        },
        "unaccounted_filesystem_mutation_count_required": 0,
        "pre_phase_snapshot": "REQUIRED",
        "post_phase_snapshot": "REQUIRED",
        "snapshot_delta_policy": "ONLY_EXACT_CONTRACTED_WRITE_SET_MAY_DIFFER",
        "rejection_policy": "BYTE_LEVEL_PRE_POST_FILESYSTEM_EQUALITY_REQUIRED",
        "prohibited": ["DELETE_AFTER_WRITE", "IGNORE_UNEXPECTED_CACHE", "ARBITRARY_CACHE_WRITE", "PREDECESSOR_CACHE_WRITE", "WEAKEN_FAIL_BEFORE_WRITE"],
    })
    emit("SUCCESSOR_V17_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json", {
        "record_type": "V17_PYTHON_CACHE_AND_WORKSPACE_WRITE_BOUNDARY_CONTRACT",
        "status": "NORMATIVE_IF_V17_IMPLEMENTED",
        "allowed_designs": {
            "DETERMINISTIC_SUPPRESSION": ["EXACT_CHILD_ENV_PYTHONDONTWRITEBYTECODE_EQUALS_1", "PYTHON_MINUS_B_OR_EQUIVALENT_PINNED_INTERPRETER_CONTROL", "NO_PYC_CREATED"],
            "EXACT_AUTHORIZED_ROUTING": ["PYTHONPYCACHEPREFIX_EXACT_CURRENT_V17_SCRATCH_ROOT", "GUARD_ATTESTATION_BEFORE_CHILD_START", "CACHE_IDENTITY_AND_PATH_STATICALLY_BOUND", "CACHE_MEMBERS_ACCOUNTED_IN_SNAPSHOT_AND_EVIDENCE"],
        },
        "selection": "ONE_EXPLICIT_DESIGN_MUST_BE_FROZEN_BEFORE_VALIDATION",
        "subprocess_environment": "EXACT_CONSTRUCTED_ENVIRONMENT_REQUIRED_FOR_EVERY_PYTHON_CHILD",
        "ambient_or_empty_environment_as_POLICY": "PROHIBITED_UNLESS_PROVEN_TO_SUPPRESS_ALL_UNACCOUNTED_MUTATIONS",
        "predecessor_cache_roots": "DENY_WRITE",
        "symlink_and_traversal_resolution": "CANONICAL_REALPATH_FAIL_CLOSED",
        "unaccounted_mutations": 0,
        "cleanup_as_acceptance": "PROHIBITED",
    })
    cases = [
        ("R01", "implicit Python bytecode creation without suppression/routing", "DETECTED_AND_FAIL_CLOSED"),
        ("R02", "bytecode-disabled Python module execution", "PASS_NO_PYC_CREATED"),
        ("R03", "exact authorized current-V17 cache routing", "PASS_IF_EXPLICITLY_SELECTED_AND_BOUND"),
        ("R04", "cache path traversal into predecessor", "FAIL_BEFORE_EXECUTION_ZERO_MUTATION"),
        ("R05", "cache symlink resolves into predecessor", "FAIL_BEFORE_EXECUTION_ZERO_MUTATION"),
        ("R06", "direct predecessor pycache mutation", "FAIL_BEFORE_EXECUTION_ZERO_MUTATION"),
        ("R07", "rejected cache write pre/post snapshot", "BYTE_IDENTICAL"),
        ("R08", "unexpected pycache after validation phase", "FAIL_CLOSED_UNACCOUNTED_MUTATION"),
    ]
    emit("V16_FAILURE_AND_V17_REGRESSION_MATRIX.json", {
        "record_type": "V16_FAILURE_AND_V17_PYTHON_CACHE_REGRESSION_MATRIX",
        "status": "PASS",
        "cases": [{"id": i, "case": case, "expected": expected} for i, case, expected in cases],
        "coverage_invariant": "UNACCOUNTED_FILESYSTEM_MUTATION_COUNT_EQUALS_ZERO",
        "historical_v16_pyc": {"path": "src/__pycache__/workspace_boundary_v16.cpython-314.pyc", "sha256": HASHES["implicit_pyc"], "disposition": "IMMUTABLE_FAILURE_EVIDENCE"},
    })
    emit("SUCCESSOR_DECISION.json", {
        "record_type": "V16_SUCCESSOR_DECISION",
        "status": "PASS",
        "decision": "TERMINALIZE_V16_AND_AUTHORIZE_DISTINCT_V17_CONDITIONALLY",
        "v17_status": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "reason": "V16 already contains frozen failure evidence and an unaccounted interpreter artifact; a fresh identity avoids deletion, cleanup, mixed validation history, and weakened append-only provenance.",
    })
    emit("SUCCESSOR_V17_REQUIREMENTS.json", {
        "record_type": "SUCCESSOR_V17_REQUIREMENTS",
        "status": "NORMATIVE_IF_V17_IMPLEMENTED",
        "fresh_workspace_required": True,
        "v16_history": "IMMUTABLE_REFERENCE_ONLY",
        "requirements": [
            "EXACT_V17_WORKSPACE_AND_INVOCATION_IDENTITY_BINDING",
            "FAIL_BEFORE_WRITE_GUARD_FOR_EXPLICIT_MUTATIONS",
            "EXPLICIT_POLICY_FOR_EVERY_IMPLICIT_RUNTIME_MUTATION",
            "DETERMINISTIC_PYTHON_BYTECODE_SUPPRESSION_OR_EXACT_GUARDED_ROUTING",
            "EXACT_CHILD_PROCESS_ENVIRONMENT_BINDING",
            "PRE_AND_POST_FILESYSTEM_SNAPSHOT_ACCOUNTING_PER_PHASE",
            "UNACCOUNTED_FILESYSTEM_MUTATION_COUNT_ZERO",
            "PREDECESSOR_READ_ALLOWED_WRITE_DENIED",
            "FULL_V1_TO_V16_REGRESSIONS",
            "FRESH_UNIT_PRIMARY_INDEPENDENT_PREFLIGHT_CLOSURE_LOCK_AND_POST_LOCK_CHAIN",
        ],
        "forbidden": ["V16_MUTATION", "PYC_DELETION_AFTER_WRITE", "IGNORE_RULE_FOR_UNEXPECTED_CACHE", "PREDECESSOR_CACHE_WRITE", "TARGET", "CREDENTIAL", "TARGET_NETWORK", "SUBAGENT", "PARALLELISM", "PROMOTION", "SUBMISSION"],
    })
    emit("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "V16_BYTECODE_CACHE_ERRATUM_OPERATION_AUTHORIZATION_MATRIX",
        "status": "PASS",
        "governance_artifact_creation": "AUTHORIZED",
        "read_v14_v15_v16_frozen_evidence": "AUTHORIZED",
        "v16_patch_rerun_delete_cleanup_lock_or_execution": "PROHIBITED",
        "worker_or_codex_invocation": "PROHIBITED",
        "v17_creation_or_execution_during_governance": "PROHIBITED",
        "target_credential_network_subagent_parallelism_capability_promotion_submission": "PROHIBITED",
    })
    emit("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "V16_IMPLICIT_BYTECODE_CACHE_ERRATUM_DECISION_SUMMARY",
        "governance_identity": IDENTITY,
        "status": "PASS_PENDING_FREEZE",
        "IMPLICIT_PYTHON_BYTECODE_CACHE_WRITE_BOUNDARY_COVERAGE_GAP": "YES",
        "WORKSPACE_WRITE_BOUNDARY_COVERAGE_GAP": "YES",
        "PYTHON_EXECUTION_ENVIRONMENT_DEFECT": "YES",
        "OBSERVER_SELFTEST_HARNESS_DEFECT": "YES",
        "WORKSPACE_GUARD_CORE_LOGIC_DEFECT": "NO",
        "v16_disposition": "FAIL_CLOSED_PRELOCK_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "decision": "TERMINALIZE_V16_AND_AUTHORIZE_DISTINCT_V17_CONDITIONALLY",
        "worker_or_codex_invocation_count": 0,
    })
    emit("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V16_ERRATUM_NEXT_LEGAL_MILESTONE",
        "status": "PASS",
        "milestone": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V17_ONCE_IF_ALL_GATES_PASS",
        "precondition": "THIS_GOVERNANCE_PACKAGE_PASS_LOCKED_GOVERNANCE_ONLY",
        "v17_created_or_executed_here": False,
    })
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
