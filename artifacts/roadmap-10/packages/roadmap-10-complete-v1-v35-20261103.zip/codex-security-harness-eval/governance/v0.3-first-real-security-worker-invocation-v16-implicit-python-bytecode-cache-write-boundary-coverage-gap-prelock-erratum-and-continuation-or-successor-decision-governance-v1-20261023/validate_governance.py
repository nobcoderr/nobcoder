"""Primary governance validation for the V16 implicit bytecode-cache erratum."""
from __future__ import annotations

from governance_common import *


def main() -> int:
    checks: list[dict[str, Any]] = []

    def check(identifier: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    state = frozen_v16_state()
    binding = load_json(ROOT / "V16_FROZEN_PRELOCK_EVIDENCE_BINDING.json")
    ownership = load_json(ROOT / "DEFECT_OWNERSHIP_ADJUDICATION.json")
    disposition = load_json(ROOT / "V16_PRELOCK_TERMINAL_DISPOSITION.json")
    mutation = load_json(ROOT / "RUNTIME_FILESYSTEM_MUTATION_ACCOUNTING_CONTRACT.json")
    cache = load_json(ROOT / "SUCCESSOR_V17_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json")
    matrix = load_json(ROOT / "V16_FAILURE_AND_V17_REGRESSION_MATRIX.json")
    decision = load_json(ROOT / "SUCCESSOR_DECISION.json")
    operations = load_json(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    source = source_environment_evidence()

    check("G001_V16_HASHES_EXACT", exact_v16_hashes())
    check("G002_PREDECESSOR_HASHES_EXACT", exact_predecessor_hashes())
    check("G003_FAILURE_MANIFEST_78_EXACT", failure_manifest_verdict().get("status") == "PASS", failure_manifest_verdict())
    check("G004_UNIT_135_OF_135", state["unit"].get("status") == "PASS" and state["unit"].get("validation_counts") == {"total": 135, "passed": 135, "failed": 0})
    check("G005_PRIMARY_53_OF_54", state["primary"].get("status") == "FAIL_CLOSED" and state["primary"].get("validation_counts") == {"total": 54, "passed": 53, "failed": 1})
    check("G006_FAILED_GATE_EXACT", state["primary"].get("failure_ids") == ["S064_CORE_PREFLIGHT"])
    check("G007_INDEPENDENT_AND_PREFLIGHT_NOT_STARTED", not (PRELOCK / "independent-static-validation-run-0001.json").exists() and not (PRELOCK / "fresh-preflight-run-0001.json").exists())
    check("G008_ZERO_EXECUTION_AND_NO_LOCK", v16_zero_execution_state())
    check("G009_TERMINAL_EVIDENCE_EXACT", state["terminal"].get("status") == "FAIL_CLOSED_DURING_PRIMARY_STATIC_VALIDATION_UNEXPECTED_PYTHON_CACHE_ARTIFACT_BEFORE_FRESH_PREFLIGHT_STATIC_LOCK_AND_ATTEMPT")
    check("G010_IMPLICIT_PYC_EXACT", sha256(V16_FILES["implicit_pyc"]) == HASHES["implicit_pyc"])
    check("G011_SOURCE_CAUSAL_EVIDENCE", all(source.values()), source)
    check("G012_EXPLICIT_GUARD_REGRESSIONS_PASS", explicit_guard_regressions_passed())
    check("G013_GAP_YES", ownership.get("IMPLICIT_PYTHON_BYTECODE_CACHE_WRITE_BOUNDARY_COVERAGE_GAP") == "YES")
    check("G014_BOUNDARY_COVERAGE_YES", ownership.get("WORKSPACE_WRITE_BOUNDARY_COVERAGE_GAP") == "YES")
    check("G015_PYTHON_ENV_DEFECT", str(ownership.get("PYTHON_EXECUTION_ENVIRONMENT_DEFECT", "")).startswith("YES_"))
    check("G016_SELFTEST_HARNESS_DEFECT", str(ownership.get("OBSERVER_SELFTEST_HARNESS_DEFECT", "")).startswith("YES_"))
    check("G017_GUARD_CORE_NOT_DEFECTIVE", ownership.get("WORKSPACE_GUARD_CORE_LOGIC_DEFECT") == "NO_EXPLICIT_GUARDED_MUTATION_REGRESSIONS_ALL_PASS")
    check("G018_RUNTIME_NOT_CLASSIFIED", ownership.get("TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT") == "NOT_ESTABLISHED_NO_RUNTIME_ATTEMPT" and ownership.get("CONFINEMENT") == "NOT_PROVEN_NOT_EXECUTED")
    check("G019_MUTATION_ACCOUNTING_COMPLETE", mutation.get("unaccounted_filesystem_mutation_count_required") == 0 and mutation.get("rejection_policy") == "BYTE_LEVEL_PRE_POST_FILESYSTEM_EQUALITY_REQUIRED")
    check("G020_EXPLICIT_IMPLICIT_SEPARATION", set(mutation.get("mutation_classes", {})) == {"EXPLICIT_APPLICATION_WRITE", "IMPLICIT_RUNTIME_OR_INTERPRETER_WRITE"})
    check("G021_CACHE_DESIGNS_BOUNDED", set(cache.get("allowed_designs", {})) == {"DETERMINISTIC_SUPPRESSION", "EXACT_AUTHORIZED_ROUTING"} and cache.get("unaccounted_mutations") == 0)
    check("G022_CLEANUP_IGNORE_PROHIBITED", {"DELETE_AFTER_WRITE", "IGNORE_UNEXPECTED_CACHE", "ARBITRARY_CACHE_WRITE"} <= set(mutation.get("prohibited", [])))
    check("G023_REGRESSION_MATRIX", len(matrix.get("cases", [])) == 8 and {row["id"] for row in matrix.get("cases", [])} == {f"R{i:02d}" for i in range(1, 9)})
    check("G024_V16_TERMINAL_IMMUTABLE", disposition.get("immutable") is True and disposition.get("continuation") == "PROHIBITED" and disposition.get("static_lock") == "NOT_ISSUED")
    check("G025_COUNTS_ZERO", disposition.get("attempt") == disposition.get("worker_invocation") == disposition.get("codex_as_worker_invocation") == "0_OF_1")
    check("G026_SUCCESSOR_DECISION", decision.get("decision") == "TERMINALIZE_V16_AND_AUTHORIZE_DISTINCT_V17_CONDITIONALLY" and decision.get("v17_status") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("G027_OPERATION_CEILING", operations.get("v16_patch_rerun_delete_cleanup_lock_or_execution") == "PROHIBITED" and operations.get("worker_or_codex_invocation") == "PROHIBITED")
    check("G028_V17_NOT_CREATED", not V17.exists())
    check("G029_FROZEN_BINDING", binding.get("failure_manifest_sha256") == HASHES["failure_manifest"] and binding.get("failure_manifest_member_count") == 78 and binding.get("v14_v15_predecessor_hash_mismatch_count") == 0)

    failures = [row["id"] for row in checks if row["status"] == "FAIL"]
    result = {
        "record_type": "V16_BYTECODE_CACHE_PRIMARY_GOVERNANCE_VALIDATION",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
        "worker_or_codex_invocation_count": 0,
    }
    write_json_once(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", result)
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
