"""Freeze the validated V16 governance package without touching V16."""
from __future__ import annotations

from governance_common import *

EXCLUDED = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"}


def main() -> int:
    for name in ("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0002.json"):
        if load_json(ROOT / name).get("status") != "PASS":
            raise RuntimeError(f"cannot freeze: {name} is not PASS")
    if not exact_v16_hashes() or not exact_predecessor_hashes() or not v16_zero_execution_state() or V17.exists():
        raise RuntimeError("cannot freeze: external evidence or authority boundary drift")
    binding = load_json(ROOT / "V16_FROZEN_PRELOCK_EVIDENCE_BINDING.json")
    current = snapshot_tree(V16)
    if current["member_count"] != binding["workspace_member_count"] or current["tree_root_sha256"] != binding["workspace_tree_root_sha256"]:
        raise RuntimeError("cannot freeze: V16 workspace drift")
    members = []
    for path in sorted(item for item in ROOT.iterdir() if item.is_file() and item.name not in EXCLUDED):
        members.append({"path": path.name, "sha256": sha256(path), "size": path.stat().st_size})
    canonical_root = hashlib.sha256("".join(f"{row['path']}\0{row['sha256']}\n" for row in members).encode()).hexdigest()
    manifest = {"record_type": "V16_BYTECODE_CACHE_GOVERNANCE_ARTIFACT_MANIFEST", "status": "PASS", "member_count": len(members), "canonical_root_sha256": canonical_root, "members": members}
    write_json_once(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", manifest)
    lock = {
        "record_type": "V16_BYTECODE_CACHE_GOVERNANCE_LOCK",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "manifest_sha256": sha256(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "canonical_root_sha256": canonical_root,
        "IMPLICIT_PYTHON_BYTECODE_CACHE_WRITE_BOUNDARY_COVERAGE_GAP": "YES",
        "WORKSPACE_WRITE_BOUNDARY_COVERAGE_GAP": "YES",
        "PYTHON_EXECUTION_ENVIRONMENT_DEFECT": "YES",
        "OBSERVER_SELFTEST_HARNESS_DEFECT": "YES",
        "WORKSPACE_GUARD_CORE_LOGIC_DEFECT": "NO",
        "v16_disposition": "FAIL_CLOSED_PRELOCK_TERMINAL_NO_RETRY_REFERENCE_ONLY",
        "decision": "TERMINALIZE_V16_AND_AUTHORIZE_DISTINCT_V17_CONDITIONALLY",
        "v17_status": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v16_failure_manifest_sha256": HASHES["failure_manifest"],
        "v16_failure_evidence_member_count": 78,
        "v16_workspace_tree_root_sha256": binding["workspace_tree_root_sha256"],
        "static_lock": "NOT_ISSUED",
        "attempt": "0_OF_1",
        "worker_invocation": "0_OF_1",
        "codex_as_worker_invocation": "0_OF_1",
        "worker_or_codex_invocation_during_governance": 0,
    }
    write_json_once(ROOT / "GOVERNANCE_LOCK.json", lock)
    for path in [*(ROOT / row["path"] for row in members), ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json", ROOT / "GOVERNANCE_LOCK.json"]:
        os.chmod(path, 0o444)
    print(json.dumps({"status": lock["status"], "members": len(members), "root": canonical_root}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
