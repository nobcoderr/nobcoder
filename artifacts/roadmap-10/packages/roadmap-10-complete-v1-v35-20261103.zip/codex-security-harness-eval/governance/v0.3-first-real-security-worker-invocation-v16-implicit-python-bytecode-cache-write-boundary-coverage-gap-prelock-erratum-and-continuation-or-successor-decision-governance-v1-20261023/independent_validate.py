"""Independent V16 governance validation with direct AST and byte checks."""
from __future__ import annotations

import ast
import subprocess
import tempfile

from governance_common import *


def empty_env_observer_launch_count() -> int:
    tree = ast.parse(V16_FILES["runner"].read_text(encoding="utf-8"))
    target = next(node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "run_temporal_observer_selftest")
    count = 0
    for node in ast.walk(target):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute) or node.func.attr != "Popen":
            continue
        for keyword in node.keywords:
            if keyword.arg == "env" and isinstance(keyword.value, ast.Dict) and not keyword.value.keys:
                count += 1
    return count


def main() -> int:
    checks: list[dict[str, Any]] = []

    def check(identifier: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    historical = load_json(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    primary = load_json(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load_json(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    ownership = load_json(ROOT / "DEFECT_OWNERSHIP_ADJUDICATION.json")
    disposition = load_json(ROOT / "V16_PRELOCK_TERMINAL_DISPOSITION.json")
    decision = load_json(ROOT / "SUCCESSOR_DECISION.json")
    mutation = load_json(ROOT / "RUNTIME_FILESYSTEM_MUTATION_ACCOUNTING_CONTRACT.json")
    cache = load_json(ROOT / "SUCCESSOR_V17_PYTHON_CACHE_AND_WRITE_BOUNDARY_CONTRACT.json")
    binding = load_json(ROOT / "V16_FROZEN_PRELOCK_EVIDENCE_BINDING.json")

    check("I000_HISTORICAL_RUN_0001_PRESERVED", sha256(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0001.json") == "570ee30cdfc914449195222190a87b052eed91f785cca449e836dc8af9d06c4d" and historical.get("failure_ids") == ["I007_EMPTY_ENV_OBSERVER_LAUNCH_AST"])
    check("I001_PRIMARY_PASS", primary.get("status") == "PASS")
    check("I002_NEGATIVE_PASS", negative.get("status") == "PASS")
    check("I003_V16_HASHES_DIRECT", all(sha256(path) == HASHES[name] for name, path in V16_FILES.items()))
    check("I004_PREDECESSOR_HASHES_DIRECT", all(sha256(path) == HASHES[name] for name, path in PREDECESSOR_FILES.items()))
    manifest = load_json(V16_FILES["failure_manifest"])
    rows = manifest.get("members", [])
    mismatches = []
    for row in rows:
        path = V16 / row.get("path", "")
        if not path.is_file() or path.is_symlink() or sha256(path) != row.get("sha256") or path.stat().st_size != row.get("bytes"):
            mismatches.append(row.get("path"))
    check("I005_MANIFEST_78_INDEPENDENT", len(rows) == manifest.get("member_count") == 78 and not mismatches, mismatches)
    check("I006_PYC_IN_MANIFEST_AND_EXACT", any(row.get("path") == "src/__pycache__/workspace_boundary_v16.cpython-314.pyc" and row.get("sha256") == HASHES["implicit_pyc"] for row in rows))
    check("I007_EMPTY_ENV_OBSERVER_LAUNCH_AST", empty_env_observer_launch_count() == 2, empty_env_observer_launch_count())
    primary_result = load_json(V16_FILES["primary"])
    failed = {row.get("id"): row for row in primary_result.get("checks", []) if row.get("status") == "FAIL"}
    check("I008_PRIMARY_CAUSAL_GATE", set(failed) == {"S064_CORE_PREFLIGHT"} and failed["S064_CORE_PREFLIGHT"].get("evidence") == ["exact_workspace_set", "python_cache_absent"], failed)
    check("I009_EXPLICIT_GUARD_CORE_REGRESSIONS", explicit_guard_regressions_passed())
    check("I010_OWNERSHIP_SEPARATION", ownership.get("WORKSPACE_GUARD_CORE_LOGIC_DEFECT") == "NO_EXPLICIT_GUARDED_MUTATION_REGRESSIONS_ALL_PASS" and ownership.get("TEMPORAL_OBSERVER_IMPLEMENTATION_DEFECT") == "NOT_ESTABLISHED_NO_RUNTIME_ATTEMPT")
    check("I011_MUTATION_RULE", mutation.get("normative_rule") == "EVERY_FILESYSTEM_MUTATION_MUST_BE_EXPLICITLY_AUTHORIZED_OR_EXPLICITLY_CONTRACTED_AS_AN_IDENTITY_BOUND_RUNTIME_SIDE_EFFECT" and mutation.get("unaccounted_filesystem_mutation_count_required") == 0)
    check("I012_CACHE_POLICY_BOUNDED", cache.get("cleanup_as_acceptance") == "PROHIBITED" and cache.get("predecessor_cache_roots") == "DENY_WRITE")
    check("I013_V16_TERMINAL", disposition.get("status") == "FAIL_CLOSED_PRELOCK_TERMINAL_NO_RETRY_REFERENCE_ONLY" and disposition.get("continuation") == "PROHIBITED")
    check("I014_V17_DECISION", decision.get("decision") == "TERMINALIZE_V16_AND_AUTHORIZE_DISTINCT_V17_CONDITIONALLY")
    current = snapshot_tree(V16)
    check("I015_V16_TREE_BOUND", current.get("member_count") == binding.get("workspace_member_count") and current.get("tree_root_sha256") == binding.get("workspace_tree_root_sha256"), current)
    check("I016_ZERO_EXECUTION", v16_zero_execution_state())
    check("I017_V17_ABSENT", not V17.exists())

    with tempfile.TemporaryDirectory(prefix="v16-independent-bytecode-") as temporary:
        root = Path(temporary)
        (root / "m.py").write_text("X=1\n", encoding="utf-8")
        command = ["/usr/bin/python3.14", "-c", "import sys;sys.path.insert(0,'.');import m"]
        first = subprocess.run(command, cwd=root, env={}, check=False)
        implicit = bool(list((root / "__pycache__").glob("m*.pyc")))
        disabled = root / "disabled"; disabled.mkdir(); (disabled / "m.py").write_text("X=1\n", encoding="utf-8")
        second = subprocess.run(["/usr/bin/python3.14", "-B", *command[1:]], cwd=disabled, env={"PYTHONDONTWRITEBYTECODE": "1"}, check=False)
        check("I018_INDEPENDENT_IMPLICIT_CONTROL", first.returncode == 0 and implicit)
        check("I019_INDEPENDENT_DISABLED_CONTROL", second.returncode == 0 and not (disabled / "__pycache__").exists())

    check("I020_NEGATIVE_ZERO_MUTATION", all(row.get("zero_filesystem_mutation", True) for row in negative.get("checks", [])))
    failures = [row["id"] for row in checks if row["status"] == "FAIL"]
    result = {
        "record_type": "V16_BYTECODE_CACHE_INDEPENDENT_GOVERNANCE_VALIDATION",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
        "worker_or_codex_invocation_count": 0,
    }
    write_json_once(ROOT / "INDEPENDENT_GOVERNANCE_VALIDATION_RESULT_RUN-0002.json", result)
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
