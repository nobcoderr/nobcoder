"""Python-cache governance fixtures; all mutations are confined to temporary trees."""
from __future__ import annotations

import subprocess
import tempfile

from governance_common import *


def main() -> int:
    checks: list[dict[str, Any]] = []

    def check(identifier: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"id": identifier, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    with tempfile.TemporaryDirectory(prefix="v16-bytecode-governance-") as temporary:
        base = Path(temporary)
        current = base / "v17"
        predecessor = base / "v16"
        current.mkdir(); predecessor.mkdir()
        module = current / "probe_module.py"
        module.write_text("VALUE = 17\n", encoding="utf-8")
        command = ["/usr/bin/python3.14", "-c", "import sys;sys.path.insert(0,'.');import probe_module;assert probe_module.VALUE==17"]

        unguarded = subprocess.run(command, cwd=current, env={}, check=False, capture_output=True, text=True)
        implicit = list((current / "__pycache__").glob("probe_module*.pyc"))
        check("N001_IMPLICIT_BYTECODE_CREATION_DETECTED", unguarded.returncode == 0 and len(implicit) == 1, {"count": len(implicit)})

        disabled = base / "disabled"
        disabled.mkdir(); (disabled / "probe_module.py").write_text("VALUE = 17\n", encoding="utf-8")
        disabled_run = subprocess.run(["/usr/bin/python3.14", "-B", *command[1:]], cwd=disabled, env={"PYTHONDONTWRITEBYTECODE": "1"}, check=False, capture_output=True, text=True)
        check("N002_BYTECODE_DISABLED_NO_CACHE", disabled_run.returncode == 0 and not (disabled / "__pycache__").exists())

        routed = base / "routed"
        routed.mkdir(); (routed / "probe_module.py").write_text("VALUE = 17\n", encoding="utf-8")
        cache_root = routed / "authorized-cache"; cache_root.mkdir()
        policy = authorize_python_cache_policy(identity="V17", expected_identity="V17", workspace=routed, expected_workspace=routed, mode="ROUTED_CURRENT_WORKSPACE", cache_root=cache_root, deny_roots=[predecessor])
        routed_run = subprocess.run(command, cwd=routed, env={"PYTHONPYCACHEPREFIX": str(cache_root)}, check=False, capture_output=True, text=True)
        check("N003_AUTHORIZED_CURRENT_CACHE_ROUTING", policy.get("status") == "PASS" and routed_run.returncode == 0 and any(cache_root.rglob("probe_module*.pyc")) and not (routed / "__pycache__").exists())

        deny_current = base / "deny-current"; deny_current.mkdir()
        deny_predecessor = base / "deny-predecessor"; deny_predecessor.mkdir()
        link = deny_current / "cache-link"; link.symlink_to(deny_predecessor, target_is_directory=True)
        before = snapshot_tree(base)

        def rejected(**kwargs: Any) -> bool:
            try:
                authorize_python_cache_policy(**kwargs)
            except CachePolicyError:
                return True
            return False

        common = {"identity": "V17", "expected_identity": "V17", "workspace": deny_current, "expected_workspace": deny_current, "mode": "ROUTED_CURRENT_WORKSPACE", "deny_roots": [deny_predecessor]}
        traversal = deny_current / ".." / "deny-predecessor" / "cache"
        check("N004_CACHE_TRAVERSAL_REJECTED", rejected(**common, cache_root=traversal))
        check("N005_CACHE_SYMLINK_REJECTED", rejected(**common, cache_root=link))
        check("N006_PREDECESSOR_PYCACHE_REJECTED", rejected(**common, cache_root=deny_predecessor / "__pycache__"))
        check("N007_UNRESOLVED_IDENTITY_REJECTED", rejected(**{**common, "identity": None}, cache_root=deny_current / "cache"))
        check("N008_REJECTED_WRITES_ZERO_MUTATION", before == snapshot_tree(base))
        check("N009_DISABLED_POLICY_ACCEPTED", authorize_python_cache_policy(identity="V17", expected_identity="V17", workspace=deny_current, expected_workspace=deny_current, mode="DISABLED", cache_root=None, deny_roots=[deny_predecessor]).get("status") == "PASS")

    failures = [row["id"] for row in checks if row["status"] == "FAIL"]
    result = {
        "record_type": "V16_BYTECODE_CACHE_NEGATIVE_GOVERNANCE_FIXTURES",
        "status": "PASS" if not failures else "FAIL_CLOSED",
        "checks": checks,
        "failure_ids": failures,
        "validation_counts": {"total": len(checks), "passed": len(checks) - len(failures), "failed": len(failures)},
        "real_v16_mutations": 0,
        "worker_or_codex_invocation_count": 0,
    }
    write_json_once(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", result)
    print(json.dumps(result["validation_counts"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
