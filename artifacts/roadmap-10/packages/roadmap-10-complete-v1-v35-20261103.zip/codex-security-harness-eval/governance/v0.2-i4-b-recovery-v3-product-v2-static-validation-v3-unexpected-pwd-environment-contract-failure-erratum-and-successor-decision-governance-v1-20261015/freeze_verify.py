#!/usr/bin/env python3
"""Read-only final freeze verification."""

from __future__ import annotations

import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent


def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    manifest = json.loads((ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").read_text())
    lock = json.loads((ROOT / "GOVERNANCE_LOCK.json").read_text())
    checks = []

    def check(name: str, passed: bool) -> None:
        checks.append({"name": name, "pass": bool(passed)})

    rows = bytearray()
    check("manifest status", manifest["status"] == "PASS")
    check("lock status", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("manifest digest", sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json") == lock["governance_manifest_sha256"])
    check("member count", manifest["member_count"] == len(manifest["files"]))
    for member in manifest["files"]:
        path = ROOT / member["path"]
        check("member " + member["path"], path.is_file() and not path.is_symlink() and path.stat().st_size == member["bytes"] and sha(path) == member["sha256"])
        rows.extend(f"{member['sha256']}  {member['path']}\n".encode("ascii"))
    check("member root", hashlib.sha256(rows).hexdigest() == manifest["member_root_sha256"])
    root_rows = rows + f"{sha(ROOT / 'GOVERNANCE_ARTIFACT_MANIFEST.json')}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("ascii")
    check("canonical root", hashlib.sha256(root_rows).hexdigest() == lock["canonical_artifact_root_sha256"])
    check("root member count", lock["root_member_count"] == manifest["member_count"] + 1)
    check("all files read-only", all(not (path.stat().st_mode & 0o222) for path in ROOT.iterdir() if path.is_file()))
    check("directory read-only", not (ROOT.stat().st_mode & 0o222))
    passed = sum(row["pass"] for row in checks)
    print(json.dumps({"status": "PASS" if passed == len(checks) else "FAIL_CLOSED", "checks_total": len(checks), "checks_passed": passed, "failed": [row["name"] for row in checks if not row["pass"]], "manifest_sha256": sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"), "lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"), "canonical_root": lock["canonical_artifact_root_sha256"]}, sort_keys=True))
    return 0 if passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
