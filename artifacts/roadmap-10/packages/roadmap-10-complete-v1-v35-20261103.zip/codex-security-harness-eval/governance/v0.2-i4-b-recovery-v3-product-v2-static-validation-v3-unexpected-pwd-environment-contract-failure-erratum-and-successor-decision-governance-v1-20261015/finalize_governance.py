#!/usr/bin/env python3
"""Create non-self-referential governance manifest and lock, then freeze."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATION_V3_UNEXPECTED_PWD_ENVIRONMENT_CONTRACT_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"


def sha(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    value.update(path.read_bytes())
    return value.hexdigest()


def create(path: pathlib.Path, value: dict, mode: int = 0o444) -> None:
    if path.exists() or path.is_symlink():
        raise RuntimeError(f"final artifact collision: {path}")
    data = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode("ascii")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, mode)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)


def main() -> int:
    self_test = json.loads((ROOT / "GOVERNANCE_TEST_RESULT.json").read_text())
    independent = json.loads((ROOT / "INDEPENDENT_VALIDATION_RESULT.json").read_text())
    negative = json.loads((ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json").read_text())
    if self_test["status"] != "PASS" or independent["status"] != "PASS" or negative["status"] != "PASS":
        raise RuntimeError("mandatory validation failed")
    excluded = {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    members = []
    for path in sorted((p for p in ROOT.iterdir() if p.is_file() and p.name not in excluded), key=lambda p: p.name):
        members.append({"path": path.name, "bytes": path.stat().st_size, "sha256": sha(path)})
    rows = b"".join(f"{row['sha256']}  {row['path']}\n".encode("ascii") for row in members)
    manifest = {"schema_version": 1, "governance_identity": IDENTITY, "status": "PASS", "member_count": len(members), "files": members, "member_root_sha256": hashlib.sha256(rows).hexdigest()}
    manifest_path = ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    create(manifest_path, manifest)
    manifest_sha = sha(manifest_path)
    root_rows = rows + f"{manifest_sha}  GOVERNANCE_ARTIFACT_MANIFEST.json\n".encode("ascii")
    canonical_root = hashlib.sha256(root_rows).hexdigest()
    lock = {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "governance_manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": canonical_root,
        "root_member_count": len(members) + 1,
        "decision": "AUTHORIZE_DISTINCT_STATIC_VALIDATION_V4_CONDITIONALLY",
        "v3_status": "FAIL_CLOSED_TERMINAL_CONSUMED_NO_RETRY",
        "v0_2": "PASS_LOCKED_GOVERNANCE_ONLY", "G0": "NOT_MET", "V0_3": "BLOCKED",
        "P3_V2": "NOT_AUTHORIZED", "P6": "NOT_AUTHORIZED", "Recovery_V3": "NOT_AUTHORIZED"
    }
    lock_path = ROOT / "GOVERNANCE_LOCK.json"
    create(lock_path, lock)
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": lock["status"], "members": len(members), "root_members": len(members) + 1, "manifest_sha256": manifest_sha, "lock_sha256": sha(lock_path), "canonical_root": canonical_root}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
