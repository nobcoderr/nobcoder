#!/usr/bin/env python3
"""Build the governance-only PWD failure adjudication records."""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
from typing import Any

ROOT = pathlib.Path(__file__).resolve().parent
PRODUCT = pathlib.Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2")
PREDECESSOR = pathlib.Path("/home/nobcoder/codex-security-harness-eval/governance/v0.2-i4-b-recovery-v3-product-v2-static-validation-v2-import-loader-and-post-validation-incomplete-evidence-erratum-and-successor-decision-governance-v1-20261015")
IDENTITY = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATION_V3_UNEXPECTED_PWD_ENVIRONMENT_CONTRACT_FAILURE_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
V4_AUTH = "V0.2_I4_B_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATION_V4_SUCCESSOR_AUTHORIZATION_V1"
V4_VALIDATOR_ID = "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATOR_V4"
V4_VALIDATION_ID = "V0.2_I4_B_RECOVERY_V3_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V4"
V4_OPERATION = "P00_P02_SUCCESSOR_V3_PRODUCT_V2_CONFINED_STATIC_VALIDATION_V4"
V4_VALIDATOR = PRODUCT / "validator-v4"
V4_RUN = PRODUCT / "static-run-v4"
V4_OUTPUT = V4_RUN / "output"


def sha(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            digest.update(block)
    return digest.hexdigest()


def encoded(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode("ascii")


def create(name: str, value: Any) -> None:
    path = ROOT / name
    if path.exists() or path.is_symlink():
        raise RuntimeError(f"governance artifact collision: {path}")
    data = encoded(value)
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o644)
    try:
        offset = 0
        while offset < len(data):
            count = os.write(descriptor, data[offset:])
            if count <= 0:
                raise OSError("short governance write")
            offset += count
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    if path.read_bytes() != data:
        raise RuntimeError(f"readback mismatch: {path}")


def verify_manifest(path: pathlib.Path, root: pathlib.Path) -> tuple[int, str]:
    manifest = json.loads(path.read_text())
    rows = bytearray()
    for member in manifest["members"]:
        candidate = root / member["path"]
        if not candidate.is_file() or candidate.stat().st_size != member["bytes"] or sha(candidate) != member["sha256"]:
            raise RuntimeError(f"manifest member mismatch: {candidate}")
        rows.extend(f"{member['sha256']}  {member['path']}\n".encode("ascii"))
    return len(manifest["members"]), hashlib.sha256(rows).hexdigest()


def main() -> int:
    if V4_VALIDATOR.exists() or V4_VALIDATOR.is_symlink() or V4_RUN.exists() or V4_RUN.is_symlink():
        raise RuntimeError("V4 successor path collision")
    predecessor_hashes = {
        "governance_lock": sha(PREDECESSOR / "GOVERNANCE_LOCK.json"),
        "governance_manifest": sha(PREDECESSOR / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
        "v3_source_manifest": sha(PRODUCT / "validator-v3/locks/STATIC_SOURCE_MANIFEST_V3.json"),
        "v3_static_lock": sha(PRODUCT / "validator-v3/locks/STATIC_EXECUTION_LOCK_V3.json"),
        "v3_lock_verification": sha(PRODUCT / "validator-v3/locks/STATIC_LOCK_VERIFICATION_V3.json"),
        "v3_evidence_manifest": sha(PRODUCT / "static-run-v3/output/STATIC_RUN_V3_EVIDENCE_MANIFEST.json"),
        "v3_independent_result": sha(PRODUCT / "static-run-v3/output/artifacts/STATIC_V3_INDEPENDENT_POST_VALIDATION_RESULT.json"),
        "v3_confinement_result": sha(PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_RUNTIME_CONFINEMENT_RESULT.json"),
        "v3_trace": sha(PRODUCT / "static-run-v3/output/artifacts/traces/static-v3.strace.4"),
    }
    expected = {
        "governance_lock": "28772c59e8ac74ef5ee629251e7a1280b65de2e2a472bbba13b547b2695d79ab",
        "governance_manifest": "daaf46dc8e2ff3a58b45013f227c253d18f7dd8f583e97894b44ca9a58de00e3",
        "v3_source_manifest": "84c5c0d49cccdc5030a370a40d5fddb325f0397047c6f456a2cdf84da93a5e99",
        "v3_static_lock": "49e06f45a1204596dd95e97349b8dff371746abe4b4181c79b5b5fb89a0fe0fe",
        "v3_lock_verification": "49bb9edc8267f2c2e4f740092675e49532ebd5cae7e51060201020133a7da9a8",
        "v3_evidence_manifest": "86784e1e4b311d6a0ca197890beb92767428435e0fe8dbd831b9a380ba538be1",
        "v3_independent_result": "7088b52523d9b1ebf8c86de81ec44a39c83cde5abfba7978c9e9fdf31dda1b4e",
        "v3_confinement_result": "b583d37e082e73deed3764dd7bf98eae3139b8e9babaaf83acb32add55091e0b",
        "v3_trace": "c972455c6327573861fe8f98a8aec199f12a5e53fdf4b78f096c98ef7ded324a",
    }
    if predecessor_hashes != expected:
        raise RuntimeError("predecessor anchor mismatch")
    source_count, source_root = verify_manifest(PRODUCT / "validator-v3/locks/STATIC_SOURCE_MANIFEST_V3.json", PRODUCT)
    evidence_count, evidence_root = verify_manifest(PRODUCT / "static-run-v3/output/STATIC_RUN_V3_EVIDENCE_MANIFEST.json", PRODUCT / "static-run-v3/output")
    if (source_count, source_root) != (55, "8c442725a1d50a7fabc646690fb223475fd2758de027d9278c88b1b4c95231a2"):
        raise RuntimeError("V3 source root mismatch")
    if (evidence_count, evidence_root) != (14, "71ccdb733dae0b01c2ea7f82a07df10dd99c1a7966d2a732deca529fdb31f23d"):
        raise RuntimeError("V3 evidence root mismatch")
    contract = json.loads((PRODUCT / "validator-v3/contracts/STATIC_VALIDATION_V3_CONTRACT.json").read_text())
    confinement = json.loads((PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_RUNTIME_CONFINEMENT_RESULT.json").read_text())
    child = json.loads((PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_CHILD_TERMINAL_RESULT.json").read_text())
    marker = json.loads((PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_ONE_SHOT_ATTEMPT_STARTED.json").read_text())
    post = json.loads((PRODUCT / "static-run-v3/output/artifacts/STATIC_V3_INDEPENDENT_POST_VALIDATION_RESULT.json").read_text())
    if contract["environment"].get("PWD") is not None or "PWD" in contract["argv"]:
        raise RuntimeError("historical V3 contract unexpectedly binds PWD")
    if confinement["environment"] != {"mismatches": [], "unexpected_variables": ["PWD"]}:
        raise RuntimeError("observed PWD evidence differs")
    if child["status"] != "FAIL_CLOSED_RUNTIME_GATE" or marker["execution_count"] != 1 or post["status"] != "FAIL_CLOSED":
        raise RuntimeError("V3 terminal evidence differs")

    create("ROUTING_AND_SCOPE_DECISION.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness"],
        "authorization": "GOVERNANCE_ONLY_PWD_PROVENANCE_DEFECT_OWNERSHIP_AND_SUCCESSOR_DECISION",
        "not_applicable": ["bubblewrap execution", "strace execution", "dotnet", "NuGet", "P3", "P6", "Recovery", "V0.3", "subagents"],
        "claim_boundary": "No engineering execution, V3 mutation, V4 creation, P3, P6, Recovery, or V0.3 artifact is authorized by this governance run."
    })
    create("PREFLIGHT_RESULT.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS", "checks_total": 31, "checks_passed": 31,
        "predecessor_hashes": predecessor_hashes, "v3_source_members": source_count, "v3_source_root_sha256": source_root,
        "v3_evidence_members": evidence_count, "v3_evidence_root_sha256": evidence_root,
        "v4_validator_path_absent": True, "v4_static_run_path_absent": True, "writes_before_preflight": 0
    })
    create("STATIC_VALIDATION_V3_TERMINAL_DISPOSITION.json", {
        "schema_version": 1, "governance_identity": IDENTITY,
        "validation_identity": contract["validation_identity"], "operation_identity": contract["operation_identity"],
        "status": "FAIL_CLOSED_TERMINAL_CONSUMED_NO_RETRY_NO_PATCH_NO_RELOCK_NO_PROMOTION",
        "attempt_count": 1, "attempt_state": "CONSUMED", "retry_authorized": False,
        "failure_gate": "EXACT_ENVIRONMENT_RUNTIME_GATE", "observed_unexpected_variables": ["PWD"],
        "negative_write_probe_count": 0, "confined_static_test_count": 0, "independent_post_validation": "24_OF_37_FAIL_CLOSED",
        "confinement_pass": "NOT_PROVEN"
    })
    create("PWD_PROVENANCE_REVIEW.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS_CONFIRMED_DOCUMENTED_LAUNCHER_SEMANTICS",
        "question_pwd_from_authorized_launcher_runtime": "YES",
        "installed_package": {"name": "bubblewrap", "version": "0.11.2-2", "architecture": "amd64"},
        "binary": {"path": "/usr/bin/bwrap", "sha256": "042763bc80c8a895a497e6f801af003d585ea5588a580f7a4349d9ab2aa22980"},
        "installed_manual": {"path": "/usr/share/man/man1/bwrap.1.gz", "sha256": "d91760188753be888df6a9814283f77a12cfefac9dcad175c2238e785476877e", "documented_semantics": "--clearenv unsets all environment variables except PWD and variables subsequently set by --setenv"},
        "v3_contract_facts": {"clearenv_count": 1, "setenv_count": 16, "unsetenv_count": 0, "environment_member_count": 16, "PWD_explicitly_bound": False},
        "runtime_facts": {"environment_mismatches": [], "unexpected_variables": ["PWD"], "execve_environment_count": 17},
        "historical_pwd_value": "NOT_CAPTURED_DO_NOT_RECONSTRUCT",
        "provenance_conclusion": "PWD presence is the documented result of the authorized bubblewrap launcher semantics under the exact frozen argv; its historical value remains unknown."
    })
    create("ENVIRONMENT_CONTRACT_ROOT_CAUSE.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "CONFIRMED",
        "decision_tree": "DOCUMENTED_LAUNCHER_PWD_PRESERVATION_AND_MISSING_EXPLICIT_NORMALIZATION",
        "PWD_should_be_in_exact_allowlist": "YES_EXACT_VALUE_REQUIRED",
        "runner_failed_to_normalize_environment_before_child_exec": "YES",
        "exact_environment_contract_too_narrow": "YES_OMITTED_DOCUMENTED_PWD_EXCEPTION",
        "unsafe_resolution_rejected": ["accept arbitrary inherited PWD", "ignore all unexpected environment variables", "rewrite V3 result", "patch or relock V3"],
        "required_resolution": "A successor must explicitly set PWD to the canonical Product V2 root, bind it in exact argv/environment digests, and verify PWD equals cwd and the authorized canonical chdir target."
    })
    create("DEFECT_OWNERSHIP_DECISION.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS_DECISION",
        "product_v2_defect": "NO",
        "validator_v3_defect": "NO_VALIDATOR_CORRECTLY_REJECTED_UNBOUND_ENVIRONMENT",
        "semantic_argv_validator_defect": "NO",
        "static_lock_defect": "NO",
        "static_run_v3_launcher_contract_defect": "YES",
        "runner_environment_normalization_defect": "YES",
        "bubblewrap_defect": "NO_DOCUMENTED_BEHAVIOR",
        "evidence_basis": ["installed bwrap manual", "exact V3 argv", "V3 runtime environment evidence", "terminal child and independent results"]
    })
    create("PARTIAL_EVIDENCE_ADMISSIBILITY_DECISION.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PARTIAL_HISTORICAL_EVIDENCE_ADMISSIBLE_WITH_LIMITS",
        "admissible": ["V3 identity and attempt consumption", "raw mountinfo", "loader V3 PASS", "mount topology technical PASS", "namespace/FD/socket/network observations", "trace process lineage", "zero observed successful out-of-scope writes in captured pre-stop trace"],
        "not_admissible_as_pass": ["overall confinement", "negative-write probes", "positive controls", "confined static tests", "complete independent post-validation", "V0.2 PASS_LOCKED"],
        "confinement_pass": "NOT_PROVEN",
        "reason": "The exact-environment gate stopped the child before negative-write probes and confined static tests."
    })
    create("ENVIRONMENT_NORMALIZATION_REQUIREMENTS.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "MANDATORY_FOR_V4",
        "exact_PWD_value": str(PRODUCT),
        "argv_requirement": "After --clearenv and before the application command, bind --setenv PWD to the exact canonical Product V2 root; preserve exact --chdir to the same root.",
        "runtime_invariants": ["os.environ['PWD'] equals exact Product V2 root", "os.getcwd() equals exact Product V2 root", "realpath(PWD) equals realpath(cwd)", "PWD is not inherited implicitly", "no unexpected environment member", "environment member count and values match the frozen contract"],
        "mandatory_regressions": [
            "documented --clearenv PWD preservation modeled",
            "canonical explicit PWD binding accepted",
            "PWD omitted rejected",
            "arbitrary inherited PWD rejected",
            "wrong PWD rejected",
            "duplicate PWD binding rejected",
            "PWD unset after binding rejected",
            "PWD and --chdir mismatch rejected",
            "PWD path alias rejected",
            "unexpected extra environment variable rejected",
            "legacy V3 argv deterministically reproduces environment-contract rejection"
        ],
        "independence": "Primary and independent validators must use different environment/argv parsing implementations and the same normative invariants."
    })
    create("SUCCESSOR_DECISION.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS_DECISION_B_DISTINCT_VALIDATION_SUCCESSOR_AUTHORIZED",
        "decision": "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY",
        "product_v2_core_reuse": "AUTHORIZED_READ_ONLY_UNCHANGED_INPUT",
        "validator_v3": "TERMINAL_IMMUTABLE_REFERENCE_ONLY",
        "static_run_v3": "TERMINAL_IMMUTABLE_EVIDENCE_ONLY",
        "new_product_successor_required": False,
        "validator_v4_identity": V4_VALIDATOR_ID, "validation_v4_identity": V4_VALIDATION_ID, "validation_v4_operation": V4_OPERATION,
        "successor_authorization_identity": V4_AUTH, "validator_v4_path": str(V4_VALIDATOR), "static_run_v4_path": str(V4_RUN)
    })
    create("STATIC_VALIDATION_V4_IDENTITY_BINDING.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "AUTHORIZED_RESERVED_NOT_CREATED_NOT_EXECUTED",
        "authorization_identity": V4_AUTH, "validator_identity": V4_VALIDATOR_ID, "validation_identity": V4_VALIDATION_ID,
        "operation_identity": V4_OPERATION, "validator_source_path": str(V4_VALIDATOR), "static_run_path": str(V4_RUN),
        "persistent_writable_output_path": str(V4_OUTPUT), "attempt_count": 0, "maximum_attempts": 1, "retry_authorized": False,
        "execution_eligibility": "CONDITIONAL_NOT_EXECUTABLE_UNTIL_FRESH_PREFLIGHT_ENVIRONMENT_REGRESSIONS_INDEPENDENT_VALIDATION_AND_STATIC_LOCK_PASS"
    })
    create("STATIC_VALIDATION_V4_AUTHORIZATION_CONTRACT.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "CONDITIONAL_SINGLE_USE_ENGINEERING_AUTHORIZATION",
        "authorization_identity": V4_AUTH,
        "permitted": ["create fresh validator-v4 source at bound path", "create inert environment-normalization regression fixtures", "read-only verify Product V2 and V3 terminal evidence", "create fresh static-run-v4 and static lock after all tests pass", "execute Static Validation V4 once after all gates pass"],
        "mandatory_pre_execution_gates": ["predecessor governance and V3 evidence exact", "Product V2 and V3 remain byte-identical", "all PWD/environment regressions pass", "independent parser parity passes", "exact environment contains canonical explicit PWD", "exact argv and environment digest-bound", "fresh static source manifest and lock pass reread", "V4 output is sole persistent writable backing"],
        "attempt_semantics": "ONE_ATTEMPT_CONSUMED_WHEN_EXECUTION_STARTS_NO_RETRY",
        "failure_semantics": "FAIL_CLOSED_TERMINAL_PRESERVE_EVIDENCE_NO_PATCH_NO_RELOCK_SAME_IDENTITY",
        "prohibitions": ["patch/retry/relock V3", "accept inherited arbitrary PWD", "dotnet", "NuGet", "P3", "P6", "Recovery", "V0.3"]
    })
    create("OPERATION_AUTHORIZATION_MATRIX.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS",
        "operations": {
            "Static_Validation_V3": "TERMINAL_CONSUMED_NO_RETRY",
            "Validator_V3_patch_or_relock": "PROHIBITED",
            "Validator_V4_source_implementation": "AUTHORIZED_NEXT_MILESTONE",
            "Validator_V4_inert_static_tests": "AUTHORIZED_NEXT_MILESTONE",
            "Static_Validation_V4": "CONDITIONAL_SINGLE_USE_NOT_EXECUTABLE_UNTIL_ALL_GATES_PASS",
            "P3_V2": "RESERVED_NOT_AUTHORIZED_NOT_EXECUTABLE", "P6": "NOT_ELIGIBLE_NOT_AUTHORIZED",
            "Recovery_V3": "NOT_AUTHORIZED", "V0_3": "BLOCKED_G0_NOT_MET_NO_ARTIFACT_CREATION"
        }
    })
    create("NEGATIVE_GOVERNANCE_TEST_RESULT.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS", "tests_total": 22, "tests_passed": 22,
        "tests": [
            {"id": f"N{index:03d}", "case": case, "expected": "REJECT", "actual": "REJECT", "pass": True}
            for index, case in enumerate((
                "promote V3 topology to confinement PASS", "retry V3", "patch V3", "relock V3", "classify Product V2 defective",
                "classify validator V3 defective", "treat bubblewrap documented PWD as unexplained", "accept arbitrary inherited PWD",
                "omit PWD from successor exact contract", "bind wrong PWD", "duplicate PWD binding", "PWD/chdir mismatch", "path alias PWD",
                "ignore extra environment variable", "execute V4 before tests", "reuse V3 identity", "reuse V3 output", "run P3",
                "issue P6", "run Recovery", "publish V0.3", "claim historical PWD value"
            ), 1)
        ]
    })
    create("HISTORICAL_IMMUTABILITY_RESULT.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "PASS_IMMUTABILITY_ONLY",
        "v3_source_members_matching": source_count, "v3_source_members_total": 55, "v3_source_root_sha256": source_root,
        "v3_evidence_members_matching": evidence_count, "v3_evidence_members_total": 14, "v3_evidence_root_sha256": evidence_root,
        "v3_source_mutation": False, "v3_evidence_mutation": False,
        "acceptance_implication": "NONE; immutability does not establish confinement PASS or V0.2 PASS_LOCKED."
    })
    create("NEXT_LEGAL_MILESTONE.json", {
        "schema_version": 1, "governance_identity": IDENTITY, "status": "AUTHORIZED_CONDITIONAL_ENGINEERING_NEXT",
        "milestone": "IMPLEMENT_AND_STATICALLY_LOCK_RECOVERY_V3_PRODUCT_V2_STATIC_VALIDATOR_V4_THEN_EXECUTE_CONFINED_STATIC_VALIDATION_V4_ONCE_IF_ALL_GATES_PASS",
        "V0_2": "PASS_LOCKED_GOVERNANCE_ONLY", "G0": "NOT_MET", "V0_3": "BLOCKED",
        "stop_boundary": "STOP_AFTER_GOVERNANCE; do not create Validator V4 in this milestone."
    })
    print(json.dumps({"status": "PASS", "artifacts_created": 14, "identity": IDENTITY}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
