#!/usr/bin/env python3
"""Deterministic self-tests for the PWD governance decision."""

from __future__ import annotations

import json
import os
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
PRODUCT = pathlib.Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2")


def create(path: pathlib.Path, value: dict) -> None:
    if path.exists() or path.is_symlink():
        raise RuntimeError("self-test output collision")
    data = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode("ascii")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o644)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)


def main() -> int:
    checks = []

    def check(name: str, passed: bool) -> None:
        checks.append({"id": f"G{len(checks) + 1:03d}", "name": name, "pass": bool(passed)})

    terminal = json.loads((ROOT / "STATIC_VALIDATION_V3_TERMINAL_DISPOSITION.json").read_text())
    provenance = json.loads((ROOT / "PWD_PROVENANCE_REVIEW.json").read_text())
    cause = json.loads((ROOT / "ENVIRONMENT_CONTRACT_ROOT_CAUSE.json").read_text())
    ownership = json.loads((ROOT / "DEFECT_OWNERSHIP_DECISION.json").read_text())
    admissibility = json.loads((ROOT / "PARTIAL_EVIDENCE_ADMISSIBILITY_DECISION.json").read_text())
    requirements = json.loads((ROOT / "ENVIRONMENT_NORMALIZATION_REQUIREMENTS.json").read_text())
    successor = json.loads((ROOT / "SUCCESSOR_DECISION.json").read_text())
    binding = json.loads((ROOT / "STATIC_VALIDATION_V4_IDENTITY_BINDING.json").read_text())
    authorization = json.loads((ROOT / "STATIC_VALIDATION_V4_AUTHORIZATION_CONTRACT.json").read_text())
    matrix = json.loads((ROOT / "OPERATION_AUTHORIZATION_MATRIX.json").read_text())["operations"]
    negative = json.loads((ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT.json").read_text())
    immutable = json.loads((ROOT / "HISTORICAL_IMMUTABILITY_RESULT.json").read_text())
    next_step = json.loads((ROOT / "NEXT_LEGAL_MILESTONE.json").read_text())
    runtime = json.loads((PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_RUNTIME_CONFINEMENT_RESULT.json").read_text())
    contract = json.loads((PRODUCT / "validator-v3/contracts/STATIC_VALIDATION_V3_CONTRACT.json").read_text())

    check("V3 status terminal", "TERMINAL_CONSUMED" in terminal["status"])
    check("V3 attempt one", terminal["attempt_count"] == 1)
    check("V3 retry false", terminal["retry_authorized"] is False)
    check("V3 patch prohibited", "NO_PATCH" in terminal["status"])
    check("V3 relock prohibited", "NO_RELOCK" in terminal["status"])
    check("V3 promotion prohibited", "NO_PROMOTION" in terminal["status"])
    check("V3 probes zero", terminal["negative_write_probe_count"] == 0)
    check("V3 confined tests zero", terminal["confined_static_test_count"] == 0)
    check("V3 confinement not proven", terminal["confinement_pass"] == "NOT_PROVEN")
    check("runtime only PWD unexpected", runtime["environment"] == {"mismatches": [], "unexpected_variables": ["PWD"]})
    check("contract excludes PWD", "PWD" not in contract["environment"])
    check("argv excludes PWD", "PWD" not in contract["argv"])
    check("argv uses clearenv once", contract["argv"].count("--clearenv") == 1)
    check("argv has no unsetenv", contract["argv"].count("--unsetenv") == 0)
    check("launcher provenance yes", provenance["question_pwd_from_authorized_launcher_runtime"] == "YES")
    check("installed bwrap exact", provenance["installed_package"]["version"] == "0.11.2-2")
    check("bwrap digest exact", provenance["binary"]["sha256"] == "042763bc80c8a895a497e6f801af003d585ea5588a580f7a4349d9ab2aa22980")
    check("manual digest exact", provenance["installed_manual"]["sha256"] == "d91760188753be888df6a9814283f77a12cfefac9dcad175c2238e785476877e")
    check("historical PWD not reconstructed", provenance["historical_pwd_value"] == "NOT_CAPTURED_DO_NOT_RECONSTRUCT")
    check("PWD exact allowlist yes", cause["PWD_should_be_in_exact_allowlist"] == "YES_EXACT_VALUE_REQUIRED")
    check("runner normalization defect yes", cause["runner_failed_to_normalize_environment_before_child_exec"] == "YES")
    check("contract too narrow yes", cause["exact_environment_contract_too_narrow"].startswith("YES"))
    check("arbitrary PWD rejected", "accept arbitrary inherited PWD" in cause["unsafe_resolution_rejected"])
    check("Product V2 not defective", ownership["product_v2_defect"] == "NO")
    check("validator V3 not defective", ownership["validator_v3_defect"].startswith("NO_"))
    check("semantic parser not defective", ownership["semantic_argv_validator_defect"] == "NO")
    check("static lock not defective", ownership["static_lock_defect"] == "NO")
    check("launcher contract defective", ownership["static_run_v3_launcher_contract_defect"] == "YES")
    check("bubblewrap not defective", ownership["bubblewrap_defect"] == "NO_DOCUMENTED_BEHAVIOR")
    check("partial evidence limited", admissibility["status"] == "PARTIAL_HISTORICAL_EVIDENCE_ADMISSIBLE_WITH_LIMITS")
    check("topology admissible technical", "mount topology technical PASS" in admissibility["admissible"])
    check("overall confinement not admissible", "overall confinement" in admissibility["not_admissible_as_pass"])
    check("negative probes not admissible", "negative-write probes" in admissibility["not_admissible_as_pass"])
    check("static tests not admissible", "confined static tests" in admissibility["not_admissible_as_pass"])
    check("V0.2 PASS not admissible", "V0.2 PASS_LOCKED" in admissibility["not_admissible_as_pass"])
    check("exact successor PWD", requirements["exact_PWD_value"] == str(PRODUCT))
    check("PWD equals cwd invariant", any("os.getcwd()" in item for item in requirements["runtime_invariants"]))
    check("no unexpected environment invariant", "no unexpected environment member" in requirements["runtime_invariants"])
    check("regression set complete", len(requirements["mandatory_regressions"]) == 11)
    check("independent implementation required", "different" in requirements["independence"])
    check("distinct successor authorized", successor["decision"] == "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY")
    check("Product V2 reuse read-only", successor["product_v2_core_reuse"] == "AUTHORIZED_READ_ONLY_UNCHANGED_INPUT")
    check("V3 validator reference only", successor["validator_v3"] == "TERMINAL_IMMUTABLE_REFERENCE_ONLY")
    check("V3 run evidence only", successor["static_run_v3"] == "TERMINAL_IMMUTABLE_EVIDENCE_ONLY")
    check("V4 attempt zero", binding["attempt_count"] == 0)
    check("V4 max one", binding["maximum_attempts"] == 1)
    check("V4 retry false", binding["retry_authorized"] is False)
    check("V4 paths absent", not pathlib.Path(binding["validator_source_path"]).exists() and not pathlib.Path(binding["static_run_path"]).exists())
    check("V4 conditional", authorization["status"] == "CONDITIONAL_SINGLE_USE_ENGINEERING_AUTHORIZATION")
    check("V4 tests gate", any("PWD/environment regressions" in item for item in authorization["mandatory_pre_execution_gates"]))
    check("V4 lock gate", any("static source manifest" in item for item in authorization["mandatory_pre_execution_gates"]))
    check("V3 remains terminal in matrix", matrix["Static_Validation_V3"] == "TERMINAL_CONSUMED_NO_RETRY")
    check("P3 prohibited", matrix["P3_V2"].startswith("RESERVED_NOT_AUTHORIZED"))
    check("P6 prohibited", matrix["P6"].startswith("NOT_ELIGIBLE"))
    check("Recovery prohibited", matrix["Recovery_V3"] == "NOT_AUTHORIZED")
    check("V0.3 blocked", matrix["V0_3"].startswith("BLOCKED"))
    check("negative tests 22/22", negative["status"] == "PASS" and negative["tests_total"] == negative["tests_passed"] == 22 and all(row["pass"] for row in negative["tests"]))
    check("V3 source immutable 55/55", immutable["v3_source_members_matching"] == immutable["v3_source_members_total"] == 55 and immutable["v3_source_mutation"] is False)
    check("V3 evidence immutable 14/14", immutable["v3_evidence_members_matching"] == immutable["v3_evidence_members_total"] == 14 and immutable["v3_evidence_mutation"] is False)
    check("V0.2 remains governance only", next_step["V0_2"] == "PASS_LOCKED_GOVERNANCE_ONLY")
    check("G0 remains unmet", next_step["G0"] == "NOT_MET")
    check("next milestone V4", "STATIC_VALIDATOR_V4" in next_step["milestone"] and "STATIC_VALIDATION_V4" in next_step["milestone"])

    passed = sum(row["pass"] for row in checks)
    result = {"schema_version": 1, "governance_identity": next_step["governance_identity"], "status": "PASS" if passed == len(checks) else "FAIL_CLOSED", "tests_total": len(checks), "tests_passed": passed, "tests": checks}
    create(ROOT / "GOVERNANCE_TEST_RESULT.json", result)
    print(json.dumps({"status": result["status"], "tests": f"{passed}/{len(checks)}", "failed": [row["name"] for row in checks if not row["pass"]]}, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
