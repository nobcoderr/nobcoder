#!/usr/bin/env python3
"""Independent evidence-derived review of PWD provenance and V4 eligibility."""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
PRODUCT = pathlib.Path("/home/nobcoder/v0.2-i4-b-v3-partial-evidence-recovery-v3-handoff-v3-20261014/product-v2")


def digest(path: pathlib.Path) -> str:
    value = hashlib.sha256()
    value.update(path.read_bytes())
    return value.hexdigest()


def create(path: pathlib.Path, value: dict) -> None:
    if path.exists() or path.is_symlink():
        raise RuntimeError("independent result collision")
    data = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode("ascii")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o644)
    try:
        os.write(fd, data)
        os.fsync(fd)
    finally:
        os.close(fd)


def main() -> int:
    findings = []

    def verify(name: str, passed: bool, evidence=None) -> None:
        row = {"id": f"I{len(findings) + 1:03d}", "name": name, "pass": bool(passed)}
        if evidence is not None:
            row["evidence"] = evidence
        findings.append(row)

    contract = json.loads((PRODUCT / "validator-v3/contracts/STATIC_VALIDATION_V3_CONTRACT.json").read_text())
    confinement = json.loads((PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_RUNTIME_CONFINEMENT_RESULT.json").read_text())
    child = json.loads((PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_CHILD_TERMINAL_RESULT.json").read_text())
    post = json.loads((PRODUCT / "static-run-v3/output/artifacts/STATIC_V3_INDEPENDENT_POST_VALIDATION_RESULT.json").read_text())
    manual_path = pathlib.Path("/usr/share/man/man1/bwrap.1.gz")
    manual = gzip.decompress(manual_path.read_bytes()).decode("utf-8")
    provenance = json.loads((ROOT / "PWD_PROVENANCE_REVIEW.json").read_text())
    cause = json.loads((ROOT / "ENVIRONMENT_CONTRACT_ROOT_CAUSE.json").read_text())
    owner = json.loads((ROOT / "DEFECT_OWNERSHIP_DECISION.json").read_text())
    admissibility = json.loads((ROOT / "PARTIAL_EVIDENCE_ADMISSIBILITY_DECISION.json").read_text())
    requirements = json.loads((ROOT / "ENVIRONMENT_NORMALIZATION_REQUIREMENTS.json").read_text())
    successor = json.loads((ROOT / "SUCCESSOR_DECISION.json").read_text())
    binding = json.loads((ROOT / "STATIC_VALIDATION_V4_IDENTITY_BINDING.json").read_text())
    authorization = json.loads((ROOT / "STATIC_VALIDATION_V4_AUTHORIZATION_CONTRACT.json").read_text())
    matrix = json.loads((ROOT / "OPERATION_AUTHORIZATION_MATRIX.json").read_text())["operations"]

    verify("installed manual digest", digest(manual_path) == "d91760188753be888df6a9814283f77a12cfefac9dcad175c2238e785476877e")
    verify("manual clearenv section names PWD exception", "Unset all environment variables, except for" in manual and "\\fBPWD\\fR" in manual)
    verify("manual names subsequent setenv", "subsequently set by" in manual and "\\-setenv" in manual)
    verify("bound bwrap binary digest", digest(pathlib.Path("/usr/bin/bwrap")) == "042763bc80c8a895a497e6f801af003d585ea5588a580f7a4349d9ab2aa22980")
    verify("V3 clearenv exactly once", contract["argv"].count("--clearenv") == 1)
    verify("V3 setenv count equals contract env", contract["argv"].count("--setenv") == len(contract["environment"]) == 16)
    verify("V3 has no explicit PWD", "PWD" not in contract["argv"] and "PWD" not in contract["environment"])
    verify("V3 has no unsetenv", "--unsetenv" not in contract["argv"])
    verify("runtime has no bound-value mismatch", confinement["environment"]["mismatches"] == [])
    verify("runtime has only PWD unexpected", confinement["environment"]["unexpected_variables"] == ["PWD"])
    verify("runtime failure solely environment", confinement["failures"] == ["environment mismatch"])
    verify("child stops at runtime gate", child["status"] == "FAIL_CLOSED_RUNTIME_GATE" and child["test_sequence_status"] == "NOT_EXECUTED")
    verify("post validation incomplete", post["status"] == "FAIL_CLOSED" and post["checks_passed"] == 24 and post["checks_total"] == 37)
    verify("negative probes absent", not (PRODUCT / "static-run-v3/output/artifacts/runtime/STATIC_V3_WRITE_PROBE_RESULT.json").exists())
    verify("confined tests absent", not any((PRODUCT / "static-run-v3/output/artifacts/test-results").iterdir()))
    verify("provenance decision matches evidence", provenance["question_pwd_from_authorized_launcher_runtime"] == "YES")
    verify("historic value honestly unknown", provenance["historical_pwd_value"].startswith("NOT_CAPTURED"))
    verify("contract cause is omission", cause["exact_environment_contract_too_narrow"].startswith("YES_OMITTED"))
    verify("normalization cause is affirmative", cause["runner_failed_to_normalize_environment_before_child_exec"] == "YES")
    verify("Product not blamed", owner["product_v2_defect"] == "NO")
    verify("validator not blamed", owner["validator_v3_defect"].startswith("NO_"))
    verify("launcher contract owns defect", owner["static_run_v3_launcher_contract_defect"] == "YES")
    verify("bubblewrap documented not defective", owner["bubblewrap_defect"] == "NO_DOCUMENTED_BEHAVIOR")
    verify("confinement remains unproven", admissibility["confinement_pass"] == "NOT_PROVEN")
    verify("V4 exact PWD canonical", requirements["exact_PWD_value"] == str(PRODUCT))
    verify("V4 refuses inherited PWD", "PWD is not inherited implicitly" in requirements["runtime_invariants"])
    verify("V4 binds cwd equality", any("os.getcwd()" in row for row in requirements["runtime_invariants"]))
    verify("V4 regression count", len(requirements["mandatory_regressions"]) == 11)
    verify("successor is distinct", successor["decision"] == "B_AUTHORIZE_NEW_SUCCESSOR_IDENTITY" and successor["validator_v4_identity"] == binding["validator_identity"] and successor["validation_v4_identity"] == binding["validation_identity"])
    verify("V4 path fresh", not pathlib.Path(binding["validator_source_path"]).exists() and not pathlib.Path(binding["static_run_path"]).exists())
    verify("V4 fresh attempt zero", binding["attempt_count"] == 0 and binding["maximum_attempts"] == 1 and binding["retry_authorized"] is False)
    verify("V4 execution conditional", "CONDITIONAL_NOT_EXECUTABLE" in binding["execution_eligibility"])
    verify("fresh lock mandatory", any("static source manifest" in gate for gate in authorization["mandatory_pre_execution_gates"]))
    verify("environment regressions mandatory", any("PWD/environment regressions" in gate for gate in authorization["mandatory_pre_execution_gates"]))
    verify("V3 patch prohibited", matrix["Validator_V3_patch_or_relock"] == "PROHIBITED")
    verify("P3 remains blocked", matrix["P3_V2"].startswith("RESERVED_NOT_AUTHORIZED"))
    verify("P6 remains blocked", matrix["P6"].startswith("NOT_ELIGIBLE"))
    verify("Recovery remains blocked", matrix["Recovery_V3"] == "NOT_AUTHORIZED")
    verify("V0.3 remains blocked", matrix["V0_3"].startswith("BLOCKED"))

    passed = sum(row["pass"] for row in findings)
    result = {"schema_version": 1, "governance_identity": provenance["governance_identity"], "status": "PASS" if passed == len(findings) else "FAIL_CLOSED", "checks_total": len(findings), "checks_passed": passed, "checks": findings}
    create(ROOT / "INDEPENDENT_VALIDATION_RESULT.json", result)
    print(json.dumps({"status": result["status"], "checks": f"{passed}/{len(findings)}", "failed": [row["name"] for row in findings if not row["pass"]]}, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
