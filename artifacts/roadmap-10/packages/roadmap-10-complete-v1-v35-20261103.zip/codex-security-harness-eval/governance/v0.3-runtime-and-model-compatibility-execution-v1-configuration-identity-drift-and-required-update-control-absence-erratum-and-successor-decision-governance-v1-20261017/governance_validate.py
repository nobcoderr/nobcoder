#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v1-20261017")
V2 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v2-20261017")
IDENTITY = (
    "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1_"
    "CONFIGURATION_IDENTITY_DRIFT_AND_REQUIRED_UPDATE_CONTROL_ABSENCE_"
    "ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
)
OPERATION_KEYS = {
    "candidate_promotions", "capability_edges", "codex_cli_invocations", "compatibility_suite_executions",
    "credential_operations", "daybreak_invocations", "exploit_replays", "external_network_operations",
    "future_runtime_invocations", "parallel_operations", "runtime_invocations", "subagent_processes",
    "submission_operations", "target_operations", "worker_processes",
}
DOCUMENTS = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_AUTHORIZATION_BINDING.json",
    "V1_PRELOCK_EVIDENCE_BINDING.json", "CONFIGURATION_IDENTITY_DRIFT_FACTS.json",
    "CAUSAL_OWNERSHIP_ADJUDICATION.json", "V1_PRELOCK_TERMINAL_DISPOSITION.json",
    "RUNTIME_IDENTITY_DIMENSION_MODEL.json", "SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS.json",
    "RUNTIME_IDENTITY_PRECHECK_REQUIREMENTS.json", "SUCCESSOR_V2_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEXT_LEGAL_MILESTONE.json", "GOVERNANCE_DECISION_SUMMARY.json",
}


def load(name: str) -> dict[str, Any]:
    value = json.loads((ROOT / name).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(name)
    return value


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def zero_ops(value: Any) -> bool:
    return isinstance(value, dict) and set(value) == OPERATION_KEYS and all(type(value[k]) is int and value[k] == 0 for k in OPERATION_KEYS)


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    check("G001_ROOT", ROOT.is_dir() and not ROOT.is_symlink())
    check("G002_DOCUMENT_SET", all((ROOT / name).is_file() and not (ROOT / name).is_symlink() for name in DOCUMENTS))
    parsed = {name: load(name) for name in DOCUMENTS}
    check("G003_IDENTITIES", all(doc.get("governance_identity") == IDENTITY for doc in parsed.values()))
    check("G004_V2_ABSENT", not V2.exists() and not V2.is_symlink())
    check("G005_V1_STATIC_LOCK_ABSENT", not (V1 / "STATIC_EXECUTION_LOCK.json").exists())
    check("G006_V1_ATTEMPT_MARKER_ABSENT", not (V1 / "static-run-v1/ATTEMPT_MARKER.json").exists())
    check("G007_V1_RUNTIME_EMPTY", not any(path.is_file() for path in (V1 / "static-run-v1").rglob("*")))

    evidence = parsed["V1_PRELOCK_EVIDENCE_BINDING.json"]
    check("G008_ATTEMPT_ZERO", evidence.get("attempt_count") == 0)
    check("G009_CODEX_INVOCATION_ZERO", evidence.get("codex_cli_invocation_count") == 0)
    check("G010_UNIT_PASS", evidence.get("unit_fixtures") == {"total": 25, "passed": 25, "failed": 0})
    check("G011_PRIMARY_PASS", evidence.get("primary_static_validation") == {"total": 61, "passed": 61, "failed": 0})
    check("G012_INDEPENDENT_PASS", evidence.get("independent_static_validation") == {"total": 25, "passed": 25, "failed": 0})
    check("G013_PREFLIGHT_FAIL_ONLY", evidence.get("fresh_preflight") == {"total": 20, "passed": 18, "failed": 2})
    check("G014_HISTORY_PRESENT", len(evidence.get("append_only_prelock_history", [])) == 9)
    check("G015_BOUND_EVIDENCE", len(evidence.get("bound_evidence", [])) == 5)
    check("G016_BOUND_HASHES", all(sha(V1 / row["path"]) == row["sha256"] for row in evidence.get("bound_evidence", [])))

    facts = parsed["CONFIGURATION_IDENTITY_DRIFT_FACTS.json"]
    check("G017_BINARY_PASS", facts.get("binary", {}).get("identity") == "PASS")
    check("G018_BINARY_SHA", facts.get("binary", {}).get("sha256") == "628e35487d888a28f0427fc37501da529dd3d81fcbad7a2c3421c1e8670d92e1")
    check("G019_CONFIG_MISMATCH", facts.get("configuration", {}).get("identity_match") is False)
    check("G020_EXPECTED_CONFIG_SHA", facts.get("configuration", {}).get("expected_sha256") == "0f87224d0760e0667bd6807fe26b2f79fa5c08555792a060c39eda0ccd34e71a")
    check("G021_ACTUAL_CONFIG_SHA", facts.get("configuration", {}).get("actual_sha256") == "9f559aff9c257410098b0576c48350d55c3da00ad08d3bf5702db20063e25c59")
    check("G022_REQUIRED_ABSENT", facts.get("configuration", {}).get("required_control_observation") == "ABSENT")
    check("G023_SYMLINK_NONAUTH", facts.get("default_symlink", {}).get("authority") == "NON_AUTHORITATIVE_NOT_USED")

    cause = parsed["CAUSAL_OWNERSHIP_ADJUDICATION.json"]
    check("G024_BINARY_NOT_DEFECT", cause.get("binary_identity_defect") == "NO")
    check("G025_CAUSAL_HISTORY_UNKNOWN", cause.get("authorized_config_snapshot_stale") == "UNKNOWN_NO_CAUSAL_HISTORY")
    check("G026_PROVISIONING_OWNERSHIP", "CONFIGURATION_PROVISIONING_LIFECYCLE_GAP" in cause.get("ownership_defects", []))
    check("G027_AUTH_PRECONDITION_OWNERSHIP", "EXECUTION_AUTHORIZATION_PRECONDITION_GAP_FOR_COMPLIANT_CONFIG" in cause.get("ownership_defects", []))
    check("G028_RUNTIME_DEFECT_NOT_CLAIMED", cause.get("runtime_product_defect") == "NOT_ESTABLISHED_RUNTIME_NEVER_INVOKED")

    disposition = parsed["V1_PRELOCK_TERMINAL_DISPOSITION.json"]
    check("G029_V1_TERMINAL", disposition.get("disposition") == "FAIL_CLOSED_CONFIGURATION_IDENTITY_MISMATCH_TERMINAL_REFERENCE_PREDECESSOR")
    check("G030_V1_NO_CONTINUE", disposition.get("continue_v1") == "PROHIBITED")
    check("G031_V1_NO_PATCH_RELOCK", disposition.get("patch_v1") == disposition.get("relock_v1") == "PROHIBITED")

    successor = parsed["SUCCESSOR_V2_AUTHORIZATION_DECISION.json"]
    check("G032_SUCCESSOR_AUTH", successor.get("decision") == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V2_CONDITIONALLY")
    check("G033_SUCCESSOR_ID", successor.get("successor_execution_identity") == "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V2")
    check("G034_SUCCESSOR_SUITE", successor.get("successor_suite_identity") == "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V3")
    check("G035_SUCCESSOR_ATTEMPT_ZERO", successor.get("attempt_count") == 0 and successor.get("attempt_limit") == 1)
    check("G036_HOME_CONFIG_NO_MUTATION", successor.get("home_config_mutation_authorized") is False)
    check("G037_PROVIDER_FALSE", successor.get("provider_transport_authorized") is False)
    check("G038_WORKER_TARGET_FALSE", successor.get("worker_or_target_use_authorized") is False)

    config = parsed["SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS.json"]
    check("G039_CONFIG_UNDER_V2", str(config.get("authorized_candidate_path", "")).startswith(str(V2) + "/"))
    check("G040_REQUIRED_SETTING_FALSE", config.get("required_exact_values") == {"check_for_update_on_startup": False})
    check("G041_CONFIG_CONSUMPTION_PROOF", "PROVE_EXACT_LOCKED_BYTES" in config.get("consumption_rule", ""))
    check("G042_CONFIG_DRIFT_FAILS", str(config.get("configuration_drift", "")).startswith("STOP_BEFORE_ATTEMPT"))

    precheck = parsed["RUNTIME_IDENTITY_PRECHECK_REQUIREMENTS.json"]
    required = set(precheck.get("required_checks", []))
    check("G043_PRECHECK_REQUIRED", precheck.get("pre_attempt_gate") == "RUNTIME_IDENTITY_PRECHECK_REQUIRED")
    check("G044_PRECHECK_DIMENSIONS", {"EXACT_BINARY_SHA256", "EXACT_CONFIG_SHA256", "CONFIG_CONSUMPTION_PROOF", "DEFAULT_SYMLINK_NON_AUTHORITATIVE"}.issubset(required))
    check("G045_PRECHECK_FAILURE_ZERO", precheck.get("attempt_on_failure") == "0_OF_1" and precheck.get("invocation_on_failure") == 0)

    authority = parsed["AUTHORITY_NON_ESCALATION_DECISION.json"]
    check("G046_ZERO_OPERATIONS", zero_ops(authority.get("operation_counters")))
    check("G047_GOVERNANCE_ONLY", authority.get("governance_only") is True)
    check("G048_NO_CONFIG_EDIT", authority.get("config_edited_this_milestone") is False)
    check("G049_NO_STATIC_LOCK", authority.get("static_lock_issued_this_milestone") is False)
    check("G050_NO_RUNTIME", authority.get("runtime_invoked_this_milestone") is False)
    check("G051_ALL_DOWNSTREAM_FALSE", all(authority.get(key) is False for key in [
        "worker_execution_authorized", "subagent_execution_authorized", "credential_use_authorized",
        "target_access_authorized", "external_network_authorized", "exploit_replay_authorized",
        "parallelism_authorized", "capability_graph_authorized", "candidate_promotion_authorized",
        "submission_automation_authorized",
    ]))
    matrix = parsed["NEGATIVE_GOVERNANCE_TEST_MATRIX.json"]
    check("G052_NEGATIVE_COUNT", matrix.get("case_count") == 32 == len(matrix.get("cases", [])))
    check("G053_NEGATIVE_UNIQUE", len({row.get("case_id") for row in matrix.get("cases", [])}) == 32)
    check("G054_NEGATIVE_REJECT", all(row.get("expected") == "REJECT" for row in matrix.get("cases", [])))
    routing = parsed["ROUTING_LEDGER.json"]
    check("G055_ROUTING_COVERAGE", routing.get("shared_installed_skill_count") == 74 and routing.get("shared_represented_route_count") == 75)
    check("G056_NO_SUBAGENTS", routing.get("subagents_used") is False)
    check("G057_NEXT_MILESTONE", "COMPATIBILITY_SUITE_V2" in parsed["NEXT_LEGAL_MILESTONE.json"].get("next_if_pass_locked", ""))

    script_names = ["build_governance.py", "governance_validate.py", "negative_validate.py", "independent_validate.py", "freeze_verify.py", "finalize_governance.py"]
    for name in script_names:
        try:
            ast.parse((ROOT / name).read_text(encoding="utf-8"))
            okay = True
        except Exception:
            okay = False
        check(f"G_SYNTAX_{name}", okay)

    failed = [row for row in checks if row["status"] == "FAIL"]
    result = {
        "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "run_id": "PRIMARY_GOVERNANCE_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed),
        "checks": checks,
        "operation_counters": {key: 0 for key in sorted(OPERATION_KEYS)},
    }
    with (ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({k: result[k] for k in ("status", "checks_total", "checks_passed", "checks_failed")}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
