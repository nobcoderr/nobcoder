#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V2 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v2-20261017")
IDENTITY = (
    "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1_"
    "CONFIGURATION_IDENTITY_DRIFT_AND_REQUIRED_UPDATE_CONTROL_ABSENCE_"
    "ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: str(row["path"]))).encode()).hexdigest()


def require_pass(name: str, total: str, passed: str, failed: str) -> dict[str, Any]:
    value = load(name)
    if value.get("status") != "PASS" or value.get(failed) != 0 or value.get(total) != value.get(passed):
        raise SystemExit(f"not PASS: {name}")
    return value


def main() -> None:
    if (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").exists() or (ROOT / "GOVERNANCE_LOCK.json").exists():
        raise SystemExit("final artifacts already exist")
    if V2.exists() or V2.is_symlink():
        raise SystemExit("successor must remain absent at governance freeze")
    primary = require_pass("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "checks_total", "checks_passed", "checks_failed")
    negative = require_pass("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "tests_total", "tests_passed", "tests_failed")
    independent = require_pass("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json", "checks_total", "checks_passed", "checks_failed")
    freeze = require_pass("FREEZE_VERIFICATION_RESULT_RUN-0001.json", "checks_total", "checks_passed", "checks_failed")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    if any(value != 0 for value in authority["operation_counters"].values()):
        raise SystemExit("nonzero operation counter")
    members = []
    for path in sorted(path for path in ROOT.iterdir() if path.is_file() and path.name not in {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}):
        if path.is_symlink():
            raise SystemExit("symlink member")
        members.append({"path": path.name, "sha256": sha(path), "bytes": path.stat().st_size})
    member_root = canonical_root(members)
    manifest = {
        "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "canonical_member_root_sha256": member_root,
        "member_count": len(members),
        "members": members,
        "self_referential_hashes": False,
    }
    with (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True)
        handle.write("\n")
    manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    artifact_root = canonical_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    successor = load("SUCCESSOR_V2_AUTHORIZATION_DECISION.json")
    lock = {
        "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_GOVERNANCE_LOCK",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY",
        "decision": successor["decision"],
        "v1_disposition": "FAIL_CLOSED_CONFIGURATION_IDENTITY_MISMATCH_TERMINAL_REFERENCE_PREDECESSOR",
        "v1_attempt_count": 0,
        "v1_codex_invocation_count": 0,
        "v1_static_execution_lock": "NOT_ISSUED",
        "binary_identity_defect": "NO",
        "configuration_identity_match": False,
        "required_update_control": "ABSENT",
        "causal_history": "UNKNOWN_DO_NOT_RECONSTRUCT",
        "ownership_defects": load("CAUSAL_OWNERSHIP_ADJUDICATION.json")["ownership_defects"],
        "v2_execution_identity": successor["successor_execution_identity"],
        "v2_suite_identity": successor["successor_suite_identity"],
        "v2_path": successor["successor_path"],
        "v2_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_AT_FREEZE",
        "v2_attempt_count": 0,
        "v2_attempt_limit": 1,
        "home_config_mutation_authorized": False,
        "dedicated_config_candidate_required": True,
        "runtime_identity_precheck_required": True,
        "config_consumption_proof_required": True,
        "provider_transport_authorized": False,
        "daybreak_invocation_authorized": False,
        "worker_execution_authorized": False,
        "subagent_execution_authorized": False,
        "credential_use_authorized": False,
        "target_access_authorized": False,
        "external_network_authorized": False,
        "exploit_replay_authorized": False,
        "parallelism_authorized": False,
        "capability_graph_authorized": False,
        "candidate_promotion_authorized": False,
        "submission_automation_authorized": False,
        "operation_counters": authority["operation_counters"],
        "validation_counts": {
            "primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
            "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
            "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
            "freeze_candidate": {"total": freeze["checks_total"], "passed": freeze["checks_passed"], "failed": freeze["checks_failed"]},
        },
        "canonical_member_root_sha256": member_root,
        "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 2},
        "next_legal_milestone": load("NEXT_LEGAL_MILESTONE.json")["next_if_pass_locked"],
        "separate_acceptance_after_successor_execution": True,
    }
    with (ROOT / "GOVERNANCE_LOCK.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(lock, handle, indent=2, sort_keys=True)
        handle.write("\n")
    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": lock["status"],
        "decision": lock["decision"],
        "member_count": len(members),
        "governance_manifest_sha256": manifest_sha,
        "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"),
        "canonical_artifact_root_sha256": artifact_root,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
