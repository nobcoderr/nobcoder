#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import stat
import tomllib
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
BASE = Path("/home/nobcoder")
GOV_BASE = BASE / "codex-security-harness-eval/governance"
AUTH = GOV_BASE / "v0.3-runtime-and-model-compatibility-execution-authorization-governance-v1-20261017"
CONTRACT = GOV_BASE / "v0.3-runtime-and-model-compatibility-contract-v2-20261017"
V1 = BASE / "v0.3-runtime-and-model-compatibility-execution-v1-20261017"
V2 = BASE / "v0.3-runtime-and-model-compatibility-execution-v2-20261017"
CONFIG = BASE / ".codex/config.toml"
CODEX = BASE / ".codex/packages/standalone/releases/0.162.1-x86_64-unknown-linux-musl/bin/codex"
DEFAULT_CODEX = BASE / ".local/bin/codex"
ROUTING_MAP = BASE / "skill/config/AUTO_ROUTING_MAP.json"

IDENTITY = (
    "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1_"
    "CONFIGURATION_IDENTITY_DRIFT_AND_REQUIRED_UPDATE_CONTROL_ABSENCE_"
    "ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
)
V1_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1"
V2_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V2"
V2_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V3"

AUTH_HASHES = {
    "GOVERNANCE_LOCK.json": "391115baa03b30c420febaf43f478971a26a7cccb60d84c14cb4fda288007503",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "8f6e274d33cd797cdbd893afe8a39699098f15706ca1dd9e9782f347eb4daf18",
}
AUTH_ROOT = "c01564ae1e61f953eb39d36b93a657aafb174c11184396be6a2ebbacc2536da4"
CONTRACT_HASHES = {
    "GOVERNANCE_LOCK.json": "f083b7bc2756d9052c8c66bc6fb8ed3f3b42aacf54ac1b914d3e2e1270b3a363",
    "GOVERNANCE_ARTIFACT_MANIFEST.json": "6234ab0c6e31c81551394bce8a110a9145656cec6d10bb3c0aca660a331e2e31",
    "CODEX_CLI_0_162_1_CANDIDATE_BINDING.json": "149db13da86b35741d421eca271cc5fc17cd45312032a4811798db5d2cb44d22",
    "CONFIGURATION_IDENTITY_CONTRACT.json": "ce4c1b2bd93c37a558d2679e218512a56bd1be7f0ec5dcb28ca9af5844b82a35",
}
V1_EVIDENCE_HASHES = {
    "SOURCE_MANIFEST_CANDIDATE_RUN_0003.json": "68a16463bb5e3994d3988bc9ca357aee112edba3b79767a42c138a02294e6534",
    "results/prelock/unit-fixtures-run-0002.json": "c33ac1a9d6d4437a3123b10c360fcdab38f14f6630db028d74c2cabe10873e46",
    "results/prelock/primary-static-validation-run-0003.json": "ecf1aaa2e09de3dc6d3f603cbb58287655e2629b0afbe590e1fc85cea8c84483",
    "results/prelock/independent-static-validation-run-0002.json": "f5e447fbc9f10098ab99af213d37d66c01e9585fff9bc2033c09216ee2e1f579",
    "results/prelock/fresh-preflight-run-0002.json": "8576c7ef04edbfdd985603eb7b78bee7a4d862d8a53018c4b36a2ee3c7837dd4",
}
EXPECTED_CONFIG_SHA = "0f87224d0760e0667bd6807fe26b2f79fa5c08555792a060c39eda0ccd34e71a"
OBSERVED_CONFIG_SHA = "9f559aff9c257410098b0576c48350d55c3da00ad08d3bf5702db20063e25c59"
CODEX_SHA = "628e35487d888a28f0427fc37501da529dd3d81fcbad7a2c3421c1e8670d92e1"

OPERATION_KEYS = [
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "compatibility_suite_executions", "credential_operations", "daybreak_invocations",
    "exploit_replays", "external_network_operations", "future_runtime_invocations",
    "parallel_operations", "runtime_invocations", "subagent_processes",
    "submission_operations", "target_operations", "worker_processes",
]
ZERO_OPERATIONS = {key: 0 for key in OPERATION_KEYS}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(path)
    return value


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(
        f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: str(row["path"]))
    ).encode()
    return hashlib.sha256(material).hexdigest()


def verify_frozen_governance(root: Path, hashes: dict[str, str], artifact_root: str) -> dict[str, Any]:
    if not root.is_dir() or root.is_symlink():
        raise SystemExit(f"invalid predecessor root: {root}")
    for name, expected in hashes.items():
        path = root / name
        if not path.is_file() or path.is_symlink() or sha(path) != expected:
            raise SystemExit(f"predecessor mismatch: {path}")
    manifest = load(root / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    members = manifest.get("members")
    if not isinstance(members, list):
        raise SystemExit("invalid predecessor manifest")
    for row in members:
        path = root / str(row.get("path", ""))
        if not path.is_file() or path.is_symlink() or path.stat().st_size != row.get("bytes") or sha(path) != row.get("sha256"):
            raise SystemExit(f"predecessor member mismatch: {path}")
    manifest_path = root / "GOVERNANCE_ARTIFACT_MANIFEST.json"
    computed = canonical_root(
        members + [{"path": manifest_path.name, "sha256": sha(manifest_path), "bytes": manifest_path.stat().st_size}]
    )
    if computed != artifact_root:
        raise SystemExit("predecessor canonical artifact root mismatch")
    if stat.S_IMODE(root.stat().st_mode) != 0o555:
        raise SystemExit("predecessor root not frozen")
    if any(stat.S_IMODE(path.stat().st_mode) != 0o444 for path in root.iterdir() if path.is_file()):
        raise SystemExit("predecessor member not frozen")
    return {"member_count": len(members), "canonical_artifact_root_sha256": computed}


def write_json(name: str, value: Any) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_v1_evidence() -> dict[str, Any]:
    if not V1.is_dir() or V1.is_symlink():
        raise SystemExit("invalid V1 workspace")
    for relative, expected in V1_EVIDENCE_HASHES.items():
        path = V1 / relative
        if not path.is_file() or path.is_symlink() or sha(path) != expected:
            raise SystemExit(f"V1 evidence mismatch: {path}")
    preflight = load(V1 / "results/prelock/fresh-preflight-run-0002.json")
    failures = {name for name, row in preflight.get("checks", {}).items() if row.get("status") == "FAIL"}
    if preflight.get("status") != "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT":
        raise SystemExit("unexpected V1 preflight status")
    if failures != {"automatic_update_disabled", "codex_configuration_identity"}:
        raise SystemExit("unexpected V1 failure set")
    if preflight.get("attempt_count") != 0 or preflight.get("codex_cli_invocation_count") != 0:
        raise SystemExit("V1 operation counters changed")
    forbidden = [
        V1 / "STATIC_EXECUTION_LOCK.json",
        V1 / "STATIC_EXECUTION_LOCK_VERIFICATION.json",
        V1 / "HUMAN_GATE.json",
        V1 / "static-run-v1/ATTEMPT_MARKER.json",
    ]
    if any(path.exists() or path.is_symlink() for path in forbidden):
        raise SystemExit("unexpected post-preflight artifact")
    static_files = [path for path in (V1 / "static-run-v1").rglob("*") if path.is_file()]
    if static_files:
        raise SystemExit("static-run-v1 not empty")
    return {"preflight": preflight, "static_run_file_count": 0}


def routing_ledger() -> dict[str, Any]:
    routing = load(ROUTING_MAP)
    installed = {path.parent.name for path in (BASE / "skill/skill").glob("*/SKILL.md")}
    represented = set(routing.get("skill_routes", {})) | set(routing.get("always_active_skills", []))
    if installed - represented:
        raise SystemExit(f"unrepresented skills: {sorted(installed - represented)}")
    always = set(routing.get("always_active_skills", []))
    active_specific = {"agentic-security-research-harness", "external-ai-security-tool-governor"}
    entries = []
    for name in sorted(represented):
        if name in always:
            state = "ACTIVE"
            reason = "MANDATORY_CORE_POLICY_GOVERNANCE_ONLY_NO_CANDIDATE_GENERATION"
        elif name in active_specific:
            state = "ACTIVE"
            reason = "RUNTIME_HARNESS_OR_EXTERNAL_RUNTIME_GOVERNANCE"
        else:
            state = "NOT_APPLICABLE"
            reason = "NO_TARGET_OR_SPECIALIST_SURFACE_IN_GOVERNANCE_ONLY_ADJUDICATION"
        entries.append({"module": name, "state": state, "reason": reason})
    entries.append({"module": "codex-security-harness", "state": "ACTIVE", "reason": "LOCAL_COMPATIBILITY_RUNTIME_GOVERNANCE"})
    return {
        "routing_map_sha256": sha(ROUTING_MAP),
        "shared_installed_skill_count": len(installed),
        "shared_represented_route_count": len(represented),
        "evaluated_module_count": len(entries),
        "entries": entries,
        "subagents_used": False,
    }


def main() -> None:
    if V2.exists() or V2.is_symlink():
        raise SystemExit("successor V2 path already exists")
    auth_info = verify_frozen_governance(AUTH, AUTH_HASHES, AUTH_ROOT)
    # Contract V2's complete tree is already bound through the frozen auth package;
    # these exact members independently anchor the facts used by this adjudication.
    for name, expected in CONTRACT_HASHES.items():
        path = CONTRACT / name
        if not path.is_file() or path.is_symlink() or sha(path) != expected:
            raise SystemExit(f"contract predecessor mismatch: {path}")
    evidence = verify_v1_evidence()
    if not CONFIG.is_file() or CONFIG.is_symlink() or sha(CONFIG) != OBSERVED_CONFIG_SHA:
        raise SystemExit("observed config snapshot changed before governance build")
    parsed_config = tomllib.loads(CONFIG.read_text(encoding="utf-8"))
    if "check_for_update_on_startup" in parsed_config:
        raise SystemExit("required-setting observation changed before governance build")
    if not CODEX.is_file() or CODEX.is_symlink() or sha(CODEX) != CODEX_SHA or not os.access(CODEX, os.X_OK):
        raise SystemExit("pinned Codex binary mismatch")

    common = {"schema_version": "1.0", "governance_identity": IDENTITY}
    write_json(
        "ROUTING_AND_SCOPE_DECISION.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_ROUTING_AND_SCOPE_DECISION",
            "task": "GOVERNANCE_ONLY_PRELOCK_CONFIG_DRIFT_ADJUDICATION_AND_SUCCESSOR_DECISION",
            "allowed_operations": [
                "READ_FROZEN_GOVERNANCE_AND_PRELOCK_EVIDENCE",
                "CREATE_NEW_GOVERNANCE_ARTIFACTS",
                "PRIMARY_AND_NEGATIVE_GOVERNANCE_VALIDATION",
                "INDEPENDENT_GOVERNANCE_VALIDATION",
                "FINAL_FREEZE_VERIFICATION",
            ],
            "prohibited_this_milestone": [
                "EDIT_OR_REPLACE_CODEX_CONFIG",
                "PATCH_RELOCK_OR_CONTINUE_EXECUTION_V1",
                "CREATE_OR_EXECUTE_SUCCESSOR_V2",
                "ISSUE_STATIC_EXECUTION_LOCK",
                "INVOKE_CODEX_DAYBREAK_WORKER_OR_SUBAGENT",
                "USE_CREDENTIAL_TARGET_NETWORK_OR_PROVIDER_TRANSPORT",
                "RUN_EXPLOIT_PARALLELISM_CAPABILITY_GRAPH_PROMOTION_OR_SUBMISSION",
            ],
            "target_access": "NONE",
            "network_access": "NONE",
            "runtime_execution": "NONE",
            "subagents": "NOT_USED",
        },
    )
    write_json("ROUTING_LEDGER.json", {**common, "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_ROUTING_LEDGER", **routing_ledger()})
    write_json(
        "PREDECESSOR_AUTHORIZATION_BINDING.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_PREDECESSOR_AUTHORIZATION_BINDING",
            "authorization_governance": {
                "path": str(AUTH),
                "lock_sha256": AUTH_HASHES["GOVERNANCE_LOCK.json"],
                "manifest_sha256": AUTH_HASHES["GOVERNANCE_ARTIFACT_MANIFEST.json"],
                "canonical_artifact_root_sha256": AUTH_ROOT,
                **auth_info,
            },
            "compatibility_contract_v2": {
                "path": str(CONTRACT),
                "lock_sha256": CONTRACT_HASHES["GOVERNANCE_LOCK.json"],
                "manifest_sha256": CONTRACT_HASHES["GOVERNANCE_ARTIFACT_MANIFEST.json"],
                "candidate_binding_sha256": CONTRACT_HASHES["CODEX_CLI_0_162_1_CANDIDATE_BINDING.json"],
                "configuration_contract_sha256": CONTRACT_HASHES["CONFIGURATION_IDENTITY_CONTRACT.json"],
                "status": "PASS_LOCKED_GOVERNANCE_CONTRACT_ONLY",
            },
        },
    )
    result_history = []
    for path in sorted((V1 / "results/prelock").glob("*.json")):
        result_history.append({"path": path.relative_to(V1).as_posix(), "sha256": sha(path), "bytes": path.stat().st_size})
    write_json(
        "V1_PRELOCK_EVIDENCE_BINDING.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_V1_PRELOCK_EVIDENCE_BINDING",
            "execution_identity": V1_EXECUTION,
            "workspace": str(V1),
            "bound_evidence": [{"path": path, "sha256": digest} for path, digest in V1_EVIDENCE_HASHES.items()],
            "append_only_prelock_history": result_history,
            "source_implemented": True,
            "unit_fixtures": {"passed": 25, "failed": 0, "total": 25},
            "primary_static_validation": {"passed": 61, "failed": 0, "total": 61},
            "independent_static_validation": {"passed": 25, "failed": 0, "total": 25},
            "fresh_preflight": {"passed": 18, "failed": 2, "total": 20},
            "attempt_count": 0,
            "codex_cli_invocation_count": 0,
            "static_execution_lock": "NOT_ISSUED",
            "human_gate": "NOT_ISSUED",
            "static_run_file_count": evidence["static_run_file_count"],
        },
    )
    write_json(
        "CONFIGURATION_IDENTITY_DRIFT_FACTS.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIGURATION_IDENTITY_DRIFT_FACTS",
            "binary": {"path": str(CODEX), "sha256": CODEX_SHA, "version": "0.162.1", "identity": "PASS"},
            "default_symlink": {
                "path": str(DEFAULT_CODEX),
                "resolved_path": str(DEFAULT_CODEX.resolve(strict=False)),
                "authority": "NON_AUTHORITATIVE_NOT_USED",
            },
            "configuration": {
                "path": str(CONFIG),
                "expected_sha256": EXPECTED_CONFIG_SHA,
                "actual_sha256": OBSERVED_CONFIG_SHA,
                "identity_match": False,
                "toml_parse": "PASS",
                "required_control": "check_for_update_on_startup=false",
                "required_control_observation": "ABSENT",
            },
            "frozen_contract_prior_observation": "ABSENT_NOT_COMPLIANT",
            "compatibility_established": False,
        },
    )
    write_json(
        "CAUSAL_OWNERSHIP_ADJUDICATION.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_CAUSAL_OWNERSHIP_ADJUDICATION",
            "binary_identity_defect": "NO",
            "suite_source_semantics_defect": "NO_EVIDENCE",
            "fail_closed_preflight_defect": "NO_PRECHECK_WORKED_AS_DESIGNED",
            "configuration_identity_match": "NO",
            "required_config_control": "ABSENT_CONFIRMED_AT_CURRENT_SNAPSHOT",
            "frozen_contract_recorded_noncompliance": "YES_ABSENT_NOT_COMPLIANT",
            "authorized_config_snapshot_stale": "UNKNOWN_NO_CAUSAL_HISTORY",
            "local_config_changed": "CURRENT_BYTES_DIFFER_FROM_AUTHORIZED_DIGEST_CAUSAL_HISTORY_UNKNOWN",
            "config_contract_binding_defect": "NO_DRIFT_RULE_CORRECTLY_REQUIRED_FRESH_DECISION",
            "required_field_never_applied": "FROZEN_CONTRACT_SHOWS_ABSENT_AT_CONTRACT_SNAPSHOT_BUT_PRIOR_HISTORY_UNKNOWN",
            "ownership_defects": [
                "CONFIGURATION_PROVISIONING_LIFECYCLE_GAP",
                "EXECUTION_AUTHORIZATION_PRECONDITION_GAP_FOR_COMPLIANT_CONFIG",
            ],
            "runtime_product_defect": "NOT_ESTABLISHED_RUNTIME_NEVER_INVOKED",
        },
    )
    write_json(
        "V1_PRELOCK_TERMINAL_DISPOSITION.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_V1_PRELOCK_TERMINAL_DISPOSITION",
            "execution_identity": V1_EXECUTION,
            "disposition": "FAIL_CLOSED_CONFIGURATION_IDENTITY_MISMATCH_TERMINAL_REFERENCE_PREDECESSOR",
            "attempt": "0_OF_1_UNCONSUMED_BUT_IDENTITY_TERMINAL",
            "runtime_invocation_count": 0,
            "codex_cli_invocation_count": 0,
            "patch_v1": "PROHIBITED",
            "relock_v1": "PROHIBITED",
            "continue_v1": "PROHIBITED",
            "promote_v1": "PROHIBITED",
            "prelock_evidence": "ADMISSIBLE_HISTORICAL_EVIDENCE_ONLY",
        },
    )
    write_json(
        "RUNTIME_IDENTITY_DIMENSION_MODEL.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_RUNTIME_IDENTITY_DIMENSION_MODEL",
            "dimensions": {
                "BINARY_IDENTITY": ["absolute_path", "version", "sha256", "executable_type"],
                "CONFIG_IDENTITY": ["absolute_path", "sha256", "required_keys", "required_values", "consumption_proof"],
                "DEFAULT_SYMLINK_IDENTITY": ["resolved_path", "informational_drift", "must_not_select_runtime"],
            },
            "rules": [
                "BINARY_PASS_DOES_NOT_IMPLY_CONFIG_PASS",
                "DEFAULT_SYMLINK_DRIFT_DOES_NOT_REPLACE_PINNED_ABSOLUTE_BINARY",
                "CONFIG_BYTES_PRESENT_DO_NOT_PROVE_RUNTIME_CONSUMPTION",
                "ALL_CRITICAL_DIMENSIONS_MUST_PASS_BEFORE_ATTEMPT_MARKER",
            ],
        },
    )
    successor_config_path = V2 / "runtime-config-candidate/config.toml"
    write_json(
        "SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS",
            "successor_execution_identity": V2_EXECUTION,
            "authorized_candidate_path": str(successor_config_path),
            "home_config_mutation_authorized": False,
            "required_exact_values": {"check_for_update_on_startup": False},
            "forbidden_content_classes": [
                "RAW_SECRET", "CREDENTIAL", "PROVIDER_TOKEN", "TARGET", "EXTERNAL_NETWORK_ENDPOINT",
                "MCP_SERVER", "WORKER_AUTHORITY", "AUTO_APPROVAL", "UNSANDBOXED_FALLBACK",
            ],
            "digest_rule": "COMPUTE_ACTUAL_BYTES_AND_BIND_EXACT_SHA256_BEFORE_STATIC_EXECUTION_LOCK",
            "consumption_rule": "PROVE_EXACT_LOCKED_BYTES_ARE_THE_CONFIG_CONSUMED_BY_CODEX_0_162_1",
            "unknown_critical_key": "FAIL_CLOSED",
            "configuration_drift": "STOP_BEFORE_ATTEMPT_FRESH_GOVERNANCE_OR_SUCCESSOR_REQUIRED",
        },
    )
    write_json(
        "RUNTIME_IDENTITY_PRECHECK_REQUIREMENTS.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_SUCCESSOR_RUNTIME_IDENTITY_PRECHECK_REQUIREMENTS",
            "pre_attempt_gate": "RUNTIME_IDENTITY_PRECHECK_REQUIRED",
            "required_checks": [
                "EXACT_ABSOLUTE_BINARY_PATH",
                "EXACT_BINARY_SHA256",
                "EXACT_VERSION_0_162_1",
                "EXACT_CONFIG_CANDIDATE_PATH",
                "EXACT_CONFIG_SHA256",
                "REQUIRED_CONFIG_KEYS_AND_VALUES",
                "FORBIDDEN_AND_UNKNOWN_CRITICAL_CONFIG_REJECTION",
                "CONFIG_CONSUMPTION_MECHANISM_BOUND_TO_EXACT_ARGV_ENV_CWD",
                "CONFIG_CONSUMPTION_PROOF",
                "DEFAULT_SYMLINK_NON_AUTHORITATIVE",
                "PROVIDER_TRANSPORT_DISABLED",
                "RUNTIME_SUBSTRATE_V5_PASS_LOCKED",
            ],
            "failure_semantics": "STOP_BEFORE_STATIC_LOCK_OR_ATTEMPT_MARKER",
            "attempt_on_failure": "0_OF_1",
            "invocation_on_failure": 0,
        },
    )
    write_json(
        "SUCCESSOR_V2_AUTHORIZATION_DECISION.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_EXECUTION_V2_SUCCESSOR_AUTHORIZATION_DECISION",
            "decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V2_CONDITIONALLY",
            "successor_execution_identity": V2_EXECUTION,
            "successor_suite_identity": V2_SUITE,
            "successor_path": str(V2),
            "state_at_decision": "CONDITIONAL_ENGINEERING_AND_SINGLE_USE_COMPATIBILITY_VALIDATION_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
            "attempt_count": 0,
            "attempt_limit": 1,
            "fresh_source_identity_required": True,
            "fresh_tests_required": True,
            "fresh_static_lock_required": True,
            "fresh_one_shot_contract_required": True,
            "v1_reference_only": True,
            "v1_source_copy_as_authoritative_result": "PROHIBITED",
            "config_candidate_creation_authorized_only_under_successor_path": True,
            "home_config_mutation_authorized": False,
            "runtime_invocation_authorized": "CONDITIONAL_ONLY_AFTER_ALL_PREATTEMPT_GATES_PASS",
            "codex_invocation_limit": 1,
            "daybreak_invocation_authorized": False,
            "provider_transport_authorized": False,
            "external_network_authorized": False,
            "worker_or_target_use_authorized": False,
        },
    )
    write_json(
        "AUTHORITY_NON_ESCALATION_DECISION.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_AUTHORITY_NON_ESCALATION_DECISION",
            "governance_only": True,
            "v2_created_this_milestone": False,
            "config_edited_this_milestone": False,
            "static_lock_issued_this_milestone": False,
            "compatibility_suite_executed_this_milestone": False,
            "runtime_invoked_this_milestone": False,
            "worker_execution_authorized": False,
            "subagent_execution_authorized": False,
            "credential_use_authorized": False,
            "target_access_authorized": False,
            "external_network_authorized": False,
            "exploit_replay_authorized": False,
            "parallelism_authorized": False,
            "capability_graph_authorized": False,
            "candidate_promotion_authorized": False,
            "submission_automation_authorized": False,
            "operation_counters": ZERO_OPERATIONS,
        },
    )
    write_json(
        "OPERATION_AUTHORIZATION_MATRIX.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_OPERATION_AUTHORIZATION_MATRIX",
            "current_governance_operations": ZERO_OPERATIONS,
            "successor_future_conditional": {
                "create_v2_workspace_and_source": True,
                "create_dedicated_config_candidate_under_v2": True,
                "pure_unit_and_static_validation": True,
                "issue_static_lock_only_after_identity_precheck_pass": True,
                "one_identity_bound_codex_compatibility_invocation_after_all_gates": True,
            },
            "not_authorized": [
                "EDIT_HOME_CODEX_CONFIG", "CONTINUE_V1", "DAYBREAK", "WORKER", "SUBAGENT",
                "CREDENTIAL", "TARGET", "EXTERNAL_NETWORK", "EXPLOIT", "PARALLELISM",
                "CAPABILITY_GRAPH", "PROMOTION", "SUBMISSION",
            ],
            "unknown_operation": "REJECT",
        },
    )
    negative_cases = [
        ("N001", "continue_v1_after_prelock_failure", "REJECT"),
        ("N002", "patch_v1_source", "REJECT"),
        ("N003", "relock_v1", "REJECT"),
        ("N004", "edit_home_codex_config", "REJECT"),
        ("N005", "select_codex_from_PATH", "REJECT"),
        ("N006", "use_default_symlink_as_runtime_identity", "REJECT"),
        ("N007", "use_codex_0_163_0", "REJECT"),
        ("N008", "config_digest_mismatch", "REJECT"),
        ("N009", "required_update_control_absent", "REJECT"),
        ("N010", "required_update_control_true", "REJECT"),
        ("N011", "config_bytes_not_proven_consumed", "REJECT"),
        ("N012", "unknown_critical_config_key", "REJECT"),
        ("N013", "secret_in_config_candidate", "REJECT"),
        ("N014", "provider_token_in_config_candidate", "REJECT"),
        ("N015", "MCP_server_in_config_candidate", "REJECT"),
        ("N016", "provider_transport_enabled", "REJECT"),
        ("N017", "external_network_enabled", "REJECT"),
        ("N018", "static_lock_before_identity_precheck", "REJECT"),
        ("N019", "attempt_marker_before_all_gates", "REJECT"),
        ("N020", "automatic_retry", "REJECT"),
        ("N021", "runtime_output_self_certifies_PASS_LOCKED", "REJECT"),
        ("N022", "worker_authority_inferred", "REJECT"),
        ("N023", "subagent_authority_inferred", "REJECT"),
        ("N024", "credential_authority_inferred", "REJECT"),
        ("N025", "target_authority_inferred", "REJECT"),
        ("N026", "exploit_authority_inferred", "REJECT"),
        ("N027", "parallelism_or_capability_graph_inferred", "REJECT"),
        ("N028", "candidate_promotion_or_submission_inferred", "REJECT"),
        ("N029", "daybreak_availability_inferred", "REJECT"),
        ("N030", "rewrite_prelock_evidence", "REJECT"),
        ("N031", "claim_config_drift_causal_history", "REJECT"),
        ("N032", "claim_compatibility_established_before_execution", "REJECT"),
    ]
    write_json(
        "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_NEGATIVE_GOVERNANCE_TEST_MATRIX",
            "case_count": len(negative_cases),
            "cases": [{"case_id": case, "scenario": scenario, "expected": expected} for case, scenario, expected in negative_cases],
        },
    )
    write_json(
        "NEXT_LEGAL_MILESTONE.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_NEXT_LEGAL_MILESTONE",
            "next_if_pass_locked": (
                "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_"
                "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V2_"
                "ONCE_IF_ALL_GATES_PASS"
            ),
            "successor_execution_identity": V2_EXECUTION,
            "successor_suite_identity": V2_SUITE,
            "acceptance_after_execution": "SEPARATE_GOVERNANCE_REQUIRED",
        },
    )
    write_json(
        "GOVERNANCE_DECISION_SUMMARY.json",
        {
            **common,
            "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_GOVERNANCE_DECISION_SUMMARY",
            "v1_disposition": "FAIL_CLOSED_CONFIGURATION_IDENTITY_MISMATCH_TERMINAL_REFERENCE_PREDECESSOR",
            "v1_attempt_count": 0,
            "v1_codex_invocation_count": 0,
            "configuration_identity_match": False,
            "required_update_control": "ABSENT",
            "causal_history": "UNKNOWN_DO_NOT_RECONSTRUCT",
            "successor_decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V2_CONDITIONALLY",
            "successor_attempt_count": 0,
            "governance_status_before_validation": "CANDIDATE",
        },
    )


if __name__ == "__main__":
    main()
