#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v1-20261017")
V2 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v2-20261017")
CONFIG = Path("/home/nobcoder/.codex/config.toml")
IDENTITY = (
    "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1_"
    "CONFIGURATION_IDENTITY_DRIFT_AND_REQUIRED_UPDATE_CONTROL_ABSENCE_"
    "ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
)
SCRIPTS = {"build_governance.py", "governance_validate.py", "negative_validate.py", "independent_validate.py", "freeze_verify.py", "finalize_governance.py"}
BASE_JSON = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_AUTHORIZATION_BINDING.json",
    "V1_PRELOCK_EVIDENCE_BINDING.json", "CONFIGURATION_IDENTITY_DRIFT_FACTS.json",
    "CAUSAL_OWNERSHIP_ADJUDICATION.json", "V1_PRELOCK_TERMINAL_DISPOSITION.json",
    "RUNTIME_IDENTITY_DIMENSION_MODEL.json", "SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS.json",
    "RUNTIME_IDENTITY_PRECHECK_REQUIREMENTS.json", "SUCCESSOR_V2_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "NEXT_LEGAL_MILESTONE.json", "GOVERNANCE_DECISION_SUMMARY.json",
}
RESULTS = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json"}


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_root(rows: list[dict[str, Any]]) -> str:
    return hashlib.sha256("".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: str(row["path"]))).encode()).hexdigest()


def verify(final: bool) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    checks: list[dict[str, Any]] = []
    def check(check_id: str, value: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if value else "FAIL", "evidence": evidence})

    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    candidate = SCRIPTS | BASE_JSON | RESULTS
    check("F001_ROOT", ROOT.is_dir() and not ROOT.is_symlink())
    if final:
        check("F002_FINAL_ARTIFACTS", {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json", "FREEZE_VERIFICATION_RESULT_RUN-0001.json"}.issubset(actual))
    else:
        check("F002_CANDIDATE_FILE_SET", actual == candidate, {"actual": len(actual), "expected": len(candidate)})
    check("F003_NO_SYMLINKS", all(not path.is_symlink() for path in ROOT.iterdir()))
    check("F004_V2_ABSENT_AT_FREEZE", not V2.exists() and not V2.is_symlink())
    check("F005_CONFIG_UNCHANGED", sha(CONFIG) == "9f559aff9c257410098b0576c48350d55c3da00ad08d3bf5702db20063e25c59")
    check("F006_V1_NO_ATTEMPT", not (V1 / "static-run-v1/ATTEMPT_MARKER.json").exists())
    check("F007_V1_NO_STATIC_LOCK", not (V1 / "STATIC_EXECUTION_LOCK.json").exists())
    check("F008_V1_RUNTIME_EMPTY", not any(path.is_file() for path in (V1 / "static-run-v1").rglob("*")))
    for name in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / name).read_text(encoding="utf-8"))
            okay = True
        except Exception:
            okay = False
        check(f"F_SYNTAX_{name}", okay)
    parse_names = BASE_JSON | RESULTS
    if final:
        parse_names |= {"FREEZE_VERIFICATION_RESULT_RUN-0001.json", "GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
    check("F015_JSON_PARSE", all(isinstance(load(name), dict) for name in parse_names))
    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    successor = load("SUCCESSOR_V2_AUTHORIZATION_DECISION.json")
    check("F016_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_failed"] == 0 and primary["checks_total"] == primary["checks_passed"])
    check("F017_NEGATIVE_PASS", negative["status"] == "PASS" and negative["tests_failed"] == 0 and negative["tests_total"] == negative["tests_passed"] == 32)
    check("F018_INDEPENDENT_PASS", independent["status"] == "PASS" and independent["checks_failed"] == 0 and independent["checks_total"] == independent["checks_passed"] == 40)
    check("F019_ZERO_OPERATIONS", all(value == 0 for value in authority["operation_counters"].values()))
    check("F020_GOVERNANCE_ONLY", authority["governance_only"] is True and authority["runtime_invoked_this_milestone"] is False)
    check("F021_V1_TERMINAL", load("V1_PRELOCK_TERMINAL_DISPOSITION.json")["continue_v1"] == "PROHIBITED")
    check("F022_SUCCESSOR_DECISION", successor["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V2_CONDITIONALLY")
    check("F023_SUCCESSOR_ZERO", successor["attempt_count"] == 0)
    check("F024_CONFIG_NO_HOME_MUTATION", load("SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS.json")["home_config_mutation_authorized"] is False)
    check("F025_CAUSAL_UNKNOWN", load("CAUSAL_OWNERSHIP_ADJUDICATION.json")["authorized_config_snapshot_stale"] == "UNKNOWN_NO_CAUSAL_HISTORY")
    check("F026_NEXT", "COMPATIBILITY_SUITE_V2" in load("NEXT_LEGAL_MILESTONE.json")["next_if_pass_locked"])
    if final:
        manifest = load("GOVERNANCE_ARTIFACT_MANIFEST.json")
        lock = load("GOVERNANCE_LOCK.json")
        freeze = load("FREEZE_VERIFICATION_RESULT_RUN-0001.json")
        members = manifest["members"]
        expected_files = {row["path"] for row in members} | {"GOVERNANCE_ARTIFACT_MANIFEST.json", "GOVERNANCE_LOCK.json"}
        check("F027_FREEZE_CANDIDATE_PASS", freeze["status"] == "PASS" and freeze["checks_failed"] == 0)
        check("F028_FINAL_FILE_SET", actual == expected_files, {"actual": len(actual), "expected": len(expected_files)})
        check("F029_MEMBER_COUNT", manifest["member_count"] == len(members))
        check("F030_MEMBER_HASHES", all((ROOT / row["path"]).is_file() and sha(ROOT / row["path"]) == row["sha256"] and (ROOT / row["path"]).stat().st_size == row["bytes"] for row in members))
        member_root = canonical_root(members)
        check("F031_MEMBER_ROOT", member_root == manifest["canonical_member_root_sha256"] == lock["canonical_member_root_sha256"])
        manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
        check("F032_MANIFEST_SHA", manifest_sha == lock["governance_manifest_sha256"])
        artifact_root = canonical_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
        check("F033_ARTIFACT_ROOT", artifact_root == lock["canonical_artifact_root_sha256"])
        check("F034_LOCK_IDENTITY", lock["governance_identity"] == IDENTITY)
        check("F035_LOCK_STATUS", lock["status"] == "PASS_LOCKED_GOVERNANCE_ONLY")
        check("F036_LOCK_DECISION", lock["decision"] == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V2_CONDITIONALLY")
        check("F037_LOCK_V1", lock["v1_disposition"] == "FAIL_CLOSED_CONFIGURATION_IDENTITY_MISMATCH_TERMINAL_REFERENCE_PREDECESSOR")
        check("F038_LOCK_V2", lock["v2_state"] == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_AT_FREEZE")
        check("F039_LOCK_ZERO", all(value == 0 for value in lock["operation_counters"].values()))
        check("F040_READ_ONLY_FILES", all(stat.S_IMODE(path.stat().st_mode) == 0o444 for path in ROOT.iterdir() if path.is_file()))
        check("F041_READ_ONLY_ROOT", stat.S_IMODE(ROOT.stat().st_mode) == 0o555)
    failed = [row for row in checks if row["status"] == "FAIL"]
    return checks, failed


def main() -> None:
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--write-candidate", action="store_true")
    mode.add_argument("--verify-final", action="store_true")
    args = parser.parse_args()
    checks, failed = verify(final=args.verify_final)
    payload = {
        "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_FREEZE_VERIFICATION_RESULT",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "run_id": "FREEZE_VERIFICATION_RUN-0001" if args.write_candidate else "FINAL_READ_ONLY_FREEZE_VERIFICATION",
        "phase": "FREEZE_CANDIDATE" if args.write_candidate else "FINAL_READ_ONLY",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed),
        "checks": checks,
        "operation_counters": load("AUTHORITY_NON_ESCALATION_DECISION.json")["operation_counters"],
    }
    if args.write_candidate:
        with (ROOT / "FREEZE_VERIFICATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
    summary = {key: payload[key] for key in ("phase", "status", "checks_total", "checks_passed", "checks_failed")}
    if args.verify_final:
        lock = load("GOVERNANCE_LOCK.json")
        summary.update(
            governance_lock_sha256=sha(ROOT / "GOVERNANCE_LOCK.json"),
            governance_manifest_sha256=sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json"),
            canonical_artifact_root_sha256=lock["canonical_artifact_root_sha256"],
        )
    print(json.dumps(summary, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
