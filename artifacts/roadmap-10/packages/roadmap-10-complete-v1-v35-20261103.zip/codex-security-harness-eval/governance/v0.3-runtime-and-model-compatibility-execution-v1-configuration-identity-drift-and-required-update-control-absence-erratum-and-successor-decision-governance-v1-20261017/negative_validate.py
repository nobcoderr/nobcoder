#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
IDENTITY = (
    "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1_"
    "CONFIGURATION_IDENTITY_DRIFT_AND_REQUIRED_UPDATE_CONTROL_ABSENCE_"
    "ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
)


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def policy_rejects(scenario: str) -> bool:
    disposition = load("V1_PRELOCK_TERMINAL_DISPOSITION.json")
    successor = load("SUCCESSOR_V2_AUTHORIZATION_DECISION.json")
    config = load("SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS.json")
    precheck = load("RUNTIME_IDENTITY_PRECHECK_REQUIREMENTS.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    reject = {
        "continue_v1_after_prelock_failure": disposition["continue_v1"] == "PROHIBITED",
        "patch_v1_source": disposition["patch_v1"] == "PROHIBITED",
        "relock_v1": disposition["relock_v1"] == "PROHIBITED",
        "edit_home_codex_config": config["home_config_mutation_authorized"] is False,
        "select_codex_from_PATH": "EXACT_ABSOLUTE_BINARY_PATH" in precheck["required_checks"],
        "use_default_symlink_as_runtime_identity": "DEFAULT_SYMLINK_NON_AUTHORITATIVE" in precheck["required_checks"],
        "use_codex_0_163_0": "EXACT_VERSION_0_162_1" in precheck["required_checks"],
        "config_digest_mismatch": config["configuration_drift"].startswith("STOP_BEFORE_ATTEMPT"),
        "required_update_control_absent": config["required_exact_values"] == {"check_for_update_on_startup": False},
        "required_update_control_true": config["required_exact_values"] == {"check_for_update_on_startup": False},
        "config_bytes_not_proven_consumed": "PROVE_EXACT_LOCKED_BYTES" in config["consumption_rule"],
        "unknown_critical_config_key": config["unknown_critical_key"] == "FAIL_CLOSED",
        "secret_in_config_candidate": "RAW_SECRET" in config["forbidden_content_classes"],
        "provider_token_in_config_candidate": "PROVIDER_TOKEN" in config["forbidden_content_classes"],
        "MCP_server_in_config_candidate": "MCP_SERVER" in config["forbidden_content_classes"],
        "provider_transport_enabled": successor["provider_transport_authorized"] is False,
        "external_network_enabled": successor["external_network_authorized"] is False,
        "static_lock_before_identity_precheck": precheck["failure_semantics"] == "STOP_BEFORE_STATIC_LOCK_OR_ATTEMPT_MARKER",
        "attempt_marker_before_all_gates": precheck["failure_semantics"] == "STOP_BEFORE_STATIC_LOCK_OR_ATTEMPT_MARKER",
        "automatic_retry": successor["attempt_limit"] == 1,
        "runtime_output_self_certifies_PASS_LOCKED": load("NEXT_LEGAL_MILESTONE.json")["acceptance_after_execution"] == "SEPARATE_GOVERNANCE_REQUIRED",
        "worker_authority_inferred": authority["worker_execution_authorized"] is False,
        "subagent_authority_inferred": authority["subagent_execution_authorized"] is False,
        "credential_authority_inferred": authority["credential_use_authorized"] is False,
        "target_authority_inferred": authority["target_access_authorized"] is False,
        "exploit_authority_inferred": authority["exploit_replay_authorized"] is False,
        "parallelism_or_capability_graph_inferred": authority["parallelism_authorized"] is False and authority["capability_graph_authorized"] is False,
        "candidate_promotion_or_submission_inferred": authority["candidate_promotion_authorized"] is False and authority["submission_automation_authorized"] is False,
        "daybreak_availability_inferred": successor["daybreak_invocation_authorized"] is False,
        "rewrite_prelock_evidence": disposition["prelock_evidence"] == "ADMISSIBLE_HISTORICAL_EVIDENCE_ONLY",
        "claim_config_drift_causal_history": load("CAUSAL_OWNERSHIP_ADJUDICATION.json")["authorized_config_snapshot_stale"] == "UNKNOWN_NO_CAUSAL_HISTORY",
        "claim_compatibility_established_before_execution": load("CONFIGURATION_IDENTITY_DRIFT_FACTS.json")["compatibility_established"] is False,
    }
    return reject.get(scenario, False)


def main() -> None:
    matrix = load("NEGATIVE_GOVERNANCE_TEST_MATRIX.json")
    results = []
    for row in matrix["cases"]:
        passed = row["expected"] == "REJECT" and policy_rejects(row["scenario"])
        results.append({"case_id": row["case_id"], "scenario": row["scenario"], "expected": row["expected"], "status": "PASS" if passed else "FAIL"})
    failed = sum(row["status"] == "FAIL" for row in results)
    payload = {
        "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_NEGATIVE_GOVERNANCE_TEST_RESULT",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if failed == 0 else "FAIL_CLOSED",
        "tests_total": len(results),
        "tests_passed": len(results) - failed,
        "tests_failed": failed,
        "results": results,
        "operation_counters": load("AUTHORITY_NON_ESCALATION_DECISION.json")["operation_counters"],
    }
    with (ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({k: payload[k] for k in ("status", "tests_total", "tests_passed", "tests_failed")}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
