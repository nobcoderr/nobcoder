#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v1-20261017")
V2 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v2-20261017")
IDENTITY = (
    "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1_"
    "CONFIGURATION_IDENTITY_DRIFT_AND_REQUIRED_UPDATE_CONTROL_ABSENCE_"
    "ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_V1"
)


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, value: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if value else "FAIL", "evidence": evidence})

    preflight = json.loads((V1 / "results/prelock/fresh-preflight-run-0002.json").read_text())
    failures = {name for name, row in preflight["checks"].items() if row["status"] == "FAIL"}
    check("I001_PREFLIGHT_STATUS", preflight["status"] == "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT")
    check("I002_FAILURE_SET", failures == {"automatic_update_disabled", "codex_configuration_identity"})
    check("I003_COUNTS", preflight["validation_counts"] == {"total": 20, "passed": 18, "failed": 2})
    check("I004_ATTEMPT_ZERO", preflight["attempt_count"] == 0)
    check("I005_INVOCATION_ZERO", preflight["codex_cli_invocation_count"] == 0)
    check("I006_BINARY_PASSED", preflight["checks"]["codex_binary_identity"]["status"] == "PASS")
    check("I007_CONFIG_DIGEST_PAIR", preflight["checks"]["codex_configuration_identity"]["expected_sha256"] != preflight["checks"]["codex_configuration_identity"]["actual_sha256"])
    check("I008_UPDATE_ABSENT", preflight["checks"]["automatic_update_disabled"]["observed"] == "ABSENT")
    check("I009_NO_STATIC_LOCK", not (V1 / "STATIC_EXECUTION_LOCK.json").exists())
    check("I010_NO_ATTEMPT_MARKER", not (V1 / "static-run-v1/ATTEMPT_MARKER.json").exists())
    check("I011_STATIC_RUN_EMPTY", not any(path.is_file() for path in (V1 / "static-run-v1").rglob("*")))
    check("I012_V2_ABSENT", not V2.exists() and not V2.is_symlink())

    cause = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    check("I013_NO_BINARY_DEFECT", cause["binary_identity_defect"] == "NO")
    check("I014_NO_RUNTIME_CLAIM", cause["runtime_product_defect"] == "NOT_ESTABLISHED_RUNTIME_NEVER_INVOKED")
    check("I015_NO_CAUSAL_RECONSTRUCTION", "UNKNOWN" in cause["authorized_config_snapshot_stale"] and "UNKNOWN" in cause["local_config_changed"])
    check("I016_OWNERSHIP_TWO_GAPS", set(cause["ownership_defects"]) == {"CONFIGURATION_PROVISIONING_LIFECYCLE_GAP", "EXECUTION_AUTHORIZATION_PRECONDITION_GAP_FOR_COMPLIANT_CONFIG"})

    successor = load("SUCCESSOR_V2_AUTHORIZATION_DECISION.json")
    check("I017_DISTINCT_SUCCESSOR", successor["successor_execution_identity"] != "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V1")
    check("I018_SUCCESSOR_NOT_CREATED", successor["state_at_decision"].endswith("NOT_CREATED_NOT_EXECUTED"))
    check("I019_ONE_ATTEMPT", successor["attempt_count"] == 0 and successor["attempt_limit"] == 1)
    check("I020_HOME_CONFIG_FALSE", successor["home_config_mutation_authorized"] is False)
    check("I021_NO_PROVIDER", successor["provider_transport_authorized"] is False and successor["external_network_authorized"] is False)
    check("I022_NO_WORKER_TARGET", successor["worker_or_target_use_authorized"] is False)

    config = load("SUCCESSOR_CONFIG_IDENTITY_REQUIREMENTS.json")
    check("I023_CONFIG_PATH_NEW", config["authorized_candidate_path"].startswith(str(V2) + "/"))
    check("I024_REQUIRED_FALSE", config["required_exact_values"].get("check_for_update_on_startup") is False)
    check("I025_CONSUMPTION_REQUIRED", "CONSUMED_BY_CODEX_0_162_1" in config["consumption_rule"])
    check("I026_SECRETS_FORBIDDEN", {"RAW_SECRET", "CREDENTIAL", "PROVIDER_TOKEN"}.issubset(config["forbidden_content_classes"]))

    precheck = load("RUNTIME_IDENTITY_PRECHECK_REQUIREMENTS.json")
    check("I027_PREATTEMPT", precheck["pre_attempt_gate"] == "RUNTIME_IDENTITY_PRECHECK_REQUIRED")
    check("I028_EXACT_BINARY_AND_CONFIG", {"EXACT_ABSOLUTE_BINARY_PATH", "EXACT_BINARY_SHA256", "EXACT_CONFIG_SHA256"}.issubset(precheck["required_checks"]))
    check("I029_CONSUMPTION_AND_SYMLINK", {"CONFIG_CONSUMPTION_PROOF", "DEFAULT_SYMLINK_NON_AUTHORITATIVE"}.issubset(precheck["required_checks"]))
    check("I030_FAIL_BEFORE_ATTEMPT", precheck["failure_semantics"] == "STOP_BEFORE_STATIC_LOCK_OR_ATTEMPT_MARKER")

    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")
    check("I031_ZERO_OPS", all(value == 0 for value in authority["operation_counters"].values()))
    check("I032_NO_CONFIG_EDIT", authority["config_edited_this_milestone"] is False)
    check("I033_NO_RUNTIME", authority["runtime_invoked_this_milestone"] is False)
    check("I034_NO_V2_CREATE", authority["v2_created_this_milestone"] is False)
    check("I035_NO_AUTHORITY_ESCALATION", all(authority[key] is False for key in authority if key.endswith("_authorized")))

    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I036_PRIMARY_PASS", primary["status"] == "PASS" and primary["checks_failed"] == 0)
    check("I037_NEGATIVE_PASS", negative["status"] == "PASS" and negative["tests_failed"] == 0 and negative["tests_total"] == 32)
    check("I038_PRELOCK_HISTORY_PRESERVED", len(load("V1_PRELOCK_EVIDENCE_BINDING.json")["append_only_prelock_history"]) == 9)
    check("I039_NEXT_SEPARATE_ACCEPTANCE", load("NEXT_LEGAL_MILESTONE.json")["acceptance_after_execution"] == "SEPARATE_GOVERNANCE_REQUIRED")
    check("I040_ROUTING_NO_SUBAGENT", load("ROUTING_LEDGER.json")["subagents_used"] is False)

    failed = [row for row in checks if row["status"] == "FAIL"]
    payload = {
        "record_type": "V0_3_COMPATIBILITY_CONFIG_DRIFT_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0",
        "governance_identity": IDENTITY,
        "run_id": "INDEPENDENT_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks_total": len(checks),
        "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed),
        "checks": checks,
        "operation_counters": load("AUTHORITY_NON_ESCALATION_DECISION.json")["operation_counters"],
    }
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
    print(json.dumps({k: payload[k] for k in ("status", "checks_total", "checks_passed", "checks_failed")}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
