#!/usr/bin/env python3
"""Independent evidence and policy validation for the V5 pre-lock erratum."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V5 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
OLD = Path("/home/nobcoder/.codex/packages/standalone/releases/0.162.1-x86_64-unknown-linux-musl")
NEW = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl")
IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5_RUNTIME_IDENTITY_UNAVAILABLE_AND_NONCANDIDATE_INVOCATION_DEVIATION_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
EXPECTED_V5_ROOT = "f8bd58de48721da7099c4430998f6cacd7351cff43ffb8c99d85c3744aa6d74b"
EXPECTED_BINARY = "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215"
EXPECTED_PACKAGE = "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def regular(path: Path) -> bool:
    try:
        item = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISREG(item.st_mode) and not stat.S_ISLNK(item.st_mode)


def tree_digest(path: Path) -> str:
    lines = []
    for member in sorted(candidate for candidate in path.rglob("*") if candidate.is_file()):
        lines.append(f"{digest(member)}  {member.relative_to(path).as_posix()}\n")
    return hashlib.sha256("".join(lines).encode()).hexdigest()


def main() -> None:
    rows: list[dict[str, Any]] = []
    def verify(check_id: str, condition: bool, evidence: Any = None) -> None:
        rows.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    terminal = load("V5_TERMINAL_DISPOSITION.json")
    evidence = load("V5_PRELOCK_EVIDENCE_BINDING.json")
    availability = load("RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION.json")
    deviation = load("NONCANDIDATE_INVOCATION_DEVIATION_ADJUDICATION.json")
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    selection = load("SUCCESSOR_RUNTIME_IDENTITY_SELECTION.json")
    discovery = load("IDENTITY_SAFE_DISCOVERY_CONTRACT.json")
    config = load("CONFIG_BINDING_DECISION.json")
    successor = load("SUCCESSOR_V6_AUTHORIZATION_DECISION.json")
    requirements = load("SUCCESSOR_V6_REQUIREMENTS.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")

    verify("I001_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    verify("I002_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_failed") == 0 and negative.get("tests_total") == 24)
    verify("I003_IDENTITY", all(load(name).get("governance_identity") == IDENTITY for name in ["V5_TERMINAL_DISPOSITION.json", "V5_PRELOCK_EVIDENCE_BINDING.json", "RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION.json", "SUCCESSOR_V6_AUTHORIZATION_DECISION.json"]))
    verify("I004_V5_ROOT", tree_digest(V5) == EXPECTED_V5_ROOT, tree_digest(V5))
    verify("I005_V5_ROOT_BOUND", evidence.get("canonical_tree_root_sha256") == EXPECTED_V5_ROOT)
    verify("I006_V5_PREFLIGHT_HASH", digest(V5 / "results/prelock/fresh-preflight-run-0001.json") == evidence.get("fresh_preflight_sha256"))
    verify("I007_V5_DEVIATION_HASH", digest(V5 / "results/prelock/noncandidate-discovery-event-run-0001.json") == evidence.get("noncandidate_discovery_event_sha256"))
    verify("I008_V5_TERMINAL_HASH", digest(V5 / "results/prelock/prelock-terminal-record-run-0001.json") == evidence.get("prelock_terminal_record_sha256"))
    for name in ["STATIC_EXECUTION_LOCK.json", "STATIC_EXECUTION_LOCK_VERIFICATION.json", "static-run-v1/ATTEMPT_MARKER.json", "static-run-v1/runtime-result-0001.json"]:
        verify("I_ABSENT_" + name.replace("/", "_").replace(".", "_"), not (V5 / name).exists() and not (V5 / name).is_symlink())
    verify("I013_V5_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_PRELOCK_TERMINAL_REFERENCE_PREDECESSOR")
    verify("I014_ATTEMPT_ZERO", terminal.get("candidate_attempt") == "0_OF_1_NOT_CONSUMED")
    verify("I015_CANDIDATE_INVOCATION_ZERO", terminal.get("candidate_codex_0_162_1_invocation_count") == 0)
    verify("I016_NONCANDIDATE_ONE", terminal.get("noncandidate_codex_0_163_0_discovery_invocation_count") == 1)
    verify("I017_OLD_RELEASE_ABSENT", not OLD.exists() and not OLD.is_symlink())
    verify("I018_OLD_NOT_INCOMPATIBLE", availability.get("candidate_0_162_1_incompatibility_proven") is False)
    binary = NEW / "bin/codex"
    package = NEW / "codex-package.json"
    verify("I019_NEW_BINARY_REGULAR", regular(binary) and os.access(binary, os.X_OK))
    verify("I020_NEW_BINARY_SHA", regular(binary) and digest(binary) == EXPECTED_BINARY)
    verify("I021_NEW_PACKAGE_SHA", regular(package) and digest(package) == EXPECTED_PACKAGE)
    metadata = json.loads(package.read_text()) if regular(package) else {}
    verify("I022_NEW_METADATA", (metadata.get("version"), metadata.get("target"), metadata.get("variant"), metadata.get("entrypoint")) == ("0.163.0", "x86_64-unknown-linux-musl", "codex", "bin/codex"))
    verify("I023_DEVIATION_CLASS", deviation.get("classification") == "NONCANDIDATE_DISCOVERY_INVOCATION_DEVIATION")
    verify("I024_DEVIATION_PRESERVED", deviation.get("historical_evidence_must_remain") is True and deviation.get("candidate_attempt_consumed") is False)
    verify("I025_THREE_OWNERS", [ownership.get("runtime_provisioning_lifecycle_gap"), ownership.get("toolchain_identity_availability_drift"), ownership.get("discovery_probe_identity_guard_gap")] == ["YES", "YES", "YES"])
    choices = {row["id"]: row["decision"] for row in selection.get("options", [])}
    verify("I026_OPTION_EXCLUSIVE", choices == {"A_REPROVISION_0_162_1": "NOT_SELECTED", "B_ADOPT_0_163_0_AS_FRESH_CANDIDATE": "SELECTED"})
    verify("I027_NO_COMPAT_INFERENCE", selection.get("compatibility") == "NOT_ESTABLISHED")
    verify("I028_DISCOVERY_NONEXEC", discovery.get("failure_semantics") == "STOP_WITH_ATTEMPT_0_AND_INVOCATION_0")
    verify("I029_DISCOVERY_PROHIBITIONS", set(discovery.get("prohibited_discovery", [])) == {"PATH_LOOKUP", "DEFAULT_SYMLINK_AS_AUTHORITY", "CODEX_VERSION_INVOCATION_BEFORE_IDENTITY_PASS", "ANY_RUNTIME_INVOCATION_AS_AVAILABILITY_PROBE"})
    verify("I030_CONFIG_FRESH", config.get("must_be_fresh_v6_artifact") is True and config.get("v5_config_may_be_runtime_input") is False)
    verify("I031_CONFIG_GLOBAL_UNCHANGED", config.get("global_config_mutation_authorized") is False)
    verify("I032_SUCCESSOR_FRESH", (successor.get("successor_execution_identity"), successor.get("successor_suite_identity"), successor.get("successor_runtime_identity")) == ("V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6", "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V7", "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL"))
    verify("I033_SUCCESSOR_NOT_CREATED", not V6.exists() and not V6.is_symlink() and successor.get("creation_or_execution_this_milestone") is False)
    verify("I034_ONE_SHOT", successor.get("attempt_count") == 0 and successor.get("attempt_limit") == 1 and successor.get("codex_0_163_0_invocation_count") == 0 and successor.get("codex_0_163_0_invocation_limit") == 1)
    binding = requirements.get("runtime_binding", {})
    verify("I035_EXACT_BINDING", binding == {"binary_path": str(binary), "binary_sha256": EXPECTED_BINARY, "package_path": str(package), "package_sha256": EXPECTED_PACKAGE, "config_path": str(V6 / "runtime-config-candidate/config.toml"), "config_sha256": "7ae835188ef2ab3221e15effac45375b2d6112954d022aa7776f802f7b8697c0"})
    verify("I036_NO_CURRENT_OPS", len(authority.get("governance_operation_counters", {})) == 15 and all(value == 0 for value in authority.get("governance_operation_counters", {}).values()))
    verify("I037_HISTORICAL_COUNT_SEPARATE", authority.get("historical_v5_noncandidate_invocation_count") == 1)
    authorized_flags = [value for key, value in authority.items() if key.endswith("_authorized")]
    verify("I038_NO_AUTHORITY_ESCALATION", authorized_flags and not any(authorized_flags))
    verify("I039_COMPAT_NOT_ESTABLISHED", terminal.get("compatibility") == "NOT_ESTABLISHED")
    verify("I040_CONFINEMENT_NOT_PROVEN", terminal.get("confinement") == "NOT_PROVEN")

    failures = [row for row in rows if row["status"] == "FAIL"]
    payload = {
        "governance_identity": IDENTITY,
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_INDEPENDENT_VALIDATION_RESULT",
        "schema_version": "1.0", "run_id": "INDEPENDENT_VALIDATION_RUN-0001",
        "status": "PASS" if not failures else "FAIL_CLOSED", "checks": rows,
        "checks_total": len(rows), "checks_passed": len(rows) - len(failures), "checks_failed": len(failures),
        "operation_counters": {key: 0 for key in authority.get("governance_operation_counters", {})},
    }
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True); handle.write("\n")
    print(json.dumps({"status": payload["status"], "passed": payload["checks_passed"], "total": payload["checks_total"]}, sort_keys=True))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
