#!/usr/bin/env python3
"""Build the V5 pre-lock runtime-identity governance adjudication."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v4-non-numeric-strace-exit-return-grammar-and-missing-runtime-result-post-validation-failure-erratum-and-successor-decision-governance-v1-20261020")
V5 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")

OLD_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.162.1-x86_64-unknown-linux-musl/bin/codex")
OLD_PACKAGE = OLD_BINARY.parent.parent / "codex-package.json"
NEW_RELEASE = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl")
NEW_BINARY = NEW_RELEASE / "bin/codex"
NEW_PACKAGE = NEW_RELEASE / "codex-package.json"
DEFAULT_CODEX = Path("/home/nobcoder/.local/bin/codex")
DEFAULT_RELEASE = Path("/home/nobcoder/.codex/packages/standalone/current")

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5_RUNTIME_IDENTITY_UNAVAILABLE_AND_NONCANDIDATE_INVOCATION_DEVIATION_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V5_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5"
V5_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V6"
V6_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6"
V6_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V7"
V6_RUNTIME = "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL"
V6_CONFIG = V6 / "runtime-config-candidate/config.toml"

HASHES = {
    "predecessor_lock": "cb389d375597d5d564c7ecb29936a930ef99c106215014017ee1b8c48be9104d",
    "predecessor_manifest": "ad52ef6930899b56acc0705be4476f90a8e9d1b2e99d83cf13c49cbe645f4f09",
    "predecessor_root": "5a1009e82cb2c11d627249cae528e0346d756f4563c78898b697dede68269a1b",
    "v5_tree_root": "f8bd58de48721da7099c4430998f6cacd7351cff43ffb8c99d85c3744aa6d74b",
    "v5_preflight": "c5fc77cfa0e2781b52af0f3968a2b967f79311d55e271f83320f7b30a37e57a8",
    "v5_discovery": "f41ec28df6ef0bdb139d6d9d8680fe2e1d7014282813c524d7d6040c50088ca2",
    "v5_terminal": "b17b1f265d98bff7e71cb74d469d049a2b70d5ec6cd8e815ea0535b90a4cc9b9",
    "new_binary": "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215",
    "new_package": "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78",
    "fresh_config_spec": "7ae835188ef2ab3221e15effac45375b2d6112954d022aa7776f802f7b8697c0",
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
}

V5_FILES = {
    "contracts/COMPATIBILITY_REQUEST.json": "0fb6a4e032be3886e6163ffc8d14fcee16cd2c8b4d09b07f04216165c6185d2e",
    "contracts/EXECUTION_CONTRACT.json": "eea968d91646478bb3464e569ece850eb8b17d3b9b6114f7b9d8eef62bec0527",
    "contracts/EXPECTED_EXECUTION_PLAN.json": "a0e78a544ed370954d40f6c69706e70ab830a1379bfecb4916020ac2361a5600",
    "contracts/OPERATION_COUNTERS.json": "975682f914910fd5652416abfad81888a01d4ad3c112abb1a67bf23e5817595c",
    "contracts/SUITE_DEFINITION.json": "f1c2c68741b2ec4ced22034f663000cad34ef12da310dd22ec38e117df613280",
    "preflight.py": "6548a10b857f1374ed6ebe5af9455243fd8fc11203cb4bb9a537c5a9b66d0dcb",
    "results/prelock/fresh-preflight-run-0001.json": HASHES["v5_preflight"],
    "results/prelock/noncandidate-discovery-event-run-0001.json": HASHES["v5_discovery"],
    "results/prelock/prelock-terminal-record-run-0001.json": HASHES["v5_terminal"],
    "runtime-config-candidate/config.toml": HASHES["fresh_config_spec"],
    "src/__init__.py": "5b2ea2bb2e652caf482f94a87b8c210ef286703088a7df244851c22a73d551af",
    "src/compatibility_v5.py": "7c71eaf727f8424a5e88c66cc98b9403b7d0674fbcdc45130ff685a63228ea49",
    "src/runner_v5.py": "b4bc47771979fae490bb6a4e5f0af40e4e2baa29e4026129827fed0dae43db54",
}

OPERATION_KEYS = [
    "candidate_promotions", "capability_edges", "codex_cli_invocations",
    "compatibility_suite_executions", "credential_operations", "daybreak_invocations",
    "exploit_replays", "external_network_operations", "future_runtime_invocations",
    "parallel_operations", "runtime_invocations", "subagent_processes",
    "submission_operations", "target_operations", "worker_processes",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_root(rows: list[dict[str, Any]]) -> str:
    payload = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(payload.encode()).hexdigest()


def tree_root(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = [
        {"path": member.relative_to(path).as_posix(), "sha256": sha(member), "bytes": member.stat().st_size}
        for member in sorted(item for item in path.rglob("*") if item.is_file())
    ]
    return canonical_root(rows), rows


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def regular(path: Path) -> bool:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode)


def verify_predecessor_manifest() -> dict[str, Any]:
    manifest = load(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    for row in manifest["members"]:
        member = PRED / row["path"]
        if not regular(member) or sha(member) != row["sha256"] or member.stat().st_size != row["bytes"]:
            raise SystemExit(f"predecessor manifest mismatch: {member}")
    if canonical_root(manifest["members"]) != manifest["canonical_member_root_sha256"]:
        raise SystemExit("predecessor canonical member root mismatch")
    if load(PRED / "GOVERNANCE_LOCK.json")["canonical_artifact_root_sha256"] != HASHES["predecessor_root"]:
        raise SystemExit("predecessor canonical artifact root mismatch")
    return manifest


def main() -> None:
    expected_sources = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
    actual_sources = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual_sources != expected_sources or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual_sources)}")
    if V6.exists() or V6.is_symlink():
        raise SystemExit("successor V6 must not exist during governance adjudication")

    fixed = {
        PRED / "GOVERNANCE_LOCK.json": HASHES["predecessor_lock"],
        PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json": HASHES["predecessor_manifest"],
        V5 / "results/prelock/fresh-preflight-run-0001.json": HASHES["v5_preflight"],
        V5 / "results/prelock/noncandidate-discovery-event-run-0001.json": HASHES["v5_discovery"],
        V5 / "results/prelock/prelock-terminal-record-run-0001.json": HASHES["v5_terminal"],
        NEW_BINARY: HASHES["new_binary"], NEW_PACKAGE: HASHES["new_package"],
        ROUTER_MAP: HASHES["router_map"],
    }
    failed = [str(path) for path, digest in fixed.items() if not regular(path) or sha(path) != digest]
    if failed:
        raise SystemExit("canonical preflight digest failure: " + ", ".join(failed))
    verify_predecessor_manifest()

    v5_root, v5_rows = tree_root(V5)
    observed_v5 = {row["path"]: row["sha256"] for row in v5_rows}
    if v5_root != HASHES["v5_tree_root"] or observed_v5 != V5_FILES:
        raise SystemExit("V5 file set or tree root changed")
    if any(member.is_symlink() for member in V5.rglob("*")):
        raise SystemExit("V5 contains symlink")
    for forbidden in ("STATIC_EXECUTION_LOCK.json", "STATIC_EXECUTION_LOCK_VERIFICATION.json", "static-run-v1/ATTEMPT_MARKER.json", "static-run-v1/runtime-result-0001.json"):
        if (V5 / forbidden).exists() or (V5 / forbidden).is_symlink():
            raise SystemExit(f"forbidden V5 execution artifact exists: {forbidden}")

    preflight = load(V5 / "results/prelock/fresh-preflight-run-0001.json")
    discovery = load(V5 / "results/prelock/noncandidate-discovery-event-run-0001.json")
    terminal = load(V5 / "results/prelock/prelock-terminal-record-run-0001.json")
    if preflight["status"] != "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT":
        raise SystemExit("V5 preflight disposition changed")
    if set(preflight["failure_ids"]) != {"codex_binary", "codex_package", "codex_binary_executable", "no_out_of_identity_codex_invocation"}:
        raise SystemExit("V5 preflight failure set changed")
    if terminal["attempt_count"] != 0 or terminal["candidate_codex_invocation_count"] != 0:
        raise SystemExit("V5 candidate attempt/invocation changed")
    if discovery["noncandidate_codex_invocation_count"] != 1 or discovery["reported_version"] != "codex-cli 0.163.0":
        raise SystemExit("V5 noncandidate deviation changed")

    if OLD_BINARY.exists() or OLD_BINARY.is_symlink() or OLD_PACKAGE.exists() or OLD_PACKAGE.is_symlink():
        raise SystemExit("0.162.1 unexpectedly available; adjudication facts changed")
    package = load(NEW_PACKAGE)
    expected_package = {"layoutVersion": 1, "version": "0.163.0", "target": "x86_64-unknown-linux-musl", "variant": "codex", "entrypoint": "bin/codex", "resourcesDir": "codex-resources", "pathDir": "codex-path"}
    if package != expected_package or not os.access(NEW_BINARY, os.X_OK):
        raise SystemExit("0.163.0 filesystem/package identity mismatch")

    predecessor = load(PRED / "GOVERNANCE_LOCK.json")
    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0", "scope": "GOVERNANCE_ONLY_FROZEN_PRELOCK_EVIDENCE_ADJUDICATION",
        "authorized_actions": ["READ_FROZEN_V5_PRELOCK_EVIDENCE", "INSPECT_RUNTIME_FILESYSTEM_AND_PACKAGE_METADATA_WITHOUT_EXECUTION", "ADJUDICATE_OWNERSHIP", "SELECT_SUCCESSOR_RUNTIME_IDENTITY", "ISSUE_CONDITIONAL_SUCCESSOR_DECISION", "RUN_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE"],
        "forbidden_actions": ["PROVISION_RUNTIME", "CHANGE_DEFAULT_SYMLINK", "PATCH_OR_CONTINUE_V5", "ISSUE_V5_STATIC_LOCK", "INVOKE_CODEX_OR_ANY_MODEL_RUNTIME", "CREATE_OR_EXECUTE_V6", "WORKER_OR_SUBAGENT_EXECUTION", "CREDENTIAL_TARGET_OR_NETWORK_OPERATION", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION"],
        "target_or_runtime_execution_authority": False,
    })
    write("ROUTING_LEDGER.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_ROUTING_LEDGER", "schema_version": "1.0",
        "active": ["mandatory-auto-router", "authorized-security-autopilot", "codex-security-harness", "agentic-security-research-harness", "external-ai-security-tool-governor", "software-engineer-copilot"],
        "deferred": ["compatibility runtime execution", "worker/subagent execution", "credential/target/network access", "exploit replay", "parallel research", "capability graph"],
        "not_applicable": ["live vulnerability discovery", "program-impact finding adjudication", "prior-art vulnerability screening", "target-specific offensive validation"],
        "subagents_used": False, "codex_invoked_during_governance": False, "runtime_invoked_during_governance": False,
        "router_map_sha256": HASHES["router_map"],
    })
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_PREDECESSOR_CHAIN_BINDING", "schema_version": "1.0",
        "predecessor_governance_identity": predecessor["governance_identity"], "predecessor_status": predecessor["status"],
        "predecessor_decision": predecessor["decision"], "predecessor_lock_sha256": HASHES["predecessor_lock"],
        "predecessor_manifest_sha256": HASHES["predecessor_manifest"], "predecessor_canonical_artifact_root_sha256": HASHES["predecessor_root"],
        "authorized_v5_execution_identity": predecessor["v5_execution_identity"], "authorized_v5_suite_identity": predecessor["v5_suite_identity"],
    })
    write("V5_PRELOCK_EVIDENCE_BINDING.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_EVIDENCE_BINDING", "schema_version": "1.0",
        "v5_path": str(V5), "execution_identity": V5_EXECUTION, "suite_identity": V5_SUITE,
        "member_count": len(v5_rows), "canonical_tree_root_sha256": v5_root, "members": v5_rows,
        "fresh_preflight_sha256": HASHES["v5_preflight"], "noncandidate_discovery_event_sha256": HASHES["v5_discovery"],
        "prelock_terminal_record_sha256": HASHES["v5_terminal"], "integrity_at_adjudication": "PASS",
        "filesystem_read_only_claim": "NOT_MADE", "content_mutation_during_governance": "PROHIBITED",
    })
    write("V5_TERMINAL_DISPOSITION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "execution_identity": V5_EXECUTION, "suite_identity": V5_SUITE,
        "disposition": "FAIL_CLOSED_PRELOCK_TERMINAL_REFERENCE_PREDECESSOR",
        "preflight": "FAIL_CLOSED_BEFORE_STATIC_LOCK_AND_ATTEMPT", "static_lock": "NOT_ISSUED",
        "candidate_attempt": "0_OF_1_NOT_CONSUMED", "candidate_codex_0_162_1_invocation_count": 0,
        "noncandidate_codex_0_163_0_discovery_invocation_count": 1,
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN",
        "patch": "PROHIBITED", "continuation": "PROHIBITED", "relock": "PROHIBITED", "candidate_retry": "PROHIBITED",
    })
    write("RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION", "schema_version": "1.0",
        "expected_candidate": {"version": "0.162.1", "binary_path": str(OLD_BINARY), "expected_sha256": "628e35487d888a28f0427fc37501da529dd3d81fcbad7a2c3421c1e8670d92e1", "available": False},
        "candidate_0_162_1_incompatibility_proven": False,
        "available_noncandidate": {"version_from_package_metadata": package["version"], "target": package["target"], "binary_path": str(NEW_BINARY), "binary_sha256": HASHES["new_binary"], "package_path": str(NEW_PACKAGE), "package_sha256": HASHES["new_package"], "regular_executable": True, "compatibility": "NOT_ESTABLISHED"},
        "default_symlink_observation": {"path": str(DEFAULT_CODEX), "resolved_path": str(DEFAULT_CODEX.resolve(strict=False)), "authoritative_for_successor_execution": False},
        "verdict": "CODEX_0_162_1_EXPECTED_IDENTITY_AVAILABLE_NO_AND_CODEX_0_163_0_AVAILABLE_AS_UNTESTED_IDENTITY",
    })
    write("NONCANDIDATE_INVOCATION_DEVIATION_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_NONCANDIDATE_INVOCATION_DEVIATION_ADJUDICATION", "schema_version": "1.0",
        "observed_command": discovery["command"], "resolved_runtime": discovery["resolved_binary"], "reported_version": discovery["reported_version"],
        "count": 1, "classification": "NONCANDIDATE_DISCOVERY_INVOCATION_DEVIATION",
        "candidate_attempt_consumed": False, "candidate_invocation_count_incremented": False,
        "historical_evidence_must_remain": True, "erasure_or_reclassification": "PROHIBITED",
        "successor_lesson": "DISCOVERY_MUST_USE_NON_EXECUTING_FILESYSTEM_AND_PACKAGE_METADATA_BEFORE_ANY_RUNTIME_INVOCATION",
    })
    write("CAUSAL_OWNERSHIP_ADJUDICATION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_CAUSAL_OWNERSHIP_ADJUDICATION", "schema_version": "1.0",
        "runtime_provisioning_lifecycle_gap": "YES", "toolchain_identity_availability_drift": "YES", "discovery_probe_identity_guard_gap": "YES",
        "codex_0_162_1_compatibility_defect": "NOT_PROVEN", "codex_0_163_0_compatibility": "NOT_ESTABLISHED",
        "v5_parser_or_suite_defect": "NOT_ADJUDICATED_BY_THIS_FAILURE", "confinement_bypass": "NO_EVIDENCE_OF_BYPASS_BUT_CONFINEMENT_NOT_PROVEN",
        "ownership": ["RUNTIME_PROVISIONING_LIFECYCLE_CONTRACT", "RUNTIME_IDENTITY_AVAILABILITY_BINDING", "PRE_INVOCATION_DISCOVERY_GUARD"],
    })
    write("SUCCESSOR_RUNTIME_IDENTITY_SELECTION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_SUCCESSOR_RUNTIME_IDENTITY_SELECTION", "schema_version": "1.0",
        "options": [
            {"id": "A_REPROVISION_0_162_1", "decision": "NOT_SELECTED", "reason": "EXACT_IDENTITY_ABSENT_AND_GOVERNANCE_MILESTONE_DOES_NOT_AUTHORIZE_PROVISIONING"},
            {"id": "B_ADOPT_0_163_0_AS_FRESH_CANDIDATE", "decision": "SELECTED", "reason": "EXACT_FILESYSTEM_AND_PACKAGE_IDENTITY_AVAILABLE_FOR_FUTURE_FRESH_VALIDATION_WITHOUT_INFERRING_COMPATIBILITY"},
        ],
        "selected_runtime_identity": V6_RUNTIME, "compatibility": "NOT_ESTABLISHED", "availability": "IDENTITY_PINNED_FROM_NON_EXECUTING_METADATA",
        "selection_does_not_authorize_invocation": True,
    })
    write("IDENTITY_SAFE_DISCOVERY_CONTRACT.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_IDENTITY_SAFE_DISCOVERY_CONTRACT", "schema_version": "1.0",
        "required_order": ["INSPECT_EXACT_ABSOLUTE_PATH_WITHOUT_EXECUTION", "VERIFY_REGULAR_NON_SYMLINK_FILE", "VERIFY_BINARY_SHA256", "VERIFY_PACKAGE_METADATA_PATH_AND_SHA256", "VERIFY_DECLARED_VERSION_TARGET_VARIANT_ENTRYPOINT", "BIND_FRESH_CONFIG_PATH_AND_SHA256", "ONLY_AFTER_ALL_PRELOCK_GATES_MAY_ATTEMPT_MARKER_AND_RUNTIME_INVOCATION_EXIST"],
        "prohibited_discovery": ["PATH_LOOKUP", "DEFAULT_SYMLINK_AS_AUTHORITY", "CODEX_VERSION_INVOCATION_BEFORE_IDENTITY_PASS", "ANY_RUNTIME_INVOCATION_AS_AVAILABILITY_PROBE"],
        "failure_semantics": "STOP_WITH_ATTEMPT_0_AND_INVOCATION_0",
    })
    write("CONFIG_BINDING_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_CONFIG_BINDING_DECISION", "schema_version": "1.0",
        "successor_config_path": str(V6_CONFIG), "required_exact_content_utf8": "check_for_update_on_startup = false\n",
        "required_sha256": HASHES["fresh_config_spec"], "must_be_fresh_v6_artifact": True,
        "v5_config_may_be_reference_input": True, "v5_config_may_be_runtime_input": False,
        "global_config_mutation_authorized": False, "selected_and_consumed_proof_required": True,
    })
    requirements = [
        "FRESH_V6_EXECUTION_AND_SUITE_IDENTITIES", "CARRY_FORWARD_V1_THROUGH_V5_REGRESSIONS",
        "EXACT_0_163_0_ABSOLUTE_BINARY_PATH", "EXACT_0_163_0_BINARY_SHA256", "EXACT_0_163_0_PACKAGE_METADATA_AND_SHA256",
        "NO_PATH_OR_DEFAULT_SYMLINK_RUNTIME_SELECTION", "IDENTITY_SAFE_NON_EXECUTING_DISCOVERY", "FRESH_V6_DEDICATED_CONFIG_BINDING",
        "CONFIG_EXISTS_SELECTED_AND_CONSUMED_PROOF", "SYSCALL_FAMILY_DISPATCH_BEFORE_RETURN_PARSE",
        "EXPLICIT_NON_NUMERIC_EXIT_RETURN_GRAMMAR", "TYPED_EXIT_AND_EXIT_GROUP_EVENTS", "SEMANTIC_EXECVE_LINEAGE_CLASSIFICATION",
        "NAMESPACE_SETUP_WRITE_PROOF", "SEMANTIC_SYSCALL_PATH_CLASSIFICATION", "NO_FREE_TEXT_OR_REGEX_PATH_INFERENCE",
        "DIAGNOSTIC_COMPLETE_RUNTIME_RESULT", "PRIMARY_AND_INDEPENDENT_STATIC_VALIDATION", "FRESH_PREFLIGHT",
        "STATIC_LOCK_BEFORE_ATTEMPT", "EXACTLY_ONE_V6_ATTEMPT_AND_0_163_0_INVOCATION", "INDEPENDENT_POST_VALIDATION",
        "EVIDENCE_FREEZE", "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    write("SUCCESSOR_V6_REQUIREMENTS.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_SUCCESSOR_V6_REQUIREMENTS", "schema_version": "1.0",
        "successor_execution_identity": V6_EXECUTION, "successor_suite_identity": V6_SUITE, "successor_runtime_identity": V6_RUNTIME,
        "mandatory_requirements": requirements,
        "runtime_binding": {"binary_path": str(NEW_BINARY), "binary_sha256": HASHES["new_binary"], "package_path": str(NEW_PACKAGE), "package_sha256": HASHES["new_package"], "config_path": str(V6_CONFIG), "config_sha256": HASHES["fresh_config_spec"]},
        "pre_attempt_failure_semantics": "STOP_ATTEMPT_REMAINS_0_INVOCATION_REMAINS_0",
    })
    write("SUCCESSOR_V6_AUTHORIZATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_SUCCESSOR_V6_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V6_WITH_CODEX_0_163_0_CONDITIONALLY",
        "state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED", "successor_execution_identity": V6_EXECUTION,
        "successor_suite_identity": V6_SUITE, "successor_runtime_identity": V6_RUNTIME, "successor_path": str(V6),
        "attempt_count": 0, "attempt_limit": 1, "codex_0_163_0_invocation_count": 0, "codex_0_163_0_invocation_limit": 1,
        "creation_or_execution_this_milestone": False, "separate_acceptance_required": True,
        "authority_ceiling": "COMPATIBILITY_VALIDATION_ONLY_NO_WORKER_CREDENTIAL_TARGET_NETWORK_OR_OFFENSIVE_AUTHORITY",
    })
    zeros = {key: 0 for key in OPERATION_KEYS}
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "governance_operation_counters": zeros, "historical_v5_noncandidate_invocation_count": 1,
        "worker_execution_authorized": False, "subagent_execution_authorized": False, "credential_use_authorized": False,
        "target_access_authorized": False, "external_network_authorized": False, "daybreak_invocation_authorized": False,
        "exploit_replay_authorized": False, "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "current_milestone": {"read_frozen_evidence": True, "read_runtime_metadata_without_execution": True, "governance_writes": True, "governance_validation": True, "governance_freeze": True},
        "current_milestone_forbidden": ["runtime_provisioning", "symlink_change", "V5_static_lock", "V5_continuation", "Codex_invocation", "V6_creation_or_execution", "worker", "subagent", "credential", "target", "network", "Daybreak", "exploit", "parallelism", "capability_graph", "promotion", "submission"],
        "future_v6_conditional_only": ["create_fresh_V6_source_tests_and_config", "static_validate_and_lock_V6", "one_identity_bound_0_163_0_compatibility_invocation_if_all_gates_pass"],
    })
    negative_cases = [
        ("N001", "CLAIM_0_162_1_AVAILABLE", "REJECT"), ("N002", "CLAIM_0_162_1_INCOMPATIBLE", "REJECT"),
        ("N003", "ERASE_0_163_0_DEVIATION", "REJECT"), ("N004", "COUNT_DEVIATION_AS_CANDIDATE_ATTEMPT", "REJECT"),
        ("N005", "CONTINUE_V5_IDENTITY", "REJECT"), ("N006", "ISSUE_V5_STATIC_LOCK", "REJECT"),
        ("N007", "PROVISION_0_162_1_DURING_GOVERNANCE", "REJECT"), ("N008", "ADOPT_0_163_0_WITHOUT_NEW_IDENTITY", "REJECT"),
        ("N009", "USE_PATH_LOOKUP", "REJECT"), ("N010", "USE_DEFAULT_SYMLINK_AS_AUTHORITY", "REJECT"),
        ("N011", "OMIT_0_163_0_BINARY_DIGEST", "REJECT"), ("N012", "OMIT_0_163_0_PACKAGE_DIGEST", "REJECT"),
        ("N013", "REUSE_V5_CONFIG_AS_RUNTIME_INPUT", "REJECT"), ("N014", "OMIT_FRESH_CONFIG_BINDING", "REJECT"),
        ("N015", "DISCOVER_WITH_CODEX_VERSION_INVOCATION", "REJECT"), ("N016", "INFER_COMPATIBILITY_FROM_AVAILABILITY", "REJECT"),
        ("N017", "ALLOW_MORE_THAN_ONE_SUCCESSOR_ATTEMPT", "REJECT"), ("N018", "ALLOW_RETRY", "REJECT"),
        ("N019", "AUTHORIZE_WORKER_OR_TARGET", "REJECT"), ("N020", "AUTHORIZE_EXTERNAL_NETWORK", "REJECT"),
        ("N021", "CREATE_V6_DURING_GOVERNANCE", "REJECT"), ("N022", "MUTATE_DEFAULT_SYMLINK", "REJECT"),
        ("N023", "PROMOTE_RUNTIME_PASS_LOCKED_NOW", "REJECT"), ("N024", "OMIT_SEPARATE_ACCEPTANCE", "REJECT"),
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_NEGATIVE_TEST_MATRIX", "schema_version": "1.0",
        "cases": [{"test_id": test_id, "mutation": mutation, "expected": expected} for test_id, mutation, expected in negative_cases],
        "test_count": len(negative_cases),
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "v5_disposition": "FAIL_CLOSED_PRELOCK_TERMINAL_REFERENCE_PREDECESSOR",
        "code_0_162_1_available": False, "code_0_162_1_incompatibility_proven": False,
        "noncandidate_0_163_0_discovery_invocation_count": 1,
        "ownership_defects": ["RUNTIME_PROVISIONING_LIFECYCLE_GAP", "TOOLCHAIN_IDENTITY_AVAILABILITY_DRIFT", "DISCOVERY_PROBE_IDENTITY_GUARD_GAP"],
        "selected_successor_option": "B_ADOPT_0_163_0_AS_FRESH_CANDIDATE",
        "successor_decision": "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V6_WITH_CODEX_0_163_0_CONDITIONALLY",
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN", "pass_locked_governance_pending_validation_and_freeze": True,
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_if_pass_locked": "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6_WITH_CODEX_0_163_0_ONCE_IF_ALL_GATES_PASS",
        "successor_creation_or_execution_now": False, "runtime_provisioning_now": False,
        "compatibility_execution_requires_fresh_identity_bound_preflight": True,
    })
    print(json.dumps({"status": "GOVERNANCE_SOURCE_BUILT_AWAITING_VALIDATION", "identity": IDENTITY, "selected_successor_runtime": V6_RUNTIME}, sort_keys=True))


if __name__ == "__main__":
    main()
