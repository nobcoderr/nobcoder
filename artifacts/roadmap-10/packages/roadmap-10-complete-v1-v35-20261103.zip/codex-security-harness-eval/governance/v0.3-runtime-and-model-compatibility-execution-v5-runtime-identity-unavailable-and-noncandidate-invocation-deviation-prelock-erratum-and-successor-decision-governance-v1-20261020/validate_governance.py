#!/usr/bin/env python3
"""Primary and negative-fixture validation for the V5 pre-lock erratum."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import stat
from copy import deepcopy
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v4-non-numeric-strace-exit-return-grammar-and-missing-runtime-result-post-validation-failure-erratum-and-successor-decision-governance-v1-20261020")
V5 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
OLD_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.162.1-x86_64-unknown-linux-musl/bin/codex")
OLD_PACKAGE = OLD_BINARY.parent.parent / "codex-package.json"
NEW_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl/bin/codex")
NEW_PACKAGE = NEW_BINARY.parent.parent / "codex-package.json"

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5_RUNTIME_IDENTITY_UNAVAILABLE_AND_NONCANDIDATE_INVOCATION_DEVIATION_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V6_EXECUTION = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6"
V6_SUITE = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_SUITE_V7"
V6_RUNTIME = "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL"
NEW_BINARY_SHA = "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215"
NEW_PACKAGE_SHA = "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78"
CONFIG_SHA = "7ae835188ef2ab3221e15effac45375b2d6112954d022aa7776f802f7b8697c0"
V5_ROOT = "f8bd58de48721da7099c4430998f6cacd7351cff43ffb8c99d85c3744aa6d74b"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V5_PRELOCK_EVIDENCE_BINDING.json", "V5_TERMINAL_DISPOSITION.json",
    "RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION.json", "NONCANDIDATE_INVOCATION_DEVIATION_ADJUDICATION.json",
    "CAUSAL_OWNERSHIP_ADJUDICATION.json", "SUCCESSOR_RUNTIME_IDENTITY_SELECTION.json",
    "IDENTITY_SAFE_DISCOVERY_CONTRACT.json", "CONFIG_BINDING_DECISION.json",
    "SUCCESSOR_V6_REQUIREMENTS.json", "SUCCESSOR_V6_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def regular(path: Path) -> bool:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISREG(info.st_mode) and not stat.S_ISLNK(info.st_mode)


def tree_root(path: Path) -> str:
    rows = []
    for member in sorted(item for item in path.rglob("*") if item.is_file()):
        rows.append(f"{sha(member)}  {member.relative_to(path).as_posix()}\n")
    return hashlib.sha256("".join(rows).encode()).hexdigest()


def canonical_policy() -> dict[str, Any]:
    return {
        "old_available": False, "old_incompatible": False, "deviation_count": 1,
        "deviation_preserved": True, "candidate_attempt_count": 0,
        "v5_terminal": True, "v5_continuation": False, "v5_static_lock": False,
        "provision_during_governance": False, "execution_identity": V6_EXECUTION,
        "suite_identity": V6_SUITE, "runtime_identity": V6_RUNTIME,
        "binary_path": str(NEW_BINARY), "binary_sha": NEW_BINARY_SHA,
        "package_path": str(NEW_PACKAGE), "package_sha": NEW_PACKAGE_SHA,
        "config_path": str(V6 / "runtime-config-candidate/config.toml"), "config_sha": CONFIG_SHA,
        "reuse_v5_config": False, "discovery_mode": "FILESYSTEM_PACKAGE_METADATA_ONLY",
        "path_lookup": False, "default_symlink_authoritative": False,
        "compatibility": "NOT_ESTABLISHED", "attempt_limit": 1, "retry": False,
        "worker_or_target": False, "external_network": False, "create_v6_now": False,
        "mutate_symlink": False, "runtime_pass_locked": False, "separate_acceptance": True,
    }


def policy_accepts(value: dict[str, Any]) -> bool:
    expected = canonical_policy()
    return value == expected


def mutated_cases() -> dict[str, dict[str, Any]]:
    changes = {
        "N001": ("old_available", True), "N002": ("old_incompatible", True),
        "N003": ("deviation_preserved", False), "N004": ("candidate_attempt_count", 1),
        "N005": ("v5_continuation", True), "N006": ("v5_static_lock", True),
        "N007": ("provision_during_governance", True), "N008": ("execution_identity", "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5"),
        "N009": ("path_lookup", True), "N010": ("default_symlink_authoritative", True),
        "N011": ("binary_sha", None), "N012": ("package_sha", None),
        "N013": ("reuse_v5_config", True), "N014": ("config_sha", None),
        "N015": ("discovery_mode", "CODEX_VERSION_INVOCATION"), "N016": ("compatibility", "PASS_LOCKED"),
        "N017": ("attempt_limit", 2), "N018": ("retry", True),
        "N019": ("worker_or_target", True), "N020": ("external_network", True),
        "N021": ("create_v6_now", True), "N022": ("mutate_symlink", True),
        "N023": ("runtime_pass_locked", True), "N024": ("separate_acceptance", False),
    }
    output: dict[str, dict[str, Any]] = {}
    for test_id, (key, mutation) in changes.items():
        value = deepcopy(canonical_policy())
        value[key] = mutation
        output[test_id] = value
    return output


def main() -> None:
    expected = SCRIPTS | BASE
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"validation file-set mismatch: actual={sorted(actual)}")

    checks: list[dict[str, Any]] = []
    def check(check_id: str, passed: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if passed else "FAIL", "evidence": evidence})

    check("P001_FILE_SET", actual == expected, {"expected": len(expected), "actual": len(actual)})
    check("P002_V6_ABSENT", not V6.exists() and not V6.is_symlink())
    check("P003_OLD_BINARY_ABSENT", not OLD_BINARY.exists() and not OLD_BINARY.is_symlink())
    check("P004_OLD_PACKAGE_ABSENT", not OLD_PACKAGE.exists() and not OLD_PACKAGE.is_symlink())
    check("P005_NEW_BINARY_REGULAR", regular(NEW_BINARY))
    check("P006_NEW_BINARY_EXECUTABLE", regular(NEW_BINARY) and os.access(NEW_BINARY, os.X_OK))
    check("P007_NEW_BINARY_SHA", regular(NEW_BINARY) and sha(NEW_BINARY) == NEW_BINARY_SHA)
    check("P008_NEW_PACKAGE_REGULAR", regular(NEW_PACKAGE))
    check("P009_NEW_PACKAGE_SHA", regular(NEW_PACKAGE) and sha(NEW_PACKAGE) == NEW_PACKAGE_SHA)
    package = json.loads(NEW_PACKAGE.read_text()) if regular(NEW_PACKAGE) else {}
    check("P010_NEW_PACKAGE_VERSION", package.get("version") == "0.163.0")
    check("P011_NEW_PACKAGE_TARGET", package.get("target") == "x86_64-unknown-linux-musl")
    check("P012_NEW_PACKAGE_VARIANT", package.get("variant") == "codex")
    check("P013_NEW_PACKAGE_ENTRYPOINT", package.get("entrypoint") == "bin/codex")
    check("P014_V5_TREE_ROOT", tree_root(V5) == V5_ROOT, tree_root(V5))
    for forbidden in ("STATIC_EXECUTION_LOCK.json", "STATIC_EXECUTION_LOCK_VERIFICATION.json", "static-run-v1/ATTEMPT_MARKER.json", "static-run-v1/runtime-result-0001.json"):
        check("P_V5_ABSENT_" + forbidden.replace("/", "_").replace(".", "_"), not (V5 / forbidden).exists() and not (V5 / forbidden).is_symlink())
    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            syntax = True
        except (SyntaxError, UnicodeDecodeError):
            syntax = False
        check("P_SYNTAX_" + script, syntax)
    loaded: dict[str, dict[str, Any]] = {}
    for name in sorted(BASE):
        try:
            payload = load(name)
            loaded[name] = payload
            valid_json = payload.get("governance_identity") == IDENTITY
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            valid_json = False
        check("P_JSON_" + name, valid_json)

    terminal = loaded.get("V5_TERMINAL_DISPOSITION.json", {})
    availability = loaded.get("RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION.json", {})
    deviation = loaded.get("NONCANDIDATE_INVOCATION_DEVIATION_ADJUDICATION.json", {})
    ownership = loaded.get("CAUSAL_OWNERSHIP_ADJUDICATION.json", {})
    selection = loaded.get("SUCCESSOR_RUNTIME_IDENTITY_SELECTION.json", {})
    discovery = loaded.get("IDENTITY_SAFE_DISCOVERY_CONTRACT.json", {})
    config = loaded.get("CONFIG_BINDING_DECISION.json", {})
    successor = loaded.get("SUCCESSOR_V6_AUTHORIZATION_DECISION.json", {})
    requirements = loaded.get("SUCCESSOR_V6_REQUIREMENTS.json", {})
    authority = loaded.get("AUTHORITY_NON_ESCALATION_DECISION.json", {})
    summary = loaded.get("GOVERNANCE_DECISION_SUMMARY.json", {})
    next_step = loaded.get("NEXT_LEGAL_MILESTONE.json", {})

    check("P040_V5_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_PRELOCK_TERMINAL_REFERENCE_PREDECESSOR")
    check("P041_V5_NO_LOCK", terminal.get("static_lock") == "NOT_ISSUED")
    check("P042_V5_ATTEMPT_ZERO", terminal.get("candidate_attempt") == "0_OF_1_NOT_CONSUMED")
    check("P043_V5_CANDIDATE_INVOCATION_ZERO", terminal.get("candidate_codex_0_162_1_invocation_count") == 0)
    check("P044_V5_NONCANDIDATE_INVOCATION_ONE", terminal.get("noncandidate_codex_0_163_0_discovery_invocation_count") == 1)
    check("P045_NO_COMPATIBILITY_PROMOTION", terminal.get("compatibility") == "NOT_ESTABLISHED")
    check("P046_NO_CONFINEMENT_PROMOTION", terminal.get("confinement") == "NOT_PROVEN")
    check("P047_OLD_UNAVAILABLE", availability.get("expected_candidate", {}).get("available") is False)
    check("P048_OLD_INCOMPAT_NOT_PROVEN", availability.get("candidate_0_162_1_incompatibility_proven") is False)
    check("P049_NEW_AVAILABLE_UNTESTED", availability.get("available_noncandidate", {}).get("compatibility") == "NOT_ESTABLISHED")
    check("P050_DEVIATION_CLASS", deviation.get("classification") == "NONCANDIDATE_DISCOVERY_INVOCATION_DEVIATION")
    check("P051_DEVIATION_PRESERVED", deviation.get("historical_evidence_must_remain") is True)
    check("P052_DEVIATION_NOT_ATTEMPT", deviation.get("candidate_attempt_consumed") is False)
    check("P053_PROVISIONING_GAP", ownership.get("runtime_provisioning_lifecycle_gap") == "YES")
    check("P054_AVAILABILITY_DRIFT", ownership.get("toolchain_identity_availability_drift") == "YES")
    check("P055_DISCOVERY_GUARD_GAP", ownership.get("discovery_probe_identity_guard_gap") == "YES")
    check("P056_SELECT_0163", selection.get("selected_runtime_identity") == V6_RUNTIME)
    check("P057_SELECTION_NO_INVOCATION", selection.get("selection_does_not_authorize_invocation") is True)
    check("P058_METADATA_DISCOVERY_FIRST", discovery.get("required_order", [None])[0] == "INSPECT_EXACT_ABSOLUTE_PATH_WITHOUT_EXECUTION")
    check("P059_PATH_PROHIBITED", "PATH_LOOKUP" in discovery.get("prohibited_discovery", []))
    check("P060_VERSION_INVOCATION_PROHIBITED", "CODEX_VERSION_INVOCATION_BEFORE_IDENTITY_PASS" in discovery.get("prohibited_discovery", []))
    check("P061_FRESH_CONFIG", config.get("must_be_fresh_v6_artifact") is True)
    check("P062_CONFIG_PATH", config.get("successor_config_path") == str(V6 / "runtime-config-candidate/config.toml"))
    check("P063_CONFIG_SHA", config.get("required_sha256") == CONFIG_SHA)
    check("P064_GLOBAL_CONFIG_MUTATION_DENIED", config.get("global_config_mutation_authorized") is False)
    check("P065_SUCCESSOR_DECISION", successor.get("decision") == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V6_WITH_CODEX_0_163_0_CONDITIONALLY")
    check("P066_SUCCESSOR_EXECUTION", successor.get("successor_execution_identity") == V6_EXECUTION)
    check("P067_SUCCESSOR_SUITE", successor.get("successor_suite_identity") == V6_SUITE)
    check("P068_SUCCESSOR_RUNTIME", successor.get("successor_runtime_identity") == V6_RUNTIME)
    check("P069_ONE_ATTEMPT", successor.get("attempt_count") == 0 and successor.get("attempt_limit") == 1)
    check("P070_ONE_INVOCATION", successor.get("codex_0_163_0_invocation_count") == 0 and successor.get("codex_0_163_0_invocation_limit") == 1)
    check("P071_NO_CREATE_EXECUTE_NOW", successor.get("creation_or_execution_this_milestone") is False)
    runtime_binding = requirements.get("runtime_binding", {})
    check("P072_BIND_BINARY_PATH", runtime_binding.get("binary_path") == str(NEW_BINARY))
    check("P073_BIND_BINARY_SHA", runtime_binding.get("binary_sha256") == NEW_BINARY_SHA)
    check("P074_BIND_PACKAGE_SHA", runtime_binding.get("package_sha256") == NEW_PACKAGE_SHA)
    check("P075_BIND_CONFIG_SHA", runtime_binding.get("config_sha256") == CONFIG_SHA)
    check("P076_PREATTEMPT_STOP", requirements.get("pre_attempt_failure_semantics") == "STOP_ATTEMPT_REMAINS_0_INVOCATION_REMAINS_0")
    counters = authority.get("governance_operation_counters", {})
    check("P077_GOVERNANCE_COUNTERS_ZERO", len(counters) == 15 and all(value == 0 for value in counters.values()))
    check("P078_HISTORICAL_DEVIATION_SEPARATE", authority.get("historical_v5_noncandidate_invocation_count") == 1)
    denied = [key for key, value in authority.items() if key.endswith("_authorized") and value is not False]
    check("P079_NO_AUTHORITY_ESCALATION", not denied, denied)
    check("P080_SUMMARY_SELECTION", summary.get("selected_successor_option") == "B_ADOPT_0_163_0_AS_FRESH_CANDIDATE")
    check("P081_NEXT_MILESTONE", next_step.get("next_if_pass_locked") == "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V6_WITH_CODEX_0_163_0_ONCE_IF_ALL_GATES_PASS")
    check("P082_PREDECESSOR_LOCK", sha(PRED / "GOVERNANCE_LOCK.json") == "cb389d375597d5d564c7ecb29936a930ef99c106215014017ee1b8c48be9104d")
    check("P083_CANONICAL_POLICY_ACCEPTS", policy_accepts(canonical_policy()))

    failed = [row for row in checks if row["status"] == "FAIL"]
    write("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_GOVERNANCE_VALIDATION_RESULT",
        "schema_version": "1.0", "run_id": "GOVERNANCE_VALIDATION_RUN-0001",
        "status": "PASS" if not failed else "FAIL_CLOSED", "checks": checks,
        "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": {key: 0 for key in authority.get("governance_operation_counters", {})},
    })

    matrix = loaded.get("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {})
    matrix_cases = {row["test_id"]: row for row in matrix.get("cases", [])}
    results = []
    for test_id, value in sorted(mutated_cases().items()):
        rejected = not policy_accepts(value)
        expected_reject = matrix_cases.get(test_id, {}).get("expected") == "REJECT"
        results.append({"test_id": test_id, "expected": "REJECT", "observed": "REJECT" if rejected else "ACCEPT", "status": "PASS" if rejected and expected_reject else "FAIL"})
    negative_failed = [row for row in results if row["status"] == "FAIL"]
    write("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_NEGATIVE_TEST_RESULT",
        "schema_version": "1.0", "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if not negative_failed and len(results) == 24 else "FAIL_CLOSED",
        "tests": results, "tests_total": len(results), "tests_passed": len(results) - len(negative_failed), "tests_failed": len(negative_failed),
        "positive_control": {"canonical_policy_accepted": policy_accepts(canonical_policy())},
        "operation_counters": {key: 0 for key in authority.get("governance_operation_counters", {})},
    })
    print(json.dumps({"primary": {"status": "PASS" if not failed else "FAIL_CLOSED", "passed": len(checks)-len(failed), "total": len(checks)}, "negative": {"status": "PASS" if not negative_failed and len(results)==24 else "FAIL_CLOSED", "passed": len(results)-len(negative_failed), "total": len(results)}}, sort_keys=True))
    if failed or negative_failed or len(results) != 24:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
