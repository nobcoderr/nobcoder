#!/usr/bin/env python3
"""Freeze the V5 pre-lock erratum only after all governance gates pass."""

from __future__ import annotations

import ast
import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
PRED = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v4-non-numeric-strace-exit-return-grammar-and-missing-runtime-result-post-validation-failure-erratum-and-successor-decision-governance-v1-20261020")
V5 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v5-20261020")
V6 = Path("/home/nobcoder/v0.3-runtime-and-model-compatibility-execution-v6-20261020")
OLD = Path("/home/nobcoder/.codex/packages/standalone/releases/0.162.1-x86_64-unknown-linux-musl")
NEW_BINARY = Path("/home/nobcoder/.codex/packages/standalone/releases/0.163.0-x86_64-unknown-linux-musl/bin/codex")
NEW_PACKAGE = NEW_BINARY.parent.parent / "codex-package.json"

IDENTITY = "V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V5_RUNTIME_IDENTITY_UNAVAILABLE_AND_NONCANDIDATE_INVOCATION_DEVIATION_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V5_ROOT = "f8bd58de48721da7099c4430998f6cacd7351cff43ffb8c99d85c3744aa6d74b"
NEW_BINARY_SHA = "399ff69c431c066e40de318fba45c2b07f45a76b19939d247ee4828fc70c4215"
NEW_PACKAGE_SHA = "5fa8533bde21972564cbb2c665c99c6d6d0e92b625fa6f4fdf1354ac5fb71a78"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V5_PRELOCK_EVIDENCE_BINDING.json", "V5_TERMINAL_DISPOSITION.json",
    "RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION.json", "NONCANDIDATE_INVOCATION_DEVIATION_ADJUDICATION.json",
    "CAUSAL_OWNERSHIP_ADJUDICATION.json", "SUCCESSOR_RUNTIME_IDENTITY_SELECTION.json",
    "IDENTITY_SAFE_DISCOVERY_CONTRACT.json", "CONFIG_BINDING_DECISION.json",
    "SUCCESSOR_V6_REQUIREMENTS.json", "SUCCESSOR_V6_AUTHORIZATION_DECISION.json",
    "AUTHORITY_NON_ESCALATION_DECISION.json", "OPERATION_AUTHORIZATION_MATRIX.json",
    "NEGATIVE_GOVERNANCE_TEST_MATRIX.json", "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {"GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json"}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def regular(path: Path) -> bool:
    try:
        item = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISREG(item.st_mode) and not stat.S_ISLNK(item.st_mode)


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def tree_root(path: Path) -> str:
    data = "".join(f"{sha(member)}  {member.relative_to(path).as_posix()}\n" for member in sorted(candidate for candidate in path.rglob("*") if candidate.is_file()))
    return hashlib.sha256(data.encode()).hexdigest()


def canonical_root(rows: list[dict[str, Any]]) -> str:
    data = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda item: item["path"]))
    return hashlib.sha256(data.encode()).hexdigest()


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_symlink() or path.is_dir() for path in ROOT.iterdir()):
        raise SystemExit(f"finalize file-set mismatch: actual={len(actual)} expected={len(expected)}")

    primary = load("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    negative = load("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = load("INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    terminal = load("V5_TERMINAL_DISPOSITION.json")
    availability = load("RUNTIME_IDENTITY_AVAILABILITY_ADJUDICATION.json")
    deviation = load("NONCANDIDATE_INVOCATION_DEVIATION_ADJUDICATION.json")
    ownership = load("CAUSAL_OWNERSHIP_ADJUDICATION.json")
    selection = load("SUCCESSOR_RUNTIME_IDENTITY_SELECTION.json")
    successor = load("SUCCESSOR_V6_AUTHORIZATION_DECISION.json")
    requirements = load("SUCCESSOR_V6_REQUIREMENTS.json")
    authority = load("AUTHORITY_NON_ESCALATION_DECISION.json")

    checks: list[dict[str, Any]] = []
    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("F001_PRIMARY", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("F002_NEGATIVE", negative.get("status") == "PASS" and negative.get("tests_failed") == 0 and negative.get("tests_total") == 24)
    check("F003_INDEPENDENT", independent.get("status") == "PASS" and independent.get("checks_failed") == 0)
    check("F004_V5_ROOT", tree_root(V5) == V5_ROOT, tree_root(V5))
    check("F005_V6_ABSENT", not V6.exists() and not V6.is_symlink())
    check("F006_OLD_RUNTIME_ABSENT", not OLD.exists() and not OLD.is_symlink())
    check("F007_NEW_BINARY", regular(NEW_BINARY) and sha(NEW_BINARY) == NEW_BINARY_SHA and os.access(NEW_BINARY, os.X_OK))
    check("F008_NEW_PACKAGE", regular(NEW_PACKAGE) and sha(NEW_PACKAGE) == NEW_PACKAGE_SHA)
    check("F009_PREDECESSOR_LOCK", sha(PRED / "GOVERNANCE_LOCK.json") == "cb389d375597d5d564c7ecb29936a930ef99c106215014017ee1b8c48be9104d")
    check("F010_PREDECESSOR_MANIFEST", sha(PRED / "GOVERNANCE_ARTIFACT_MANIFEST.json") == "ad52ef6930899b56acc0705be4476f90a8e9d1b2e99d83cf13c49cbe645f4f09")
    for name in ["STATIC_EXECUTION_LOCK.json", "STATIC_EXECUTION_LOCK_VERIFICATION.json", "static-run-v1/ATTEMPT_MARKER.json", "static-run-v1/runtime-result-0001.json"]:
        check("F_V5_ABSENT_" + name.replace("/", "_").replace(".", "_"), not (V5 / name).exists() and not (V5 / name).is_symlink())
    check("F015_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_PRELOCK_TERMINAL_REFERENCE_PREDECESSOR")
    check("F016_ATTEMPT_ZERO", terminal.get("candidate_attempt") == "0_OF_1_NOT_CONSUMED")
    check("F017_CANDIDATE_INVOCATION_ZERO", terminal.get("candidate_codex_0_162_1_invocation_count") == 0)
    check("F018_NONCANDIDATE_ONE", deviation.get("count") == 1 and terminal.get("noncandidate_codex_0_163_0_discovery_invocation_count") == 1)
    check("F019_OLD_UNAVAILABLE", availability.get("expected_candidate", {}).get("available") is False)
    check("F020_OLD_INCOMPAT_NOT_PROVEN", availability.get("candidate_0_162_1_incompatibility_proven") is False)
    check("F021_OWNERSHIP", [ownership.get("runtime_provisioning_lifecycle_gap"), ownership.get("toolchain_identity_availability_drift"), ownership.get("discovery_probe_identity_guard_gap")] == ["YES", "YES", "YES"])
    check("F022_SELECTION", selection.get("selected_runtime_identity") == "CODEX_RUNTIME_V2_CANDIDATE_0_163_0_LINUX_X86_64_MUSL")
    check("F023_SUCCESSOR", successor.get("decision") == "AUTHORIZE_DISTINCT_COMPATIBILITY_EXECUTION_V6_WITH_CODEX_0_163_0_CONDITIONALLY")
    check("F024_ONE_SHOT", successor.get("attempt_count") == 0 and successor.get("attempt_limit") == 1 and successor.get("codex_0_163_0_invocation_count") == 0 and successor.get("codex_0_163_0_invocation_limit") == 1)
    check("F025_FRESH_CONFIG", requirements.get("runtime_binding", {}).get("config_path") == str(V6 / "runtime-config-candidate/config.toml"))
    check("F026_NO_CURRENT_OPERATIONS", len(authority.get("governance_operation_counters", {})) == 15 and all(value == 0 for value in authority.get("governance_operation_counters", {}).values()))
    check("F027_NO_AUTHORITY_ESCALATION", not any(value for key, value in authority.items() if key.endswith("_authorized")))
    check("F028_NOT_COMPATIBLE", terminal.get("compatibility") == "NOT_ESTABLISHED")
    check("F029_NOT_CONFINED", terminal.get("confinement") == "NOT_PROVEN")
    check("F030_NO_SYMLINKS", not any(path.is_symlink() for path in ROOT.iterdir()))
    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SYNTAX_" + script, valid)
    check("F035_IDENTITY", all(load(name).get("governance_identity") == IDENTITY for name in BASE | RESULTS))

    failures = [row for row in checks if row["status"] == "FAIL"]
    if failures:
        raise SystemExit("final freeze verification failed: " + ", ".join(row["check_id"] for row in failures))
    freeze = {
        "governance_identity": IDENTITY,
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT",
        "schema_version": "1.0", "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001", "phase": "FINAL_FREEZE_CANDIDATE",
        "status": "PASS", "checks": checks, "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "operation_counters": authority["governance_operation_counters"],
        "historical_v5_noncandidate_invocation_count": 1,
    }
    with (ROOT / FREEZE).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(freeze, handle, indent=2, sort_keys=True); handle.write("\n")

    member_files = sorted((ROOT / name for name in expected | {FREEZE}), key=lambda path: path.name)
    members = [{"path": path.name, "sha256": sha(path), "bytes": path.stat().st_size} for path in member_files]
    member_root = canonical_root(members)
    manifest = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "canonical_serialization": "UTF8_SORTED_PATH_SHA256_DOUBLE_SPACE_NEWLINE",
        "canonical_member_root_sha256": member_root, "member_count": len(members), "members": members,
        "self_referential_hashes": False,
    }
    with (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True); handle.write("\n")
    manifest_sha = sha(ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json")
    artifact_root = canonical_root(members + [{"path": "GOVERNANCE_ARTIFACT_MANIFEST.json", "sha256": manifest_sha, "bytes": (ROOT / "GOVERNANCE_ARTIFACT_MANIFEST.json").stat().st_size}])
    lock = {
        "record_type": "V0_3_COMPATIBILITY_EXECUTION_V5_PRELOCK_ERRATUM_GOVERNANCE_LOCK",
        "schema_version": "1.0", "governance_identity": IDENTITY,
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": successor["decision"],
        "v5_disposition": terminal["disposition"], "v5_static_lock": terminal["static_lock"],
        "v5_candidate_attempt": terminal["candidate_attempt"], "v5_candidate_codex_0_162_1_invocation_count": 0,
        "v5_noncandidate_codex_0_163_0_discovery_invocation_count": 1,
        "codex_0_162_1_available": False, "codex_0_162_1_incompatibility_proven": False,
        "ownership_defects": ["RUNTIME_PROVISIONING_LIFECYCLE_GAP", "TOOLCHAIN_IDENTITY_AVAILABILITY_DRIFT", "DISCOVERY_PROBE_IDENTITY_GUARD_GAP"],
        "selected_successor_option": "B_ADOPT_0_163_0_AS_FRESH_CANDIDATE",
        "v6_execution_identity": successor["successor_execution_identity"], "v6_suite_identity": successor["successor_suite_identity"],
        "v6_runtime_identity": successor["successor_runtime_identity"], "v6_path": successor["successor_path"],
        "v6_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_AT_FREEZE", "v6_attempt_count": 0, "v6_attempt_limit": 1,
        "v6_codex_0_163_0_invocation_count": 0, "v6_codex_0_163_0_invocation_limit": 1,
        "v6_runtime_binding": requirements["runtime_binding"], "v6_mandatory_requirements": requirements["mandatory_requirements"],
        "compatibility": "NOT_ESTABLISHED", "confinement": "NOT_PROVEN", "pass_locked_runtime_compatibility_issued": False,
        "worker_execution_authorized": False, "subagent_execution_authorized": False, "credential_use_authorized": False,
        "target_access_authorized": False, "external_network_authorized": False, "daybreak_invocation_authorized": False,
        "exploit_replay_authorized": False, "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "operation_counters": authority["governance_operation_counters"], "historical_v5_noncandidate_invocation_count": 1,
        "validation_counts": {
            "primary": {"total": primary["checks_total"], "passed": primary["checks_passed"], "failed": primary["checks_failed"]},
            "negative": {"total": negative["tests_total"], "passed": negative["tests_passed"], "failed": negative["tests_failed"]},
            "independent": {"total": independent["checks_total"], "passed": independent["checks_passed"], "failed": independent["checks_failed"]},
            "final_freeze": {"total": len(checks), "passed": len(checks), "failed": 0},
        },
        "canonical_member_root_sha256": member_root, "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root,
        "structural_counts": {"manifest_members": len(members), "root_members": len(members) + 2},
        "next_legal_milestone": load("NEXT_LEGAL_MILESTONE.json")["next_if_pass_locked"],
    }
    with (ROOT / "GOVERNANCE_LOCK.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(lock, handle, indent=2, sort_keys=True); handle.write("\n")

    for path in ROOT.iterdir():
        if path.is_file():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({"status": lock["status"], "decision": lock["decision"], "governance_manifest_sha256": manifest_sha, "governance_lock_sha256": sha(ROOT / "GOVERNANCE_LOCK.json"), "canonical_artifact_root_sha256": artifact_root}, sort_keys=True))


if __name__ == "__main__":
    main()
