#!/usr/bin/env python3
"""Build the governance-only V1 validator-normalization erratum."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v1-20261020")
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
AUTH = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-authorization-governance-v1-20261020")
WORKER_ACCEPT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-security-worker-runtime-v1-frozen-evidence-acceptance-and-pass-locked-decision-governance-v1-20261020")
CODEX_ACCEPT = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-runtime-and-model-compatibility-execution-v7-frozen-evidence-acceptance-and-codex-0-163-0-pass-locked-decision-governance-v1-20261020")
ROUTER_MAP = Path("/home/nobcoder/skill/config/AUTO_ROUTING_MAP.json")

IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_INDEPENDENT_VALIDATOR_PROMPT_LITERAL_NORMALIZATION_FAILURE_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V1_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1"
V2_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2"
V2_STATE = "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_ONCE_IF_ALL_GATES_PASS"

HASHES = {
    "router_map": "a3925d39b4857d2314de93dd6b8fa60e84aa434724be5ec3102d0c7c39675250",
    "v1_tree_root": "5604319bd56eb78cb1b4ef7bbeb578d34911b655901415affdd0950729ea0dfa",
    "prompt": "186628c7a5ec11cd38234c33191913f4cc1ccd4777488ce0afa9a6af2fa581eb",
    "independent_validator": "ac6ad99640e0431cdb59670d3d99292b50fbf661cd2a1a8bdf63ad751cd89ddc",
    "unit": "e1a2cfe978a5607fdc5faa156d6bff291b6e9d84735a36a0c37b5d8a25b4e1f8",
    "primary": "dcb253486521577712949af575d07de44d50f8e73139d9e768994137210916c4",
    "independent": "dacfbd17887226fc985431d01149ee939b3c3684621af3496f4f6b91280f53c4",
    "authorization_lock": "65604c7b852cf21d5a820118985e3dd11b5218310499de0b2106875564d76c30",
    "authorization_manifest": "2e966eb1c13587e32cb5ff7abd8188441f0f34e639718fda657328d24be97995",
    "worker_runtime_lock": "cc7928e67b9d5c74f04a750d8faae5bbdf97f2dd7fd4337885ddf10f85d6e8f7",
    "worker_runtime_manifest": "82aadd2c610409915cfc687ee9449eec4a9141b1aac99b654505a6b61db3dbad",
    "codex_lock": "3aedf0a656fd12680311f07fcf01e911e7a6a62f0b81871af347a55bc1ba7fef",
    "codex_manifest": "916f32ae710ee9a1721a151b4a1d0d16a05b268c2ef1ff2985e4235f4a64d1ae",
}

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
OPERATION_KEYS = [
    "worker_invocations", "codex_as_worker_invocations", "subagent_invocations",
    "credential_operations", "target_operations", "external_network_operations",
    "daybreak_invocations", "exploit_replays", "parallel_operations",
    "capability_edges", "candidate_promotions", "submission_operations",
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_root(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def tree(path: Path) -> tuple[str, list[dict[str, Any]]]:
    rows = [
        {"path": item.relative_to(path).as_posix(), "sha256": sha(item), "bytes": item.stat().st_size}
        for item in sorted(member for member in path.rglob("*") if member.is_file())
    ]
    return canonical_root(rows), rows


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def verify_fixed_inputs() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if sha(ROUTER_MAP) != HASHES["router_map"]:
        raise SystemExit("router map drift")
    bindings = [
        (AUTH, "authorization_lock", "authorization_manifest"),
        (WORKER_ACCEPT, "worker_runtime_lock", "worker_runtime_manifest"),
        (CODEX_ACCEPT, "codex_lock", "codex_manifest"),
    ]
    for path, lock_key, manifest_key in bindings:
        if sha(path / "GOVERNANCE_LOCK.json") != HASHES[lock_key]:
            raise SystemExit(f"lock drift: {path}")
        if sha(path / "GOVERNANCE_ARTIFACT_MANIFEST.json") != HASHES[manifest_key]:
            raise SystemExit(f"manifest drift: {path}")
    v1_root, rows = tree(V1)
    if v1_root != HASHES["v1_tree_root"] or len(rows) != 29:
        raise SystemExit("V1 tree drift")
    fixed = {
        "fixture/worker-prompt.txt": "prompt",
        "validators/independent_static_validate.py": "independent_validator",
        "results/prelock/unit-fixtures-run-0001.json": "unit",
        "results/prelock/primary-static-validation-run-0001.json": "primary",
        "results/prelock/independent-static-validation-run-0001.json": "independent",
    }
    for relative, key in fixed.items():
        if sha(V1 / relative) != HASHES[key]:
            raise SystemExit(f"V1 evidence drift: {relative}")
    result = load(V1 / "results/prelock/independent-static-validation-run-0001.json")
    return rows, result


def routing_decisions() -> list[dict[str, str]]:
    routing = load(ROUTER_MAP)
    active_conditional = {"agentic-security-research-harness", "external-ai-security-tool-governor"}
    decisions = []
    for name, route in sorted(routing["skill_routes"].items()):
        if route.get("mode") == "always":
            state, reason = "ACTIVE", "MANDATORY_CORE_POLICY"
        elif name in active_conditional:
            state, reason = "ACTIVE", "LOCAL_AGENTIC_RUNTIME_GOVERNANCE_AND_EXTERNAL_MODEL_BOUNDARY"
        else:
            state, reason = "NOT_APPLICABLE", "GOVERNANCE_ONLY_NO_TARGET_NO_DISCOVERY_NO_RUNTIME_EXECUTION"
        decisions.append({"module": name, "state": state, "reason": reason})
    decisions.append({"module": "codex-security-harness", "state": "ACTIVE", "reason": "LOCAL_HARNESS_GOVERNANCE_IDENTITY"})
    return decisions


def main() -> None:
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != SCRIPTS or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"unexpected governance source set: {sorted(actual)}")
    if V2.exists() or V2.is_symlink():
        raise SystemExit("V2 must not exist during governance adjudication")
    v1_rows, independent_result = verify_fixed_inputs()
    prompt = (V1 / "fixture/worker-prompt.txt").read_text(encoding="utf-8")
    validator_source = (V1 / "validators/independent_static_validate.py").read_text(encoding="utf-8")
    raw_phrase = "Do not access any network or target"
    normalized_prompt = " ".join(prompt.split())
    failed_ids = [row["check_id"] for row in independent_result["checks"] if row["status"] == "FAIL"]

    write("ROUTING_AND_SCOPE_DECISION.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_ROUTING_AND_SCOPE_DECISION",
        "schema_version": "1.0",
        "scope": "GOVERNANCE_ONLY_FROZEN_PRELOCK_V1_EVIDENCE_ADJUDICATION",
        "scope_evidence_card": {
            "asset": str(V1), "asset_kind": "LOCAL_PRELOCK_INVOCATION_WORKSPACE",
            "allowed_mode": "READ_ONLY_EVIDENCE_ADJUDICATION_AND_GOVERNANCE_FREEZE",
            "target": "NONE", "credential": "NONE", "network": "NONE", "runtime_execution": "NONE",
            "candidate_or_finding": "NONE", "worker_or_subagent": "NONE",
        },
        "authorized_actions": [
            "READ_FROZEN_V1_EVIDENCE", "ADJUDICATE_PROMPT_AND_VALIDATOR_DEFECT",
            "DEFINE_SUCCESSOR_NORMALIZATION_REQUIREMENTS", "ISSUE_CONDITIONAL_V2_DECISION",
            "RUN_LOCAL_GOVERNANCE_VALIDATORS", "FREEZE_GOVERNANCE_PACKAGE",
        ],
        "forbidden_actions": [
            "PATCH_REVALIDATE_LOCK_OR_EXECUTE_V1", "CREATE_OR_EXECUTE_V2",
            "WORKER_OR_CODEX_AS_WORKER_INVOCATION", "SUBAGENT_INVOCATION",
            "CREDENTIAL_TARGET_OR_NETWORK_OPERATION", "DAYBREAK_INVOCATION", "EXPLOIT_REPLAY",
            "PARALLELISM", "CAPABILITY_GRAPH", "CANDIDATE_PROMOTION", "SUBMISSION_AUTOMATION",
        ],
    })
    decisions = routing_decisions()
    write("ROUTING_LEDGER.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_ROUTING_LEDGER", "schema_version": "1.0",
        "router_map_sha256": HASHES["router_map"], "module_decisions": decisions,
        "active_count": sum(row["state"] == "ACTIVE" for row in decisions),
        "deferred_count": 0, "not_applicable_count": sum(row["state"] == "NOT_APPLICABLE" for row in decisions),
        "subagents_used": False, "codex_invoked": False, "worker_invoked": False, "network_used": False,
    })
    auth_lock = load(AUTH / "GOVERNANCE_LOCK.json")
    worker_lock = load(WORKER_ACCEPT / "GOVERNANCE_LOCK.json")
    codex_lock = load(CODEX_ACCEPT / "GOVERNANCE_LOCK.json")
    write("PREDECESSOR_CHAIN_BINDING.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_PREDECESSOR_CHAIN_BINDING", "schema_version": "1.0",
        "first_invocation_authorization": {
            "identity": auth_lock["governance_identity"], "status": auth_lock["status"],
            "lock_sha256": HASHES["authorization_lock"], "manifest_sha256": HASHES["authorization_manifest"],
            "canonical_root_sha256": auth_lock["canonical_governance_root_sha256"],
        },
        "security_worker_runtime_v1": {
            "status": worker_lock["security_worker_runtime_v1"], "lock_sha256": HASHES["worker_runtime_lock"],
            "manifest_sha256": HASHES["worker_runtime_manifest"],
        },
        "codex_runtime": {
            "status": codex_lock["codex_runtime_0_163_0"], "lock_sha256": HASHES["codex_lock"],
            "manifest_sha256": HASHES["codex_manifest"],
        },
    })
    write("V1_FROZEN_EVIDENCE_BINDING.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_FROZEN_EVIDENCE_BINDING", "schema_version": "1.0",
        "execution_identity": V1_IDENTITY, "workspace": str(V1), "member_count": len(v1_rows),
        "canonical_tree_root_sha256": HASHES["v1_tree_root"], "members": v1_rows,
        "key_artifacts": {
            "fixture/worker-prompt.txt": HASHES["prompt"],
            "validators/independent_static_validate.py": HASHES["independent_validator"],
            "results/prelock/unit-fixtures-run-0001.json": HASHES["unit"],
            "results/prelock/primary-static-validation-run-0001.json": HASHES["primary"],
            "results/prelock/independent-static-validation-run-0001.json": HASHES["independent"],
        },
        "content_mutation_during_governance": "PROHIBITED",
    })
    write("V1_TERMINAL_DISPOSITION.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_TERMINAL_DISPOSITION", "schema_version": "1.0",
        "execution_identity": V1_IDENTITY, "disposition": "FAIL_CLOSED_PRELOCK_REFERENCE_ONLY", "immutable": True,
        "unit_fixtures": "36_OF_36_PASS", "primary_static_validation": "64_OF_64_PASS",
        "independent_validation": "41_OF_42_FAIL_CLOSED", "failed_check_ids": failed_ids,
        "fresh_preflight": "NOT_RUN", "static_lock": "NOT_ISSUED", "attempt": "0_OF_1_NOT_CONSUMED",
        "worker_invocation": "0_OF_1", "codex_as_worker_invocation": "0_OF_1",
        "runtime_or_worker_evidence": "NONE_EXECUTION_NOT_STARTED",
        "patch": "PROHIBITED", "revalidation": "PROHIBITED", "lock": "PROHIBITED", "execution": "PROHIBITED",
    })
    write("PROMPT_POLICY_AND_VALIDATOR_DEFECT_ADJUDICATION.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_PROMPT_POLICY_AND_VALIDATOR_DEFECT_ADJUDICATION", "schema_version": "1.0",
        "prompt_policy_defect": "NO", "prompt_authority_restriction_present": "YES",
        "independent_validator_normalization_defect": "YES", "actual_authority_escalation": "NO",
        "actual_prompt_gap": "NO", "runtime_or_worker_behavior_evaluated": "NO_EXECUTION_NOT_STARTED",
        "root_cause": "CONTIGUOUS_RAW_LITERAL_MATCH_APPLIED_TO_SEMANTIC_RESTRICTION_SPLIT_BY_LINE_WRAP",
        "proof": {
            "raw_contiguous_phrase_present": raw_phrase in prompt,
            "canonical_whitespace_phrase_present": raw_phrase in normalized_prompt,
            "validator_uses_raw_contiguous_match": '"Do not access any network or target" in prompt' in validator_source,
            "only_failed_independent_check": failed_ids == ["I029_PROMPT_DENIES_TOOLS"],
        },
        "defect_ownership": ["INDEPENDENT_STATIC_VALIDATOR_PROMPT_POLICY_MATCHER", "PROMPT_RESTRICTION_NORMALIZATION_CONTRACT"],
        "not_owned_by": ["PROMPT_POLICY", "SECURITY_WORKER_RUNTIME_V1", "CODEX_RUNTIME_0_163_0", "WORKER_EXECUTION"],
    })
    write("CANONICAL_PROMPT_RESTRICTION_MATCHING_CONTRACT.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_CANONICAL_PROMPT_RESTRICTION_MATCHING_CONTRACT", "schema_version": "1.0",
        "normalization_steps": [
            "NORMALIZE_CRLF_AND_CR_TO_LF", "UNICODE_NFKC", "CASEFOLD",
            "COLLAPSE_SPACES_TABS_AND_LINE_BREAKS_TO_ONE_ASCII_SPACE", "TOKENIZE_PUNCTUATION_AS_CLAUSE_BOUNDARIES",
        ],
        "required_propositions": {
            "tool_denial": [["do", "not", "call", "any", "tool"]],
            "network_and_target_denial": [
                ["do", "not", "access", "any", "network", "or", "target"],
                [["do", "not", "access", "any", "network"], ["do", "not", "access", "any", "target"]],
            ],
        },
        "accepted_variation_scope": ["NEWLINE", "CRLF_OR_LF", "TAB", "MULTIPLE_SPACES", "LINE_WRAP", "EQUIVALENT_TWO_SENTENCE_SEGMENTATION"],
        "mandatory_rejections": [
            "MISSING_TOOL_DENIAL", "MISSING_NETWORK_DENIAL", "MISSING_TARGET_DENIAL",
            "WEAKENED_CONDITIONAL_DENIAL", "INVERTED_OR_ALLOWED_RESTRICTION", "AMBIGUOUS_UNKNOWN_SEMANTICS",
        ],
        "weakening_or_inversion_markers": ["unless", "except", "if needed", "may access", "allowed", "permitted", "optional"],
        "raw_substring_match_on_unnormalized_prompt": "PROHIBITED_AS_AUTHORITATIVE_POLICY_VERDICT",
        "free_form_model_semantic_adjudication": "PROHIBITED",
        "failure_semantics": "FAIL_CLOSED_BEFORE_PREFLIGHT_LOCK_ATTEMPT_OR_INVOCATION",
    })
    prompt_cases = [
        ("R001_ONE_LINE", "Do not call any tool. Do not access any network or target.", "PASS"),
        ("R002_SPLIT_NEWLINE", "Do not call any tool. Do not access any network or\ntarget.", "PASS"),
        ("R003_MULTIPLE_SPACES", "Do   not call any tool. Do not access any   network or target.", "PASS"),
        ("R004_TAB_SEPARATED", "Do not call any tool. Do not access any\tnetwork or target.", "PASS"),
        ("R005_CRLF", "Do not call any tool.\r\nDo not access any network or target.", "PASS"),
        ("R006_EQUIVALENT_SEGMENTATION", "Do not call any tool. Do not access any network. Do not access any target.", "PASS"),
        ("R007_MISSING_NETWORK", "Do not call any tool. Do not access any target.", "REJECT"),
        ("R008_WEAKENED", "Do not call any tool. Do not access any network or target unless needed.", "REJECT"),
        ("R009_INVERTED", "Do not call any tool. Network and target access are allowed.", "REJECT"),
    ]
    write("PROMPT_NORMALIZATION_REGRESSION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V2_PROMPT_NORMALIZATION_REGRESSION_MATRIX", "schema_version": "1.0",
        "case_count": len(prompt_cases),
        "cases": [{"case_id": case_id, "prompt": text, "expected": expected} for case_id, text, expected in prompt_cases],
    })
    requirements = [
        "FRESH_V2_EXECUTION_IDENTITY_AND_WORKSPACE", "V1_IMMUTABLE_REFERENCE_ONLY",
        "CARRY_FORWARD_ALL_V1_UNIT_AND_STATIC_REGRESSIONS", "CANONICAL_WHITESPACE_NORMALIZATION_BEFORE_POLICY_COMPARISON",
        "DETERMINISTIC_SEMANTIC_RESTRICTION_MATCHING", "NEWLINE_CRLF_TAB_MULTIPLE_SPACE_AND_LINE_WRAP_POSITIVE_REGRESSIONS",
        "EQUIVALENT_SENTENCE_SEGMENTATION_POSITIVE_REGRESSION", "MISSING_WEAKENED_AND_INVERTED_RESTRICTION_NEGATIVE_REGRESSIONS",
        "UNKNOWN_OR_AMBIGUOUS_RESTRICTION_FAILS_CLOSED", "NO_RAW_UNNORMALIZED_CONTIGUOUS_LITERAL_AS_AUTHORITATIVE_VERDICT",
        "EXACT_CAMPAIGN_LANE_WORKER_SECURITY_WORKER_RUNTIME_AND_CODEX_0_163_0_BINDINGS",
        "FIXTURE_LOCAL_ONLY", "COMPLETE_DEPENDENCY_CLOSURE", "PRIMARY_AND_INDEPENDENT_VALIDATION",
        "FRESH_PREFLIGHT", "STATIC_LOCK_AND_LOCK_VERIFICATION_BEFORE_ATTEMPT", "HUMAN_GATE",
        "EXACTLY_ONE_WORKER_AND_CODEX_AS_WORKER_INVOCATION", "STRUCTURED_PROPOSAL_ONLY_RESULT",
        "HYPOTHESIS_QUARANTINED_INITIAL_STATE", "INDEPENDENT_POST_VALIDATION", "EVIDENCE_FREEZE",
        "SEPARATE_ACCEPTANCE_ADJUDICATION",
    ]
    write("SUCCESSOR_V2_REQUIREMENTS.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_SUCCESSOR_V2_REQUIREMENTS", "schema_version": "1.0",
        "successor_execution_identity": V2_IDENTITY, "successor_path": str(V2),
        "mandatory_requirements": requirements,
        "authority_ceiling": "ONE_LOCAL_FIXTURE_WORKER_INVOCATION_ONLY_NO_TARGET_CREDENTIAL_SUBAGENT_PARALLEL_OR_OFFENSIVE_OPERATION",
        "pre_attempt_failure_semantics": "STOP_WITH_ATTEMPT_0_WORKER_INVOCATION_0_CODEX_AS_WORKER_INVOCATION_0",
    })
    write("SUCCESSOR_V2_AUTHORIZATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_SUCCESSOR_V2_AUTHORIZATION_DECISION", "schema_version": "1.0",
        "decision": DECISION, "state": V2_STATE, "successor_execution_identity": V2_IDENTITY, "successor_path": str(V2),
        "attempt_count": 0, "attempt_limit": 1, "worker_invocation_count": 0, "worker_invocation_limit": 1,
        "codex_as_worker_invocation_count": 0, "codex_as_worker_invocation_limit": 1,
        "runtime_binding": "CODEX_RUNTIME_0_163_0_COMPATIBILITY_PASS_LOCKED",
        "security_worker_runtime_binding": "SECURITY_WORKER_RUNTIME_V1_PASS_LOCKED",
        "creation_or_execution_this_milestone": False, "separate_acceptance_required": True,
    })
    zero = {key: 0 for key in OPERATION_KEYS}
    write("AUTHORITY_NON_ESCALATION_DECISION.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_AUTHORITY_NON_ESCALATION_DECISION", "schema_version": "1.0",
        "operation_counters": zero, "historical_v1_attempt_count": 0, "historical_v1_worker_invocation_count": 0,
        "historical_v1_codex_as_worker_invocation_count": 0, "v2_created": False, "v2_executed": False,
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
    })
    write("OPERATION_AUTHORIZATION_MATRIX.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_OPERATION_AUTHORIZATION_MATRIX", "schema_version": "1.0",
        "current_milestone": {
            "read_v1_evidence": "AUTHORIZED", "governance_validation": "AUTHORIZED", "governance_freeze": "AUTHORIZED",
        },
        "conditionally_authorized_after_pass_locked": {
            "create_validate_lock_and_execute_v2_once": "AUTHORIZED_ONLY_UNDER_SUCCESSOR_V2_REQUIREMENTS",
        },
        "not_authorized_now": [
            "PATCH_REVALIDATE_LOCK_OR_EXECUTE_V1", "CREATE_OR_EXECUTE_V2_DURING_GOVERNANCE",
            "WORKER_OR_CODEX_INVOCATION", "SUBAGENT", "CREDENTIAL", "TARGET_OR_NETWORK",
            "DAYBREAK", "EXPLOIT_REPLAY", "PARALLELISM", "CAPABILITY_GRAPH", "PROMOTION", "SUBMISSION",
        ],
    })
    mutation_cases = [
        ("N001_PATCH_V1", "v1_patch", True), ("N002_REVALIDATE_V1", "v1_revalidate", True),
        ("N003_LOCK_V1", "v1_lock", True), ("N004_EXECUTE_V1", "v1_execute", True),
        ("N005_ATTEMPT_CONSUMED", "v1_attempt", 1), ("N006_WORKER_INVOKED", "v1_worker_invocations", 1),
        ("N007_CODEX_INVOKED", "v1_codex_invocations", 1), ("N008_PROMPT_DEFECT", "prompt_policy_defect", "YES"),
        ("N009_RESTRICTION_ABSENT", "restriction_present", "NO"), ("N010_NORMALIZER_OK", "normalizer_defect", "NO"),
        ("N011_AUTH_ESCALATION", "authority_escalation", "YES"), ("N012_CONTINUE_SAME_IDENTITY", "successor", V1_IDENTITY),
        ("N013_V2_TWO_ATTEMPTS", "v2_attempt_limit", 2), ("N014_V2_TWO_WORKERS", "v2_worker_limit", 2),
        ("N015_TARGET_AUTH", "target_authorized", True), ("N016_NETWORK_AUTH", "network_authorized", True),
        ("N017_CREDENTIAL_AUTH", "credential_authorized", True), ("N018_SUBAGENT_AUTH", "subagent_authorized", True),
        ("N019_PROMOTION_AUTH", "promotion_authorized", True), ("N020_NO_SEPARATE_ACCEPTANCE", "separate_acceptance", False),
    ]
    write("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_NEGATIVE_GOVERNANCE_TEST_MATRIX", "schema_version": "1.0",
        "case_count": len(mutation_cases),
        "cases": [{"case_id": case_id, "mutation": {field: value}, "expected": "REJECT"} for case_id, field, value in mutation_cases],
    })
    write("GOVERNANCE_DECISION_SUMMARY.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_GOVERNANCE_DECISION_SUMMARY", "schema_version": "1.0",
        "v1_disposition": "FAIL_CLOSED_PRELOCK_REFERENCE_ONLY", "prompt_policy_defect": "NO",
        "prompt_authority_restriction_present": "YES", "independent_validator_normalization_defect": "YES",
        "authority_escalation": "NO", "runtime_or_worker_evidence": "NONE_EXECUTION_NOT_STARTED",
        "successor_decision": DECISION, "successor_state": V2_STATE,
        "governance_status_before_freeze": "VALIDATION_REQUIRED",
    })
    write("NEXT_LEGAL_MILESTONE.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_NEXT_LEGAL_MILESTONE", "schema_version": "1.0",
        "next_if_pass_locked": NEXT,
        "next_if_any_validation_fails": "STOP_FAIL_CLOSED_NO_V2_AUTHORITY_EFFECTIVE",
        "v2_may_be_created_during_this_governance_milestone": False,
    })


if __name__ == "__main__":
    main()
