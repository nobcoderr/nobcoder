#!/usr/bin/env python3
"""Primary, prompt-regression, and negative governance validation."""

from __future__ import annotations

import ast
import hashlib
import json
import re
import unicodedata
from copy import deepcopy
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v1-20261020")
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_INDEPENDENT_VALIDATOR_PROMPT_LITERAL_NORMALIZATION_FAILURE_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V1_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1"
V2_IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_ONCE_IF_ALL_GATES_PASS"
V1_ROOT = "5604319bd56eb78cb1b4ef7bbeb578d34911b655901415affdd0950729ea0dfa"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V1_FROZEN_EVIDENCE_BINDING.json", "V1_TERMINAL_DISPOSITION.json",
    "PROMPT_POLICY_AND_VALIDATOR_DEFECT_ADJUDICATION.json", "CANONICAL_PROMPT_RESTRICTION_MATCHING_CONTRACT.json",
    "PROMPT_NORMALIZATION_REGRESSION_MATRIX.json", "SUCCESSOR_V2_REQUIREMENTS.json",
    "SUCCESSOR_V2_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str) -> dict[str, Any]:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def tree_root(path: Path) -> str:
    rows = [
        f"{sha(member)}  {member.relative_to(path).as_posix()}\n"
        for member in sorted(item for item in path.rglob("*") if item.is_file())
    ]
    return hashlib.sha256("".join(rows).encode()).hexdigest()


def normalized_tokens(text: str) -> list[str]:
    canonical = unicodedata.normalize("NFKC", text.replace("\r\n", "\n").replace("\r", "\n")).casefold()
    canonical = re.sub(r"\s+", " ", canonical).strip()
    return re.findall(r"[a-z0-9]+", canonical)


def contains(tokens: list[str], phrase: list[str]) -> bool:
    return any(tokens[index:index + len(phrase)] == phrase for index in range(len(tokens) - len(phrase) + 1))


def restriction_verdict(text: str) -> str:
    tokens = normalized_tokens(text)
    weakening = [
        ["unless"], ["except"], ["if", "needed"], ["may", "access"],
        ["allowed"], ["permitted"], ["optional"],
    ]
    if any(contains(tokens, phrase) for phrase in weakening):
        return "REJECT"
    tool = contains(tokens, ["do", "not", "call", "any", "tool"])
    combined = contains(tokens, ["do", "not", "access", "any", "network", "or", "target"])
    split = (
        contains(tokens, ["do", "not", "access", "any", "network"])
        and contains(tokens, ["do", "not", "access", "any", "target"])
    )
    return "PASS" if tool and (combined or split) else "REJECT"


def canonical_policy() -> dict[str, Any]:
    return {
        "v1_patch": False, "v1_revalidate": False, "v1_lock": False, "v1_execute": False,
        "v1_attempt": 0, "v1_worker_invocations": 0, "v1_codex_invocations": 0,
        "prompt_policy_defect": "NO", "restriction_present": "YES", "normalizer_defect": "YES",
        "authority_escalation": "NO", "successor": V2_IDENTITY, "v2_attempt_limit": 1,
        "v2_worker_limit": 1, "target_authorized": False, "network_authorized": False,
        "credential_authorized": False, "subagent_authorized": False, "promotion_authorized": False,
        "separate_acceptance": True,
    }


def main() -> None:
    expected = SCRIPTS | BASE
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("P001_EXACT_INPUT_SET", actual == expected, {"actual": sorted(actual), "expected": sorted(expected)})
    check("P002_NO_SUBDIRECTORY_OR_SYMLINK", not any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()))
    check("P003_V2_ABSENT", not V2.exists() and not V2.is_symlink())
    check("P004_V1_TREE_ROOT", tree_root(V1) == V1_ROOT, tree_root(V1))
    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("P_SCRIPT_" + script, valid)
    docs: dict[str, dict[str, Any]] = {}
    for name in sorted(BASE):
        try:
            payload = load(name)
            docs[name] = payload
            valid = payload.get("governance_identity") == IDENTITY
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            valid = False
        check("P_JSON_" + name, valid)

    terminal = docs.get("V1_TERMINAL_DISPOSITION.json", {})
    defect = docs.get("PROMPT_POLICY_AND_VALIDATOR_DEFECT_ADJUDICATION.json", {})
    contract = docs.get("CANONICAL_PROMPT_RESTRICTION_MATCHING_CONTRACT.json", {})
    successor = docs.get("SUCCESSOR_V2_AUTHORIZATION_DECISION.json", {})
    requirements = docs.get("SUCCESSOR_V2_REQUIREMENTS.json", {})
    authority = docs.get("AUTHORITY_NON_ESCALATION_DECISION.json", {})
    summary = docs.get("GOVERNANCE_DECISION_SUMMARY.json", {})
    next_step = docs.get("NEXT_LEGAL_MILESTONE.json", {})
    matrix = docs.get("NEGATIVE_GOVERNANCE_TEST_MATRIX.json", {})
    prompt_matrix = docs.get("PROMPT_NORMALIZATION_REGRESSION_MATRIX.json", {})

    check("P030_V1_REFERENCE_ONLY", terminal.get("disposition") == "FAIL_CLOSED_PRELOCK_REFERENCE_ONLY")
    check("P031_V1_IMMUTABLE", terminal.get("immutable") is True)
    check("P032_ATTEMPT_ZERO", terminal.get("attempt") == "0_OF_1_NOT_CONSUMED")
    check("P033_WORKER_ZERO", terminal.get("worker_invocation") == "0_OF_1")
    check("P034_CODEX_ZERO", terminal.get("codex_as_worker_invocation") == "0_OF_1")
    check("P035_STATIC_LOCK_NOT_ISSUED", terminal.get("static_lock") == "NOT_ISSUED")
    check("P036_NO_V1_MUTATION_OR_EXECUTION", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "revalidation", "lock", "execution"]))
    check("P037_PROMPT_POLICY_NO_DEFECT", defect.get("prompt_policy_defect") == "NO")
    check("P038_RESTRICTION_PRESENT", defect.get("prompt_authority_restriction_present") == "YES")
    check("P039_NORMALIZER_DEFECT", defect.get("independent_validator_normalization_defect") == "YES")
    check("P040_NO_AUTHORITY_ESCALATION", defect.get("actual_authority_escalation") == "NO" and defect.get("actual_prompt_gap") == "NO")
    proof = defect.get("proof", {})
    check("P041_RAW_LITERAL_FALSE", proof.get("raw_contiguous_phrase_present") is False)
    check("P042_CANONICAL_LITERAL_TRUE", proof.get("canonical_whitespace_phrase_present") is True)
    check("P043_VALIDATOR_RAW_MATCH_PROVEN", proof.get("validator_uses_raw_contiguous_match") is True)
    check("P044_ONLY_I029_FAILED", proof.get("only_failed_independent_check") is True)
    check("P045_NO_RUNTIME_EVIDENCE", terminal.get("runtime_or_worker_evidence") == "NONE_EXECUTION_NOT_STARTED")
    accepted = set(contract.get("accepted_variation_scope", []))
    check("P046_NORMALIZATION_COVERAGE", {"NEWLINE", "CRLF_OR_LF", "TAB", "MULTIPLE_SPACES", "LINE_WRAP", "EQUIVALENT_TWO_SENTENCE_SEGMENTATION"} == accepted)
    rejections = set(contract.get("mandatory_rejections", []))
    check("P047_REJECTION_COVERAGE", {"MISSING_NETWORK_DENIAL", "WEAKENED_CONDITIONAL_DENIAL", "INVERTED_OR_ALLOWED_RESTRICTION"}.issubset(rejections))
    check("P048_RAW_MATCH_PROHIBITED", contract.get("raw_substring_match_on_unnormalized_prompt") == "PROHIBITED_AS_AUTHORITATIVE_POLICY_VERDICT")
    check("P049_FAIL_CLOSED", contract.get("failure_semantics") == "FAIL_CLOSED_BEFORE_PREFLIGHT_LOCK_ATTEMPT_OR_INVOCATION")
    check("P050_SUCCESSOR_DECISION", successor.get("decision") == DECISION and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("P051_SUCCESSOR_IDENTITY", successor.get("successor_execution_identity") == V2_IDENTITY and successor.get("successor_path") == str(V2))
    check("P052_V2_ONE_SHOT", successor.get("attempt_count") == 0 and successor.get("attempt_limit") == 1)
    check("P053_V2_ONE_WORKER", successor.get("worker_invocation_count") == 0 and successor.get("worker_invocation_limit") == 1)
    check("P054_V2_ONE_CODEX", successor.get("codex_as_worker_invocation_count") == 0 and successor.get("codex_as_worker_invocation_limit") == 1)
    check("P055_V2_NOT_CREATED", successor.get("creation_or_execution_this_milestone") is False and not V2.exists())
    required = set(requirements.get("mandatory_requirements", []))
    check("P056_REQUIRED_NORMALIZATION", "CANONICAL_WHITESPACE_NORMALIZATION_BEFORE_POLICY_COMPARISON" in required)
    check("P057_REQUIRED_POSITIVE_REGRESSIONS", "NEWLINE_CRLF_TAB_MULTIPLE_SPACE_AND_LINE_WRAP_POSITIVE_REGRESSIONS" in required)
    check("P058_REQUIRED_NEGATIVE_REGRESSIONS", "MISSING_WEAKENED_AND_INVERTED_RESTRICTION_NEGATIVE_REGRESSIONS" in required)
    check("P059_NO_RAW_MATCH_REQUIREMENT", "NO_RAW_UNNORMALIZED_CONTIGUOUS_LITERAL_AS_AUTHORITATIVE_VERDICT" in required)
    counters = authority.get("operation_counters", {})
    check("P060_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {key: value for key, value in authority.items() if key.endswith("_authorized") and value is not False}
    check("P061_NO_CURRENT_AUTHORITY_ESCALATION", not escalations, escalations)
    check("P062_SUMMARY", summary.get("successor_decision") == DECISION and summary.get("v1_disposition") == "FAIL_CLOSED_PRELOCK_REFERENCE_ONLY")
    check("P063_NEXT_STEP", next_step.get("next_if_pass_locked") == NEXT)
    check("P064_PROMPT_MATRIX", prompt_matrix.get("case_count") == 9 and len(prompt_matrix.get("cases", [])) == 9)
    check("P065_NEGATIVE_MATRIX", matrix.get("case_count") == 20 and len(matrix.get("cases", [])) == 20)

    failed = [row for row in checks if row["status"] == "FAIL"]
    write("GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_GOVERNANCE_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "GOVERNANCE_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "operation_counters": counters,
    })

    prompt_results = []
    for case in prompt_matrix.get("cases", []):
        observed = restriction_verdict(case.get("prompt", ""))
        prompt_results.append({
            "case_id": case.get("case_id"), "expected": case.get("expected"), "observed": observed,
            "status": "PASS" if observed == case.get("expected") else "FAIL",
        })
    prompt_failed = [row for row in prompt_results if row["status"] == "FAIL"]
    write("PROMPT_NORMALIZATION_REGRESSION_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V2_PROMPT_NORMALIZATION_REGRESSION_RESULT", "schema_version": "1.0",
        "run_id": "PROMPT_NORMALIZATION_REGRESSION_RUN-0001",
        "status": "PASS" if not prompt_failed and len(prompt_results) == 9 else "FAIL_CLOSED",
        "tests": prompt_results, "tests_total": len(prompt_results),
        "tests_passed": len(prompt_results) - len(prompt_failed), "tests_failed": len(prompt_failed),
    })

    negative_results = []
    canonical = canonical_policy()
    for case in matrix.get("cases", []):
        candidate = deepcopy(canonical)
        mutation = case.get("mutation", {})
        candidate.update(mutation)
        observed = "REJECT" if candidate != canonical else "ACCEPT"
        negative_results.append({
            "case_id": case.get("case_id"), "expected": case.get("expected"), "observed": observed,
            "status": "PASS" if observed == case.get("expected") else "FAIL",
        })
    negative_failed = [row for row in negative_results if row["status"] == "FAIL"]
    write("NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_NEGATIVE_GOVERNANCE_TEST_RESULT", "schema_version": "1.0",
        "run_id": "NEGATIVE_GOVERNANCE_TEST_RUN-0001",
        "status": "PASS" if not negative_failed and len(negative_results) == 20 else "FAIL_CLOSED",
        "tests": negative_results, "tests_total": len(negative_results),
        "tests_passed": len(negative_results) - len(negative_failed), "tests_failed": len(negative_failed),
        "positive_control": {"canonical_policy_accepted": canonical_policy() == canonical},
    })
    print(json.dumps({
        "primary": [len(checks) - len(failed), len(checks)],
        "prompt_regression": [len(prompt_results) - len(prompt_failed), len(prompt_results)],
        "negative": [len(negative_results) - len(negative_failed), len(negative_results)],
    }, sort_keys=True))
    if failed or prompt_failed or negative_failed or len(prompt_results) != 9 or len(negative_results) != 20:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
