#!/usr/bin/env python3
"""Verify, freeze, and lock the V1 normalization erratum package."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v1-20261020")
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_INDEPENDENT_VALIDATOR_PROMPT_LITERAL_NORMALIZATION_FAILURE_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
DECISION = "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_CONDITIONALLY"
NEXT = "IMPLEMENT_VALIDATE_LOCK_AND_EXECUTE_V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_ONCE_IF_ALL_GATES_PASS"
V1_ROOT = "5604319bd56eb78cb1b4ef7bbeb578d34911b655901415affdd0950729ea0dfa"

SCRIPTS = {"build_governance.py", "validate_governance.py", "independent_validate.py", "finalize_governance.py"}
BASE = {
    "ROUTING_AND_SCOPE_DECISION.json", "ROUTING_LEDGER.json", "PREDECESSOR_CHAIN_BINDING.json",
    "V1_FROZEN_EVIDENCE_BINDING.json", "V1_TERMINAL_DISPOSITION.json",
    "PROMPT_POLICY_AND_VALIDATOR_DEFECT_ADJUDICATION.json", "CANONICAL_PROMPT_RESTRICTION_MATCHING_CONTRACT.json",
    "PROMPT_NORMALIZATION_REGRESSION_MATRIX.json", "SUCCESSOR_V2_REQUIREMENTS.json",
    "SUCCESSOR_V2_AUTHORIZATION_DECISION.json", "AUTHORITY_NON_ESCALATION_DECISION.json",
    "OPERATION_AUTHORIZATION_MATRIX.json", "NEGATIVE_GOVERNANCE_TEST_MATRIX.json",
    "GOVERNANCE_DECISION_SUMMARY.json", "NEXT_LEGAL_MILESTONE.json",
}
RESULTS = {
    "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json", "PROMPT_NORMALIZATION_REGRESSION_RESULT_RUN-0001.json",
    "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json", "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json",
}
FREEZE = "FINAL_FREEZE_VERIFICATION_RESULT_RUN-0001.json"
MANIFEST = "GOVERNANCE_ARTIFACT_MANIFEST.json"
LOCK = "GOVERNANCE_LOCK.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree_root(path: Path) -> str:
    rows = [
        f"{sha(member)}  {member.relative_to(path).as_posix()}\n"
        for member in sorted(item for item in path.rglob("*") if item.is_file())
    ]
    return hashlib.sha256("".join(rows).encode()).hexdigest()


def canonical(rows: list[dict[str, Any]]) -> str:
    material = "".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(rows, key=lambda row: row["path"]))
    return hashlib.sha256(material.encode()).hexdigest()


def write(name: str, payload: dict[str, Any]) -> None:
    with (ROOT / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    expected = SCRIPTS | BASE | RESULTS
    actual = {path.name for path in ROOT.iterdir() if path.is_file()}
    if actual != expected or any(path.is_dir() or path.is_symlink() for path in ROOT.iterdir()):
        raise SystemExit(f"finalizer input set mismatch: {sorted(actual)}")
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    for script in sorted(SCRIPTS):
        try:
            ast.parse((ROOT / script).read_text(encoding="utf-8"), filename=script)
            valid = True
        except (SyntaxError, UnicodeDecodeError):
            valid = False
        check("F_SCRIPT_" + script, valid)
    check("F001_V1_ROOT_UNCHANGED", tree_root(V1) == V1_ROOT, tree_root(V1))
    check("F002_V2_ABSENT", not V2.exists() and not V2.is_symlink())
    check("F003_V1_NO_ATTEMPT", not (V1 / "ATTEMPT_MARKER.json").exists() and not (V1 / "static-run-v1/ATTEMPT_MARKER.json").exists())
    check("F004_V1_NO_STATIC_LOCK", not (V1 / "STATIC_EXECUTION_LOCK.json").exists())
    check("F005_V1_STATIC_RUN_EMPTY", (V1 / "static-run-v1").is_dir() and not any((V1 / "static-run-v1").iterdir()))
    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    prompt_result = read(ROOT / "PROMPT_NORMALIZATION_REGRESSION_RESULT_RUN-0001.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    independent = read(ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json")
    check("F006_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("F007_PROMPT_REGRESSION_PASS", prompt_result.get("status") == "PASS" and prompt_result.get("tests_passed") == 9 and prompt_result.get("tests_failed") == 0)
    check("F008_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_passed") == 20 and negative.get("tests_failed") == 0)
    check("F009_INDEPENDENT_PASS", independent.get("status") == "PASS" and independent.get("checks_failed") == 0)
    check("F010_RESULT_IDENTITIES", all(doc.get("governance_identity") == IDENTITY for doc in [primary, prompt_result, negative, independent]))
    terminal = read(ROOT / "V1_TERMINAL_DISPOSITION.json")
    defect = read(ROOT / "PROMPT_POLICY_AND_VALIDATOR_DEFECT_ADJUDICATION.json")
    contract = read(ROOT / "CANONICAL_PROMPT_RESTRICTION_MATCHING_CONTRACT.json")
    successor = read(ROOT / "SUCCESSOR_V2_AUTHORIZATION_DECISION.json")
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    summary = read(ROOT / "GOVERNANCE_DECISION_SUMMARY.json")
    next_step = read(ROOT / "NEXT_LEGAL_MILESTONE.json")
    check("F011_V1_TERMINAL", terminal.get("disposition") == "FAIL_CLOSED_PRELOCK_REFERENCE_ONLY" and terminal.get("immutable") is True)
    check("F012_V1_ZERO", terminal.get("attempt") == "0_OF_1_NOT_CONSUMED" and terminal.get("worker_invocation") == "0_OF_1" and terminal.get("codex_as_worker_invocation") == "0_OF_1")
    check("F013_V1_NO_CONTINUATION", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "revalidation", "lock", "execution"]))
    check("F014_DEFECT", defect.get("prompt_policy_defect") == "NO" and defect.get("prompt_authority_restriction_present") == "YES" and defect.get("independent_validator_normalization_defect") == "YES")
    check("F015_NO_ESCALATION", defect.get("actual_authority_escalation") == "NO" and defect.get("actual_prompt_gap") == "NO")
    check("F016_CONTRACT_FAIL_CLOSED", contract.get("failure_semantics") == "FAIL_CLOSED_BEFORE_PREFLIGHT_LOCK_ATTEMPT_OR_INVOCATION")
    check("F017_SUCCESSOR_DECISION", successor.get("decision") == DECISION and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("F018_SUCCESSOR_ZERO", successor.get("attempt_count") == 0 and successor.get("worker_invocation_count") == 0 and successor.get("codex_as_worker_invocation_count") == 0)
    counters = authority.get("operation_counters", {})
    check("F019_OPERATION_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    escalations = {key: value for key, value in authority.items() if key.endswith("_authorized") and value is not False}
    check("F020_NO_CURRENT_AUTHORITY_ESCALATION", not escalations, escalations)
    check("F021_SUMMARY", summary.get("successor_decision") == DECISION and summary.get("governance_status_before_freeze") == "VALIDATION_REQUIRED")
    check("F022_NEXT", next_step.get("next_if_pass_locked") == NEXT and next_step.get("v2_may_be_created_during_this_governance_milestone") is False)
    failed = [row for row in checks if row["status"] == "FAIL"]
    if failed:
        raise SystemExit("final freeze verification failed: " + ",".join(row["check_id"] for row in failed))

    write(FREEZE, {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_FINAL_FREEZE_VERIFICATION_RESULT", "schema_version": "1.0",
        "run_id": "FINAL_FREEZE_VERIFICATION_RUN-0001", "status": "PASS",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks), "checks_failed": 0,
        "v1_tree_root_sha256": V1_ROOT, "v2_absent": True,
        "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
    })
    names = sorted(expected | {FREEZE})
    rows = [{"path": name, "sha256": sha(ROOT / name), "bytes": (ROOT / name).stat().st_size} for name in names]
    artifact_root = canonical(rows)
    write(MANIFEST, {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_GOVERNANCE_ARTIFACT_MANIFEST", "schema_version": "1.0",
        "member_count": len(rows), "members": rows, "canonical_artifact_root_sha256": artifact_root,
        "excluded_self_referential_artifacts": [MANIFEST, LOCK],
    })
    manifest_sha = sha(ROOT / MANIFEST)
    write(LOCK, {
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_GOVERNANCE_LOCK", "schema_version": "1.0",
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "v1_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1",
        "v1_disposition": "FAIL_CLOSED_PRELOCK_REFERENCE_ONLY", "v1_immutable": True,
        "v1_attempt_count": 0, "v1_worker_invocation_count": 0, "v1_codex_as_worker_invocation_count": 0,
        "prompt_policy_defect": "NO", "prompt_authority_restriction_present": "YES",
        "independent_validator_normalization_defect": "YES", "actual_authority_escalation": "NO",
        "runtime_or_worker_evidence": "NONE_EXECUTION_NOT_STARTED",
        "v2_execution_identity": "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2",
        "v2_state": "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED",
        "v2_attempt_count": 0, "v2_attempt_limit": 1,
        "v2_worker_invocation_count": 0, "v2_worker_invocation_limit": 1,
        "v2_codex_as_worker_invocation_count": 0, "v2_codex_as_worker_invocation_limit": 1,
        "worker_execution_authorized_now": False, "codex_as_worker_invocation_authorized_now": False,
        "credential_use_authorized": False, "target_access_authorized": False, "external_network_authorized": False,
        "subagent_authorized": False, "daybreak_authorized": False, "exploit_replay_authorized": False,
        "parallelism_authorized": False, "capability_graph_authorized": False,
        "candidate_promotion_authorized": False, "submission_automation_authorized": False,
        "validation": {
            "primary": {"status": primary["status"], "passed": primary["checks_passed"], "total": primary["checks_total"]},
            "prompt_regression": {"status": prompt_result["status"], "passed": prompt_result["tests_passed"], "total": prompt_result["tests_total"]},
            "negative": {"status": negative["status"], "passed": negative["tests_passed"], "total": negative["tests_total"]},
            "independent": {"status": independent["status"], "passed": independent["checks_passed"], "total": independent["checks_total"]},
            "final_freeze": {"status": "PASS", "passed": len(checks), "total": len(checks)},
        },
        "operation_counters": counters, "governance_manifest_sha256": manifest_sha,
        "canonical_artifact_root_sha256": artifact_root, "next_legal_milestone": NEXT,
        "authority_ceiling": "V2_ENGINEERING_AND_ONE_LOCAL_FIXTURE_WORKER_INVOCATION_CONDITIONALLY_AUTHORIZED_ONLY_AFTER_THIS_LOCK_NO_CURRENT_RUNTIME_OR_TARGET_AUTHORITY",
    })
    for path in ROOT.iterdir():
        if path.is_file() and not path.is_symlink():
            os.chmod(path, 0o444)
    os.chmod(ROOT, 0o555)
    print(json.dumps({
        "status": "PASS_LOCKED_GOVERNANCE_ONLY", "decision": DECISION,
        "manifest_sha256": manifest_sha, "canonical_artifact_root_sha256": artifact_root,
        "files": len(rows) + 2,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
