#!/usr/bin/env python3
"""Independent validation for the V1 prompt-normalization erratum."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
V1 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v1-20261020")
V2 = Path("/home/nobcoder/v0.3-first-real-security-worker-invocation-v2-20261020")
AUTH = Path("/home/nobcoder/codex-security-harness-eval/governance/v0.3-first-real-security-worker-invocation-authorization-governance-v1-20261020")
IDENTITY = "V0_3_FIRST_REAL_SECURITY_WORKER_INVOCATION_V1_INDEPENDENT_VALIDATOR_PROMPT_LITERAL_NORMALIZATION_FAILURE_PRELOCK_ERRATUM_AND_SUCCESSOR_DECISION_GOVERNANCE_ONLY"
V1_ROOT = "5604319bd56eb78cb1b4ef7bbeb578d34911b655901415affdd0950729ea0dfa"
AUTH_LOCK_SHA = "65604c7b852cf21d5a820118985e3dd11b5218310499de0b2106875564d76c30"
PROMPT_SHA = "186628c7a5ec11cd38234c33191913f4cc1ccd4777488ce0afa9a6af2fa581eb"
VALIDATOR_SHA = "ac6ad99640e0431cdb59670d3d99292b50fbf661cd2a1a8bdf63ad751cd89ddc"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def tree_root(path: Path) -> str:
    rows = [
        f"{sha(member)}  {member.relative_to(path).as_posix()}\n"
        for member in sorted(item for item in path.rglob("*") if item.is_file())
    ]
    return hashlib.sha256("".join(rows).encode()).hexdigest()


def semantic_policy_accepts(text: str) -> bool:
    text = unicodedata.normalize("NFKC", text).casefold()
    text = re.sub(r"[\t\n\r\f\v ]+", " ", text).strip()
    if re.search(r"\b(unless|except|allowed|permitted|optional)\b|\bif\s+needed\b|\bmay\s+access\b", text):
        return False
    tool = re.search(r"\bdo\s+not\s+call\s+any\s+tool\b", text) is not None
    combined = re.search(r"\bdo\s+not\s+access\s+any\s+network\s+or\s+target\b", text) is not None
    split_network = re.search(r"\bdo\s+not\s+access\s+any\s+network\b", text) is not None
    split_target = re.search(r"\bdo\s+not\s+access\s+any\s+target\b", text) is not None
    return tool and (combined or (split_network and split_target))


def write(payload: dict[str, Any]) -> None:
    with (ROOT / "INDEPENDENT_VALIDATION_RESULT_RUN-0001.json").open("x", encoding="utf-8", newline="\n") as handle:
        json.dump({"governance_identity": IDENTITY, **payload}, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main() -> None:
    checks: list[dict[str, Any]] = []

    def check(check_id: str, condition: bool, evidence: Any = None) -> None:
        checks.append({"check_id": check_id, "status": "PASS" if condition else "FAIL", "evidence": evidence})

    check("I001_V1_ROOT", tree_root(V1) == V1_ROOT, tree_root(V1))
    check("I002_AUTHORIZATION_LOCK", sha(AUTH / "GOVERNANCE_LOCK.json") == AUTH_LOCK_SHA)
    check("I003_V2_ABSENT", not V2.exists() and not V2.is_symlink())
    check("I004_PROMPT_HASH", sha(V1 / "fixture/worker-prompt.txt") == PROMPT_SHA)
    check("I005_VALIDATOR_HASH", sha(V1 / "validators/independent_static_validate.py") == VALIDATOR_SHA)
    check("I006_NO_ATTEMPT_MARKER", not (V1 / "ATTEMPT_MARKER.json").exists() and not (V1 / "static-run-v1/ATTEMPT_MARKER.json").exists())
    check("I007_NO_STATIC_LOCK", not (V1 / "STATIC_EXECUTION_LOCK.json").exists())
    check("I008_STATIC_RUN_EMPTY", (V1 / "static-run-v1").is_dir() and not any((V1 / "static-run-v1").iterdir()))
    old_result = read(V1 / "results/prelock/independent-static-validation-run-0001.json")
    failures = [row.get("check_id") for row in old_result.get("checks", []) if row.get("status") == "FAIL"]
    check("I009_OLD_RESULT_41_42", old_result.get("status") == "FAIL_CLOSED" and old_result.get("checks_passed") == 41 and old_result.get("checks_total") == 42)
    check("I010_ONLY_I029_FAILED", failures == ["I029_PROMPT_DENIES_TOOLS"], failures)
    prompt = (V1 / "fixture/worker-prompt.txt").read_text(encoding="utf-8")
    validator = (V1 / "validators/independent_static_validate.py").read_text(encoding="utf-8")
    check("I011_RESTRICTION_SEMANTICALLY_PRESENT", semantic_policy_accepts(prompt))
    check("I012_RAW_CONTIGUOUS_ABSENT", "Do not access any network or target" not in prompt)
    check("I013_RAW_MATCH_IMPLEMENTATION", '"Do not access any network or target" in prompt' in validator)

    primary = read(ROOT / "GOVERNANCE_VALIDATION_RESULT_RUN-0001.json")
    prompt_result = read(ROOT / "PROMPT_NORMALIZATION_REGRESSION_RESULT_RUN-0001.json")
    negative = read(ROOT / "NEGATIVE_GOVERNANCE_TEST_RESULT_RUN-0001.json")
    check("I014_PRIMARY_PASS", primary.get("status") == "PASS" and primary.get("checks_failed") == 0)
    check("I015_PROMPT_REGRESSION_PASS", prompt_result.get("status") == "PASS" and prompt_result.get("tests_passed") == 9 and prompt_result.get("tests_failed") == 0)
    check("I016_NEGATIVE_PASS", negative.get("status") == "PASS" and negative.get("tests_passed") == 20 and negative.get("tests_failed") == 0)

    matrix = read(ROOT / "PROMPT_NORMALIZATION_REGRESSION_MATRIX.json")
    independent_results = []
    for case in matrix.get("cases", []):
        observed = "PASS" if semantic_policy_accepts(case.get("prompt", "")) else "REJECT"
        independent_results.append({
            "case_id": case.get("case_id"), "expected": case.get("expected"), "observed": observed,
            "status": "PASS" if observed == case.get("expected") else "FAIL",
        })
    independent_regression_failures = [row for row in independent_results if row["status"] == "FAIL"]
    check("I017_INDEPENDENT_REGRESSION_9_9", len(independent_results) == 9 and not independent_regression_failures, independent_results)

    terminal = read(ROOT / "V1_TERMINAL_DISPOSITION.json")
    defect = read(ROOT / "PROMPT_POLICY_AND_VALIDATOR_DEFECT_ADJUDICATION.json")
    contract = read(ROOT / "CANONICAL_PROMPT_RESTRICTION_MATCHING_CONTRACT.json")
    successor = read(ROOT / "SUCCESSOR_V2_AUTHORIZATION_DECISION.json")
    requirements = read(ROOT / "SUCCESSOR_V2_REQUIREMENTS.json")
    authority = read(ROOT / "AUTHORITY_NON_ESCALATION_DECISION.json")
    matrix_auth = read(ROOT / "OPERATION_AUTHORIZATION_MATRIX.json")
    check("I018_V1_DISPOSITION", terminal.get("disposition") == "FAIL_CLOSED_PRELOCK_REFERENCE_ONLY" and terminal.get("immutable") is True)
    check("I019_V1_NO_PATCH_REVALIDATE_LOCK_EXEC", all(terminal.get(key) == "PROHIBITED" for key in ["patch", "revalidation", "lock", "execution"]))
    check("I020_V1_ZERO_COUNTS", terminal.get("attempt") == "0_OF_1_NOT_CONSUMED" and terminal.get("worker_invocation") == "0_OF_1" and terminal.get("codex_as_worker_invocation") == "0_OF_1")
    check("I021_DEFECT_CLASSIFICATION", defect.get("prompt_policy_defect") == "NO" and defect.get("prompt_authority_restriction_present") == "YES" and defect.get("independent_validator_normalization_defect") == "YES")
    check("I022_NO_AUTHORITY_ESCALATION", defect.get("actual_authority_escalation") == "NO" and defect.get("actual_prompt_gap") == "NO")
    check("I023_DETERMINISTIC_CONTRACT", contract.get("free_form_model_semantic_adjudication") == "PROHIBITED" and contract.get("raw_substring_match_on_unnormalized_prompt") == "PROHIBITED_AS_AUTHORITATIVE_POLICY_VERDICT")
    check("I024_SUCCESSOR_V2", successor.get("decision") == "AUTHORIZE_DISTINCT_FIRST_REAL_SECURITY_WORKER_INVOCATION_V2_CONDITIONALLY" and successor.get("state") == "CONDITIONALLY_AUTHORIZED_NOT_CREATED_NOT_EXECUTED")
    check("I025_SUCCESSOR_ZERO_COUNTS", successor.get("attempt_count") == 0 and successor.get("worker_invocation_count") == 0 and successor.get("codex_as_worker_invocation_count") == 0)
    required = set(requirements.get("mandatory_requirements", []))
    check("I026_SUCCESSOR_NORMALIZATION_REQUIREMENTS", {
        "CANONICAL_WHITESPACE_NORMALIZATION_BEFORE_POLICY_COMPARISON",
        "MISSING_WEAKENED_AND_INVERTED_RESTRICTION_NEGATIVE_REGRESSIONS",
        "NO_RAW_UNNORMALIZED_CONTIGUOUS_LITERAL_AS_AUTHORITATIVE_VERDICT",
    }.issubset(required))
    counters = authority.get("operation_counters", {})
    check("I027_OPERATION_COUNTERS_ZERO", len(counters) == 12 and all(value == 0 for value in counters.values()), counters)
    current_auth = matrix_auth.get("current_milestone", {})
    check("I028_GOVERNANCE_ONLY", set(current_auth) == {"read_v1_evidence", "governance_validation", "governance_freeze"})
    check("I029_NO_V2_CREATE_EXECUTE", successor.get("creation_or_execution_this_milestone") is False and not V2.exists())
    routing = read(ROOT / "ROUTING_LEDGER.json")
    check("I030_NO_OPERATIONAL_ROUTING", routing.get("subagents_used") is False and routing.get("codex_invoked") is False and routing.get("worker_invoked") is False and routing.get("network_used") is False)

    failed = [row for row in checks if row["status"] == "FAIL"]
    write({
        "record_type": "FIRST_WORKER_V1_NORMALIZATION_ERRATUM_INDEPENDENT_VALIDATION_RESULT", "schema_version": "1.0",
        "run_id": "INDEPENDENT_VALIDATION_RUN-0001", "status": "PASS" if not failed else "FAIL_CLOSED",
        "checks": checks, "checks_total": len(checks), "checks_passed": len(checks) - len(failed), "checks_failed": len(failed),
        "independent_prompt_regression_results": independent_results,
        "attempt_count": 0, "worker_invocation_count": 0, "codex_as_worker_invocation_count": 0,
    })
    print(json.dumps({"status": "PASS" if not failed else "FAIL_CLOSED", "passed": len(checks) - len(failed), "total": len(checks)}, sort_keys=True))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
