# Pilot V2 clean holdout

These eight opaque cases are source snapshots for the blinded Pilot V2. Worker-visible
files contain no class labels, advisory identifiers, patch diffs, or curator oracles.
Ground truth and fingerprints live outside this tree under the curator-only store.

Do not run either benchmark system against these cases before the schedule is sealed.
