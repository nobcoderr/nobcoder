#!/bin/sh
set -eu
cd "$(dirname "$0")/../target"
PYTHONDONTWRITEBYTECODE=1 python smoke_test.py
