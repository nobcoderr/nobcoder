#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
PYTHONPYCACHEPREFIX="${TMPDIR:-/tmp}/pilot-v2-build-$$" python -m compileall -q target
