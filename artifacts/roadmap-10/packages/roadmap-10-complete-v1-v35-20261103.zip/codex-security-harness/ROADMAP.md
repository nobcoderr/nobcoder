# NobCoder red-team roadmap

This document is a non-authoritative architecture roadmap. It records supported
future capabilities and research-method inputs; it does not grant execution,
target, credential, network, worker, exploit, or submission authority.

## Current milestone

`V0_3_RUNTIME_AND_MODEL_COMPATIBILITY_EXECUTION_V3` is the active engineering
lineage. Its only conditionally authorized runtime action is one identity-bound
Codex CLI 0.162.1 compatibility invocation after every pre-attempt gate and the
static lock pass. Compatibility acceptance remains a separate governance step.

## Planned sequence

1. Compatibility Execution V3 and separate Codex compatibility acceptance.
2. `SecurityWorkerRuntime` contract and bounded execution authorization.
3. Credential Broker and Target Access Gateway contracts.
4. Red-Team Methodology and Evidence Ladder contract.
5. Blind historical OSS vulnerability-rediscovery benchmarks.
6. Fresh OSS holdout evaluation.
7. One authorized target-interacting worker.
8. Hermes active verifier under a separate scoped identity.
9. Serial candidate portfolio.
10. Parallel falsifiable research lanes.
11. Capability graph and full-chain integration.
12. Authorized bug-bounty campaigns and separately governed submission flow.

Every future capability is supported by architecture but remains
`DEFERRED_REQUIRES_SEPARATE_AUTHORIZATION` until its own gate is frozen.

## Historical vulnerability rediscovery benchmark

The public [PwnEscape article](https://pwn.ai/blog/pwnescape) is registered only
as external prior art and methodology input:

```text
classification = PUBLIC_PRIOR_ART_REFERENCE
uses =
  THREAT_MODEL_REFERENCE
  HISTORICAL_REDISCOVERY_BENCHMARK
  EVIDENCE_LADDER_EXAMPLE
  ATTACK_SURFACE_EXPANSION_EXAMPLE
not =
  NEW_FINDING
  CURRENT_CANDIDATE
  EXECUTION_AUTHORIZATION
```

Any vulnerability identifier, date, attribution, or impact statement taken
from that article is unverified prior-art metadata until independently checked.
No article command or PoC is authorized by this registry entry.

The future benchmark will use a pinned historical revision in an offline,
researcher-owned environment. Ground truth is withheld from the worker. The
evaluation measures attack-surface mapping, hypothesis generation, root-cause
rediscovery, controlled PoC construction, impact escalation, and eventual
comparison with the known disclosure. Rediscovery earns no new-finding credit.

## Methodology additions

The Red-Team Methodology contract is expected to make these objects first
class:

- `AttackSurface` and `TrustBoundary`, including non-obvious subsystems touched
  by attacker-controlled state;
- `HistoricalInvariant` and `InvariantHypothesis`, covering legacy assumptions,
  cross-version semantic drift, deferred work, stale metadata, and old-API/new-
  consumer interactions;
- `Experiment` and `FailedExperiment`, preserved append-only;
- an evidence ladder from source anomaly through primitive, boundary crossing,
  controlled read/write, privilege capability, end-to-end impact, and full
  chain;
- explicit distinctions such as leak != RCE, write != RCE, and owned-lab RCE
  != production RCE;
- `ResearchCostTelemetry`: time to first hypothesis, primitive, and `STRONG`;
  tokens/API cost; experiments; killed hypotheses; duplicates; and false-
  positive rate.

These additions are proposals for a later contract. They do not modify the
active compatibility execution contract retroactively.
